"""Reference-led production contracts and content-bound release review.

No model inference is hidden here: the host agent supplies the creative plan and
observations. Deterministic checks fail closed; review attestations are labelled.
"""
from __future__ import annotations
import hashlib
import json
import math
import re
import time
from pathlib import Path
from . import util

SCHEMA = 1
STATES = {'waiting_editor', 'analysing', 'planning', 'building', 'reviewing', 'ready', 'blocked'}
CHECKS = ('speech', 'reference', 'typography', 'motion', 'assets', 'audio', 'colour')
INPUTS = ('project.json', 'active-edit-request.json', 'words.json', 'segments.json', 'scene-plan.json', 'edit-plan.json', 'customer-memory.json', 'style-inputs.json', 'style-direction.json', 'selected-library.json', 'render/grade.json','cut-controls.json', 'work/style-library/picks.json', 'work/style-library/words.json', 'work/style-library/layout.json', 'work/style-library/plan.json', 'work/style-library/execution.json')


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def state(p: Path, phase: str | None = None, message: str = '', **extra) -> dict:
    d = util.read_json(p / 'workflow.json', default={})
    if phase:
        if phase not in STATES:
            raise util.Fail('Unknown editing stage.')
        d.update(phase=phase, message=message, updated=time.time(), **extra)
        util.write_json(p / 'workflow.json', d)
    # A stale lease never presents an idle editor as actively working.
    if d.get('phase') in {'analysing', 'planning', 'building', 'reviewing'} and d.get('lease_until', 0) < time.time():
        d = dict(d, phase='waiting_editor', message='Editor activity needs checking; your project and messages are saved.')
    return d


def claim(p: Path, owner: str, phase='analysing',request_id=None,delivery_token=None) -> dict:
    if phase not in {'analysing', 'planning', 'building', 'reviewing'}:
        raise util.Fail('Choose analysing, planning, building, or reviewing.')
    # OS ownership releases on process exit; an abandoned directory cannot
    # permanently block every subsequent claim after an interrupted command.
    with util.file_guard(p / '.editor.guard', 'This edit is already running in a chat. Continue there with workflow next, or choose Continue in a new chat in Studio.', timeout=5):
        d = util.read_json(p / 'workflow.json', default={})
        from . import editor,chat_execution
        native=p.resolve().parent==util.PROJECTS.resolve() and (p/'project.json').is_file() and editor.read(p.name).get('execution_mode')=='chat'
        if native and chat_execution.paste_only():
            import secrets
            owner='chat-'+secrets.token_hex(16)
        elif not owner.strip():raise util.Fail('Identify the agent session that is doing the work.')
        if native:
            # The guarded delivery generation is authoritative. A crash after
            # revocation must not let its obsolete workflow lease strand a new claim.
            chat_execution.claim(p,request_id,owner,delivery_token)
        elif d.get('lease_until', 0) > time.time() and d.get('owner') != owner:
            raise util.Fail('Another editor holds this project.', 'Wait for its lease to expire or use that session.')
        same_request = (request_id is None and d.get('request_id') is None) or bool(request_id) and d.get('request_id') == request_id
        return state(p, phase, {'analysing':'Studying your footage and instructions','planning':'Planning your edit','building':'Building your video','reviewing':'Checking your video'}[phase], owner=owner, request_id=request_id, started=(d.get('started') if same_request else None) or time.time(), lease_until=time.time() + 1800)


def next_step(p: Path, owner: str) -> dict:
    """Recover context without revealing a delivery capability to another owner."""
    from . import editor,requests,chat_execution,activity_store
    with util.file_guard(p/'.editor-job.guard',timeout=5):
        job=editor.read(p.name)
        if not owner or job.get('claimed_owner')!=owner or job.get('state')!='editing' or job.get('cancel'):
            raise util.Fail('This conversation does not own the edit. Use Studio to resume it safely.')
        import os
        host=os.environ.get('CODEX_THREAD_ID') or os.environ.get('CLAUDE_SESSION_ID') or ''
        if job.get('claimed_host_id') and host!=job['claimed_host_id'] and os.environ.get('CREATORCUT_NATIVE_DELIVERY')!=job.get('delivery_token'):
            raise util.Fail('This host conversation does not own the edit. Use Studio to resume it safely.')
        request=requests.active(p)
        if request.get('id')!=job.get('request_id'):raise util.Fail('The saved request changed. Open Studio before continuing.')
        token=job['delivery_token']
        candidate=util.read_json(p/'render/candidate.json',default={})
        verified=[]
        if candidate.get('file') and candidate.get('sha256'):
            f=(p/candidate['file']).resolve()
            if f.is_relative_to(p.resolve()) and f.is_file() and digest(f)==candidate['sha256'] and candidate.get('inputs')==fingerprint(p):
                verified.append({'file':candidate['file'],'sha256':candidate['sha256']})
        activity=activity_store.latest(p.name)
        if activity.get('running'):command=None;waiting='Wait for the current step to finish; do not start a second command.'
        elif verified:
            try:require_release(p);command='workflow publish'
            except util.Fail:
                evidence=util.read_json(p/'render/evidence.json',default={})
                command='workflow review-dry-run' if evidence.get('candidate_sha256')==candidate['sha256'] else 'workflow evidence'
            waiting=None
        elif (p/'edit-plan.json').is_file() and (p/'scene-plan.json').is_file():command='workflow validate';waiting=None
        else:command='workflow init';waiting=None
        return {'project':p.name,'request_id':request['id'],'request':request,'delivery_token':token,'workflow':state(p),
                'completed_steps':['candidate_hash_and_inputs_verified'] if verified else [],'verified_artifacts':verified,'activity':activity,'waiting':waiting,
                'next_action':'Inspect the returned request and plans; supply the review report for review-dry-run, or finish the creative plan before rendering.',
                'next_command':('edit.py '+command+' '+p.name) if command else None,
                'environment':{'CREATORCUT_NATIVE_DELIVERY':token}}


def initial_decisions(settings):
    """Start from immutable choices, never an accidental creative opposite."""
    from . import colour_choice
    music=settings.get('music_selection') or {}
    mode=music.get('mode') or ('none' if settings.get('music') in (None,'','none') else 'auto' if settings.get('music')=='auto' else 'provided')
    decision={'none':'none','library':'provided','upload':'provided','provided':'provided','auto':'licensed'}.get(mode)
    if decision is None:raise util.Fail('Choose your music again in Studio, then press Make.')
    colour=colour_choice.choice(settings)
    result={'colour':'preserve' if colour=='natural' else 'reference' if colour=='reference' else 'custom',
            'voice':'process' if settings.get('voice_cleanup') is True else 'preserve','music':decision}
    if result['colour']=='custom' or result['voice']=='process':result['reason']='Apply the exact saved Studio colour and voice choices; do not replace them with defaults.'
    return result


def init(p: Path) -> dict:
    cfg = util.read_json(p / 'project.json')
    from . import requests
    saved=util.read_json(p/'scene-plan.json',default={});request=requests.active(p)
    if request and saved and saved.get('request_id')==request['id']:return saved
    from . import learn, revision_context
    revision_context.write(p)
    learn.project_memory(p, cfg.get('style'))
    from . import signature
    signature.write_direction(p)
    from . import library
    library.context(p)
    existing = util.read_json(p / 'scene-plan.json', default={})
    if existing:
        return existing
    doc = {'schema': SCHEMA, 'brief': cfg.get('brief', {}).get('prompt', ''),
           'reference': {'source': '', 'evidence': [], 'summary': ''},
           'decisions': initial_decisions({**cfg,**request.get('settings',{})}),
           'requirements': [], 'scenes': [], 'unresolved': []}
    util.write_json(p / 'scene-plan.json', doc)
    state(p, 'planning', 'Preparing a scene plan from your request and reference.')
    return doc


def local(p: Path, source: str) -> Path:
    if not source or not isinstance(source, str):
        raise util.Fail('A local asset path is missing.')
    f = Path(source)
    if not f.is_absolute():
        f = p / f if (p / f).exists() else util.ROOT / f
    if f.is_absolute():f=util.app_path(f)
    f = f.resolve()
    if not f.is_file():
        raise util.Fail(f'An asset is missing: {source}')
    return f


def _number(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def validate(p: Path, *, runtime=False) -> dict:
    doc = util.read_json(p / 'scene-plan.json', default={})
    plan = util.read_json(p / 'edit-plan.json', default={})
    errors, warnings = [], []
    structural = []
    if not isinstance(doc,dict) or not isinstance(plan,dict):
        structural.append('Scene and edit plans must be JSON objects.')
    else:
        for obj,key,typ in [(doc,'scenes',list),(doc,'requirements',list),(doc,'reference',dict),(doc,'decisions',dict),
                            (plan,'items',list),(plan,'canvas',dict),(plan,'fonts',dict),(plan,'styles',dict)]:
            if not isinstance(obj.get(key),typ): structural.append(f'{key} must be a {typ.__name__}.')
        for seq in (doc.get('scenes',[]),doc.get('requirements',[]),plan.get('items',[])):
            if isinstance(seq,list) and any(not isinstance(x,dict) for x in seq): structural.append('Scenes, requirements and render items must be objects.')
        for x in doc.get('scenes',[]) if isinstance(doc.get('scenes'),list) else []:
            if isinstance(x,dict) and (not isinstance(x.get('items',[]),list) or any(not isinstance(i,str) for i in x.get('items',[]))):
                structural.append('Scene item bindings must be a list of string ids.')
    if structural:
        result={'ok':False,'errors':structural,'warnings':[],'checked_at':time.time()}
        util.write_json(p/'render'/'contract-check.json',result)
        return result
    journal=util.read_json(p/'plan-transaction.json',default={})
    if journal and journal.get('phase')!='committed':errors.append('Recover the interrupted plan save with plan-save --recover before rendering.')
    from . import requests
    errors.extend(requests.errors(p,doc))
    from . import refs
    try: refs.production_inputs(p.name)
    except util.Fail as error: errors.append(str(error))
    try:request=requests.active(p)
    except util.Fail:request={}
    if request.get('schema',1)>=3 and (request.get('batch') or {}).get('notes'):
        from . import annotations
        saved={n['id']:n for n in annotations.read(p.name).get('notes',[])}
        for note in request['batch']['notes']:
            if saved.get(note['id'],{}).get('status') not in ('editing','ready'):
                errors.append('Record the actual feedback before rendering this revision: '+note['id'])
    from . import library
    if doc.get('schema') != SCHEMA:
        errors.append('scene-plan.json needs schema 1.')
    if not doc.get('brief', '').strip():
        errors.append('Record the customer brief in scene-plan.json.')
    if doc.get('unresolved'):
        errors.append('Resolve or discuss the listed missing assets / uncertain instructions.')
    from . import colour_choice
    errors.extend(colour_choice.errors(p,doc,plan))
    from . import render_controls
    try:
        plan=render_controls.preflight(p)
    except util.Fail as error:errors.append(error.message)
    errors.extend(render_controls.errors(p,doc,plan))
    from . import request_constraints
    errors.extend(request_constraints.errors(p,doc,plan,request.get('settings',{})))
    decisions = doc.get('decisions', {})
    for key, values in {'colour': {'preserve','reference','custom'}, 'voice': {'preserve','process'}, 'music': {'none','provided','licensed'}}.items():
        if decisions.get(key) not in values:
            errors.append(f'Choose an explicit {key} decision: {sorted(values)}.')
    if any(decisions.get(k) == v for k,v in [('colour','custom'),('voice','process')]) and not decisions.get('reason'):
        errors.append('Explain requested creative colour / voice changes in decisions.reason.')
    dur = plan.get('duration')
    if not _number(dur) or not 0 < dur <= 14400:
        errors.append('The edit plan needs a valid duration (up to four hours).')
        dur = 0
    cv = plan.get('canvas', {})
    if not (all(isinstance(cv.get(k),int) and not isinstance(cv[k],bool) and 16 <= cv[k] <= 7680 and cv[k]%2==0 for k in ('w','h'))
            and _number(cv.get('fps')) and 1 <= cv['fps'] <= 120):
        errors.append('Canvas needs even width/height from 16 to 7680 and fps from 1 to 120.')
    for key, st in plan.get('styles',{}).items():
        if st.get('font',key) not in plan.get('fonts',{}):
            errors.append(f'Text style {key} has no configured font.')
        if not _number(st.get('size')) or not 0 < st['size'] <= 3:
            errors.append(f'Text style {key} needs a positive canvas-relative size.')
    scenes = doc.get('scenes') or []
    if not scenes:
        errors.append('Plan the video scene by scene before rendering.')
    ids, item_ids = set(), set()
    items = plan.get('items') or []
    for item in items:
        if not isinstance(item, dict):
            errors.append('Every render item must be an object.'); continue
        iid = item.get('id')
        if not isinstance(iid,str):
            errors.append('Render item id must be a string.'); continue
        if not iid or iid in item_ids:
            errors.append('Every render item needs a unique id.')
        item_ids.add(iid)
        a,b = item.get('t0'),item.get('t1')
        if not (_number(a) and _number(b) and 0 <= a < b <= dur + .05):
            errors.append(f'Invalid item timing: {iid}.')
        if item.get('type') not in {'caption','card','note','burst','html','piece'}:
            errors.append(f'Unsupported render item: {iid}.')
    cursor = 0.
    scene_by_id = {}
    words = util.read_json(p / 'words.json', default={'words':[]}).get('words',[])
    norm = lambda s: ' '.join(''.join(c.lower() if c.isalnum() else ' ' for c in s).split())
    transcript = norm(' '.join(w.get('w','') for w in words))
    for s in scenes:
        sid = s.get('id')
        if not isinstance(sid,str):
            errors.append('Scene id must be a string.'); continue
        if not sid or sid in ids:
            errors.append('Each scene needs a unique id.')
        ids.add(sid); scene_by_id[sid] = s
        a,b = s.get('t0'),s.get('t1')
        if not (_number(a) and _number(b) and 0 <= a < b <= dur + .05):
            errors.append(f'Invalid scene timing: {sid}.'); continue
        if abs(a - cursor) > .06:
            errors.append(f'Gap or overlap before scene {sid}; include intentional plain footage as a scene.')
        cursor = b
        for key in ('speech','purpose','layout','entry','hold','exit','sound'):
            if not isinstance(s.get(key), str) or not s[key].strip():
                errors.append(f'{sid}: describe {key} (use "none" when intentional).')
        if not s.get('items') and s.get('treatment') != 'footage':
            errors.append(f'{sid}: bind render item ids or mark treatment footage.')
        for iid in s.get('items',[]):
            matches = [i for i in items if i.get('id') == iid]
            if len(matches) != 1:
                errors.append(f'{sid}: missing or ambiguous render item {iid}.')
            elif matches[0].get('t0',dur+1) >= b or matches[0].get('t1',-1) <= a:
                errors.append(f'{sid}: item {iid} does not intersect this scene.')
        if words and norm(s.get('speech','')) not in transcript and s.get('speech') != 'none':
            errors.append(f'{sid}: spoken anchor does not occur in the cut transcript.')
        elif words and s.get('speech')!='none':
            # A phrase can cross a scene boundary while its title continues.
            # Its actual spoken interval must still touch this scene; merely
            # occurring elsewhere in the movie is not a timing anchor.
            timed=[(token,w.get('start',0),w.get('end',0)) for w in words for token in norm(w.get('w','')).split()]
            wanted=norm(s['speech']).split();found=False
            for first in range(len(timed)-len(wanted)+1):
                window=timed[first:first+len(wanted)]
                if [x[0] for x in window]==wanted and window and window[-1][2]>=a-.08 and window[0][1]<=b+.08:found=True;break
            if not found:errors.append(f"{sid}: spoken anchor does not occur within this scene's cut words.")
    if dur and abs(cursor-dur) > .06:
        errors.append('Scenes must cover the full cut timeline.')
    memory = util.read_json(p/'customer-memory.json', default={})
    rules = [r['rule'] for r in memory.get('creator',[])+memory.get('preset',[]) if r.get('rule')]
    rules += [r.get('rule') or r.get('text','') for r in memory.get('project_feedback',[]) if r.get('scope')=='project']
    application = doc.get('memory_application', [])
    if not isinstance(application, list):
        errors.append('memory_application must be a list.'); application=[]
    for rule in dict.fromkeys(rules):
        row=next((x for x in application if isinstance(x,dict) and x.get('rule')==rule),None)
        if not row or row.get('status') not in {'applied','overridden','not_applicable'}:
            errors.append('Account for saved editing feedback in memory_application: '+rule[:100]); continue
        if len(str(row.get('reason','')).strip())<12:
            errors.append('Explain how saved feedback was applied or overridden: '+rule[:100])
        if row['status']=='applied' and (not row.get('scenes') or not isinstance(row['scenes'],list) or any(x not in scene_by_id for x in row['scenes'])):
            errors.append('Bind the applied preference to actual scenes: '+rule[:100])
    bound = {i for s in scenes for i in s.get('items',[])}
    if item_ids - bound:
        errors.append('Bind every render item to a scene: ' + ', '.join(str(x) for x in item_ids-bound))
    for it in items:
        if not (_number(it.get('t0')) and _number(it.get('t1'))): continue
        covered = it['t0']
        bindings = sorted((s for s in scenes if it.get('id') in s.get('items',[]) and _number(s.get('t0')) and _number(s.get('t1'))),key=lambda s:s['t0'])
        for s in bindings:
            if s['t0'] > covered + .06: break
            covered = max(covered,s['t1'])
        if covered < it['t1'] - .06:
            errors.append(f'{it.get("id")}: bind this continuous item to every scene it spans.')
    ref = doc.get('reference',{})
    cfg = util.read_json(p/'project.json',default={})
    from . import refs
    expects_reference = bool(cfg.get('brief',{}).get('references')) or bool(refs.for_project(p.name)) or str(cfg.get('style','')).startswith('ref-')
    if expects_reference and not ref.get('source') and not doc.get('reference_override'):
        errors.append('This project has a reference. Link its source and evidence, or document the customer instruction to ignore it.')
    if ref.get('source'):
        reference_duration=None
        try:
            reference_source=local(p,ref['source'])
            if reference_source.suffix.lower() not in util.IMAGE_EXT:
                measured=util.probe(reference_source)
                reference_duration=float(measured.get('video_duration') or measured.get('duration') or 0)
                if not math.isfinite(reference_duration) or reference_duration<=0:raise util.Fail('The reference duration could not be read. Upload a playable reference file.')
        except util.Fail as e: errors.append(e.message)
        if not ref.get('summary') or not ref.get('evidence'):
            errors.append('Study the actual reference: add a summary and local evidence frames / sheets.')
        for f in ref.get('evidence',[]):
            try: local(p,f)
            except util.Fail as e: errors.append(e.message)
        for s in scenes:
            r = s.get('reference')
            if r and not (isinstance(r, dict) and _number(r.get('t0')) and _number(r.get('t1')) and 0 <= r['t0'] < r['t1']):
                errors.append(f'{s.get("id")}: reference needs valid t0/t1 timing.')
            if isinstance(r,dict) and _number(r.get('t1')) and reference_duration is not None and r['t1']>reference_duration+.001:
                errors.append(f"{s.get('id')}: reference.t1 exceeds the measured reference duration ({reference_duration:.3f}s). Correct its timing before rendering.")
            if not s.get('reference') and not s.get('adaptation'):
                errors.append(f'{s.get("id")}: add reference timing or explain the adaptation.')
    else:
        if not doc.get('style_direction'):
            errors.append('Without a reference, record the customer-approved style direction.')
    for r in doc.get('requirements',[]):
        if not r.get('id') or not r.get('text') or not r.get('scenes') or any(s not in ids for s in r.get('scenes',[])):
            errors.append('Every brief requirement needs an id, text, and valid scene ids.')
    if not doc.get('requirements'):
        errors.append('Map the customer requirements to scenes.')
    for font in plan.get('fonts',{}).values():
        try: local(p,font.get('file',''))
        except util.Fail as e: errors.append(e.message)
    for it in items:
        for wd in it.get('words',[]):
            if wd.get('style','caption') not in plan.get('styles',{}):
                errors.append(f'Undefined text style in {it.get("id")}.')
        if it.get('behind') and not plan.get('person_cutout'):
            errors.append('Behind-person graphics need a real foreground mask.')
    paths = [plan.get('background',{}).get('src','')]
    paths += [plan['person_cutout']['src']] if plan.get('person_cutout') else []
    for i in items:
        if i.get('src'): paths.append(i['src'])
        paths += i.get('srcs',[])
        paths += list(i.get('assets',{}).values())
    for src in paths:
        try: local(p,src)
        except util.Fail as e: errors.append(e.message)
    if decisions.get('colour') == 'preserve' and plan.get('background',{}).get('src') == 'graded.mp4':
        errors.append('Original colour requested, but the background uses graded.mp4.')
    audio = plan.get('audio',{})
    if decisions.get('music') == 'none' and audio.get('music'):
        errors.append('The saved scene plan says no music, but a music track is configured. Match the music decision to the saved Studio request; do not delete a requested track.')
    if decisions.get('sfx') == 'none' and audio.get('events'):
        errors.append('Sound effects are disabled in the scene decisions.')
    if decisions.get('music') != 'none' and not audio.get('music'):
        errors.append('Music was planned but no music asset is configured.')
    try:
        from . import soundtrack
        soundtrack.validate(p,plan)
    except util.Fail as e: errors.append(e.message)
    runtime_checks={'performed':False,'reason':'Metadata checks only; the CLI preflight runs capacity and browser checks in its actual host.'}
    if runtime and not errors:
        from . import capacity,browser_runtime
        try:
            space=capacity.check(p,plan)
            layout=browser_runtime.ensure(p)
            runtime_checks={'performed':True,'capacity':space,'browser':layout}
        except util.Fail as error:errors.append(error.message)
    result = {'ok':not errors,'errors':errors,'warnings':warnings,'runtime_checks':runtime_checks,'checked_at':time.time()}
    util.write_json(p/'render'/'contract-check.json', result)
    return result


def require_plan(p: Path):
    result = validate(p)
    if not result['ok']:
        raise util.Fail('The scene plan is incomplete.', '\n'.join(result['errors'][:15]))


def fingerprint(p: Path) -> dict:
    # Exclude runtime project status/version fields so publication doesn't invalidate itself.
    cfg = util.read_json(p/'project.json')
    for key in ('status','version','latest','rendered_at','generated_at','shelf','selected_version','title','saved_presets','preparation','studio_step','settings_need_edit','choice_origins','reference_style'):
        cfg.pop(key,None)
    if isinstance(cfg.get('framing'),dict):cfg['framing'].pop('auto_face',None)
    if 'media' in cfg:
        from . import requests
        cfg['media']=requests.settings(cfg)['media']
    out = {'project':hashlib.sha256(json.dumps(cfg,sort_keys=True).encode()).hexdigest()}
    # reference_style is a derived asynchronous index, not creative evidence.
    # Bind actual scan contents and the rendered direction/plan instead. A late
    # index write cannot invalidate an otherwise identical reviewed candidate.
    from . import refs
    for name, sha in refs.production_inputs(p.name).items():
        out['reference-analysis/' + name] = sha
    for name in INPUTS[1:]:
        f = p/name
        out[name] = digest(f) if f.exists() else None
    plan = util.read_json(p/'edit-plan.json',default={})
    paths = [plan.get('background',{}).get('src','')]
    if plan.get('person_cutout'): paths.append(plan['person_cutout']['src'])
    paths += [f.get('file','') for f in plan.get('fonts',{}).values()]
    for it in plan.get('items',[]):
        paths += ([it['src']] if it.get('src') else []) + it.get('srcs',[]) + list(it.get('assets',{}).values())
    audio = plan.get('audio',{})
    paths += [x.get('src','') for x in audio.get('events',[])]
    if audio.get('music'): paths.append(audio['music'].get('src',''))
    doc = util.read_json(p/'scene-plan.json',default={})
    paths += doc.get('reference',{}).get('evidence',[])
    if doc.get('reference',{}).get('source'): paths.append(doc['reference']['source'])
    for src in sorted(set(paths)):
        f = local(p,src)
        out[str(f.relative_to(util.ROOT)) if f.is_relative_to(util.ROOT) else str(f)] = digest(f)
    return out


def register(p: Path, video: Path) -> dict:
    require_plan(p)
    check = util.read_json(p/'render'/'check.json',default={})
    if not check.get('ok'):
        raise util.Fail('The renderer technical check did not pass.')
    from . import delivery
    video = delivery.prepare(p, video)
    info = util.probe(video)
    plan = util.read_json(p/'edit-plan.json')
    if abs(info['duration'] - plan['duration']) > max(.15,2 / plan.get('canvas',{}).get('fps',30)):
        raise util.Fail('The video duration does not match the scene plan.')
    cv = plan.get('canvas',{})
    if (info['width'],info['height']) != (cv.get('w'),cv.get('h')):
        raise util.Fail('The video dimensions do not match the planned canvas.')
    if abs(info['fps'] - delivery.FPS) > .001:
        raise util.Fail('The video does not match the 30 fps delivery profile.')
    # One complete decode verifies the video and measures audio with real frame/time progress.
    decode=[util.ffmpeg_bin(),'-nostdin','-hide_banner','-xerror','-i',str(video)]
    if info.get('has_audio'):decode+=['-af','volumedetect']
    measured=util.run_progress(decode+['-f','null','-'],info['duration'],detail='Checking the complete video and audio',timeout=max(1800,info['duration']*30+60))
    candidate = {'delivery_profile':delivery.PROFILE,'file':str(video.relative_to(p)), 'sha256':digest(video),'inputs':fingerprint(p),'probe':info,'check_sha256':digest(p/'render'/'check.json'),'created':time.time()}
    audio_check={'candidate_sha256':candidate['sha256'],'has_audio':info.get('has_audio',False),
                 'method':'One complete FFmpeg decode with signal measurements; no perceptual listening implied'}
    if info.get('has_audio'):
        for label in ('mean','max'):
            match=re.search(label+r'_volume:\s*(-?[0-9.]+|-[Ii]nf)\s*dB',measured.stderr)
            audio_check[label+'_db']=float(match[1]) if match and 'inf' not in match[1].lower() else None
    util.write_json(p/'render'/'audio-check.json',audio_check)
    candidate['audio_check_sha256']=digest(p/'render'/'audio-check.json')
    util.write_json(p/'render'/'candidate.json',candidate)
    state(p,'reviewing','Candidate rendered. Checking speech, design, motion and sound.')
    return candidate


def evidence_times(p: Path) -> list[float]:
    doc = util.read_json(p/'scene-plan.json')
    times = set()
    for s in doc['scenes']:
        a,b = s['t0'],s['t1']; d = b-a
        times.update(round(t,3) for t in (a+min(.04,d*.05),a+d*.2,a+d*.6,b-min(.04,d*.05)))
    # Short overlays/captions can occur entirely between the broad scene samples.
    # Include their hold and each timed word so typography cannot pass with no visible glyph evidence.
    plan=util.read_json(p/'edit-plan.json',default={})
    for item in plan.get('items',[]):
        a,b=item.get('t0'),item.get('t1')
        if _number(a) and _number(b) and 0<=a<b:
            times.add(round((a+b)/2,3))
            words=item.get('words',[])
            if isinstance(words,list):
                for i,w in enumerate(words):
                    if not isinstance(w,dict):continue
                    start=w.get('t');end=words[i+1].get('t',b) if i+1<len(words) and isinstance(words[i+1],dict) else b
                    if _number(start) and _number(end) and a<=start<end<=b:times.add(round((start+end)/2,3))
    return sorted(times)


def reference_frame(source: Path, at: float, target: Path):
    """End timestamps are boundaries, not frames. Keep candidate on extraction failure."""
    if source.suffix.lower() in util.IMAGE_EXT:
        from PIL import Image
        Image.open(source).convert('RGB').save(target)
        return
    probe=util.probe(source)
    duration=float(probe.get('video_duration') or probe.get('duration') or 0)
    fps=float(probe.get('fps') or 30)
    if duration<=0 or not math.isfinite(duration) or fps<=0 or not math.isfinite(fps):
        raise util.Fail('The reference duration could not be read. Upload a playable reference file; the rendered video is kept.')
    seek=max(0,min(float(at),max(0,duration-1/fps)))
    target.unlink(missing_ok=True)
    try:
        util.run([util.ffmpeg_bin(),'-nostdin','-v','error','-y','-ss',str(seek),'-i',str(source),'-frames:v','1',str(target)],timeout=60)
    except util.Fail:pass
    if target.is_file() and target.stat().st_size:return
    # VFR/edit-list rounding can still leave an empty seek. Decode through EOF
    # and overwrite one image, retaining the actual last decodable frame.
    try:
        util.run([util.ffmpeg_bin(),'-nostdin','-v','error','-y','-i',str(source),'-an','-update','1',str(target)],timeout=max(60,min(600,duration*4)))
    except util.Fail:pass
    if not target.is_file() or not target.stat().st_size:
        target.unlink(missing_ok=True)
        raise util.Fail('The reference review frame could not be read. Retry workflow evidence; your rendered video is kept.')


def make_evidence(p: Path):
    cand = util.read_json(p/'render'/'candidate.json')
    import uuid
    out = p/'render'/'review-frames'/uuid.uuid4().hex; out.mkdir(parents=True,exist_ok=True)
    rows=[]
    from PIL import Image, ImageDraw
    thumbs=[]
    times=evidence_times(p);doc=util.read_json(p/'scene-plan.json')
    fps=float(cand.get('probe',{}).get('fps') or 30)
    count=cand.get('probe',{}).get('frame_count')
    max_frame=max(0,int(count)-1) if count else max(0,round(float(cand.get('probe',{}).get('video_duration') or util.read_json(p/'edit-plan.json')['duration'])*fps)-1)
    indices=sorted({max(0,min(max_frame,math.ceil(t*fps-1e-8))) for t in times})
    if indices:
        expression=util.balanced_sum('eq(n\\,'+str(i)+')' for i in indices)
        util.run([util.ffmpeg_bin(),'-nostdin','-v','error','-y','-i',str(p/cand['file']),'-vf','select='+expression,'-fps_mode','vfr','-start_number','0',str(out/'candidate-%04d.jpg')],timeout=max(180,util.read_json(p/'edit-plan.json')['duration']*5))
    outputs={index:out/('candidate-%04d.jpg'%n) for n,index in enumerate(indices)}
    for n,t in enumerate(times):
        dst=outputs[max(0,min(max_frame,math.ceil(t*fps-1e-8)))]
        if not dst.is_file():raise util.Fail('Review frame extraction did not finish. Retry the evidence step; the video is kept.')
        row = {'time':t,'frame':max(0,min(max_frame,math.ceil(t*fps-1e-8))),'file':str(dst.relative_to(p))}
        scene = next((x for x in doc['scenes'] if x['t0'] <= t <= x['t1']), None)
        if scene and scene.get('reference') and doc.get('reference',{}).get('source'):
            ref = scene['reference']; source = local(p, doc['reference']['source'])
            rt = ref['t0'] + (t-scene['t0']) / (scene['t1']-scene['t0']) * (ref['t1']-ref['t0'])
            target = out/f'{n:04d}-reference.jpg'
            reference_frame(source,rt,target)
            row.update(reference_time=round(rt,3),reference_file=str(target.relative_to(p)))
        rows.append(row)
        im=Image.open(dst).convert('RGB'); im.thumbnail((180,220))
        tile=Image.new('RGB',(190,250),'#171717'); tile.paste(im,((190-im.width)//2,8))
        ImageDraw.Draw(tile).text((8,230),f'{t:.3f}s',fill='white');thumbs.append(tile)
    sheet=Image.new('RGB',(190*4,250*math.ceil(len(thumbs)/4)),'#171717')
    for n,im in enumerate(thumbs):sheet.paste(im,((n%4)*190,(n//4)*250))
    sheet.save(p/'render'/'review-sheet.jpg')
    util.write_json(p/'render'/'evidence.json',{'candidate_sha256':cand['sha256'],'frames':rows,'sheet':'render/review-sheet.jpg'})


def approve(p: Path, report: dict):
    cand=util.read_json(p/'render'/'candidate.json')
    require_plan(p)
    if digest(p/cand['file']) != cand['sha256'] or fingerprint(p) != cand['inputs']:
        raise util.Fail('The video or inputs changed; render and review again.')
    from . import requests
    request_errors=requests.errors(p,util.read_json(p/'scene-plan.json'),report=report)
    if request_errors:raise util.Fail('Requested changes need review: '+ '; '.join(request_errors))
    if report.get('candidate_sha256') != cand['sha256'] or not report.get('reviewer'):
        raise util.Fail('Review must identify its reviewer and the current video hash.')
    if not report.get('watched_video') and report.get('visual_method') != 'frame_sequence':
        raise util.Fail('Watch the video, or explicitly record frame_sequence inspection with its limitations.')
    if not report.get('listened_audio'):
        audio_check=util.read_json(p/'render'/'audio-check.json',default={})
        if report.get('audio_method') != 'signal_analysis' or audio_check.get('candidate_sha256') != cand['sha256']:
            raise util.Fail('Listen to the audio, or explicitly record signal_analysis using this video audio-check.json.')
    if (not report.get('watched_video') or not report.get('listened_audio')) and not report.get('limitations'):
        raise util.Fail('Disclose the limits of frame/signal review rather than claiming perceptual playback.')
    checks=report.get('checks',{})
    for key in CHECKS:
        if checks.get(key,{}).get('pass') is not True or len(checks.get(key,{}).get('observations','').strip())<12:
            raise util.Fail(f'Review {key} with specific observations; a score alone is insufficient.')
    check=util.read_json(p/'render'/'check.json',default={})
    if cand.get('audio_check_sha256') and digest(p/'render'/'audio-check.json') != cand['audio_check_sha256']:
        raise util.Fail('The audio measurements changed after video registration.')
    if cand.get('check_sha256') and (not (p/'render'/'check.json').exists() or digest(p/'render'/'check.json') != cand['check_sha256']):
        raise util.Fail('The technical findings changed after rendering; review a fresh video.')
    for finding in check.get('review_findings',[]):
        resolution=next((x for x in report.get('exceptions',[]) if x.get('finding')==finding['id']),{})
        if len(resolution.get('reason','').strip()) < 20 or not resolution.get('evidence'):
            raise util.Fail('Resolve this visual finding by fixing and re-rendering, or document intentional reference-led design with evidence: '+finding['id'])
        for src in resolution['evidence']:local(p,src)
    scenes=util.read_json(p/'scene-plan.json')['scenes']
    evidence=util.read_json(p/'render'/'evidence.json',default={})
    if evidence.get('candidate_sha256') != cand['sha256']:
        raise util.Fail('Generate review evidence for this video first.')
    for s in scenes:
        r=report.get('scenes',{}).get(s['id'],{})
        if r.get('pass') is not True or len(r.get('observations','').strip())<12:
            raise util.Fail(f'Inspect entry, movement, hold and exit for {s["id"]}.')
    if report.get('issues'):
        raise util.Fail('Unresolved review issues remain. Fix them and render again.')
    frames = evidence.get('frames', [])
    if len(frames) < len(evidence_times(p)):
        raise util.Fail('Review evidence is incomplete; regenerate it for all scenes.')
    for e in frames:
        local(p,e['file'])
        if e.get('reference_file'): local(p,e['reference_file'])
    report=dict(report,approved_at=time.time(),inputs=cand['inputs'],kind='agent-attested visual/audio review; not an automatic aesthetic score')
    util.write_json(p/'render'/'release-review.json',report)
    return report


def require_release(p: Path):
    cand=util.read_json(p/'render'/'candidate.json',default={})
    review=util.read_json(p/'render'/'release-review.json',default={})
    if not cand or not review or review.get('candidate_sha256')!=cand.get('sha256'):
        raise util.Fail('This video has not passed review.', 'Use workflow evidence, review, then publish.')
    if digest(p/cand['file']) != cand['sha256'] or fingerprint(p)!=review.get('inputs'):
        raise util.Fail('The approved inputs changed. Render and review again.')
    return cand


def publish(p: Path, note=''):
    with util.project_lock(p,heavy_work=False):
        from . import chat_execution
        require_release(p)
        from . import videos
        # snapshot_version is idempotent for an already published candidate.
        v=videos.snapshot_version(p.name,note)
        from . import learn
        learn.complete(p.name, v['candidate_sha256'])
        state(p,'ready','Reviewed version ready.',lease_until=0)
        videos.update(p.name,lambda c:(c.pop('selected_version',None),c.update(status='previewed')))
        from . import chat_execution
        return v


def review_dry_run(p: Path,report:dict):
    """Collect independent review failures without approving or changing the candidate."""
    errors=[]
    if not isinstance(report,dict):return {'ok':False,'errors':['Review must be an object.']}
    try:errors.extend(validate(p)['errors'])
    except (util.Fail,OSError,TypeError,ValueError) as error:errors.append(str(error))
    candidate=util.read_json(p/'render/candidate.json',default={});scene=util.read_json(p/'scene-plan.json',default={})
    from . import requests
    try:errors.extend(requests.errors(p,scene,report=report))
    except (util.Fail,OSError,TypeError,ValueError) as error:errors.append(str(error))
    if not candidate:errors.append('Render and register a candidate before review.')
    else:
        if report.get('candidate_sha256')!=candidate.get('sha256'):errors.append('Review identifies a different candidate.')
        try:
            if digest(p/candidate['file'])!=candidate['sha256'] or fingerprint(p)!=candidate.get('inputs'):errors.append('The candidate or its inputs changed after rendering.')
        except (util.Fail,OSError,KeyError) as error:errors.append('Candidate verification: '+str(error))
    if not report.get('reviewer'):errors.append('Identify the reviewer.')
    if not report.get('watched_video') and report.get('visual_method')!='frame_sequence':errors.append('Watch the video or explicitly record frame_sequence review.')
    if not report.get('listened_audio'):
        audio=util.read_json(p/'render/audio-check.json',default={})
        if report.get('audio_method')!='signal_analysis' or not candidate or audio.get('candidate_sha256')!=candidate.get('sha256'):errors.append('Listen to audio or bind signal_analysis to this candidate.')
    if (not report.get('watched_video') or not report.get('listened_audio')) and not report.get('limitations'):errors.append('Disclose frame/signal inspection limitations.')
    checks=report.get('checks') if isinstance(report.get('checks'),dict) else {}
    for key in CHECKS:
        row=checks.get(key)
        if not isinstance(row,dict) or row.get('pass') is not True or len(str(row.get('observations','')).strip())<12:errors.append('Review '+key+' with specific observations.')
    reviewed=report.get('scenes') if isinstance(report.get('scenes'),dict) else {}
    for row in scene.get('scenes',[]) if isinstance(scene,dict) else []:
        if not isinstance(row,dict):continue
        result=reviewed.get(row.get('id'),{})
        if not isinstance(result,dict) or result.get('pass') is not True or len(str(result.get('observations','')).strip())<12:errors.append('Inspect entry, motion, hold and exit for scene '+str(row.get('id'))+'.')
    if report.get('issues'):errors.append('Resolve the reported review issues before publication.')
    evidence=util.read_json(p/'render/evidence.json',default={})
    if not candidate or evidence.get('candidate_sha256')!=candidate.get('sha256'):errors.append('Generate evidence for the current candidate.')
    for frame in evidence.get('frames',[]):
        if not isinstance(frame,dict):errors.append('Invalid evidence frame.');continue
        for key in ('file','reference_file'):
            if frame.get(key):
                try:local(p,frame[key])
                except util.Fail as error:errors.append(str(error))
    # The full approval gate remains authoritative; this probe cannot approve or publish anything.
    try:approve_probe_errors=_review_integrity_errors(p,report,candidate)
    except (util.Fail,OSError,TypeError,ValueError,KeyError) as error:approve_probe_errors=[str(error)]
    errors.extend(approve_probe_errors)
    return {'ok':not errors,'errors':list(dict.fromkeys(errors)),'kind':'dry run only; no approval written'}


def _review_integrity_errors(p,report,candidate):
    errors=[]
    for key,file in [('check_sha256','check.json'),('audio_check_sha256','audio-check.json')]:
        if candidate.get(key) and (not (p/'render'/file).is_file() or digest(p/'render'/file)!=candidate[key]):errors.append('Registered '+file+' changed after rendering.')
    evidence=util.read_json(p/'render/evidence.json',default={})
    if candidate and len(evidence.get('frames',[]))<len(evidence_times(p)):errors.append('Review evidence is incomplete for the required scenes and overlays.')
    check=util.read_json(p/'render/check.json',default={})
    exceptions=report.get('exceptions',[])
    for finding in check.get('review_findings',[]):
        resolution=next((row for row in exceptions if isinstance(row,dict) and row.get('finding')==finding.get('id')),{})
        if len(str(resolution.get('reason','')).strip())<20 or not resolution.get('evidence'):errors.append('Resolve visual finding '+str(finding.get('id'))+' with evidence.')
        for file in resolution.get('evidence',[]):
            try:local(p,file)
            except util.Fail as error:errors.append(str(error))
    return errors
