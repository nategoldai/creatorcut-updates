"""Immutable Studio instructions and explicit, candidate-bound coverage checks.
These checks enforce traceability, not automatic aesthetic judgement or AI wakeup.
"""
from __future__ import annotations
import hashlib,json
from . import util,videos

FIELDS=('brief','style','preset_version','preset_library_choices','platform','look','library_choices','media','music','music_selection','music_volume','progress_bar','voice_cleanup','cta','captions','framing','grade','colour_recipe','overrides','sfx','zoom')

def settings(cfg):
    result={k:cfg[k] for k in FIELDS if k in cfg}
    if isinstance(result.get('framing'),dict):result['framing']={k:v for k,v in result['framing'].items() if k!='auto_face'}
    if 'media' in result:
        result['media']=[{k:m[k] for k in ('id','kind','file','name','size_mb','duration') if k in m} for m in result['media']]
    return result

# Published17 used schema3 with a shorter settings field list. Keep that exact
# captured contract valid after a code-only update; never rewrite its ID/bytes.
LEGACY17_FIELDS=('brief','style','preset_version','preset_library_choices','platform','look','library_choices','media','music','voice_cleanup','captions','framing','grade','overrides','sfx','zoom')
SETTINGS_CONTRACT='studio-settings-2026-11-02'
def settings_match(cfg,request):
    saved=request.get('settings',{})
    if request.get('settings_contract')==SETTINGS_CONTRACT:return settings(cfg)==saved
    if isinstance(saved,dict) and set(saved).issubset(LEGACY17_FIELDS):
        old={k:cfg[k] for k in LEGACY17_FIELDS if k in cfg}
        if 'media' in old:old['media']=[{k:m[k] for k in ('id','kind','file','name','size_mb','duration') if k in m} for m in old['media']]
        old=dict(old);saved=dict(saved)
        for value in (old,saved):
            if isinstance(value.get('framing'),dict):value['framing']={k:v for k,v in value['framing'].items() if k!='auto_face'}
        return old==saved
    return settings(cfg)==saved


def attached(pid):
    from . import refs
    return [{k:r[k] for k in ('id','kind','url','file','name') if k in r}
            for r in refs.for_project(pid)]

def create(pid, *, batch=None):
    p=videos._dir(pid)
    with util.file_guard(p/'.request.guard',timeout=5),util.file_guard(p/'.editor-job.guard',timeout=5):
        from . import editor
        if editor.read(pid).get('state') not in editor.ACTIVE and (p/'next-settings.json').exists():
            from .server import apply_pending_settings
            apply_pending_settings(pid)
        cfg=videos.load(pid)
        references=attached(pid)
        data={'schema':3,'settings_contract':SETTINGS_CONTRACT,'project':pid,'settings':settings(cfg),'references':references,'batch':batch}
        rid=hashlib.sha256(json.dumps(data,sort_keys=True).encode()).hexdigest()[:32]
        job=editor.read(pid);reuse=False
        if job.get('state') in editor.ACTIVE:
            saved=active(p)
            # Repeated Make after an update is still the SAME immutable intent.
            # Preserve its ID, token and bytes; changed instructions remain refused.
            if saved and saved.get('id')==job.get('request_id') and settings_match(cfg,saved) and saved.get('batch')==batch and saved.get('references',[])==references:
                data=saved;rid=saved['id'];reuse=True
            elif job.get('request_id')!=rid:
                raise util.Fail('Your current edit is still running. Your new notes stay saved; apply them after it finishes.')
        if not reuse:
            data['id']=rid
            dst=p/'edit-requests'/f'{rid}.json'
            if not dst.exists():util.write_durable_json(dst,data)
            util.write_durable_json(p/'active-edit-request.json',data)
    return {'ok':True,'id':rid,'prompt':f'Edit existing project {pid}. Read the COMPLETE immutable request kit/projects/{pid}/edit-requests/{rid}.json, including every setting, full brief, reference and feedback batch. Claim this exact request in the visible CreatorCut chat. Keep that chat open. Prepare footage while reference analysis runs; use completed reference evidence before styling. Do not substitute a generic look for a failed reference. Read kit/docs/request-contract.md. Bind scene-plan.request_id to {rid} and account for every requested setting and note in request_application. Render, inspect and publish only after candidate-bound request_checks pass. Preserve originals and older versions. Use one precedence rule: explicit Studio choices, this video’s written request, chosen reference, saved style and preferences, then defaults. Keep the current execution owner; never fork a competing editor.'}

def active(p):
    d=util.read_json(p/'active-edit-request.json',default={})
    if not d:return {}
    if not isinstance(d,dict) or d.get('schema') not in (1,2,3) or d.get('project')!=p.name:
        raise util.Fail('The saved editing request is invalid. Resend the saved Studio instructions.')
    expected=dict(d);rid=expected.pop('id',None)
    if hashlib.sha256(json.dumps(expected,sort_keys=True).encode()).hexdigest()[:32]!=rid:
        raise util.Fail('The saved editing request changed. Resend the saved Studio instructions.')
    file=p/'edit-requests'/f'{rid}.json'
    if util.read_json(file,default={})!=d:raise util.Fail('The exact editing request snapshot is missing or changed.')
    return d

def required(d):
    s=d.get('settings',{});out=['brief']
    for k in ('style','preset_version','look','platform','library_choices','preset_library_choices'):
        if s.get(k):out.append(k)
    if d.get('schema',1)>=3:
        for k in ('media','music','music_selection','music_volume','voice_cleanup','captions','framing','grade','colour_recipe','overrides','sfx','zoom','progress_bar','keywords','cta'):
            if k in s and s[k] is not None:out.append(k)
    for i,_ in enumerate(s.get('brief',{}).get('references',[])):out.append(f'reference:{i}')
    for r in d.get('references',[]):out.append('studio-reference:'+r['id'])
    if s.get('brief',{}).get('length'):out.append('length')
    for n in (d.get('batch') or {}).get('notes',[]):out.append('note:'+n['id'])
    return out

def errors(p,doc,*,report=None):
    try:d=active(p)
    except util.Fail as e:return [str(e)]
    if not d:return [] # Existing projects remain compatible until their next Studio request.
    out=[]
    if not settings_match(videos.load(p.name),d):
        out.append('Studio settings changed after this request. Save and send a fresh request before rendering.')
    if d.get('schema',1)>=2 and attached(p.name)!=d.get('references',[]):
        out.append('Studio reference choices changed after this request. Start with the current saved choices.')
    if doc.get('request_id')!=d['id']:out.append('Bind scene-plan.request_id to the exact active editing request.')
    rows=doc.get('request_application',[])
    if not isinstance(rows,list) or any(not isinstance(x,dict) for x in rows):return out+['request_application must contain objects.']
    ids={s.get('id') for s in doc.get('scenes',[]) if isinstance(s,dict)}
    need=required(d)
    for key in need:
        matches=[x for x in rows if x.get('key')==key]
        if len(matches)!=1:out.append('Account for requested input exactly once: '+key);continue
        row=matches[0]
        if row.get('status') not in ('applied','overridden') or len(str(row.get('reason','')).strip())<20:
            out.append('Record a concrete application or explicit higher-priority override: '+key)
        if row.get('status')=='applied' and (not isinstance(row.get('scenes'),list) or not row['scenes'] or any(x not in ids for x in row['scenes'])):
            out.append('Bind requested input to existing scene ids: '+key)
        # Revision notes cannot be silently dismissed as a lower-priority style default.
        if key.startswith('note:') and row.get('status')!='applied':out.append('Resolve the requested revision before release: '+key)
    if report is not None:
        from . import render_controls,request_constraints
        plan=util.read_json(p/'edit-plan.json',default={})
        if plan:
            out.extend(render_controls.errors(p,doc,plan))
            out.extend(request_constraints.errors(p,doc,plan,d.get('settings',{})))
        checks=report.get('request_checks',{})
        if not isinstance(checks,dict):return out+['request_checks must be an object.']
        for key in need:
            row=checks.get(key,{})
            if not isinstance(row,dict) or row.get('pass') is not True or len(str(row.get('observations','')).strip())<20:
                out.append('Inspect this requested input in the actual candidate: '+key)
    return out
