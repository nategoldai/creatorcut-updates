"""Problem reports contain only selected facts, never logs or project content."""
import hashlib
import re
import secrets
import time
import unicodedata
from pathlib import Path

from . import telemetry, util

CHOICES = ("It got stuck", "The video looks wrong", "An error appeared", "Install problem", "Something else")
AREAS = frozenset("studio install update editor render reference footage captions music effects".split())
CLASSES = frozenset("input app host machine network".split())
REASONS = {
    "unknown": "The editing step could not finish.",
    "storage": "The Mac ran out of available space.",
    "source": "The editing tools could not read the source footage.",
    "browser": "The rendering browser could not finish this step.",
    "access": "The editing tools could not access a required file or resource.",
    "timeout": "The editing tool stopped making progress.",
    "stuck": "Studio was open and the edit showed no progress for 20 minutes.",
    "crash": "CreatorCut encountered an unexpected error.",
    "startup": "Studio could not start.",
    "missing_input": "A required project input was unavailable.",
}
CODE = re.compile(r"CC-[A-Z0-9]{5}\Z")


def directory():
    return util.STUDIO_OUT / "problem-reports"


def scrub(value, private=()):
    text = unicodedata.normalize("NFC", str(value or ""))
    for item in sorted(set(item for item in private if isinstance(item, str) and len(item) >= 3), key=len, reverse=True):
        text = re.sub(re.escape(unicodedata.normalize("NFC",item)), "[removed]", text, flags=re.I)
    text = re.sub(r"\b[\w.-]+\.[A-Za-z]{2,}/[^\s,;]*", "[removed]", text)
    text = re.sub(r"(?<!\w)[\w .()\-]{1,160}\.\w{2,5}\b", "[removed]", text, flags=re.I)
    text = re.sub(r"(?:https?://|file:|www\.)\S+", "[removed]", text, flags=re.I)
    text = re.sub(r"\b[^\s@]+@[^\s@]+\.[^\s@]+", "[removed]", text)
    text = re.sub(r"(?:\b[A-Za-z]:[\\/]|~?/)[^\r\n,;]*", "[removed]", text)
    text = re.sub(r"\b(?:bearer\s+\S+|(?:sk|ghp|github_pat|phc)[_-]\S+|[a-f0-9]{16,}|[A-Za-z0-9_+=/-]{25,})\b",
                  "[removed]", text, flags=re.I)
    text = re.sub(r"(?<!\w)@[\w.]+|(?<!\d)(?:\+?\d[(). -]*){7,}(?!\d)", "[removed]", text)
    return re.sub(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", "[removed]", text).strip()[:500]


def private_terms(project):
    profile = util.read_json(util.PROFILE, default={})
    contact = util.read_json(util.STUDIO_OUT / "dashboard-contact.json", default={})
    terms = [profile.get("name"), contact.get("email"), str(util.ROOT), str(Path.home())]
    if project:
        row = util.read_json(project / "project.json", default={})
        terms.extend((row.get("title"), row.get("name")))
        for item in row.get("media", []):
            terms.extend((item.get("name"), Path(item.get("file") or "").name))
    return terms


def report_path(code):
    if not isinstance(code, str) or not CODE.fullmatch(code):
        raise util.Fail("That report code is unavailable.")
    return directory() / (code + ".json")


def save(row):
    path = report_path(row["code"])
    util.write_json(path, row)


def read(code):
    row = util.read_json(report_path(code), default={})
    if not row:
        raise util.Fail("That report is no longer saved.")
    return row


def _step(value):
    from editor import director
    return value if value in AREAS or value in director.LABELS else "editor"


def build(project=None, *, trigger="button", area="editor", reason="unknown", failure_class="app",
          choice="", text="", signature=None):
    from editor import director
    status = director.status(project) if project else {}
    area = _step(status.get("failed_step") or area)
    chat_facts = status.get("report_chat_facts") or {}
    if reason == "unknown" and chat_facts.get("request") == status.get("request_id"):
        reason = chat_facts.get("reason") or reason
    reason = reason if reason in REASONS else "unknown"
    headline = f"Stuck at {area} for 20 min" if reason == "stuck" else f"CreatorCut could not finish {area}"
    summary = REASONS[reason]
    attempts = status.get("rescue_attempts") or {}
    count = min(2, attempts.get(area, 0)) if isinstance(attempts.get(area, 0), int) else 0
    if count:
        summary += f" CreatorCut tried {count} recovery steps."
    if project:
        summary += " Earlier saved versions were kept."
    code = "CC-" + "".join(secrets.choice("ABCDEFGHJKLMNPQRSTUVWXYZ23456789") for _ in range(5))
    payload = dict(telemetry.identity(), type="report", code=code, time=telemetry.utc(),
                   trigger=trigger, step=area, failure_class=failure_class if failure_class in CLASSES else "app",
                   headline=headline, ai_summary=summary)
    if choice in CHOICES:
        payload["choice"] = choice
    customer_text = scrub(text, private_terms(project))
    if customer_text:
        payload["customer_text"] = customer_text
    progress = status.get("overall_percent")
    version = status.get("version")
    state = status.get("state")
    lines = [headline, summary, f"CreatorCut {payload['app_version']} · {payload['host']}"]
    if state in ("working", "waiting_chat", "waiting_for", "paused", "needs_you", "done", "stopped"):
        lines.append(f"Edit state: {state}")
    if type(progress) in (int, float) and 0 <= progress <= 100:
        lines.append(f"Progress: {round(progress)}%")
    if type(version) is int and version > 0:
        lines.append(f"Saved version: {version}")
    payload["report_text"] = "\n".join(lines)
    return {"code": code, "payload": payload, "project": project.name if project else "",
            "request": status.get("request_id"), "signature": signature, "created": time.time(),
            "status": "saved"}


def submit(project=None, **facts):
    directory().mkdir(parents=True, exist_ok=True)
    with util.file_guard(directory() / ".reports.guard", timeout=2):
        row = build(project, **facts)
        signature = row.get("signature")
        recent = sorted(directory().glob("CC-*.json"), key=lambda file: file.stat().st_mtime)
        if signature:
            for file in reversed(recent):
                previous = util.read_json(file, default={})
                if previous.get("signature") == signature and (
                    row["request"] or time.time() - previous.get("created", 0) < 3600
                ):
                    return previous
        for file in recent[:-99]:
            file.unlink(missing_ok=True)
        save(row)
    deliver(row)
    return row


def deliver(row, note=None, *, retry=False):
    if row.get("status") == "sent" and note is None:
        return
    if not telemetry.enabled():
        return
    payload = note or row["payload"]
    with util.file_guard(directory() / ".reports.guard", timeout=2):
        latest = read(row["code"])
        field = "note_status" if note is not None else "status"
        if latest.get(field) == "sent" or latest.get(field) == "queued" and not retry:
            row.update(latest)
            return
        if telemetry.enqueue(payload):
            latest[field] = "queued"
            save(latest)
        row.update(latest)


def receipt(payload, *, sent):
    with util.file_guard(directory() / ".reports.guard", timeout=2):
        if not report_path(payload["code"]).exists():
            return
        row = read(payload["code"])
        row["note_status" if payload["type"] == "report_note" else "status"] = "sent" if sent else "saved"
        save(row)


def add_note(code, choice, text):
    row = read(code)
    project = util.PROJECTS / row["project"] if row.get("project") else None
    with util.file_guard(directory() / ".reports.guard", timeout=2):
        row = read(code)
        if row.get("note_status") in ("queued", "sent"):
            return row
        note = {"type": "report_note", "code": code, "time": telemetry.utc(),
                "customer_text": scrub(text, private_terms(project)),
                "choice": choice if choice in CHOICES else "Something else"}
        row["note"] = note
        row["note_status"] = "saved"
        save(row)
    deliver(row)
    deliver(row, note)
    return row


def public(row):
    return {"code": row["code"], "status": row["status"], "note_status": row.get("note_status"),
            "copy": row["payload"]["report_text"] + "\nReport code: " + row["code"] +
                    ("\n" + row["note"]["customer_text"] if row.get("note") else
                     "\n" + row["payload"].get("customer_text", ""))}


def automatic(project=None, *, area="editor", reason="unknown", trigger="automatic", signature=""):
    try:
        safe_id = hashlib.sha256(signature.encode()).hexdigest()[:24] if signature else None
        return submit(project, trigger=trigger, area=area, reason=reason, signature=safe_id)
    except (OSError, ValueError, util.Fail):
        return None
