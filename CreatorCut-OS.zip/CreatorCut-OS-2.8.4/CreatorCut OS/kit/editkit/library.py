"""Pinned executable style library. UI choices are data, never generated substitutes.
All heavy steps use the installation resource gate. Original plugin data is never read.
"""
from __future__ import annotations
import ast, copy, hashlib, json, math, os, shutil, sys
from pathlib import Path
from . import util



def digest_file(path):
    from .workflow import digest
    return digest(path)


def catalogue():
    return util.read_json(util.KIT/'style-library/catalogue.json')


def entry(identifier, version=None, verify=False):
    candidates=[(util.KIT/'style-library',catalogue())]
    shipped=util.KIT/'style-library-versions'
    if version:
        for manifest in shipped.glob('*/catalogue.json'):
            candidates.append((manifest.parent,util.read_json(manifest)))
    cache=util.STUDIO_OUT/'library-versions'
    if version:
        for manifest in cache.glob('*/catalogue.json'):
            try:candidates.append((manifest.parent,util.read_json(manifest)))
            except util.Fail:continue
    for root,doc in candidates:
        row=next((x for x in doc['entries'] if x['id']==identifier and (not version or x['version']==version)),None)
        if not row:continue
        if verify:
            for rel,want in dict(doc.get('common_files',{}),**row['files']).items():
                f=root/rel
                if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest()!=want:
                    raise util.Fail('The selected effect code failed its integrity check: '+rel)
        return dict(row,_root=str(root))
    raise util.Fail('That saved style version is unavailable. Choose its current version explicitly; the preset has not been changed.')


def pin_choices(value):
    """Retain selected executable source under protected user state before future app updates."""
    c=validate_choices(value)
    items=[c[k] for k in ('look','caption') if isinstance(c.get(k),dict)]+c['effects']
    if not items:return c
    roots={Path(entry(i['id'],i['version'],True)['_root']) for i in items}
    destination=util.STUDIO_OUT/'library-versions';destination.mkdir(parents=True,exist_ok=True)
    with util.file_guard(destination/'.pin.guard',timeout=10):
        for root in roots:
            if destination.resolve() in root.resolve().parents:continue
            doc=util.read_json(root/'catalogue.json')
            bundle=hashlib.sha256(json.dumps(doc,sort_keys=True).encode()).hexdigest()[:24]
            out=destination/bundle
            if out.exists():continue
            temporary=destination/(bundle+'.pending')
            shutil.rmtree(temporary,ignore_errors=True)
            try:
                shutil.copytree(root,temporary,ignore=shutil.ignore_patterns('__pycache__','*.pyc','previews'))
                temporary.replace(out)
            finally:shutil.rmtree(temporary,ignore_errors=True)
    return c


def validate_choices(value):
    if not isinstance(value,dict) or set(value)-{'look','caption','effects','placements','effects_mode'}: raise util.Fail('Invalid style choices.')
    result={}
    for kind in ('look','caption'):
        key=value.get(kind)
        if key is not None:
            if key=='none' and kind=='caption': result[kind]='none'; continue
            if not isinstance(key,dict): raise util.Fail('Styles need an id and code version.')
            e=entry(key.get('id'),key.get('version'))
            if e['kind']!=kind: raise util.Fail('Incorrect style category.')
            result[kind]={'id':e['id'],'version':e['version']}
    selected=value.get('effects',[])
    if not isinstance(selected,list) or len(selected)>12: raise util.Fail('Choose up to twelve effects.')
    mode=value.get('effects_mode','replace' if 'effects' in value else 'inherit')
    if mode not in ('inherit','replace'):raise util.Fail('Invalid effect selection mode.')
    result['effects_mode']=mode
    result['effects']=[]
    for key in selected:
        if not isinstance(key,dict): raise util.Fail('Effects need an id and code version.')
        e=entry(key.get('id'),key.get('version'))
        if e['kind']!='effect': raise util.Fail('Incorrect effect category.')
        if any(x['id']==e['id'] for x in result['effects']): continue
        result['effects'].append({'id':e['id'],'version':e['version']})
    placements=value.get('placements',{})
    if not isinstance(placements,dict): raise util.Fail('Invalid effect placement.')
    result['placements']={}
    for key,where in placements.items():
        if key not in [x['id'] for x in result['effects']]: continue
        if isinstance(where,dict):
            a,b=where.get('start'),where.get('end')
            if where.get('mode')!='range' or not all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) for v in (a,b)) or not 0<=a<b<=14400:
                raise util.Fail('Choose valid From and To seconds for this effect.')
            result['placements'][key]={'mode':'range','start':a,'end':b}
        else:
            if where not in ('auto','hook','middle','end'): raise util.Fail('Choose a supported placement.')
            result['placements'][key]=where
    return result


def choices(p, include_disabled=False, current=False, omissions=None):
    cfg=util.read_json(p/'project.json')
    def versioned(value):
        if not current or not isinstance(value,dict):return value
        value=copy.deepcopy(value)
        for kind in ('look','caption'):
            item=value.get(kind)
            if isinstance(item,dict):item['version']=entry(item.get('id'))['version']
        effects=value.get('effects')
        if isinstance(effects,list):
            available=[]
            for item in effects:
                if isinstance(item,dict):
                    identifier=item.get('id')
                    try:item['version']=entry(identifier)['version']
                    except util.Fail:
                        if omissions is None or not isinstance(identifier,str) or not identifier.startswith('effect:'):raise
                        label=identifier.split(':',1)[1].replace('-',' ').title()
                        omissions.append(f'I left {label} out because it is unavailable in this installation. Your saved choice was kept.')
                        continue
                available.append(item)
            value['effects']=available
        return value
    manual=validate_choices(versioned(cfg.get('library_choices',{})))
    from . import learn
    memory={}
    saved_memory=learn._load(allow_empty=True)
    for rule in saved_memory.get('creator',[]):
        for kind,value in rule.get('library_choices',{}).items():memory[kind]=value
    for rule in saved_memory.get('presets',{}).get(cfg.get('style',''),[]):
        for kind,value in rule.get('library_choices',{}).items():memory[kind]=value
    # A named preset beats universal defaults; both remain below a new reference.
    inherited=dict(memory,**cfg.get('preset_library_choices',{}))
    preset=validate_choices(versioned(inherited))
    ref=util.read_json(p/'style-inputs.json',default={}).get('reference',{})
    # A measured reference feature can be custom, rather than a library key. Do not force an old preset over it.
    if ref:
        if any(k in ref for k in ('fonts','styles','captions','motion','colour','graphics')):preset.pop('look',None)
        if any(k in ref for k in ('captions','fonts','styles')):preset.pop('caption',None)
        if any(k in ref for k in ('effects','graphics','motion')):preset['effects']=[]
    result=dict(preset)
    for k in ('look','caption'):
        if k in manual:result[k]=manual[k]
    result['effects']=manual['effects'] if manual['effects_mode']=='replace' else list({x['id']:x for x in preset.get('effects',[])+manual.get('effects',[])}.values())
    if not include_disabled and cfg.get('captions',{}).get('enabled') is False:result['caption']='none'
    elif cfg.get('captions',{}).get('enabled') is True and result.get('caption')=='none':
        default=entry('caption:signature');result['caption']={'id':default['id'],'version':default['version']}
    result['effects_mode']='replace'
    result['placements']={**preset.get('placements',{}),**manual.get('placements',{})}
    return result


def context(p):
    selected=choices(p)
    out={'schema':1,'choices':selected,'precedence':'this video explicit request (including explicit Studio choices and requested reference) > saved style > Studio defaults/picks > effect defaults',
         'constraints':[],'content_questions':[]}
    for item in selected.get('effects',[]):
        e=entry(item['id'],item['version'],True)
        out['constraints'].append({k:e.get(k) for k in ('id','version','shot','camera','wall','material','notes','slot')})

    util.write_json(p/'selected-library.json',out)
    return out


def preflight(identifier, evidence, version=None):
    """Measured suitability, separate from semantic/visual review. No guessed head geometry."""
    e=entry(identifier,version,verify=True); issues=[]
    for field in ('shot','camera'):
        if not evidence.get(field): issues.append('Measure '+field+' first.')
        elif evidence[field]!='unknown' and e.get(field) and evidence[field] not in e[field]: issues.append('This effect does not support this '+field+'.')
    slot=e.get('slot',{})
    if slot.get('cutout') not in (None,'none') and not evidence.get('clean_cutout'): issues.append('A reviewed clean subject cutout is required.')
    if e.get('material') and not str(e['material']).lower().startswith(('none','nothing needed')) and not evidence.get('assets'): issues.append('Add the required material: '+e['material'])
    if not evidence.get('semantic_reason'): issues.append('Anchor the effect to the actual spoken words or visual action.')
    if not evidence.get('layout_reviewed'): issues.append('Review the face, text safe zones and open space.')
    reason = 'this moment needs different framing'
    if evidence.get('shot') in e.get('shot',[]):
        reason = 'it needs a steadier camera' if evidence.get('camera') not in (*e.get('camera',[]), 'unknown') else 'your outline could not be separated cleanly' if slot.get('cutout') not in (None,'none') and not evidence.get('clean_cutout') else 'it needs the extra material described in What it needs' if not evidence.get('assets') else 'this moment does not have a suitable spoken line or clear layout'
    return {'ok':not issues,'issues':issues,'id':e['id'],'version':e['version'],
            'skip':('I left '+e['name']+' out because '+reason+'.') if issues else None}


def _env():
    env=dict(os.environ,CREATORCUT_KIT=str(util.KIT),CREATORCUT_LIBRARY_STATE=str(util.STUDIO_OUT/'library-runtime'))
    node=util.which('node')
    paths=([str(Path(node).parent)] if node else [])+[str(util.BIN),env.get('PATH','')]
    env['PATH']=os.pathsep.join(paths)
    env['PYTHONUNBUFFERED']='1'
    env.update(WORKERS='1',BAKE_WORKERS='1',OMP_NUM_THREADS='1')
    return env


def normalize_generated_registration(slot):
    html=Path(slot)/'index.html'
    if not html.is_file():return
    before=html.read_text();after=before.replace('(window.__timelines || (window.__timelines = new Object()))["main"] = tl;', 'window.__timelines = window.__timelines || new Object(); window.__timelines["main"] = tl;')
    if after!=before:
        html.write_text(after)
        util.write_json(Path(slot)/'lint-compatibility.json',{'adapter':'explicit timeline registry v1','before_sha256':hashlib.sha256(before.encode()).hexdigest(),'after_sha256':hashlib.sha256(after.encode()).hexdigest(),'pinned_sources_changed':False})


def adapt_post_counter(slot,key):
    """Repair only the known CSV counter in a working copy, preserving saved pins."""
    if key not in ('digital-zoom', 'rack-focus', 'god-rays', 'spatial-glass', 'neon-sign', 'scene-text', 'doodle-boil', 'paper-cut', 'glass-type', 'word-pile', 'inside-out', 'vertigo', 'shatter-3d', 'cover-story', 'code-scan'):return
    slot=Path(slot);file=slot/'post.py'
    if not file.is_file():return
    text=file.read_text();tree=ast.parse(text);old=next((n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='count'),None)
    if old is None:return
    body=ast.get_source_segment(text,old)
    if 'csv=p=0' not in body or 'return int(subprocess.run' not in body:return
    current=entry('effect:'+key,verify=True);trusted=Path(current['_root'])/'effects'/key/'post.py';replacement=trusted.read_text();fn=next(n for n in ast.parse(replacement).body if isinstance(n,ast.FunctionDef) and n.name=='count')
    before=hashlib.sha256(text.encode()).hexdigest();lines=text.splitlines(keepends=True);lines[old.lineno-1:old.end_lineno]=[ast.get_source_segment(replacement,fn)+'\n'];updated=''.join(lines);ast.parse(updated);file.write_text(updated)
    util.write_json(slot/'post-count-compatibility.json',{'adapter':'ffprobe-json-counter-v1','before_sha256':before,'after_sha256':hashlib.sha256(updated.encode()).hexdigest(),'pinned_source_changed':False})
    receipt=util.read_json(slot/'creatorcut-receipt.json',default={})
    if receipt:receipt['implementation']=_slot_sources(slot);util.write_json(slot/'creatorcut-receipt.json',receipt)


def run_script(p, script, args=(), timeout=3600, library_root=None):
    from . import resources
    root=Path(library_root or util.KIT/'style-library')
    if script=='fx_run.py' and args:
        if len(args)>2 and str(args[1])=='hf' and str(args[2])=='lint':normalize_generated_registration(args[0])
        receipt=Path(str(args[0]))/'creatorcut-receipt.json'
        if receipt.is_file():
            r=verify_slot(receipt.parent)
            if len(args)>1 and str(args[1])=='post.py':adapt_post_counter(receipt.parent,r['id'].split(':')[-1])
            root=Path(entry(r['id'],r['version'],True)['_root'])
    file=root/'scripts'/script
    if file.parent!=root/'scripts' or not file.is_file(): raise util.Fail('Unknown library tool.')
    import tempfile
    tmp=p/'work/library-temp';tmp.mkdir(parents=True,exist_ok=True)
    with resources.heavy(),tempfile.TemporaryDirectory(prefix='run-',dir=tmp) as folder:
        fonts=Path(p).resolve()/'.creatorcut-render-cache/fonts'
        fonts.mkdir(parents=True,exist_ok=True)
        env=dict(_env(),TMPDIR=folder,TMP=folder,TEMP=folder,
                 HYPERFRAMES_FONT_CACHE_DIR=str(fonts),HYPERFRAMES_HISTORY_ROOT=str(fonts.parent/'history'),HYPERFRAMES_EXTRACT_CACHE_DIR=str(Path(folder)/'extract'),
                 HYPERFRAMES_SKIP_SKILLS='1',DO_NOT_TRACK='1')
        owner=p if (p/'project.json').is_file() else p.parent.parent if p.name=='style-library' and p.parent.name=='work' else None
        if owner:
            owner_cfg=util.read_json(owner/'project.json')
            if owner_cfg.get('zoom') is False:env['CREATORCUT_DISABLE_ZOOM']='1'
            if owner_cfg.get('sfx') is False:env['SFX']='0'
            if script=='fx_run.py' and isinstance(choices(owner).get('caption'),dict):env['CAPTIONS']='0'
        import subprocess,time,re
        from collections import deque
        from . import activity_store
        stage={'layout.py':'Measuring your frame','build_reel.py':'Building your selected style','hf.py':'Rendering your selected style','fx_new.py':'Preparing your effect','fx_add.py':'Placing your effect'}.get(script,'Applying your effect')
        if script=='fx_run.py' and len(args)>1:stage={'prep.py':'Measuring your effect','bake.py':'Drawing your effect','build.py':'Building your effect','hf':'Rendering your effect','check.py':'Checking your effect'}.get(str(args[1]),'Preparing your effect')
        activity_store.update(label='Applying your selected style',detail=stage,percent=None,last_output=time.time(),estimated_remaining_seconds=None,estimate_basis=None)
        matting_frames=0
        if script=='fx_new.py' and '--from' in args and '--to' in args:matting_frames=round(float(args[list(args).index('--to')+1])*30)-round(float(args[list(args).index('--from')+1])*30)
        elif args and (Path(str(args[0]))/'clip.json').is_file():matting_frames=int(util.read_json(Path(str(args[0]))/'clip.json').get('frames') or 0)
        elif script=='rvm_cut.py' and args and (Path(str(args[0]))/'assets/aroll.mp4').is_file():matting_frames=round(util.probe(Path(str(args[0]))/'assets/aroll.mp4')['duration']*30)
        from . import browser_cleanup
        browser_registry,browser_scope=browser_cleanup.configure(env,folder)
        proc=util.spawn([sys.executable,str(file),*[str(a) for a in args]],cwd=p,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace')
        output=deque(maxlen=2000);last_pulse=[0.]
        def pulse():
            now=time.time()
            if now-last_pulse[0]>=10:
                activity_store.update(heartbeat=now)
                last_pulse[0]=now
        try:
            for line in util.progress_lines(proc,timeout=timeout,idle_timeout=min(timeout,600),on_tick=pulse):
                output.append(line)
                if 'stage still running' in line:
                    activity_store.update(heartbeat=time.time())
                    continue
                activity_store.update(last_output=time.time())
                matting=re.search(r'(\d+) frames done, ([0-9.]+)s per frame',line)
                if matting and args:
                    count=matting_frames;done=int(matting[1])
                    if count:
                        remaining=max(0,count-done)*float(matting[2]);activity_store.update(estimated_remaining_seconds=round(remaining),estimate_basis='Measured cut-out frames; later render not included')
                        util.activity('Cutting out your subject · about '+str(max(1,round(remaining/60)))+' min left for this cut-out',min(100,100*done/count));continue
                activity_store.update(estimated_remaining_seconds=None,estimate_basis=None)
                m=re.search(r'^(?:.*(?:render|matting|bake|frame)[^0-9]*)?(\d+)\s*/\s*(\d+)\s*$',line.strip(),re.I)
                if m and int(m[2])>0:util.activity(stage,100*int(m[1])/int(m[2]))
                else:util.activity(stage)
                print(line,end='',flush=True)
            text=''.join(output)
            if proc.returncode:raise util.Fail(stage+' failed:\n'+'\n'.join(text.strip().splitlines()[-12:]))
            return subprocess.CompletedProcess(proc.args,proc.returncode,text,'')
        finally:
            util.stop_process(proc)
            browser_cleanup.cleanup(browser_registry,browser_scope)


def _copy_style_fonts(workspace, choices):
    """Install the exact selected engine's font bundle; never render a silent fallback."""
    import re
    primary=next((choices[k] for k in ('look','caption') if isinstance(choices.get(k),dict)),None)
    if primary is None:primary=next(iter(choices.get('effects',[])),None)
    root=Path(entry(primary['id'],primary['version'],True)['_root']) if primary else util.KIT/'style-library'
    source=root/'engine/fonts';css=source/'fonts.css'
    if not css.is_file():raise util.Fail('The selected style font bundle is missing. Repair the installation before rendering.')
    required=re.findall(r"url\(['\"]?([^)'\"]+)",css.read_text())
    for rel in required:
        file=(source/rel).resolve()
        if source.resolve() not in file.parents or not file.is_file():raise util.Fail('A selected style font is missing: '+rel)
    destination=workspace/'assets/fonts'
    shutil.copytree(source,destination,dirs_exist_ok=True)
    for rel in ['fonts.css',*required]:
        if hashlib.sha256((source/rel).read_bytes()).digest()!=hashlib.sha256((destination/rel).read_bytes()).digest():raise util.Fail('A selected font did not copy correctly: '+rel)
    return destination


def prepare(p):
    """Adapt only this video's cut/word data to the unchanged caption/effect engine."""
    from . import resources
    with resources.heavy(), util.file_guard(p/'.library.guard',timeout=5):
        w=p/'work/style-library';(w/'assets').mkdir(parents=True,exist_ok=True)
        from . import colour_choice
        src=colour_choice.ensure_cut(p)
        if not src.is_file(): raise util.Fail('Finish the best-take cut before building styles.')
        info=util.probe(src)
        if (info['width'],info['height'])!=(1080,1920): raise util.Fail('This style needs a vertical 1080 × 1920 video. Choose Reels, TikTok or Shorts in Studio, then rebuild the cut before applying it.')
        # One content fingerprint protects against using slots from an earlier cut.
        from .workflow import digest
        sig=digest(src)
        previous=util.read_json(w/'source.json',default={})
        if previous and previous.get('sha256')!=sig and (w/'fx').exists():
            raise util.Fail('The cut changed. Archive the previous style workspace and re-anchor its effects before continuing.')
        dest=w/'assets/aroll.mp4'
        colour_contract='limited-rec709-v2'
        if not dest.exists() or previous.get('sha256')!=sig or previous.get('colour_contract')!=colour_contract:
            temporary=dest.with_suffix('.pending.mp4')
            try:
                from .cut import tonemap_filter
                matrix=info.get('colorspace')
                matrix=matrix if matrix in ('bt709','bt470bg','smpte170m','bt2020nc') else 'bt709'
                vf=tonemap_filter(info) if info.get('hdr') else ''
                if not info.get('hdr'):
                    vf=f"scale=in_color_matrix={matrix}:out_color_matrix=bt709:in_range={'pc' if info.get('color_range')=='pc' else 'tv'}:out_range=tv:flags=accurate_rnd+full_chroma_int,"
                util.run([util.ffmpeg_bin(),'-nostdin','-y','-v','error','-i',str(src),'-map','0:v:0','-map','0:a:0?',
                    '-vf',vf+'fps=30,setsar=1,format=yuv420p','-c:v','libx264','-preset','fast','-crf','14',
                    '-pix_fmt','yuv420p','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-color_range','tv','-c:a','aac',str(temporary)],timeout=max(120,min(14400,info['duration']*20)))
                converted=util.probe(temporary)
                if converted.get('hdr') or abs(converted['duration']-info['duration'])>1/30+.01:raise util.Fail('The style working copy did not preserve SDR timing.')
                temporary.replace(dest)
            finally:temporary.unlink(missing_ok=True)
        doc=util.read_json(p/'words.json');words=doc.get('words',[]) if isinstance(doc,dict) else doc
        words_sig=digest(p/'words.json')
        # Also protects older pinned caption engines without changing their code.
        normalized=[dict(x,text=x.get('text',x.get('w','')).strip()) for x in words if isinstance(x.get('text',x.get('w','')),str) and x.get('text',x.get('w','')).strip()]
        if not (w/'words.json').exists() or previous.get('word_source_sha256')!=words_sig or util.read_json(w/'words.json')!=normalized:
            util.write_json(w/'words.json',normalized)
        util.write_json(w/'source.json',{'sha256':sig,'working_colour':'SDR Rec.709','colour_contract':colour_contract,'word_source_sha256':words_sig})
        segdoc=util.read_json(p/'segments.json',default={});segs=segdoc.get('segments',[]) if isinstance(segdoc,dict) else segdoc
        util.write_json(w/'segments.json',[dict(x,frame=round(x.get('start',0)*30),frames=round((x.get('end',0)-x.get('start',0))*30)) for x in segs])
        for name in ('cutout.webm','subject.webm'):
            if not info.get('hdr') and (p/name).is_file() and not (w/'assets/subject.webm').exists():
                shutil.copy2(p/name,w/'assets/subject.webm')
        c=choices(p);_copy_style_fonts(w,c);look=c.get('look');caption=c.get('caption')
        picks={'mode':'preset' if look else 'custom','style':look['id'].split(':')[1] if look else None,
               'captionStyle':caption['id'].split(':')[1] if isinstance(caption,dict) else ('none' if caption=='none' or not look else entry(look['id'],look['version']).get('captionStyle','none')),
               'effects':[x['id'].split(':')[1] for x in c['effects']]}
        # An unselected feature is UNKNOWN, not "no captions". Agent must resolve reference/default before render.
        sections={part:[] for part in ('hook','middle','end')}
        for selected in c['effects']:
            where=c.get('placements',{}).get(selected['id'],'auto')
            for part in sections:
                if where=='auto' or isinstance(where,dict) or where==part:sections[part].append(selected['id'].split(':')[1])
        if c['effects']:picks['effectSections']=sections
        util.write_json(w/'picks.json',picks)
        context(p)
        return w


def _slot_sources(slot):
    return {str(f.relative_to(slot)):hashlib.sha256(f.read_bytes()).hexdigest() for f in slot.rglob('*.py') if '__pycache__' not in f.parts}


def verify_slot(slot):
    receipt=util.read_json(slot/'creatorcut-receipt.json',default={})
    expected=receipt.get('implementation')
    if expected and expected!=_slot_sources(slot):
        raise util.Fail('The selected effect implementation changed outside its saved parameters. Restore its pinned code before continuing.')
    return receipt


def configure(slot, values):
    """JSON-only values replace existing top-level constants via AST positions, never eval/exec input."""
    if not isinstance(values,dict): raise util.Fail('Effect parameters must be an object.')
    receipt=verify_slot(slot)
    source=(slot/'build.py').read_text();tree=ast.parse(source);lines=source.splitlines(keepends=True);edits=[]
    allowed={}
    for node in tree.body:
        if isinstance(node,ast.Assign) and len(node.targets)==1:
            target=node.targets[0]
            if isinstance(target,ast.Name) and target.id.isupper():allowed[target.id]=(node,None)
            elif isinstance(target,(ast.Tuple,ast.List)) and isinstance(node.value,(ast.Tuple,ast.List)) and len(target.elts)==len(node.value.elts):
                for index,name in enumerate(target.elts):
                    if isinstance(name,ast.Name) and name.id.isupper():allowed[name.id]=(node,index)
    if set(values)-set(allowed): raise util.Fail('Unknown effect parameters: '+', '.join(sorted(set(values)-set(allowed))))
    json.dumps(values,allow_nan=False)
    grouped={}
    for key,value in values.items():
        node,index=allowed[key];grouped.setdefault(node,{}).update({key:value})
    for node,updates in grouped.items():
        if isinstance(node.targets[0],ast.Name):replacement=f'{node.targets[0].id} = {updates[node.targets[0].id]!r}\n'
        else:
            replacement=''.join(name.id+' = '+(repr(updates[name.id]) if name.id in updates else ast.get_source_segment(source,node.value.elts[index]))+'\n' for index,name in enumerate(node.targets[0].elts))
        edits.append((node.lineno-1,node.end_lineno,replacement))
    for start,end,value in sorted(edits,reverse=True): lines[start:end]=[value]
    result=''.join(lines);ast.parse(result)
    (slot/'build.py').write_text(result)
    prior=util.read_json(slot/'creatorcut-parameters.json',default={})
    util.write_json(slot/'creatorcut-parameters.json',dict(prior,**values))
    if receipt:
        receipt['implementation']=_slot_sources(slot);util.write_json(slot/'creatorcut-receipt.json',receipt)












def matting_ready():
    import importlib.util
    target=util.KIT/'library-state/models/rvm_mobilenetv3_fp32.onnx'
    try:
        return target.is_file() and hashlib.sha256(target.read_bytes()).hexdigest()=='88d4531297118f595bf2fd60f6f566aec2e559393802d1f436c380f0cbbd2828' and all(importlib.util.find_spec(name) for name in ('numpy','onnxruntime','scipy'))
    except (OSError,ImportError,ValueError):return False

def ensure_matting():
    """One-time local model download with a pinned hash; never silently use another matte model."""
    from . import resources
    import urllib.request,ssl,time
    target=util.KIT/'library-state/models/rvm_mobilenetv3_fp32.onnx'
    want='88d4531297118f595bf2fd60f6f566aec2e559393802d1f436c380f0cbbd2828'
    if target.exists() and hashlib.sha256(target.read_bytes()).hexdigest()==want:return target
    for module in ('onnxruntime','scipy.ndimage'):
        try:__import__(module)
        except ImportError:raise util.Fail('The clean cutout needs the vision dependencies. Complete CreatorCut setup before this effect.')
    with resources.heavy(),util.file_guard(target.with_suffix('.guard'),timeout=5):
        if target.exists() and hashlib.sha256(target.read_bytes()).hexdigest()==want:return target
        target.parent.mkdir(parents=True,exist_ok=True);temp=target.with_suffix('.pending')
        url='https://github.com/PeterL1n/RobustVideoMatting/releases/download/v1.0.0/rvm_mobilenetv3_fp32.onnx'
        try:
            util.step('Downloading the clean subject model (15 MB, once).')
            context=ssl.create_default_context()
            try:
                import certifi
                context=ssl.create_default_context(cafile=certifi.where())
            except ImportError:pass
            deadline=time.monotonic()+600
            with urllib.request.urlopen(url,timeout=30,context=context) as response,temp.open('wb') as dest:
                size=0
                while True:
                    if time.monotonic()>deadline:raise util.Fail('The model download timed out. Retry after checking the connection.')
                    chunk=response.read1(1024*1024)
                    if not chunk:break
                    size+=len(chunk)
                    if size>150_000_000:raise util.Fail('The model download is larger than expected.')
                    dest.write(chunk);util.activity('Downloading clean subject model',min(99,size/107_000_000*100))
            if hashlib.sha256(temp.read_bytes()).hexdigest()!=want:raise util.Fail('The subject model download failed its integrity check.')
            temp.replace(target)
        except (OSError,TimeoutError) as error:
            raise util.Fail('The clean subject model could not download. Your footage is safe.','Check your connection, then run setup again; the model is only downloaded once.') from error
        finally:temp.unlink(missing_ok=True)
    return target
