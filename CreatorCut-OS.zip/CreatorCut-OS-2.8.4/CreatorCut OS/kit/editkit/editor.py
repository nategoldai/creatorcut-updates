"""Legacy process retirement and read-only compatibility for saved customer files.
No AI client, supervisor, scheduler, permission relay or provider is present.
"""
import os,time,threading
from contextlib import contextmanager
from . import util
START_LOCK=threading.RLock()
ACTIVE={'queued','starting','editing','waiting_approval','recovering'}
TERMINAL={'succeeded','failed','cancelled','needs_attention','needs_setup'}
def root():return util.STUDIO_OUT/'editor'

def control():return util.ROOT/'.creatorcut-editor-control'

def alive(pid):
    return util.process_alive(pid)

def safe_json(path):
    try:
        value=util.read_json(path,default={})
        return value if isinstance(value,dict) else {}
    except (util.Fail,OSError,ValueError):
        return {}

def identity(pid):
    return util.process_identity(pid) if alive(pid) else ''

def same_process(pid,birth):
    return alive(pid) and bool(birth) and identity(pid)==birth

def retire_managed_workers():
    """Retire this installation's private managed registry before paste work exists.

    Unknown identity is busy, never permission to kill. Hold the same startup
    locks as ensure_worker, so another new-code caller cannot start a worker
    between this check and the caller's protected reservation.
    """
    from . import chat_execution
    if chat_execution.mode()!='chat':return
    with paste_worker_guard():pass

def retire_for_studio_start():
    """Recovery failure must never prevent the repair interface opening.
    Make and reserve STILL use the strict guard, so this is not editing consent.
    """
    file=util.STUDIO_OUT/'legacy-worker-status.json'
    try:
        retire_managed_workers()
        from editor import director
        director.retire_legacy_listener()
        util.write_json(file,{'blocked':False,'updated':time.time()})
        return True
    except Exception:
        util.log_exception('Previous editor startup recovery')
        util.write_json(file,{'blocked':True,'updated':time.time(),'message':'Your previous editor has not closed safely. Restart your Mac, then reopen CreatorCut and press Make. Your videos and saved requests are safe.'})
        return False

@contextmanager
def paste_worker_guard():
    from . import owned_processes
    with START_LOCK,util.file_guard(root()/'.start.guard',timeout=10):
        def stop_record(record):
            pid,birth=record.get('pid'),record.get('birth')
            if util.reap_exited_child(pid):return
            if not alive(pid):return
            if pid==os.getpid():raise util.Fail('The previous editor record points to this process. Close this old editor before reopening Studio.')
            deadline=time.monotonic()+7
            while alive(pid):
                if util.reap_exited_child(pid):return
                current=identity(pid)
                if current and birth and current!=birth:return # Reused PID, not ours.
                if not current or not birth:
                    raise util.Fail('The previous editor cannot be verified safely. Restart your Mac, then open CreatorCut and try Make again. Your files are saved.')
                owned_processes.stop(record,'paste-migration')
                if time.monotonic()>=deadline:
                    raise util.Fail('The previous editor is still closing. Your settings are saved; try again after it stops.')
                time.sleep(.05)
            util.reap_exited_child(pid)
        # Stop the scheduler before enumerating its providers: it may have been
        # writing provider records until its last scheduling tick.
        for path in (control()/'worker.json',root()/'worker.json'):
            stop_record(safe_json(path))
        for path in sorted((control()/'providers').glob('*.json')):
            stop_record(safe_json(path))
        # A legacy worker cannot restart while its exclusive guard is held.
        # Failure to acquire is busy even if a record was absent or malformed.
        with util.file_guard(root()/'.worker.guard','The previous editor is still closing. Your settings are saved.',timeout=0):
            yield

def config():return safe_json(root()/'config.json')
def provider_name():return config().get('provider') if config().get('provider') in ('claude','codex') else 'codex'
def configure_provider(host):
 if host not in ('claude','codex'):raise util.Fail('Open this folder in your CreatorCut chat.')
 data=config();data['provider']=host;util.write_json(root()/'config.json',data);return data
def detect_host(environ=None):
 env=os.environ if environ is None else environ
 if env.get('CLAUDE_PROJECT_DIR') or env.get('CLAUDE_SESSION_ID') or env.get('CLAUDECODE') or env.get('CLAUDE_CODE_SESSION_ID'):return 'claude'
 if env.get('CODEX_THREAD_ID'):return 'codex'
 launch=util.read_json(util.KIT/'style-library/launch-list.json')
 return 'claude' if isinstance(launch,dict) and launch.get('hosts')==['claude'] else 'codex'
def read(pid):
 from editor import director
 s=director.status(util.PROJECTS/pid)
 if not s:return {}
 return dict(id=s.get('request_id'),request_id=s.get('request_id'),state={'working':'editing','waiting_chat':'queued','needs_you':'waiting_approval','done':'succeeded','stopped':'cancelled','paused':'failed'}.get(s.get('state'),'failed'),execution_mode='chat',message=s.get('step_label',''),updated=s.get('updated',0),created=s.get('started'),version=s.get('version'),state_seq=s.get('seq',0))
def public(pid):return read(pid)
def all_projects():return [p.parent.name for p in util.PROJECTS.glob('*/status.json')]
def pending_jobs():return [read(pid) for pid in all_projects() if read(pid).get('state') in ACTIVE]
def status():return {'enabled':True,'mode':'chat','provider':provider_name()}
def local_rendering_status(provider=None):return {'required':False}
def supervisor_age(worker=None):return 0
def runtime_available():return False
def cancel(pid):
 from editor import director
 return director.cancel(pid)

def protect_inputs(fn):
    """Keep files referenced by a saved or running request until it finishes or is stopped."""
    from functools import wraps
    @wraps(fn)
    def protected(pid,*args,**kwargs):
        from editor import director
        if not pid:return fn(pid,*args,**kwargs)
        with director.lock(director.OUT/'.queue.guard',True):
            state=director.status(util.PROJECTS/pid)
            if state.get('state') in ('waiting_chat','working','needs_you','paused') or alive(state.get('command_pid')):
                raise util.Fail('Stop this edit before changing its footage. Your saved choices and videos are safe.')
            return fn(pid,*args,**kwargs)
    return protected
