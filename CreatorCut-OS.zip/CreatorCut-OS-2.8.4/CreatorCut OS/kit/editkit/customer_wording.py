"""Release text check. Code identifiers, paths and video previews are not labels."""
import ast,json,re
from pathlib import Path
BAD=re.compile(r'\b(?:test|tester|testing|beta|candidate|MVP|trial|validation|unreleased|draft)\b|\brc\.\d+|preview build|not published|owner test',re.I)
# Genuine technical uses: third-party browser name; video preview controls; source
# paths/keys are not customer prose. None allows a prerelease product label.
ALLOW=('Chrome for Testing','text-behind-the speaker test',)
def forbidden(text):
 for phrase in ALLOW:text=text.replace(phrase,'')
 text=re.sub(r'[A-Za-z0-9_./-]+/[A-Za-z0-9_./-]+','',text)
 text=re.sub(r'''(?:class|id|data-[\w-]+)=["'][^"']*["']''','',text)
 return bool(BAD.search(text))
def errors(files):
 issues=[]
 prose={'README.md','INSTALL.md','START HERE.txt','GUIDE.md','AGENTS.md','CLAUDE.md','BUILD.json','kit/docs/public-readme.md','kit/docs/public-install.md','kit/docs/getting-started.md'}
 for name,data in files.items():
  if isinstance(data,bytes):
   try:text=data.decode('utf-8')
   except UnicodeDecodeError:continue
  else:text=str(data)
  if name in prose or name.startswith(('.agents/skills/','.claude/skills/','kit/skills-src/')) and name.endswith('.md'):
   if forbidden(text):issues.append(name+': customer wording')
  elif name.startswith('kit/studio/app/') and name.endswith(('.js','.html')):
   # Scan quoted presentation strings, excluding comments and identifiers.
   pattern='//[^\\n]*|/\\*[\\s\\S]*?\\*/|"(?:\\\\.|[^"\\\\\\r\\n])*"|\'(?:\\\\.|[^\'\\\\\\r\\n])*\'|`(?:\\\\.|[^`\\\\])*`'
   for match in re.finditer(pattern,text):
    token=match.group(0)
    if token.startswith(('/',)):continue
    value=token[1:-1]
    if value in ('draft',' savepreset-draft'):continue # Internal project-state key, never a rendered label.
    if forbidden(value):issues.append(name+': '+value[:100]);break
  elif name.startswith(('kit/editor/','kit/editkit/')) and name.endswith('.py') and not name.endswith(('release_gate.py','customer_wording.py')):
   try:tree=ast.parse(text)
   except SyntaxError:issues.append(name+': cannot inspect messages');continue
   for node in ast.walk(tree):
    if not isinstance(node,ast.Call):continue
    fun=node.func;label=fun.id if isinstance(fun,ast.Name) else fun.attr if isinstance(fun,ast.Attribute) else ''
    if label not in ('Fail','Needed','say','print','Busy','EffectSkip'):continue
    for arg in node.args:
     for value in ast.walk(arg):
      if isinstance(value,ast.Constant) and isinstance(value.value,str) and forbidden(value.value):issues.append(name+': '+value.value[:100])
 if any(Path(n).name in ('OWNER-TEST.md','TESTER-GUIDE.md') or n=='kit/docs/validation-guide.md' for n in files):issues.append('Developer guide included in customer package')
 return sorted(set(issues))
