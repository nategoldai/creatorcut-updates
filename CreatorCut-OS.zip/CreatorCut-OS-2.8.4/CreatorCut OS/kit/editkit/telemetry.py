"""Opt-in, bounded CreatorCut dashboard delivery."""
import hashlib
import json
import platform
import re
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timezone

from . import util

EVENTS = frozenset("""install_started install_step_done install_failed install_finished
studio_opened studio_alive make_pressed feedback_sent edit_claimed edit_step edit_heartbeat
edit_paused rescue_used effect_used effect_skipped edit_finished edit_failed download_clicked
update_installed update_failed history_summary""".split())
DETAILS = {
    "make_pressed": {"effects", "captions", "look", "reference", "music", "clip_seconds"},
    "edit_claimed": {"auto"}, "edit_heartbeat": {"waiting_for_chat"},
    "edit_finished": {"version", "effects_used", "effects_skipped", "rescues", "ai_steps"},
    "edit_failed": {"failure_class"}, "update_installed": {"from", "to"},
    "update_failed": {"from", "to"},
    "history_summary": {"videos", "finished", "failed", "last_version"},
}
SLUG = re.compile(r"[a-zA-Z0-9_-]{1,80}\Z")
_disabled = False


def config():
    return util.read_json(util.KIT / "telemetry.json", default={})


def enabled():
    try:
        return config().get("enabled") is True
    except (OSError, ValueError, AttributeError, util.Fail):
        return False


def utc():
    return datetime.now(timezone.utc).isoformat()


def queue_dir():
    return util.STUDIO_OUT / "dashboard-queue"


def install_id():
    path = util.STUDIO_OUT / "dashboard-install-id"
    with util.file_guard(path.with_suffix(".guard"), timeout=2):
        try:
            return str(uuid.UUID(path.read_text().strip()))
        except (OSError, ValueError):
            value = str(uuid.uuid4())
            path.write_text(value + "\n")
            return value


def email(value):
    value = value.strip() if isinstance(value, str) else ""
    return value if re.fullmatch(r"[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+", value) and len(value) <= 254 else None


def identity():
    from . import editor
    host = editor.provider_name()
    address = util.read_json(util.STUDIO_OUT / "dashboard-contact.json", default={}).get("email")
    return {"install_id": install_id(), "app_version": (util.KIT / "VERSION").read_text().strip()[:30],
            "host": host if host in ("claude", "codex") else "unknown", "email": email(address)}


def enqueue(payload):
    if not enabled():
        return None
    path = queue_dir()
    path.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(payload, ensure_ascii=False).encode()
    if len(raw) > (8192 if payload["type"] == "event" else 81920):
        raise ValueError("Dashboard payload too large")
    with util.file_guard(path / ".enqueue.guard", timeout=1):
        queued = sorted(path.glob("*.json"))
        if payload["type"] != "event":
            for existing in queued:
                saved = queue_row(existing)
                old = saved.get("payload") or {}
                if old.get("type") == payload["type"] and old.get("code") == payload.get("code"):
                    return existing.name
        if len(queued) >= 500:
            events = [file for file in queued if (queue_row(file).get("payload") or {}).get("type") == "event"]
            keep = 499 if payload["type"] == "event" else 500
            for expired in events[:max(0,len(events)-keep)]:
                expired.unlink(missing_ok=True)
        name = f"{time.time_ns():020d}-{uuid.uuid4().hex}.json"
        util.write_json(path / name, {"payload": payload, "created": time.time()})
    return name


def safe_detail(key, value):
    if key in ("captions", "look"):
        return value is None or isinstance(value, str) and re.fullmatch(r"[a-z0-9:-]{1,80}", value)
    if key == "effects":
        return isinstance(value, list) and len(value) <= 75 and all(safe_detail("look", item) for item in value)
    if key in ("from", "to", "last_version"):
        return isinstance(value, str) and re.fullmatch(r"[0-9.]{1,30}", value)
    if key in ("reference", "music", "failure_class"):
        return value in ("file", "link", "none", "auto", "library", "upload", "input", "app", "host", "machine", "network")
    return type(value) in (bool, int, float) and 0 <= value <= 86400


def event(name, *, project=None, request=None, step=None, seconds=None, percent=None, details=None):
    if name not in EVENTS or not enabled():
        return
    try:
        payload = dict(identity(), type="event", name=name, event_id=str(uuid.uuid4()), time=utc(),
                       mac={}, video=None, details={})
        if project:
            payload["video"] = hashlib.sha256((payload["install_id"] + project).encode()).hexdigest()[:20]
        if isinstance(request, str) and SLUG.fullmatch(request):
            payload["request_id"] = request
        if isinstance(step, str) and SLUG.fullmatch(step):
            payload["step"] = step
        for key, value, bound in (("seconds", seconds, 86400), ("percent", percent, 100)):
            if type(value) in (float, int) and 0 <= value <= bound:
                payload[key] = value
        macos = platform.mac_ver()[0]
        if re.fullmatch(r"[0-9.]{1,30}", macos):
            payload["mac"] = {"macos": macos}
        if details:
            payload["details"] = {key: value for key, value in details.items()
                                  if key in DETAILS.get(name, ()) and safe_detail(key, value)}
        return enqueue(payload)
    except (OSError, ValueError, util.Fail):
        pass


def post(payload):
    """One object per request. Disable redirects so credentials stay on the configured endpoint."""
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None

    cfg = config()
    url = cfg.get("url", "")
    if cfg.get("enabled") is not True or not url.startswith("https://") or not cfg.get("key"):
        return 0
    request = urllib.request.Request(url, data=json.dumps(payload, ensure_ascii=False).encode(),
                                     headers={"Content-Type": "application/json", "X-CreatorCut-Key": cfg["key"]})
    try:
        with urllib.request.build_opener(NoRedirect).open(request, timeout=5) as response:
            return response.status
    except urllib.error.HTTPError as error:
        return error.code
    except (OSError, ValueError):
        return 0


def queue_row(path):
    try:
        row = util.read_json(path, default={})
        payload = row.get("payload") if isinstance(row, dict) else None
        if not isinstance(payload, dict):
            return {}
        kind = payload.get("type")
        if kind == "event" and payload.get("name") in EVENTS:
            return row
        if kind in ("report", "report_note") and isinstance(payload.get("code"), str) and re.fullmatch(r"CC-[A-Z0-9]{5,8}", payload["code"]):
            return row
    except (ValueError, OSError, util.Fail, TypeError):
        pass
    return {}


def flush(limit=20, only_code=None):
    global _disabled
    if _disabled or not enabled():
        return
    directory = queue_dir()
    try:
        directory.mkdir(parents=True, exist_ok=True)
        with util.file_guard(directory / ".send.guard", timeout=0):
            attempted = 0
            for path in sorted(directory.glob("*.json")):
                row = queue_row(path)
                if not row:
                    path.unlink(missing_ok=True)
                    continue
                payload = row["payload"]
                if only_code is not None and payload.get("code") != only_code:
                    continue
                next_attempt = row.get("next_attempt", 0)
                if type(next_attempt) in (int, float) and next_attempt > time.time():
                    continue
                if attempted >= limit:
                    break
                attempted += 1
                code = post(payload)
                if code == 401:
                    _disabled = True
                    break
                kind = payload["type"]
                if code not in (200, 400, 413) and not (code == 404 and kind == "event"):
                    count = row.get("attempts", 0)
                    count = count + 1 if type(count) is int and 0 <= count < 100 else 1
                    if code != 404 or kind != "report_note" or count < 5:
                        row.update(attempts=count, next_attempt=time.time()+min(600,5*2**min(count,7)))
                        util.write_json(path,row)
                        if code != 404:
                            break
                        continue
                if kind != "event":
                    from . import problem_reports
                    problem_reports.receipt(payload, sent=code == 200)
                if code != 200:
                    util.log(f"Dashboard rejected {kind} ({code})")
                path.unlink(missing_ok=True)
    except (OSError, ValueError, util.Fail):
        pass


def contact():
    row = util.read_json(util.STUDIO_OUT / "dashboard-contact.json", default={})
    skips = row.get("skips", 0)
    return {"email": email(row.get("email")), "skips": min(2, max(0, skips)) if type(skips) is int else 0}


def contact_prompt():
    row = contact()
    videos = sum(path.is_file() for path in util.PROJECTS.glob("*/project.json"))
    return {"ask": not row["email"] and (row["skips"] == 0 or row["skips"] == 1 and videos >= 2)}


def save_contact(address, skip):
    row = contact()
    if skip:
        row["skips"] = min(2, row["skips"] + 1)
    else:
        row["email"] = email(address)
        if not row["email"]:
            raise util.Fail("Enter a valid email or choose Skip.")
    util.write_json(util.STUDIO_OUT / "dashboard-contact.json", row)


def watch():
    """One Studio-only observer. It sends queued facts and never drives an edit."""
    from editor import director, session
    from . import problem_reports
    last_alive = last_heartbeat = float("-inf")
    changed_at = time.monotonic()
    progress_key = None
    event("studio_opened")
    while True:
        if enabled():
            try:
                now = time.monotonic()
                if now - last_alive >= 600:
                    event("studio_alive")
                    last_alive = now
                update = util.read_json(util.STUDIO_OUT / "update.json", default={})
                from . import updater
                previous = util.read_json(updater.BACKUP / "backup.json", default={})
                old_version = previous.get("version") if isinstance(previous,dict) else None
                new_version = previous.get("target") if isinstance(previous,dict) and previous.get("phase")=="committed" else None
                if old_version and new_version==updater.current():
                    marker=util.STUDIO_OUT / "dashboard-last-update"
                    if not marker.exists() or marker.read_text().strip()!=new_version:
                        if event("update_installed",details={"from":old_version,"to":new_version}):
                            marker.write_text(new_version+"\n")
                history = util.STUDIO_OUT / "dashboard-history-sent"
                if update.get("status") == "done" and not history.exists():
                    projects = list(util.PROJECTS.glob("*/status.json"))
                    states = [director.status(path.parent) for path in projects]
                    queued = event("history_summary", details={"videos": len(states),
                          "finished": sum(s.get("state") == "done" for s in states),
                          "failed": sum(s.get("state") in ("failed", "needs_you") for s in states),
                          "last_version": old_version or identity()["app_version"]})
                    if queued:
                        history.touch()
                project = director.current()
                st = director.status(project) if project else {}
                request = st.get("request_id")
                stage = st.get("active_step")
                active = st.get("state") in ("working", "waiting_for", "waiting_resources")
                key = (request, stage, st.get("step_label"), round(st.get("overall_percent") or 0))
                if key != progress_key or not active:
                    progress_key, changed_at = key, now
                if project and request and active and now - last_heartbeat >= 300:
                    event("edit_heartbeat", project=project.name, request=request, step=stage,
                          percent=st.get("overall_percent"), details={"waiting_for_chat": not director.command_alive(st)})
                    last_heartbeat = now
                if project and request and st.get("state") == "working" and now - changed_at >= 1200 and not director.command_alive(st) and session.alive(st.get("owner_process")) is True:
                    row = problem_reports.automatic(project, area=stage or "editor", reason="stuck", signature=f"stuck:{request}")
                    if row and st.get("problem_report_code") != row["code"]:
                        director.put(project, _request=request, problem_report_code=row["code"])
                    changed_at = now
                flush()
            except (OSError, ValueError, TypeError, director.Needed, util.Fail):
                pass
        time.sleep(5)
