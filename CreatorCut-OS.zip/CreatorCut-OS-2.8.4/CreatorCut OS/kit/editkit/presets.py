"""Presets as skills. Every saved preset is also written as a real skill the agent loads:
.claude/skills/preset-<id>/SKILL.md (Claude Code) and .agents/skills/preset-<id>/SKILL.md (Codex).

The skill holds everything needed to replicate the reference editing: the creator's own description, the edit spec
(written from frame-by-frame measurements and refined by the agent after reading every frame sheet), the exact
caption measurements and the engine settings. The style JSON in my-brand/styles stays the source for the engine."""
from __future__ import annotations

import json,os

from . import colour_choice
from . import util
from .learn import _serialized


def write_skill(style_id: str) -> str:
    sid = util.slugify(style_id)
    f = util.USER_STYLES_DIR / f"{sid}.json"
    if not f.exists():
        raise util.Fail("That preset doesn't exist.")
    style = util.read_json(f)
    spec_f = util.USER_STYLES_DIR / f"{sid}.md"
    spec = spec_f.read_text(encoding="utf-8") if spec_f.exists() else ""
    m = util.read_json(util.PROJECTS / "_teach" / sid / "measurements.json", default={})
    name = style.get("name", sid)
    desc = (f"Apply the saved '{name}' editing preset using its actual recipe, instructions and reference evidence. "
            f"Use when style '{sid}' is selected or the creator requests {name}; current instructions take precedence.")
    refs = ", ".join(m.get("files", [])) if m else ""
    body = [f"# Preset: {name}", "",
            f"Engine style id: `{sid}` (settings in `my-brand/styles/{sid}.json`; set it with `edit.py style <project> {sid}`).",
            ""]
    if style.get("description"):
        body += ["## What the creator asked for", "", style["description"].strip(), ""]
    kit = style.get("kit") or {}
    rid = kit.get("reference")
    rdir = f"kit/projects/_teach/_refs/{rid}" if rid else ""
    body += ["## How to use this preset", "",
             "Follow kit/editor/RECIPE.md in the visible chat: read the saved design, adapt it to the new footage, inspect the finished frames, and publish.",
             f"1. Read the reference's annotated sheets{f' (`{rdir}/map/annotated/`)' if rdir else ''} and font sheets"
             f"{f' (`{rdir}/fonts/`)' if rdir else ''} before the first edit in a conversation.",
             "2. Reuse its design system (fonts, layout, motion, pacing, colour and sound), adapting content to the new script. Current explicit instructions and new references take precedence.",
             "3. Never copy the reference creator's logos, name, face or footage.", ""]
    if kit.get("styles"):
        body += ["## Measured text styles", "", "| style | role | font | size (frame h) | colour | case | entry |", "|---|---|---|---|---|---|---|"]
        for k, st in kit["styles"].items():
            f = st["font"]
            body.append(f"| S{k} | {st['role']} {st['size_class']} {st['colour_family']} | {f['family']} {f['weight']}{' italic' if f['italic'] else ''} | "
                        f"{st['size']} | {st['colour']} | {st['case']} | {st['anim']['ease']} {st['anim']['ms']} ms |")
        cap = kit.get("captions", {})
        body += ["", f"Words per caption: median {cap.get('words_per_block', {}).get('median')}, single-word share "
                 f"{cap.get('words_per_block', {}).get('single_word_share')}; cuts per minute {kit.get('cuts_per_minute')}.", ""]
    bp = style.get("blueprint") or {}
    if bp:
        import json as _json
        body += ["## Blueprint (how this reference edits beyond text; `design` applies it)", "",
                 "```json", _json.dumps(bp, indent=1, ensure_ascii=False)[:3000], "```",
                 ("It was measured automatically: refine it from the dense frames (`" + (rdir + "/dense/") + "`) and set `\"auto\": false`." if bp.get("auto") else ""), ""]
    try:
        from . import learn
        lr = [r for r in learn.public()["presets"].get(sid, [])]
        if lr:
            body += ["## Learned preferences (current request/reference takes precedence)", ""] + [f"- {r['rule']}" for r in lr] + [""]
    except Exception:
        pass
    if style.get("recipe"):
        recipe = recipe_context(sid)
        if recipe.get('kind')=='creatorcut':
            body += ['## Saved video design', '', 'Read '+recipe['folder']+'/recipe.json and plan.json. Reuse this design language, settings, fonts and motion on the new footage. Adapt words and timing. Current explicit choices take precedence. Follow kit/editor/RECIPE.md.', '']
        elif recipe.get("kind") in ("brief","snapshot"):
            body += ["## Saved editing instructions and references", "", "Read " + recipe["folder"] + "/recipe.json for the FULL brief_template, saved settings and references. This is a starting preset, not a reviewed finished edit. Resolve any unfinished reference analysis; do not fall back to a generic look.", ""]
        else:
            body += ["## Approved finished-edit recipe", "",
                 "Read the project-pinned recipe from customer-memory.json first; this skill describes the latest version.",
                 "Latest evidence: " + recipe["folder"] + "/recipe.json (with plan.json, scenes.json and review.json).",
                 "Reuse the design grammar, not the source creator's words, footage, timestamps or scene count.",
                 "Check the actual candidate against this recipe during review; a loaded skill is not proof of visual fidelity.", ""]
    body += ["## Edit spec", "", spec.strip() or "(not written yet)", ""]
    if refs:
        body += [f"Learned from: {refs}", ""]
    text = f"---\nname: preset-{sid}\ndescription: {json.dumps(desc, ensure_ascii=False)}\n---\n\n" + "\n".join(body)
    out = None
    for root in ((util.BRAND / "skills",) if os.environ.get('CREATORCUT_MANAGED_EDITOR')=='1' else (util.BRAND / "skills",util.ROOT / ".claude" / "skills", util.ROOT / ".agents" / "skills")):
        d = root / f"preset-{sid}"
        d.mkdir(parents=True, exist_ok=True)
        util.write_text(d / "SKILL.md",text)
        out = out or util.rel(d / "SKILL.md")
    return out


@_serialized
def rename_id(old: str, name: str) -> str:
    """Give a preset a readable id from its name (its files, analysis, skill and every video using it follow)."""
    import shutil
    new = util.slugify(name)[:40] or old
    if new == old or (util.USER_STYLES_DIR / f"{new}.json").exists():
        return old
    for ext in (".json", ".md", ".frames", ".recipes"):
        f = util.USER_STYLES_DIR / f"{old}{ext}"
        if f.exists():
            f.rename(util.USER_STYLES_DIR / f"{new}{ext}")
    spec = util.USER_STYLES_DIR / f"{new}.md"
    if spec.exists():
        spec.write_text(spec.read_text().replace(f"{old}.recipes/", f"{new}.recipes/"), encoding="utf-8")
    t_old, t_new = util.PROJECTS / "_teach" / old, util.PROJECTS / "_teach" / new
    if t_old.exists() and not t_new.exists():
        t_old.rename(t_new)
    for root in ((util.BRAND / "skills",) if os.environ.get('CREATORCUT_MANAGED_EDITOR')=='1' else (util.BRAND / "skills",util.ROOT / ".claude" / "skills", util.ROOT / ".agents" / "skills")):
        if (root / f"preset-{old}").exists():
            shutil.rmtree(root / f"preset-{old}")
    thumb = util.STUDIO_OUT / "assets" / "styles" / f"{old}.jpg"
    if thumb.exists():
        thumb.rename(thumb.with_name(f"{new}.jpg"))
    def fix_profile(p):
        p["learned_styles"] = [new if x == old else x for x in p.get("learned_styles", [])]
        if p.get("style") == old:
            p["style"] = new
    util.update_profile(fix_profile)
    from . import videos
    for pj in util.PROJECTS.glob("*/project.json"):
        cfg = util.read_json(pj, default={})
        if cfg.get("style") == old:
            # Merge into the latest project under the shared metadata guard;
            # renaming must not erase a brief saved concurrently in Studio.
            def relabel(current):
                if current.get("style") == old:
                    current["style"] = new
            videos.update(pj.parent.name, relabel)
    from . import learn
    with learn.memory_lock():
        d=learn._load()
        if old in d["presets"]:
            d["presets"][new]=d["presets"].pop(old);learn._save(d)
        learn.write_memory_skill()
    # A resumed project must read the renamed recipe and its preset feedback,
    # while retaining the exact version it selected before the rename.
    for pj in util.PROJECTS.glob("*/project.json"):
        cfg = util.read_json(pj, default={})
        if cfg.get("style") == new:
            learn.project_memory(pj.parent, new)
    return new


def recipe_context(sid: str, version=None) -> dict:
    if not sid:
        return {}
    sid = util.slugify(sid)
    style = util.read_json(util.USER_STYLES_DIR / f"{sid}.json", default={})
    recipe = style.get("recipe") or {}
    n = version or recipe.get("version")
    if not n:
        return {"skill": f".agents/skills/preset-{sid}/SKILL.md"} if style else {}
    f = util.USER_STYLES_DIR / f"{sid}.recipes" / f"v{int(n)}" / "recipe.json"
    if not f.exists():
        raise util.Fail("The selected preset recipe version is missing.", "Choose an available preset instead of silently using another look.")
    return dict(util.read_json(f), folder=util.rel(f.parent), skill=f".agents/skills/preset-{sid}/SKILL.md")


def _grammar(plan: dict, scenes: dict) -> dict:
    # Keep design attributes; source-specific text, files and absolute timing are evidence only.
    omit = {"text", "words", "src", "srcs", "assets", "t0", "t1", "file", "path", "url", "html", "start", "end", "t", "time", "id", "scene_id", "asset", "media_id", "transcript"}
    def clean(v):
        if isinstance(v, dict):
            return {k: clean(x) for k,x in v.items() if k not in omit and not k.startswith("_")}
        if isinstance(v, list):
            return [clean(x) for x in v][:100]
        return v
    patterns = []
    for item in plan.get("items", []):
        v = clean(item)
        if v and v not in patterns:
            patterns.append(v)
    return {"styles": clean(plan.get("styles", {})), "background": clean(plan.get("background", {})),
            "patterns": patterns, "decisions": clean(scenes.get("decisions", {})),
            "adaptation": "Re-anchor to the new speech and gestures; never reuse example text, footage or old absolute times."}


@_serialized
def from_video(pid: str, name: str, update: str = "", *, version_number=None) -> str:
    """Snapshot the reviewed video actually shown, including custom scenes, as a versioned style."""
    import shutil, time, copy
    from . import videos, workflow, learn
    cfg = videos.load(pid)
    p = util.PROJECTS / pid
    name = (name or "").strip()[:40]
    if not name:
        raise util.Fail("Give the preset a name.")
    sid = util.slugify(update) if update else util.slugify(name)[:40] or "preset"
    if update and not (util.USER_STYLES_DIR / f"{sid}.json").exists():
        raise util.Fail("That saved preset no longer exists.")
    for f in util.USER_STYLES_DIR.glob("*.json"):
        d = util.read_json(f, default={})
        if f.stem != (sid if update else "") and not d.get("hidden") and str(d.get("name", "")).strip().lower() == name.lower():
            raise util.Fail("That preset name is already used.")
    if not update:
        k = 2
        while (util.USER_STYLES_DIR / f"{sid}.json").exists() or (util.STYLES_DIR / f"{sid}.json").exists():
            sid, k = f"{util.slugify(name)[:36]}-{k}", k + 1
    # Use immutable published snapshots, not plans modified after the displayed version.
    versions = videos.versions(pid)
    selected=version_number if version_number is not None else cfg.get('selected_version')
    version = next((v for v in versions if v['n'] == selected), None) if selected else (versions[-1] if versions else None)
    if not version:
        raise util.Fail("Finish and review a video before saving its style.")
    vd = p / 'versions'; vn = version['n']
    review = util.read_json(vd / f"v{vn}.review.json", default={})
    movie = (util.ROOT / version['file']).resolve()
    if util.ROOT.resolve() not in movie.parents or not movie.is_file() or workflow.digest(movie) != version.get('candidate_sha256') or review.get('candidate_sha256') != version.get('candidate_sha256'):
        raise util.Fail("The saved version or its review no longer matches. Ask the editor to review it again.")
    plan = util.read_json(vd / f"v{vn}.plan.json", default={})
    scenes = util.read_json(vd / f"v{vn}.scenes.json", default={})
    if not plan or not scenes:
        raise util.Fail("This older video has no saved design recipe. Ask the editor to capture and review its design first.")
    for suffix, key in (("plan.json", "edit-plan.json"), ("scenes.json", "scene-plan.json")):
        expected = review.get("inputs", {}).get(key)
        if not expected or workflow.digest(vd / f"v{vn}.{suffix}") != expected:
            raise util.Fail("The saved design recipe no longer matches its reviewed inputs. Review it again before saving a preset.")
    # Revisions entered after this saved version must not leak into its preset.
    settings_file=vd/f"v{vn}.settings.json"
    if version.get('settings_sha256'):
        if not settings_file.is_file() or workflow.digest(settings_file)!=version['settings_sha256']:
            raise util.Fail("The saved version's style settings no longer match. Review it again before saving a preset.")
        cfg=util.read_json(settings_file)
    # A repeated update of the exact same reviewed version is idempotent.
    if update:
        existing = recipe_context(sid)
        if existing.get("candidate_sha256") == version['candidate_sha256'] and existing.get("video_version") == vn and existing.get("project") == pid:
            return sid

    old = cfg.get('style', '')
    data = copy.deepcopy(util.read_json(util.USER_STYLES_DIR / f"{sid if update else old}.json", default={}))
    n = int((data.get('recipe') or {}).get('version', 0)) + 1 if update else 1
    folder = util.USER_STYLES_DIR / f"{sid}.recipes" / f"v{n}"
    if folder.exists():
        raise util.Fail("A preset save is already in progress. Try again shortly.")
    folder.mkdir(parents=True)
    try:
        from . import library
        if cfg.get("preset_library_choices"):
            inherited=library.validate_choices(cfg['preset_library_choices'])
            manual=library.validate_choices(cfg.get('library_choices',{}))
            resolved=dict(inherited)
            for key in ('caption','look'):
                if key in manual:resolved[key]=manual[key]
            resolved['effects']=manual['effects'] if manual['effects_mode']=='replace' else list({x['id']:x for x in inherited.get('effects',[])+manual.get('effects',[])}.values())
            resolved['effects_mode']='replace'
            resolved['placements']={**inherited.get('placements',{}),**manual.get('placements',{})}
            cfg=dict(cfg,library_choices=resolved)
        recipe = {"schema": 1, "name": name, "version": n, "project": pid, "video_version": vn,
                  "candidate_sha256": version['candidate_sha256'], "created": time.time(),
                  "kind": "reviewed", "brief_template": {"prompt":cfg.get("brief",{}).get("prompt", ""), "settings": {k:cfg[k] for k in ("look","grade","colour_recipe","captions","sfx","music","voice_cleanup","music_volume","overrides","zoom","framing","library_choices","progress_bar") if k in cfg} | {'colour_recipe':colour_choice.pin(cfg)}}, "grammar": _grammar(plan, scenes),
                  "limitations": "Example media is not embedded. Source-specific custom code must be adapted, not blindly replayed."}
        approved_library=vd/f'v{vn}.library'
        if approved_library.exists():
            shutil.copytree(approved_library,folder/'library-evidence')
            reusable={}
            for receipt_file in (approved_library/'effects').glob('*/creatorcut-receipt.json'):
                receipt=util.read_json(receipt_file)
                parameters=util.read_json(receipt_file.parent/'creatorcut-parameters.json',default={})
                keep={'STYLE','ACCENT','INK','FONT','WEIGHT','CASE','TRACKING','SIZE','RADIUS','TILT','SHADOW','BORDER','PAPER','CHIP','DOT','SOUND','VOL_PRINT','VOL_HIT'}
                reusable[receipt['id']]={k:v for k,v in parameters.items() if k in keep}
            recipe['library_recipe']={'effect_style_parameters':reusable,'code_choices':cfg.get('library_choices',{}),'timing':'Re-anchor to new speech; no old absolute times are applied.'}
        util.write_json(folder / 'recipe.json', recipe)
        for suffix in ('plan.json', 'scenes.json', 'review.json'):
            shutil.copy2(vd / f"v{vn}.{suffix}", folder / suffix)
        from . import library
        if cfg.get('library_choices'):
            library.pin_choices(cfg['library_choices'])
            util.write_json(folder/'library-choices.json',cfg['library_choices'])
        # Candidate-registered custom source files are fingerprinted by the review.
        deps = review.get('inputs', {})
        util.write_json(folder / 'source-fingerprints.json', deps)
        sources = []
        def collect(v):
            if isinstance(v, dict):
                for k,x in v.items():
                    if isinstance(k,str) and Path(k).suffix in {'.html','.css','.js'}: sources.append(k)
                    collect(x)
            elif isinstance(v, list):
                for x in v: collect(x)
            elif isinstance(v,str) and Path(v).suffix in {'.html','.css','.js'}: sources.append(v)
        from pathlib import Path
        collect(deps); collect(plan)
        for src in set(sources):
            f = (util.ROOT / src).resolve()
            if not f.exists(): f = (p / src).resolve()
            expected = deps.get(src)
            if expected and f.is_file() and workflow.digest(f) != expected:
                raise util.Fail("An approved custom animation source changed. Restore or review it before saving the preset.")
            if p.resolve() in f.parents and f.is_file() and f.stat().st_size < 2000000:
                dest=folder/'source'/f.relative_to(p.resolve())
                dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dest)
        util.write_json(folder / 'feedback.json', util.read_json(p/'editing-feedback.json', default={}))
        poster = util.ROOT / version.get('poster', '')
        if poster.is_file():
            frames = util.USER_STYLES_DIR / f"{sid}.frames"; frames.mkdir(exist_ok=True)
            shutil.copy2(poster, folder/'poster.jpg')
            shutil.copy2(poster, frames/'01.jpg')
        data.update(name=name, hidden=False, saved_from_video=pid, brief_template=recipe["brief_template"], recipe={"version":n,"folder":util.rel(folder),"kind":"reviewed"},
                    description="Reusable style captured from a reviewed edit. Read the recipe and full approved scene evidence.")
        util.write_json(util.USER_STYLES_DIR / f"{sid}.json", data)
    except Exception:
        shutil.rmtree(folder, ignore_errors=True)
        raise
    util.USER_STYLES_DIR.mkdir(parents=True, exist_ok=True)
    (util.USER_STYLES_DIR / f"{sid}.md").write_text(
        f"# {name} — approved recipe v{n}\n\nRead {util.rel(folder)}/recipe.json and its scene/plan evidence. "
        "Preserve typography, motion language, layout, colour and sound intent. Adapt every scene to the new script. "
        "Do not copy the example's words, absolute times or private media. Current instructions override this preset.\n")
    if not update and old and old != sid:
        d = learn._load()
        if d['presets'].get(old):
            d['presets'][sid] = copy.deepcopy(d['presets'][old]); learn._save(d)
    util.update_profile(lambda pr: pr.update(learned_styles=list(dict.fromkeys(pr.get('learned_styles', [])+[sid]))))
    # Saving does not change the source project's design or invalidate its release.
    write_skill(sid)
    return sid

@_serialized
def from_brief(pid: str, name: str) -> str:
    """Save entered instructions/settings/reference evidence before rendering. Not an approved-edit claim."""
    import copy,time,shutil
    from . import videos,refs,learn
    cfg=videos.load(pid);name=(name or '').strip()[:40]
    if not name:raise util.Fail('Give this preset a name.')
    for f in util.USER_STYLES_DIR.glob('*.json'):
        if str(util.read_json(f,default={}).get('name','')).casefold()==name.casefold():
            raise util.Fail('That preset name is already used. Choose a new name or update it from a reviewed video.')
    old=cfg.get('style','');prompt=cfg.get('brief',{}).get('prompt','')
    references=refs.for_project(pid)
    if not prompt.strip() and not references and not cfg.get("library_choices") and not (util.USER_STYLES_DIR/f'{old}.json').exists():
        raise util.Fail('Add editing instructions or a reference before saving this preset.')
    sid=util.slugify(name)[:40] or 'preset';k=2
    while (util.USER_STYLES_DIR/f'{sid}.json').exists() or (util.STYLES_DIR/f'{sid}.json').exists():sid,k=f'{util.slugify(name)[:36]}-{k}',k+1
    data=copy.deepcopy(util.read_json(util.USER_STYLES_DIR/f'{old}.json',default={}))
    folder=util.USER_STYLES_DIR/f'{sid}.recipes'/'v1';folder.mkdir(parents=True)
    from . import library
    cfg=dict(cfg,library_choices=library.pin_choices(library.choices(videos._dir(pid),include_disabled=True)))
    settings={k:copy.deepcopy(cfg[k]) for k in ('look','grade','colour_recipe','captions','sfx','music','voice_cleanup','music_volume','overrides','zoom','framing','library_choices','progress_bar') if k in cfg} | {'colour_recipe':colour_choice.pin(cfg)}
    if settings.get("music")!="none":settings.pop("music",None)
    template={'prompt':prompt,'settings':settings}
    evidence=[]
    try:
        for ref in references:
            rid=ref['id'];refdir=refs._ref_dir(rid)
            row={k:ref[k] for k in ('id','url','file','name','title','kind','status') if k in ref}
            row['analysis_folder']=util.rel(refdir)
            evidence.append(row)
            dest=folder/'references'/rid;dest.mkdir(parents=True)
            for filename in ('kit.json','measurements.json','ref.json'):
                src=refdir/filename
                if src.exists():shutil.copy2(src,dest/filename)
        recipe={'schema':1,'kind':'brief','name':name,'version':1,'project':pid,'created':time.time(),
                'brief_template':template,'references':evidence,
                'grammar':{'adaptation':'These are saved customer instructions/reference evidence, not a finished edit. Adapt to new speech; study any unfinished reference analysis before planning.'}}
        util.write_json(folder/'recipe.json',recipe)
        data.update(name=name,hidden=False,description=prompt,brief_template=template,references=evidence,recipe={'version':1,'folder':util.rel(folder),'kind':'brief'})
        util.write_json(util.USER_STYLES_DIR/f'{sid}.json',data)
        (util.USER_STYLES_DIR/f'{sid}.md').write_text('Read '+util.rel(folder)+'/recipe.json for the actual saved instructions, settings and reference evidence. This preset has not yet captured a finished edit.\n')
        if learn._load()['presets'].get(old):
            d=learn._load();d['presets'][sid]=copy.deepcopy(d['presets'][old]);learn._save(d)
        util.update_profile(lambda pr:pr.update(learned_styles=list(dict.fromkeys(pr.get('learned_styles',[])+[sid]))))
        write_skill(sid)
        # Attach the new preset so the final result offers Update with this video.
        from . import editor
        if editor.read(pid).get('state') not in editor.ACTIVE:
            videos.set_brief(pid,{'style':sid})
        return sid
    except Exception:
        # Retain a completed preset if only attachment failed; do not erase valid user data.
        if not (util.USER_STYLES_DIR/f'{sid}.json').exists():shutil.rmtree(folder,ignore_errors=True)
        raise


@_serialized
def save_current(pid: str, name: str, update: str = '', *, version=None) -> dict:
    """Save reviewed output when verifiable, otherwise preserve an honest current-state recipe.
    Re-saving the same name from this project updates a versioned recipe, never another project's preset.
    """
    import copy,time,shutil
    from pathlib import Path
    from . import videos,library
    from editor import director
    if director.status(videos._dir(pid)).get('schema')==2:
        cfg=videos.load(pid);p=videos._dir(pid);sid=util.slugify(update or name)[:40] or 'my-style'
        base=sid;n=2
        if update and not (util.USER_STYLES_DIR/f'{sid}.json').is_file():raise util.Fail('Choose a saved preset to update.')
        while not update and ((util.STYLES_DIR/f'{sid}.json').exists() or (util.USER_STYLES_DIR/f'{sid}.json').exists() and util.read_json(util.USER_STYLES_DIR/f'{sid}.json',default={}).get('saved_from_video')!=pid):
            sid=f'{base[:35]}-{n}';n+=1
        selected=next((v for v in videos.versions(pid) if v['n']==version),None) if version else next(iter(reversed(videos.versions(pid))),None)
        settings=util.read_json(p/'versions'/f"v{selected['n']}.settings.json",default=cfg) if selected else cfg
        keys=('look','grade','captions','captions_on','caption_size','caption_y','caption_mode','uppercase','sfx_on','sfx_volume','music','music_volume','voice_cleanup','zoom_on','framing','library_choices','progress_bar')
        settings={k:copy.deepcopy(settings[k]) for k in keys if k in settings}
        if settings.get('music')!='none':settings.pop('music',None)
        vn=selected['n'] if selected else 0
        plan=util.read_json(p/'versions'/f'v{vn}.plan.json',default={}) if selected else util.read_json(p/'plan.json',default={})
        old=util.read_json(util.USER_STYLES_DIR/f'{sid}.json',default={});revision=int((old.get('recipe') or {}).get('version',0))+1
        folder=util.USER_STYLES_DIR/f'{sid}.recipes'/f'v{revision}';folder.mkdir(parents=True,exist_ok=False)
        template={'settings':settings,'prompt':cfg.get('brief',{}).get('prompt','')}
        recipe={'schema':2,'kind':'creatorcut','version':revision,'video_version':vn,'project':pid,'settings':settings,'brief_template':template,'plan':plan,'created':time.time()}
        design=p/'versions'/f'v{vn}.design' if selected else p
        if selected and (design/'design.json').is_file():
            files={};unavailable=[]
            for relative,expected in util.read_json(design/'design.json').get('files',{}).items():
                rel=Path(relative);source=design/rel
                if rel.is_absolute() or '..' in rel.parts or source.is_symlink() or not source.resolve().is_relative_to(design.resolve()) or not source.is_file() or director.digest_file(source)!=expected:
                    unavailable.append(relative);continue
                director.atomic_copy(source,folder/'design'/rel);files[relative]=expected
            recipe['design']={'folder':util.rel(folder/'design'),'files':files,'unavailable':unavailable,'adaptation':'Read the actual saved HTML and effect code; adapt it to new speech, never reuse example media or timing.'}
            util.write_json(folder/'design/design.json',{'files':files,'unavailable':unavailable})
        elif not selected:
            files=director.snapshot_design(p,folder/'design')
            recipe['design']={'folder':util.rel(folder/'design'),'files':files,'adaptation':'Current editable design, not a claim of a verified rendered match.'}
        else:
            recipe['design']={'files':{},'limitation':'This older video predates editable-design snapshots; only its saved plan and settings are available.'}

        util.write_json(folder/'recipe.json',recipe)
        util.write_json(folder/'plan.json',plan)
        data={'id':sid,'name':str(name)[:40],'origin':'yours','saved_from_video':pid,'recipe':{'kind':'creatorcut','version':revision,'folder':util.rel(folder)},'brief_template':template}
        util.write_json(util.USER_STYLES_DIR/f'{sid}.json',data)
        videos.update(pid,lambda c:c.setdefault('saved_presets',{}).update({str(name).casefold():sid}))
        write_skill(sid)
        util.update_profile(lambda profile:profile.update(learned_styles=list(dict.fromkeys(profile.get('learned_styles',[])+[sid]))))
        return {'ok':True,'id':sid,'name':data['name'],'saved':True}
    cfg=videos.load(pid);p=videos._dir(pid);name=str(name).strip()[:40] or 'My video style'
    sid=util.slugify(update) if update else cfg.get('saved_presets',{}).get(name.casefold(),'')
    if sid and not (util.USER_STYLES_DIR/f'{sid}.json').exists():sid=''
    if not sid:
        for f in util.USER_STYLES_DIR.glob('*.json'):
            other=util.read_json(f,default={})
            if str(other.get('name','')).casefold()==name.casefold():
                origin=other.get('saved_from_video')
                if not origin and other.get('recipe'):origin=recipe_context(f.stem).get('project')
                if origin==pid:sid=f.stem;break
    verified=False;limitation=''
    try:
        sid=from_video(pid,name,sid,version_number=version);verified=True
    except util.Fail as e:
        limitation=str(e)
        if not sid:
            base=util.slugify(name)[:36] or 'preset';sid=base;n=2
            while (util.USER_STYLES_DIR/f'{sid}.json').exists():sid=f'{base}-{n}';n+=1
        data=copy.deepcopy(util.read_json(util.USER_STYLES_DIR/f'{sid}.json',default={}))
        n=int((data.get('recipe') or {}).get('version',0))+1
        folder=util.USER_STYLES_DIR/f'{sid}.recipes'/f'v{n}'
        # A partial prior save cannot block all future saves; retain it and use the next slot.
        while folder.exists():n+=1;folder=folder.parent/f'v{n}'
        folder.mkdir(parents=True)
        try:
            vs=videos.versions(pid);v=next((x for x in vs if x['n']==version),None) if version else (vs[-1] if vs else {})
            v=v or {};vn=v.get('n');vd=p/'versions'
            source_cfg=cfg
            if vn and (vd/f'v{vn}.settings.json').exists():source_cfg=util.read_json(vd/f'v{vn}.settings.json')
            settings={k:copy.deepcopy(source_cfg[k]) for k in ('look','grade','colour_recipe','captions','sfx','music','voice_cleanup','music_volume','overrides','zoom','framing','library_choices','progress_bar') if k in source_cfg} | {'colour_recipe':colour_choice.pin(source_cfg)}
            if settings.get("music")!="none":settings.pop("music",None)
            # Preserve executable versions and their local pinned code; no generic name-only substitution.
            if settings.get('library_choices'):settings['library_choices']=library.pin_choices(settings['library_choices'])
            template={'prompt':source_cfg.get('brief',{}).get('prompt',''),'settings':settings}
            plan=util.read_json(vd/f'v{vn}.plan.json',default={}) if vn else util.read_json(p/'edit-plan.json',default={})
            scenes=util.read_json(vd/f'v{vn}.scenes.json',default={}) if vn else util.read_json(p/'scene-plan.json',default={})
            util.write_json(folder/'plan.json',plan);util.write_json(folder/'scenes.json',scenes)
            # Preserve referenced custom implementation files as local evidence, without copying private footage.
            sources=set()
            def collect(value):
                if isinstance(value,dict):
                    for key,val in value.items():
                        if key in ('src','file','source','html_path','script') and isinstance(val,str):sources.add(val)
                        elif key=='assets' and isinstance(val,dict):sources.update(x for x in val.values() if isinstance(x,str))
                        else:collect(val)
                elif isinstance(value,list):
                    for item in value:collect(item)
            collect(plan)
            for src in sources:
                f=Path(src);f=f if f.is_absolute() else (p/f if (p/f).exists() else util.ROOT/f);f=f.resolve()
                if p.resolve() in f.parents and f.suffix.lower() in ('.py','.js','.html','.css','.json','.svg') and f.is_file() and f.stat().st_size<2000000:
                    target=folder/'source'/f.relative_to(p.resolve());target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,target)

            recipe={'schema':1,'kind':'snapshot','name':name,'version':n,'project':pid,'video_version':vn,'created':time.time(),'brief_template':template,'grammar':_grammar(plan,scenes),'verification':{'reviewed':False,'reason':limitation},'references':copy.deepcopy(source_cfg.get('brief',{}).get('references',[])),'limitations':'Saved available design/settings as current-state evidence. Inspect and adapt these sources before use; do not claim this snapshot is a reviewed movie match.'}
            util.write_json(folder/'recipe.json',recipe)
            if vn:
                lib=vd/f'v{vn}.library'
                if lib.exists():shutil.copytree(lib,folder/'library-evidence')
            data.update(name=name,hidden=False,saved_from_video=pid,description='Saved current video style and instructions.',brief_template=template,recipe={'version':n,'folder':util.rel(folder),'kind':'snapshot'})
            util.write_json(util.USER_STYLES_DIR/f'{sid}.json',data)
            (util.USER_STYLES_DIR/f'{sid}.md').write_text('Read '+util.rel(folder)+'/recipe.json and its exact available design. This is a saved current state, not a verified finished-edit claim. Adapt to the next video.\n')
            write_skill(sid)
        except Exception:
            shutil.rmtree(folder,ignore_errors=True);raise
        util.update_profile(lambda pr:pr.update(learned_styles=list(dict.fromkeys(pr.get('learned_styles',[])+[sid]))))
    videos.update(pid,lambda c:c.setdefault('saved_presets',{}).update({name.casefold():sid}))
    return {'ok':True,'id':sid,'reviewed':verified,'saved_current_state':not verified,'message':'Style saved to your presets.'}


def queue_save(pid,name,update='',version=None):
    """Return immediately; an idempotent background job owns hash/copy work."""
    import hashlib,json
    from . import videos,jobs
    videos.load(pid)
    if version is None:
        versions=videos.versions(pid)
        if versions:version=versions[-1]['n']
    spec={'project':pid,'name':str(name).strip()[:40],'update':str(update),'version':version}
    key=hashlib.sha256(json.dumps(spec,sort_keys=True).encode()).hexdigest()
    old=jobs.find('preset_save',key,states=('queued','waiting','running','done'))
    if old:return {'ok':True,'job':old['id']}
    def work(jid):
        jobs.update(jid,message='Saving your video style')
        return save_current(pid,spec['name'],spec['update'],version=version)
    job=jobs.submit('preset_save',work,key=key,label='Saving your preset',heavy=False)
    return {'ok':True,'job':job['id']}
