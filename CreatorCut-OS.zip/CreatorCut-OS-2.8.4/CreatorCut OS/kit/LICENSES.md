# Licences

CreatorCut code, generated sounds, fonts, and installed third-party tools have separate terms. Review the applicable upstream licences for your use and organisation; this document does not grant rights to third-party media.

- **CreatorCut code and design:** © 2026 Nate Gold AI LLC. All rights reserved. See the app-root LICENSE for use and copying terms. Third-party parts below keep their own licences.
- **Fonts** (kit/fonts): Inter and Inter Display (SIL Open Font License 1.1, rsms/inter); Poppins, Lora, Anton, Instrument Serif, Bebas Neue, Archivo Black, DM Serif Display and Space Mono (SIL Open Font License 1.1), Permanent Marker (Apache License 2.0) and the Google Fonts the app downloads when matching a reference (SIL Open Font License 1.1 or Apache 2.0). Bundled notices for these families are in kit/fonts/licenses.
- **Sound effects** (kit/sfx): synthesised on your computer by kit/editkit/sfx.py. Original, royalty-free, yours to use.
- **FFmpeg** (kit/bin, downloaded by the installer): LGPL/GPL builds from the official FFmpeg build sites, used unmodified as a separate program.
- **Python packages** (.venv): faster-whisper (MIT), Pillow (MIT-CMU), certifi (MPL 2.0), yt-dlp (Unlicense), OpenCV (Apache 2.0); on Mac ocrmac (MIT) and PyObjC (MIT); elsewhere RapidOCR (Apache 2.0) and MediaPipe (Apache 2.0).
- **Speech model**: Whisper (MIT) in the faster-whisper format, downloaded once.
- **Motion graphics** (kit/render, installed per computer): HyperFrames (Apache 2.0) and Remotion (Remotion licence: free for individuals and companies up to 3 people; larger companies need a Remotion company licence) with GSAP (free standard licence). The headless browser is Chrome for Testing (BSD-style).

## CreatorCut OS v2 additions

- **Creator font library** (kit/fonts): Montserrat, TikTok Sans, Oswald, League Spartan, Barlow Condensed, Fredoka, Rubik,
  Outfit, Playfair Display, Caveat, DM Sans, Lexend, Nunito, Kanit, Raleway, Sora, Syne, Poppins, Lilita One, Bangers
  (SIL Open Font License 1.1); Luckiest Guy, Roboto, Open Sans (Apache License 2.0). Static Latin instances from
  Fontsource; family names normalised (suffix "CC") so every weight is a separate family. Free to use in videos.
- **Music library** (kit/music): comes from ccMixter under each track’s Creative Commons BY licence. Studio shows the exact credit (Copy credit), and each published version keeps a vN.credits.txt.
- **Reference analysis** uses OpenCV (Apache 2.0) and yt-dlp (Unlicense). Reference videos are used only to measure style
  and may be retained in the local project for comparison evidence; remove them only when no longer needed and authorized.
- **Colour grades**: every LUT is generated on your computer for that video (no third-party LUTs).

## Signature fallback
Inter Tight variable font is redistributed unmodified from Google Fonts under SIL OFL 1.1; see kit/fonts/licenses/InterTight-OFL.txt for full copyright and terms. Signature fallback code is independently authored. The separately imported Studio library and its downloaded sound assets are described below.

## Imported Studio styles and effects
Effect, caption and style source code is part of CreatorCut.

The pack uses GSAP 3.14.2. Its copyright/licence header is preserved in engine/gsap.min.js; the GSAP Standard License is at https://gsap.com/standard-license. The local copy removes a runtime CDN dependency. Pack sound files originate in heygen-com/hyperframes/skills/media-use/audio/assets/sfx; its Apache-2.0 licence is included under style-library/sfx/LICENSE-HyperFrames.txt. Fonts remain subject to their accompanying OFL/other licence files.

Clean matting optionally downloads the hash-pinned RobustVideoMatting rvm_mobilenetv3 ONNX model from PeterL1n/RobustVideoMatting. The upstream project/model's GPL-3.0 terms remain applicable. Model weights are not embedded in this source ZIP. CreatorCut does not relicense third-party dependencies or claim ownership of them.

## Walkthrough and preview images
Walkthrough and preview images use [Unsplash](https://unsplash.com/license) and [Pexels](https://www.pexels.com/license/) stock under their licences. No endorsement is implied.

## ccMixter music credits
Library tracks retain their track-specific Creative Commons BY licence and exact credit. Include the shown credit and source/licence link in the post description. Studio offers Copy credit on the selected track and finished video; each published version keeps a matching vN.credits.txt post-details file. Uploaded music must be supplied with permission. Auto requires a real licensed track with audio.music.src, rights and reason. When offline, choose suitable already-downloaded licensed audio or report the missing input; never silently remove music. No ownership or Content ID promise is made.

