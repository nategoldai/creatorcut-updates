"""Read-only identity of the visible host process; never signal a chat."""
import os,re
from pathlib import Path
import subprocess
from editkit import util


def capture(start_pid=None):
    pid = os.getppid() if start_pid is None else start_pid
    for _ in range(8):
        if pid <= 1:
            break
        try:
            value = subprocess.check_output(
                ['/bin/ps', '-o', 'ppid=', '-o', 'comm=', '-p', str(pid)],
                text=True, stderr=subprocess.DEVNULL, timeout=2).strip()
            parent, command = value.split(None, 1)
            name=Path(command.strip()).name.lower()
            wrapped=False
            if name in ('node','node.exe','nodejs','bun'):
                full=subprocess.check_output(['/bin/ps','-o','command=','-p',str(pid)],text=True,stderr=subprocess.DEVNULL,timeout=2)
                wrapped=bool(re.search(r'(?:@anthropic-ai/claude-code|(?:^|[/\s])claude-code(?:[/\s]|$))',full))
            if name in ('claude', 'claude.exe', 'codex', 'codex.exe') or wrapped:
                birth = util.process_identity(pid)
                return {'pid': pid, 'birth': birth} if birth else None
            pid = int(parent)
        except (OSError, ValueError, subprocess.SubprocessError):
            break
    return None


def project_folder(record):
    """Read the verified host's cwd, independent of the tool shell's cwd."""
    if alive(record) is not True:
        return None
    try:
        raw = subprocess.check_output(
            ['/usr/sbin/lsof', '-a', '-p', str(record['pid']), '-d', 'cwd', '-F0n'],
            stderr=subprocess.DEVNULL, timeout=2)
        paths = [os.fsdecode(field[1:]) for field in raw.replace(b'\0\n', b'\0').split(b'\0')
                 if field.startswith(b'n/')]
        if len(paths) == 1 and alive(record) is True:
            return Path(paths[0]).resolve()
    except (OSError, RuntimeError, subprocess.SubprocessError):
        pass
    return None


def alive(record):
    """True=that process lives, False=proven gone, None=not provable."""
    if not isinstance(record, dict) or type(record.get('pid')) is not int or not 1 < record['pid'] <= 2147483647 or not isinstance(record.get('birth'), str) or not record['birth']:
        return None
    if not util.process_alive(record['pid']):
        return False
    current = util.process_identity(record['pid'])
    return current == record['birth'] if current else None
