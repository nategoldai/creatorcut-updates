"""Read assembled audio in bounded chunks after regular transcription fails."""
import os
import subprocess
import sys
import tempfile
import wave
from pathlib import Path

from faster_whisper import WhisperModel

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from editkit import util


def main():
    project = Path(sys.argv[1])
    prompt = sys.argv[2] if len(sys.argv) > 2 else "Claude, Claude Code, skill."
    work = project / "work"
    model = WhisperModel(os.environ.get("CREATORCUT_SPEECH_MODEL", "small"), device="cpu", compute_type="int8")
    words = []
    with tempfile.TemporaryDirectory(dir=work) as scratch:
        audio, chunk = Path(scratch) / "audio.wav", Path(scratch) / "chunk.wav"
        subprocess.run([str(util.KIT / "bin/ffmpeg"), "-nostdin", "-v", "error", "-i",
                        str(project / "assets/aroll.mp4"), "-vn", "-ac", "1", "-ar", "16000",
                        str(audio)], check=True)
        with wave.open(str(audio)) as source:
            rate = source.getframerate()
            while source.tell() < source.getnframes():
                offset = source.tell() / rate
                with wave.open(str(chunk), "wb") as target:
                    target.setparams(source.getparams())
                    target.writeframes(source.readframes(rate * 60))
                segments, _ = model.transcribe(str(chunk), word_timestamps=True, vad_filter=False, initial_prompt=prompt)
                for segment in segments:
                    for word in segment.words or []:
                        words.append({"text": word.word.strip(), "start": round(offset + word.start, 3),
                                      "end": round(offset + word.end, 3)})
                print(f'"percent": {100 * source.tell() / source.getnframes():.2f}', flush=True)
    util.write_json(work / "words_raw.json", words)
    util.write_json(project / "words.json", words)


if __name__ == "__main__":
    main()
