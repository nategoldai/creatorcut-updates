"""Project hooks only. No global settings and no permission answers."""
import hashlib,json,sys,time
from . import director as d

def run(kind,data):
 session=str(data.get('session_id','unknown'));name=hashlib.sha256(session.encode()).hexdigest()[:20]
 if not d.listener_allowed():
  if kind=='start':return {'hookSpecificOutput':{'hookEventName':'SessionStart','additionalContext':d.setup_handoff()+' Do not start wait from this installation chat.'}}
  return None
 if kind=='start' and data.get('source')=='compact':
  return {'hookSpecificOutput':{'hookEventName':'SessionStart','additionalContext':'Context was compacted. Run .venv/bin/python edit.py next, re-read kit/editor/RECIPE.md, and continue silently from the next unfinished step.'}}
 if kind=='start':
  from editkit import editor
  editor.configure_provider('claude')
  from . import session as chat_process
  d.write(d.OUT/'chat-session.json',{'id':session,'at':time.time(),'process':chat_process.capture()})
  return {'hookSpecificOutput':{'hookEventName':'SessionStart','additionalContext':'Your first reply here must be: You’re in CreatorCut. Opening Studio. Read CLAUDE.md. Run .venv/bin/python edit.py next for pending or unfinished work. Start .venv/bin/python edit.py wait using the background Bash option when this chat opens Studio or finishes a video. If wait says another chat took over, stop listening: never re-arm wait in this chat unless the Stop hook or wait tells you the other chat closed, and do not narrate that line to the customer. If setup is unfinished, finish setup first. Do housekeeping silently. If nothing is waiting, say: Choose your footage in Studio, then press Make my video.'}}
 p=d.current()
 if kind=='notification':
  if p and d.status(p).get('owner') in (None,'',session) and d.status(p).get('state') not in ('done','stopped'):d.put(p,'needs_you',step_label=d.PLAIN['needs'])
  return None
 if kind!='stop' or data.get('stop_hook_active'):return None
 file=d.OUT/'hook-stops'/f'{name}.json';previous=d.read(file)
 if previous.get('blocked'):
  d.write(file,{'blocked':False});return None
 reason=None
 if p and d.status(p).get('owner') in (None,'',session) and d.status(p).get('state')=='working':reason='Continue the saved CreatorCut edit from its next unfinished recipe step; publish it or run .venv/bin/python edit.py ask if the customer must answer or just asked to pause. Respect an explicit stop request.'
 else:
  identity=d.listener_identity()
  retired=bool(identity and d.read(d.OUT/'retired-listeners'/f"{identity['key']}.json").get('retired'))
  still_retired=d.listener_retired(identity)
  if retired and not still_retired:
   reason='The other CreatorCut chat closed. Start .venv/bin/python edit.py wait with the Bash background option again, silently.'
  elif identity and not still_retired and not d.waiter_alive():reason='Start .venv/bin/python edit.py wait with the Bash background option, then stop. If it says another chat took over, never re-arm wait in this chat unless the Stop hook or wait tells you the other chat closed. Do this silently; do not narrate housekeeping.'
 if reason:
  d.write(file,{'blocked':True});return {'decision':'block','reason':reason}
 return None
if __name__=='__main__':
 try:data=json.loads(sys.stdin.read(65536) or '{}');result=run(sys.argv[1],data)
 except (ValueError,OSError,d.Needed):result=None
 if result:print(json.dumps(result))
