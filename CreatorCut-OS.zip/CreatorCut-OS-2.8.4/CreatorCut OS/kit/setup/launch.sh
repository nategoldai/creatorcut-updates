#!/bin/sh
# Relocatable entry: no system Python, downloads or permission changes.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
report_studio_start() {
 if [ "${1:-}" = studio ] && [ "${2:-}" = open ] && [ -x /usr/bin/perl ]; then
  /usr/bin/perl "$ROOT/kit/setup/dashboard-event.pl" "$ROOT" studio_failed studio >/dev/null 2>&1 || true
 fi
}
BASE=''
for py in "$ROOT"/kit/bin/python/*/bin/python3.12; do
 if [ -x "$py" ]; then BASE=$py; break; fi
done
if [ -z "$BASE" ]; then
 report_studio_start "$@"
 echo 'CreatorCut needs its local tools. Open this folder as your project and ask: Finish CreatorCut setup.' >&2; exit 1
fi
"$BASE" "$ROOT/kit/tools/relocate.py" || { report_studio_start "$@"; echo 'CreatorCut could not reconnect its local tools. Open this folder as your project and ask: Repair CreatorCut. Your files are safe.' >&2; exit 1; }
cd "$ROOT"
exec "$ROOT/.venv/bin/python" "$ROOT/edit.py" "$@"
