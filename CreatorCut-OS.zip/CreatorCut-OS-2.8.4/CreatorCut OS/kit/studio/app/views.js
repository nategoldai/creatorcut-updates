/* CreatorCut OS — screens: onboarding, Home, Studio, My videos, Presets. */
(function () {
  "use strict";
  const A = window.AIE;
  const { esc, icon } = A;
  const S = () => A.state || {};
  const P = () => S().profile || {};
  const agent = () => A.agentName();
  const listening = () => !!(S().listening && S().listening.listening);
  // the editor (Claude Code / Codex) behind the app: listening, working on a step, or not open
  // 2.2: the creator talks to the editor in the Claude Code / Codex chat; this screen only shows the work
  const ed = () => ({ connected: !S().offline, busy: false });
  const edLabel = () => "Studio";
  const NAME = "CreatorCut";

  /* ============================================================ pieces == */
  const mark = (size) => '<span class="mark' + (size ? " " + size : "") + '" aria-hidden="true">' + icon("cut") + '<i class="rec"></i></span>';
  const brand = () => '<span class="brand">' + mark() + '<span class="wordmark">' + NAME + "<span>OS</span></span></span>";
  const presets = () => (S().styles || []).filter((s) => s.yours);
  const styleById = (id) => (S().styles || []).find((x) => x.id === id);
  const projectById = (id) => (S().projects || []).find((x) => x.name === id);
  function installInfo() { return A.installView(S().install); }
  function miniRing(pct) {
    const c = 2 * Math.PI * 6;
    return '<svg class="mini-ring" viewBox="0 0 16 16"><circle class="t" cx="8" cy="8" r="6"/><circle class="v" cx="8" cy="8" r="6" stroke-dasharray="' + c.toFixed(2) + '" stroke-dashoffset="' + (c * (1 - pct / 100)).toFixed(2) + '"/></svg>';
  }
  function conn() {
    const iv = installInfo();
    if (iv.state === "running" || iv.state === "paused") return '<button class="conn" data-act="sheet" data-sheet="install">' + miniRing(iv.pct) + "Installing " + iv.pct + "%</button>";
    return '<span class="conn"><i class="dot ok"></i>' + edLabel() + "</span>";
  }
  function ago(t) { const s = Date.now() / 1000 - t; return s < 60 ? "now" : s < 3600 ? Math.floor(s / 60) + "m" : s < 86400 ? Math.floor(s / 3600) + "h" : Math.floor(s / 86400) + "d"; }
  const firstName = () => ((P().name || "").trim().split(/\s+/)[0] || "");

  /* ========================================================= onboarding == */
  const OB = ["welcome"];
  const PLATFORMS = [["tiktok", "TikTok"], ["reels", "Reels"], ["shorts", "Shorts"], ["youtube", "YouTube"]];
  const forced = (location.search.match(/[?&]ob=(\w+)/) || [])[1];
  if (forced && OB.includes(forced)) { A.ui.forceOnboarding = true; A.ui.obStep = forced; }
  function obStep() { const s = A.ui.obStep || (P().onboarding && P().onboarding.step) || "welcome"; return OB.includes(s) ? s : "welcome"; }
  function goStep(st) {
    const el = document.querySelector(".ob-step");
    const go = () => { A.ui.obStep = st; if (!S().offline) A.api.profile({ onboarding: { step: st } }).catch(() => {}); A.render(); window.scrollTo(0, 0); };
    if (el && !A.reduced) { el.classList.add("leave"); setTimeout(go, 240); } else go();
  }
  function obWelcome() {
    const iv = installInfo();
    return '<div class="ob-step">' + '<div class="welcome-timeline">'+miniEditTimeline(false)+'</div>' +
      '<div class="col" style="gap:12px"><h1 class="t-hero" tabindex="-1">CreatorCut OS</h1><p class="t-body">Your footage. Your style. Let’s make something great.</p></div>' +
      '<div class="field"><label class="t-label" for="ob-name">What’s your first name?</label><input class="input" id="ob-name" style="height:46px;font-size:16px" value="' + esc(A.ui.obName != null ? A.ui.obName : P().name || "") + '" data-input="obName" data-enter="obNameGo" data-free autocomplete="given-name"></div>' +
      (iv.state === "error" ? '<div class="well t-small" style="padding:12px 14px">' + esc(S().install.error || "Setup stopped.") + " Type <b>continue setup</b> in " + agent() + ".</div>" : "") +
      '<div class="ob-actions"><button class="btn btn-ink btn-lg" data-act="obNameGo">Continue' + icon("arrow") + "</button>" +
      (["running", "paused"].includes(iv.state) ? '<button class="btn btn-text" data-act="sheet" data-sheet="install">' + miniRing(iv.pct) + "Installing " + iv.pct + "%</button>" : "") + "</div></div>";
  }
  function glyph(k) {
    const phone = (inner) => '<svg class="glyph" viewBox="0 0 52 72" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="10" y="3" width="32" height="66" rx="7"/>' + inner + "</svg>";
    if (k === "tiktok") return phone('<path d="M18 54h12M18 59h8" opacity=".5"/><circle cx="35" cy="32" r="1.8" fill="currentColor" stroke="none"/><circle cx="35" cy="39" r="1.8" fill="currentColor" stroke="none"/><circle cx="35" cy="46" r="1.8" fill="currentColor" stroke="none"/>');
    if (k === "reels") return phone('<rect x="17" y="24" width="18" height="18" rx="5"/><path d="M24 29.5v7l5.5-3.5z" fill="currentColor" stroke="none"/>');
    if (k === "shorts") return phone('<path d="M22 28v13l10-6.5z" fill="currentColor" stroke="none"/><path d="M17 54h18" opacity=".5"/>');
    return '<svg class="glyph" viewBox="0 0 52 72" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="21" width="48" height="30" rx="5"/><path d="M22 30v12l9-6z" fill="currentColor" stroke="none"/><path d="M18 58h16" opacity=".5"/></svg>';
  }

  function onboarding() {
    const st = obStep(), idx = OB.indexOf(st);
    const body = obWelcome();
    const intro = !A.reduced && (!A.ui.introSeen || (!P().name && !A.ui.firstWelcomePlayed)) ? '<div class="intro design-intro" aria-hidden="true" data-static="intro"><div class="intro-timeline">'+miniEditTimeline(false)+'<span class="intro-wordmark">CreatorCut<span>Your next great edit starts here.</span></span></div></div>' : "";
    return intro + '<div class="ob"><div class="ob-progress" style="width:' + ((idx + 1) / OB.length) * 100 + '%"></div><div class="ob-top">' + brand() + '<span class="spacer"></span>' + conn() + "</div>" +
      '<main class="ob-body" data-key="ob-' + st + '">' + body + "</main><div></div></div>";
  }

  /* ============================================================== shell == */
  const NAV = [["home", "Home", "home"], ["studio", "Studio", "plus"], ["editor", "Editor", "edit"], ["videos", "My videos", "library"]];
  function shell(content, route) {
    const idx = Math.max(0, NAV.findIndex((n) => n[0] === route));
    const on = NAV.some((n) => n[0] === route);
    const side = '<nav class="side" aria-label="CreatorCut OS">' + brand() +
      '<div class="rail"><i class="ind" style="transform:translateY(' + idx * 40 + "px);opacity:" + (on ? 1 : 0) + '"></i>' +
      NAV.map(([k, l, ic], i) => '<a class="nav" href="#/' + k + '"' + (route === k ? ' aria-current="page"' : "") + ">" + icon(ic) + l + '<span class="kbd k">' + (i + 1) + "</span></a>").join("") + "</div>" +
      '<div class="foot">' + conn() + '<button class="nav" data-act="palette">' + icon("search") + 'Search<span class="spacer"></span><span class="kbd">⌘K</span></button></div></nav>';
    const tabs = '<nav class="tabs" aria-label="CreatorCut OS">' + NAV.map(([k, l, ic]) => '<a class="tab" href="#/' + k + '"' + (route === k ? ' aria-current="page"' : "") + ">" + icon(ic) + l + "</a>").join("") + "</nav>";
    return '<div class="app">' + side + '<div><header class="top">' + brand() + '<span class="spacer"></span></header>' +
      '<main class="main">' + content + '<footer class="studio-report-footer"><button class="link t-small" data-act="openProblemReport">Report a problem</button></footer></main></div></div>' + tabs;
  }

  /* =============================================================== home == */
  // a Mac folder: the back with its tab, the video peeking out, the front panel (Big Sur blue)
  const FOLDER_BACK = '<svg class="fb" viewBox="0 0 200 160" aria-hidden="true"><path d="M14 20c0-9 7-16 16-16h46c6 0 10 2 13 6l9 12h72c9 0 16 7 16 16v10H14z" fill="#3f93e4"/><rect x="8" y="34" width="184" height="122" rx="18" fill="#4fa0ea"/></svg>';
  const FOLDER_FRONT = '<svg class="ff" viewBox="0 0 200 104" preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="ffg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a7d7fb"/><stop offset="1" stop-color="#78baf2"/></linearGradient></defs>' +
    '<rect x="8" y="4" width="184" height="98" rx="18" fill="url(#ffg)"/><rect x="8" y="4" width="184" height="2" fill="#fff" opacity=".55"/><rect x="22" y="86" width="156" height="2" rx="1" fill="#3f93e4" opacity=".22"/><rect x="22" y="92" width="156" height="2" rx="1" fill="#3f93e4" opacity=".15"/></svg>';
  function videoTile(p) {
    const truth=p.engine_status||{};
    const busy=truth.state==='working';
    const poster = (p.versions && p.versions.length && p.versions[p.versions.length - 1].poster) || (p.media || []).filter((m) => m.kind === "raw").map((m) => m.thumb)[0] || p.poster || "";
    const latest = p.versions && p.versions[p.versions.length - 1];
    const vid = latest?.url || p.latest || p.preview;
    const labels={working:'Editing',waiting_chat:truth.queue_position>1?'Next in line':'Ready to start',needs_you:'Your chat needs you →',paused:'Paused',stopped:'Stopped',done:'Saved'};
    const label=p.metadata_issue?'Your files are safe':labels[truth.state]||(p.status==='finished'||latest?'Saved':p.preview?'Ready':'Saved');
    return '<a class="vtile spot mac" href="#/editor/' + encodeURIComponent(p.name) + '" data-key="' + esc(p.name) + '">' + FOLDER_BACK + '<div class="frame">' + (poster ? '<img alt="" loading="lazy" src="' + esc(poster) + '">' : vid ? '<video class="still" muted playsinline preload="metadata" src="' + esc(vid) + '#t=0.5"></video>' : "") +
      (vid ? '<video muted loop playsinline preload="none" data-hover src="' + esc(vid) + '"></video>' : "") + "</div>" + FOLDER_FRONT + (label ? '<span class="badge">' + (busy ? '<i class="dot live"></i>' : "") + label + "</span>" : "") +
      '<div class="meta"><b>' + esc(p.title || p.name) + '</b><span class="t-tiny">' + esc(p.timeline && p.timeline.duration ? A.fmtTime(p.timeline.duration) : "") + "</span></div></a>";
  }
  // Shared with the working Editor: identical operation markup and animation CSS.
  function editorMotionOverlay() {
    return '<div class="ed-operation" aria-hidden="true"><i class="ed-op-beam"></i><span class="ed-fast-selection"></span><span class="ed-trim-handle ed-trim-in"></span><span class="ed-trim-handle ed-trim-out"></span><span class="ed-transition-block">⋈</span><span class="ed-mini-keyframes">◇──◇──◆──◇</span><span class="ed-fast-discard"></span>'+Array.from({length:7},(_,i)=>'<span class="ed-op-pin" style="--n:'+i+';--x:'+(9+i*13)+'%"><i></i></span>').join('')+'<span class="ed-fast-cursor"><svg viewBox="0 0 22 28" width="17" height="22"><path d="M2 2L3 22L8 17L12 26L16 24L12 15L20 14Z" fill="white" stroke="#101a29" stroke-width="1.5" stroke-linejoin="round"/></svg><span class="ed-cursor-actions"><b>Trim</b><b>Cut</b><b>Ripple</b><b>Captions</b><b>Animate</b></span></span><span class="ed-drag-block">◆ Motion</span></div>';
  }
  function miniEditTimeline(compact) {
    const image='kit/studio/app/tour-landscape.jpg';
    const frames=Array.from({length:18},(_,i)=>'<img alt="" loading="lazy" src="'+image+'" style="--clip-i:'+i+';object-position:'+(20+(i%6)*12)+'% center">').join('');
    const bars=(n,seed)=>Array.from({length:n},(_,k)=>'<i style="left:'+((k*97+seed*31)%88)+'%;width:'+(5+((k*53+seed*17)%9))+'%;--d:'+(k*.09).toFixed(2)+'s"></i>').join('');
    const wave=Array.from({length:64},(_,k)=>'<i style="height:'+(18+((k*37)%70))+'%;--d:'+((k*13)%50)/50+'s"></i>').join('');
    return '<div class="homepage-editor-window'+(compact?' compact':'')+'" aria-hidden="true"><div class="ed-tl ed-motion-graphics ed-motion-live homepage-editor-timeline"><div class="ed-activity-caption"><span><i></i> EDITING PREVIEW</span><b>Making every cut count</b></div><div class="ed-ruler">'+Array.from({length:13},()=>'<i><small>·</small></i>').join('')+'</div><div class="ed-row"><span class="t-mono">V1</span><div class="ed-clips">'+frames+'</div></div><div class="ed-row"><span class="t-mono">TXT</span><div class="ed-bars cap">'+bars(9,1)+'</div></div><div class="ed-row"><span class="t-mono">GFX</span><div class="ed-bars gfx">'+bars(4,3)+'</div></div><div class="ed-row ed-extra-track"><span class="t-mono">V2</span><div class="ed-extra-clips">'+Array.from({length:5},(_,i)=>'<span style="--n:'+i+'"><img alt="" loading="lazy" src="'+image+'"><i>◇</i></span>').join('')+'</div></div><div class="ed-row"><span class="t-mono">A1</span><div class="ed-wave">'+wave+'</div></div>'+editorMotionOverlay()+'<i class="ed-head"></i></div></div>';
  }
  function studioTour() {
    const sample='kit/studio/app/tour-woman.jpg';
    const portrait=sample?'<img src="'+esc(sample)+'" loading="lazy" alt="">':'<span class="tour-person">'+icon('video')+'</span>';
    const file=(name,cls)=>'<span class="walk-file '+cls+'">'+icon('film')+'<b>'+name+'</b><i>MP4</i></span>';
    const demos=[
      '<div class="walk-upload"><div class="walk-chrome"><i></i><i></i><i></i><b>STUDIO</b></div><span class="walk-source-folder"></span><div class="walk-drop"><span>'+icon('upload')+'</span><b>Your footage</b><small>Drop your raw clips</small><i class="walk-drop-glow"></i></div>'+file('Raw clip.mov','walk-file-one')+file('B-roll.mp4','walk-file-two')+'<span class="walk-drop-cursor">'+icon('arrow')+'</span><div class="walk-uploaded"><img src="kit/studio/app/tour-landscape.jpg" loading="lazy" alt=""><span><b>Raw clip.mov</b><i></i></span><em>'+icon('check')+'</em></div><span class="walk-complete">Footage added</span></div>',
      '<div class="walk-style"><div class="walk-chrome"><i></i><i></i><i></i><b>INSTAGRAM REFERENCE</b></div><div class="walk-instagram-link">' + icon('link') + '<span>instagram.com/reel/...</span><i></i></div><div class="walk-analysis">'+refMedia({thumb:sample},true)+'<div class="walk-analysis-copy"><b>Scanning Instagram reel</b>'+['Captions','Pacing & cuts','Motion'].map((t,i)=>'<span style="--scan-row:'+i+'"><small>'+t+'</small><i><b></b></i><em>'+icon('check')+'</em></span>').join('')+'</div></div><div class="walk-style-picker">'+['Bold','Clean','Editorial'].map((t,i)=>'<div class="walk-style-option walk-style-option-'+i+'">'+portrait+'<b>Aa</b><span>'+t+'</span><i>'+icon('check')+'</i></div>').join('')+'</div></div>',
      '<div class="tour-editor-mini walk-editor"><span class="walk-editor-label">YOUR EDITOR AT WORK</span>'+miniEditTimeline(true)+'<span class="walk-editing-labels"><b>Cutting silence</b><b>Adding captions</b><b>Building motion</b></span></div>',
      '<div class="walk-feedback"><div class="walk-chrome"><i></i><i></i><i></i><b>EDITOR</b></div><div class="walk-review-top"><div class="walk-review-phone"><img src="kit/studio/app/tour-man.jpg" loading="lazy" alt=""><b>'+icon('play')+'</b><i>'+icon('check')+'</i></div><div class="walk-review-info"><b>Edit feedback</b><span>00:12.40 <i>Frame 373</i></span><div class="walk-mini-film">'+Array.from({length:9},()=>'<img alt="" loading="lazy" src="kit/studio/app/tour-landscape.jpg">').join('')+'<i></i></div></div></div><div class="walk-note-input"><span>Make this cut faster</span><i>'+icon('arrow')+'</i></div><div class="walk-note-row"><b>00:12.40</b><span>Make this cut faster</span><i>'+icon('check')+'</i></div><div class="walk-update"><span>Update video</span><i></i><b>'+icon('download')+' Download video</b></div></div>'
    ];
    if(window.CREATORCUT_CATALOGUE?.launch?.reference_enabled===false)demos[1]='<div class="walk-style"><div class="walk-chrome"><i></i><i></i><i></i><b>YOUR STYLE</b></div><div class="walk-style-picker">'+['Bold','Clean','Editorial'].map((t,i)=>'<div class="walk-style-option walk-style-option-'+i+'">'+portrait+'<b>Aa</b><span>'+t+'</span><i>'+icon('check')+'</i></div>').join('')+'</div><span class="walk-complete">Your look, saved for this video</span></div>';
    const steps=[['Add your raw files and B-rolls','Drop your raw recordings and B-roll clips into Studio.'],['Choose your style','Choose your captions, effects and a saved style.'],['The AI starts making your video','Your AI chat builds your video from your choices.'],['Give feedback & download','Watch the finished video, ask for changes, then download it.']];
    return '<div class="tour-grid">'+steps.map((step,i)=>'<details class="tour-card tour-step-'+i+'"><summary><div class="tour-demo" aria-hidden="true">'+demos[i]+'</div><span class="tour-card-heading"><b>0'+(i+1)+'</b><strong>'+step[0]+'</strong><i>'+icon('chev')+'</i></span></summary><p>'+step[1]+'</p></details>').join('')+'</div>';
  }
  function learningLoop() {
    const l = S().learning_progress || {}, n = Math.max(0, Number(l.completed || 0)), pct = Math.min(n, 10) * 10;
    if(l.unavailable) return '<p class="metadata-issue" role="status">Learning progress is temporarily unavailable. Your editing preferences have not been reset.</p>';
    return '<section class="learning-loop" data-static="learning-' + n + '" aria-label="Your AI editor learning loop: ' + pct + '% of your first ten completed edits">' +
      '<div class="learning-orbit" style="--progress:' + pct + '"><svg viewBox="0 0 120 120" role="img" aria-label="' + pct + '%"><circle class="loop-track" cx="60" cy="60" r="50"/><circle class="loop-arc" cx="60" cy="60" r="50" pathLength="100"/></svg><span class="loop-number">' + pct + '<small>%</small></span><span class="loop-rings" aria-hidden="true"><i></i><i></i><i></i></span><span class="loop-satellites" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></span><span class="loop-ticks" aria-hidden="true"><i style="--tick:0"></i><i style="--tick:1"></i><i style="--tick:2"></i><i style="--tick:3"></i><i style="--tick:4"></i><i style="--tick:5"></i><i style="--tick:6"></i><i style="--tick:7"></i><i style="--tick:8"></i><i style="--tick:9"></i><i style="--tick:10"></i><i style="--tick:11"></i><i style="--tick:12"></i><i style="--tick:13"></i><i style="--tick:14"></i><i style="--tick:15"></i><i style="--tick:16"></i><i style="--tick:17"></i><i style="--tick:18"></i><i style="--tick:19"></i><i style="--tick:20"></i><i style="--tick:21"></i><i style="--tick:22"></i><i style="--tick:23"></i><i style="--tick:24"></i><i style="--tick:25"></i><i style="--tick:26"></i><i style="--tick:27"></i><i style="--tick:28"></i><i style="--tick:29"></i><i style="--tick:30"></i><i style="--tick:31"></i><i style="--tick:32"></i><i style="--tick:33"></i><i style="--tick:34"></i><i style="--tick:35"></i><i style="--tick:36"></i><i style="--tick:37"></i><i style="--tick:38"></i><i style="--tick:39"></i></span></div>' +
      '<div class="loop-copy"><span class="t-mono">PERSONAL INTELLIGENCE</span><h2>Your AI editor</h2><p>' + (n >= 10 ? 'Your style keeps evolving. Keep creating.' : 'Keep editing videos to help your AI editor learn your style.') + '</p><span class="loop-detail">' + Math.min(n,10) + ' / 10 completed videos</span><div class="loop-flow" aria-label="Feedback informs preferences for your next edit"><span>Feedback</span><i>→</i><span>Your style</span><i>→</i><span>Next edit</span></div><span class="loop-note">Preferences are saved privately. Learning continues beyond 10 videos.</span></div></section>';
  }
  function home() {
    const name = firstName();
    const words = ("Welcome" + (name ? ", " + name : "") + ".").split(" ");
    const vids = (S().projects || []).filter((p) => !p.parent && (p.status !== "draft" || p.engine_status?.request_id || p.editor_job?.id));
    const ups = (S().updates || []).slice(0, 5);
    const ps = presets();
    const conn = edLabel().toUpperCase();
    let n = 0;
    const idx = () => '<span class="t-mono">' + String(++n).padStart(2, "0") + "</span>";
    return '<div class="page home page-in">' +
      '<div class="welcome2" data-static="welcome-' + esc(name) + "-" + vids.length + "-" + ps.length + '">' +
      '<span class="kicker t-mono"><i class="dot' + (ed().connected ? " ok" : "") + '"></i>' + conn + " · " + vids.length + " VIDEO" + (vids.length === 1 ? "" : "S") + " · " + ps.length + " PRESET" + (ps.length === 1 ? "" : "S") + "</span>" +
      '<h1 class="hello">Welcome' + (name ? ', <span class="nm">' + esc(name) + ".</span>" : ".") + "</h1>" +
      '<p class="sub">Edit your next <span class="rot" data-words="video,reel,short,story"><span>video</span></span> with your AI editor.</p></div>' +
      '<button class="launch spot launch-timeline" data-act="startVideo"><div><span class="launch-kicker">Make your next video</span><h2>Raw file to edited video.</h2><p>Drop your raw file. Get fully edited videos by AI</p><span class="go">Open Studio' + icon("arrow") + '</span></div><div class="launch-art" aria-hidden="true">'+miniEditTimeline(false)+'</div></button>' +
      '<section class="section studio-tour" aria-label="How it works"><div class="section-head"><h2 class="t-3 idx">' + idx() + 'How it works</h2><span class="t-tiny">Four simple steps</span></div>' + studioTour() + '</section>' + learningLoop() +
      (vids.length ? '<section class="section"><div class="section-head"><h2 class="t-3 idx">' + idx() + 'Recent</h2><a class="link t-small" href="#/videos">All videos</a></div><div class="row-scroll">' + vids.slice(0, 10).map(videoTile).join("") + "</div></section>" : "") +
      '<section class="section"><div class="section-head"><h2 class="t-3 idx">' + idx() + 'Presets</h2></div>' +
      '<div class="plist">' + ps.map((s) => presetTile(s)).join("") + newPresetTile() + "</div></section>" +
      (ups.length ? '<section class="section"><h2 class="t-3 idx">' + idx() + 'Activity</h2><div class="feed2">' + ups.map((u) => { const pj = u.project && projectById(u.project); const ps_ = u.style && styleById(u.style); const th = pj ? ((pj.versions || []).slice(-1)[0] || {}).poster || pj.poster || "" : ps_ && ps_.frames && ps_.frames[0] || ""; return '<a class="upd" data-key="u' + u.id + '" ' + (pj ? 'href="#/editor/' + encodeURIComponent(u.project) + '"' : "") + ">" + (th ? '<img class="uth" alt="" src="' + esc(th) + '">' : '<i class="pip"></i>') + '<span class="txt">' + (pj ? "<b>" + esc(pj.title) + "</b> " : "") + esc(u.text) + '</span><span class="t-mono when">' + ago(u.time) + "</span></a>"; }).join("") + "</div></section>" : "") + "</div>";
  }

  function updateBar() {
    const u = S().update || {};
    if(u.restart_required)return '<section class="upbar update-inline" role="status">Update installed. Close and reopen CreatorCut to finish. Your videos and presets are saved.</section>';
    if(u.status==='waiting_for_edit')return '<section class="upbar update-inline" role="status"><span class="update-symbol"><i class="spinner"></i></span>Your update is saved. It will install after your current work finishes.</section>';
    if (A.updating || ['downloading','installing'].includes(u.status)) {
      const measured=typeof u.pct==='number'&&Number.isFinite(u.pct);
      return '<section class="upbar busy update-inline" role="status"><span class="update-symbol"><i class="spinner"></i></span><button class="btn btn-soft btn-sm" disabled>Installing update</button><span class="update-inline-note">'+esc(A.updateReconnecting?'Reconnecting to finish your update…':u.step||'Preparing your update')+'</span><progress max="1"'+(measured?' value="'+Math.max(0,Math.min(1,u.pct))+'"':'')+' aria-label="Update progress"></progress></section>';
    }
    if (['failed','interrupted'].includes(u.status)) return '<section class="upbar update-inline" role="status"><span class="update-symbol">'+icon('redo')+'</span><button class="btn btn-soft btn-sm" data-act="installUpdate">Retry update</button><span class="update-inline-note" title="'+esc(u.error||'Your current app and files are preserved.')+'">Your files are safe · Try the update again</span></section>';
    if(u.status==='done'&&!u.available)return '<section class="upbar current update-inline" role="status">Updated. For the newest version, start a new chat in your CreatorCut folder and type: open Studio.</section>';
    if (!u.available) {
      if (A.route().name !== 'home') return '';
      const checked = !!(u.configured && u.checked && !u.error);
      const title = checked ? 'Latest update installed' : u.error ? 'Couldn’t check for updates' : u.configured === false ? 'Updates are not connected yet' : 'Checking for updates…';
      const sub = checked ? 'You have the latest version (' + (S().version || u.current || '') + ')' : u.error ? 'Checking again automatically' : 'Checking for a new version';
      return '<section class="upbar current update-inline" aria-label="App updates"><span class="update-symbol">' + icon(checked ? 'check' : 'redo') + '</span><button class="btn btn-soft btn-sm update-current" '+(u.error?'data-act="checkUpdate"':'disabled')+'>' + esc(u.error?'Check for update':title) + '</button><span class="update-inline-note" data-version="v'+esc(S().version||u.current||'')+'" title="'+esc(sub)+'">' + esc(sub) + '</span></section>';
    }
    const day=new Date().toDateString();
    try { if(localStorage.getItem('creatorcut-update-dismissed')===u.latest+':'+day)return ''; } catch (_) {}
    if(A.ui?.updateDismissed===u.latest+':'+day)return '';
    return '<section class="upbar available update-inline" role="status"><span class="update-symbol">' + icon('download') + '</span><button class="btn btn-ink btn-sm update-install" data-act="installUpdate" title="Update to '+esc(u.latest)+'">Update</button><span class="update-inline-note">A new version with fixes is ready. About 2 min. Your videos and settings stay safe.</span><button class="link t-small" data-act="dismissUpdate">Later today</button></section>';

  }

  function flip(frames, cls) {
    return frames && frames.length ? '<div class="flip' + (cls ? " " + cls : "") + '" data-flip>' + frames.map((f, i) => '<img alt="" loading="lazy" src="' + esc(f) + '"' + (i ? "" : ' class="on"') + ">").join("") + "</div>" : "";
  }
  function presetMeta(s) {
    if(s.recipe_kind === 'snapshot') return 'Saved video style';
    if(s.recipe_kind === 'brief') return 'Saved instructions & references';
    if(s.recipe_kind === 'reviewed') return 'From your finished edit';
    const rd = s.readout || [];
    const get = (l) => (rd.find((r) => r.label === l) || {}).value;
    return [get("Font"), get("Cuts")].filter(Boolean).join(" · ");
  }
  function presetTile(s, opts) {
    opts = opts || {};
    return '<button class="pmini" data-key="p-' + esc(s.id) + '" data-act="' + (opts.act || "openStyle") + '" data-id="' + esc(s.id) + '"' + (opts.pressed != null ? ' aria-pressed="' + !!opts.pressed + '"' : "") + ">" +
      '<span class="pm-f">' + flip(s.frames) + '</span><span class="pm-t"><b>' + esc(s.name) + '</b><span class="t-mono">' + esc(presetMeta(s).toUpperCase()) + "</span></span>" + icon("arrow") + "</button>";
  }
  // which saved preset a video copies (shown on the video), or its own reference
  function mediaTitle(value) { return String(value || "").replace(/\.(?:mp4|mov|m4v|webm|mkv|avi|mp3|wav|m4a|aac|flac|png|jpe?g|webp)(?:[?#].*)?$/i, "").trim() || "Video"; }
  function presetBadge(p) {
    const s = styleById(p.settings && p.settings.style);
    const ref = (p.refs || [])[0];
    if (s && s.yours !== false) return '<button class="ox-preset" data-act="openStyle" data-id="' + esc(s.id) + '">' + (s.frames && s.frames[0] ? '<img alt="" src="' + esc(s.frames[0]) + '">' : "") + '<span><span class="t-mono">PRESET</span><b>' + esc(s.name) + "</b></span>" + icon("arrow") + "</button>";
    if (ref) return '<div class="ox-preset static">' + (ref.thumb ? '<img alt="" src="' + esc(ref.thumb) + '">' : "") + '<span><span class="t-mono">YOUR REFERENCE</span><b>' + esc(mediaTitle(ref.title || ref.name || "Reference video")) + "</b></span></div>";
    return "";
  }
  // the learning loop, visible: what this preset learned from the creator's feedback
  function newPresetTile() {
    return '<button class="pmini new" data-act="startVideo"><span class="pm-f">' + icon("plus") + '</span><span class="pm-t"><b>New preset</b><span class="t-mono">FROM A REFERENCE VIDEO</span></span></button>';
  }

  /* ============================================================ studio == */
  /* One page per video: make it (footage, reference, brief) → it's being made → watch, chat, save. */
  const STAGES = [["prepare", "Reading your footage", "Footage read"], ["transcribe", "Listening to every word", "Every word transcribed"],
    ["plan", "Finding bad takes", "Bad takes found"], ["cut", "Deleting bad takes and cutting silences", "Bad takes deleted · silences cut out"],
    ["beats", "Adding captions and animations", "Captions and animations added"], ["broll", "Placing B-roll and music", "B-roll and music placed"],
    ["preview", "Rendering your video", "Rendered"]];
  function stageIndex(p) {
    const act = p.activity || (S().activity?.project === p.name ? S().activity : {});
    const order = STAGES.map((s) => s[0]);
    let cur = act.running && act.project === p.name ? order.indexOf(act.cmd === "new" ? "prepare" : act.cmd === "check" ? "broll" : act.cmd === "media" || act.cmd === "reference" ? "prepare" : act.cmd) : -1;
    const byStatus = { queued: 0, new: 1, transcribed: 2, planned: 3, cut: 4, previewed: 7 }[p.status];
    if (cur < 0 && byStatus != null) cur = byStatus;
    return Math.max(0, cur);
  }
  const rawFrames = (p) => { const raw = (p.media || []).filter((m) => m.kind === "raw"); const strip = raw.flatMap((m) => m.strip || []); return strip.length ? strip : raw.map((m) => m.thumb).filter(Boolean); };

  /* ---- 01 footage */
  function mediaZones(p) {
    const zones = [["raw", "footage", "Raw footage", "video/*,.mov,.mp4"], ["broll", "broll", "B-roll and photos", "video/*,image/*"]];
    const ups = Object.values(A.ui.uploads).filter((u) => u.project === p.name);
    return '<div class="sx-zones">' + zones.map(([kind, want, title, accept]) => {
      const items = (p.media || []).filter((m) => m.kind === kind || (kind === "broll" && m.kind === "image"));
      const up = ups.filter((u) => u.kind === kind);
      const empty = !items.length && !up.length;
      return '<section class="sx-zone' + (kind === "raw" ? " primary" : "") + (empty ? " empty" : "") + '" data-drop="' + want + '" data-project="' + esc(p.name) + '">' +
        '<label class="sx-zone-add">' + icon(kind === "music" ? "music" : kind === "raw" ? "upload" : "film") + "<b>" + title + "</b>" +
        '<input type="file" multiple accept="' + accept + '" data-change="binFiles" data-kind="' + want + '" data-project="' + esc(p.name) + '"></label>' +
        (empty ? "" : '<div class="sx-items">' + items.map((m) => '<div class="zitem" data-key="' + m.id + '">' + (m.thumb ? '<img alt="" src="' + esc(m.thumb) + '">' : '<span class="aud">' + icon(m.kind === "music" ? "music" : "film") + '<i class="t-tiny">' + esc(mediaTitle(m.name)) + "</i></span>") +
          (m.duration ? '<span class="d">' + A.fmtTime(m.duration) + "</span>" : "") + '<button class="x" data-act="removeMedia" data-id="' + m.id + '" aria-label="Remove">' + icon("x") + "</button></div>").join("") +
          up.map((u) => '<div class="zitem up' + (u.stalled || u.state === "error" ? " stuck" : "") + '" title="' + esc(u.stalled ? "Stuck. Remove it and drop it again." : u.progress >= 1 ? "Processing…" : u.name || "") + '">' +
            (u.state==='error'?'<button class="btn btn-line btn-sm" data-act="retryUpload" data-id="'+u.id+'">Retry</button>':'<span class="spinner"></span>')+'<i class="pbar" style="width:' + Math.round(u.progress * 100) + '%"></i>' +
            '<button class="x" data-act="cancelUpload" data-id="' + u.id + '" aria-label="Remove upload">' + icon("x") + "</button></div>").join("") + "</div>") + "</section>";
    }).join("") + "</div>";
  }

  /* ---- 02 reference: live scan, then what was really measured */
  const TRACKS = [["Fetching the video", 0, 0.3, "url"], ["Speech, pace and cuts", 0.3, 0.48], ["Colour and sound", 0.48, 0.6],
    ["Every word on screen", 0.6, 0.78], ["Text styles and motion", 0.78, 0.89], ["Exact fonts", 0.89, 0.96], ["Style kit", 0.96, 1]];
  function refMedia(r, busy) {
    const frames = r.frames || [];
    const inner = r.video ? '<video autoplay muted loop playsinline preload="auto" src="' + esc(r.video) + '"></video>'
      : frames.length ? '<div class="flip" data-flip>' + frames.map((f, i) => '<img alt="" src="' + esc(f) + '"' + (i ? "" : ' class="on"') + ">").join("") + "</div>"
      : r.thumb ? '<img alt="" src="' + esc(r.thumb) + '">' : '<span class="rx-wait"></span>';
    return '<div class="rx-media' + (busy ? " scanning" : "") + '">' + inner + (busy ? '<i class="rx-line"></i><i class="rx-grid"></i><span class="rx-c tl"></span><span class="rx-c tr"></span><span class="rx-c bl"></span><span class="rx-c br"></span>' : "") + "</div>";
  }
  function jobEstimate(seconds) {
    return Number.isFinite(seconds) && seconds >= 0 ? "About " + Math.max(1, Math.ceil(seconds / 60)) + " min left in this step" : "Estimating…";
  }
  function refScan(r) {
    const done = r.status === "done";
    const p = done ? 1 : r.status === "queued" ? 0 : r.progress || 0;
    const tracks = TRACKS.filter((t) => t[3] !== "url" || r.kind === "url");
    return '<div class="rx-scan"><div class="rx-top"><span class="t-mono">' + (done ? "Reference scanned ✓" : "SCANNING REFERENCE") + '</span><b class="t-num" data-tween="' + Math.round(p * 100) + '">' + Math.round(p * 100) + '</b><small>%</small></div>' +
      '<div class="rx-total"><i style="width:' + Math.max(2, p * 100) + '%"></i></div>' +
      '<div class="rx-tracks">' + tracks.map(([l, a, b]) => { const k = A.clamp((p - a) / (b - a), 0, 1); return '<div class="rx-t' + (k >= 1 ? " done" : k > 0 ? " now" : "") + '"><span>' + l + '</span><i><b style="width:' + Math.round(k * 100) + '%"></b></i><em>' + (k >= 1 ? icon("check") : k > 0 ? Math.round(k * 100) + "%" : "") + "</em></div>"; }).join("") + "</div>" +
      (!done?'<p class="t-small">'+jobEstimate(r.eta)+'</p>':'') + (done ? "" : '<div class="rx-msg t-mono" aria-live="polite"><span data-key="m-' + esc(r.message) + '" data-type="' + esc(r.message || "Starting…") + '"></span></div>') + "</div>";
  }
  function readoutRows(rows) {
    const groups = [];
    rows.forEach((row) => { let g = groups.find((x) => x[0] === row.group); if (!g) groups.push(g = [row.group, []]); g[1].push(row); });
    return groups.map(([g, rs], gi) => '<div class="ra-g" style="--gi:' + gi + '"><span class="t-mono ra-gh">' + esc(g.toUpperCase()) + "</span>" + rs.map((row, i) => {
      if (row.font && row.font_url) A.ensureFont(row.font, [row.font_url]);
      const val = row.font ? '<span class="ra-font" style="font-family:\'aie-' + esc(row.font) + '\',var(--text)">' + esc(row.value) + "</span>" : esc(row.value);
      return '<div class="ra-row" style="--i:' + i + '"><span class="k">' + esc(row.label) + '</span><span class="v">' + val +
        (row.swatches ? '<span class="sw">' + row.swatches.map((c) => '<i style="background:' + esc(c) + '"></i>').join("") + "</span>" : "") + "</span>" +
        (row.bar != null ? '<i class="ra-bar"><b style="--w:' + Math.round(row.bar * 100) + '%"></b></i>' : "") + "</div>";
    }).join("") + "</div>").join("");
  }
  /* the measurements, folded away until asked for */
  function details(key, rows) {
    const open = !!(A.ui.openDetails || {})[key];
    return '<div class="ra-more"><button class="link t-small" data-act="toggleDetails" data-k="' + esc(key) + '" aria-expanded="' + open + '">' + (open ? "Hide details" : "Show details") + icon("arrow", 'style="transform:rotate(' + (open ? -90 : 90) + 'deg)"') + "</button>" +
      (open ? '<div class="ra-rows">' + readoutRows(rows) + "</div>" : "") + "</div>";
  }
  function presetNameFrom(r) {
    const t = (r.name || "").replace(/^Video by\s+/i, "").replace(/\.(mp4|mov|m4v|webm)$/i, "").trim();
    return t.slice(0, 32);
  }
  function referenceUpload(r, p) {
    const instruction = r.cover_only ? 'Only the thumbnail could be read. Please download the reference and upload it as a video file to scan its editing, animation and pacing.' : r.kind === 'url' ? 'Please download the reference and upload it here as a video file.' : 'Please upload the original video file again.';
    const upload = p ? 'data-change="refFile" data-project="' + esc(p.name) + '"' : 'data-change="files" data-kind="reference"';
    return '<div class="rx-err" role="status"><b>Reference couldn’t be scanned.</b><span class="t-small">' + instruction + '</span><label class="sx-file">' + icon('upload') + 'Upload reference video<input type="file" accept="video/*,.mov,.mp4" ' + upload + '></label><button class="btn btn-line btn-sm" data-act="retryRef" data-id="' + esc(r.id) + '">' + (r.kind === 'url' ? 'Try link again' : 'Try again') + '</button></div>';
  }
  function refCard(r, p) {
    const busy = !["done", "error"].includes(r.status);
    const saved = r.used_by && styleById(r.used_by);
    const naming = A.ui.namingRef === r.id;
    const job = A.ui.savingRef && A.ui.savingRef.ref === r.id ? (S().jobs || []).find((j) => j.id === A.ui.savingRef.job) : null;
    const savingNow = job && ["queued", "running", "waiting"].includes(job.state);
    const head = '<div class="rx-head"><span class="rx-src">' + (r.kind === "url" ? icon("link") : icon("film")) + "<b>" + esc(mediaTitle(r.name || r.host || "Reference")) + "</b>" + (r.host ? '<span class="t-mono">' + esc(r.host.toUpperCase()) + "</span>" : "") + '</span><button class="icon-btn" data-act="' + (p ? "removeVideoRef" : "removeRef") + '" data-id="' + esc(r.id) + '" aria-label="Remove reference">' + icon("x") + "</button></div>";
    let side;
    if (r.status === "saved") side = '<p class="t-small" role="status">Reference saved. Your chat scans it before styling.</p>';
    else if (r.status === "error" || (!busy && (r.cover_only || r.study_error))) side = referenceUpload(r, p);
    else if (busy) side = refScan(r) + (Number(r.updated||r.created||0)>0 && Date.now()/1000-Number(r.updated||r.created)>120 ? '<div class="rx-err" role="status"><span>This scan has not reported progress recently. Check it or upload the video file.</span><button class="btn btn-line btn-sm" data-act="retryRef" data-id="'+esc(r.id)+'">Check scan</button></div>' : '');
    else side = '<div class="ra done">' + refScan(r) + (r.saved_style_name?'<p class="t-small">Reference scanned ✓ — saved as '+esc(r.saved_style_name)+'</p>':'') +
      ((r.readout || []).length ? details("rd-" + r.id, r.readout) : r.cover_only ? '<p class="t-small">Only the cover could be read from this link. Add the video file to study its editing.</p>' : '') +
      '<div class="ra-save">' + (saved ? '<span class="chip on">' + icon("check") + "Saved as preset · " + esc(saved.name) + "</span>"
        : savingNow ? '<span class="chip"><span class="spinner"></span>Saving preset</span>'
        : naming ? '<div class="namebar"><input class="input" value="' + esc(A.ui.refName != null ? A.ui.refName : presetNameFrom(r)) + '" placeholder="Preset name" data-input="refName" data-enter="saveRefPreset" data-id="' + esc(r.id) + '" data-project="' + esc(p ? p.name : "") + '" data-free aria-label="Preset name"><button class="btn btn-ink btn-sm" data-act="saveRefPreset" data-id="' + esc(r.id) + '" data-project="' + esc(p ? p.name : "") + '">Save</button><button class="btn btn-text btn-sm" data-act="cancelRefName">Cancel</button></div>'
        : (r.readout || []).length ? '<button class="btn btn-line btn-sm" data-act="nameRefPreset" data-id="' + esc(r.id) + '">' + icon("plus") + "Save this style as a preset</button>" : "") + "</div></div>";
    return '<article class="rx" data-key="rx-' + esc(r.id) + '">' + head + '<div class="rx-body">' + refMedia(r, busy) + side + "</div></article>";
  }
  function refSection(p) {
    const refs = p.refs || [];
    const ups = Object.values(A.ui.uploads).filter((u) => u.project === p.name && u.kind === "reference");
    const ps = presets();
    const chosen = styleById(p.settings.style);
    return '<div class="sx-ref">' +
      (window.CREATORCUT_CATALOGUE?.launch?.reference_enabled!==false ? '<div class="urlbar big">' + icon("link") + '<input type="url" inputmode="url" placeholder="Add reference link from TikTok, Instagram or YouTube" aria-label="Reference link" data-enter="addRefLink" data-free autocomplete="off" spellcheck="false"><button class="btn btn-ink btn-sm" data-act="addRefLinkBtn">Add</button></div>' +
      '<label class="sx-file" data-drop="vref" data-project="' + esc(p.name) + '">' + icon("upload") + "Add reference video file" + '<input type="file" accept="video/*,.mov,.mp4" data-change="refFile" data-project="' + esc(p.name) + '"></label>' : '') +
      ups.map((u) => '<div class="rx up"><div class="rx-head"><span class="rx-src">' + icon("film") + "<b>" + esc(mediaTitle(u.name || "Uploading")) + '</b></span><span class="t-mono">' + (u.stalled ? "STUCK" : u.progress >= 1 ? "PROCESSING" : Math.round(u.progress * 100) + "%") + '</span><button class="icon-btn" data-act="cancelUpload" data-id="' + u.id + '" aria-label="Remove upload">' + icon("x") + '</button></div><div class="rx-total"><i style="width:' + Math.round(u.progress * 100) + '%"></i></div></div>').join("") +
      refs.map((r) => refCard(r, p)).join("") +
      (ps.length ? '<label class="saved-preset-select">Use saved preset<select data-change="choosePreset" aria-label="Use saved preset"><option value="creatorcut-signature">Choose a preset…</option>' + ps.map(s=>'<option value="'+esc(s.id)+'"'+(p.settings.style===s.id?' selected':'')+'>'+esc(s.name)+'</option>').join('')+'</select></label>' : '') +
      (chosen && chosen.yours ? '<span class="t-tiny">Uses your saved preset “' + esc(chosen.name) + "”.</span>" : "") + "</div>";
  }
  const BRIEF_EXAMPLE = "Keep my best takes, remove repeated starts and shorten long pauses. Keep the pace natural.\nFollow my chosen style or reference. If captions are on, keep them clear of my face and highlight the key words.\nUse any B-roll I uploaded when I mention the product. Use my selected effects sparingly, without overcrowding the video.\nIf music is on, keep it quiet under my voice. Finish on my spoken call to action.\n\nSpecific moments: ‘At 0:12, show the product close-up.’ ‘When I say three tips, reveal them one by one.’\n\nChange these examples to match your video. Your choices above still apply.";
  function studioDraft(p) {
    const hasFootage = (p.media || []).some((m) => m.kind === "raw");
    const refs = p.refs || [];
    const analysing = refs.some((r) => !["saved", "done", "error"].includes(r.status));
    const uploading = Object.values(A.ui.uploads).some((u) => u.project === p.name&&u.state==='uploading');
    const failedUpload=Object.values(A.ui.uploads).some(u=>u.project===p.name&&u.state==='error');
    const named = !!(p.title && p.title !== "Untitled video");
    const updating = ['downloading','installing','waiting_for_edit'].includes((S().update || {}).status);
    const lowSpace=typeof S().storage?.free_bytes==='number'&&S().storage.free_bytes<2500000000;
    const preparingTools=['checking','repair'].includes(S().readiness?.state);
    const why = A.ui.savingAdjust?.[p.name] ? 'Saving your adjustments…' : A.ui.savingMusic?.[p.name] ? "Saving your music choice…" : preparingTools ? 'Finishing your editing tools… Your choices are saved.' : lowSpace ? 'Free at least 2.5 GB before editing. Your footage is saved.' : A.ui.savingLooks?.[p.name] ? "Saving your colour choice…" : A.ui.savingChoicesByProject?.[p.name] ? "Saving your look…" : !hasFootage ? "Add your raw footage first." : failedUpload ? "Retry or remove the interrupted upload." : uploading ? "Waiting for uploads." : updating ? "CreatorCut is updating. Your instructions are saved." : "";
    let start = (A.ui.editStarts || {})[p.name];
    const note = chatHost()==='Codex' ? 'Press Make, then type continue in your CreatorCut chat.' : 'Your Claude chat starts your edit automatically.';
    const step = (n, title, sub, body, on) => '<section class="sx-step' + (on ? " on" : "") + '"><div class="sx-n t-mono">' + n + '</div><div class="sx-c"><h2>' + title + "</h2>" + (sub ? '<p class="t-small">' + sub + "</p>" : "") + body + "</div></section>";
    return '<div class="sx page-in">' +
      '<header class="sx-head">'+chatConnection()+'<div class="studio-eyebrow"><span class="studio-signal"></span>CREATORCUT · STUDIO</div><a class="link t-small" href="#/videos">' + icon("back") + 'My videos</a><h1 class="t-1">Make something great.</h1><p class="studio-intro">A few simple choices. An edit that feels like you.</p></header>' +
      step("01", "Name your video", "",
        '<label class="sx-name' + (named ? " done" : "") + '"><span class="name-glyph" aria-hidden="true">' + icon('film') + '</span><input value="' + esc(named ? p.title : "") + '" placeholder="Give your next video a name…" maxlength="60" ' +
        'data-change="renameVideo" data-enter="renameVideo" data-free aria-label="Name your video"><span class="name-signal" aria-hidden="true"><i></i><i></i><i></i></span>' + (named ? '<span class="ok">' + icon("check") + "</span>" : "") + "</label>", true) +
      step("02", "Add your footage", "Start with your original clips. Add anything else below.", mediaZones(p), true) +
      ((window.CREATORCUT_CATALOGUE?.launch?.reference_enabled!==false || refs.length || presets().length) ? step("03", window.CREATORCUT_CATALOGUE?.launch?.reference_enabled===false ? "Your saved style" : "Add your references", window.CREATORCUT_CATALOGUE?.launch?.reference_enabled===false ? "Use a style you saved before." : "Show your AI the editing you love. Add a link or video file.", refSection(p), hasFootage || refs.length) : '') +
      step("04", "Choose your look", "Make it yours. Choose a style, captions and effects.", window.CreatorCutCreative.picker(p), hasFootage) +
      (window.CreatorCutMusic?.card(p)||'') +
      step("05", "Editing instructions", "Add a quick note. Mention a moment if it matters.",
        '<div class="brief-box"><label class="t-small" for="editing-brief">Your editing instructions <span class="t-tiny">(optional)</span></label>' +
        '<textarea id="editing-brief" rows="6" maxlength="20000" data-input="briefDraft" data-change="saveBrief" data-free aria-label="Detailed editing instructions" placeholder="' + esc(BRIEF_EXAMPLE) + '">' +
        esc(Object.prototype.hasOwnProperty.call(A.ui.briefDrafts || {}, p.name) ? A.ui.briefDrafts[p.name] : (p.brief || {}).prompt || '') + '</textarea>' +
        '<div class="brief-foot"><button class="link t-small" data-act="useBriefExample">Use and customize this example</button><span class="t-tiny" data-brief-status>' + esc((A.ui.briefStatus || {})[p.name] || 'Saved before the editor starts.') + '</span></div></div>', true) +
      '<button class="btn btn-line btn-sm" data-act="sheet" data-sheet="adjust">Adjust</button>'+savePresetCard(p, true) + '<div class="sx-go2">' + (why ? '<p class="t-small">' + why + "</p>" : "") +
        '<button class="make-btn' + (A.ui.savingMake ? " launch" : "") + '" data-act="makeNativeVideo" ' + (why || A.ui.savingMake || ['working','waiting_for','needs_you','waiting_chat'].includes(p.engine_status?.state) ? "disabled" : "") + '>' +
        '<span class="mb-glow"></span><span class="mb-go" aria-hidden="true">' + icon("arrow") + '</span><span class="mb-ring" aria-hidden="true"></span><span class="mb-label">' + (A.ui.savingMake ? 'Sending your request' : 'Make my video') + '</span></button>' +
        (note ? '<span class="t-tiny">' + note + "</span>" : "") +
        (start && start.error ? '<div class="step-recovery" role="alert"><b>Your project is saved.</b><p>' + esc(start.error) + '</p><span class="t-tiny">Your footage and instructions are saved.</span> '+problemLink(p)+'</div>' : '') +
      '<p class="t-small">After your video is ready, use its timeline to request changes. <a href="#/editor/animation-preview">Preview editing animation</a></p>' + "</div></div>";
  }

  /* ---- being made */
  function studioWorking(p) {
    const idx = Math.min(6,Math.floor(Number(p.engine_status?.overall_percent||0)/15));
    const raw = (p.media || []).filter((m) => m.kind === "raw");
    const frames = rawFrames(p);
    const hero = p.poster || (raw[0] && (raw[0].hero || raw[0].thumb)) || frames[0] || "";
    const rawFrame = !hero && raw[0] && raw[0].url ? '<video class="ed-frame" muted playsinline preload="auto" src="' + esc(raw[0].url + '#t=0.001') + '" aria-label="Your footage"></video>' : '';
    const land = raw[0] && raw[0].w && raw[0].h && raw[0].w > raw[0].h;
    const truth=p.engine_status||{},inProgress=['working','waiting_for','waiting_resources'].includes(truth.state),motionText=p.animation_preview_only?'Previewing the editing animation':(truth.step_label||'Editing your video').replace(/^(?:Waiting for\s+)+/i,'');
    const total=Number(truth.overall_percent||0),nowText=motionText,noEditor=!inProgress;
    const managedActive=inProgress,managed=managedActive?{state:'editing'}:null;
    const nativeStage=false,awaitingChat=false,waitingResources=false,health={},nativeLabel='Editing';
    const strip=frames.length?frames:hero?[hero]:[];
    const cutsOn=total>=20,capsOn=total>=40,gfxOn=total>=55;
    const motionPhase=/render|encod|export|compos/i.test(motionText)?'render':/caption|typograph|subtitle|transcrib/i.test(motionText)?'caption':/graphic|animat|motion|design|build/i.test(motionText)?'graphics':/cut|silence|take|trim/i.test(motionText)?'cuts':'scan';
    const pastePreview=false;
    const motionRunning=!!p.animation_preview_only||inProgress;
    const motionClasses=' ed-motion-'+motionPhase+(motionRunning?' ed-motion-live':' ed-motion-paused');
    const motionOverlay=editorMotionOverlay();

    const timelineSources=strip.length?Array.from({length:Math.max(18,Math.min(24,strip.length))},(_,i)=>strip[Math.min(strip.length-1,Math.floor(i*strip.length/Math.max(18,Math.min(24,strip.length))))]):[];
    const tlFrames = timelineSources.map((f,i)=>'<img alt="" style="--clip-i:'+i+'" src="'+esc(f)+'">').join('');

    const bars = (n, seed, on) => Array.from({ length: n }, (_, k) => { const l = (k * 97 + seed * 31) % 88, w = 5 + ((k * 53 + seed * 17) % 9); return '<i style="left:' + l + "%;width:" + w + "%;--d:" + (k * 0.09).toFixed(2) + 's"' + (on ? "" : ' class="off"') + "></i>"; }).join("");
    const wave = Array.from({ length: 64 }, (_, k) => '<i style="height:' + (18 + ((k * 37) % 70)) + "%;--d:" + ((k * 13) % 50) / 50 + 's"></i>').join("");
    const elapsedStart=truth.timer_started||truth.started||0;
    const elapsedNow=motionRunning&&elapsedStart?A.fmtTime(truth.elapsed||0):'—';
    const pct=truth.overall_percent;
    const displayPct=inProgress&&Number.isFinite(pct)?Math.round(pct):null;
    const progressCaption='Overall progress';
    const statusTitle=p.animation_preview_only?'Animation preview':({waiting_chat:'Ready to start',waiting_for:'Editing',waiting_resources:'Editing',working:'Editing',needs_you:'Your chat needs you →',done:'Done ✓',stopped:'Stopped'}[truth.state]||'Your edit is saved');
    const stageCopy=p.animation_preview_only?'Visual preview only. No video is being rendered.':motionText;
    const progressDetails=inProgress?'<p class="t-small">'+jobEstimate(truth.eta)+'</p>':'';
    const editor = '<div class="ed" data-key="editor-visualization-'+esc(p.name)+'"><div class="ed-bar"><span class="dots"><b></b><b></b><b></b></span><span class="t-mono">' + esc((p.title || "untitled").toUpperCase()) + '</span><span class="spacer"></span><span class="t-mono rec"><i></i><span title="Elapsed task time"' + (motionRunning && Number.isFinite(elapsedStart) && elapsedStart > 0 ? ' data-elapsed="' + elapsedStart + '"' : '') + '>' + elapsedNow + '</span></span></div>' +
      '<div class="ed-main"><div class="ed-view' + (land ? " land" : "") + '">' + (hero ? '<img class="ed-blur" alt="" src="'+esc(hero)+'"><img class="ed-frame" alt="Video being edited" src="'+esc((window.CreatorCutCreative.video(p)||{}).poster||hero)+'">' : rawFrame) +
        '<i class="ed-scan"></i><span class="ed-c tl"></span><span class="ed-c tr"></span><span class="ed-c bl"></span><span class="ed-c br"></span>' +
        (capsOn ? '<span class="ed-cap"><b></b><b></b></span>' : "") + (gfxOn ? '<span class="ed-card"></span>' : "") +
        '<span class="ed-pct t-mono">' + (pastePreview?'EDIT PREVIEW':managedActive ? (managed.state==='waiting_approval'?'PAUSED':managed.state==='editing'?'EDITING':'STARTING') : awaitingChat ? "FOOTAGE READY" : waitingResources ? "WAITING FOR RESOURCES" : health.state === "error" ? "STOPPED" : health.state === "quiet" ? "CHECK STEP" : noEditor ? "PAUSED" : nativeStage ? nativeLabel.toUpperCase() : "WORKING") + "</span></div>" +
        '<div class="ed-insp"><span class="t-mono k">NOW</span><b data-key="st-' + (noEditor ? "wait" : idx) + '" data-type="' + esc(noEditor ? (nowText || "Your project is saved. Continue in the conversation beside Studio.") : nowText || STAGES[Math.min(idx, STAGES.length - 1)][1]) + '"></b>' +
        '<div class="ed-layers">' + [["Footage", true], ["Cuts", cutsOn], ["Captions", capsOn], ["Graphics", gfxOn], ["Colour + sound", !nativeStage && idx >= 6]].map(([n, on]) => '<span class="' + (on ? "on" : "") + '"><i></i>' + n + "</span>").join("") + "</div></div></div>" +
      '<div class="ed-tl'+motionClasses+'"><div class="ed-activity-caption"><span><i></i> '+(p.animation_preview_only?'ANIMATION PREVIEW':pastePreview?'EDIT PREVIEW · PASTE TO START':managedActive&&managed.state!=='editing'?'PREPARING YOUR EDIT':motionRunning?'EDITING VISUALIZATION':'EDITING TIMELINE')+'</span><b>'+esc(motionText)+'</b></div><div class="ed-ruler">' + Array.from({ length: 13 }, (_, k) => '<i><small>'+(k%3===0?'·':'')+'</small></i>').join("") + "</div>" +
        '<div class="ed-row"><span class="t-mono">V1</span><div class="ed-clips">' + tlFrames + "</div></div>" +
        '<div class="ed-row"><span class="t-mono">TXT</span><div class="ed-bars cap">' + bars(9, 1, capsOn) + "</div></div>" +
        '<div class="ed-row"><span class="t-mono">GFX</span><div class="ed-bars gfx">' + bars(4, 3, gfxOn) + "</div></div>" +
        '<div class="ed-row ed-extra-track"><span class="t-mono">V2</span><div class="ed-extra-clips">'+timelineSources.filter((_,i)=>i%3===0).map((f,i)=>'<span style="--n:'+i+'"><img alt="" src="'+esc(f)+'"><i>◇</i></span>').join('')+'</div></div>' +
        '<div class="ed-row ed-extra-sound"><span class="t-mono">FX</span><div class="ed-bars sound">'+bars(6,5,true)+'</div></div>' +
        '<div class="ed-row"><span class="t-mono">A1</span><div class="ed-wave">' + wave + "</div></div>"+motionOverlay+"<i class=\"ed-head\"></i></div></div>";
    if(!p.animation_preview_only&&!inProgress)return engineStatusCard(p);
    return '<div class="gx page-in' + (awaitingChat ? ' awaiting-chat' : '') + '">' + editor +
      (awaitingChat ? '<div class="editor-handoff" role="status"><b>Your footage is ready to edit.</b><p>Your files and instructions are saved.</p><button class="btn btn-ink" data-act="makeNativeVideo">Start editing</button><span>Your video edit has not started yet.</span></div>' : '') +
      '<section class="gx-info edit-status-card" aria-label="Video editing progress"><div class="edit-status-main"><div class="edit-status-copy"><h2><i class="edit-status-dot'+(motionRunning?' is-live':'')+'" aria-hidden="true"></i>'+statusTitle+'</h2><span class="edit-stage-copy" data-key="stage-'+motionPhase+'">'+esc(stageCopy)+'</span></div>' +
      (displayPct!=null?'<div class="edit-measured'+(motionRunning?' progress-active':'')+'" role="progressbar" aria-label="'+progressCaption+'" aria-valuemin="0" aria-valuemax="100" aria-valuenow="'+displayPct+'"><b>'+displayPct+'<small>%</small></b><span>'+progressCaption+'</span></div>':'')+'</div>'+progressDetails+
      (!p.animation_preview_only&&managedActive&&managed.state!=='waiting_approval'?'<button class="edit-stop" data-act="cancelEditor">Stop edit</button>':'')+'</section></div>'+(p.animation_preview_only?'':revisionGuide(p))+'</div>';
  }
  /* under the video: the editor's notes, and what to say in the chat (the conversation itself is in Claude Code / Codex) */
  // "Save as preset": the look of this video, for every next video (only while it copies a reference, not a saved preset)
  function savePresetCard(p, beforeProduce) {
    const s = styleById(p.settings && p.settings.style);
    if (!beforeProduce && !(p.versions || []).length) return "";
    if(!beforeProduce){
      const state=A.ui.presetFeedback?.[p.name]||{},saving=state.state==='saving';
      return '<div class="savepreset preset-mini" aria-busy="'+saving+'"><b>Save this video style to your presets</b><div class="sp-row"><input placeholder="Preset name" maxlength="40" data-free aria-label="Preset name"'+(saving?' disabled':'')+'><button class="btn btn-ink btn-sm" data-act="saveVideoPreset"'+(saving?' disabled':'')+'>Add</button>'+(s&&s.yours?'<button class="preset-update" data-act="updateVideoPreset" data-id="'+esc(s.id)+'"'+(saving?' disabled':'')+' aria-label="Update preset '+esc(s.name)+'">Update saved preset</button>':'')+'</div><div class="preset-save-status '+esc(state.state||'')+'" role="status">'+(saving?'<i aria-hidden="true"><span></span><span></span><span></span></i>':'')+esc(state.text||'')+'</div></div>';
    }
    return '<div class="savepreset' + (beforeProduce ? ' savepreset-draft' : '') + '"><div class="sp-h"><span class="preset-mark" aria-hidden="true">' + icon('styles') + '</span><div><small>KEEP YOUR RECIPE</small><b>Save your style</b><span>Give it a name. Use it on your next video.</span></div></div>' +
      '<div class="sp-row"><input placeholder="Name it, e.g. Calm & clean" maxlength="40" data-enter="' + (beforeProduce ? "saveBriefPreset" : "saveVideoPreset") + '" data-free aria-label="Preset name">' +
      '<button class="btn btn-ink btn-sm" data-act="' + (beforeProduce ? "saveBriefPreset" : "saveVideoPreset") + '">' + icon("plus") + "Save as preset</button>" + (!beforeProduce && s && s.yours ? '<button class="btn btn-line btn-sm" data-act="updateVideoPreset" data-id="' + esc(s.id) + '">Update “' + esc(s.name) + '”</button>' : "") + "</div></div>";
  }
  const LOOKS = [["reference", "Like the reference", "conic-gradient(#f0a4a4,#9cc4f5,#f6d38a,#f0a4a4)"], ["natural", "Original · no colour grade", "#d9c3b0"],
    ["bright", "Bright & airy", "#f4efe6"], ["warm", "Warm", "#e9a25d"], ["cinematic", "Cinematic", "#3f6f7a"], ["moody", "Moody", "#2b2a33"], ["bw", "Black & white", "linear-gradient(90deg,#111 50%,#eee 50%)"]];

  function revisionGuide(p) {
    return '<div class="native-conversation-note chat-nudge"><span class="chat-nudge-arrow" aria-hidden="true">↖</span><div><b>Want to change something?</b><p>Write in the chat what you’d like to edit or change.</p></div></div>';
  }
  /* ---- ready: watch, ask for changes, save */
  function studioOutput(p) {
    const selectedVideo = window.CreatorCutCreative.video(p);
    const src = (selectedVideo && selectedVideo.url) || p.preview || p.latest;
    const busy = p.busy;
    const overlay = busy ? '<div class="busy"><b>' + esc(busy.label) + '</b><div class="bar' + (busy.progress != null ? "" : " indet") + '"><i style="width:' + Math.round((busy.progress || 0.1) * 100) + '%"></i></div></div>' : "";
    const vers = p.versions || [];
    const poster = (selectedVideo && selectedVideo.poster) || (vers.length && vers[vers.length - 1].poster) || p.poster || "";
    const rendering = (S().jobs || []).find((j) => j.kind === "render" && j.key === p.name && ["queued", "running", "waiting"].includes(j.state));
    const ea = p.activity || (S().activity?.project === p.name ? S().activity : {});
    const epct = rendering && ea.project === p.name && ea.cmd === "render" && ea.percent != null ? Math.round(ea.percent) : Math.round(((rendering || {}).progress || 0) * 100);
    const save = rendering ? '<span class="export-meter"><span class="t-mono">SAVING ' + epct + '%</span><span class="bar"><i style="width:' + Math.max(3, epct) + '%"></i></span></span>'
      : p.status === "finished" ? '<a class="btn btn-soft" href="#/videos">' + icon("check") + "Saved · open My videos</a>" : "";
    return '<div class="ox page-in"><div class="ox-player"><div class="iphone reveal-in"><div class="screen"><i class="island"></i><video id="mon" playsinline preload="metadata"' + (poster ? ' poster="' + esc(poster) + '"' : "") + ' src="' + esc(src) + '"></video>' +
      '<button class="bigplay" data-act="playpause" aria-label="Play">' + icon("play") + "</button>" + overlay + "</div></div>" +
      window.CreatorCutCreative.timeline(p) + "</div>" +
      '<div class="ox-side">' + presetBadge(p) +
      savePresetCard(p) +
      (window.CreatorCutMusic?.credit?.({...((vers[vers.length-1]||{}).music_credit||{}),mode:'library',credit:(vers[vers.length-1]||{}).music_credit?.text})||'') +
      '<a class="btn btn-line editor-download" data-dashboard-download="'+esc(p.name)+'" href="'+esc(A.downloadURL(src,(p.title||p.name)+'.mp4'))+'" download="'+esc((p.title||p.name)+'.mp4')+'">'+icon('download')+'Download MP4</a>' +
      '<div class="ox-save">' + save + "</div></div>" + revisionGuide(p) + "</div>";
  }
  function chatConnection(){return '';}
  function chatHost(){const hosts=typeof window!=='undefined'?window.CREATORCUT_CATALOGUE?.launch?.hosts:null;return S().editor?.provider==='codex'&&(!hosts||hosts.includes('codex'))?'Codex':'Claude';}
  function problemLink(p, area) {
    const code=p?.engine_status?.problem_report_code;
    return '<button class="link t-small" data-act="openProblemReport" data-project="'+esc(p?.name||'')+'" data-area="'+esc(area||'')+'" data-code="'+esc(code||'')+'">'+(code?'Add a note to '+esc(code):'Report a problem')+'</button>';
  }
  function engineStatusCard(p){
    const st=p.engine_status||{},host=chatHost();
    if(['needs_you','paused','waiting_chat'].includes(st.state))return startScreen(p);
    const title={waiting_chat:'Ready to start',waiting_for:'Waiting for '+(st.what||'your chat'),working:st.rescuing?'Fixing a small problem…':'Editing: '+(st.step_label||'your video'),needs_you:host+' needs you in the chat →',done:'Done ✓',stopped:'Stopped',paused:'Paused'}[st.state]||'Your edit is saved';
    return '<section class="engine-status" data-engine-state="'+esc(st.state||'waiting_for')+'" role="status"><h2>'+esc(title)+'</h2>'+(st.step_label||st.question||st.reason?'<p>'+esc(st.step_label||st.question||st.reason)+'</p>':'')+(st.state==='waiting_for'&&Number.isFinite(st.percent)?'<b>'+Math.round(st.percent)+'%</b>':'')+(st.what==='your reference scan'?'<p>'+jobEstimate(st.eta)+'</p>':'')+(st.state==='stopped'?'<button class="btn btn-ink" data-go="studio/'+esc(p.name)+'">Open Studio</button> '+problemLink(p)+'':'')+'</section>';
  }
  function startScreen(p,got=false){
    const s=S(),st=p.engine_status||{},host=s.editor?.provider;
    const claudeWaiting=host==='claude'&&st.state==='waiting_chat';
    const queued=claudeWaiting&&s.active_chat_project&&s.active_chat_project!==p.name;
    const starting=claudeWaiting&&s.waiter_alive===true;
    const headline=got?'Your edit is starting…':queued?'Your video is next':starting?'Starting your edit…':'Go to your CreatorCut chat';
    const line=got?'Your chat has picked up your video.':queued?'Your chat is finishing your other video. This one starts right after.':starting?'Your Claude chat is picking up your video. Keep it open.':host==='codex'&&st.state==='waiting_chat'?'In Codex, switch this chat to Full access, then type <strong class="start-word">continue</strong>.':'Type <strong class="start-word">continue</strong> and press Return. If it’s asking you a question, answer it first.';
    return '<main class="start-screen" role="status"><div class="start-card"><span class="t-mono">CREATORCUT</span><h1>'+headline+'</h1><p class="start-action">'+line+'</p>'+(!got&&st.question?'<p class="start-wait">'+esc(st.question)+'</p>':'')+(!got&&!queued&&!starting?'<p class="start-wait">Closed it? Open the CreatorCut folder in Claude Code or Codex first.</p>':'')+'<button class="link" data-act="cancelEditor" data-project="'+esc(p.name)+'">Stop edit</button> · <a class="link" href="#/videos">My videos</a>'+(['paused','needs_you'].includes(st.state)?' · '+problemLink(p):'')+'</div></main>';
  }
  function acknowledgeHandoff(pending){
    const id=pending.name,rid=pending.engine_status?.request_id,route=A.route(),key=id+':'+rid;
    if(A.ui.handoffAcknowledged===key)return;
    A.ui.handoffAcknowledged=key;
    setTimeout(()=>{
      if(A.ui.handoffProject!==id||A.ui.handoffAcknowledged!==key)return;
      const now=A.route(),current=(S().projects||[]).find(p=>p.name===id);
      delete A.ui.handoffProject;delete A.ui.handoffAcknowledged;
      if(now.name!==route.name||now.arg!==id||current?.engine_status?.request_id!==rid||!['working','waiting_for','needs_you','done'].includes(current?.engine_status?.state))return;
      A.go('editor/'+id);A.render();
    },1000);
  }
  function nativePanel(p){
    const st=p.engine_status||{};
    if(['needs_you','stopped','paused','waiting_chat'].includes(st.state))return engineStatusCard(p);
    return '';
  }
  function editorPanel(p){return p.engine_status?.state?nativePanel(p):'';}
  const editorActive = p => ['working','waiting_for','waiting_resources','needs_you','paused','waiting_chat'].includes(p.engine_status?.state);
  const editorExists = p => !!(p.engine_status?.request_id || p.preview || p.latest || p.versions?.length);
  function projectHelp(p){return '<div class="page editor-empty" role="status"><h1 class="t-2">Your video files are safe.</h1><p class="t-body">Ask your CreatorCut chat to help open this video. Your other videos are still available.</p><a class="btn btn-line" href="#/videos">My videos</a></div>';}
  function bindProject(p) {
    if (A.ui.studioProject !== p.name) { A.ui.studioProject = p.name; A.ui.namingRef = null; A.ui.refName = null; A.api.focus && A.api.focus(p.name).catch(() => {}); }
  }
  function studio() {
    const id = A.route().arg;
    if (!id) {
      if(A.ui.createDraftError)return '<div class="page editor-empty" role="status"><h1 class="t-2">Your videos are safe.</h1><p class="t-body">'+esc(A.ui.createDraftError)+'</p><button class="btn btn-ink" data-act="retryStudioSetup">Try opening Studio again</button></div>';
      const drafts=(S().projects||[]).filter(p=>p.status==='draft'&&!editorExists(p));
      const draft=drafts.find(p=>p.name===A.ui.orderProject)||drafts[0];
      if (draft) { setTimeout(() => {if(A.route().name==='studio'&&!A.route().arg)A.go('studio/'+draft.name);},0); }
      else if (!A.ui.creating) { A.ui.creating=true; A.createVideoDraft().then(r=>{A.ui.creating=false;A.ui.orderProject=r.project;if(A.route().name==='studio'&&!A.route().arg)A.go('studio/'+r.project);}).catch(error=>{A.ui.creating=false;A.ui.createDraftError=error.message||'The setup request did not finish. Please try again.';A.render();}); }
      return '<div class="page" role="status"><p class="t-small">Opening your video setup…</p></div>';
    }
    const p=projectById(id);
    if(!p)return '<div class="page editor-empty" role="status"><h1 class="t-2">Open your video setup</h1><p class="t-body">This video is not in this app folder. Your saved videos are in My videos.</p><button class="btn btn-ink" data-go="studio">Open Studio</button></div>';
    if(p.metadata_issue)return projectHelp(p);
    bindProject(p);A.ui.orderProject=p.name;
    return '<div data-studio-project="'+esc(p.name)+'" data-studio-view="draft" data-key="st-draft">'+studioDraft(p)+'</div>';
  }
  function editor() {
    const id=A.route().arg,projects=(S().projects||[]).filter(editorExists);
    if(id==='animation-preview'){
      const image='kit/studio/app/tour-landscape.jpg';
      const sample={name:'animation-preview',title:'Animation preview',status:'draft',animation_preview_only:true,poster:image,media:[{kind:'raw',thumb:image,hero:image}],editor_job:{id:'visual-preview',execution_mode:'chat',state:'queued',created:Date.now()/1000}};
      return '<div class="page"><div class="editor-page-head"><h1>Editing animation</h1><a class="btn btn-line" href="#/studio">Back to Studio</a></div><p class="t-small" role="status">Visual preview only. No video is being edited or rendered.</p>'+studioWorking(sample)+'</div>';
    }

    const p=id?projectById(id):projects.find(p=>p.name===A.ui.editorProject)||projects.find(editorActive)||projects[0];
    if(p&&A.ui.launchingProject===p.name){
      const frames=rawFrames(p),hero=p.poster||(p.media||[]).find(m=>m.kind==='raw')?.thumb||'';
      const strip=frames.length?frames:hero?[hero]:[];
      return '<div class="page" data-key="launch-'+esc(p.name)+'" role="status"><div class="editor-page-head"><h1>Editor</h1></div><h2 class="t-2">Saving your request</h2><p class="t-small">Saving your choices…</p><div class="ed"><div class="ed-tl ed-motion-scan ed-motion-paused"><div class="ed-activity-caption"><span><i></i> SAVING YOUR REQUEST</span></div><div class="ed-row"><span class="t-mono">V1</span><div class="ed-clips">'+Array.from({length:14},(_,k)=>strip.length?'<img alt="" style="--clip-i:'+k+'" src="'+esc(strip[k%strip.length])+'">':'<i></i>').join('')+'</div></div>'+editorMotionOverlay()+'<i class="ed-head"></i></div></div></div>';
    }
    if(p?.metadata_issue&&!p.versions?.length)return projectHelp(p);
    if(!p||!editorExists(p))return '<div class="page editor-empty"><span class="t-mono">EDITOR</span><h1 class="t-2">Your video appears here.</h1><p class="t-body">Set up a video in Studio, then click Make my video.</p><a class="btn btn-ink" href="#/studio'+(p?'/'+encodeURIComponent(p.name):'')+'">Open Studio</a></div>';
    bindProject(p);A.ui.editorProject=p.name;
    const active=editorActive(p);
    const mode=active?'work':p.preview||p.latest||p.versions?.length?'out':'work';
    const head='<div class="editor-page-head"><h1>Editor</h1><a href="#/studio">'+icon('plus')+'New video</a></div>';
    return '<div data-studio-project="'+esc(p.name)+'" data-studio-view="'+mode+'" data-key="st-'+mode+'">'+head+(p.engine_status?.chat_identity_unknown&&!p.engine_status?.command_runner_pid&&p.engine_status?.state==='working'?'<p class="t-small" role="status">Waiting for your CreatorCut chat. If it is idle, type <strong>continue</strong>.</p>':'')+(p.engine_status?.notices||[]).map(message=>'<p class="t-small" role="status">'+esc(message)+'</p>').join('')+(p.engine_status?.state?'':editorPanel(p))+(mode==='out'?studioOutput(p):studioWorking(p))+'</div>';
  }

  /* =========================================================== my videos == */
  function myVideos() {
    const vids = (S().projects || []).filter((p) => !p.parent && (p.status !== "draft" || p.engine_status?.request_id || p.editor_job?.id));
    const cards = vids.map((p, index) => {
      const vers = p.versions || [];
      const poster = (vers.length && vers[vers.length - 1].poster) || p.poster || ((p.media || []).find((m) => m.kind === "raw") || {}).thumb || "";
      const savedVideo=vers.length?vers[vers.length-1].url:'';
      const vid = savedVideo || p.latest || p.preview, dl = savedVideo || p.download || p.latest || p.preview;
      const active=['working','waiting_for','needs_you','waiting_chat'].includes(p.engine_status?.state);
      const health={state:p.engine_status?.state==='done'?'healthy':'working'};
      const activity = p.activity || {};
      const st=p.engine_status||{},status=({ready_to_start:'Type start in your chat',waiting_for:'Waiting for '+(st.what||'your chat'),working:st.rescuing?'Fixing a small problem…':'Editing: '+(st.step_label||'your video'),needs_you:'Your chat needs you →',done:'Done ✓',stopped:'Stopped — your work is saved',waiting_chat:st.queue_position>1?'Next in line':'Ready to start',paused:'Paused — open your CreatorCut chat'}[st.state]||'Saved');
      const tone = health.state === 'error' ? 'attention' : p.status === 'finished' || p.preview ? 'ready' : 'working';
      const title = p.title || p.name, url = '#/editor/' + encodeURIComponent(p.name);
      const confirm = A.ui.confirmDelete === p.name;
      return '<article class="video-library-row library-tint-' + (index % 4) + '" data-key="v-' + esc(p.name) + '">' +
        '<a class="video-library-thumb library-portrait" href="' + url + '" aria-label="Open ' + esc(title) + '">' +
        '<span class="folder-portrait">' + (poster ? '<img alt="" loading="lazy" src="' + esc(poster) + '">' : vid ? '<video muted playsinline preload="metadata" src="' + esc(vid) + '#t=0.5"></video>' : '<span aria-hidden="true">' + icon('video') + '</span>') + '</span></a>' +
        '<div class="video-library-info">' + (A.ui.renamingVideo === p.name ? '<div class="video-title-edit"><input data-free aria-label="New video title" maxlength="80" data-project="'+esc(p.name)+'" value="'+esc(title)+'" data-enter="saveLibraryTitle"><button class="btn btn-soft btn-sm" data-act="saveLibraryTitle" data-project="'+esc(p.name)+'">Save</button><button class="link t-small" data-act="cancelLibraryTitle">Cancel</button></div>' : '<div class="video-title-line"><a class="video-library-title" href="' + url + '">' + esc(title) + '</a><button class="video-rename" data-act="renameLibraryTitle" data-project="'+esc(p.name)+'" aria-label="Rename '+esc(title)+'">Rename</button></div>') +
        (p.metadata_issue?'<p class="t-small" role="status">Your files are safe. Ask your CreatorCut chat to help open this video.</p>':'')+'<div class="video-library-details"><span class="video-library-status ' + tone + '"><i aria-hidden="true"></i>' + status + '</span>' +
        (p.timeline && p.timeline.duration ? '<span>' + A.fmtTime(p.timeline.duration) + '</span>' : '') +
        (vers.length ? '<span>Version ' + esc(vers[vers.length - 1].n) + '</span>' : '') + '</div></div>' +
        (confirm ? '<div class="video-library-actions video-library-confirm" role="group" aria-label="Confirm deletion"><span>Delete this video?</span><button class="btn btn-line btn-sm" data-act="cancelDelete">Cancel</button><button class="btn btn-sm danger" data-act="deleteVideo" data-p="' + esc(p.name) + '">Delete</button></div>' :
        '<div class="video-library-actions" role="group" aria-label="Actions for ' + esc(title) + '"><a class="btn btn-ink btn-sm" href="' + url + '">Open video</a>' +
        '<button class="btn btn-line btn-sm" data-act="manageVideoPreset" data-project="' + esc(p.name) + '">Save preset</button>' +
        (dl ? '<a class="btn btn-line btn-sm" data-dashboard-download="'+esc(p.name)+'" href="' + esc(A.downloadURL(dl,title+'.mp4')) + '" download="' + esc(title + '.mp4') + '">Download</a>' : '<button class="btn btn-line btn-sm" disabled title="Available when your finished video is ready">Download</button>') +
        '<button class="video-library-delete" data-act="askDelete" data-p="' + esc(p.name) + '"'+(active?' disabled title="Stop the edit in Studio before deleting this video"':'')+' aria-label="Delete ' + esc(title) + '">' + icon('trash') + '<span>Delete</span></button></div>') + '</article>';
    });
    return '<div class="page page-in video-library"><div class="head"><div><h1 class="t-1">My videos</h1><p class="video-library-count">' + vids.length + (vids.length === 1 ? ' video' : ' videos') + ' in your library</p></div><button class="btn btn-ink btn-sm" data-act="startVideo">' + icon("plus") + 'New video</button></div>' +
      (cards.length ? '<div class="video-library-list">' + cards.join('') + '</div>' : '<div class="empty"><b class="t-3">Your videos will appear here</b><p class="t-small">Start with your footage. Your edits and saved versions stay together.</p><button class="btn btn-ink" data-act="startVideo">New video</button></div>') + '</div>';
  }

  /* ============================================================ presets == */
  function presetsPage() {
    const ps = presets();
    return '<div class="page page-in"><div class="head"><h1 class="t-1">Presets</h1><button class="btn btn-ink btn-sm" data-act="startVideo">' + icon("plus") + "New preset</button></div>" +
      '<div class="plist">' + ps.map((s) => presetTile(s)).join("") + newPresetTile() + "</div></div>";
  }
  function presetPage() {
    const s = styleById(A.route().arg);
    if (!s || !s.yours) return '<div class="page page-in"><div class="empty"><b class="t-3">This preset was deleted.</b><a class="btn btn-ink" href="#/presets">Presets</a></div></div>';
    const src = (s.sources || []).filter((x) => x.title || x.url);
    return '<div class="page page-in"><div class="head"><div class="col"><a class="link t-small" href="#/presets">' + icon("back") + 'Presets</a><input class="pname t-1" value="' + esc(s.name) + '" data-change="renamePreset" data-id="' + esc(s.id) + '" data-free aria-label="Preset name" title="Rename">' +
      (src.length ? '<span class="t-small">From ' + src.map((x) => x.url ? '<a class="link" href="' + esc(x.url) + '" target="_blank" rel="noopener">' + esc(x.title || x.url) + "</a>" : esc(x.title)).join(", ") + "</span>" : "") + "</div>" +
      '<div class="row"><button class="btn btn-text btn-sm" data-act="deletePreset" data-id="' + esc(s.id) + '">' + icon("trash") + 'Delete</button><button class="btn btn-ink btn-sm" data-act="startVideo" data-style="' + esc(s.id) + '">Use for a new video</button></div></div>' +
      '<div class="pp"><div class="rx-media">' + flip(s.frames) + '</div><div class="ra done">' + (s.recipe_kind === 'brief' ? '<p class="t-small">Your instructions, settings and references are saved. Update this preset after your first finished edit.</p>' : refScan({ status: "done", kind: "file" }) + details("ps-" + s.id, s.readout || [])) + "</div></div>" +
      "</div>";
  }
  function teachPage() { setTimeout(() => act.startVideo(null), 0); return '<div class="page"><div class="skel" style="height:60vh;border-radius:12px"></div></div>'; }

  /* =========================================================== settings == */
  /* ============================================================= sheets == */
  const reportChoices = ['It got stuck','The video looks wrong','An error appeared','Install problem','Something else'];
  function reportSheet(sh) {
    const note=!!sh.code, result=sh.result;
    const status=note ? result?.note_status : result?.status;
    const title=note?'Add a note to '+sh.code:'Report a problem';
    const message=sh.error||(status==='sent'?'Report sent':result?'Report saved on this Mac. '+(status==='queued'?'Waiting for confirmation.':'You can copy it or retry.'):'');
    return '<h2 class="t-2">'+esc(title)+'</h2>'+
      (result?'':'<p class="t-small">Choose what happened. Only basic technical details and the note you enter are included.</p><label class="t-label" for="report-choice">What happened?</label><select class="input" id="report-choice" data-change="reportChoice">'+reportChoices.map(choice=>'<option'+(sh.choice===choice?' selected':'')+'>'+esc(choice)+'</option>').join('')+'</select><label class="t-label" for="report-note">Note (optional)</label><textarea class="input" rows="3" id="report-note" data-input="reportText" data-free maxlength="500" placeholder="Leave out names and private details">'+esc(sh.text||'')+'</textarea>')+
      (result?'<p class="t-small">Report code <strong>'+esc(result.code)+'</strong></p>':'')+
      '<p class="t-small" role="status">'+esc(message)+'</p><div class="row">'+
      (!result?'<button class="btn btn-ink" data-act="submitProblemReport"'+(sh.busy?' disabled':'')+'>'+(sh.busy?'Saving…':note?'Save note':'Send report')+'</button>':
        (status!=='sent'?'<button class="btn btn-ink" data-act="retryProblemReport"'+(sh.busy?' disabled':'')+'>Retry</button>':'')+
        '<button class="btn btn-line" data-act="copyProblemReport">Copy</button>')+
      '<button class="btn btn-line" data-act="closeSheet">Close</button></div>';
  }
  function contactCard() {
    const row=S().dashboard_contact;
    if(!row?.ask||A.ui.contactAnswered)return '';
    return '<form class="metadata-issue dashboard-contact" data-dashboard-contact><p>Want to add an email for help with CreatorCut? This is optional.</p><div class="row"><input class="input" type="email" maxlength="254" placeholder="Your email" aria-label="Your email" data-free required><button class="btn btn-ink btn-sm" type="submit">Save</button><button class="btn btn-line btn-sm" type="button" data-act="skipDashboardContact">Skip</button></div></form>';
  }
  function sheet() {
    const sh = A.ui.sheet;
    if (!sh) return "";
    let body = "", wide = false;
    if (sh.type === "install") body = '<h2 class="t-2">Installing</h2>' + installListHtml() + '<button class="btn btn-soft" data-act="closeSheet">Close</button>';
    else if (sh.type === "library-preset") { const p=projectById(sh.project),busy=!!sh.saving; body='<h2 class="t-2">Save preset</h2><p class="t-small">'+((p?.versions||[]).length?'Save the finished video’s style.':'Save your current instructions and settings. You can update this preset after the video is ready.')+'</p><input class="input" data-free data-library-preset-name aria-label="Preset name" placeholder="Name your preset" maxlength="40"'+(busy?' disabled':'')+'><p class="t-small" role="status">'+esc(sh.message||'')+'</p><div class="row"><button class="btn btn-ink" data-act="saveLibraryPreset"'+(busy?' disabled':'')+'>'+(busy?'Saving…':'Save preset')+'</button><button class="btn btn-line" data-act="closeSheet"'+(busy?' disabled':'')+'>Cancel</button></div>'; }
    else if (sh.type === "problem-report") body = reportSheet(sh);
    else if (sh.type === "adjust") body = A.adjustSheet ? A.adjustSheet() : "";
    else if (sh.type === "copyblock") body = '<div class="copybox">' + esc(sh.text) + '</div><button class="btn btn-ink" data-act="copy" data-text="' + esc(sh.text) + '">Copy</button>';
    if (sh.type === "adjust") wide = true;
    return '<div class="scrim" data-act="scrim"><div class="sheet' + (wide ? " wide" : "") + '" role="dialog" aria-modal="true">' + body + "</div></div>";
  }
  function installListHtml() {
    const iv = installInfo();
    return '<div class="install-list">' + iv.steps.map((s) => '<div class="install-row ' + s.state + '" data-key="' + s.key + '"><span class="ic">' + (s.state === "done" ? icon("check") : "") + "</span>" + esc(s.label) + "</div>").join("") + "</div>";
  }
  const COMMANDS = () => [
    ["New video", "plus", () => act.startVideo(null)], ["Home", "home", () => A.go("home")], ["Studio", "plus", () => A.go("studio")], ["Editor", "edit", () => A.go("editor")], ["My videos", "library", () => A.go("videos")],
    ["Presets", "styles", () => A.go("presets")], ["New preset", "spark", () => act.startVideo(null)],
    ["Switch light / dark", "eye", () => { const r = document.documentElement; const d = r.getAttribute("data-theme") === "dark" || (!r.getAttribute("data-theme") && matchMedia("(prefers-color-scheme: dark)").matches); r.setAttribute("data-theme", d ? "light" : "dark"); }],
  ].concat((S().projects || []).filter((p) => p.status !== "draft").slice(0, 8).map((p) => [p.title || p.name, "film", () => A.go((editorExists(p)?"editor/":"studio/") + p.name)]));
  function palette() {
    if (!A.ui.palette) return "";
    const q = (A.ui.paletteQ || "").toLowerCase();
    const items = COMMANDS().filter((c) => c[0].toLowerCase().includes(q)).slice(0, 10);
    const sel = Math.min(A.ui.paletteSel || 0, Math.max(0, items.length - 1));
    return '<div class="palette" data-act="closePalette"><div class="palette-box"><input placeholder="Search" data-input="paletteQ" data-free value="' + esc(A.ui.paletteQ || "") + '" aria-label="Search"><div class="palette-list">' +
      items.map((c, i) => '<button class="palette-item" aria-selected="' + (i === sel) + '" data-act="paletteRun" data-i="' + i + '">' + icon(c[1]) + esc(c[0]) + "</button>").join("") + "</div></div></div>";
  }

  /* ============================================================= render == */
  const root = document.getElementById("app");
  function view() {
    const requested=A.route();
    if(requested.name==='editor'&&requested.arg==='animation-preview')return shell(editor(),'editor');
    const s = A.state;
    if (!s && A.fatal) return '<div class="ob"><div></div><main class="ob-body"><div class="ob-step"><h1 class="t-1">Reconnecting to Studio</h1><p class="t-body">' + esc(A.fatal) + "</p></div></main></div>";
    if (!s) return '<div class="ob"><div></div><main class="ob-body">' + mark("xl") + '<p class="t-body" role="status">Opening your Studio…</p></main></div>';
    const done = s.profile && s.profile.onboarding && s.profile.onboarding.done;
    if (!done || A.ui.forceOnboarding) return onboarding() + sheet() + palette();
    const r = A.route();
    const pending=(s.projects||[]).find(p=>p.name===r.arg&&['studio','editor'].includes(r.name));
    if(pending?.engine_status?.state==='waiting_chat'){
      bindProject(pending);A.ui.handoffProject=pending.name;delete A.ui.handoffAcknowledged;
      return startScreen(pending)+sheet();
    }
    if(pending&&A.ui.handoffProject===pending.name&&pending.engine_status?.state==='working'){
      acknowledgeHandoff(pending);
      return startScreen(pending,true)+sheet();
    }
    const pages = { home, studio, editor, videos: myVideos, library: myVideos, presets: presetsPage, styles: presetsPage, style: presetPage, preset: presetPage, teach: teachPage };
    const nav = { style: "", preset: "", teach: "", presets: "", styles: "", library: "videos" }[r.name];
    const issues = (s.data_issues || []).map(text => '<p class="metadata-issue" role="alert">' + esc(text) + '</p>').join('');
    const readiness=s.readiness||{},account=s.editor?.account||{};
    const setupNotice=readiness.state==='repair'?'<div class="metadata-issue" role="status"><p>'+esc(readiness.message)+'</p>'+' <button class="btn btn-line btn-sm" data-act="recheckReadiness">Check again</button> '+problemLink(null,'install')+'</div>':'';
    return shell(updateBar() + contactCard() + setupNotice + issues + (pages[r.name] || home)(), nav != null ? nav : r.name) + sheet() + palette();
  }
  A.subscribe(() => { A.patch(root, view()); after(); });

  /* scroll-linked fade: sections ease in as they enter the viewport */
  const io = "IntersectionObserver" in window ? new IntersectionObserver((es) => es.forEach((e) => e.target.classList.toggle("seen", e.isIntersecting)), { threshold: 0.12 }) : null;
  setInterval(() => {
    if (document.hidden) return;
    document.querySelectorAll("[data-elapsed]").forEach((el) => {
      const s = Math.max(0, Math.floor(Date.now() / 1000 - Number(el.getAttribute("data-elapsed"))));
      el.textContent = String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0");
    });
  }, 1000);
  /* scroll-linked motion: each update line's opacity and offset follow its position in the viewport */
  let scrollRaf = 0;
  const scrollFx = () => {
    scrollRaf = 0;
    const vh = window.innerHeight;
    document.querySelectorAll(".upd").forEach((el) => {
      const r = el.getBoundingClientRect();
      const c = (r.top + r.height / 2) / vh;                    // 0 top … 1 bottom
      const d = Math.min(1, Math.abs(c - 0.55) / 0.55);
      el.style.opacity = (1 - d * d * 0.75).toFixed(3);
      el.style.transform = el.matches(":hover") ? "" : "translateX(" + (d * 14).toFixed(1) + "px)";
    });
  };
  window.addEventListener("scroll", () => { if (!scrollRaf) scrollRaf = requestAnimationFrame(scrollFx); }, { passive: true });
  /* rotating word in the welcome subtitle */
  setInterval(() => {
    if (document.hidden) return;
    document.querySelectorAll(".rot[data-words]").forEach((el) => {
      const words = el.getAttribute("data-words").split(",");
      el._i = ((el._i || 0) + 1) % words.length;
      const old = el.firstElementChild;
      if (old) { old.classList.add("out"); setTimeout(() => old.remove(), 450); }
      const n = document.createElement("span"); n.textContent = words[el._i]; n.className = "in"; el.appendChild(n);
    });
  }, 2400);
  /* numbers glide to their new value instead of jumping */
  function tweens() {
    document.querySelectorAll("[data-tween]").forEach((el) => {
      const to = Number(el.getAttribute("data-tween")) || 0;
      const from = el._v != null ? el._v : 0;
      if (from === to && el._done) return;
      el._done = true; const t0 = performance.now(), dur = 900;
      const step = (t) => { const k = Math.min(1, (t - t0) / dur), v = from + (to - from) * (1 - Math.pow(1 - k, 3)); el.textContent = Math.round(v); el._v = v; if (k < 1) requestAnimationFrame(step); else el._v = to; };
      requestAnimationFrame(step);
    });
  }
  let lastStudioView = '', editorScrollFrame = 0;
  function keepEditorVisible() {
    const stage = document.querySelector('[data-studio-view]');
    if (!stage) { lastStudioView = ''; if (editorScrollFrame) cancelAnimationFrame(editorScrollFrame); editorScrollFrame = 0; return; }
    const key = stage.dataset.studioProject + ':' + stage.dataset.studioView;
    if (key === lastStudioView) return;
    lastStudioView = key;
    if (editorScrollFrame) cancelAnimationFrame(editorScrollFrame);
    if (stage.dataset.studioView === 'draft') return;
    editorScrollFrame = requestAnimationFrame(() => {
      editorScrollFrame = 0;
      const current = document.querySelector('[data-studio-view]');
      if (!current || current.dataset.studioProject + ':' + current.dataset.studioView !== key) return;
      const target = current.querySelector('.ed, .ox-player');
      if (target) target.scrollIntoView({block:'start', behavior:'instant'});
    });
  }
  function after() {
    if(A.ui.revealPasteCard){const card=document.querySelector("[data-paste-card]");if(card){delete A.ui.revealPasteCard;card.scrollIntoView({block:"center",behavior:A.reduced?"auto":"smooth"});card.querySelector("button")?.focus({preventScroll:true});}}
    keepEditorVisible();
    window.CreatorCutCreative?.bind();
    window.CreatorCutMusic?.bind();
    tweens();
    scrollFx();
    document.querySelectorAll("[data-type]").forEach((el) => {
      if (el._typed === el.getAttribute("data-type")) return;
      const text = el._typed = el.getAttribute("data-type"); let i = 0;
      const step = () => { i += 1; el.textContent = text.slice(0, i); if (i < text.length && el._typed === text) setTimeout(step, 22); };
      if (A.reduced) el.textContent = text; else step();
    });
    if (document.querySelector(".design-intro") && !A.ui.introTimer) { A.ui.introTimer = setTimeout(() => { A.ui.introSeen = true; A.ui.firstWelcomePlayed = true; try { localStorage.setItem("aie-intro", "1"); } catch (e) {} A.render(); }, 3000); }
    if (io) document.querySelectorAll(".feed-item, .folder, .section").forEach((el) => { if (!el._io) { el._io = 1; el.classList.add("fade-scroll"); io.observe(el); } });
    document.querySelectorAll("video[data-hover]").forEach((v) => {
      if (v._b) return; v._b = true;
      let tile = v.closest(".vtile, .vcard2");
      (tile = v.closest(".vtile, .vcard2")) && tile.addEventListener("mouseenter", () => { v.preload = "auto"; v.play().then(() => v.classList.add("ready")).catch(() => {}); });
      tile.addEventListener("mouseleave", () => { v.pause(); v.classList.remove("ready"); });
    });
    const m = document.getElementById("msgs");
    if (m && m._n !== m.children.length) { m._n = m.children.length; m.scrollTop = m.scrollHeight; }
    const v = document.getElementById("mon");
    if (v && !v._bound) {
      v._bound = true;
      const sync = () => {
        const d = v.duration || 0, t = v.currentTime || 0;
        const tc = document.getElementById("tc"); if (tc) tc.textContent = (window.CreatorCutCreative?.moment || A.fmtTime)(t) + " / " + A.fmtTime(d);
        const sc = document.getElementById("scrub"); if (sc && document.activeElement !== sc && d) { sc.value = String(Math.round((t / d) * 1000)); sc.style.setProperty("--p", (t / d) * 100 + "%"); }
        const p = projectById(A.ui.studioProject); const tl = p && p.timeline;
        if (tl && tl.duration) {
          ["h1", "h2"].forEach((id) => { const h = document.getElementById(id); if (h) h.style.left = (t / tl.duration) * 100 + "%"; });
          const seg = tl.segments.find((s) => t >= s.start && t <= s.end) || tl.segments[tl.segments.length - 1];
          const h0 = document.getElementById("h0"); if (h0 && seg) h0.style.left = ((seg.src_start + (t - seg.start)) / (tl.source_duration || tl.duration)) * 100 + "%";
        }
        const scr = v.closest(".screen"); if (scr) scr.classList.toggle("playing", !v.paused);
        const pb = document.querySelector(".play"); if (pb) { const want = v.paused ? "Play" : "Pause"; if (pb.getAttribute("aria-label") !== want) { pb.setAttribute("aria-label", want); pb.innerHTML = icon(v.paused ? "play" : "pause"); } }
      };
      ["timeupdate", "loadedmetadata", "play", "pause", "seeked"].forEach((e) => v.addEventListener(e, sync));
      v.addEventListener("click", () => (v.paused ? v.play() : v.pause()));
    }
    const pi = document.querySelector(".palette input"); if (pi && document.activeElement !== pi) pi.focus();
  }
  document.addEventListener("pointerdown", (e) => {
    const b = e.target.closest && e.target.closest("[data-hold=compare]"); if (!b) return;
    const cmp = document.getElementById("cmp"), mon = document.getElementById("mon"), cv = document.getElementById("cmpv"); if (!cmp || !mon || !cv) return;
    const p = projectById(A.ui.studioProject); const tl = p && p.timeline;
    const t = mon.currentTime; const seg = tl ? tl.segments.find((s) => t >= s.start && t <= s.end) : null;
    cv.currentTime = seg ? seg.src_start + (t - seg.start) : t;
    cmp.hidden = false; let k = 0;
    const open = () => { k = Math.min(100, k + 8); cmp.style.setProperty("--split", k + "%"); if (k < 100 && !cmp.hidden) requestAnimationFrame(open); };
    requestAnimationFrame(open);
    const up = () => { cmp.hidden = true; cmp.style.setProperty("--split", "0%"); window.removeEventListener("pointerup", up); };
    window.addEventListener("pointerup", up);
  });

  /* ============================================================ actions == */
  const act = A.actions;
  act.dismissUpdate=()=>{
    const key=S().update?.latest+':'+new Date().toDateString();
    A.ui.updateDismissed=key;
    try { localStorage.setItem('creatorcut-update-dismissed',key); } catch (_) {}
    A.render();
  };
  act.openProblemReport = el => {
    A.ui.sheet={type:'problem-report',project:el.dataset.project||(['studio','editor'].includes(A.route().name)?A.route().arg:''),area:el.dataset.area,
      code:el.dataset.code,choice:el.dataset.area==='install'?'Install problem':reportChoices[0]};
    A.render();
  };
  act.reportChoice = el => { if(A.ui.sheet?.type==='problem-report') A.ui.sheet.choice=el.value; };
  act.reportText = el => { if(A.ui.sheet?.type==='problem-report') A.ui.sheet.text=el.value; };
  function pollReport(sh) {
    const status=sh.code?sh.result?.note_status:sh.result?.status;
    if(status!=='queued'||A.ui.sheet!==sh)return;
    setTimeout(async()=>{
      if(A.ui.sheet!==sh)return;
      try { sh.result=await A.api.problemReport({action:'status',code:sh.result.code});A.render(); }
      catch (_) { if(A.ui.sheet!==sh)return; }
      pollReport(sh);
    },3000);
  }
  async function saveProblemReport(retry) {
    const sh=A.ui.sheet;
    if(sh?.type!=='problem-report'||sh.busy)return;
    sh.busy=true;sh.error='';A.render();
    try {
      sh.result=await A.api.problemReport(retry?{action:'retry',code:sh.result.code}:
        {code:sh.code,choice:sh.choice,text:sh.text,project:sh.project,area:sh.area});
      pollReport(sh);
    } catch (_) { sh.error='Studio could not save the report. Try again.'; }
    finally {sh.busy=false;A.render();}
  }
  act.submitProblemReport=()=>saveProblemReport(false);
  act.retryProblemReport=()=>saveProblemReport(true);
  act.copyProblemReport=()=>{const copy=A.ui.sheet?.result?.copy;if(copy)A.copy(copy);};
  async function saveDashboardContact(email,skip) {
    await A.api.dashboardContact({email,skip});
    A.ui.contactAnswered=true;
    A.setState(await A.api.state());
    A.ui.contactAnswered=false;
  }
  act.skipDashboardContact=()=>saveDashboardContact('',true);
  document.addEventListener('submit',event=>{
    const form=event.target.closest('[data-dashboard-contact]');
    if(!form)return;
    event.preventDefault();
    saveDashboardContact(form.querySelector('input').value,false).catch(error=>A.toast(error.message,'alert','err'));
  });
  act.forgetRule = (el) => A.act(() => A.api.forgetRule(el.getAttribute("data-id"), +el.getAttribute("data-i")));
  act.go = (el) => A.go(el.getAttribute("data-to"));
  act.cancelUpload = (el) => A.cancelUpload(el.getAttribute("data-id"));
  act.recheckReadiness=async()=>{await A.act(()=>A.api.readinessCheck());A.api.state().then(A.setState);};
  act.cancelEditor=async(el)=>{const p=projectById(el?.dataset?.project||A.ui.studioProject);if(p)await A.act(()=>A.api.editorCancel(p.name));};
  const briefSaves = {};
  const lookSaves = {};
  async function persistBrief(p, text) {
    const prior = briefSaves[p.name] || Promise.resolve();
    const job = prior.catch(() => {}).then(async () => {
      await A.api.brief(p.name, { prompt: text });
      p.brief = Object.assign({}, p.brief, { prompt: text });
      A.ui.briefStatus = Object.assign({}, A.ui.briefStatus, { [p.name]: 'Instructions saved' });
    });
    briefSaves[p.name] = job;
    try { await job; }
    catch(e) { A.ui.briefStatus = Object.assign({}, A.ui.briefStatus, { [p.name]: 'Not saved yet. Your saved choices are kept.' }); throw e; }
  }
  act.briefDraft = el => {
    const p = projectById(A.ui.studioProject); if (!p) return;
    A.ui.briefDrafts = Object.assign({}, A.ui.briefDrafts, { [p.name]: el.value });
    A.ui.briefStatus = Object.assign({}, A.ui.briefStatus, { [p.name]: 'Kept here. Saved when you leave the box or start editing.' });
    A.saveUI();
    const status = document.querySelector('[data-brief-status]'); if (status) status.textContent = A.ui.briefStatus[p.name];
  };
  act.saveBrief = async () => {
    const p = projectById(A.ui.studioProject); if (!p) return;
    const text = Object.prototype.hasOwnProperty.call(A.ui.briefDrafts || {}, p.name) ? A.ui.briefDrafts[p.name] : (p.brief || {}).prompt || '';
    try { await persistBrief(p,text); A.render(); } catch(e) { A.render(); }
  };
  act.useBriefExample = () => {
    const p = projectById(A.ui.studioProject); if (!p) return;
    const el = document.getElementById('editing-brief'); if (!el) return;
    if (el.value.trim()) { A.toast('Your instructions are kept. The example stays available in the empty-box placeholder.', 'check'); return; }
    el.value = BRIEF_EXAMPLE; act.briefDraft(el); el.focus(); el.setSelectionRange(0, 0); el.scrollTop = 0;
  };
  act.makeNativeVideo = async () => {
    const p = projectById(A.ui.studioProject); if (!p || A.ui.savingMake) return;
    const origin=A.route();
    if(S().os==='windows'){A.toast('Mac only for now. Your files are saved.');return;}
    if(A.ui.savingChoicesByProject?.[p.name]||A.ui.savingAdjust?.[p.name]){A.toast('Your adjustments are still saving. Please wait a moment, then click Make.');return;}
    if(!['files','paste'].includes(S().chat_delivery)){A.toast('Keep this tab open. Ask your chat to restart CreatorCut, then try again.','alert');return;}
    if(['checking','repair'].includes(S().readiness?.state)){A.toast('Your editing tools are still being prepared. Your choices are saved.');return;}
    const existing = (A.ui.editStarts || {})[p.name];
    if (existing?.state==='sent') return;
    const text = Object.prototype.hasOwnProperty.call(A.ui.briefDrafts || {}, p.name) ? A.ui.briefDrafts[p.name] : (p.brief || {}).prompt || '';
    const started = existing?.state==='uncertain' || existing?.state==='saving' ? existing.at : Date.now()/1000;
    const startState = state => {
      A.ui.editStarts = Object.assign({}, A.ui.editStarts, { [p.name]: state });
      A.saveUI(); A.render();
    };
    A.ui.savingMake = true;
    A.ui.launchingProject=p.name;A.ui.editorProject=p.name;
    try {
      startState({ state:'saving', at:started });
      if(lookSaves[p.name]) await lookSaves[p.name];
      await persistBrief(p,text);
      const result=await A.api.startRequest(p.name,null,'make-'+p.name+'-'+started);
      startState({state:'saved',at:started,request_id:result.id});
      delete A.ui.launchingProject;A.ui.editorProject=p.name;
      const here=A.route();
      if(here.name===origin.name&&here.arg===origin.arg&&A.ui.studioProject===p.name){A.ui.handoffProject=p.name;A.go('studio/'+p.name);}
      A.saveUI();
      A.api.state().then(A.setState).catch(()=>{});
      A.toast('Your choices are saved.','check');
    } catch(e) {
      const saved=(A.ui.editStarts||{})[p.name]||{};
      delete A.ui.launchingProject;
      if(e.uncertain || e.status>=500) {
        try {
          const fresh=await A.api.state();
          A.setState(fresh);
          const truth=(fresh.projects||[]).find(row=>row.name===p.name)?.engine_status;
          if(truth?.request_id && truth.request_id!==p.engine_status?.request_id && !['stopped','done'].includes(truth.state)) {
            startState({state:'saved',at:started,request_id:truth.request_id});
            A.ui.handoffProject=p.name;
            A.go('studio/'+p.name);
            return;
          }
        } catch {}
      }
      startState({ ...saved,state:e.uncertain || e.status>=500 ? 'uncertain' : 'error', at:started, error:e.message || 'The edit could not start.' });
      if(A.route().name==='editor'&&A.route().arg===p.name)A.go('studio/'+p.name);
    } finally { delete A.ui.launchingProject;A.ui.savingMake = false; A.render(); }
  };

  act.setLook = (el) => {
    const p=projectById(A.ui.studioProject), k=el.getAttribute("data-k"); if(!p)return;
    const previous=(p.settings||{}).look;
    p.settings=Object.assign({},p.settings,{look:k});
    const prior=lookSaves[p.name]||Promise.resolve();
    const job=prior.catch(()=>{}).then(()=>A.api.brief(p.name,{look:k})).catch(e=>{
      if(p.settings.look===k)p.settings.look=previous;
      A.toast('Colour choice was not saved. '+e.message,'alert','err');
      A.api.state().then(A.setState).catch(()=>{});throw e;
    });
    lookSaves[p.name]=job;
    A.ui.savingLooks=Object.assign({},A.ui.savingLooks,{[p.name]:true});
    const done=()=>{if(lookSaves[p.name]===job){delete lookSaves[p.name];delete A.ui.savingLooks[p.name];}A.render();};
    job.then(done,done);
    A.render();
  };
  const presetSaves = new Set();
  function presetStatus(pid,state,text){A.ui.presetFeedback=A.ui.presetFeedback||{};A.ui.presetFeedback[pid]={state,text};A.render();}

  act.updateVideoPreset = async (el) => {
    const p = projectById(A.ui.studioProject), id = el.getAttribute('data-id'), preset = styleById(id);
    if (!p || !preset || presetSaves.has(p.name)) return;
    presetSaves.add(p.name);presetStatus(p.name,'saving','AI is learning & saving this video style…');
    try {
      const r=await A.api.presetFromVideo(p.name,preset.name,id,window.CreatorCutCreative.version(p));if(r)presetStatus(p.name,'saved','Style updated in your presets.');
    }catch(e){presetStatus(p.name,'error',e.message||'Couldn’t save. Your settings are kept.');A.toast(e.message,'alert','err');}finally{presetSaves.delete(p.name);A.render();}
  };
  act.manageVideoPreset = (el) => { A.ui.sheet={type:'library-preset',project:el.getAttribute('data-project')};A.render(); };
  act.saveLibraryPreset=async()=>{
    const sh=A.ui.sheet;if(!sh||sh.type!=='library-preset'||sh.saving)return;
    const input=document.querySelector('[data-library-preset-name]'),name=(input?.value||'').trim(),p=projectById(sh.project);
    if(!name||!p){input?.focus();return;}sh.saving=true;sh.message='Saving your style…';A.render();
    try { const result=(p.versions||[]).length?await A.api.presetFromVideo(p.name,name,'',window.CreatorCutCreative.version(p)):await A.api.presetFromBrief(p.name,name);if(result){A.ui.sheet=null;A.toast('Preset saved. Find it on Home or choose it in Studio.','check');} }
    catch(e){sh.message=e.message||'Your settings are safe. Try saving again.';}
    finally{sh.saving=false;A.render();}
  };
  act.saveBriefPreset = async () => {
    const p = projectById(A.ui.studioProject), input=document.querySelector('.savepreset input');
    const name=((input && input.value)||'').trim();
    if(!p || !name || presetSaves.has(p.name)) { if(input) input.focus(); return; }
    presetSaves.add(p.name);
    try {
      const text=Object.prototype.hasOwnProperty.call(A.ui.briefDrafts||{},p.name)?A.ui.briefDrafts[p.name]:(p.brief||{}).prompt||'';
      await persistBrief(p,text);
      const result=await A.api.presetFromBrief(p.name,name);
      if(result) { p.settings.style=result.id; A.toast('Preset saved. Find it on Home or choose it in Studio.','check'); }
    } catch(e) { A.toast(e.message,'alert','err'); }
    finally { presetSaves.delete(p.name); }
  };
  act.saveVideoPreset = async () => {
    const p = projectById(A.ui.studioProject); const i = document.querySelector(".savepreset input");
    const name = ((i && i.value) || "").trim();
    if (!name) { if (i) { i.classList.add("shake"); i.focus(); setTimeout(() => i.classList.remove("shake"), 400); } return; }
    if (!p || presetSaves.has(p.name)) return;
    presetSaves.add(p.name);presetStatus(p.name,'saving','AI is learning & saving this video style…');
    try {
      const r=await A.api.presetFromVideo(p.name,name,"",window.CreatorCutCreative.version(p));
      if(r){presetStatus(p.name,'saved','“'+name+'” saved to your presets.');if(A.ui.studioProject===p.name){const input=document.querySelector('.preset-mini input');if(input)input.value='';}}
    }catch(e){presetStatus(p.name,'error',e.message||'Couldn’t save. Your settings are kept.');A.toast(e.message,'alert','err');}finally{presetSaves.delete(p.name);A.render();}
  };
  act.copy = (el) => A.copy(el.getAttribute("data-text"));
  act.sheet = (el) => { A.ui.sheet = { type: el.getAttribute("data-sheet") }; A.render(); };
  act.closeSheet = () => { A.ui.sheet = null; A.render(); };
  act.scrim = (el, e) => { if (e.target === el) act.closeSheet(); };
  act.obGo = (el) => goStep(el.getAttribute("data-to"));
  act.obName = (el) => { A.ui.obName = el.value; };
  act.obNameGo = async () => { const n = (A.ui.obName != null ? A.ui.obName : P().name || "").trim().split(/\s+/)[0]; if (!n) { document.getElementById("ob-name")?.focus(); return; } await A.setProfile({ name: n }); await act.finishOb(); };
  act.urlDraft = (el) => { A.ui.urlDraft = el.value; };
  act.addUrl = async () => {
    const input = document.querySelector(".urlbar input[data-input=urlDraft]");
    const raw = ((input && input.value) || A.ui.urlDraft || "").trim();
    if (!raw) { const bar = input && input.closest(".urlbar"); if (bar) { bar.classList.add("shake"); setTimeout(() => bar.classList.remove("shake"), 400); } return; }
    A.ui.urlDraft = ""; if (input) input.value = "";
    for (const u of raw.split(/[\s,]+/).filter(Boolean)) await A.act(() => A.api.addUrl(u));
  };
  act.removeRef = (el) => A.act(() => A.api.removeRef(el.getAttribute("data-id")));
  act.retryRef = (el) => A.act(() => A.api.retryRef(el.getAttribute("data-id")));
  act.finishOb = async () => {
    if (S().offline) return;
    await A.act(() => A.api.event("onboarding.done", { platform: P().platform, style: P().style, name: P().name }));
    A.ui.forceOnboarding = false; A.ui.obStep = null; A.go("home");
  };
  act.restartOb = () => { A.ui.forceOnboarding = true; A.ui.obStep = "welcome"; A.render(); };
  act.startVideo = async (el) => {
    if (A.ui.startingVideo) return;
    A.ui.startingVideo = true;
    try {
      const st = el && el.getAttribute && el.getAttribute("data-style");
      const r = await A.act(() => A.createVideoDraft());
      if (!r) return;
      if (st) await A.act(() => A.api.brief(r.project, { style: st }));
      A.go("studio/" + r.project);
    } finally { A.ui.startingVideo = false; }
  };
  act.retryStudioSetup = () => {delete A.ui.createDraftError;A.render();};
  act.openStyle = (el) => A.go("preset/" + el.getAttribute("data-id"));
  act.choosePreset = async (el) => {
    const p = projectById(A.ui.studioProject); if (!p) return;
    const id = el.value || el.getAttribute("data-id");
    const next = el.tagName === "SELECT" ? id : p.settings.style === id ? "creatorcut-signature" : id;
    const ok = await A.act(() => A.api.brief(p.name, { style: next }));
    if (ok) {
      p.settings.style = next;
      const state = await A.api.state(), fresh = state.projects.find(x=>x.name===p.name);
      if(fresh && fresh.brief && !((A.ui.briefDrafts||{})[p.name]||'').trim()) {
        A.ui.briefDrafts=Object.assign({},A.ui.briefDrafts,{[p.name]:fresh.brief.prompt||''});
      }
      A.setState(state);
    }
  };
  act.refFile = (el) => { A.handleFiles(Array.from(el.files || []), "vref", el.getAttribute("data-project")); el.value = ""; };
  act.removeVideoRef = async (el) => { const p = projectById(A.ui.studioProject); if (!p) return; const id=el.getAttribute("data-id"); const result=await A.act(() => A.api.removeVideoRef(p.name,id)); if(result){p.refs=(p.refs||[]).filter(r=>r.id!==id);A.render();} };
  act.nameRefPreset = (el) => { A.ui.namingRef = el.getAttribute("data-id"); A.ui.refName = null; A.render(); setTimeout(() => { const i = document.querySelector(".namebar input"); if (i) { i.focus(); i.select(); } }, 30); };
  act.cancelRefName = () => { A.ui.namingRef = null; A.render(); };
  act.refName = (el) => { A.ui.refName = el.value; };
  act.saveRefPreset = async (el) => {
    const pid = el.getAttribute("data-project") || "";
    const id = el.getAttribute("data-id"); const i = document.querySelector(".namebar input");
    const name = ((i && i.value) || "").trim();
    if (!name) { if (i) { i.classList.add("shake"); setTimeout(() => i.classList.remove("shake"), 400); } return; }
    const r = await A.act(() => A.api.teach(name, [id], pid));
    if (r) { A.ui.savingRef = { ref: id, job: r.job }; A.ui.namingRef = null; A.ui.refName = null; A.toast("Saving preset “" + name + "”", "check"); A.render(); }
  };
  act.binFiles = (el) => { A.handleFiles(Array.from(el.files || []), el.getAttribute("data-kind"), el.getAttribute("data-project")); el.value = ""; };
  act.files = (el) => { A.handleFiles(Array.from(el.files || []), el.getAttribute("data-kind")); el.value = ""; };
  act.removeMedia = (el) => A.act(() => A.api.removeMedia(A.ui.studioProject, el.getAttribute("data-id")));
  act.renameLibraryTitle=el=>{A.ui.renamingVideo=el.dataset.project;A.render();setTimeout(()=>{const input=document.querySelector('.video-title-edit input');input?.focus();input?.select();},30);};
  act.cancelLibraryTitle=()=>{A.ui.renamingVideo=null;A.render();};
  act.saveLibraryTitle=async el=>{
    const input=document.querySelector('.video-title-edit input'),pid=el.dataset.project||input?.dataset.project,value=input?.value.trim();
    if(!pid||!value||A.ui.renamingSaving)return;
    A.ui.renamingSaving=true;
    try{await A.api.brief(pid,{title:value});const p=projectById(pid);if(p)p.title=value;A.ui.renamingVideo=null;A.toast('Video renamed.','check');}
    catch(e){A.toast('Your title is kept here. '+e.message,'alert','err');}
    finally{A.ui.renamingSaving=false;A.render();}
  };
  act.renameVideo = (el, e) => { const p = projectById(A.ui.studioProject); const v = el.value.trim();
    if (e && e.type === "keydown") { el.blur(); return; }       // Enter: leaving the field saves it (change event)
    if (p && v && v !== p.title) { p.title = v; A.act(() => A.api.brief(p.name, { title: v })).then(() => A.render()); } };
  act.restore = (el) => A.act(() => A.api.restore(A.ui.studioProject, Number(el.getAttribute("data-n"))));
  act.playpause = () => { const v = document.getElementById("mon"); if (v) v.paused ? v.play() : v.pause(); };
  act.seek = (el) => { const v = document.getElementById("mon"); if (v && v.duration) { v.currentTime = (el.value / 1000) * v.duration; el.style.setProperty("--p", el.value / 10 + "%"); } };
  act.profileField = (el) => { A.setProfile({ [el.getAttribute("data-k")]: el.value.trim() }); el.classList.add("saved"); setTimeout(() => el.classList.remove("saved"), 900); };
  act.rulebookDraft = (el) => { A.ui.rulebookDraft = el.value; A.ui.rulebookFor = A.route().arg; };
  act.saveRulebook = async (el) => { const t = document.querySelector("textarea.rulebook"); if (t && await A.act(() => A.api.saveRulebook(el.getAttribute("data-id"), t.value), "Saved")) A.ui.rulebookDraft = null; };
  act.saveWebsite = async () => {
    const i = document.querySelector(".page .urlbar input"); if (!i) return;
    if (await A.act(() => A.api.website(i.value.trim()))) A.render();
  };
  act.addRefLink = async (el) => { const p = projectById(A.ui.studioProject); const u = (el.value || "").trim(); if (!p || !u) return; el.value = ""; await A.act(() => A.api.videoRef(p.name, u)); };
  act.addRefLinkBtn = (el) => act.addRefLink(el.parentElement.querySelector("input"));
  act.askDelete = (el) => { A.ui.confirmDelete = el.getAttribute("data-p"); A.render(); };
  act.cancelDelete = () => { A.ui.confirmDelete = null; A.render(); };
  act.deleteVideo = async (el) => { const id = el.getAttribute("data-p"); A.ui.confirmDelete = null; if (await A.act(() => A.api.deleteVideo(id), "Deleted")) { if (A.state) A.state.projects = (A.state.projects || []).filter((p) => p.name !== id); A.render(); } };
  act.toggleDetails = (el) => { const k = el.getAttribute("data-k"); A.ui.openDetails = Object.assign({}, A.ui.openDetails, { [k]: !(A.ui.openDetails || {})[k] }); A.render(); };
  act.renamePreset = async (el) => {
    const id = el.getAttribute("data-id"), name = el.value.trim();
    const cur = styleById(id); if (!cur || !name || name === cur.name) { if (cur) el.value = cur.name; return; }
    const r = await A.act(() => A.api.renameStyle(id, name), "Renamed");
    if (!r) { el.value = cur.name; return; }
    if (r.id && r.id !== id) A.go("preset/" + r.id);
  };
  act.deletePreset = async (el) => { const id = el.getAttribute("data-id"); if (await A.act(() => A.api.deletePreset(id), "Preset deleted")) A.go("presets"); };
  act.forget = (el) => { const m = (P().memory || []).slice(); m.splice(Number(el.getAttribute("data-i")), 1); A.setProfile({ memory: m }); };
  act.cleanStorage = async () => { const r = await A.act(() => A.api.cleanStorage()); if (r) A.toast("Freed " + r.freed_mb + " MB", "check"); };
  act.checkUpdate = async () => { const r = await A.act(() => A.api.checkUpdate()); if (r) A.toast(!r.configured ? "Couldn’t check for updates right now." : r.checking ? "Checking for your update…" : r.error ? r.error : r.available ? "Version " + r.latest + " available" : "Up to date", "check"); };
  // one click: the Studio downloads and installs the update itself, restarts, and the page reloads on the new version
  act.installUpdate = async () => {
    if(A.updating)return; // A double click never starts a second transaction.
    const from=S().version,started=Date.now();let confirmed=false;
    A.updating=true;A.updateReconnecting=false;A.render();
    try{await A.flushAllProjectSaves?.();}
    catch(_){
      A.updating=false;
      if(A.state)A.state.update={...(A.state.update||{}),status:'interrupted',error:'Your latest choices are not saved yet. Save them, then try updating again.'};
      A.render();return;
    }
    try{const reply=await A.api.applyUpdate();confirmed=!!reply?.ok;}
    catch(_){A.updateReconnecting=true;A.render();}
    const tick=async()=>{
      try{
        const state=await A.api.state(5000),u=state.update||{};
        A.updateReconnecting=false;
        if(u.restart_required){A.updating=false;A.setState(state);return;}
        if(state.version&&state.version!==from&&!['downloading','installing','waiting_for_edit'].includes(u.status)){location.reload();return;}
        if(['downloading','installing','waiting_for_edit','done'].includes(u.status))confirmed=true;
        if(['failed','interrupted'].includes(u.status)&&Date.now()-started>=10000){A.updating=false;A.setState(state);return;}
        A.setState(state);
      }catch(_){A.updateReconnecting=true;A.render();} // A restart is not a failed install.
      if(!confirmed&&Date.now()-started>=60000){
        A.updating=false;A.updateReconnecting=false;
        if(A.state)A.state.update={...(A.state.update||{}),status:'interrupted',error:'Your current version is safe. Please try the update again.'};
        A.render();return;
      }
      if(Date.now()-started>=24*60*60*1000){A.updating=false;A.updateReconnecting=false;A.render();return;}
      setTimeout(tick,A.updateReconnecting?2000:1000);
    };
    await tick();
  };
  act.palette = () => { A.ui.palette = true; A.ui.paletteQ = ""; A.ui.paletteSel = 0; A.render(); };
  act.closePalette = (el, e) => { if (!e || e.target === el) { A.ui.palette = false; A.render(); } };
  act.paletteQ = (el) => { A.ui.paletteQ = el.value; A.ui.paletteSel = 0; A.render(); };
  act.paletteRun = (el) => { const q = (A.ui.paletteQ || "").toLowerCase(); const c = COMMANDS().filter((x) => x[0].toLowerCase().includes(q))[Number(el.getAttribute("data-i"))]; A.ui.palette = false; A.render(); if (c) c[2](); };

  /* settings changes from the Adjust sheet (shared with v2 helpers below) */
  const adjustChains=new Map();
  function setProject(key,value){
    const pid=A.ui.studioProject;if(!projectById(pid))return Promise.resolve();
    A.ui.savingAdjust={...(A.ui.savingAdjust||{}),[pid]:Number(A.ui.savingAdjust?.[pid]||0)+1};
    const job=(adjustChains.get(pid)||Promise.resolve()).catch(()=>{}).then(()=>persistProjectSetting(pid,key,value));
    adjustChains.set(pid,job);
    const saved=job.finally(()=>{A.ui.savingAdjust[pid]=Math.max(0,Number(A.ui.savingAdjust[pid]||1)-1);if(adjustChains.get(pid)===job)adjustChains.delete(pid);A.render();});
    saved.catch(()=>{});
    A.render();
    return saved;
  }
  async function persistProjectSetting(pid,key,value){
    const p=projectById(pid);if(!p)return;
    const old=p.settings[key];p.settings[key]=value;A.render();
    const result=await A.act(()=>A.api.event('edit.set',{project:p.name,key,value}));
    const live=projectById(p.name)||p;
    if(!result){live.settings[key]=old;A.render();return;}
    live.settings[key]=Object.prototype.hasOwnProperty.call(result,'value')?result.value:value;
    A.toast(result.queued?'Saved for your next edit':result.value!==value?'Saved within the supported range':'Setting saved for your next edit','check');A.render();
  }
  act.retryUpload=el=>A.retryUpload(el.getAttribute("data-id"));
  act.adjustValue = el => setProject(el.getAttribute("data-key"), el.value);
  act.setVal = (el) => setProject(el.getAttribute("data-key"), el.getAttribute("data-value"));
  act.setToggle = (el) => setProject(el.getAttribute("data-key"), el.getAttribute("aria-checked") !== "true");
  act.nudge = (el) => { const p = projectById(A.ui.studioProject); if (p) setProject("caption_size", A.clamp((p.settings.caption_size || 80) + Number(el.getAttribute("data-d")), 40, 180)); };
  act.captionY = (el) => setProject("caption_y", Math.round((0.8 - (el.value / 100) * 0.35) * 1000) / 1000);
  act.musicVol = (el) => setProject("music_volume", Math.round((el.value / 100) * 0.5 * 1000) / 1000);
  act.sfxVol = (el) => setProject("sfx_volume", Math.round((el.value / 100) * 0.6 * 1000) / 1000);
  act.rangeFill = (el) => el.style.setProperty("--p", el.value + "%");
  let audioEl = null;
  act.previewMusic = (el) => { const src = el.getAttribute("data-src"); if (audioEl && audioEl._src === src && !audioEl.paused) { audioEl.pause(); return; } if (audioEl) audioEl.pause(); audioEl = new Audio(src); audioEl._src = src; audioEl.volume = 0.6; audioEl.play().catch(() => {}); };
  A.adjustSheet = () => {
    const p = projectById(A.ui.studioProject); if (!p) return "";
    const st = p.settings;
    const tog = (key, on, label) => '<div class="row" style="justify-content:space-between"><span>' + label + '</span><button class="toggle" role="switch" aria-checked="' + !!on + '" data-act="setToggle" data-key="' + key + '" aria-label="' + label + '"></button></div>';
    const y = st.caption_y || 0.66, yp = Math.round(((0.8 - y) / 0.35) * 100);
    const grades = [["natural", "Natural"], ["clean", "Clean"], ["warm", "Warm"], ["punchy", "Punchy"], ["cinematic", "Cinematic"], ["moody", "Moody"], ["soft", "Soft"], ["luxe", "Luxe"], ["film", "Film"], ["mono", "B&W"]];
    if (st.custom_grade) grades.unshift(["custom", "From preset"]);
    return '<div class="row"><h2 class="t-2">Adjust</h2><span class="spacer"></span><button class="icon-btn" data-act="closeSheet" aria-label="Close">' + icon("x") + "</button></div>" +
      '<div class="form"><div class="col full" style="gap:10px"><label>Length<input data-change="adjustValue" data-key="video_length" value="'+esc(p.brief?.length||'best')+'" placeholder="Best, 30 seconds or 20-30 seconds"></label><label>Call to action<input maxlength="300" data-change="adjustValue" data-key="cta" value="'+esc(st.cta||'')+'" placeholder="Optional ending line"></label><label>Platform<select data-change="adjustValue" data-key="platform">'+PLATFORMS.filter(([id])=>id!=='youtube').map(([id,name])=>'<option value="'+id+'"'+(st.platform===id?' selected':'')+'>'+name+'</option>').join('')+'</select></label></div><div class="col" style="gap:14px"><span class="t-3">Captions</span>' + tog("captions_on", st.captions_on !== false, "Captions") +
      '<div class="row" style="justify-content:space-between"><span>Size</span><div class="row"><button class="icon-btn" data-act="nudge" data-d="-6" aria-label="Smaller">' + icon("minus") + '</button><span class="t-num" style="min-width:34px;text-align:center">' + (st.caption_size || 80) + '</span><button class="icon-btn" data-act="nudge" data-d="6" aria-label="Bigger">' + icon("plus") + "</button></div></div>" +
      '<div class="col" style="gap:6px"><span>Position</span><input type="range" min="0" max="100" value="' + yp + '" style="--p:' + yp + '%" data-change="captionY" data-input="rangeFill" aria-label="Caption position"></div>' +
      tog("uppercase", st.uppercase, "Force ALL CAPS") + "</div>" +
      '<div class="col" style="gap:14px"><span class="t-3">Look</span><div class="opt-row">' + grades.map(([k, n]) => '<button class="chip" aria-pressed="' + (st.grade === k) + '" data-act="setVal" data-key="grade" data-value="' + k + '">' + n + "</button>").join("") + "</div>" + "</div>" +
      '<div class="col full" style="gap:14px"><span class="t-3">Sound</span>' + tog("voice_cleanup", st.voice_cleanup !== false, "Voice clean-up") + tog("sfx_on", st.sfx_on !== false, "Sound effects") + "</div></div>";
  };

  document.addEventListener("keydown", (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); if (A.ui.palette) { A.ui.palette = false; A.render(); } else act.palette(); return; }
    if (A.ui.palette) {
      const q = (A.ui.paletteQ || "").toLowerCase(); const n = COMMANDS().filter((c) => c[0].toLowerCase().includes(q)).length;
      if (e.key === "ArrowDown") { A.ui.paletteSel = Math.min(n - 1, (A.ui.paletteSel || 0) + 1); A.render(); e.preventDefault(); }
      if (e.key === "ArrowUp") { A.ui.paletteSel = Math.max(0, (A.ui.paletteSel || 0) - 1); A.render(); e.preventDefault(); }
      if (e.key === "Enter") { const b = document.querySelector('.palette-item[aria-selected="true"]'); if (b) b.click(); }
      if (e.key === "Escape") { A.ui.palette = false; A.render(); }
      return;
    }
    const tag = (e.target.tagName || "").toLowerCase();
    if (tag === "input" || tag === "textarea" || tag === "select" || e.target.isContentEditable) return;
    if (document.querySelector(".platforms") && /^[1-4]$/.test(e.key)) { const b = document.querySelectorAll(".ptile")[Number(e.key) - 1]; if (b) b.click(); return; }
    if (document.querySelector(".rail") && /^[1-4]$/.test(e.key)) A.go(NAV[Number(e.key) - 1][0]);
  });
  A.onEvent = (ev) => {
    const p = ev.payload || {};
    if (ev.type === "render.done") A.toast("Saved to My videos", "check");
    else if (ev.type === "version.ready") A.toast("Version " + p.n + " ready", "check");
    else if (ev.type === "job.error") A.toast(p.message || "Something didn’t work", "alert", "err");
  };
  A.onUploaded = async (data) => {
    const ref=data?.ref;
    if(ref){
      const p=projectById(ref.project);
      if(p){p.refs=(p.refs||[]).filter(r=>r.id!==ref.id).concat(ref);A.render();}
      A.toast('Reference uploaded. Scanning its style…','check');
    }
    try{A.setState(await A.api.state());}catch(error){A.toast('Your upload is saved. Reconnecting to show its scan…','info');}
  };
  try { A.ui.introSeen = !!localStorage.getItem("aie-intro"); } catch (e) { A.ui.introSeen = true; }
  if (A.reduced) A.ui.introSeen = true;
})();
