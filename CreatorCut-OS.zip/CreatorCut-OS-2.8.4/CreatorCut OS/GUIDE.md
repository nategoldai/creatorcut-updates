# Your first CreatorCut video

Installed. Now open it in a new chat:
**Claude:** use **Claude Code (the Code tab in the Claude app)**. Click **New session** → click the folder name under the message box → **Open folder…** → choose **CreatorCut** in your Home folder → **Open** → click **Trust**. Then type: **open Studio**.
**Codex:** **New chat** → choose the **CreatorCut** folder → choose **Full access** once if you accept its local access. Then type: **open Studio**.

**1. Add your footage.** Drop raw files and B-roll into Studio. Use footage without captions already burned into it.

**2. Choose your look.** Pick captions, colour, music and up to two effects. Open **What it needs** beside an effect to see whether it needs your pictures, numbers or a wider shot. Add a reference file or link if you like. Wait for **Reference scanned ✓**; a scan can take a few minutes.

**3. Make your video.** Press **Make my video** and keep your Claude chat open. If it doesn't start within 30 seconds, type **continue**. In Codex, type **continue**. Answer any genuine question or permission request in your chat.

**4. Give feedback and download.** Pause the finished video, write feedback, press **Add edit**, then **Update video**. Your earlier version stays saved. Press **Download** when you're happy.

**Save as preset** keeps your chosen style. Tell your chat when a preference should be remembered for future videos. **Stop edit** stops safely. If the chat closes, open this same folder and type **continue**.

Captions: English and other Latin-alphabet languages. Keep your Mac awake and plugged in, close heavy apps, and leave several GB free plus 2.5 GB per edit. If you need help, send a screenshot of the chat.
