# 2.8.19

Stop overlong edits safely after one hour of observed active work, preserving progress and saved versions. Continuing uses verified saved steps when footage and choices match. Waiting and disconnected screens no longer display a running editing animation or timer.

# 2.8.18

Check composition dependencies before opening the rendering browser. Preserve each failed Studio launch diagnostic and report known safe error facts. Ask the editing chat to correct invalid review times. Reuse verified completed cut sections if the later join fails. Avoid unchanged automatic retries for unclassified preview, rendering and review failures.

## 2.8.17

- Check cut instructions, render prerequisites and music inputs before their tools run.
- Match build fallbacks to diagnosed caption or style failures.
- Distinguish browser failure phases and idle chat waits in diagnostics.
- Flag silent raw uploads before Make and explain incomplete movie files.

## 2.8.16

- Keep Studio available when an interrupted update needs repair, and prevent damaged metadata or outdated choices from blocking other videos.
- Improve installer error messages and preserve the previous setup log.
- Guard edit pickup against canceled requests and stale chat heartbeats.
- Check effect plans before rendering and preserve existing projects and video versions on a name collision.
- Keep failed update status visible and stop reporting a failure when already current.

## 2.8.15

Restore standalone graphics commands. Let customers move an idle edit between Codex chats and continue from saved work. Keep broken queue or setup records from blocking startup. Recover from an occupied Studio port and retain verified downloads when only the checksum request needs retrying. Includes the upload, reference progress and feedback checks from the reliability audit.

## 2.8.13

Keep owner installs out of dashboard reporting. Filter children’s and novelty tracks out of Auto music. Resolve stock sound aliases in authored mixes.

## 2.8.12

Protect speech edges at quiet points, vary graphic entrance sounds, and use the selected look to guide Auto music.

## 2.8.11

Use the final reviewed editing brief and Signature caption template. Start each new edit with fresh creative direction. Show when Auto music is preparing and keep Make disabled until saving finishes.

## 2.8.10

Give the editor clearer direction for story-led scene changes, proof footage, readable caption transitions and final picture and sound review.

## 2.8.9

Prepare person cutouts for the effect section, improve HDR assembly speed, retain the selected style colour by default, and make Signature emphasis and effect notices clearer.

## 2.8.8

Fixed Repair on macOS, preserved the purchase email while Studio refreshes, and kept early install activity for delivery once the editing host is known. Added a safe Codex chat handoff and clearer problem reports. Routine creative corrections stay in the edit.

## 2.8.7

Faster Make, clearer chat pickup and recovery, safer updates while an edit is waiting, and clearer feedback status. Signature uses serif emphasis and more sound choices.

## 2.8.6

Purchase email at first launch, editable support contact, richer startup and edit diagnostics, and automatic reports for a chat pickup delay. Reports use the live Lovable incident format with matching save receipts. If the server rejects an initial report, CreatorCut tries a short legacy report and keeps the full evidence locally.

## 2.8.5

Dashboard reporting is on by default. This candidate also includes the updated Signature editing direction, sound cues, framing and consistent revision loudness.

## 2.8.3

Save a problem report with a shareable code, recover a failed edit step, and see a clearer update banner. Dashboard sending starts disabled.

## 2.7.23 — unpublished candidate

Frame Break limited to its owner-proven three-second span while the longer-path colour cause remains unresolved; Spotlight added with attributed real-run evidence. Rotated-video frame-count post checks use JSON. Unsuitable Blackout/Vertigo moments are rejected before effect preparation. Update checks share in-flight discovery. The development matrix can use the normal prepare/transcribe/plan/cut flow with --real-cut. Acceptance remains incomplete.

## 2.7.22 — unpublished candidate

Frame-counted multi-section cuts and shared word/segment offsets; explicit style colour ranges; content-bound cut-out reuse and recipe resume; truthful renderer permission diagnostics; failed-effect notices without attaching failed output; pinned real-render release allowlist. Final real-phone colour, human-speech drift and long-effect timing acceptance remain unverified.

# 2.7.20 — unpublished candidate

Visible-chat paste transport fix, bounded downloads, watcher startup recovery, library recipe/parameter checks, compact saved controls and revised customer guides. Real installation, style matrix and complete editing acceptance remain incomplete.

## 2.7.19-rc.14 — local candidate

- Cache successful Claude account probes for sixty seconds per installation and exact binary; explicit reconnects refresh them.
- Expired authentication invalidates the cache and leads to sign-in recovery. Completed sign-in resumes setup-paused jobs while preserving declined permissions and local-rendering consent.
- Live Claude conversation test acknowledged the test message but exposed no CreatorCut app tool; native routing remains unverified.

## 2.7.19-rc.13 — execution reliability candidate

- Distinguish actual step progress from a background liveness pulse. Repeated status output cannot indefinitely renew a stalled edit.
- Detect an inactive AI turn after three minutes; long-running tools retain a separate generous progress window. Explicit human decisions remain explicit.
- Tolerate progress metadata corruption and files replaced during a status read.
- Require an exact project for project commands; never silently edit another recent video.
- Keep the existing interface, effect library, request coverage and verified-publication gates.
- Native chat routing remains disabled until the installed host proves actual reception. CLI help and a transport write are not reception evidence.

# 2.7.19-rc.3 — local audit candidate, not published

- Isolated readiness, ordered choice saves, bounded background preset saves, reference recovery and private pinned dependencies.
- Measured structured progress, limited per-frame status writes, protected job transitions and verified orphan shutdown.
- Actual update-lock checks prevent abandoned update flags from blocking Make. Customer release requires exact-version acceptance on both hosts.
- Complete reference-scan barriers and content-bound reference evidence prevent silent partial styles and late-index invalidation.
- Legacy activity records use actual writer locks; managed project tools bind to one installation with unrelated native bridges disabled in that process only.
- Historical verification flags do not certify this candidate. See the local release acceptance gate before packaging.

## 2.7.18 — Exact colour choices and caption control

- Studio Captions On / Off saves per video and in presets. Off preserves the chosen font/style and prevents stale captioned composites being reused. Existing exports remain unchanged until a new edit.
- Original adds no creative colour filter. Every named look uses an executable pinned recipe; reference colour uses measured current-reference values. The classic renderer uses the same colour contract.
- Selected effects require attached real slots, not a name-only applied claim. Missing fonts fail explicitly rather than silently substituting another face; font assets with equal filenames keep distinct content.
- Concurrent videos get distinct folders atomically. Existing projects, preset versions, style code and learning memory remain protected during updates.
- Verified with synthetic actual colour and caption renders plus regression tests. Individual artistic results and every possible host/security environment cannot be guaranteed.

# 2.7.17 — editor connection and renderer recovery

- Keep Claude and Codex sessions tied to the selected host; preserve the saved exact request across recovery.
- Fix Claude browser rendering in its normal Mac sandbox. Setup explains its one-time, app-only local connection consent before editing starts.
- Stop repeated permission retries after a lost connection. Queued older jobs also check readiness before running.
- Keep live connection heartbeats separate from measured editing progress; stop duplicate polling after reconnection.
- Bound private Python startup checks and fail disconnected sends promptly. Preserve presets, videos and consent across updates.
- 657 backend tests and 19 interface suites pass. Real Claude sandbox graphics rendering passes. Full customer Studio publication, fresh independent onboarding, Windows and mobile host execution are not certified by these tests.

# 2.7.16 — installed instruction access in Claude

- Give project sessions access to installed static instructions/styles without adding the whole app root or other projects. Protect those resources from editing and supply root instructions directly in session context.
- Live native Read test passes with outside-working-directory restrictions enabled and no confirmation prompt. 631 backend tests pass.

# 2.7.15 — Claude runtime update checks

- Include the private Claude runtime requirements in update dependency checks, verify the installed runtime, and preserve its folder during app-file updates. Other hosts do not install this optional runtime.
- 628 backend tests pass; native Claude render/revision output checks and 15 UI suites passed.

# 2.7.14 — native Claude editor

- Claude installs select a native official Claude editor automatically, install its pinned runtime privately, and use the real Claude account check.
- Saved jobs capture their provider; project sessions and connections remain separate. Revisions cannot overlap SDK cleanup.
- Setup and shortcuts use the current host without configuring another host’s account or global trust settings.
- Private Python 3.12 is bootstrapped from older system Python; installation and account checks finish before opening Studio.
- 626 backend tests, 15 UI suites and eight publisher tests pass. A real authenticated Claude synthetic edit and saved-session revision produced independently verified outputs. Fresh Claude desktop onboarding and a complete customer Studio publication run were not repeated. Normal account and security requirements remain.

## 2.7.13 — cleaner progress and stronger recovery

- Replaced repeated progress headings, logs and sweeping decorative lines with one compact animated status card.
- Shows one percentage, preferring actual current-tool telemetry and labelling verified milestones separately. Waiting states never pretend to be editing or show fabricated progress.
- Compact, explicit security confirmations remain available; no permission policy is bypassed or automatically accepted.
- Includes bounded server startup, duplicate-launch prevention, inherited-pipe shutdown repair, monotonic supervisor/scheduler health and same-request crash recovery.
- 600 backend tests and 15 interface suites passed locally. Independent fresh Claude-host onboarding is not verified.

## 2.7.11 — Studio startup repair

- Missing request IDs no longer count as a confirmed request match or crash initial state/status updates.
- New drafts explicitly load their saved state before navigation, without depending on event-stream timing. The same creation key survives a lost refresh so retry cannot duplicate a video.
- Missing project links lead to a working Studio entry instead of an indefinite loading screen.
- Installer downloads now have bounded connection/transfer timeouts and retry limits; duplicate Mac/Linux setup waits are bounded rather than infinite.
- Added browser regression coverage for fresh-tab, existing legacy jobs and interrupted draft hydration.

## 2.7.10 — verified installation and live progress

- Dedicated first-install chat title now uses CREATORCUT regardless of the initial request wording, preserving later manual renames.
- Fixed the speech-model setup path before its cache/download check; tools remain gated until verified.
- Malformed setup timestamps cannot produce false completion or break the progress card.
- Compact premium installation card: blue orb, orbiting detail, measured percentage and verified step segments. Responsive and reduced-motion aware.
- Read-only local status service works before editing tools are installed, independently of Studio. No early Editor screen.
- Percentages use verified steps; no elapsed-time counters or invented download progress. Final 10% requires the current version’s actual account/supervisor readiness receipt.
- Interrupted installs retain their progress and show a saved/reconnecting state. Design-preview samples are clearly labelled.

## 2.7.9 — complete setup before opening

- Studio refuses to open or bind a preview before tools, downloaded speech model, fonts, sounds, actual account and a live managed supervisor are verified.
- Setup cannot silently defer a failed speech-model download or call missing tools installed. Cache checks reject incomplete models and broken links.
- Recognize generated installation titles including Install CreatorCut updates; rename once early using a supported host tool and preserve later customer renames.
- Concise beginner installation messages; separate Claude and Codex folders, shortcuts and speech caches.
- Validate the exact installation identity before reusing a server on a saved port.

## 2.7.8 — responsive start and isolated confirmation

- Make opens Editor with an honest preparation animation before saving or network replies. No invented editing progress.
- A durable job acknowledges without waiting on supervisor startup; one background wake attempt is coalesced and the existing watchdog independently retries it.
- A lightweight authenticated per-project status route confirms lost replies and refreshes active job states independently of full library snapshots. Requests have bounded deadlines and overlapping status reads are suppressed.
- Old request/job data cannot falsely confirm a new request or leak an old approval into a new accepted job.
- Fault injection covers blocked supervision, failed thread creation, duplicate clicks, lost replies, a hung full-state request and preparation-view cleanup after a failed save.

## 2.7.7 — 2026-10-22
- Fix live Editor state updates freezing behind render resources: readiness checks now run once in the background and never block state responses.
- Keep exact FFmpeg version/filter queries outside the heavy encoding lock, with short timeouts; real encoding remains serialized.
- Preserve active editor processes while applying the local web-server hotfix.

## 2.7.6 — 2026-10-22
- Download verified updates by immutable GitHub object id, avoiding stale branch downloads immediately after publication.
- Includes the 2.7.5 start-recovery, update-pulse and mobile layout improvements.

## 2.7.5 — 2026-10-22
- Recover the confirmed editor job even when both Make/Update HTTP dispatch replies are lost; preserve the same request and prevent duplicate videos.
- Gently pulse Download new version only when an update is available; respect reduced motion.
- Improve phone update-button targets and input font sizes; check four pages at 320/390/430px.
- Publish through the permanent GitHub installation/update channel; keep customer projects, presets and editing memory.

# 2.7.4 — Update recovery and refreshed getting-started experience

- Journal app-file installation before replacement, mark successful commits and restore an interrupted transaction before the server and editing supervisor start. Retain videos, presets, memory and local account configuration. Atomic restores do not overwrite protected customer paths.
- Reconcile a lost Update-button reply against saved installer state without sending duplicate installation requests. Keep the button unavailable when no verified newer version exists.
- Allow up to ten minutes for a bounded GitHub download so a larger package can arrive over slower connections. Require the local renderer installer when dependencies change rather than silently skipping it.
- Include the updated compact walkthrough animations and beginner starter guide. The guide uses app-style vector drawings and explains extracted-folder setup, presets and personal memory; it contains no customer photos or screenshots.
- Public update channel remains nategoldai/creatorcut-updates / CreatorCut-OS.zip. Publishing is a separate action; local packaging does not change the public release.

# 2.7.3 — Bounded editor message delivery

- Move editor pipe writes to a dedicated, bounded writer queue. A child that stops reading cannot hold the response registry lock or bypass the request deadline.
- Include message delivery in the total request deadline. If delivery is ambiguous, terminate only this owned transport and preserve the durable request; do not replay an unconfirmed turn into it.
- Stop the owned child before closing its input stream so shutdown cannot block on a flush into an unresponsive process. Keep required host permissions unchanged.
- Accept provider error messages that are not JSON objects without crashing the response reader.
- 499 Python cases and eleven UI/setup suites passed, including a real non-reading child, forty concurrent reply-matching requests and malformed provider responses. This verifies these scenarios, not zero failure probability or permission-free operation. No new ZIP or public update feed was created.

# 2.7.2 — Independent projects and reliable saved preferences

- Allow two independent project sessions without allowing concurrent heavy renders. A permission wait, reconnect backoff or malformed queue entry in one project cannot monopolize the supervisor. Keep per-project writer locks, crash recovery and one-worker rendering.
- Bind restored session metadata to its exact project and installation. Copied/imported videos cannot silently resume another video's conversation. Explicit Retry clears an old reconnect delay.
- Reconcile a lost dispatch reply against active/completed jobs only. A stopped job is resumed idempotently instead of being falsely shown as a new start.
- Normalize preset feedback names to the actual preset ID; generate creator/preset skill text atomically. Serialize memory snapshots with preference updates.
- Read the activity log once per state snapshot, instead of once per project. Track process birth identities to detect reused PIDs. Use non-destructive Windows process queries instead of POSIX signal probes; native Windows execution still requires separate verification.
- Give the imported effect renderer project-owned font caches and invocation-owned extraction caches; restore a missing SciPy dependency in the live private environment. A real pinned Dot Counter render decoded successfully; frame checks verified exactly three dots and the requested timed entrance/exit.
- Home uses the actual editing-job state and newest saved preview, so a paused job is not labelled Creating and an older preview does not replace the latest saved video.
- Remove unused duplicate-chat actions and unreachable Make mirroring code from the current interface. Replace contradictory production instructions with the managed editor contract; legacy connector compatibility stays explicitly isolated.
- 496 Python regression cases and eleven UI/setup suites passed. New tests include real project-thread concurrency with isolated requests/feedback, bounded capacity, failed thread starts, network-reply recovery, preset skill loading, atomic writes and simulated Windows API calls. No new ZIP or public feed update was made.

# 2.7.1 — Editing reliability audit

- Reproduce the customer composition's two-minute browser-check deadline in isolation. Preserve its full unsliced timeline/motion sweep, and run the same five readability samples on fresh pages for multi-video compositions. Keep all findings and require every expected sample report.
- Use unique capture filenames, reject failed/empty outputs, and remove only the failed attempt's partial movie. Existing published files remain untouched. Accept only newly written check reports; incomplete reports cannot pass.
- Continue a normally ended but unfinished editing turn up to two times in the same project/session/request. Never replay denied/expired permissions or pretend unfinished output is complete.
- Recognize joined multi-clip sources using their ordered input provenance. Asset preparation percentages cannot masquerade as full video capture progress.
- Setup checks exact renderer pins and rejects dependencies pointing outside app-owned modules. Repair the live installation's deleted-cache link for the style renderer.
- 478 Python regression checks and nine interface/setup suites pass. The customer composition passes technical validation in an isolated copy while retaining visual findings for review. A finished published customer video and its host permission lifecycle are separate checks. No new ZIP or public update was published during this audit.

# 2.7.0 — Less repeated work, same final quality

- Verify content hashes before reusing prepared source footage, transcripts, person cutouts and reference measurements/style studies. Changed source, settings, code, model weights or tracked outputs invalidate the relevant cache. Incomplete and zero-byte outputs never become valid cache entries.
- Reuse the last unchanged visual render for sound-only revisions; remix audio, rerun technical checks and require fresh candidate review/publication. Draft and final remain separate. One last visual result is retained per project instead of an unbounded render history.
- Validate visual assets and fonts before rebuilding composition files and doing media conversion. Prepared seeking assets now use content identity and verified completion records.
- Add revision-context.json with exact saved-version, frame, scene and affected item ids. Planning guidance preserves work outside the requested scope; it does not blindly apply notes or skip review.
- Keep memory limits, worker count, final resolution, encoding settings, inference settings and release gates unchanged. Complex per-scene video stitching is not enabled.
- Show one percentage below the timeline. Keep Editing and a rotating task label while work runs; real permission waits remain explicit in a separate notice.
- 464 Python checks and eight UI suites pass. Real synthetic preparation/asset reuse produced byte-identical outputs. A full synthetic graphics/audio render passed; a real audio-only revision reused its visual bytes and created a fresh candidate. These are scoped checks, not an end-to-end speed or creative-quality guarantee.

# 2.6.1 — Renderer setup and session permissions

- Probe cache writes and the loopback browser server inside the same restricted project sandbox before starting the editing turn. Record prerequisite results separately from actual render validation.
- Support explicit session-scoped permission grants using the documented permissions response. Once grants stay turn-scoped; declines and timeouts grant nothing.
- Keep font caches under the current project and extraction caches under the invocation-owned temporary directory. No global HOME or security policy changes.
- Setup guidance now distinguishes installed tools from renderer permission readiness. Session grants are per project session; no installation-wide or zero-failure promise is made.
- 432 Python tests pass. A real sandbox probe confirmed writable project cache and blocked loopback server without granting access or starting another model.

# 2.6.0 — Visible progress and reference upload confirmation

- Always show progress during managed editing from actual preparation, transcription, current-request design, render, review and publication milestones. Weights describe completed work, not elapsed time or an ETA; only publication reaches 100%. Live renderer measurements contribute within the render stage.
- Show a small animated activity accent while work runs. Planning can remain at its last verified milestone; no timer fabricates completion.
- Immediately confirm reference uploads and show their scan card, then refresh persisted state. Do not silently rely on the next event-stream update.
- Keep removed-reference markers when an older scanner saves late, preventing replaced references reappearing.

# 2.5.9 — Writer recovery and clear progress

- Recover an idle retained writer by branching completed stored history; do not fork when any stored turn is unfinished or the thread is active. Keep project/resource guards and original request identity.
- Keep raw provider diagnostics in local logs instead of customer-facing failure panels. Show an honest paused state and retain required permissions.
- Make measured tool percentage prominent in the main editing heading. Unmeasured planning remains animated without invented progress.
- Regression tests reproduce idle/active writer conflicts, protect against a second writer and prevent raw failure text in public state and timeline/panel markup.

# 2.5.8 — Launch audit and recovery fixes

- Keep accepted Make and revision jobs visible even if a simultaneous state refresh replaces the selected project. A failed refresh cannot switch an accepted revision back to its old player.
- Surface asynchronous button failures; bound draft setup retries; keep number keys inside dropdowns and editable fields.
- Download the latest saved version rather than a stale preview. Actual embedded-browser download saved a byte-identical MP4.
- Distinguish an unanswered permission request expiring from a user declining it. Retain required security permissions and resumable project state.
- Align connector descriptions and the six-page starter guide with Studio setup, dedicated Editor and the managed project engine.
- 418 Python checks, seven UI suites and an isolated real graphics/audio render passed. These checks do not prove every customer environment or creative result.

# 2.5.7 — Studio, Editor and downloads

- Add a dedicated Editor tab for active edits, completed movies and frame feedback. Studio remains the video setup form; accepted Make requests open their exact Editor project immediately.
- Keep draft setup and current Editor selection independently. Legacy Studio links to started videos redirect safely; Home, My videos and search open Editor. Empty Editor does not create a project.
- Show actual tool percentage on the editing viewport and label it as current-step progress; unmeasured planning and permission waits do not invent a percentage.
- Send an explicit attachment download response with safe UTF-8 filenames. Playback retains seek/range support. Keep one MP4 export default and offer Download MP4 in Editor too.
- 417 Python checks pass, plus route/double-click, loading, timeline and reference-recovery UI regressions.

# 2.5.6 — Reference scan recovery

- Keep trying downloaders if short-link preflight fails; try the next Instagram public page when a media URL has expired.
- Probe downloaded video before accepting it, allowing another method after a broken MP4 response. Enforce the reference download size limit in yt-dlp too.
- Show a direct Upload reference video action for failed scans, cover-only results and unfinished style studies. A cover preview never displays a full scan confirmation.
- 415 Python checks pass, with an additional UI regression for project-bound upload recovery and partial/error states. Free existing download methods are retained; no Apify or paid service added.

# 2.5.5 — Editing reliability audit

- Render a clear loading screen before the first state response instead of an empty page.

- Pin supervisor heartbeats to the code version actually loaded; an on-disk update no longer makes old code claim to be new.
- Recover a stale supervisor even when a newer release and queued jobs coincide.
- Treat real command/file/tool output as liveness during long edits without inventing percentages.
- Coalesce streamed token/frame activity writes to once per second to reduce disk pressure.
- 408 automated checks pass, including real-process update identity and concurrent project isolation. The customer revision published version 2; playback, pause, exact timeline seeking and all 12 thumbnails were checked live. Required account/permission/resource limits remain real.

# 2.5.4 — Frame badge and startup repair

- Put the purple frame badge directly next to the blue time, independent of old small-label styling.
- Guard feedback binding before the first application state arrives; prevents a blank initial screen.
- Correct explicit session-approval support to match the installed App Server schema. Real security consent is retained; no automatic or hidden approval.
- Add protocol response and no-answer safety tests; 405 Python checks pass. UI regression covers initial null state and pause-before-send.

# 2.5.3 — Simpler feedback and mobile layout

- One Edit feedback card with softly coloured notes, newest first, smooth insertion and Add edit.
- Clear Update video with this feedback button; remove the folder submission animation.
- Pause the old movie immediately when submitting; show a still image and editing visualization while revising, with no old-video controls or feedback player.
- Bind sending state to the correct project; preserve exact version/timestamp and prevent duplicate dispatch.
- Put a contrasting frame stamp beside the blue time.
- Phone-sized controls wrap cleanly; show a compact version badge on Home. Responsive checks at 320–1024px passed. Mobile host integration is not claimed.

# 2.5.2 — Real render progress and clearer editing

- Enable HyperFrames machine progress: quiet mode previously suppressed real percentage events.
- Clear a finished percentage when a new unmeasured stage begins.
- Keep the editing visualization keyed during live status updates; use many small footage frames, a longer varied loop and expanding tracks.
- Put rotating workflow phrases beside Editing; show measured step percentages separately.
- Keep Open video, Save preset, Download and Delete visible in My videos. Unavailable actions explain why they are disabled.
- Save named draft presets from the library while protecting the settings of an active render.
- Offer explicit session approval only when the installed editor protocol supports it; retain real security prompts and truthful failure states.

# 2.5.1 — Safer independent edits and saved styles

- Freeze each active request before enqueue; repeated clicks reuse the same job.
- Protect source footage and references from concurrent replacement or deletion.
- Isolate malformed, cancelled and failed projects so other videos continue.
- Recover job records, project sessions and personal preferences from durable local backups.
- Preserve music and voice-cleanup settings in presets; use saved version settings rather than a newer draft.
- Require reference coverage and timeline-feedback capture in new request reviews.
- Recognize a reviewed published movie even if the editor connection loses its final reply.

# 2.5.0 — Persistent editing

- Make and timeline Update start an app-owned Codex editing session, independent of an idle host chat.
- Durable, idempotent jobs; supervisor watchdog; bounded connection recovery; archived-session restoration; no duplicate writer.
- Real approval and sign-in states, reviewed-output completion gates and preserved revision timestamps.
- Uploaded Studio references are frozen into each exact request, independently of asynchronous analysis progress.
- Customer memory skills are updated in the managed editor's writable data area.
- Projects, presets, approved versions and local preferences remain preserved on update.
- This engine requires each creator's own signed-in Codex account, including when hosted inside Claude.

## 2.4.6
- Repair new-video publication thumbnail crash and preset-name activity lookup.
- Remove automatic copy dialogs from Make/Update; keep unsent requests saved truthfully.
- 339 Python regressions; real same-conversation Make and frame-anchored Update rendered and published.
- Compact single-row update status, blue install button, arrow-first Make with real send loading.
- Rename videos directly in My videos without invalidating rendered content.
- Save the displayed version as a reusable preset; preserve current-state recipes if old review evidence cannot be verified. Same-project/same-name saves update versioned presets.
- Host UI metadata compatibility and documented sendFollowUpMessage alternative; actual host capability remains required.
- Add /creatorcut launcher skill and per-user installation registry on setup.
- Keep explicit memory above inferred suggestions; verify saved movie content before counting completed edits.
- Regenerate missing/stale timeline frames and prefer thumbnails from actual saved versions.
- Avoid stale GitHub CDN responses using the verified blob identity. No zero-failure or universal idle-wake guarantee.

## 2.4.5
- Freeze full Studio settings and revision notes at Make/Update; stable request identities survive retries.
- Bind scene plans and candidate review to each exact request, reference, selected effect and note.
- Prevent revision notes from being marked ready before a reviewed new version is published.
- Keep Make delivery attached to the original project if the user navigates during saving.
- Serialise colour saves before Make and prevent a failed choice from silently looking saved.
- Background thumbnail completion no longer invalidates a candidate review.
- 321 regression checks passed. Idle native conversation wake remains unsupported/unverified; foreground receiver and advertised host delivery are distinct.

# CreatorCut OS 2.4.4

- Distinguishes a live Update action from the explicit copy-to-this-chat fallback.
- Real foreground native Update click verified through this conversation, project claim, caption revision and a changed rendered version. This does not establish idle-chat wake or Claude lifecycle support.
- Stable timeline request IDs, persistent browser uncertainty and on-disk delivery receipts prevent unsafe repeated sends after reload or Studio restart.
- Fixes feedback saved before the first seek/pause, and switches to the newly produced version after an update.
- One malformed project is isolated rather than hiding every project.
- Failed preset saving shows the actual reason instead of a generic message.

# CreatorCut OS 2.4.3

- Smooth refresh-rate timeline playhead; exact time and frame when paused.
- Simpler feedback input and list, pointer cursor, no plus sign or extra guidance.
- Full-width whole-video timeline, verified with a 79-second video.
- Slower note arrival and smooth list movement, respecting reduced motion.
- Compact preset saving with real pending/success/error states and a small interactive chat hint.

# CreatorCut OS 2.4.2

- Simplified frame feedback directly beneath the video, with a larger playback clock.
- Newest changes animate into the top of the list; the input clears after saving.
- One Update video action preserves and sends an immutable exact-version feedback batch to the existing native conversation.
- Failed/unconfirmed sends retain notes; only actual editing activity displays editing progress.
- Unsent changes can be removed without training personal memory.

# CreatorCut OS 2.4.1

- Refined light Studio with full-width raw uploads, aligned compact preset saving and larger inspectable previews.
- Rebuilt creator-footage previews from high-quality masters, natural source colour and original executable effects.
- Compact Home updates and explainer, richer decorative learning-loop visual with real completed-project progress.
- Small blue Mac folders in the row-based video library.
- Fixed missing font-bundle installation in the main style compositor; selected fonts must exist before rendering.
- Interrupted effect setup now prepares privately and commits atomically; failed attempts can be retried.
- Fast fallback thumbnails stay available during long renders and recover their decoder capacity after a worker-start failure.
- Gallery previews release decoder buffers when closed or offscreen.

# CreatorCut OS 2.4.0

- Light, compact Studio with collapsible executable looks, captions and effects.
- Exact-version, creator-footage preview loops and pinned style source.
- Frame/range feedback attached to the saved video version and source scene.
- Named preset recipes retain actual choices and approved reusable parameters.
- Explicit lasting preferences can remember selected executable style versions.
- Reference decisions remain separate from preset identity and current instructions.
- Private pinned renderer; real frame progress and completed setup-step progress.
- Existing source-preserving export, update, recovery and multi-session safeguards retained.

# 2.3.7 — Clearer My videos

- Replaced oversized folder cards with a compact thumbnail list.
- Titles wrap safely; status, duration and version stay with their video.
- Open video, Save preset, Download and Delete remain visible within each row.
- Responsive action rows for narrow panels; retained delete confirmation and empty state.
- Verified eight window widths, long titles and action bounds in an actual browser.

# 2.3.6 — Recovery and lifecycle audit

- Silent Studio streams trigger a real state refresh and reconnect. Repeated connects and overlapping recovery requests are prevented.
- Duplicate background actions share their active worker. Worker-start failures become explicit retryable errors.
- Active jobs remain visible and durable even after large histories. Malformed activity/job entries are isolated.
- Notification-write failures do not mark a successful export as failed.
- Timed-out command trees are stopped together. On POSIX, render children retain the capacity lock if their parent crashes.
- A confirmed child completion supersedes an older server-restart warning without hiding genuine failures.
- Verified with injected failures, real subprocesses and two graphics/audio exports.

# 2.3.5 — Concurrent project safety

- Separate worker and project progress records; Studio no longer borrows another video's status.
- Shared heavy-operation lock across native sessions, visible automatic resource waits and one browser worker.
- Per-invocation renderer temp folders; removed unsafe global frame-cache deletion.
- Reentrant internal project guards protect active render assets. Updates check every active worker.
- Includes 2.3.4 CapCut-style 30 fps delivery defaults.

# 2.3.4

- Default final exports use the verified CapCut-style encoding profile: constant 30 fps, H.264 High, about 12 Mbps, one-second keyframes, AAC 44.1 kHz/160 kbps stereo and SDR Rec.709.
- Normalize before review; cache approved delivery files; preserve original files, timing and aspect ratio. Historical exports receive the same encoding profile with traceable source/output hashes.

# 2.3.3

- Existing website-fed installations migrate to the release-only GitHub repository after installing, including older installers that preserve their old configuration. Custom publisher channels remain unchanged.

# 2.3.2

- Single-ZIP public GitHub update delivery: embedded version detection, verified package caching and preserved projects/presets/editing memory. Repository binding remains required before GitHub distribution.
- Preserve custom update channels; verified packages can migrate the legacy publisher website channel.

# CreatorCut OS 2.3.1
- Recover the initial server-metadata startup race; never treat a blocked workflow as a successful start or obscure current errors with an old building message.
- Prevent stale failure records and invalid worker PIDs from giving a false stopped/running status after a genuine resume.
- Resolve unconfirmed delivery when the project actually starts; keep one project’s uncertain request from blocking unrelated projects.
- Reconnect an active foreground tool after Studio restarts or changes ports; prevent a second tool from taking an action already being acknowledged.
- Preserve concurrent metadata changes and existing approved library files; keep pinned preset memory connected after a rename.
- Add a foreground native-action connection: Studio's Make action returns to the existing conversation's active tool, with no second AI or persistent action queue. Host cancellation and disconnects release it; it does not wake an ended conversation.
- Recover render/editor locks after process death using operating-system locks. Preserve existing valid sources when a multi-clip join fails.
- Generate real footage/preview thumbnails asynchronously with bounded extraction, without blocking Studio status requests.
- Bound metadata reads, reuse upload metadata, and avoid applying render-sized disk reserves to metadata-only starts.
- Correct soundtrack filter-file arguments for current FFmpeg versions; verify an actual graphics and audio export.
- Protect active native edits and older active jobs during updates, serialize update transactions, and copy new code files atomically. Retry failed feed checks with bounded backoff.
- Stop waiting for an installer that is no longer running, and show the actual native editing stage instead of an assumed pipeline step.
- Bring the actual editor into view when an edit starts or the output becomes ready; do not reset the customer's scroll on progress updates.
- Reuse creation requests on double clicks and lost-response retries instead of creating duplicate projects.
- Reuse the saved Studio project throughout editing; intentional new projects remain separate.

# CreatorCut OS 2.3.0

- CreatorCut Signature default: Inter Tight, white/yellow typography, speech-timed in-place word animation and selective readable text behind the speaker.
- Field-by-field direction resolution: explicit instructions, clear reference choices, selected presets and relevant personal preferences override unspecified defaults.
- Real timed-caption starter when no measured reference is available; scene planning and render review remain required.
- Updated Studio with detailed Step 5 instructions, named presets, background editing memory, real progress states and native conversation guidance.
- Verified local update installation with checksum/backup checks and preservation of projects, presets and preference files.
- Consistent CreatorCut OS naming and release version in setup, chat integration and update notices.

Partial reference retry clears stale cover/study failure flags and runs once; an already-complete full scan is left intact.
