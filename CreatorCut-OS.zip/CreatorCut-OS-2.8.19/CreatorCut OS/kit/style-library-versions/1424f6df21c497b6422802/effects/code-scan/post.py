#!/usr/bin/env python3
"""code-scan, last step. After the render: frame-count check, edge colour check, phone copy, stills, contact sheets.

Reads work/marks.json (written by build.py: first and last frame, the print front travelling in, code landed, the
card typing, the card done, the fold back, plain again) and pulls those frames from the FINAL mp4 into
work/qa/sheet_*.jpg with frame numbers, so you can check: plain footage at both ends, no dark patches mid
transition, the face never under the card, the card inside the safe zone.
It also prints how far frame 0 and the last frame of the render are from the a-roll (mean levels per channel).

Usage (from the slot folder):  PY post.py [extra frame numbers ...]
"""
import json
import os
import shutil
import subprocess
import sys

from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
FF = shutil.which('ffmpeg') or 'ffmpeg'
FP = shutil.which('ffprobe') or 'ffprobe'
NAME = os.path.basename(HERE)
R = os.path.join(HERE, f'renders/{NAME}.mp4')
if not os.path.exists(R):
    sys.exit(f'renders/{NAME}.mp4 is missing: render first')


def count(path):
    result = subprocess.run([FP, '-v', 'error', '-select_streams', 'v:0', '-count_frames',
                             '-show_entries', 'stream=nb_read_frames', '-of', 'json', path],
                            capture_output=True, text=True, timeout=60)
    try:
        value = json.loads(result.stdout)['streams'][0]['nb_read_frames']
        if result.returncode or not str(value).isdigit() or int(value) <= 0:raise ValueError()
        return int(value)
    except (ValueError, KeyError, IndexError, TypeError):
        sys.exit('The video frames could not be checked. Rebuild this effect render, then run post.py again.')


a, r = count(os.path.join(HERE, 'assets/aroll.mp4')), count(R)
print(f'frames: aroll {a}, render {r}' + ('' if a == r else '   !! FRAME COUNT MISMATCH'))
if a != r:
    sys.exit(1)


def grab(path, n):
    raw = subprocess.run([FF, '-v', 'error', '-i', path, '-vf', f'select=eq(n\\,{n}),scale=270:480', '-fps_mode', 'passthrough',
                          '-frames:v', '1', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'], capture_output=True).stdout
    return [sum(raw[c::3]) / max(1, len(raw) // 3) for c in range(3)]


for n_ in (0, r - 1):
    ga, gr = grab(os.path.join(HERE, 'assets/aroll.mp4'), n_), grab(R, n_)
    dl = [round(y - x, 1) for x, y in zip(ga, gr)]
    print(f'edge frame {n_}: render minus a-roll, mean R G B levels {dl}'
          + ('   (the render pipeline, not the effect: the reel lays the slot over the a-roll)' if max(map(abs, dl)) > 1.0 else ''))
phone = os.path.join(HERE, f'renders/{NAME}-phone.mp4')
subprocess.run([FF, '-v', 'error', '-y', '-i', R, '-vf', 'scale=720:1280:flags=lanczos', '-c:v', 'libx264', '-preset', 'slow', '-crf', '27',
                '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '128k', '-movflags', '+faststart', phone], check=True)

marks = json.load(open(os.path.join(HERE, 'work/marks.json')))
frames = sorted(set(marks['marks']) | {int(v) for v in sys.argv[1:]})
os.makedirs(os.path.join(HERE, 'renders/stills'), exist_ok=True)
os.makedirs(os.path.join(HERE, 'work/qa'), exist_ok=True)
for k, f in enumerate(marks['stills'][:3]):
    subprocess.run([FF, '-v', 'error', '-y', '-i', R, '-vf', f'select=eq(n\\,{f})', '-frames:v', '1', '-q:v', '2',
                    os.path.join(HERE, f'renders/stills/{NAME}-{k + 1}.jpg')], check=True)

TW, TH, PER = 360, 640, 6
sel = '+'.join(f'eq(n\\,{f})' for f in frames)
raw = subprocess.run([FF, '-v', 'error', '-i', R, '-vf', f"select='{sel}',scale={TW}:{TH}", '-fps_mode', 'passthrough', '-f', 'rawvideo',
                      '-pix_fmt', 'rgb24', '-'], capture_output=True).stdout
sheets = []
for s in range(0, len(frames), PER):
    part = frames[s:s + PER]
    sheet = Image.new('RGB', (TW * len(part), TH), '#111')
    for k, f in enumerate(part):
        i = s + k
        im = Image.frombytes('RGB', (TW, TH), raw[i * TW * TH * 3:(i + 1) * TW * TH * 3])
        d = ImageDraw.Draw(im)
        d.rectangle([0, 0, 64, 22], fill=(0, 0, 0))
        d.text((6, 5), f'f{f}', fill=(255, 255, 255))
        sheet.paste(im, (TW * k, 0))
    p = os.path.join(HERE, f'work/qa/sheet_{s // PER + 1}.jpg')
    sheet.save(p, quality=88)
    sheets.append(os.path.relpath(p, HERE))
print(f'phone copy: renders/{NAME}-phone.mp4\nstills: frames {marks["stills"][:3]} -> renders/stills/\nlook at: ' + ', '.join(sheets))
