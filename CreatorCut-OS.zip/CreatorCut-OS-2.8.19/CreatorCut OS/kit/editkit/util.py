"""Shared helpers: paths, running commands, probing media, JSON io, friendly output."""
from __future__ import annotations

import json
import errno
import os
import platform
import re
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]          # the toolkit folder
KIT = ROOT / "kit"
STYLES_DIR = KIT / "styles"
BRAND = ROOT / "my-brand"
USER_STYLES_DIR = BRAND / "styles"                    # styles the user teaches / customises
FONTS_DIR = KIT / "fonts"
SFX_DIR = KIT / "sfx"
DOCS_DIR = KIT / "docs"
PROJECTS = KIT / "projects"
RAW = ROOT / "my-videos" / "raw"
FINISHED = ROOT / "my-videos" / "finished"
MUSIC = BRAND / "music"
REFERENCES = BRAND / "references"
STUDIO_OUT = KIT / "studio-out"
STUDIO_PAGE = ROOT / "Studio.html"
PROFILE = BRAND / "profile.json"
BIN = KIT / "bin"                                       # portable FFmpeg + uv, installed by kit/setup/install.*

VIDEO_EXT = {".mp4", ".mov", ".m4v", ".mkv", ".webm", ".avi", ".mts"}
IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp", ".heic", ".heif"}
AUDIO_EXT = {".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg"}


# ---------------------------------------------------------------- output ----
class Fail(Exception):
    """An error with a plain-language explanation and a suggested fix."""

    def __init__(self, message: str, fix: str = ""):
        super().__init__(message)
        self.message = message
        self.fix = fix


class ProgressTimeout(Fail):
    """The child exceeded its overall or no-output deadline."""


class LockBusy(Fail):
    """A real contention condition, distinct from disk/permission/locking failures."""


def say(msg: str = "") -> None:
    print(msg, flush=True)


def step(msg: str) -> None:
    print(f"• {msg}", flush=True)


def ok(msg: str) -> None:
    print(f"✓ {msg}", flush=True)


def warn(msg: str) -> None:
    print(f"! {msg}", flush=True)


def log(msg: str) -> None:
    """Technical details go to kit/studio-out/server.log, never to the creator."""
    try:
        STUDIO_OUT.mkdir(parents=True, exist_ok=True)
        path=STUDIO_OUT/'server.log'
        with file_guard(path.with_suffix('.guard'),timeout=.1):
            if path.exists() and path.stat().st_size>2*1024*1024:path.replace(path.with_suffix('.previous.log'))
            with path.open('a',encoding='utf-8') as stream:stream.write(time.strftime('%Y-%m-%d %H:%M:%S ')+str(msg)[-65536:].rstrip()+'\n')
    except (OSError,Fail):pass


def log_exception(where: str, exception=None, *, crash=False, project=None, stage=None) -> None:
    import sys
    import traceback
    exc = exception or sys.exc_info()
    log(f"{where}:\n{''.join(traceback.format_exception(*exc))}")
    if crash and exc[0] is not None and not issubclass(exc[0],KeyboardInterrupt):
        from . import problem_reports
        tb = exc[2]
        while tb and tb.tb_next:
            tb = tb.tb_next
        code = tb.tb_frame.f_code if tb else None
        signature = f"{exc[0].__name__}:{code.co_name if code else ''}:{tb.tb_lineno if tb else 0}"
        exception_type = exc[0]
        if issubclass(exception_type, TypeError):
            reason = "crash_type"
        elif issubclass(exception_type, (KeyError, IndexError, ValueError)):
            reason = "crash_data"
        elif issubclass(exception_type, RuntimeError):
            reason = "crash_runtime"
        else:
            reason = "crash"
        area = stage or ("studio" if where.startswith(("GET", "POST", "Studio", "startup")) else "editor")
        try:
            problem_reports.automatic(project, area=area, reason=reason, trigger="crash", signature=signature)
        except Exception:
            pass  # Reporting must not break the original error path.


# ------------------------------------------------------------------ json ----
def read_json(path: Path, default=None):
    path = Path(path)
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        if default is not None:
            return default
        raise Fail(f"Missing file: {rel(path)}") from None
    except (json.JSONDecodeError, UnicodeDecodeError):
        if default is not None:
            return default
        raise Fail("CreatorCut could not read a saved file.",
                   "Your footage was kept. Ask your CreatorCut chat to check this installation.") from None


def read_object(path: Path) -> dict:
    """Best-effort read for optional metadata, never for authoritative journals."""
    value = read_json(path, default={})
    return value if isinstance(value, dict) else {}


def write_text(path: Path, text: str) -> None:
    """Replace derived skills atomically, so readers retain a complete old or new file."""
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(f'.{path.name}.{os.getpid()}.{threading.get_ident()}.tmp')
    try:
        tmp.write_text(text,encoding='utf-8')
        for attempt in range(5):
            try:
                os.replace(tmp,path);return
            except PermissionError:time.sleep(.05*(attempt+1))
        os.replace(tmp,path)
    finally:tmp.unlink(missing_ok=True)


def write_json(path: Path, data) -> None:
    """Atomic write: readers (the Studio server, other threads) never see a half-written file."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.{threading.get_ident()}.tmp")
    try:
        with tmp.open("w", encoding="utf-8") as stream:
            stream.write(json.dumps(data, indent=2, ensure_ascii=False) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        for attempt in range(5):
            try:
                os.replace(tmp, path)
                return
            except PermissionError:   # Windows: the target is briefly open in another process
                time.sleep(0.05 * (attempt + 1))
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def write_durable_json(path: Path,data) -> None:
    """Acknowledge critical jobs/preferences only after their data reaches disk."""
    path=Path(path);write_json(path,data)
    if os.name!='nt':
        fd=os.open(str(path.parent),os.O_RDONLY)
        try:os.fsync(fd)
        finally:os.close(fd)


def _darwin_process_info(pid):
    import ctypes
    # Darwin PROC_PIDTBSDINFO. Validate byte count and PID before status.
    class BSDInfo(ctypes.Structure):
        _fields_=[(n,ctypes.c_uint32) for n in ('flags','status','xstatus','pid','ppid','uid','gid','ruid','rgid','svuid','svgid','rfu')]+[('comm',ctypes.c_char*16),('name',ctypes.c_char*32)]+[(n,ctypes.c_uint32) for n in ('nfiles','pgid','jobc','tdev','tpgid')]+[('nice',ctypes.c_int32),('start_sec',ctypes.c_uint64),('start_usec',ctypes.c_uint64)]
    api=ctypes.CDLL('/usr/lib/libproc.dylib',use_errno=True)
    api.proc_pidinfo.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_uint64,ctypes.c_void_p,ctypes.c_int];api.proc_pidinfo.restype=ctypes.c_int
    info=BSDInfo();n=api.proc_pidinfo(pid,3,0,ctypes.byref(info),ctypes.sizeof(info))
    return info if n == ctypes.sizeof(info) and info.pid == pid else None


def process_zombie(pid: int) -> bool:
    """An exited, unreaped process owns no work or locks. Denial stays unknown.
    No signal or wait is performed here: ordinary Popen users keep their status.
    """
    if type(pid) is not int or pid<=0:return False
    try:
        if sys.platform=='darwin':
            import ctypes,signal
            # waitid with WNOWAIT observes only OUR child without consuming its
            # exit status. It remains available when generic process queries do not.
            libc=ctypes.CDLL(None,use_errno=True);info=ctypes.create_string_buffer(512)
            libc.waitid.argtypes=[ctypes.c_int,ctypes.c_uint,ctypes.c_void_p,ctypes.c_int];libc.waitid.restype=ctypes.c_int
            if libc.waitid(os.P_PID,pid,info,os.WEXITED|os.WNOHANG|os.WNOWAIT)==0:
                fields=(ctypes.c_int*4).from_buffer(info)
                if fields[0]==signal.SIGCHLD and fields[3]==pid and fields[2] in (1,2,3):return True
            info = _darwin_process_info(pid)
            return info is not None and info.status == 5
        if sys.platform.startswith('linux'):
            text=Path('/proc')/str(pid)/'stat';return text.read_text().rsplit(')',1)[1].strip().split()[0]=='Z'
    except (OSError,ValueError,IndexError,AttributeError):pass
    return False


def reap_exited_child(pid: int) -> bool:
    """Only collect a known zombie that is OUR child. Never signal or reap live work."""
    if type(pid) is not int or pid<=0:return False
    try:return os.waitpid(pid,os.WNOHANG)[0]==pid
    except (ChildProcessError,OSError):return False


def process_alive(pid: int) -> bool:
    """Non-destructive process query. Never use POSIX signal probes on Windows."""
    if type(pid) is not int or pid<=0:return False
    try:
        if sys.platform=='win32':
            import ctypes
            from ctypes import wintypes
            api=ctypes.WinDLL('kernel32',use_last_error=True)
            api.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];api.OpenProcess.restype=wintypes.HANDLE
            api.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)];api.GetExitCodeProcess.restype=wintypes.BOOL
            api.CloseHandle.argtypes=[wintypes.HANDLE];api.CloseHandle.restype=wintypes.BOOL
            handle=api.OpenProcess(0x1000,False,pid)
            if not handle:return ctypes.get_last_error()==5 # unknown access is conservatively busy
            try:
                code=wintypes.DWORD()
                return not api.GetExitCodeProcess(handle,ctypes.byref(code)) or code.value==259
            finally:api.CloseHandle(handle)
        os.kill(pid,0);return not process_zombie(pid)
    except PermissionError:return True
    except (OSError,AttributeError):return False


def process_identity(pid: int) -> str:
    """Creation identity, not just a reusable PID. Query-only access on Windows."""
    if type(pid) is not int or pid<=0:return ''
    try:
        if sys.platform=='win32':
            import ctypes
            from ctypes import wintypes
            api=ctypes.WinDLL('kernel32',use_last_error=True)
            api.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];api.OpenProcess.restype=wintypes.HANDLE
            api.GetProcessTimes.argtypes=[wintypes.HANDLE,*([ctypes.POINTER(wintypes.FILETIME)]*4)];api.GetProcessTimes.restype=wintypes.BOOL
            api.CloseHandle.argtypes=[wintypes.HANDLE];api.CloseHandle.restype=wintypes.BOOL
            handle=api.OpenProcess(0x1000,False,pid) # PROCESS_QUERY_LIMITED_INFORMATION
            if not handle:return ''
            try:
                created,ended,kernel,user=[wintypes.FILETIME() for _ in range(4)]
                if not api.GetProcessTimes(handle,ctypes.byref(created),ctypes.byref(ended),ctypes.byref(kernel),ctypes.byref(user)):return ''
                return 'win:'+str((created.dwHighDateTime<<32)|created.dwLowDateTime)
            finally:api.CloseHandle(handle)
        if sys.platform=='darwin':
            info = _darwin_process_info(pid)
            if info is not None and info.start_sec:
                stamp = time.localtime(info.start_sec)
                # Match the format in the earlier installations' ownership records.
                return time.strftime('%a %b ', stamp) + str(stamp.tm_mday).rjust(2) + time.strftime(' %H:%M:%S %Y', stamp)
        return subprocess.check_output(['ps','-p',str(pid),'-o','lstart='],text=True,timeout=3).strip()
    except (OSError,subprocess.SubprocessError,AttributeError):return ''


def app_path(path):
    """Resolve a moved app's old absolute media paths without changing requests."""
    path=Path(path)
    if not path.is_absolute():return ROOT/path
    location=read_json(KIT/'runtime-location.json',default={})
    for old in location.get('previous_roots',[]):
        base=Path(old)
        if path.is_relative_to(base):
            candidate=ROOT/path.relative_to(base)
            if candidate.resolve().is_relative_to(ROOT.resolve()):return candidate
    return path


def rel(path) -> str:
    try:
        return str(Path(path).resolve().relative_to(ROOT))
    except Exception:
        return str(path)


def slugify(text: str) -> str:
    s = re.sub(r"[^a-zA-Z0-9]+", "-", text).strip("-").lower()
    return s[:48] or "video"


# --------------------------------------------------------------- system ----
def os_name() -> str:
    s = platform.system()
    return {"Darwin": "mac", "Windows": "windows"}.get(s, "linux")


def which(name: str) -> str | None:
    own = BIN / (name + (".exe" if os_name() == "windows" else ""))
    if own.is_file():
        return str(own)
    for candidate in (BIN/name/'bin'/name, BIN/name/(name+'.exe')):
        if candidate.is_file():return str(candidate)
    found = shutil.which(name)
    if found:
        return found
    # common install spots that may not be on PATH inside an app-launched shell
    candidates = []
    if os_name() == "mac":
        candidates = [f"/opt/homebrew/bin/{name}", f"/usr/local/bin/{name}",
                      f"/opt/homebrew/opt/ffmpeg-full/bin/{name}", f"/usr/local/opt/ffmpeg-full/bin/{name}"]
    elif os_name() == "windows":
        local = os.environ.get("LOCALAPPDATA", "")
        candidates = [os.path.join(local, "Microsoft", "WinGet", "Links", name + ".exe")]
    for c in candidates:
        if c and os.path.exists(c):
            return c
    return None


def ffmpeg_bin() -> str:
    own = BIN / ("ffmpeg.exe" if os_name() == "windows" else "ffmpeg")
    if own.exists():
        return str(own)
    # ffmpeg-full on mac is keg-only, so prefer it when present
    for c in ["/opt/homebrew/opt/ffmpeg-full/bin/ffmpeg", "/usr/local/opt/ffmpeg-full/bin/ffmpeg"]:
        if os.path.exists(c):
            return c
    p = which("ffmpeg")
    if not p:
        raise Fail("FFmpeg isn't installed yet.", "Run the setup skill: it installs everything automatically.")
    return p


def ffprobe_bin() -> str:
    own = BIN / ("ffprobe.exe" if os_name() == "windows" else "ffprobe")
    if own.exists():
        return str(own)
    for c in ["/opt/homebrew/opt/ffmpeg-full/bin/ffprobe", "/usr/local/opt/ffmpeg-full/bin/ffprobe"]:
        if os.path.exists(c):
            return c
    p = which("ffprobe")
    if not p:
        raise Fail("ffprobe isn't installed yet (it comes with FFmpeg).", "Run /setup and Claude will install it for you.")
    return p


def run(cmd: list[str], quiet: bool = True, check: bool = True, label: str = "", cwd=None, timeout: float = 3600, env=None) -> subprocess.CompletedProcess:
    """Run a command; on failure raise a Fail with the useful tail of the error output. The direct child command has a timeout;
    timeout failures are reported for recovery. Progress-runner process groups have separate cleanup."""
    # Exact metadata-only invocations cannot encode video or consume a render
    # slot. In particular doctor() must remain readable while a render owns it.
    metadata_args=tuple(str(x) for x in cmd[1:])
    metadata=metadata_args in (('-version',),('-filters',),('-hide_banner','-version'),('-hide_banner','-filters'))
    if Path(cmd[0]).stem.lower() == 'ffmpeg' and not metadata:
        from .resources import heavy
        with heavy(label or 'Processing video'):
            return _run_unlocked(cmd, quiet, check, label, cwd, timeout, env)
    return _run_unlocked(cmd, quiet, check, label, cwd, min(timeout,10) if metadata and Path(cmd[0]).stem.lower()=='ffmpeg' else timeout, env)


def _run_unlocked(cmd, quiet=True, check=True, label='', cwd=None, timeout=3600, env=None):
    t0 = time.time()
    proc = spawn(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding='utf-8', errors='replace', cwd=str(cwd) if cwd else None, env=env)
    try:
        stdout, stderr = proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        cleaned = stop_process(proc)
        try: proc.communicate(timeout=2)
        except subprocess.TimeoutExpired: cleaned = False
        ending = 'was stopped' if cleaned else 'could not be fully stopped; see the engine log'
        raise Fail(f"{label or Path(cmd[0]).name} exceeded {timeout:g} seconds and {ending}.",
                   "Your files are kept. Check the log, then retry the interrupted step.")
    finally:
        stop_process(proc)
        if proc.stdout: proc.stdout.close()
        if proc.stderr: proc.stderr.close()
    proc = subprocess.CompletedProcess(cmd, proc.returncode, stdout, stderr)
    if check and proc.returncode != 0:
        tail = "\n".join((proc.stderr or proc.stdout or "").strip().splitlines()[-12:])
        error = Fail(f"{label or Path(cmd[0]).name} failed:\n{tail}",
                     "Read the last lines above. If it mentions a missing file or font, run `edit.py doctor`.")
        error.exit_code = proc.returncode
        raise error
    if not quiet:
        say(proc.stdout)
    if label:
        ok(f"{label} ({time.time() - t0:.1f}s)")
    return proc


_progress_state = {}
_progress_lock = threading.Lock()


def activity(detail: str = "", percent: float | None = None) -> None:
    """Update what the engine is doing right now (shown live in the Studio): a short line about the real work
    and, when known, the percentage of the current step."""
    from . import activity_store
    import math,json
    if percent is not None:
        try:percent=float(percent)
        except (TypeError,ValueError):percent=None
        if percent is not None and not math.isfinite(percent):percent=None
    if percent is not None:percent=max(0,min(100,percent))
    stage=str(detail)[:120]
    key=(os.getpid(),threading.get_ident(),str(activity_store._current.get()))
    now=time.monotonic()
    with _progress_lock:
        old=_progress_state.get(key)
        force=not old or stage!=old[1] or (percent is None)!=(old[2] is None) or (percent in (0,100) and percent!=old[2])
        if not force and 0<=now-old[0]<.2:return
        if len(_progress_state)>128:_progress_state.clear()
        _progress_state[key]=(now,stage,percent)
    activity_store.detail(stage, percent)
    print('CREATORCUT_PROGRESS '+json.dumps({'schema':1,'stage':stage,'percent':percent},allow_nan=False),flush=True)



def process_group_options() -> dict:
    return {"start_new_session": True} if os.name != "nt" else {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP}


def spawn(cmd, **kwargs):
    kwargs.setdefault("stdin", subprocess.DEVNULL)
    kwargs.update(process_group_options())
    if os.name != 'nt':
        from .resources import inherited_fds
        from . import chat_execution
        held = inherited_fds()+chat_execution.inherited_fds()
        if held: kwargs['pass_fds'] = tuple(set(kwargs.get('pass_fds', ())) | set(held))
    proc = subprocess.Popen(cmd, **kwargs)
    proc._creatorcut_isolated = os.name != "nt"
    proc._creatorcut_birth = process_identity(proc.pid)
    return proc


def stop_process(proc) -> bool:
    """Stop only the child/group created by spawn, allowing ten seconds to exit."""
    import signal
    isolated = bool(getattr(proc, '_creatorcut_isolated', False))
    birth = getattr(proc, '_creatorcut_birth', '')
    clean = True
    if isolated:
        current = process_identity(proc.pid)
        if birth and current and current != birth:
            log(f'Cleanup skipped reused process id {proc.pid}.')
            return False
        if not birth: isolated = False  # Direct Popen child only; no inferred group ownership.
    def group_alive():
        nonlocal clean
        if not isolated: return False
        current = process_identity(proc.pid)
        if current and current != birth:
            clean=False
            return False
        try: os.killpg(proc.pid, 0); return True
        except ProcessLookupError: return False
        except PermissionError as error:
            clean=False;log(f'Cannot verify owned group {proc.pid}: {error}');return False
    def stop(sig):
        nonlocal clean
        if isolated:
            current = process_identity(proc.pid)
            if current and current != birth:
                clean=False;log(f'Cleanup skipped reused process id {proc.pid}.');return
            try: os.killpg(proc.pid, sig)
            except ProcessLookupError: return
            except PermissionError as error:
                clean=False;log(f'Process-group cleanup {proc.pid}: {error}')
        if proc.poll() is None:
            try: proc.terminate() if sig == signal.SIGTERM else proc.kill()
            except ProcessLookupError: pass
            except PermissionError as error:
                clean=False;log(f'Process cleanup {proc.pid}: {error}')
    if proc.poll() is None or isolated:
        deadline=time.monotonic()+10
        stop(signal.SIGTERM)
        try: proc.wait(timeout=max(.01,deadline-time.monotonic()))
        except subprocess.TimeoutExpired: pass
        # Parent exit is not proof that its render/browser children exited.
        while group_alive() and time.monotonic()<deadline:
            time.sleep(min(.1,max(0,deadline-time.monotonic())))
        if proc.poll() is None or group_alive():
            stop(getattr(signal,'SIGKILL',9))
            try: proc.wait(timeout=3)
            except subprocess.TimeoutExpired: clean=False
    return clean


def progress_lines(proc, timeout=3600, idle_timeout=300, on_tick=None):
    """Read a child without an unbounded pipe wait. No-output deadline is diagnostic."""
    import queue
    q = queue.Queue()
    def read():
        try:
            for line in proc.stdout:
                q.put(line)
        finally:
            q.put(None)
    reader = threading.Thread(target=read, daemon=True)
    reader.start()
    started = last = time.monotonic()
    disk_checked=started
    finished = False
    try:
        while True:
            now = time.monotonic()
            if now-disk_checked>=10:
                disk_checked=now
                try:remaining_space=shutil.disk_usage(ROOT).free
                except OSError:remaining_space=None
                if remaining_space is not None and remaining_space<512*1024*1024:
                    raise Fail('This computer is nearly out of working space. The current step was stopped safely.','Free disk space, then retry this step. Originals and previously saved videos are kept.')
            if now-started > timeout:
                raise ProgressTimeout("This step exceeded its time limit and was stopped safely.")
            if now-last > idle_timeout:
                raise ProgressTimeout("This step stopped reporting progress and was stopped safely.",
                                      "Inspect its log, fix the cause, then retry the interrupted step. Existing files are kept.")
            if on_tick:
                on_tick()
            try:
                line = q.get(timeout=min(.5, max(.01, idle_timeout/4)))
            except queue.Empty:
                continue
            if line is None:
                break
            last = time.monotonic()
            yield line
        remaining = max(.01, min(timeout-(time.monotonic()-started), idle_timeout-(time.monotonic()-last)))
        try:
            proc.wait(timeout=remaining)
            finished = True
        except subprocess.TimeoutExpired:
            raise ProgressTimeout("This step exceeded its time limit.", "Inspect its log and retry the step.")
    finally:
        if not finished:
            stop_process(proc)
        reader.join(timeout=1)
        if proc.stdout and not reader.is_alive():
            proc.stdout.close()

def atomic_encode(cmd, total=None, label='', detail='', expected=None, timeout=3600):
    """Verify a private sibling output before replacing any last good movie."""
    import tempfile,errno
    dest=Path(cmd[-1]);dest.parent.mkdir(parents=True,exist_ok=True)
    if expected is None:
        source=cmd[cmd.index('-i')+1];expected=probe(Path(source))
    fd,name=tempfile.mkstemp(prefix=dest.stem+'-',suffix='.pending'+dest.suffix,dir=dest.parent);os.close(fd);temp=Path(name)
    try:
        args=[*cmd[:-1],str(temp)]
        result=run_progress(args,total,label=label,detail=detail,timeout=timeout) if total is not None else run(args,timeout=timeout)
        info=probe(temp)
        duration=total if total is not None else expected.get('duration')
        if expected.get('frame_count') is not None:
            if info.get('frame_count') != expected['frame_count']:raise Fail('The new video is missing planned frames. Your previous movie is kept.','Retry this saved cut; if it repeats, share the cut log in this chat.')
            measured = info.get('video_duration') or info['duration']
            if abs(measured - expected['frame_count']/expected['fps']) > 1/expected['fps'] + .001:raise Fail('The new video timing did not match its frames. Your previous movie is kept.','Retry this saved cut and check its source timing.')
        elif duration is not None and abs(info['duration']-duration)>.1:raise Fail('The new video did not finish completely. Your previous movie is kept.','Retry this saved step; if it repeats, share its log in this chat.')
        if any(expected.get(k) is not None and info.get(k)!=expected[k] for k in ('width','height','has_audio')):raise Fail('The new video did not match its planned frame or sound. Your previous movie is kept.','Retry this saved step after checking the source.')
        with temp.open('rb') as f:os.fsync(f.fileno())
        os.replace(temp,dest);return result
    except OSError as error:
        if error.errno==errno.ENOSPC:raise Fail('Your Mac ran out of space. The previous video is safe.','Free some space, then retry this saved step.') from error
        raise
    except Fail as error:
        if any(x in error.message.lower() for x in ('no space left','disk full','not enough space')):raise Fail('Your Mac ran out of space. The previous video is safe.','Free some space, then retry this saved step.') from error
        raise
    finally:temp.unlink(missing_ok=True)


def run_progress(cmd: list[str], total: float, label: str = "", cwd=None, detail: str = "", timeout=3600, idle_timeout=300) -> subprocess.CompletedProcess:
    """Run FFmpeg and report real progress (from -progress) to the Studio."""
    from .resources import heavy
    with heavy(detail or label or 'Processing video'):
        return _run_progress_unlocked(cmd, total, label, cwd, detail, timeout, idle_timeout)


def _run_progress_unlocked(cmd, total, label='', cwd=None, detail='', timeout=3600, idle_timeout=300):
    full = cmd[:1] + ["-progress", "pipe:1", "-nostats"] + cmd[1:]
    proc = spawn(full, cwd=str(cwd) if cwd else None, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            text=True, encoding="utf-8", errors="replace")
    err: list[str] = []
    import threading as _th
    def _drain():
        try:
            for line in proc.stderr:  # type: ignore[union-attr]
                err.append(line)
                del err[:-40]
        finally:
            # The reader owns this pipe. Close it after EOF on both successful
            # encodes and stopped jobs, without racing a live blocking read.
            if proc.stderr:proc.stderr.close()
    t = _th.Thread(target=_drain, daemon=True)
    t.start()
    t0, last = time.time(), -1.0
    frame = 0
    for line in progress_lines(proc, timeout, idle_timeout):
        k, _, v = line.strip().partition("=")
        if k == "frame":
            frame = int(v or 0)
        if k in ("out_time_us", "out_time_ms") and v.isdigit() and total > 0:
            pct = int(v) / 1e6 / total * 100
            if pct - last >= 1:
                last = pct
                activity(f"{detail} · frame {frame}" if detail else "", pct)
    proc.wait()
    t.join(timeout=2)
    if proc.returncode != 0:
        tail = "\n".join("".join(err).strip().splitlines()[-12:])
        error = Fail(f"{label or Path(cmd[0]).name} failed:\n{tail}",
                     "Read the last lines above. If it mentions a missing file or font, run `edit.py doctor`.")
        error.exit_code = proc.returncode
        raise error
    activity("", 100)
    if label:
        ok(f"{label} ({time.time() - t0:.1f}s)")
    return subprocess.CompletedProcess(full,proc.returncode,"","".join(err))


def ffmpeg_major() -> int:
    out = run([ffmpeg_bin(), "-hide_banner", "-version"]).stdout
    m = re.search(r"ffmpeg version n?(\d+)", out)
    if m:
        return int(m.group(1))
    return 7 if re.search(r"ffmpeg version N-", out) else 6   # git builds are recent


def filter_script_args(script_path: Path) -> list[str]:
    """Pass a long filter graph from a file (avoids command-length limits on Windows)."""
    if ffmpeg_major() >= 7:
        return ["-/filter_complex", str(script_path)]
    return ["-filter_complex_script", str(script_path)]


def ffmpeg_has_filter(name: str) -> bool:
    out = run([ffmpeg_bin(), "-hide_banner", "-filters"], check=False).stdout
    return re.search(rf"^\s*\S+\s+{re.escape(name)}\s", out, re.M) is not None


# ---------------------------------------------------------------- media ----
def frame_probe(binary, path):
    """Count decoded frames on the first actual top-level video stream."""
    result = subprocess.run([str(binary), "-v", "error", "-count_frames", "-show_streams",
                             "-of", "json", str(path)], capture_output=True, text=True,
                            check=True, timeout=900)
    streams = json.loads(result.stdout).get("streams", [])
    video = next((row for row in streams if row.get("codec_type") == "video"
                  and not (row.get("disposition") or {}).get("attached_pic")), {})
    count = video.get("nb_read_frames")
    if count in (None, "N/A"):
        count = video.get("nb_frames")
    return dict(video, frames=int(count) if str(count).isdigit() else 0)


def probe(path: Path, timeout: float = 20) -> dict:
    """Duration, display size (rotation applied), fps, HDR flag and audio presence."""
    path = app_path(path)
    if not path.exists():
        raise Fail(f"The source file is missing: {path.name}.", "Reconnect that file or add it again in Studio. Your saved edits are kept.")
    out = run([ffprobe_bin(), "-v", "error", "-print_format", "json", "-show_format", "-show_streams", str(path)],
              label="", timeout=timeout).stdout
    data = json.loads(out)
    v = next((s for s in data["streams"] if s.get("codec_type") == "video"), None)
    a = next((s for s in data["streams"] if s.get("codec_type") == "audio"), None)
    if v is None:
        raise Fail(f"{path.name} has no video track.")
    w, h = int(v.get("width", 0)), int(v.get("height", 0))
    rot = 0
    for sd in v.get("side_data_list", []) or []:
        if "rotation" in sd:
            rot = int(float(sd["rotation"]))
    if "rotate" in (v.get("tags") or {}):
        rot = int(v["tags"]["rotate"])
    if abs(rot) % 180 == 90:
        w, h = h, w
    fr = v.get("avg_frame_rate") or v.get("r_frame_rate") or "30/1"
    try:
        num, den = fr.split("/")
        fps = float(num) / float(den) if float(den) else 30.0
    except Exception:
        fps = 30.0
    try:dur = float(data["format"].get("duration") or v.get("duration") or 0)
    except (TypeError,ValueError):dur=0
    transfer = (v.get("color_transfer") or "").lower()
    hdr = transfer in ("arib-std-b67", "smpte2084")
    try:video_duration=float(v.get("duration") or 0)
    except (ValueError,TypeError):video_duration=0
    frame_count=int(v["nb_frames"]) if str(v.get("nb_frames","")).isdigit() else None
    return {"video_duration":video_duration,"frame_count":frame_count,"path": str(path), "duration": dur, "width": w, "height": h, "fps": round(fps, 3),
            "has_audio": a is not None, "hdr": hdr, "transfer": transfer,
            "codec": v.get("codec_name"), "pix_fmt": v.get("pix_fmt"),
            "color_range":v.get("color_range"), "colorspace":v.get("color_space"), "color_primaries":v.get("color_primaries")}


def fmt_time(t: float) -> str:
    t = max(0.0, t)
    m, s = divmod(t, 60)
    return f"{int(m)}:{s:04.1f}"


def newest_raw_video() -> Path | None:
    vids = [p for p in RAW.glob("*") if p.suffix.lower() in VIDEO_EXT]
    return max(vids, key=lambda p: p.stat().st_mtime) if vids else None


def load_profile() -> dict:
    return read_json(PROFILE, default={})


PROFILE_LOCK = threading.RLock()


def save_profile(p: dict) -> None:
    write_json(PROFILE, p)


def update_profile(fn) -> dict:
    """Read-modify-write the profile under a lock (the Studio server saves from several threads)."""
    with PROFILE_LOCK, file_guard(PROFILE.parent / '.profile.guard', 'Your settings are saving another change.', timeout=5):
        prof = load_profile()
        fn(prof)
        save_profile(prof)
        return prof


def project_dir(name: str) -> Path:
    if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_-]{0,80}', name or ''):
        raise Fail('Invalid project name.')
    PROJECTS.mkdir(parents=True, exist_ok=True)
    d = PROJECTS / name
    if not d.exists():
        existing = ", ".join(sorted(p.name for p in PROJECTS.iterdir() if p.is_dir() and not p.name.startswith("_"))) or "none yet"
        raise Fail(f"There's no project called '{name}'.", f"Projects: {existing}. Start one with `edit.py new`.")
    return d


def latest_project() -> str | None:
    PROJECTS.mkdir(parents=True, exist_ok=True)
    dirs = [p for p in PROJECTS.iterdir() if p.is_dir() and not p.name.startswith("_") and (p / "project.json").exists()]
    if not dirs:
        return None
    return max(dirs, key=lambda p: (p / "project.json").stat().st_mtime).name


from contextlib import contextmanager

@contextmanager
def file_guard(path: Path, message='This operation is already running.', timeout=0, *, retain_in_children=False):
    """Kernel lock: a process crash releases ownership without stale PID files.

    Keep the inode after unlocking, so other processes cannot lock a different
    file under the same path. An existing guard file is not an active lock.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    stream = path.open('a+b')
    acquired = False
    try:
        deadline = time.monotonic() + max(0, float(timeout))
        while not acquired:
            try:
                if os.name == 'nt':
                    import msvcrt
                    if stream.seek(0, os.SEEK_END) == 0:
                        stream.write(b'\0');stream.flush()
                    stream.seek(0)
                    msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                acquired = True
            except OSError as error:
                if error.errno not in (errno.EAGAIN,errno.EACCES,errno.EWOULDBLOCK):
                    raise Fail('The project lock could not be accessed.', 'Check the project folder permissions and local disk before retrying.') from error
                if time.monotonic() >= deadline:
                    raise LockBusy(message, 'Wait for that operation to finish, then try again.') from error
                time.sleep(min(.02, max(0, deadline-time.monotonic())))
        yield stream
    finally:
        try:
            if acquired and not (retain_in_children and os.name != "nt"):
                if os.name == 'nt':
                    import msvcrt
                    stream.seek(0);msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
        finally:
            stream.close()


import contextvars
_project_locks = contextvars.ContextVar('creatorcut_project_locks', default=frozenset())

@contextmanager
def project_lock(project: Path, *, _nested=False, heavy_work=True):
    from .resources import heavy
    key = str(Path(project).resolve())
    if key in _project_locks.get():
        if not _nested: raise Fail("This project is already rendering.")
        yield
        return
    from contextlib import nullcontext
    with heavy() if heavy_work else nullcontext():
        token = _project_locks.set(_project_locks.get() | {key})
        try:
            with _project_lock_once(Path(project)):
                yield
        finally:
            _project_locks.reset(token)

@contextmanager
def _project_lock_once(project: Path):
    """One candidate writer across processes, with automatic crash recovery."""
    with file_guard(project / '.render.guard', 'This project is already rendering.'):
        legacy = project / '.render.lock'
        if legacy.exists():
            try:
                old = json.loads(legacy.read_text())
                pid = int(old.get('pid') or 0)
            except (OSError, ValueError, TypeError, AttributeError):
                pid = 0
            alive = False
            if pid > 0:
                try:
                    alive = process_alive(pid)
                except ProcessLookupError:
                    pass
                except OSError:
                    alive = True
            if alive or (pid == 0 and 0 <= time.time() - legacy.stat().st_mtime < 5):
                raise Fail('This project is already rendering.', 'Wait for that render before starting another.')
            legacy.unlink(missing_ok=True)
        yield


def balanced_sum(expressions):
    """Bound FFmpeg expression depth without dropping any selected frame or cut."""
    rows=list(expressions)
    if not rows:return '0'
    while len(rows)>1:
        rows=['('+rows[n]+'+'+rows[n+1]+')' if n+1<len(rows) else rows[n] for n in range(0,len(rows),2)]
    return rows[0]
