"""CreatorCut OS editing engine."""
