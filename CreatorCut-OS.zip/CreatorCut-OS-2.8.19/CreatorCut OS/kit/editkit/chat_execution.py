"""Read-only compatibility for older core modules. Customer work is in editor.director."""
from contextlib import contextmanager
def mode():return 'chat'
def paste_only():return False
def inherited_fds():return ()
@contextmanager
def command_guard(p):
 from . import util
 from editor import director
 with util.file_guard(p/'.recipe-command.guard'):
  with director.lock(director.OUT/'.queue.guard',True):
   status=director.status(p)
   if status.get('state')=='stopped':
    raise util.Fail('This attempt was stopped. Start it again from Studio.')
   if status.get('resume_here') or (status.get('owner') and status['owner']!=director.chat_owner()):
    raise util.Fail('This edit belongs to another CreatorCut chat. Continue there.')
  yield
