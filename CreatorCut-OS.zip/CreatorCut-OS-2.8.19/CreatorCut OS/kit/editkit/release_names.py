"""Reject unresolved function globals in first-party Python before packaging."""
import builtins
from pathlib import Path
import symtable

IMPLICIT = set(vars(builtins)) | {
    "__file__", "__name__", "__doc__", "__package__", "__spec__",
    "__loader__", "__builtins__", "__path__", "__debug__", "__class__",
}


def _functions(table):
    for child in table.get_children():
        if child.get_type() == "function":
            yield child
        yield from _functions(child)


def errors(root):
    paths = [root / "edit.py"]
    for area in ("editor", "editkit", "setup", "tools", "style-library/scripts"):
        paths.extend(path for path in (root / "kit" / area).rglob("*.py")
                     if "__pycache__" not in path.parts)
    issues = []
    for path in sorted(paths):
        label = path.relative_to(root)
        try:
            source = path.read_text(encoding="utf-8")
            module = symtable.symtable(source, str(label), "exec")
        except (OSError, SyntaxError, ValueError) as error:
            issues.append(f"{label}: could not check Python source ({error})")
            continue
        if "import *" in source:
            continue
        defined = IMPLICIT | {symbol.get_name() for symbol in module.get_symbols()
                              if symbol.is_assigned() or symbol.is_imported() or symbol.is_namespace()}
        functions = list(_functions(module))
        defined.update(symbol.get_name() for function in functions for symbol in function.get_symbols()
                       if symbol.is_declared_global() and (symbol.is_assigned() or symbol.is_imported()))
        for function in functions:
            for symbol in function.get_symbols():
                if (symbol.is_global() and symbol.is_referenced() and
                        not symbol.is_assigned() and not symbol.is_imported() and
                        symbol.get_name() not in defined):
                    issues.append(f"{label}:{function.get_lineno()}: {function.get_name()} uses undefined name {symbol.get_name()!r}")
    return sorted(set(issues))
