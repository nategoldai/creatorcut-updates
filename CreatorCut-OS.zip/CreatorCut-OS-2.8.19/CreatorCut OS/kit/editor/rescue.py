"""Bounded recovery for the visible chat's current request."""
import errno
import re
from pathlib import Path

from editkit import diagnostics, problem_reports, telemetry, util

ACTIONS = {
    "remux": {"ingest", "assemble", "probe"},
    "transcribe-chunked": {"words"},
    "reference-sheet": {"reference"},
    "effect-simple": {"fx-new", "fx-run", "fx-add", "fx-check", "render"},
    "no-cutout": {"layout", "fx-new", "fx-run"},
    "render-safe": {"render", "base"},
    "captions-basic": {"build", "init"},
    "no-music": {"music"},
    "free-space": set(),
}
CHANGES = {
    "effect-simple": "The selected effect would be simplified.",
    "no-cutout": "The graphic would appear in front instead of behind the subject.",
    "captions-basic": "The selected captions would switch to a basic style.",
    "no-music": "The video would finish without the selected music.",
}


def tool_symptom(output):
    """A recognized tool symptom without forwarding the tool's raw output."""
    patterns = (
        ("disk_full", r"no space left on device|disk quota exceeded"),
        ("access_denied", r"permission denied|operation not permitted"),
        ("missing_movie_index", r"moov atom not found"),
        ("missing_audio", r"stream map .* matches no streams|output file does not contain any stream"),
        ("invalid_media", r"invalid data found when processing input"),
        ("unsupported_decoder", r"decoder .* not found|no decoder found"),
        ("browser_launch", r"failed to launch (?:the )?browser|could not launch (?:the )?browser"),
        ("browser_navigation", r"navigation timeout|net::err_|ECONNREFUSED|ECONNRESET|page\.goto.*(?:timed? out|failed)"),
        ("browser_capture", r"unable to capture screenshot|captureScreenshot.*(?:timed? out|failed)"),
        ("browser_crash", r"thermal_state_observer_mac|target closed|browser process exited"),
    )
    return next((name for name, pattern in patterns if re.search(pattern, output, re.I)), "unclassified")


def classify(step, error, tail):
    if isinstance(error, OSError) and error.errno == errno.ENOSPC or re.search(r"no space left|free some space", tail, re.I):
        return "machine", "storage", "free-space"
    if re.search(r"permission denied|operation not permitted|full access", tail, re.I):
        return "host", "access", None
    if re.search(r"file not found|no such file|add your footage again", tail, re.I):
        return "input", "missing_input", None
    if step in ACTIONS["remux"] and re.search(r"unsupported timecode track|track layout.*not supported", tail, re.I):
        return "input", "source", "remux"
    if step in ("base", "render", "snapshot") and tool_symptom(tail).startswith("browser_"):
        return "app", "browser", "render-safe" if step in ACTIONS["render-safe"] else None
    symptom = diagnostics.failure_facts(tail).get("detail_code")
    if symptom in ("invalid_review_time", "invalid_data", "missing_asset", "invalid_code"):
        return "app", "creative_correction_needed", None
    if symptom == "missing_module":
        return "app", "video_tool_missing", None
    if symptom == "missing_file":
        return "input", "missing_input", None
    if step in ("snapshot", "base", "render", "check"):
        return "app", "unknown", None
    if step == "words":
        return "app", "unknown", "transcribe-chunked"
    if step == "reference":
        return "app", "unknown", "reference-sheet"
    if step == "music":
        return "app", "unknown", "retry"
    if step in ACTIONS["captions-basic"] and re.search(r"caption|font", tail, re.I):
        return "app", "unknown", "captions-basic"
    if step == "layout":
        return "app", "unknown", "no-cutout"
    if step.startswith("fx-"):
        return "app", "unknown", "effect-simple"
    return "app", "unknown", "retry"


def consume(p, step):
    from . import director as d
    status = d.status(p)
    attempts = dict(status.get("rescue_attempts", {}))
    count = attempts.get(step, 0)
    if count >= 2:
        raise d.Needed("Two recovery attempts were used. Your saved versions are safe. Use Send a problem report in Studio.")
    attempts[step] = count + 1
    d.put(p, "working", rescue_attempts=attempts, rescuing=True, step_label="Fixing a small problem…")
    diagnostics.record(p.name, "rescue_used", stage=step, request_id=status.get("request_id"))
    telemetry.event("rescue_used", project=p.name, request=status.get("request_id"), step=step)


def creative_correction(p, step, error, command_args):
    from . import director as d
    status = d.status(p)
    corrections = dict(status.get("creative_corrections", {}))
    count = corrections.get(step, 0)
    remaining = 2 - count
    if not isinstance(error, d.CreativeCheckNeeded) or remaining <= 0:
        return False
    # A repairable build/lint result is part of editing. The chat changes its
    # creative files before trying again, with no customer prompt or incident.
    corrections[step] = count + 1
    d.put(p, "working", step_label="Adjusting your edit", creative_corrections=corrections,
          failed_step=None, rescuing=False, command_pid=None, eta=None,
          rescue_failure={"step": step, "action": "retry", "args": command_args, "remaining": remaining})
    return True


def failed(p, step, error, command_args):
    from . import director as d
    if isinstance(error, d.StepNeedsInput):
        # Preflight failures must never be classified using a previous attempt's log.
        failure_class, reason, action = error.failure_class, error.reason, None
    elif isinstance(error, d.CreativeCheckNeeded):
        failure_class, reason, action = "app", "creative_correction_needed", None
    else:
        log = p / "work" / ("last-" + step + ".log")
        with log.open("rb") if log.is_file() else open("/dev/null", "rb") as stream:
            stream.seek(0, 2)
            stream.seek(max(0, stream.tell() - 65536))
            tail = stream.read().decode(errors="replace")
        failure_class, reason, action = classify(step, error, str(error) + "\n" + tail)
    status = d.status(p)
    if isinstance(error, d.IngestInputNeeded) and error.symptom == "track_layout" and error.clip and not status.get("rescue_attempts", {}).get(step):
        d.put(p, rescue_failure={"step": step, "action": "remux", "reason": "source", "args": command_args})
        try:
            return run(p, "rescue", ["remux", "--clip", f"c{error.clip}"])
        except (d.Needed, OSError):
            d.put(p, "needs_you", step_label=str(error), question=str(error), rescuing=False)
            status = d.status(p)
    if status.get("rescue_override", {}).get("no_music") and step == "music":
        action = None
    signature = f"final:{status.get('request_id')}:{step}"
    structured = telemetry.incident_protocol()
    first = None
    if structured:
        first = problem_reports.automatic(p, area=step, reason=reason, failure_class=failure_class, signature=signature)
        if first:
            d.put(p, problem_report_code=first["code"])
            attempt = status.get("rescue_attempts", {}).get(step, 0)
            if attempt:
                problem_reports.record_outcome(status.get("request_id"), "retry_failed", step=step, attempt=attempt)
    if not status.get("rescuing") and action in ("retry", "render-safe") and not status.get("rescue_attempts", {}).get(step):
        consume(p, step)
        print("Fixing a small problem…")
        return d.main([step, *command_args])
    remaining = 2 - status.get("rescue_attempts", {}).get(step, 0)
    failure = {"step": step, "action": action, "reason": reason,
               "class": failure_class, "remaining": remaining, "args": command_args}
    if step == "publish":
        candidate = command_args[0] if command_args else "renders/final.mp4"
        failure["render_sha256"] = status.get("rendered_artifacts", {}).get(candidate, {}).get("sha256")
    d.put(p, rescuing=False, rescue_failure=failure)
    if action and remaining:
        instructions = f"retry {step}" if action == "retry" else f"rescue {action}"
        if action == "remux":
            raw = d.read(p / "creator-request.json").get("files", {}).get("raw", [])
            instructions += " --clip c1" if len(raw) == 1 else " --clip <affected clip ID>"
            if len(raw) != 1:
                print("Check the local step details for the affected clip before remuxing.")
        if action in CHANGES:
            print(CHANGES[action] + " Ask the customer first, then add --accept if they agree.")
        print(f"CREATORCUT RESCUE: step={step} ({failure_class}). {problem_reports.REASONS[reason]} "
              f"Run edit.py {instructions}. Tries left: {remaining}.")
    else:
        telemetry.event("edit_failed", project=p.name, request=status.get("request_id"), step=step,
                        details={"failure_class": failure_class})
        report = first if structured else problem_reports.automatic(
            p, area=step, reason=reason, failure_class=failure_class, signature=signature)
        if report:
            problem_reports.record_outcome(status.get("request_id"), "needs_customer", step=step)
        if isinstance(error, d.IngestInputNeeded):
            if report:
                d.put(p, problem_report_code=report["code"])
            return None
        if remaining <= 0:
            message = "This step still could not finish. Your saved versions are safe. Use Send a problem report in Studio."
            d.put(p, "needs_you", step_label="This step could not finish", question=message,
                  problem_report_code=report["code"] if report else None)
            print(message)
            return 1
        if report:
            d.put(p, problem_report_code=report["code"])
        print("Your saved versions are safe. Use Send a problem report in Studio.")
    return None


def ingest_files(p, files):
    from . import director as d
    replacements = d.status(p).get("rescue_inputs", {})
    return [replacements.get(file, file) for file in files]


def run(p, command, args):
    from . import director as d
    status = d.status(p)
    failed_step = status.get("failed_step")
    rescue = status.get("rescue_failure", {})
    if not failed_step or failed_step != rescue.get("step"):
        raise d.Needed("There is no failed step to recover.")
    if command == "retry":
        if args != [failed_step] or rescue.get("action") is None:
            raise d.Needed("Choose the failed step shown in Studio.")
        consume(p, failed_step)
        return d.main([failed_step, *rescue.get("args", [])])
    action = args[0] if args else ""
    if action != rescue.get("action") or action not in ACTIONS:
        raise d.Needed("Choose the suggested recovery for the failed step.")
    if action in CHANGES and "--accept" not in args:
        raise d.Needed(CHANGES[action] + " Ask the customer first.")
    if action == "remux":
        files = d.read(p / "creator-request.json").get("files", {}).get("raw", [])
        clip = args[2] if len(args) == 3 and args[1] == "--clip" else ""
        if not re.fullmatch(r"c[1-9]\d*", clip) or int(clip[1:]) > len(files):
            raise d.Needed("Choose a source clip from the current edit.")
        consume(p, failed_step)
        original = files[int(clip[1:]) - 1]
        target = p / "work" / ("rescue-" + clip + ".mp4")
        partial = target.with_suffix(".pending.mp4")
        target.parent.mkdir(exist_ok=True)
        d.run_process(p, [str(d.KIT / "bin/ffmpeg"), "-nostdin", "-v", "error", "-y", "-i", original,
                      "-map", "0:v:0", "-map", "0:a:0?", "-fps_mode", "passthrough", "-c:v", "libx264",
                      "-c:a", "aac", "-dn", "-sn", "-write_tmcd", "0", str(partial)], failed_step, mark_complete=False)
        partial.replace(target)
        d.put(p, rescue_inputs=dict(status.get("rescue_inputs", {}), **{original: str(target)}))
        sources = d.read(p / "sources.json")
        if clip in sources:
            sources[clip] = str(target)
            d.write(p / "sources.json", sources)
    elif action == "reference-sheet":
        references = d.read(p / "creator-request.json").get("files", {}).get("references", [])
        source = next((r.get("file") for r in references if r.get("file")), None)
        if not source:
            raise d.Needed("Add a local reference file before making a reference sheet.")
        consume(p, failed_step)
        dest = p / "reference-sheet"
        dest.mkdir(exist_ok=True)
        metadata = util.probe(Path(source))
        duration = float(metadata.get("duration") or 0)
        if duration <= 0:
            raise d.Needed("The reference video could not be read. Try uploading it again.")
        d.run_process(p, [str(d.KIT / "bin/ffmpeg"), "-nostdin", "-v", "info", "-y", "-i", source,
                      "-vf", f"fps=12/{duration},scale=180:-2,tile=4x3", "-frames:v", "1", str(dest / "sheet.jpg")], failed_step)
        log = d.run_process(p, [str(d.KIT / "bin/ffmpeg"), "-nostdin", "-v", "info", "-i", source,
                      "-vf", "scale=160:-2,select=gt(scene\\,0.32),showinfo", "-an", "-f", "null", "-"], failed_step)
        cuts = len(re.findall(r"Parsed_showinfo.*\bn:\s*\d+", log.read_text(errors="replace")))
        d.write(dest / "measurements.json", {"estimated_cuts_per_minute": round(60*cuts/duration, 2),
                "average_shot_seconds": round(duration/(cuts+1), 2), "words_per_minute": None})
        d.put(p, rescuing=False, failed_step=None)
        print("Use the reference sheet in this project. Report only the visual traits you can verify.")
        return 0
    elif action == "free-space":
        consume(p, failed_step)
        for path in [*p.glob("renders/*.pending.mp4"), *p.glob("work/rescue-*.pending.mp4")]:
            path.unlink(missing_ok=True)
        d.clear_render_temporary(p)
    elif action == "effect-simple":
        effect = next((arg for arg in args[1:] if re.fullmatch(r"[a-z0-9-]+", arg)), "")
        if effect != next(iter(rescue.get("args", [])), None) or not (d.LIB / "effects" / effect / "effect.md").is_file():
            raise d.Needed("Choose the effect to simplify.")
        consume(p, failed_step)
        doc = d.LIB / "effects" / effect / "effect.md"
        previews = sorted((doc.parent / "example").glob("*.jpg"))[:4]
        print(f"Use {doc} to design a simpler project HTML layer.")
        if previews:
            print("Preview frames:", *previews)
        notices = d.status(p).get("notices", [])
        d.put(p, notices=list(dict.fromkeys([*notices, "The selected " + effect.replace("-", " ") + " effect needed a simpler treatment."])))
        d.put(p, rescuing=False, failed_step=None)
        return 0
    elif action in CHANGES:
        consume(p, failed_step)
        override = dict(status.get("rescue_override", {}), **{action.replace("-", "_"): True})
        d.put(p, rescue_override=override)
        notice = {"no_cutout":"I moved the graphic in front of the subject.",
                  "captions_basic":"I switched to a basic caption style.",
                  "no_music":"I finished without the selected music."}[action.replace("-", "_")]
        d.put(p, notices=list(dict.fromkeys([*status.get("notices", []), notice])))
        print(notice)
    else:
        consume(p, failed_step)
    if action == "transcribe-chunked":
        d.put(p, rescue_override=dict(status.get("rescue_override", {}), transcribe_chunked=True))
    return d.main([failed_step, *rescue.get("args", [])])
