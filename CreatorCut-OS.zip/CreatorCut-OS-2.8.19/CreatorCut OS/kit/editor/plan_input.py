"""Validate the data the visible editing chat writes, before rendering it."""
import json
import math
from pathlib import Path, PurePosixPath


class InvalidPlan(ValueError):
    pass


def number(value):
    return (type(value) is int and abs(value) <= 10**12) or (type(value) is float and math.isfinite(value))


def _check_finite(value, area):
    stack = [value]
    while stack:
        item = stack.pop()
        if type(item) is float and not math.isfinite(item):
            raise InvalidPlan(f"{area} has a number that is not finite.")
        if isinstance(item, dict):
            stack.extend(item.values())
        elif isinstance(item, list):
            stack.extend(item)


def load(project, cut_length=None):
    path = project / 'plan.json'
    if not path.is_file():
        raise InvalidPlan("The edit plan is missing. Run init or restore the plan for this edit.")
    try:
        plan = json.loads(path.read_text(encoding='utf-8'))
    except (ValueError, RecursionError):
        raise InvalidPlan("The edit plan could not be read. Fix the plan in this chat and build again.") from None
    if not isinstance(plan, dict):
        raise InvalidPlan("The edit plan must contain a single object.")
    duration = plan.get('duration')
    if duration is not None and (not number(duration) or duration <= 0):
        raise InvalidPlan("The edit plan needs a positive video duration.")
    frame = 1 / 30
    if cut_length and duration is not None and abs(duration - cut_length) > frame:
        raise InvalidPlan("The edit plan duration does not match the current cut. Update it from the saved cut.")
    limit = cut_length or duration
    slots = plan.get('slots', [])
    if not isinstance(slots, list):
        raise InvalidPlan("The effect slots must be a list.")
    intervals = []
    for index, slot in enumerate(slots, 1):
        label = f"Effect slot {index}"
        if not isinstance(slot, dict):
            raise InvalidPlan(f"{label} needs a source and a time range.")
        if slot.get('off'):
            continue  # Old disabled effects may outlive their files and timings.
        _check_finite(slot, label)
        src = slot.get('src')
        if not isinstance(src, str) or not src.strip():
            raise InvalidPlan(f"{label} has no video source. Add its local render or turn the slot off.")
        relative = PurePosixPath(src)
        try:
            safe = (project / Path(src)).resolve().is_relative_to(project.resolve())
        except (OSError, ValueError, RuntimeError):
            safe = False
        if relative.is_absolute() or '..' in relative.parts or ':' in src or '\\' in src or not safe:
            raise InvalidPlan(f"{label} needs a source inside this video project.")
        if any(slot.get(k) is not None and not isinstance(slot[k], str) for k in ('slot', 'key')):
            raise InvalidPlan(f"{label} needs a valid effect name.")
        start, end = slot.get('from'), slot.get('to')
        if not number(start) or not number(end) or not 0 <= start < end:
            raise InvalidPlan(f"{label} needs a start and end in seconds, with the end after the start.")
        if limit and (start >= limit or end > limit + frame):
            raise InvalidPlan(f"{label} runs past the current cut. Move it inside the video.")
        y = slot.get('caption_y')
        if y is not None and (not number(y) or not 236 <= y <= 1376):
            raise InvalidPlan(f"{label} puts captions outside the visible area. Set its caption position between 236 and 1376.")
        intervals.append((start, end, index))
    intervals.sort()
    for (_, end, first), (start, _, second) in zip(intervals, intervals[1:]):
        if start < end - .01:  # Keep the same rounding tolerance as fx_add.
            raise InvalidPlan(f"Effect slots {first} and {second} overlap. Separate their time ranges.")
    _check_finite({k: v for k, v in plan.items() if k != 'slots'}, "The edit plan")
    return plan
