# 2.3.3

- Existing website-fed installations migrate to the release-only GitHub repository after installing, including older installers that preserve their old configuration. Custom publisher channels remain unchanged.

# 2.3.2

- Single-ZIP public GitHub update delivery: embedded version detection, verified package caching and preserved projects/presets/editing memory. Repository binding remains required before GitHub distribution.
- Preserve custom update channels; verified packages can migrate the legacy publisher website channel.

# CreatorCut OS 2.3.1
- Recover the initial server-metadata startup race; never treat a blocked workflow as a successful start or obscure current errors with an old building message.
- Prevent stale failure records and invalid worker PIDs from giving a false stopped/running status after a genuine resume.
- Resolve unconfirmed delivery when the project actually starts; keep one project’s uncertain request from blocking unrelated projects.
- Reconnect an active foreground tool after Studio restarts or changes ports; prevent a second tool from taking an action already being acknowledged.
- Preserve concurrent metadata changes and existing approved library files; keep pinned preset memory connected after a rename.
- Add a foreground native-action connection: Studio's Make action returns to the existing conversation's active tool, with no second AI or persistent action queue. Host cancellation and disconnects release it; it does not wake an ended conversation.
- Recover render/editor locks after process death using operating-system locks. Preserve existing valid sources when a multi-clip join fails.
- Generate real footage/preview thumbnails asynchronously with bounded extraction, without blocking Studio status requests.
- Bound metadata reads, reuse upload metadata, and avoid applying render-sized disk reserves to metadata-only starts.
- Correct soundtrack filter-file arguments for current FFmpeg versions; verify an actual graphics and audio export.
- Protect active native edits and older active jobs during updates, serialize update transactions, and copy new code files atomically. Retry failed feed checks with bounded backoff.
- Stop waiting for an installer that is no longer running, and show the actual native editing stage instead of an assumed pipeline step.
- Bring the actual editor into view when an edit starts or the output becomes ready; do not reset the customer's scroll on progress updates.
- Reuse creation requests on double clicks and lost-response retries instead of creating duplicate projects.
- Reuse the saved Studio project throughout editing; intentional new projects remain separate.

# CreatorCut OS 2.3.0

- CreatorCut Signature default: Inter Tight, white/yellow typography, speech-timed in-place word animation and selective readable text behind the speaker.
- Field-by-field direction resolution: explicit instructions, clear reference choices, selected presets and relevant personal preferences override unspecified defaults.
- Real timed-caption starter when no measured reference is available; scene planning and render review remain required.
- Updated Studio with detailed Step 5 instructions, named presets, background editing memory, real progress states and native conversation guidance.
- Verified local update installation with checksum/backup checks and preservation of projects, presets and preference files.
- Consistent CreatorCut OS naming and release version in setup, chat integration and update notices.
