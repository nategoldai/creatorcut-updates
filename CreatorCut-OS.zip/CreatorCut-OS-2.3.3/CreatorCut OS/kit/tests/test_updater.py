"""Update package application, preservation, rollback and version ordering on isolated fixtures."""
import hashlib,json,sys,tempfile,unittest,zipfile
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from editkit import updater,util

class UpdateTests(unittest.TestCase):
    def setUp(self):
        t=tempfile.TemporaryDirectory();self.addCleanup(t.cleanup);self.tmp=Path(t.name);self.root=self.tmp/'installed';(self.root/'kit').mkdir(parents=True)
        (self.root/'kit/VERSION').write_text('2.3.0-rc.7');(self.root/'edit.py').write_text('old');(self.root/'obsolete.txt').write_text('old file');(self.root/'kit/FILES.txt').write_text('edit.py\nobsolete.txt\nkit/VERSION\n')
        for rel in ['my-brand/learned.json','kit/projects/demo/project.json','.agents/skills/creator-preferences/SKILL.md','.claude/skills/preset-mine/SKILL.md','.mcp.json']:
            p=self.root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('customer data')
        for obj,key,value in [(util,'ROOT',self.root),(util,'KIT',self.root/'kit'),(updater,'BACKUP',self.root/'kit/update-backup'),(updater,'CONFIG',self.root/'kit/update.json'),(updater,'STATE',self.root/'kit/studio-out/update.json')]:
            x=patch.object(obj,key,value);x.start();self.addCleanup(x.stop)
    def package(self,version='2.3.0-rc.8',extras=None):
        files={'edit.py':b'new','kit/editkit/__init__.py':b'','kit/VERSION':version.encode(),'.agents/skills/creator-preferences/SKILL.md':b'overwrite attempt','.mcp.json':b'overwrite attempt'}
        files.update(extras or {})
        files['kit/SHA256-MANIFEST.json']=json.dumps({k:hashlib.sha256(v).hexdigest() for k,v in files.items()}).encode()
        z=self.tmp/'release.zip'
        with zipfile.ZipFile(z,'w') as out:
            for rel,body in files.items():out.writestr('release/CreatorCut OS/'+rel,body)
        return z
    def test_beta_versions_and_stable_release_order(self):
        self.assertTrue(updater._newer('2.3.0-rc.10','2.3.0-rc.9'))
        self.assertTrue(updater._newer('2.3.0','2.3.0-rc.99'))
        self.assertFalse(updater._newer('2.3.0-rc.8','2.3.0'))
        self.assertFalse(updater._newer('2.1.0','2.3.0-rc.7'))
    def test_update_and_rollback_preserve_customer_data(self):
        self.assertEqual(updater.apply(str(self.package())),'2.3.0-rc.8')
        self.assertFalse((self.root/'obsolete.txt').exists())
        self.assertEqual((self.root/'edit.py').read_text(),'new')
        for rel in ['my-brand/learned.json','kit/projects/demo/project.json','.agents/skills/creator-preferences/SKILL.md','.claude/skills/preset-mine/SKILL.md','.mcp.json']:
            self.assertEqual((self.root/rel).read_text(),'customer data')
        self.assertEqual(updater.rollback(),'2.3.0-rc.7');self.assertTrue((self.root/'obsolete.txt').exists())
    def test_dependency_failure_rolls_back_original_code(self):
        z=self.package(extras={'kit/requirements.txt':b'new dependency'})
        with patch.object(updater,'_install_deps',side_effect=RuntimeError('dependency unavailable')):
            with self.assertRaises(RuntimeError):updater.apply(str(z))
        self.assertEqual(updater.current(),'2.3.0-rc.7');self.assertEqual((self.root/'edit.py').read_text(),'old')
        self.assertFalse((self.root/'kit/requirements.txt').exists())
    def test_unsafe_zip_path_rejected_without_touching_app(self):
        z=self.package()
        with zipfile.ZipFile(z,'a') as out:out.writestr('../escape.txt','unsafe')
        with self.assertRaises(util.Fail):updater.apply(str(z))
        self.assertEqual((self.root/'edit.py').read_text(),'old')
    def test_tampered_manifest_rejected(self):
        z=self.package()
        with zipfile.ZipFile(z,'a') as out:out.writestr('release/CreatorCut OS/unlisted.txt','unexpected')
        with self.assertRaises(util.Fail):updater.apply(str(z))
        self.assertEqual(updater.current(),'2.3.0-rc.7')
    def test_old_package_cannot_downgrade(self):
        with self.assertRaises(util.Fail):updater.apply(str(self.package('2.1.0')))
        self.assertEqual(updater.current(),'2.3.0-rc.7')

    def test_disabled_feed_can_migrate_with_verified_package(self):
        (self.root/'kit/update.json').write_text('{"url":""}')
        updater.apply(str(self.package(extras={'kit/update.json':b'{"url":"https://publisher.example/latest.json"}'})))
        self.assertEqual(json.loads((self.root/'kit/update.json').read_text())['url'],'https://publisher.example/latest.json')
    def test_customer_existing_feed_is_preserved(self):
        (self.root/'kit/update.json').write_text('{"url":"https://my-publisher.example/latest.json"}')
        updater.apply(str(self.package(extras={'kit/update.json':b'{"url":"https://other.example/latest.json"}'})))
        self.assertEqual(json.loads((self.root/'kit/update.json').read_text())['url'],'https://my-publisher.example/latest.json')
    def test_legacy_publisher_feed_can_migrate_to_single_zip_github(self):
        (self.root/'kit/update.json').write_text('{"url":"https://nategold.ai/creatorcut/latest.json"}')
        updater.apply(str(self.package(extras={'kit/update.json':b'{"github_repository":"publisher/creatorcut"}'})))
        self.assertEqual(json.loads((self.root/'kit/update.json').read_text())['github_repository'],'publisher/creatorcut')
    def test_existing_github_channel_is_preserved(self):
        (self.root/'kit/update.json').write_text('{"github_repository":"customer/creatorcut"}')
        updater.apply(str(self.package(extras={'kit/update.json':b'{"github_repository":"other/creatorcut"}'})))
        self.assertEqual(json.loads((self.root/'kit/update.json').read_text())['github_repository'],'customer/creatorcut')
    def test_first_run_migrates_legacy_config_preserved_by_old_installer(self):
        util.write_json(updater.CONFIG,{'url':'https://nategold.ai/creatorcut/latest.json'})
        util.write_json(util.KIT/'release-channel.json',{'github_repository':'nategoldai/creatorcut-updates'})
        self.assertEqual(updater._channel_config()['github_repository'],'nategoldai/creatorcut-updates')
        self.assertNotIn('url',util.read_json(updater.CONFIG))
    def test_first_run_does_not_replace_custom_feed(self):
        util.write_json(updater.CONFIG,{'url':'https://customer.example/latest.json'})
        util.write_json(util.KIT/'release-channel.json',{'github_repository':'nategoldai/creatorcut-updates'})
        self.assertEqual(updater._channel_config()['url'],'https://customer.example/latest.json')
    def test_first_run_without_packaged_channel_keeps_legacy_feed(self):
        util.write_json(updater.CONFIG,{'url':'https://nategold.ai/creatorcut/latest.json'})
        self.assertEqual(updater._channel_config()['url'],'https://nategold.ai/creatorcut/latest.json')
    def test_verified_feed_detects_next_beta(self):
        from editkit import linkfetch
        (self.root/'kit/update.json').write_text('{"url":"https://publisher.example/latest.json"}')
        payload={'version':'2.3.0-rc.8','zip':'https://publisher.example/new.zip','sha256':'a'*64}
        with patch.object(linkfetch,'_get',return_value=json.dumps(payload).encode()):result=updater.check()
        self.assertTrue(result['available']);self.assertEqual(result['latest'],'2.3.0-rc.8')
    def test_unsigned_feed_does_not_offer_unsafe_install(self):
        from editkit import linkfetch
        (self.root/'kit/update.json').write_text('{"url":"https://publisher.example/latest.json"}')
        with patch.object(linkfetch,'_get',return_value=b'{"version":"2.3.0-rc.8","zip":"https://publisher.example/new.zip"}'):
            result=updater.check()
        self.assertFalse(result['available']);self.assertIn('verify',result['error'])
    def test_failed_feed_is_not_reported_as_up_to_date(self):
        from editkit import linkfetch
        (self.root/'kit/update.json').write_text('{"url":"https://publisher.example/latest.json"}')
        with patch.object(linkfetch,'_get',side_effect=OSError('offline')):
            result=updater.check()
            self.assertIn('error',result)
            with self.assertRaises(util.Fail):updater.apply()

if __name__=='__main__':unittest.main()
