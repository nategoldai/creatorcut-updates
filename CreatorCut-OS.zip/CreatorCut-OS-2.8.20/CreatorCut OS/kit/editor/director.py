"""File-only Studio/chat handoff and recipe commands. No model client or permission relay."""
import contextlib,contextvars,copy,hashlib,json,math,os,re,secrets,shutil,signal,subprocess,sys,threading,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];KIT=ROOT/'kit';PROJECTS=KIT/'projects';OUT=KIT/'studio-out';LIB=KIT/'style-library';SCRIPTS=LIB/'scripts'
LABELS={'ingest':'Reading your footage','assemble':'Picking your best takes','words':'Listening to your cut','layout':'Finding your best framing','init':'Preparing your style','build':'Building your video','lint':'Checking your graphics','snapshot':'Checking the look','base':'Saving your first cut','fx-check':'Choosing your effects','fx-new':'Preparing your effect','fx-run':'Adding your effect','fx-add':'Adding your effect','render':'Rendering your video','check':'Checking the result','music':'Adding your music','publish':'Saving your video','frames':'Checking the result','probe':'Checking your video','silence':'Checking your sound','look':'Checking the look'}
WEIGHTS={'ingest':(0,10),'assemble':(10,20),'words':(20,26),'layout':(26,30),'init':(30,35),'build':(35,40),'lint':(40,42),'snapshot':(42,44),'base':(44,55),'fx-check':(55,55),'fx-new':(55,58),'fx-run':(58,74),'fx-add':(74,76),'render':(76,91),'check':(91,94),'music':(94,98),'publish':(98,100)}
PLAIN={'waiting':'Open your CreatorCut chat to start your video.','queue':'Next in line','paused':'Paused: open your CreatorCut chat and type continue. Nothing is lost.','needs':'Your chat needs you →','stopped':'Stopped. Your footage and versions are safe.','failed':'This step could not finish. Open your chat and ask it to continue.','space':'Please free some space, then type continue in your CreatorCut chat.','missing':'Please add your footage again, then type continue in your CreatorCut chat.','silent':'A raw clip has no audio track. Press Stop edit, move the silent clip to B-roll or replace it with a clip with sound, then press Make my video and type continue in your CreatorCut chat.'}
TECH=re.compile(r'\.(?:py|json|mp4)\b|kit/|Traceback|Error:|mean difference|frame f|stderr|ffmpeg|\b(?:slot|token|delivery|workflow|listener|waiter)\b',re.I)
_REQUEST_CONTEXT=contextvars.ContextVar('creatorcut_request',default=None)
_idle_observation=None
EDIT_BUDGET_SECONDS=3600
EDIT_BUDGET_MESSAGE='This edit used one hour of active editing and stopped safely. Your progress and saved versions are kept. Press Continue saved edit in Studio to carry on.'

def account_edit_budget(old, changes, wall, mono):
 """Accumulate observed active time once under the existing status lock."""
 rid=changes.get('request_id',old.get('request_id'))
 same=bool(rid and rid==old.get('request_id'))
 value=old.get('edit_active_seconds',0) if same else 0
 active=float(value) if type(value) in (int,float) and math.isfinite(value) and value>=0 else 0.
 previous=old.get('edit_budget_mono');previous_wall=old.get('edit_budget_wall')
 working=(old.get('state')=='working' or old.get('state')=='waiting_chat' and old.get('claimed_at')
          or old.get('state')=='waiting_for' and (old.get('waiting_own_work') or old.get('waiting_for_last_step') and old.get('command_pid')))
 if same and working and type(previous) in (int,float) and type(previous_wall) in (int,float):
  delta=mono-previous
  if 0<=delta<=8 and abs((wall-previous_wall)-delta)<=8:active+=delta
 return {'edit_active_seconds':active,'edit_budget_mono':mono,'edit_budget_wall':wall}

def enforce_edit_budget(p,request):
 """Cancel this request; its owned worker performs all process signalling."""
 if not request:return False
 with lock(OUT/'.queue.guard',True):
  row=status(p)
  if row.get('request_id')!=request:return False
  if row.get('stop_reason')=='edit_deadline':return True
  used=row.get('edit_active_seconds',0)
  if type(used) not in (int,float) or not math.isfinite(used) or row.get('state') in ('done','stopped') or used<EDIT_BUDGET_SECONDS:return False
  step=row.get('active_step') or 'editor'
  write(p/'cancel.json',{'cancel':True,'reason':'edit_deadline','request_id':request,'at':time.time()})
  put(p,'stopped',_request=request,stop_reason='edit_deadline',step_label=EDIT_BUDGET_MESSAGE,
      what=None,eta=None,question=None,waiting_for_last_step=False)
  audit_event(p,'step.failed',request=request,stage=step,outcome='edit_deadline')
  from editkit import problem_reports
  report=problem_reports.automatic(p,area=step,reason='edit_deadline',failure_class='app',signature='edit-deadline:'+request)
  if report:put(p,_request=request,problem_report_code=report['code'])
 return True

class Needed(Exception):pass
class StepNeedsInput(Needed):
 def __init__(self, reason, message, failure_class="app", *, tool=None, recorded=False):
  super().__init__(message)
  self.reason=reason
  self.failure_class=failure_class
  self.tool=tool
  self.recorded=recorded

class IngestInputNeeded(StepNeedsInput):
 def __init__(self, reason, message, failure_class='input', *, clip=None, symptom=None, exit_code=None):
  super().__init__(reason,message,failure_class)
  self.clip=clip
  self.symptom=symptom
  self.exit_code=exit_code
class RenderNeeded(Needed):pass
class SpanNeeded(Needed):pass
class Busy(Needed):pass
class EffectSkip(Needed):pass
class CreativeCheckNeeded(Needed):pass
class ReviewTimingNeeded(CreativeCheckNeeded):
 def __init__(self,reason,duration=None):
  self.reason=reason;self.duration=duration
  message=('The review samples are outside the current export. Run check without --at to sample this video.'
           if reason=='explicit_samples_outside_render' else
           'The caption timings do not fit the current export. Run words, then rebuild the captions and render before running check again.')
  if type(duration) in (int,float) and math.isfinite(duration):message+=f' The current export is {duration:.3f} seconds long.'
  super().__init__(message)
class CaptionBuildNeeded(Needed):pass
class LookBuildNeeded(Needed):pass
def read(p,default=None):
 try:return json.loads(Path(p).read_text())
 except (OSError,ValueError):return {} if default is None else default
def write(p,value):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.'+secrets.token_hex(6)+'.partial')
 with tmp.open('w') as f:json.dump(value,f,indent=2);f.flush();os.fsync(f.fileno())
 os.replace(tmp,p)
@contextlib.contextmanager
def lock(p,wait=False,message='Another CreatorCut step is finishing. Try continue again in a moment.',*,shared=False):
 import fcntl
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('a+') as f:
  try:fcntl.flock(f,(fcntl.LOCK_SH if shared else fcntl.LOCK_EX)|(0 if wait else fcntl.LOCK_NB))
  except BlockingIOError:raise Busy(message or '')
  try:yield
  finally:fcntl.flock(f,fcntl.LOCK_UN)
def alive(pid):
 from editkit import util
 return util.process_alive(pid)
def project(name):
 if not isinstance(name,str) or not re.fullmatch('[a-zA-Z0-9_-]+',name) or not (PROJECTS/name/'project.json').is_file():raise Needed(PLAIN['missing'])
 p=PROJECTS/name
 if not p.resolve().is_relative_to(PROJECTS.resolve()):raise Needed(PLAIN['missing'])
 return p
def current():
 data=read(OUT/'current-edit.json')
 if not isinstance(data,dict) or not data.get('video'):return None
 try:return project(data['video'])
 except Needed:return None
def status(p):
 row=read(Path(p)/'status.json')
 if not isinstance(row,dict) or row.get('schema')!=2:return {}
 return row
def put(p,state=None,_request=None,_observed_seq=None,**changes):
 context=_REQUEST_CONTEXT.get()
 if _request is None and context and context[0]==Path(p).name:_request=context[1]
 with lock(Path(p)/'.status-28.guard',True):
  old=status(p)
  if _request is not None and old.get('request_id')!=_request:return old
  if _observed_seq is not None and old.get('seq')!=_observed_seq:return old
  now=time.time();elapsed=float(old.get('elapsed',0))
  if old.get('state') in ('working','waiting_for','waiting_resources'):elapsed+=max(0,min(600,now-float(old.get('elapsed_at',old.get('updated',now)))))
  row=dict(old,schema=2,updated=now,elapsed=elapsed,elapsed_at=now,**changes)
  row.update(account_edit_budget(old,changes,now,time.monotonic()))
  if state:
   row['state']=state
   if state!='needs_you':row.pop('question',None)
  if old.get('stop_reason')=='edit_deadline' and row.get('request_id')==old.get('request_id'):
   row.update(state='stopped',step_label=EDIT_BUDGET_MESSAGE,question=None,eta=None)
  row['overall_percent']=max(float(old.get('overall_percent',0)),float(changes.get('overall_percent',old.get('overall_percent',0))))
  if row.get('state')!='done':row['overall_percent']=min(99,row['overall_percent'])
  if row.get('state') in ('working','waiting_for','waiting_resources'):row['timer_started']=now-row['elapsed']
  else:row.pop('timer_started',None)
  row['seq']=old.get('seq',0)+1;write(Path(p)/'status.json',row)
 return row
def audit_event(p, kind, *, request=None, **fields):
 from editkit import diagnostics
 diagnostics.record(p.name,kind,request_id=request or status(p).get('request_id'),**fields)

def public(name):
 try:
  row=dict(status(project(name)))
  if not row:return {}
  heartbeat=row.get('heartbeat')
  fresh=type(heartbeat) in (int,float) and 0<=time.time()-heartbeat<8
  row['tool_running']=bool(fresh and row.get('command_pid') and command_alive({'command_pid':row.get('command_pid'),'command_birth':row.get('command_birth')}))
  if 'edit_active_seconds' in row:
   used=row['edit_active_seconds']
   row['elapsed']=used if type(used) in (int,float) and math.isfinite(used) and used>=0 else 0
   if row['tool_running'] and row.get('state')=='working':row['timer_started']=time.time()-row['elapsed']
   else:row.pop('timer_started',None)
  if row.get('claimed_at'):
   row=dict(row,can_resume_here=can_resume_here(row))
  return row
 except Needed:return {}
def command_alive(s):
 from editkit import util
 for pid,birth in ((s.get('command_runner_pid'),s.get('command_runner_birth')),(s.get('command_pid'),s.get('command_birth'))):
  if not alive(pid):continue
  if birth:
   current=util.process_identity(pid)
   if current and current!=birth:continue
  return True
 return False
def can_resume_here(st):
 from . import session
 from editkit import editor
 return (editor.config().get('provider')=='codex' and st.get('state') in ('working','waiting_chat','needs_you','paused')
         and bool(st.get('claimed_at') and st.get('owner')) and not st.get('resume_here')
         and not st.get('paused_for_update') and not command_alive(st)
         and (bool(st.get('owner_process')) or session.alive(st.get('owner_process')) is not True))

def approve_resume_here(name,request_id):
 p=project(name)
 with lock(KIT/'.update.guard',shared=True),lock(OUT/'.queue.guard',True):
  st=status(p)
  if not request_id or st.get('request_id')!=request_id or current()!=p or not can_resume_here(st):
   raise Needed('This edit can no longer switch chats. Check its current status in Studio.')
  with lock(p/'.recipe-command.guard',message='The current editing command must finish before you switch chats.'):
   return put(p,'waiting_chat',resume_here=True,what=None,eta=None,
              step_label='Open this CreatorCut folder in a new Codex chat and type continue.')


def refresh_clock():
 """Engine-only clock; no chat client, edit scheduling, takeover or rendering."""
 global _idle_observation
 p=current()
 if not p:return False
 s=status(p)
 if s.get('state') in ('done','stopped'):return False
 if s.get('claimed_at'):
  s=put(p,_request=s.get('request_id'),_observed_seq=s.get('seq'))
  if enforce_edit_budget(p,s.get('request_id')):return False
 from . import session
 owner=session.alive(s.get('owner_process'));gone=owner is False
 running=command_alive(s)
 claimed_wait=s.get('state')=='waiting_chat' and bool(s.get('claimed_at'))
 if gone and running and s.get('state') in ('working','waiting_for'):
  if not s.get('waiting_for_last_step'):
   put(p,'waiting_for',_request=s.get('request_id'),_observed_seq=s.get('seq'),step_label='Your last step is closing safely',what='your last editing step to close',waiting_for_last_step=True,eta=None)
 elif not running and gone and (claimed_wait or s.get('state') in ('working','waiting_for','needs_you')):
  message='Your AI chat closed before finishing. Your footage and choices are saved. In your CreatorCut chat type continue to carry on.'
  updated=put(p,'paused',_request=s.get('request_id'),_observed_seq=s.get('seq'),step_label=message,command_pid=None,what=None,eta=None)
  if updated.get('state')=='paused':
   from editkit import telemetry
   telemetry.event('edit_paused',project=p.name,request=s.get('request_id'),step=s.get('active_step'))
 elif s.get('state') in ('working','needs_you') or claimed_wait:
  if s.get('state')!='needs_you' and not running and owner is not False:
   now=time.monotonic();identity=(p,s.get('request_id'),s.get('heartbeat'))
   prior=_idle_observation
   began=prior[1] if prior and prior[0]==identity and 0<=now-prior[2]<=8 else now
   _idle_observation=(identity,began,now)
   if now-began>=1200:
    put(p,'needs_you',_request=s.get('request_id'),_observed_seq=s.get('seq'),step_label=PLAIN['needs'],question='Your edit is waiting in chat. Open it and type continue.')
    return True
  else:_idle_observation=None
  waiting=not running and owner is None
  if waiting!=bool(s.get('chat_identity_unknown')):
   put(p,_request=s.get('request_id'),_observed_seq=s.get('seq'),chat_identity_unknown=waiting)
 return True
def status_clock():
 from editkit import util
 deadline=time.monotonic()+3
 while True:
  try:
   with lock(OUT/'.status-clock.guard'):
    write(OUT/'status-clock.json',{'pid':os.getpid(),'birth':util.process_identity(os.getpid())})
    try:
     while refresh_clock():time.sleep(2)
    finally:
     file=OUT/'status-clock.json'
     if read(file).get('pid')==os.getpid():write(file,{'pid':None})
    return
  except Busy:
   if time.monotonic()>=deadline:return
   time.sleep(.05)
def start_clock():
 # A bounded engine observer only marks a genuinely abandoned edit paused.
 # Studio stays read-only; the observer cannot start or recover an edit.
 subprocess.Popen([sys.executable,str(ROOT/'edit.py'),'_status-clock'],cwd=ROOT,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
def requests(*, active_only=False):
 rows=[]
 folder=OUT/'requests'
 if active_only:
  ids={status(file.parent).get('request_id') for file in PROJECTS.glob('*/status.json')}
  files=(folder/f'{rid}.json' for rid in ids if isinstance(rid,str) and re.fullmatch('[a-f0-9]{32}',rid))
 else:
  files=folder.glob('*.json')
 for file in files:
  row=read(file)
  if not isinstance(row,dict) or row.get('id')!=file.stem or type(row.get('created')) not in (int,float):continue
  try:project(row.get('video'))
  except (Needed,TypeError):continue
  rows.append(row)
 return sorted(rows,key=lambda row:row['created'])

def delivery_for(request_id):
 row=read(OUT/'request-state'/f'{request_id}.json')
 return row if isinstance(row,dict) else {}

def cancelled(p):
 marker=read(p/'cancel.json')
 return isinstance(marker,dict) and marker.get('cancel') is True

def pending_request(p,row,delivery):
 st=status(p)
 return (st.get('state')=='waiting_chat' and st.get('request_id')==row['id']
         and not st.get('claimed_at') and not delivery.get('delivered')
         and not delivery.get('cancelled') and not cancelled(p))
TAKEOVER_LINE='CREATORCUT: another CreatorCut chat is now starting your videos. Do not run wait again in this chat.'
def retire_legacy_listener():
 """An older wait loop cannot understand takeover tokens after an update.
 Verify its exact installation, command and creation identity; never stop a chat.
 """
 from editkit import util
 if ROOT.resolve()!=util.ROOT.resolve():return False
 file=OUT/'waiter.json';r=read(file);pid,birth=r.get('pid'),r.get('birth')
 if r.get('token') or not util.process_alive(pid):return True
 if not birth or pid==os.getpid() or util.process_identity(pid)!=birth:return False
 try:
  command=subprocess.check_output(['/bin/ps','-p',str(pid),'-o','command='],text=True,timeout=3).strip()
  cwd=subprocess.check_output(['/usr/sbin/lsof','-a','-p',str(pid),'-d','cwd','-Fn'],text=True,stderr=subprocess.DEVNULL,timeout=3)
  if not re.search(r'(?:^|[/\s])edit\.py\s+wait$',command) or ('n'+str(ROOT.resolve())) not in cwd.splitlines():return False
 except (OSError,subprocess.SubprocessError):return False
 if util.process_identity(pid)!=birth:return False
 from . import session
 host=session.capture(pid)
 if session.alive(host) is True:
  key=hashlib.sha256(json.dumps(host,sort_keys=True).encode()).hexdigest()
  write(OUT/'retired-listeners'/f'{key}.json',{'retired':True,'at':time.time(),'reason':'older listener retired during update'})
 try:os.kill(pid,signal.SIGTERM)
 except ProcessLookupError:return True
 end=time.monotonic()+3
 while util.process_alive(pid) and time.monotonic()<end:time.sleep(.05)
 util.reap_exited_child(pid)
 if util.process_alive(pid):return False
 if read(file).get('pid')==pid:write(file,dict(r,pid=None,heartbeat=0))
 return True
def listener_allowed(caller_cwd=None):
 from . import session
 root=ROOT.resolve()
 explicit=os.environ.get('CLAUDE_PROJECT_DIR')
 host=Path(explicit).resolve() if explicit else session.project_folder(session.capture())
 if host is not None:return host==root
 return Path(caller_cwd or os.getcwd()).resolve().is_relative_to(root)

def studio_project_context(caller_cwd=None):
 """Resolve the launch context separately from background edit ownership."""
 from . import session
 root=ROOT.resolve()
 cwd=Path(caller_cwd or os.getcwd()).resolve()
 explicit=os.environ.get('CLAUDE_PROJECT_DIR')
 if explicit:
  detected=Path(explicit).resolve()
  return detected==root, cwd, detected
 if cwd.is_relative_to(root):
  return True, cwd, None
 detected=session.project_folder(session.capture())
 # A known Codex host process's cwd does not identify its selected chat.
 return not os.environ.get('CODEX_THREAD_ID') and detected==root, cwd, detected

def require_studio_project():
 from editkit.util import Fail
 allowed,cwd,detected=studio_project_context()
 if allowed:return
 root=ROOT.resolve()

 def display(path):
  if path is None:return 'not detected'
  home=Path.home().resolve()
  return ascii(str(Path('~')/path.relative_to(home)) if path.is_relative_to(home) else str(path))

 details=f'Command folder: {display(cwd)}. CreatorCut installation: {display(root)}.'
 if detected is not None:
  label='Detected project folder' if os.environ.get('CLAUDE_PROJECT_DIR') else 'Host process folder'
  details+=f' {label}: {display(detected)}.'
 raise Fail('Studio could not open from this folder. '+details,
            'Select this CreatorCut installation in your chat and run Open Studio from that folder.')

def setup_handoff():
 home=Path.home().resolve()
 folder=f'{ROOT.name} in your Home folder' if ROOT.parent.resolve()==home else str(ROOT)
 return ('Installed. Now open it in a new chat:\n'
         'Claude: use Claude Code (the Code tab in the Claude app). Click New session → click the folder name under the message box → Open folder… → choose '+folder+' → Open → click Trust. Then type: open Studio.\n'
         'Codex: New chat → choose '+folder+' → choose Full access once if you accept its local access. Then type: open Studio.')
def listener_identity():
 from . import session
 process=session.capture()
 if session.alive(process) is not True:
  owner=os.environ.get('CLAUDE_CODE_SESSION_ID') or os.environ.get('CLAUDE_SESSION_ID') or read(OUT/'chat-session.json').get('id') or ('local-'+str(os.getppid()))
  if os.environ.get('CLAUDECODE')=='1':
   return {'process':None,'owner':owner,'key':hashlib.sha256(('claude-session:'+owner).encode()).hexdigest(),'untracked':True}
  return None
 owner=os.environ.get('CLAUDE_CODE_SESSION_ID') or os.environ.get('CLAUDE_SESSION_ID') or os.environ.get('CODEX_THREAD_ID')
 hook=read(OUT/'chat-session.json')
 if not owner and hook.get('process')==process:owner=hook.get('id')
 # The shared hook record can change when another chat opens; retirement cannot.
 return {'process':process,'owner':owner or '', 'key':hashlib.sha256(json.dumps(process,sort_keys=True).encode()).hexdigest()}
def listener_retired(identity=None):
 identity=identity or listener_identity()
 if not identity:return False
 file=OUT/'retired-listeners'/f"{identity['key']}.json"
 if not read(file).get('retired'):return False
 from . import session
 successor=read(OUT/'waiter.json')
 if successor.get('listener_key')!=identity['key']:
  # A listener can finish announcing while its owning chat is still alive.
  # Preserve retirement in that gap; never make two open chats ping-pong.
  host=session.alive(successor.get('chat_process'))
  if host is True:return True
  if host is None and successor.get('untracked') and waiter_alive():return True
  if host is None and successor.get('chat_process'):return True
 file.unlink(missing_ok=True)
 return False
def waiter_alive():
 from . import session
 r=read(OUT/'waiter.json')
 if not isinstance(r,dict):return False
 heartbeat=r.get('heartbeat')
 if type(heartbeat) not in (int,float) or not 0<=time.time()-heartbeat<12:return False
 return bool(r.get('token') and session.alive({'pid':r.get('pid'),'birth':r.get('birth')}) is True and (session.alive(r.get('chat_process')) is True or r.get('untracked') is True))
def active_chat_project():
 from . import session
 row=read(OUT/'current-edit.json')
 try:p=project(row.get('video')) if isinstance(row,dict) and row.get('video') else None
 except Needed:return None
 if not p:return None
 st=status(p)
 if (st.get('request_id') and st['request_id']==row.get('request_id')
     and (st.get('state') in ('working','waiting_for','waiting_resources') or st.get('state')=='waiting_chat' and st.get('claimed_at'))
     and (command_alive(st) or session.alive(st.get('owner_process')) is True)):
  return p.name
 return None
def digest_file(file):
 h=hashlib.sha256()
 with Path(file).open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def atomic_copy(source,target):
 target=Path(target);target.parent.mkdir(parents=True,exist_ok=True);temporary=target.with_name(target.name+'.'+secrets.token_hex(5)+'.partial')
 try:
  cloned=False
  if sys.platform=='darwin':
   import ctypes
   fn=ctypes.CDLL('/usr/lib/libSystem.B.dylib',use_errno=True).clonefile
   fn.argtypes=[ctypes.c_char_p,ctypes.c_char_p,ctypes.c_int];fn.restype=ctypes.c_int
   cloned=fn(os.fsencode(source),os.fsencode(temporary),0)==0
  if not cloned:shutil.copyfile(source,temporary)
  with temporary.open('rb') as stream:os.fsync(stream.fileno())
  os.replace(temporary,target)
 finally:temporary.unlink(missing_ok=True)
def source_identity(files, *, from_studio=False):
 result={}
 for value in files.get('raw',[]):
  path=Path(value).resolve()
  missing = (f'CreatorCut could not read {Path(value).name}. Reconnect its drive or add the clip again in Studio.'
             if from_studio else PLAIN['missing'])
  if not path.is_relative_to(ROOT.resolve()) or not path.is_file():raise Needed(missing)
  # This is a local cache identity, not an integrity seal. Any write, move,
  # replacement or metadata change invalidates reuse without rereading the clip.
  try: info=path.stat()
  except OSError as error: raise Needed(missing) from error
  result[str(path)]=[info.st_dev,info.st_ino,info.st_size,info.st_mtime_ns,info.st_ctime_ns]
 return result
def same_edit_choices(before,after):
 # Background poster generation changes presentation metadata, not edit choices.
 def content(cfg):
  value=copy.deepcopy(cfg)
  if not isinstance(value,dict):return value
  for item in value.get('media',[]):
   if isinstance(item,dict):
    for key in ('thumb','strip','hero','w','h'):item.pop(key,None)
  return value
 return content(before)==content(after)
def save_request(name,notes=None,key=None,*,from_studio=False):
 from editkit import videos,editor,util,updater
 editor.retire_managed_workers()
 p=project(name)
 with lock(KIT/'.update.guard',message='CreatorCut is updating. Press Make after it finishes.',shared=True), lock(OUT/'.queue.guard',True):
  try:updater.require_recovered()
  except util.Fail as error:raise Needed(error.message) from None
  if key:
   for found in reversed(requests()):
    if found.get('key')!=key or found.get('video')!=name:continue
    delivery=delivery_for(found['id'])
    if status(p).get('request_id')==found['id'] or delivery.get('delivered'):return found
  active=status(p)
  if command_alive(active):raise Needed('Your previous edit is stopping. Press Make my video again in a moment.')
  if active.get('state')=='waiting_chat' and active.get('request_id') and not cancelled(p) and not delivery_for(active['request_id']).get('cancelled'):raise Needed(PLAIN['waiting'])
  if active.get('state') in ('working','needs_you','waiting_for') and active.get('request_id'):raise Needed('Finish or stop this edit before starting it again.')
  with util.file_guard(p/'.request.guard',timeout=5):
   from editkit.server import apply_pending_settings
   rejected_settings=apply_pending_settings(name)
   from editkit import library
   cfg=videos.load(name);omissions=['A saved setting is no longer available. Check your choices in Studio.'] if rejected_settings else []
   if from_studio:
    raw = [item for item in cfg.get('media', []) if item.get('kind') == 'raw' and item.get('file')]
    if not raw:
     raise Needed('Add your raw footage before starting an edit.')
    for index, item in enumerate(raw, 1):
     if item.get('has_audio') is False:
      raise Needed(f'Raw footage clip {index} has no audio track. Add it as B-roll or replace it with a clip that has audio.')
   cfg=dict(cfg,library_choices=library.choices(p,include_disabled=True,current=True,omissions=omissions))
  for kind in ('look','caption'):
   if isinstance(cfg['library_choices'].get(kind),dict):
    row=library.entry(cfg['library_choices'][kind]['id']);cfg['library_choices'][kind]={'id':row['id'],'version':row['version']}
  cfg['library_choices']['effects']=[{'id':row['id'],'version':row['version']} for row in (library.entry(item['id']) for item in cfg['library_choices'].get('effects',[]))]
  launch=read(LIB/'launch-list.json',{})
  if len(cfg['library_choices']['effects'])>launch.get('max_effects',2):raise Needed('Choose up to two effects for this video. Your saved choices are kept.')
  refs=[]
  from editkit import refs as reference
  for r in reference.for_project(name):
   local=ROOT/r['file'] if r.get('file') else next(iter(reference._ref_dir(r['id']).glob('video.*')),None)
   refs.append({'id':r['id'],'file':str(local) if local and local.is_file() else None,'status':r['status'],'analysis':str(reference._ref_dir(r['id'])/'kit.json'),'frames':str(reference._ref_dir(r['id'])/'map/annotated')})
  media=cfg.get('media',[]);files={kind:[str((ROOT/m['file']).resolve()) for m in media if m.get('kind')==kind and m.get('file')] for kind in ('raw','broll','image','music')}
  files['references']=refs
  selection=cfg.get('music_selection') or {}
  files['auto_music']=[dict(t,file=str((p/t['project_file']).resolve())) for t in selection.get('tracks',[]) if t.get('project_file')]
  files['effect_material']=cfg.get('effect_material',{})
  identity=source_identity(files,from_studio=from_studio);previous=read(p/'creator-request.json');reused=[]
  resume_saved=active.get('stop_reason')=='edit_deadline' and same_edit_choices(previous.get('choices'),cfg)
  if (notes or resume_saved) and identity and previous.get('source_identity')==identity:
   required={'ingest':['sources.json','transcript.txt'],'assemble':['assets/aroll.mp4','segments.json'],'words':['words.json','work/onsets.json'],'layout':['layout.json']}
   for step,paths in required.items():
    if all((p/name).is_file() for name in paths):reused.append(step)
   if bool(previous.get('choices',{}).get('voice_cleanup'))!=bool(cfg.get('voice_cleanup')):reused=[step for step in reused if step=='ingest']
  feedback_context={}
  if notes:
   layers=[];plan=read(p/'plan.json');slots=plan.get('slots',[]) if isinstance(plan,dict) else []
   for slot in slots or []:
    if not isinstance(slot,dict):continue
    effect=str(slot.get('key') or slot.get('slot') or 'effect')
    try:effect_name=library.entry('effect:'+effect)['name']
    except (util.Fail,KeyError,ValueError):effect_name=effect.replace('-',' ').title()
    start=slot.get('from',float(slot.get('frame',0))/30)
    end=slot.get('to',float(start)+float(slot.get('frames',0))/30)
    slot_name=str(slot.get('slot') or slot.get('key') or '');folder=p/'fx'/slot_name if re.fullmatch('[a-zA-Z0-9_-]+',slot_name) else p/'fx'
    layers.append({'effect':effect_name,'from':start,'to':end,'normal_captions_hidden':slot.get('captions')=='hide','effect_folder':str(folder.relative_to(ROOT))})
   feedback_context={'published_version':active.get('version'),'creative_html':str((p/'index.html').relative_to(ROOT)),'visible_effects':layers,'instruction':'Inspect the visible text at each feedback moment. An effect may replace the normal captions. Enlarge or restyle that effect text when it is what the customer sees; do not only change a hidden caption layer. Compare actual before/after frames.'}
  rid=secrets.token_hex(16);row={'id':rid,'key':key,'type':'notes' if notes else 'make','video':name,'title':cfg.get('title') or 'Your video','created':time.time(),'feedback_context':feedback_context,'choices':cfg,'notes':notes or [],'files':files,'source_identity':identity,'reused_steps':reused}
  if resume_saved:row['resume_saved_work']=True
  write(OUT/'requests'/f'{rid}.json',row)
  # Delivery state is separate; the request is immutable.
  write(OUT/'request-state'/f'{rid}.json',{'delivered':False})
  pending=0
  for queued in requests(active_only=True):
   if queued['id']==rid:continue
   if pending_request(PROJECTS/queued['video'],queued,delivery_for(queued['id'])):
    pending+=1
  another=active_chat_project()
  position=1+pending+int(bool(another and another!=name))
  (p/'cancel.json').unlink(missing_ok=True)
  write(p/'status.json',{'schema':2,'state':'waiting_chat','step_label':PLAIN['queue'] if position>1 else PLAIN['waiting'],'overall_percent':0,'started':None,'updated':time.time(),'heartbeat':0,'request_id':rid,'queue_position':position,'notices':list(dict.fromkeys(omissions)),'seq':active.get('seq',0)+1})
  from editkit import telemetry
  lib=cfg.get('library_choices',{})
  def choice_id(value):
   value=value.get('id') if isinstance(value,dict) else value
   return value if isinstance(value,str) and re.fullmatch(r'[a-z0-9:-]{1,80}',value) else None
  telemetry.event('feedback_sent' if notes else 'make_pressed',project=name,request=rid,details={
   'effects':[choice_id(e) for e in lib.get('effects',[]) if choice_id(e)],
   'captions':'off' if cfg.get('captions_on') is False else choice_id(lib.get('caption')) or 'signature','look':choice_id(lib.get('look')),
   'reference':'file' if any(r.get('file') for r in refs) else 'link' if refs else 'none',
   'music':selection.get('mode') if selection.get('mode') in ('auto','library','upload','none') else 'none',
   'clip_seconds':round(sum(m['duration'] for m in media if m.get('kind')=='raw' and type(m.get('duration')) in (int,float) and 0<=m['duration']<=86400),2)})
  audit_event(p,'requested',request=rid,outcome='revision' if notes else 'new_edit')
  return row

def chat_owner():
 if os.environ.get('CLAUDE_CODE_SESSION_ID'):return os.environ['CLAUDE_CODE_SESSION_ID']
 if os.environ.get('CLAUDECODE') or os.environ.get('CLAUDE_PROJECT_DIR') or os.environ.get('CLAUDE_SESSION_ID'):
  return os.environ.get('CLAUDE_SESSION_ID') or read(OUT/'chat-session.json').get('id','')
 return os.environ.get('CODEX_THREAD_ID') or read(OUT/'chat-session.json').get('id','')
def chat_process():
 from . import session
 row=read(OUT/'chat-session.json')
 record=row.get('process') if row.get('id')==chat_owner() else None
 return record if session.alive(record) is True else session.capture()
def next_request():
 from editkit import editor,updater,util
 try:updater.require_recovered()
 except util.Fail as error:raise Needed(error.message) from None
 if os.environ.get('CLAUDE_CODE_SESSION_ID') or os.environ.get('CLAUDECODE'):editor.configure_provider('claude')
 elif os.environ.get('CODEX_THREAD_ID'):editor.configure_provider('codex')
 from . import session
 deadline=time.monotonic()+900;announced=False
 while True:
  waiting=False
  with lock(KIT/'.update.guard',message='CreatorCut is updating. Type continue after it finishes.',shared=True), lock(OUT/'.queue.guard',True):
   p=current()
   stopped=False
   if p:
    s=public(p.name)
    stopped=s.get('state')=='stopped' or cancelled(p)
    if not stopped and s.get('state')!='done' and (s.get('claimed_at') or delivery_for(s.get('request_id')).get('delivered')):
     if s.get('paused_for_update'):
      from editkit import updater
      if updater.is_queued():raise Busy('CreatorCut is updating. Type continue after it finishes.')
     owner=chat_owner();owner_alive=session.alive(s.get('owner_process'));gone=owner_alive is False
     switch=s.get('resume_here')
     process=None
     if command_alive(s):
      if s.get('owner')!=owner and gone:waiting=True
      elif s.get('owner')!=owner:raise Busy('This video is being edited in your other chat.')
      else:raise Busy('Your video is finishing its current step. Try continue again in a moment.')
     elif s.get('owner')!=owner and not gone and not s.get('paused_for_update') and not switch:
      raise Busy('Your other chat has this saved edit open. Type continue there, or use Switch to a new Codex chat in Studio.')
     if not waiting:
      if switch:
       if os.environ.get('CODEX_THREAD_ID')!=owner or not owner:
        raise Busy('Open the CreatorCut folder in a Codex chat so CreatorCut can identify it, then type continue.')
       process=chat_process()
       if s.get('owner')!=owner and owner_alive is True and process!=s.get('owner_process'):
        raise Busy('The original chat is still open in another Codex process. Continue there, or close it before switching.')
       if s.get('owner')==owner and owner_alive is not True:
        raise Busy('Open this CreatorCut folder in a new Codex chat and type continue.')
      with lock(p/'.recipe-command.guard',message='The current editing command must finish before you continue.'):
       row=read(OUT/'requests'/f"{s['request_id']}.json")
       if not isinstance(row,dict) or row.get('id')!=s['request_id'] or row.get('video')!=p.name:
        put(p,'stopped',step_label=PLAIN['stopped'],resume_here=False)
        raise Needed('The saved edit request could not be read. Open the same video in Studio and press Make my video. Your footage and saved versions are safe.')
       handoff=describe(row,p,resume=True)
       resumed=s.get('state') in ('paused','needs_you') or bool(switch)
       state='waiting_chat' if resumed else None
       put(p,state,owner=owner,owner_process=process if switch else chat_process(),heartbeat=time.time(),waiting_for_last_step=False,paused_for_update=False,resume_here=False,chat_identity_unknown=False,**({'step_label':'Continuing your video','claimed_at':s.get('claimed_at') or time.time(),'eta':None,'what':None} if resumed else {}))
      delivery=OUT/'request-state'/f"{row['id']}.json"
      if not delivery_for(row['id']).get('delivered'):write(delivery,{'delivered':True,'at':s.get('claimed_at') or time.time()})
      if resumed:audit_event(p,'resumed',request=row['id'],state=s['state'])
      observe_claim(p)
      return handoff
   if not waiting:
    for row in requests(active_only=True):
     delivered=OUT/'request-state'/f"{row['id']}.json"
     receipt=delivery_for(row['id'])
     p=project(row['video'])
     if not pending_request(p,row,receipt):continue
     auto=bool(receipt.get('announced_by'))
     # Materialize the context before committing ownership. An interrupted
     # write leaves the request queued and available to the same chat.
     handoff=describe(row,p)
     write(OUT/'current-edit.json',{'video':p.name,'request_id':row['id']})
     claimed=time.time()
     put(p,'waiting_chat',step_label='Your chat picked up your video',claimed_at=claimed,heartbeat=claimed,owner=chat_owner(),owner_process=chat_process(),queue_position=0,completed=row.get('reused_steps',[]))
     write(delivered,{'delivered':True,'at':claimed})
     handoff['completed']=status(p).get('completed',[])
     observe_claim(p)
     if row.get('notes'):
      with lock(p/'.annotations.guard',True):
       notes=read(p/'annotations.json',{'notes':[]});ids={n['id'] for n in row['notes']}
       for note in notes.get('notes',[]):
        if note.get('id') in ids and note.get('status')=='saved':note.update(status='received',received_at=time.time())
       write(p/'annotations.json',notes)
     from editkit import telemetry
     telemetry.event('edit_claimed',project=p.name,request=row['id'],details={'auto':auto})
     audit_event(p,'claimed',request=row['id'],outcome='automatic' if auto else 'chat')
     return handoff
    if stopped:
     return {'message':EDIT_BUDGET_MESSAGE if s.get('stop_reason')=='edit_deadline' else 'This attempt was stopped. Open the same video in Studio and press Make my video to try again, or open a saved version to send feedback. Your footage and saved versions are safe.'}
    return {'message':'Nothing is waiting.'}
  # Release the queue guard while the closed chat's last local step finishes.
  # Never kill it, rotate its request or let another writer overlap it.
  if time.monotonic()>deadline:raise Busy('Your video is still finishing a step. Use Stop edit before starting it again.')
  if not announced:print('Your video is finishing its current step. Keeping your saved work.',flush=True);announced=True
  time.sleep(1)
def observe_claim(p):
 if ROOT.joinpath('edit.py').is_file():
  with contextlib.suppress(OSError):start_clock()
  with contextlib.suppress(OSError):start_awake(p)
def describe(row,p,resume=False):
 write(p/'creator-request.json',row)
 recipe='Follow kit/editor/RECIPE.md from step 1. Use the saved completed steps when continuing.'
 if row.get('resume_saved_work'):recipe+=' Continue the saved plan and HTML; check existing outputs before rerunning a step.'
 if not resume and row.get('type')=='make' and not row.get('resume_saved_work'):
  recipe+=" Design this video fresh: re-read RECIPE step 7, don't reuse the previous video's graphics or layout."
 return {'message':('Continue the saved edit' if resume or row.get('resume_saved_work') else 'A new, separate request')+' '+row['id']+' for '+str(row.get('title') or 'your video'),'request':row,'recipe':recipe,'project':str(p),'completed':status(p).get('completed',[]),'memory':str(ROOT/'my-brand/editing-memory.md')}
def wait():
 from . import session
 from editkit import util
 if not listener_allowed():
  print(setup_handoff(),flush=True);return
 identity=listener_identity()
 if not identity:
  print('Open the CreatorCut folder in your chat and type continue to start your video.',flush=True);return
 if listener_retired(identity):print(TAKEOVER_LINE,flush=True);return
 if not retire_legacy_listener():
  write(OUT/'retired-listeners'/f"{identity['key']}.json",{'retired':True,'at':time.time(),'reason':'unverified previous listener'})
  print('Type continue in your CreatorCut chat to start. The previous chat connection could not be closed safely.',flush=True);return
 token=secrets.token_hex(16);file=OUT/'waiter.json';birth=util.process_identity(os.getpid());guard=OUT/'.waiter-state.guard'
 # Separate from the old lifetime guard so an older orphan cannot hold us out.
 with lock(guard,True,message=None):
  previous=read(file)
  if previous.get('listener_key') and previous['listener_key']!=identity['key']:
   write(OUT/'retired-listeners'/f"{previous['listener_key']}.json",{'retired':True,'at':time.time()})
  takeover=bool(previous)
  write(file,{'pid':os.getpid(),'birth':birth,'heartbeat':time.time(),'token':token,'listener_key':identity['key'],'chat_process':identity['process'],'untracked':bool(identity.get('untracked'))})
 try:
  while True:
   with lock(guard,True,message=None):
    registered=read(file)
    if registered.get('token')!=token:
     write(OUT/'retired-listeners'/f"{identity['key']}.json",{'retired':True,'at':time.time()})
     print(TAKEOVER_LINE,flush=True);return
    if not identity.get('untracked') and session.alive(identity['process']) is not True:return
    write(file,dict(registered,heartbeat=time.time()))
    with lock(OUT/'.queue.guard',True):
     for row in requests(active_only=True):
      f=OUT/'request-state'/f"{row['id']}.json";s=delivery_for(row['id'])
      if not pending_request(PROJECTS/row['video'],row,s):continue
      last=s.get('announced_at',0)
      if s.get('announced') and not takeover and time.time()-last<30:continue
      # Check the captured owner again immediately before announcing.
      if not identity.get('untracked') and session.alive(identity['process']) is not True:return
      write(f,dict(s,announced=True,announced_at=time.time(),announced_by=token))
      print('CREATORCUT: the customer pressed Make for '+json.dumps(row['title'])+' (a new request '+row['id']+'). Run now: .venv/bin/python edit.py next',flush=True);return
    takeover=False
   time.sleep(2)
 finally:
  with lock(guard,True,message=None):
   if read(file).get('token')==token:write(file,dict(read(file),pid=None,heartbeat=0))
def start_awake(p):
 """One request-scoped Mac sleep assertion, including AI thinking between steps."""
 if sys.platform!='darwin' or not Path('/usr/bin/caffeinate').is_file():return
 st=status(p);rid=st.get('request_id')
 if not rid:return
 with lock(p/'.awake-launch.guard',True,message=None):
  old=read(p/'awake.json')
  from . import session
  if old.get('request_id')==rid and session.alive(old.get('process')) is True:return
  log=(p/'work');log.mkdir(exist_ok=True)
  with (log/'awake.log').open('a') as stream:
   proc=subprocess.Popen([sys.executable,str(ROOT/'edit.py'),'_awake',p.name,rid],cwd=ROOT,stdin=subprocess.DEVNULL,stdout=stream,stderr=stream,start_new_session=True)
  from editkit import util
  write(p/'awake.json',{'request_id':rid,'process':{'pid':proc.pid,'birth':util.process_identity(proc.pid)}})

def hold_awake(name,rid):
 from . import session
 p=project(name)
 def finished(st):
  if st.get('request_id')!=rid or st.get('state') in ('done','stopped','failed') or st.get('paused_for_update'):return True
  return not command_alive(st) and (st.get('state')=='needs_you' or st.get('state')=='paused' and session.alive(st.get('owner_process')) is not True)
 with lock(p/'.awake.guard',True,message=None):
  if finished(status(p)):return
  child=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  try:
   while not finished(status(p)):
    time.sleep(.5)
  finally:
   if child.poll() is None:child.terminate()
   child.wait(timeout=3)

def caption_language_notice(p):
 import unicodedata
 req=read(p/'creator-request.json');cfg=req.get('choices',{})
 if cfg.get('captions_enabled') is False or cfg.get('captions_on') is False or cfg.get('captions') is False or isinstance(cfg.get('captions'),dict) and cfg['captions'].get('enabled') is False:return None
 doc=read(p/'words.json',[]);words=doc if isinstance(doc,list) else doc.get('words',[])
 text=' '.join(str(w.get('word',w.get('text',''))) for w in words if isinstance(w,dict))
 if any(c.isalpha() and 'LATIN' not in unicodedata.name(c,'') for c in text):
  notice='These captions use a language our fonts do not support yet. Please choose captions off or provide Latin-alphabet captions before styling.'
  notes=list(status(p).get('notices',[]))
  if notice not in notes:put(p,notices=notes+[notice])
  raise Needed(notice)
 return None

def pause_for_update(name):
 p=project(name)
 with lock(OUT/'.queue.guard',True):
  st=status(p)
  if st.get('state')!='needs_you' or command_alive(st):
   raise Needed('Wait for the current step to finish before pausing for the update.')
  return put(p,'paused',paused_for_update=True,step_label='Saved for the update. Type continue in your CreatorCut chat after it installs.')

def cancel(name):
 p=project(name)
 with lock(OUT/'.queue.guard',True):
  write(p/'cancel.json',{'cancel':True,'at':time.time()})
  rid=status(p).get('request_id')
  if rid:
   f=OUT/'request-state'/f'{rid}.json';write(f,dict(delivery_for(rid),cancelled=True))
  from editkit import problem_reports
  problem_reports.record_outcome(rid,'stopped')
  return put(p,'stopped',step_label=PLAIN['stopped'])
def ensure(p,starting=False):
 context=_REQUEST_CONTEXT.get()
 if context and context!=(Path(p).name,status(p).get('request_id')):raise Needed(PLAIN['stopped'])
 if read(p/'cancel.json').get('cancel'):
  raise Needed(EDIT_BUDGET_MESSAGE if read(p/'cancel.json').get('reason')=='edit_deadline' else PLAIN['stopped'])
 threshold=int(os.environ.get('CREATORCUT_TEST_MIN_FREE_BYTES','2000000000')) if starting else 2_000_000_000
 from editkit import capacity
 if max(shutil.disk_usage(p).free,capacity.available(p))<threshold:raise Needed(PLAIN['space'])
def environment(p):
 from editkit import speech_models,util
 env=dict(os.environ);env['PYTHONUNBUFFERED']='1';env['CREATORCUT_KIT']=str(KIT);env['CREATORCUT_LIBRARY_STATE']=str(KIT/'library-state');env['CREATORCUT_LIBRARY_RENDER']=str(KIT/'render/node_modules/hyperframes-library');env['PATH']=str(KIT/'bin')+os.pathsep+str(KIT/'bin/node/bin')+os.pathsep+env.get('PATH','');env['TMPDIR']=str(p/'work/tmp');Path(env['TMPDIR']).mkdir(parents=True,exist_ok=True);env['CREATORCUT_SPEECH_MODEL']=str(speech_models.folder(read(util.PROFILE).get('whisper_model') or 'small'));env['HF_HUB_OFFLINE']='1';choices=read(p/'creator-request.json').get('choices',{});env['SFX']='1' if choices.get('sfx_on',choices.get('sfx',True)) else '0';env['HF_HOME']=str(KIT/'cache/huggingface');env['HYPERFRAMES_FONT_CACHE_DIR']=str(KIT/'cache/render-fonts');env['HYPERFRAMES_EXTRACT_CACHE_DIR']=str(p/'work/tmp/extract')
 if choices.get('captions_on') is False or choices.get('captions',{}).get('enabled') is False or choices.get('library_choices',{}).get('caption')=='none':
  env['CAPTIONS']='0'
 for pattern in ('render/node_modules/.remotion/chrome-headless-shell/*/chrome-headless-shell-*/*','bin/chrome-headless-shell/*/chrome-headless-shell-*/*','bin/chrome-headless-shell-*/*','render/node_modules/.cache/puppeteer/chrome-headless-shell/*/chrome-headless-shell-*/*'):
  browser=next((f for f in KIT.glob(pattern) if f.name in ('chrome-headless-shell','chrome-headless-shell.exe') and f.is_file()),None)
  if browser:env['HYPERFRAMES_BROWSER_PATH']=str(browser);break
 if sys.platform=='darwin':
  # The recipe engine launches the pinned style renderer directly. Apply the
  # same existing Mac process-layout adapter used by the older motion wrapper.
  # This grants no host access and does not alter encoding or creative quality.
  env['CREATORCUT_BROWSER_MODE']='compatibility'
  preload=(KIT/'tools/browser_compat.mjs').as_uri()
  option='--import='+preload
  env['NODE_OPTIONS']=(env.get('NODE_OPTIONS','')+' '+option).strip()
  env['CREATORCUT_RENDER_SCOPE_ID']=secrets.token_hex(12)
 return env
def explicit_colour(cfg):
 # Older drafts already stored "natural" as a default. A pinned recipe
 # distinguishes the Original button from that legacy default.
 return bool(cfg.get('grade') is not None or cfg.get('colour_recipe')
             or cfg.get('look') not in (None, '', 'natural'))

def apply_colour_choice(html,grade):
 """An explicit Studio grade wins over stock photographic treatments.

 Grade actual footage/cut-outs once, not ancestor wrappers or creative layers.
 Stock tint overlays are separately marked so Original really removes them.
 """
 html=re.sub(r'<style\b[^>]*\bid=[\"\']creatorcut-colour[\"\'][^>]*>.*?</style>','',html,flags=re.I|re.S)
 grade=grade or 'none'
 css=('#plate,#cutw{filter:none!important}'
      '#footage video:not(#back *),#slots video.gr,.creatorcut-colour-fill{filter:'+grade+'!important}'
      '[data-creatorcut-look-grade]{display:none!important}')
 return html.replace('</head>','<style id="creatorcut-colour">'+css+'</style></head>')
def inline_local_fonts(index,project):
 """Expose installed font declarations to the renderer's static compiler.

 Browsers read linked CSS, but the pinned compiler otherwise mistakes its fonts
 for missing and tries an online font download. Keep the same local font files.
 """
 if not index.is_file():return
 from urllib.parse import urlsplit,unquote
 html=index.read_text()
 def replace_link(match):
  tag=match.group(0)
  rel=re.search(r"\brel=[\"']([^\"']+)[\"']",tag,re.I);href=re.search(r"\bhref=[\"']([^\"']+)[\"']",tag,re.I)
  if not rel or 'stylesheet' not in rel.group(1).lower().split() or not href:return tag
  url=urlsplit(href.group(1))
  if url.scheme or url.netloc or url.query:return tag
  sheet=(index.parent/unquote(url.path)).resolve()
  if not sheet.is_relative_to(project.resolve()) or not sheet.is_file() or sheet.stat().st_size>500000:return tag
  css=sheet.read_text()
  if '@font-face' not in css:return tag
  def address(m):
   value=m.group(2);parsed=urlsplit(value)
   if parsed.scheme or parsed.netloc or value.startswith('#'):return m.group(0)
   file=(sheet.parent/unquote(parsed.path)).resolve()
   if not file.is_relative_to(project.resolve()) or not file.is_file():return m.group(0)
   return 'url("'+os.path.relpath(file,index.parent.resolve()).replace(os.sep,'/')+'")'
  css=re.sub(r"url\(\s*([\"']?)([^\"')]+)\1\s*\)",address,css)
  return '<style data-creatorcut-local-fonts="true">'+css+'</style>'
 changed=re.sub(r'<link\b[^>]*>',replace_link,html,flags=re.I)
 if changed!=html:index.write_text(changed)


def validate_composition_assets(p):
 from html.parser import HTMLParser
 from urllib.parse import unquote, urlsplit
 class Assets(HTMLParser):
  def __init__(self):
   super().__init__();self.paths=[]
  def handle_starttag(self, tag, attrs):
   values=dict(attrs)
   value=values.get('src') if tag in ('script','img','video','audio','source','iframe') else values.get('href') if tag=='link' and values.get('rel')=='stylesheet' else None
   if value:self.paths.append((tag,value))
 parser=Assets();parser.feed((p/'index.html').read_text())
 for index, (tag, address) in enumerate(parser.paths,1):
  value=urlsplit(address)
  if value.scheme == 'data' or not value.path:
   continue
  if value.scheme or value.netloc:
   raise CreativeCheckNeeded(f'Composition asset {index} uses an online address. Save the required asset inside this video and update its reference before running this step again. Use the bundled local animation library for graphics.')
  file=(p/unquote(value.path)).resolve()
  if not file.is_relative_to(p.resolve()) or not file.is_file():
   raise CreativeCheckNeeded(f'Composition asset {index} is unavailable. Correct its local reference or restore the asset before running this step again.')


def render_fingerprint(p):
 """Conservative local input identity; dynamic/network assets are never reused."""
 from urllib.parse import urlsplit,unquote
 files={p/'index.html'};todo=[p/'index.html'];seen=set()
 for folder in (p/'assets',p/'fx'):
  if folder.is_dir():files.update(f for f in folder.rglob('*') if f.is_file() and 'work' not in f.relative_to(folder).parts and '__pycache__' not in f.parts and '.pending' not in f.name and not f.name.endswith('.guard'))
 while todo:
  file=todo.pop()
  if file in seen:continue
  seen.add(file)
  if file.suffix not in ('.html','.css','.js'):continue
  text=file.read_text(errors='replace')
  if re.search(r'\bfetch\s*\(|XMLHttpRequest|new\s+Image\s*\(',text):return None
  urls=re.findall(r'(?:src|href)\s*=\s*["\']([^"\']+)|url\(\s*["\']?([^"\')\s]+)',text,re.I)
  for pair in urls:
   url=next(v for v in pair if v);parsed=urlsplit(url)
   if parsed.scheme=='data' or url.startswith('#'):continue
   if parsed.scheme or parsed.netloc:return None
   target=(file.parent/unquote(parsed.path)).resolve()
   if not target.is_relative_to(p.resolve()) or not target.is_file():return None
   if target.relative_to(p.resolve()).parts[0] in ('work','versions','renders'):return None
   files.add(target);todo.append(target)
 h=hashlib.sha256()
 for file in sorted(files):
  if not file.resolve().is_relative_to(p.resolve()):return None
  h.update(str(file.relative_to(p)).encode());h.update(digest_file(file).encode())
 return h.hexdigest()

def reuse_render(p,target,step):
 fingerprint=render_fingerprint(p)
 if not fingerprint:return False
 records=status(p).get('rendered_artifacts',{});rid=status(p).get('request_id')
 for name in dict.fromkeys([target,'renders/base.mp4']):
  row=records.get(name,{});source=p/name
  if row.get('request_id')!=rid or row.get('inputs_sha256')!=fingerprint or not source.is_file():continue
  actual=digest_file(source)
  if row.get('sha256')!=actual:continue
  if name=='renders/final.mp4' and read(p/'music-mix.json').get('mixed_sha256')==actual:continue
  if name!=target:atomic_copy(source,p/target)
  records[target]=dict(row)
  put(p,'working',step_label='Saving your video',overall_percent=WEIGHTS[step][1],rendered_artifacts=records,command_pid=None,heartbeat=time.time())
  print('Your checked video is saved.')
  return True
 return False

def matching_safety_render(p):
 """Recovery's movie and composition must describe the same current picture."""
 records=status(p).get('rendered_artifacts',{});html=digest_file(p/'index.html')
 for name in ('renders/final.mp4','renders/base.mp4'):
  row=records.get(name,{});file=p/name
  if row.get('request_id')==status(p).get('request_id') and row.get('html_sha256')==html and file.is_file() and row.get('sha256')==digest_file(file):return name
 return None

def script(p,name,args):return [sys.executable,str(SCRIPTS/name),str(p),*map(str,args)]
def cut_frames(p):
 segments=read(p/'segments.json',[])
 if isinstance(segments,dict):segments=segments.get('segments',[])
 return sum(row['frames'] for row in segments if isinstance(row,dict) and type(row.get('frames')) is int and row['frames']>0)

def command_limit(step,p):
 def seconds(value):
  try:return max(0,float(value or 0))
  except (TypeError,ValueError):return 0
 def duration_of(rows):
  return sum(seconds(row.get('duration')) for row in rows if isinstance(row,dict))
 if step=='ingest':
  duration=duration_of([m for m in read(p/'project.json').get('media',[]) if m.get('kind')=='raw'])
  if not duration:
   from editkit import util
   for name in read(p/'creator-request.json').get('files',{}).get('raw',[]):
    try:duration+=util.probe(Path(name))['duration']
    except (OSError,ValueError,util.Fail):pass
 elif step=='assemble':
  duration=duration_of([{'duration':seconds(row['out'])-seconds(row['in'])} for row in read(p/'edl.json',[]) if isinstance(row,dict) and 'in' in row and 'out' in row])
 elif step=='words':
  duration=sum(seconds(row.get('frames'))/30 for row in read(p/'segments.json',[]) if isinstance(row,dict))
 else:
  duration=cut_frames(p)/30 or seconds(read(p/'plan.json').get('duration'))
 if step in ('base','render','fx-run','fx-new','layout','init'):return max(1200,min(21600,900+duration*90))
 return max(300,min(3600,180+duration*8))
def stop_child(proc):
 """Only the unreaped direct child/session created by this command."""
 if proc.poll() is not None:return
 if getattr(proc,'_creatorcut_guardian',False):
  try:proc.stdin.write('stop\n');proc.stdin.flush()
  except (OSError,ValueError):pass
  try:proc.wait(timeout=6);return
  except subprocess.TimeoutExpired:pass
 from editkit import stepguard
 stepguard._stop_child(proc,grace=.5)
 try:proc.wait(timeout=5)
 except subprocess.TimeoutExpired:raise Needed(PLAIN['failed'])
def measured_work(line):
 m=re.search(r'(?:Streaming|Rendering|Rendered|Capturing|Captured) (?:frame )?(\d+)/(\d+)',line,re.I)
 if m and int(m[2]):return 'frame',int(m[1]),int(m[2])
 m=re.search(r'(\d+(?:\.\d+)?)/(\d+(?:\.\d+)?)\s*\[[^\]]*?(\d+(?:\.\d+)?)\s*(frames?|seconds?|s)/s\]',line)
 if m and float(m[3])>0:return 'reported',float(m[1]),float(m[2]),float(m[3])
 return None

def measured_progress(line,argv,p):
 m=re.search(r'(?:"pct"\s*:\s*|"percent"\s*:\s*)([\d.]+)',line)
 if m:return float(m[1])
 if len(argv)>1 and Path(str(argv[1])).name=='transcribe_cut.py':
  m=re.search(r'(\d{1,3})%\|',line)
  if m:return float(m[1])
 m=re.search(r'(?:Streaming|Rendering|Rendered|Capturing|Captured) (?:frame )?(\d+)/(\d+)',line,re.I)
 if m and int(m[2]):return float(m[1])*100/int(m[2])
 m=re.search(r'(\d+) frames done,',line)
 if m:
  total=0;args=list(map(str,argv))
  try:
   if '--from' in args and '--to' in args:total=round((float(args[args.index('--to')+1])-float(args[args.index('--from')+1]))*30)
   elif len(args)>2 and Path(args[1]).name=='fx_run.py':total=int(read(Path(args[2])/'clip.json').get('frames',0))
   else:total=cut_frames(p) or round(float(read(p/'plan.json').get('duration',0))*30)
  except (ValueError,IndexError,TypeError):total=0
  if total:return min(100,int(m[1])*100/total)
 return None
def step_display(p,cmd,step):
 lo,hi=WEIGHTS.get(step,(status(p).get('overall_percent',0),status(p).get('overall_percent',0)));label=LABELS.get(step,'Editing your video')
 trial=status(p).get('effect_trial') if step=='render' else None
 if not trial and step not in ('fx-new','fx-run','fx-add'):return lo,hi,label
 args=list(map(str,cmd));key=trial['key'] if trial else Path(args[3] if step=='fx-add' and len(args)>3 else args[2] if len(args)>2 else '').name
 entries=read(LIB/'catalogue.json',{}).get('entries',[]);entry=next((e for e in entries if e.get('key')==key and e.get('kind')=='effect'),None)
 if not entry:return lo,hi,label
 selected=read(p/'creator-request.json').get('choices',{}).get('library_choices',{}).get('effects',[]);keys=[(v.get('id','') if isinstance(v,dict) else str(v)).split(':')[-1] for v in selected]
 active={s.get('key') or s.get('slot') for s in read(p/'plan.json').get('slots',[]) if not s.get('off')}
 n=max(1,len(keys));i=min(n-1,len(active.intersection(keys)-{key}));base=55+21*i/n
 if trial:
  if not keys or set(keys)<=active:return lo,hi,label
  return base+20/n,base+21/n,'Adding your effect'
 a,b=(0,3) if step=='fx-new' else (20,21) if step=='fx-add' else (3,20)
 if step=='fx-run':
  op=args[3:] if len(args)>3 else []
  if op[:1]==['onsets.py']:a,b=3,4
  elif op[:1]==['prep.py']:a,b=4,9
  elif op[:1]==['build.py']:a,b=9,11
  elif op[:2]==['hf','lint']:a,b=11,12
  elif op[:2]==['hf','snapshot']:a,b=12,13
  elif op[:2]==['hf','render']:a,b=13,19
  elif op[:1] in (['post.py'],['check.py']):a,b=19,20
 return base+a/n,base+b/n,('Preparing ' if step=='fx-new' else 'Adding ')+entry['name']
def capture_retry_command(cmd,text,attempt):
 """One same-quality retry for a capture failure after rendering really began.
 Host denials, startup crashes and invalid content are never bypassed/retried.
 """
 words=list(map(str,cmd))
 if attempt or 'render' not in words or not any(Path(w).name in ('hf.py','fx_run.py') for w in words):return None
 if 'Unable to capture screenshot' not in text or '[Parallel]' not in text:return None
 if not re.search(r'"framesCompleted"\s*:\s*[1-9]\d*',text):return None
 if re.search(r'operation not permitted|permission denied|thermal_state_observer_mac|requires approval|sandbox access denied',text,re.I):return None
 if '--workers' in words:
  i=words.index('--workers')
  if i+1>=len(words) or words[i+1]=='1':return None
  del words[i:i+2]
 if '--workers=1' in words:return None
 words=[w for w in words if not w.startswith('--workers=')]
 return [*words,'--workers','1']

def require_step_file(p, relative, reason, message):
 path = p / relative
 if not path.is_file() or not path.stat().st_size:
  raise StepNeedsInput(reason, message)
 return path

def validate_cut_inputs(p):
 from .plan_input import number
 require_step_file(p, 'sources.json', 'missing_source_map',
                   'The source list is missing. Run ingest again in your CreatorCut chat before assembling.')
 sources = read(p/'sources.json')
 if not isinstance(sources, dict) or not sources:
  raise StepNeedsInput('missing_source_map', 'The source list could not be read. Run ingest again before assembling.')
 sections = read(p/'edl.json')
 if not isinstance(sections, list) or not sections:
  raise CreativeCheckNeeded('The cut has no readable edit decisions. Restore or correct the cut list in this chat, then run assemble again.')
 for index, section in enumerate(sections, 1):
  label = f'Cut section {index}'
  if not isinstance(section, dict):
   raise CreativeCheckNeeded(f'{label} is invalid. Correct the cut list and run assemble again.')
  clip = section.get('clip')
  if not isinstance(clip, str) or not isinstance(sources.get(clip), str) or not sources[clip]:
   raise CreativeCheckNeeded(f'{label} names an unknown source clip. Correct the cut list and run assemble again.')
  if not (p / sources[clip]).is_file():
   raise StepNeedsInput('missing_source_media', f'The source for cut section {index} is unavailable. Restore the clip or add it again in Studio.', 'input')
  start, end = section.get('in'), section.get('out')
  if not number(start) or not number(end) or not 0 <= start < end:
   raise CreativeCheckNeeded(f'{label} needs valid start and end times. Correct the cut list and run assemble again.')
  zoom, x, y = section.get('zoom', 1), section.get('cx', .5), section.get('cy', .5)
  if not all(number(n) for n in (zoom, x, y)) or not (0 < zoom <= 20 and 0 <= x <= 1 and 0 <= y <= 1):
   raise CreativeCheckNeeded(f'{label} has invalid framing. Correct its zoom and centre in the cut list, then run assemble again.')

def check_ingest_inputs(files, project=None):
 from editkit import util
 for index, filename in enumerate(files, 1):
  path=util.app_path(filename)
  if not path.is_file():
   raise IngestInputNeeded('missing_input', f'Footage clip {index} is missing. Press Stop edit, add the clip again, then press Make my video.', clip=index)
  symptom=exit_code=None
  try:
   binary=util.ffprobe_bin()
   if index==1:
    version=subprocess.run([binary,'-version'],capture_output=True,timeout=5)
    if version.returncode or not version.stdout.startswith(b'ffprobe version'):
     raise IngestInputNeeded('video_tool_missing','CreatorCut’s local video reader could not start. Ask your CreatorCut chat to repair setup, then type continue.','app')
   metadata=util.probe(path)
  except (OSError,subprocess.TimeoutExpired) as error:
   raise IngestInputNeeded('video_tool_missing','CreatorCut’s local video reader could not start. Ask your CreatorCut chat to repair setup, then type continue.','app') from error
  except (KeyError, ValueError):
   metadata={}
  except util.Fail as error:
   if re.search(r': (?:permission denied|operation not permitted)\s*$',str(error),re.I):
    raise IngestInputNeeded('access', f'CreatorCut could not access footage clip {index}. Check access in your CreatorCut chat, then type continue.', 'host', clip=index) from error
   if str(error).startswith("ffprobe isn't installed"):
    raise IngestInputNeeded('video_tool_missing', 'CreatorCut needs its local video tools. Ask your CreatorCut chat to repair setup, then type continue.', 'app', clip=index) from error
   if re.match(r'ffprobe exceeded .* seconds',str(error)):
    raise IngestInputNeeded('timeout', f'Footage clip {index} took too long to open. Check that it is downloaded to your Mac, then type continue.', 'app', clip=index) from error
   from . import rescue
   symptom=rescue.tool_symptom(str(error))
   exit_code=getattr(error,'exit_code',None)
   metadata={}
  if not metadata.get('width') or not metadata.get('height') or not math.isfinite(metadata.get('duration',0)) or metadata.get('duration',0)<=0:
   message = (f'Footage clip {index} has an incomplete MP4 or MOV container. Download the original again or export it from a playable source, then replace the clip in Studio.'
              if symptom=='missing_movie_index' else f'Footage clip {index} could not be read. Press Stop edit, replace the clip with a playable MP4 or MOV, then press Make my video.')
   raise IngestInputNeeded('source', message, clip=index, symptom=symptom, exit_code=exit_code)
  if project:
   try:megabytes=round(path.stat().st_size/1e6,2)
   except OSError:megabytes=None
   extension=path.suffix.lower()
   audit_event(project,'source.probed',stage='ingest',clip=index,
               codec=metadata.get('codec'),pixel_format=metadata.get('pix_fmt'),width=metadata['width'],height=metadata['height'],
               fps=metadata.get('fps'),duration=round(metadata['duration'],3),megabytes=megabytes,
               extension=extension[1:] if extension in ('.mp4','.mov','.m4v','.mkv','.webm','.avi') else 'other',
               outcome='audio_present' if metadata.get('has_audio') else 'no_audio')
  if not metadata.get('has_audio'):
   raise IngestInputNeeded('silent_input',f'Footage clip {index} has no sound track. Move it to B-roll or replace it with a clip that has sound, then restart the edit.', clip=index)


def run_process(p,cmd,step,_capture_attempt=0,*,mark_complete=True):
 from editkit import resources
 waiting_recorded=False
 def waiting(holder):
  nonlocal waiting_recorded
  ensure(p)
  blocker=holder.get('label') or 'your other editing step'
  name=holder.get('project');progress={}
  if not waiting_recorded:
   audit_event(p,'resource.wait',stage=step,outcome='same_video' if name==p.name else 'other_video' if name else 'local_tool')
   waiting_recorded=True
  own_work=blocker.startswith('Preparing the person cutout for ') and name==p.name and holder.get('request')==status(p).get('request_id')
  if blocker.startswith('Preparing the person cutout for ') and isinstance(name,str) and re.fullmatch('[a-zA-Z0-9_-]+',name) and holder.get('request')==status(p).get('request_id'):progress=read(PROJECTS/name/'work/matte-progress.json')
  overall=float(status(p).get('overall_percent',0))
  if name==p.name and isinstance(progress.get('percent'),(int,float)):overall=max(overall,55+3*min(100,max(0,progress['percent']))/100)
  put(p,'waiting_for',step_label=('Preparing your cutout…' if blocker.startswith('Preparing the person cutout for ') else re.sub(r'^(?:Waiting for\s+)+','',blocker,flags=re.I)),what=blocker,blocker=blocker,overall_percent=overall,percent=overall,eta=progress.get('eta') if name==p.name else None,heartbeat=time.time(),command_pid=None,waiting_own_work=own_work)
  if enforce_edit_budget(p,status(p).get('request_id')):raise Needed(EDIT_BUDGET_MESSAGE)
 with resources.heavy(LABELS.get(step,'Editing your video')+' for '+str(read(p/'project.json').get('title') or p.name),on_wait=waiting,project=p.name,request=status(p).get('request_id')):
  return _run_process(p,cmd,step,_capture_attempt,mark_complete=mark_complete)
def _run_process(p,cmd,step,_capture_attempt=0,*,mark_complete=True):
 from editkit import resources
 ensure(p,starting=True);request=(_REQUEST_CONTEXT.get() or (p.name,status(p).get('request_id')))[1];log=p/'work'/('last-'+step+'.log');log.parent.mkdir(parents=True,exist_ok=True);lo,hi,label=step_display(p,cmd,step)
 limit=command_limit(step,p)
 read_fd,write_fd=os.pipe();guardian=Path(__file__).resolve().parents[1]/'editkit/stepguard.py'
 try:
  proc=subprocess.Popen([sys.executable,'-S',str(guardian),'--supervise',str(write_fd),str(p/'work/child-cpu.json'),'--exec',*map(str,cmd)],cwd=p,env=environment(p),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True,pass_fds=(write_fd,*resources.inherited_fds()))
  proc._creatorcut_guardian=True;proc._creatorcut_status_fd=read_fd
 except BaseException:
  os.close(read_fd);raise
 finally:os.close(write_fd)
 from editkit import util
 started=time.time();began=time.monotonic();last_work=[began]
 measured_step=step in ('ingest','assemble','words');best_progress=-1; samples=[]
 previous=status(p)
 recut=step=='assemble' and 'assemble' in previous.get('completed',[]) and previous.get('overall_percent',0)>=hi
 if recut:label='Re-cutting your video'
 stalled=[False];put(p,'working',active_step=step,step_label='Fixing a small problem…' if status(p).get('rescuing') else label,what=None,blocker=None,percent=None,overall_percent=lo,heartbeat=time.time(),command_pid=proc.pid,command_birth=util.process_identity(proc.pid),command_started=started,eta=None,cut_pass_percent=0 if recut else None)
 audit_event(p,'step.started',request=request,stage=step)
 stop=threading.Event()
 def watch():
  last_tick=began;last_wall=started;active_since=began
  while not stop.wait(2):
   if read(p/'cancel.json').get('cancel') or status(p).get('request_id')!=request:
    stop_child(proc);return
   now,wall=time.monotonic(),time.time()
   if now-last_tick>8 or abs((wall-last_wall)-(now-last_tick))>8:
    # There was no trustworthy observation while the Mac was asleep.
    active_since+=now-last_tick;last_work[0]=now
   last_tick,last_wall=now,wall
   if (not measured_step and now-active_since>limit) or now-last_work[0]>(limit if measured_step else max(300,min(limit,900))):
    stalled[0]=True;stop_child(proc);return
   put(p,_request=request,heartbeat=time.time(),command_pid=proc.pid)
   if enforce_edit_budget(p,request):stop_child(proc);return
 def guarded_watch():
  try:watch()
  except (OSError,Needed):
   stalled[0]=True
   stop_child(proc)
 thread=threading.Thread(target=guarded_watch,daemon=True);thread.start()
 try:
  ingest_phase=None
  with log.open('w') as f:
   for line in proc.stdout:
    f.write(line);f.flush()
    marker=re.fullmatch(r'CREATORCUT_INGEST (speech|media) (\d+)\s*',line) if step=='ingest' else None
    if marker:
     phase,index=marker[1],int(marker[2])
     if phase!=ingest_phase:
      put(p,step_label='Turning speech into text' if phase=='speech' else 'Reading your footage')
     ingest_phase=phase
    percent=measured_progress(line,cmd,p)
    if not measured_step or (percent is not None and percent>best_progress):
     last_work[0]=time.monotonic()
    if percent is not None:
     best_progress=max(best_progress,percent)
     work=measured_work(line);eta=None
     if work and work[0]=='frame':
      _,count,total=work;now=time.monotonic()
      if samples and (samples[-1][2]!=total or count<samples[-1][1]):samples.clear()
      if not samples or count>samples[-1][1]:samples.append((now,count,total));samples=samples[-6:]
      if len(samples)>=3 and samples[-1][0]-samples[0][0]>=2 and count<total:
       eta=round((total-count)*(samples[-1][0]-samples[0][0])/(count-samples[0][1]))
     elif work and work[0]=='reported' and 0<work[1]<work[2]:
      eta=round((work[2]-work[1])/work[3])
     put(p,overall_percent=lo+(hi-lo)*min(100,percent)/100,heartbeat=time.time(),eta=eta,
         **({'cut_pass_percent':max(0,min(100,best_progress))} if recut else {}))
  code=proc.wait()
 finally:
  stop.set();thread.join(timeout=4)
  stop_child(proc)
  if proc.stdout:proc.stdout.close()
  if proc.stdin:proc.stdin.close()
  os.close(proc._creatorcut_status_fd)
 put(p,command_pid=None,cut_pass_percent=None)
 ensure(p)
 if code or stalled[0]:
  # Preserve the first failing output for this request before a retry truncates
  # last-STEP.log. Only bounded local evidence is retained; reports use safe facts.
  if isinstance(request,str) and re.fullmatch(r'[a-f0-9]{32}',request) and step in LABELS:
   saved=p/'work'/('first-failure-'+step+'-'+request+'.log')
   try:
    with log.open('rb') as original:
     original.seek(0,2);original.seek(max(0,original.tell()-65536))
     detail=original.read()
    with saved.open('xb') as first:first.write(detail)
   except OSError:pass
 retry=capture_retry_command(cmd,log.read_text(errors='replace'),_capture_attempt) if code and not stalled[0] and not status(p).get('rescuing') and status(p).get('rescue_attempts',{}).get(step,0)<2 else None
 if retry:
  from editor import rescue
  rescue.consume(p,step)
  atomic_copy(log,log.with_name(log.stem+'.parallel-attempt.log'))
  write(p/'work/capture-retry.json',{'attempts':2,'workers':1,'same_quality':True,'reason':'Parallel frame capture failed after rendering began.'})
  return run_process(p,retry,step,_capture_attempt=1,mark_complete=mark_complete)
 if code or stalled[0]:
  from editor import rescue
  with log.open('rb') as stream:
   stream.seek(0,2);stream.seek(max(0,stream.tell()-65536))
   failure=stream.read().decode(errors='replace')
  from editkit import diagnostics
  facts = diagnostics.failure_facts(failure)
  reason = 'timeout' if stalled[0] else rescue.tool_symptom(failure)
  tool = 'video_renderer' if step in ('base','render','snapshot','lint') else 'ffmpeg' if step in ('assemble','music') else None
  audit_event(p,'step.failed',request=request,stage=step,exit_code=code,tool=tool,
              duration=round(time.monotonic()-began,2),percent=max(0,best_progress),outcome=reason,**facts)
  if stalled[0]:
   raise StepNeedsInput('timeout', f'{label} stopped making progress. Retry this saved step in your CreatorCut chat.', tool=tool, recorded=True)
  if code and step=='ingest' and 'Output file does not contain any stream' in failure and ingest_phase!='speech':raise Needed(PLAIN['silent'])
  if reason=='access_denied' or re.search(r'sandbox access denied|thermal_state_observer_mac',failure,re.I):
   message = ('Choose Full access below the message box for this CreatorCut chat, then type continue so its local video tools can run.'
              if os.environ.get('CODEX_THREAD_ID') else 'The editing tool could not access a local resource. Check access in your CreatorCut chat, then type continue.')
   raise StepNeedsInput('access', message, 'host', tool=tool, recorded=True)
  if step=='ingest' and ingest_phase=='speech':
   raise IngestInputNeeded('speech_recognition', 'Speech recognition could not finish. Your footage is saved. Type continue in your CreatorCut chat to retry.', 'app', clip=index or None, exit_code=code)
  if step=='ingest' and ingest_phase=='media' and index and re.search(r'(?:timecode|track layout)',failure,re.I):
   raise IngestInputNeeded('source',f'Footage clip {index} could not be prepared. Press Stop edit, replace the clip, then press Make my video.',clip=index,symptom='track_layout',exit_code=code)
  if code:
   # This stays in the customer's editing chat. Raw tool text is NEVER
   # included in diagnostics.record or the dashboard payload.
   excerpt=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',failure)
   lines=[re.sub(r'[\x00-\x08\x0b-\x1f\x7f]','',line) for line in excerpt.splitlines() if line.strip()]
   print('CREATORCUT LOCAL TOOL DIAGNOSTIC (not a dashboard report):')
   print('\n'.join(lines[-10:])[-3000:])
  if code and facts.get('detail_code')=='invalid_review_time':
   detail={}
   for line in failure.splitlines():
    if line.startswith('CREATORCUT_REVIEW_TIMING_JSON '):
     try:detail=json.loads(line.split(' ',1)[1])
     except ValueError:pass
   raise ReviewTimingNeeded(detail.get('reason','invalid_words'),detail.get('duration'))
  if code and facts.get('detail_code') in ('renderer_arguments','render_composition'):
   raise CreativeCheckNeeded('The renderer rejected '+('a command option' if facts['detail_code']=='renderer_arguments' else 'the composition')+'. Read the local diagnostic above, correct that exact input and retry. Keep the selected style and captions; do not rerun an unchanged command.')
  if code and facts.get('detail_code') in ('invalid_review_time', 'invalid_data', 'missing_asset', 'invalid_code'):
   raise CreativeCheckNeeded('Correct the local creative files using the step’s saved diagnostic, then run this step again.')
  if code and facts.get('exception_type') in ('NameError','TypeError','KeyError','IndexError','AttributeError'):
   raise StepNeedsInput('tool_error', 'An editing tool encountered an internal error. Its details are saved for support; your earlier versions are safe.', tool=tool, recorded=True)
  if code and step in ('build','lint') and reason=='unclassified':
   failure_class,_,_=rescue.classify(step,None,failure)
   if failure_class=='app':
    if step=='build':
     if re.search(r'(?im)^(?:Unknown caption style|--caption custom needs a caption spec)\b',failure):
      raise CaptionBuildNeeded('The selected captions could not build.')
     if re.search(r'(?im)^Unknown overall style\b',failure):
      raise LookBuildNeeded('The selected look could not build.')
    raise CreativeCheckNeeded('Check the local step details, fix the creative files and run the step again.')
  raise Needed(f'{label} could not finish. Your saved versions are safe. Type continue in your CreatorCut chat to retry.')
 if mark_complete:
  done=status(p).get('completed',[])
  put(p,overall_percent=hi,heartbeat=time.time(),command_pid=None,eta=None,completed=list(dict.fromkeys(done+[step])))
 return log

def await_reference(p,seconds=45):
 """Wait only for styling, with real scan state and no heavy-work resource."""
 refs=read(p/'creator-request.json').get('files',{}).get('references',[])
 from editkit import refs as reference
 def scan_progress(message,fraction):
  ensure(p)
  put(p,'working',active_step='reference',step_label='Reading your reference',percent=round(100*fraction),eta=None,heartbeat=time.time())
 for ref in refs:
  path=Path(ref.get('analysis','')).resolve()
  if not path.is_relative_to(ROOT.resolve()):raise Needed('Please add your reference again in Studio.')
  live=read(path.with_name('ref.json'))
  if (live.get('status')=='saved' or live.get('scan_in_chat') and live.get('status') in ('fetching','analysing')) and not live.get('removed'):
   if live.get('project')!=p.name:raise Needed('Please add your reference again in Studio.')
   scan_progress('Reading your reference',0)
   reference.scan_in_edit(ref['id'],scan_progress,lambda:ensure(p))
 deadline=time.monotonic()+seconds
 while True:
  ensure(p);available=[];pending=[];failed=[]
  for ref in refs:
   path=Path(ref.get('analysis','')).resolve()
   if not path.is_relative_to(ROOT.resolve()):raise Needed('Please add your reference again in Studio.')
   profile=read(path);live=read(path.with_name('ref.json'))
   fallback=read(path.with_name('measurements.json')) if live.get('status')=='done' else {}
   if (profile or fallback) and not live.get('removed') and (not live or live.get('status')=='done'):
    partial=bool(live.get('study_error') and fallback)
    available.append(dict(ref,status='done',measurements=fallback if partial else profile or fallback,**({'fallback_measurements':fallback} if partial else {})))
   elif live.get('status') in ('error','done') or live.get('removed'):failed.append(ref)
   else:pending.append(live)
  write(p/'reference-inputs.json',available)
  if not pending:
   old='Your reference was not ready, so I used your selected style.'
   notices=[n for n in status(p).get('notices',[]) if n not in (old,'Your reference is still being read.')]
   if failed:notices.append('This reference could not be read. Download it and drop the video file here instead. I kept your chosen style.')
   if any(row.get('fallback_measurements') for row in available):
    notices.append('Some reference details could not be read. I used the measurements the scan could verify.')
   put(p,'working',step_label='Applying your reference' if available else 'Finishing your selected style',heartbeat=time.time(),what=None,percent=None,eta=None,notices=list(dict.fromkeys(notices)))
   return {'ready':True,'references':available,'message':'Read the completed measurements and annotated frames; apply their traits and record reference_use.' if available else 'Continue with the selected style.'}
  percent=sum(float(r.get('progress') or 0) for r in pending)/len(pending)*100
  estimates=[r['estimated_remaining_seconds'] for r in pending if isinstance(r.get('estimated_remaining_seconds'),(float,int))]
  put(p,'waiting_for',active_step='reference',what='your reference scan',step_label='Reading your reference…',percent=percent,eta=max(estimates) if estimates else None,heartbeat=time.time())
  if time.monotonic()>=deadline:return {'ready':False,'message':'Your reference is still being read. Run reference again to keep waiting before final styling.'}
  time.sleep(.5)

def init(p):
 req=read(p/'creator-request.json');cfg=req['choices'];choices=cfg.get('library_choices',{});caption=choices.get('caption',{})
 from editkit import styles
 saved=styles.style_path(cfg.get('style',''))
 preset=read(saved) if saved else {}
 if saved:
  from editkit import presets
  preset=dict(preset,design=presets.recipe_context(cfg.get('style',''),cfg.get('preset_version')))
 write(p/'preset-inputs.json',preset)
 available=[]
 for ref in req.get('files',{}).get('references',[]):
  path=Path(ref.get('analysis','')).resolve()
  live=read(path.with_name('ref.json'))
  measured=read(path) or (read(path.with_name('measurements.json')) if live.get('status')=='done' else {})
  if measured and (not live or (live.get('status')=='done' and not live.get('removed') and not live.get('cover_only'))):
   available.append(dict(ref,measurements=measured))
 write(p/'reference-inputs.json',available)
 reference_notice='Your reference is still being read.'
 notices=[n for n in status(p).get('notices',[]) if n!=reference_notice]
 if req.get('files',{}).get('references') and not available:
  notices.append(reference_notice);print(reference_notice)
 if notices!=status(p).get('notices',[]):put(p,notices=notices)
 from editkit import library
 default_caption=library.entry(choices['look']['id']).get('captionStyle','signature') if choices.get('look') else 'signature'
 picks={'mode':'preset' if choices.get('look') else 'custom','style':(choices.get('look') or {}).get('id','').split(':')[-1] or None,'captionStyle':caption.get('id','caption:'+default_caption).split(':')[-1] if isinstance(caption,dict) else 'none' if caption=='none' else 'signature','effects':[r['id'].split(':')[-1] if isinstance(r,dict) else r.split(':')[-1] for r in choices.get('effects',[])]}
 if cfg.get('captions_on') is False or cfg.get('captions',{}).get('enabled') is False:picks['captionStyle']='none'
 write(p/'studio-picks.json',picks)
 if picks.get('style') in ('chalk-talk','show-and-tell') and not (p/'assets/subject.webm').is_file():run_process(p,script(p,'rvm_cut.py',[]),'layout')
 run_process(p,script(p,'init_project.py',[]),'init');plan=read(p/'plan.json');plan['picks']=picks
 from editkit import colour_choice
 grade=colour_choice.choice(cfg) if explicit_colour(cfg) else None
 plan['grade']={'natural':None,'bw':'grayscale(1)','warm':'sepia(.12) saturate(1.08) brightness(1.02)','cinematic':'contrast(1.08) saturate(.86)','moody':'brightness(.90) contrast(1.08) saturate(.88)','bright':'brightness(1.06) contrast(.96) saturate(1.06)','punchy':'contrast(1.12) saturate(1.12)','soft':'contrast(.92) brightness(1.04)','luxe':'contrast(1.04) saturate(.92)','film':'sepia(.08) contrast(.96) saturate(.94)'}.get(grade,plan.get('grade'))
 if grade=='reference':
  target=next((r['measurements'].get('colour') for r in reversed(available) if r['measurements'].get('colour')),None)
  if target:
   from editkit import grade as measured_grade
   ours=measured_grade.stats(p/'assets/aroll.mp4',n=6)
   if ours:
    clamp=lambda v,a,b:max(a,min(b,v))
    brightness=clamp(target['lum']/max(.02,ours['lum']),.85,1.15)
    contrast=clamp(target['contrast']/max(.02,ours['contrast']),.88,1.22)
    saturation=clamp(target['sat']/max(.02,ours['sat']),.75,1.3)
    warmth=clamp((target['warm']-ours['warm'])*.8,0,.18)
    plan['grade']=f'brightness({brightness:.4f}) contrast({contrast:.4f}) saturate({saturation:.4f}) sepia({warmth:.4f})'
    write(p/'reference-colour.json',{'reference':target,'source':ours,'css':plan['grade']})
  else:
   notes=status(p).get('notices',[]);put(p,notices=list(dict.fromkeys(notes+['Your reference was not ready, so I used your selected style.'])))
 write(p/'plan.json',plan)
def remove_unselected_effects(p, request, plan):
 # Only retire effects previously chosen in Studio. Keep independent custom
 # layers, and keep the published versions and their original effect files.
 previous = status(p).get('version') or request.get('feedback_context',{}).get('published_version')
 if not previous:
  versions=saved_versions(p)
  previous=versions[-1].get('n') if versions else None
 if not previous:
  return
 def effects(choices):
  return {str(item.get('id') if isinstance(item,dict) else item).split(':')[-1]
          for item in choices.get('library_choices',{}).get('effects',[])}
 prior=read(p/'versions'/f'v{previous}.settings.json')
 removed=effects(prior)-effects(request.get('choices',{}))
 if removed:
  plan['slots']=[slot for slot in plan.get('slots',[]) if
                 (slot.get('key') or slot.get('slot') or Path(str(slot.get('src',''))).stem.removeprefix('fx-')) not in removed]

def signature_make(request):
 """Only new Signature edits; do not restyle revisions or a selected look."""
 cfg=request.get('choices',{})
 return (request.get('type')=='make' and cfg.get('style') in (None,'','creatorcut-signature')
         and not cfg.get('library_choices',{}).get('look') and not cfg.get('preset_version'))

def full_frame_signature(p,request):
 # Keep the source frame full height. Convert the old lifted layout back to
 # source coordinates, leaving a compact caption lane within the safe area.
 if not signature_make(request):return
 path=p/'layout.json';layout=read(path);lift=layout.get('lift');head=layout.get('head')
 if type(lift) is not int or lift<=0 or not isinstance(head,dict):return
 if not all(type(head.get(k)) is int for k in ('top','top_min','chin_max')):return
 bands=layout.get('bands',{});fits=layout.get('fits',{})
 top,tmin,chin=(head[k] for k in ('top','top_min','chin_max'))
 above=tmin-104>=236
 for key in ('WALL_LEFT','WALL_RIGHT'):
  wall=bands.get(key)
  if isinstance(wall,list) and len(wall)==3:
   wall[1]=max(236,top+(138 if key=='WALL_LEFT' else 182))
 bands.update(HEAD_TOP=top,Y_ABOVE_HEAD=tmin-104 if above else None,Y_CHEST=min(1340,max(1170,chin+30)))
 fits.update(above_head=above,behind_head=(top-226)/.6084>=110,chest='yes' if chin+100<=1170 else 'tight',lower=chin+30<=1376)
 layout.update(lift=0,bands=bands,fits=fits,notes=[
  n for n in layout.get('notes',[]) if not n.startswith('Close-up: the picture is lifted')])
 write(path,layout)

def signature_sound_cues(p,request,plan):
 """Honor explicit layer sounds. Add default entrance sounds only for Signature."""
 cfg=request.get('choices',{})
 if cfg.get('sfx_on',cfg.get('sfx',True)) is False:
  plan['sounds']=[]
  for slot in plan.get('slots',[]):slot['sfx']=[]
  return
 # Respect an authored mix, including an explicit empty list. Rebuild only
 # cues generated here so moving or removing a graphic cannot leave its sound.
 old=plan.get('sounds',[])
 if 'sounds' in plan and (not old or any(not isinstance(c,dict) or not c.get('signature_cue') for c in old)):
  # Resolve familiar cue aliases when the authored mix names a stock sound
  # that is packaged under another name. Keep cue timing and volume intact.
  aliases={'ding.mp3':'ding.wav','impact-bass.mp3':'impact-bass-1.mp3'}
  for cue in old or []:
   source=cue.get('src') if isinstance(cue,dict) else None
   if not isinstance(source,str) or not source.startswith('assets/sfx/') or (p/source).is_file():continue
   name=aliases.get(Path(source).name,Path(source).name)
   if not re.fullmatch(r'[a-z0-9-]+\.(?:mp3|wav)',name):continue
   bundled=(KIT/'sfx' if name.endswith('.wav') else KIT/'style-library/sfx')/name
   if not bundled.is_file():continue
   target=p/'assets/sfx'/name
   if not target.is_file():atomic_copy(bundled,target)
   cue['src']='assets/sfx/'+name
  return
 automatic=signature_make(request) or (
  request.get('type')=='notes' and any(not cue.get('explicit_layer_cue') for cue in old))
 bundled={'click-soft':(.32,.23),'ping':(.55,.24),'chime':(.8,.22),'sparkle':(.65,.23),
          'typing':(1.2,.22),'impact-bass-1':(.65,.24),'impact-bass-2':(.65,.24),
          'whoosh-short':(.52,.25),'whoosh-cinematic':(.85,.23)}
 aliases={'impact-bass':'impact-bass-1'}
 entrances={'pop':('pop','click-soft','ping'),'slide-up':('whoosh-short','click-soft','whoosh'),
            'fade':('swoosh','sparkle','chime')}
 wave_names=('pop','whoosh','swoosh','riser','thud','click','ding','tick','camera')
 cues=[]
 last_automatic=None
 entrance_counts={}
 for layer in plan.get('layers') or []:
  if not isinstance(layer,dict):continue
  at,end=layer.get('from'),layer.get('to')
  if type(at) not in (int,float) or type(end) not in (int,float) or not math.isfinite(at) or not math.isfinite(end) or at<0 or end-at<.08:continue
  if not (layer.get('html') or layer.get('media')):continue
  media=layer.get('media')
  if isinstance(media,dict) and media.get('src') and not (p/media['src']).is_file():continue
  selected=layer.get('sfx')
  if selected is False:continue
  selected=aliases.get(selected,selected) if isinstance(selected,str) else None
  explicit=selected in wave_names or selected in bundled
  if not explicit:
   entrance=layer.get('in')
   if not automatic or not isinstance(entrance,str) or entrance not in entrances:continue
   choices=entrances[entrance];index=entrance_counts.get(entrance,0)
   selected=choices[index%len(choices)]
   if selected==last_automatic:
    index+=1;selected=choices[index%len(choices)]
   entrance_counts[entrance]=index+1;last_automatic=selected
  if selected in bundled:
   duration,volume=bundled[selected];name=selected+'.mp3';src=KIT/'style-library/sfx'/name
   if not src.is_file():continue
  else:
   name=selected+'.wav';src=KIT/'sfx'/name;volume=.25 if not explicit else .22
   import wave
   try:
    with wave.open(str(src),'rb') as sound:duration=sound.getnframes()/sound.getframerate()
   except (OSError,EOFError,wave.Error):continue
  cues.append((at,end,name,duration,volume,explicit))
 sounds=[]
 explicit_times=[at for at,_,_,_,_,explicit in cues if explicit]
 for at,end,name,duration,volume,explicit in sorted(cues):
  if not explicit:
   if any(abs(at-other)<.55 for other in explicit_times):continue
   if sounds and (at-sounds[-1]['at']<.55 or (name==Path(sounds[-1]['src']).name and at-sounds[-1]['at']<2)):continue
  relative='assets/sfx/'+name;target=p/relative
  if not target.is_file():atomic_copy((KIT/'style-library/sfx' if name.endswith('.mp3') else KIT/'sfx')/name,target)
  sounds.append({'src':relative,'at':at,'vol':volume,'dur':min(duration,end-at),'signature_cue':True,'explicit_layer_cue':explicit})
 if sounds:plan['sounds']=sounds
 elif old:plan.pop('sounds',None)

def build_with_fallback(p,args,flags):
 """Try a failed caption/look separately, retaining colour and other choices.
 A host denial, Stop or storage failure is never retried as a creative omission.
 """
 rid=status(p).get('request_id');saved=status(p).get('style_omissions',{})
 omitted=dict(saved) if saved.get('request_id')==rid else {}
 # An explicit retry of the saved caption must reach that renderer, rather
 # than being shadowed by the earlier fallback's first --caption argument.
 selected=read(p/'studio-picks.json').get('captionStyle');options=[*args,*flags]
 retry_caption=bool(omitted.get('caption') and selected not in (None,'none') and any(options[i:i+2]==['--caption',selected] for i in range(len(options)-1)))
 if retry_caption:omitted['caption']=False
 def command(caption=False,look=False):
  override=[]
  if caption:override+=['--caption','none']
  if look:override+=['--style','none']
  return script(p,'build_reel.py',['--picks',str(p/'studio-picks.json'),*override,*flags,*args])
 caption, look = bool(omitted.get('caption')), bool(omitted.get('look'))
 original = (caption, look)
 attempt_log = p/'work/last-build.log'
 while True:
  try:
   result = run_process(p,command(caption,look),'build')
   break
  except Needed as error:
   if (caption, look) == original:
    try:shutil.copyfile(attempt_log,p/'work/last-build-failure.log')
    except OSError:pass
   if cancelled(p):raise
   if isinstance(error, CaptionBuildNeeded) and not caption:
    caption = True
   elif isinstance(error, LookBuildNeeded) and not look:
    look = True
   else:
    raise
 if (caption,look)!=original or retry_caption:
  caption_notice = 'Your captions could not finish, so I left them out of this version.'
  look_notice = 'Your chosen look could not finish, so I kept your clean footage for this version.'
  notices = [notice for notice in status(p).get('notices',[]) if notice not in (caption_notice,look_notice)]
  if caption:
   notices.append(caption_notice)
   if not original[0]:print(caption_notice)
  if look:
   notices.append(look_notice)
   if not original[1]:print(look_notice)
  put(p,style_omissions={'request_id':rid,'caption':caption,'look':look},notices=notices)
 return result

def fx_new(p,args):
 if len(args)<3:raise Needed('Choose the effect and a moment for it in your chat.')
 key=args[0].split(':')[-1];a,b=float(args[1]),float(args[2]);n=round((b-a)*30);segments=read(p/'segments.json',[]);segments=segments.get('segments',[]) if isinstance(segments,dict) else segments
 cuts=[int(r.get('frame',round(r.get('start',0)*30))) for r in segments];total=cut_frames(p)
 keyfile=LIB/'effects'/key/'build.py';code=keyfile.read_text() if keyfile.exists() else ''
 minimum=109 if key=='spotlight' else 72 if key=='frame-break' else 30
 for m in re.finditer(r'assert\s+(?:N|n|FRAMES|frames)\s*>\s*(\d+)',code):minimum=max(minimum,int(m[1])+1)
 overlap=any(float(s.get('from',s.get('t0',s.get('start',0))))<b and a<float(s.get('to',s.get('t1',s.get('end',0)))) for s in read(p/'plan.json').get('slots',[]) if not s.get('off') and (s.get('slot') or s.get('key'))!=key)
 two_shot=next((int(e.get('segments') or 1)>=2 for e in read(LIB/'effects/index.json').get('effects',[]) if e.get('key')==key),False)
 inside=[c for c in cuts if round(a*30)<c<round(b*30)]
 bad_cut=(len(inside)!=1 or inside[0]-round(a*30)<11 or round(b*30)-inside[0]<11) if two_shot else bool(inside)
 if key=='frame-break' and n>90:raise SpanNeeded('Frame Break works in a section up to 3 seconds. Choose a shorter moment.')
 if n<minimum or bad_cut or overlap:
  boundaries=sorted(set([0,*cuts,*[int(r.get('frame',0))+int(r.get('frames',0)) for r in segments]]))
  options=([(max(0,c-max(11,minimum//2))/30,min(total,c+max(11,minimum-minimum//2))/30) for c in cuts if c>=11 and total-c>=11] if two_shot else [(x/30,(x+minimum)/30) for x,y in zip(boundaries,boundaries[1:]) if y-x>=minimum])
  reason='That moment is too short.' if n<minimum else 'That moment overlaps another effect.' if overlap else 'This effect needs one cut with room on each side.' if two_shot else 'That moment crosses a cut.'
  suggestion=min(options,key=lambda pair:abs(pair[0]-a)) if options else None
  raise SpanNeeded(reason+(' Try %.2f to %.2f seconds within one shot.'%suggestion if suggestion else ' This cut has no continuous shot long enough; leave this effect out and keep finishing.'))
 args2=[key,'--project',str(p),'--from',str(a),'--to',str(b),'--picks',str(p/'studio-picks.json')]
 material=read(p/'creator-request.json').get('files',{}).get('effect_material',{}).get(key)
 needs={'orbit':'your reel covers','couch-wall':'your reel covers','green-screen':'your background video or picture','inside-out':'your B-roll clip'}
 if key in needs and not material:raise EffectSkip('it needs '+needs[key]+' from Studio')
 if material:
  material=Path(material).resolve()
  if not material.is_relative_to(p.resolve()) or not material.is_dir():raise EffectSkip('its extra files need adding again in Studio')
  args2+=['--buyer-files',str(material)]
 slot=p/'fx'/key;fingerprint={'source':digest_file(p/'assets/aroll.mp4'),'from':a,'to':b,'key':key}
 if slot.exists() and read(slot/'creatorcut-source.json')!=fingerprint:
  archive=p/'fx/_retired';archive.mkdir(parents=True,exist_ok=True);slot.rename(archive/(key+'-'+secrets.token_hex(5)))
 result=run_process(p,[sys.executable,str(SCRIPTS/'fx_new.py'),*args2],'fx-new')
 if slot.is_dir():write(slot/'creatorcut-source.json',fingerprint)
 return result
def mix_music(p):
 req=read(p/'creator-request.json');cfg=req['choices'];selection=cfg.get('music_selection') or {};mode=selection.get('mode') or cfg.get('music','none');plan=read(p/'plan.json')
 source=require_step_file(p, 'renders/final.mp4', 'missing_render',
                          'The rendered video is missing. Run render before adding music or checking it.');mixed=read(p/'music-mix.json')
 current=digest_file(source) if source.is_file() else None
 if mode=='none':
  if current and current==mixed.get('mixed_sha256'):raise Needed('Rebuild the video in your chat to remove its added music.')
  (p/'music-credit.json').unlink(missing_ok=True);return
 track=p/selection.get('project_file','');offset=0
 if mode=='auto':
  music=plan.get('music',{});track=p/music.get('src','');selection=music
  allowed={str((p/t['project_file']).resolve()):t for t in (cfg.get('music_selection') or {}).get('tracks',[])}
  if str(track.resolve()) not in allowed:raise StepNeedsInput('music_selection_needed','Choose one of the prepared music tracks in your CreatorCut chat, then run music again.','input')
  selection=dict(allowed[str(track.resolve())],reason=music.get('reason',''),mode='auto')
  requested=music.get('start')
  if type(requested) in (int,float) and math.isfinite(requested):
   offset=round(max(0,min(requested,30,(selection.get('duration_seconds') or 0)-2)),3)
  if offset:selection['start']=offset
 if not track.is_file() or not track.stat().st_size:
  raise StepNeedsInput('missing_music_track', 'The selected music track is unavailable. Restore or select the track again in Studio, then continue in your CreatorCut chat.', 'input')
 out=p/'renders/music.pending.mp4'
 volume=max(0,min(1,float(cfg.get('music_volume',.16))))
 mix={'track':digest_file(track),'volume':volume}
 if offset:mix['start']=offset
 if signature_make(req):
  mix['target_lufs']=-14
 elif req.get('type')=='notes':
  base_version=req.get('feedback_context',{}).get('published_version')
  if type(base_version) is int and base_version>0:
   base=read(p/'versions'/f'v{base_version}.entry.json')
   if base.get('n')==base_version and base.get('music_target_lufs')==-14:
    mix['target_lufs']=-14
 signature=hashlib.sha256(json.dumps(mix,sort_keys=True).encode()).hexdigest()
 if current and current==mixed.get('mixed_sha256'):
  if signature==mixed.get('signature'):return
  raise Needed('Rebuild the video in your chat before changing its music.')
 duration=cut_frames(p)/30
 fade=f',afade=t=out:st={max(0,duration-1.5):.3f}:d={min(1.5,duration):.3f}' if duration else ''
 finish=',loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000' if 'target_lufs' in mix else ''
 graph=f'[0:a]loudnorm=I=-16:TP=-1.5,aresample=48000,asplit[voice][key];[1:a]volume={volume},aresample=48000,afade=t=in:d=0.25{fade}[music];[music][key]sidechaincompress=threshold=0.025:ratio=9:attack=12:release=380[duck];[voice][duck]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.89:level=false{finish}[a]'
 start=['-ss',str(offset)] if offset else []
 run_process(p,[str(KIT/'bin/ffmpeg'),'-v','error','-y','-i',str(source),'-stream_loop','-1',*start,'-i',str(track),'-filter_complex',graph,'-map','0:v:0','-map','[a]','-dn','-sn','-write_tmcd','0','-c:v','copy','-c:a','aac','-shortest',str(out)],'music');out.replace(source)
 write(p/'music-credit.json',selection)
 mixed={'signature':signature,'mixed_sha256':digest_file(source),'request_id':req.get('id')}
 if 'target_lufs' in mix:mixed['target_lufs']=mix['target_lufs']
 write(p/'music-mix.json',mixed)
 records=status(p).get('rendered_artifacts',{});saved=records.get('renders/final.mp4',{})
 if saved.get('request_id')==status(p).get('request_id'):
  saved['sha256']=digest_file(source);records['renders/final.mp4']=saved;put(p,rendered_artifacts=records)

def saved_versions(p):
 index=p/'versions/versions.json'
 try:
  doc=json.loads(index.read_text())
  if isinstance(doc.get('versions'),list) and all(isinstance(v,dict) and isinstance(v.get('n'),int) for v in doc['versions']):return doc['versions']
 except (OSError,ValueError,AttributeError):pass
 rows=[]
 for file in sorted((p/'versions').glob('v*.mp4')):
  m=re.fullmatch(r'v(\d+)\.mp4',file.name)
  if not m:continue
  n=int(m[1]);entry=read(p/'versions'/f'v{n}.entry.json');digest=digest_file(file)
  if entry.get('n')==n and entry.get('candidate_sha256')==digest and entry.get('file')==str(file.relative_to(ROOT)):
   rows.append(entry);continue
  try:
   info=json.loads(subprocess.check_output([str(KIT/'bin/ffprobe'),'-v','error','-show_format','-of','json',str(file)],timeout=15))
   duration=float(info['format']['duration'])
   if duration>0:rows.append({'n':n,'file':str(file.relative_to(ROOT)),'duration':duration,'candidate_sha256':digest,'created':file.stat().st_mtime,'note':'Saved video'})
  except (OSError,ValueError,KeyError,subprocess.SubprocessError):continue
 if index.exists() and not rows:raise Needed('Your saved video list needs repair. Open your CreatorCut chat and ask it to restore your saved versions.')
 return sorted(rows,key=lambda row:row['n'])
def clear_render_temporary(p):
 """Finished decoder frames only; retain sources, mattes, plans and every saved version."""
 temporary=p/'work/tmp'
 if temporary.is_symlink() or not temporary.resolve().is_relative_to(p.resolve()):return
 try:
  if temporary.is_dir():shutil.rmtree(temporary)
 except OSError:pass # Cleanup never turns a published movie into a failed edit.
def snapshot_design(p,folder):
 """Keep the actual editable design with a version; never copy example media.

 Creative HTML can differ from plan.json. Retaining only the plan loses those
 changes when the creator saves that version as a preset after another edit.
 """
 folder=Path(folder);files={};allowed={'.html','.css','.js','.py','.json','.svg'}
 candidates=[p/'index.html',*p.glob('*.css'),*p.glob('*.js')]
 for slot in read(p/'plan.json').get('slots',[]):
  key=str(slot.get('slot') or slot.get('key') or '')
  if not re.fullmatch(r'[a-zA-Z0-9_-]+',key):continue
  effect=p/'fx'/key
  if effect.is_dir():candidates.extend(f for f in effect.iterdir() if f.is_file())
 for source in candidates:
  if source.suffix.lower() not in allowed or source.is_symlink() or not source.resolve().is_relative_to(p.resolve()) or not source.is_file():continue
  if source.stat().st_size>2_000_000:continue
  relative=source.relative_to(p);target=folder/relative
  if not target.exists():atomic_copy(source,target)
  files[str(relative)]=digest_file(target)
 write(folder/'design.json',{'schema':1,'files':files,'adaptation':'Read this actual design as evidence. Adapt typography, layout and animation to new speech; never reuse example footage, words or absolute times.'})
 return files

def final_effect_notices(p):
 """Compare the current request with the actual enabled slots at publication."""
 st=status(p);notices=list(st.get('notices',[]));slots=read(p/'plan.json').get('slots',[])
 slots=[slot for slot in slots if isinstance(slot,dict)]
 # The builder can reject an enabled plan slot (missing media, bad span).
 # Its finished composition, bound to the render receipt, is authoritative.
 built_sources=None
 if (p/'work/build.json').is_file() and (p/'index.html').is_file():
  from html.parser import HTMLParser
  class EffectVideos(HTMLParser):
   def handle_starttag(self,tag,attrs):
    if tag!='video':return
    attr=dict(attrs)
    if re.fullmatch(r'fx[0-9]+',attr.get('id') or '') and attr.get('src'):
     built_sources.add(attr['src'])
  built_sources=set()
  EffectVideos().feed((p/'index.html').read_text())
 def label(key):
  from editkit import library,util
  try:return library.entry('effect:'+key)['name']
  except (util.Fail,KeyError,ValueError):return key.replace('-',' ').title()
 def attached(key):
  return any(not slot.get('off') and (built_sources is None or slot.get('src') in built_sources) and (
   str(slot.get('slot') or '').split(':')[-1]==key or str(slot.get('key') or '').split(':')[-1]==key
   or Path(str(slot.get('src',''))).stem in (key,'fx-'+key)) for slot in slots)
 def mentioned(key):
  starts=('I left '+label(key)+' out','I left '+key.replace('-',' ').title()+' out')
  return any(n.casefold().startswith(tuple(x.casefold() for x in starts)) for n in notices)
 for slot in slots:
  if slot.get('off') and slot.get('stale_cut'):
   key=str(slot.get('key') or slot.get('slot') or 'effect').split(':')[-1]
   if not attached(key) and not mentioned(key):
    notices.append('I left '+label(key)+' out because the cut changed and the effect was not rebuilt.')
 for key,notice in st.get('pending_effect_notices',{}).items():
  if not st.get('failed_effects',{}).get(key):continue
  if attached(key):notice='I kept the last good '+label(key)+': that change could not finish.'
  elif mentioned(key):continue
  if notice not in notices:notices.append(notice)
 for pick in read(p/'creator-request.json').get('choices',{}).get('library_choices',{}).get('effects',[]):
  identifier=pick.get('id') if isinstance(pick,dict) else pick
  if not isinstance(identifier,str) or not re.fullmatch(r'effect:[a-z0-9-]+',identifier):continue
  key=identifier.split(':',1)[1]
  if not attached(key) and not mentioned(key):
   title=label(key);reason=st.get('unsuitable_effects',{}).get(title)
   notices.append('I left '+title+' out: '+(reason or 'the edit did not finish applying it.'))
 return notices
def require_current_render(p,src):
 st=status(p)
 record=st.get('rendered_artifacts',{}).get(str(src.relative_to(p)),{})
 if record.get('request_id')!=st.get('request_id') or record.get('sha256')!=digest_file(src) or record.get('html_sha256')!=digest_file(p/'index.html') or record.get('inputs_sha256') and record['inputs_sha256']!=render_fingerprint(p):
  raise RenderNeeded('The edit changed after its last render. Run .venv/bin/python edit.py render, then music and check. Review the finished frames before running publish again.')
 return record

def publish(p,args):
 ensure(p);src=p/(args[0] if args else 'renders/final.mp4')
 if not src.resolve().is_relative_to(p.resolve()) or not src.is_file():raise Needed('Finish rendering your video, then save it again.')
 require_current_render(p,src)
 request_data=read(p/'creator-request.json')
 choices=request_data.get('choices',{})
 selected_music=(choices.get('music_selection') or {}).get('mode') or choices.get('music','none')
 mix=read(p/'music-mix.json')
 actual_digest=digest_file(src)
 mixed_here=mix.get('mixed_sha256')==actual_digest and mix.get('request_id')==request_data.get('id')
 if selected_music!='none' and not mixed_here and not status(p).get('rescue_override',{}).get('no_music'):
  raise RenderNeeded('Your selected music has not been added to this render. Run .venv/bin/python edit.py music, then check and publish.')
 if selected_music=='none' and mix.get('mixed_sha256')==actual_digest:
  raise RenderNeeded('This render still has music. Rebuild it without music, then check and publish.')
 probe=json.loads(subprocess.check_output([str(KIT/'bin/ffprobe'),'-v','error','-count_frames','-show_streams','-show_format','-of','json',str(src)]))
 base=json.loads(subprocess.check_output([str(KIT/'bin/ffprobe'),'-v','error','-count_frames','-show_streams','-of','json',str(p/'assets/aroll.mp4')]))
 # Compare picture to picture. Container duration may include a longer source
 # audio tail; conversely, long audio must not disguise truncated video.
 def picture(doc):
  v=next((s for s in doc.get('streams',[]) if s.get('codec_type')=='video'),{})
  try:
   n=int(v.get('nb_read_frames') or v.get('nb_frames') or 0)
   num,den=map(float,v.get('avg_frame_rate','0/1').split('/'));fps=num/den
   seconds=float(v.get('duration') or (n/fps if fps else 0))
   return n,fps,seconds
  except (ValueError,TypeError,ZeroDivisionError):return 0,0,0
 n,fps,duration=picture(probe);bn,bfps,base_duration=picture(base)
 audio=next((s for s in probe.get('streams',[]) if s.get('codec_type')=='audio'),{})
 try:audio_duration=float(audio.get('duration',0))
 except (ValueError,TypeError):audio_duration=0
 if n<=0 or bn<=0 or fps<=0 or bfps<=0 or duration+.5/max(fps,bfps)<base_duration or audio_duration+.1<duration:
  raise Needed('The video has not finished rendering yet. Please continue in your chat.')
 subprocess.run([str(KIT/'bin/ffmpeg'),'-nostdin','-v','error','-xerror','-i',str(src),'-map','0:v:0','-map','0:a:0','-f','null','-'],check=True,capture_output=True,timeout=max(60,duration*5))
 with lock(p/'.publish.guard'):
  index=p/'versions/versions.json';versions=saved_versions(p);digest=digest_file(src);existing=next((v for v in versions if v.get('candidate_sha256')==digest and v.get('request_id')==status(p).get('request_id')),None)
  newly_published=not existing
  if not existing:
   next_n=max([v.get('n',0) for v in versions]+[0])+1
   request=status(p).get('request_id')
   for entry in (p/'versions').glob('v*.entry.json'):
    row=read(entry);n=row.get('n')
    if isinstance(n,int) and n>=next_n and row.get('request_id')==request and row.get('candidate_sha256')==digest:
     expected=p/'versions'/f'v{n}.mp4'
     if row.get('file')==str(expected.relative_to(ROOT)) and (not expected.exists() or digest_file(expected)==digest):
      existing=row;break
   if not existing:
    from editkit import videos
    n=videos.next_version_number(p/'versions',versions);dst=p/'versions'/f'v{n}.mp4';dst.parent.mkdir(exist_ok=True)
    while dst.exists():n+=1;dst=p/'versions'/f'v{n}.mp4'
    existing={'n':n,'file':str(dst.relative_to(ROOT)),'duration':duration,'created':time.time(),'time':time.time(),'note':'Edited in your chat','candidate_sha256':digest,'request_id':request}
    mix=read(p/'music-mix.json')
    if mix.get('mixed_sha256')==digest and mix.get('request_id')==request and mix.get('target_lufs')==-14:
     existing['music_target_lufs']=-14
    write(p/'versions'/f'v{n}.entry.json',existing)
   n=existing['n'];dst=ROOT/existing['file']
   if not dst.exists():atomic_copy(src,dst)
   finished=ROOT/'my-videos/finished'/f'{p.name}-v{n}.mp4';finished.parent.mkdir(parents=True,exist_ok=True);atomic_copy(src,finished)
   versions.append(existing)
  for name,suffix in [('words.json','words.json'),('segments.json','segments.json'),('plan.json','plan.json'),('work/build.json','build.json')]:
   if (p/name).exists():shutil.copy2(p/name,p/'versions'/f"v{existing['n']}.{suffix}")
  write(p/'versions'/f"v{existing['n']}.settings.json",read(p/'creator-request.json').get('choices',{}))
  design=p/'versions'/f"v{existing['n']}.design"
  if not (design/'design.json').is_file():snapshot_design(p,design)
  if mixed_here and selected_music!='none' and (p/'music-credit.json').is_file():
   shutil.copy2(p/'music-credit.json',p/'versions'/f"v{existing['n']}.music-credit.json")
   from editkit import music_library
   credit=music_library.attribution(read(p/'music-credit.json'))
   if credit:
    credits=p/'versions'/f"v{existing['n']}.credits.txt"
    credits.write_text(credit['text']+'\n',encoding='utf-8')
    existing.update(music_credit=credit,credits_file=str(credits.relative_to(ROOT)))
  # Publish pointers only after the validated movie and its edit metadata exist.
  atomic_copy(src,p/'preview.mp4')
  write(index,{'versions':versions})
  from editkit import videos
  videos.update(p.name,lambda cfg:cfg.update(latest=existing['file'],status='finished',version=existing['n']))
  ids={n['id'] for n in read(p/'creator-request.json').get('notes',[])}
  review=read(p/'work/feedback-boundary.json')
  verified=set(review.get('verified_notes',[])) if review.get('request_id')==status(p).get('request_id') and review.get('video_sha256')==digest else set()
  if ids:
   with lock(p/'.annotations.guard',True):
    notes=read(p/'annotations.json',{'notes':[]})
    for n in notes.get('notes',[]):
     if n.get('id') in ids:
      if n['id'] in verified:n.update(status='ready',applied_version=existing['n'])
      elif n.get('status')!='ready':
       n.pop('applied_version',None)
       n.update(status='unverified',reviewed_version=existing['n'])
    write(p/'annotations.json',notes)
  counter=read(ROOT/'my-brand/learning-progress.json',{'completed':{}});counter.setdefault('completed',{})[p.name]={'sha256':digest,'time':time.time(),'published':True};write(ROOT/'my-brand/learning-progress.json',counter)
  put(p,'done',overall_percent=100,step_label='Your video is ready',version=existing['n'],command_pid=None,heartbeat=time.time(),notices=list(dict.fromkeys(final_effect_notices(p)+(read(p/'work/feedback-boundary.json').get('notices',[]) if read(p/'work/feedback-boundary.json').get('request_id')==status(p).get('request_id') else []))))
  clear_render_temporary(p)
  if newly_published:
   from editkit import telemetry
   st=status(p)
   from editkit import problem_reports
   problem_reports.record_outcome(st.get('request_id'),'published')
   telemetry.event('edit_finished',project=p.name,request=st.get('request_id'),seconds=st.get('elapsed'),
                   details={'version':existing['n'],'rescues':sum(st.get('rescue_attempts',{}).values()),'ai_steps':st.get('ai_steps',0),'effects_used':len(read(p/'plan.json').get('slots') or []),'effects_skipped':len(st.get('failed_effects') or {})})
 return {'message':'Your video is ready.','version':existing['n'],'notices':status(p).get('notices',[])}
def main(argv):
 cmd=argv[0] if argv else 'status';args=argv[1:];request_token=None;runner_owned=False;admitted=False;runner_project=None;runner_request=None
 started_at=time.monotonic()
 try:
  if cmd=='_matte':
   from editor import matte
   matte.run(args[0],args[1] if len(args)>1 else None);return 0
  if cmd=='_status-clock':status_clock();return 0
  if cmd=='_awake':hold_awake(args[0],args[1]);return 0
  if cmd=='wait':wait();return 0
  if cmd=='ask' and (not args or any(arg.startswith('-') for arg in args)):
   print('Usage: edit.py ask "Your question for the customer"')
   return 0 if args in (['--help'],['-h']) else 2
  if cmd=='next':print(json.dumps(next_request(),indent=2));return 0
  p=current()
  if cmd=='status':print(json.dumps(public(args[0]) if args else status(p) if p else {},indent=2));return 0
  if not p:raise Needed('Choose your video in Studio and press Make my video.')
  st=status(p);owner=chat_owner()
  context=_REQUEST_CONTEXT.get();expected=(p.name,st.get('request_id'))
  if context and context!=expected:raise Needed(PLAIN['stopped'])
  request_token=_REQUEST_CONTEXT.set(expected)
  if enforce_edit_budget(p,expected[1]):raise Needed(EDIT_BUDGET_MESSAGE)
  # Register the entire local command, including its resource wait and metadata
  # prelude. The queue guard makes starting a command and taking ownership
  # atomic with respect to each other. Nested calls share the outer lease.
  with lock(KIT/'.update.guard',message='CreatorCut is updating. Type continue after it finishes.',shared=True) if not context else contextlib.nullcontext(), lock(OUT/'.queue.guard',True):
   from editkit import updater,util
   try:updater.require_recovered()
   except util.Fail as error:raise Needed(error.message) from None
   st=status(p)
   if st.get('request_id')!=expected[1]:raise Needed(PLAIN['stopped'])
   if st.get('resume_here'):raise Busy('This edit is waiting for a different Codex chat to claim it. Type continue in that chat before running an editing step.')
   if st.get('owner') and st['owner']!=owner:raise Busy('This video is being edited in your other chat.')
   nested=context==expected and st.get('command_runner_pid')==os.getpid()
   if command_alive(st) and not nested:raise Busy('This video is being edited in your other chat.')
   if not nested:
    from editkit import util
    if cancelled(p) or not st or st.get('state') in ('stopped','done') or st.get('paused_for_update') or (st.get('state')=='waiting_chat' and not st.get('claimed_at')):
     raise Needed('Open the saved edit in your CreatorCut chat first.')
    first_step=cmd in (*LABELS,'reference') and (not st.get('started') or st.get('state')=='waiting_chat')
    if first_step:
     put(p,'working',started=st.get('started') or time.time(),step_label=LABELS.get(cmd,'Reading your reference'),heartbeat=time.time(),waiting_for_last_step=False)
    put(p,command_runner_pid=os.getpid(),command_runner_birth=util.process_identity(os.getpid()))
    runner_owned=True;runner_project=p;runner_request=expected[1]
   admitted=True
  if cmd=='ask':
   if st.get('state')=='needs_you' and st.get('question'):
    print(st['question']);return 1
   put(p,'needs_you',step_label=PLAIN['needs'],question=' '.join(args) if args and not TECH.search(' '.join(args)) else PLAIN['needs'])
   audit_event(p,'customer.input',request=expected[1],outcome='chat_question')
   print('Please answer the question in your chat.');return 0
  if cmd=='progress':put(p,'working',step_label='Designing your graphics',heartbeat=time.time());print('Designing your graphics.');return 0
  from editor import rescue
  if cmd in ('retry','rescue'):
   try:return rescue.run(p,cmd,args)
   except (Needed,OSError,ValueError,subprocess.SubprocessError) as error:
    failed=status(p).get('failed_step')
    if failed and status(p).get('rescuing'):
     put(p,'needs_you',step_label=PLAIN['failed'])
     rescue.failed(p,failed,error,(status(p).get('rescue_failure') or {}).get('args',[]))
    print(str(error) if isinstance(error,Needed) else PLAIN['failed']);return 1
  ensure(p)
  recovery=status(p)
  failure=recovery.get('rescue_failure') or {}
  if recovery.get('failed_step')==cmd and not recovery.get('rescuing') and failure.get('action'):
   fresh_publish=False
   if cmd=='publish':
    src=p/(args[0] if args else 'renders/final.mp4')
    if src.resolve().is_relative_to(p.resolve()) and src.is_file():
     receipt=require_current_render(p,src)
     fresh_publish=receipt['sha256']!=failure.get('render_sha256')
   if fresh_publish:
    put(p,failed_step=None,rescue_failure=None)
   else:rescue.consume(p,cmd)
  if cmd in LABELS:
   put(p,ai_steps=status(p).get('ai_steps',0)+1)
  # Keep the first effect's checked render when a later effect fails.
  trial=status(p).get('effect_trial')
  if cmd=='fx-add' and trial and args and trial.get('key')!=args[0]:
   if main(['build']) or main(['render']):return 1
  if cmd=='fx-add' and args and not status(p).get('failed_effects',{}).get(args[0]):inline_local_fonts(p/'index.html',p)
  if cmd=='fx-add' and args and not status(p).get('failed_effects',{}).get(args[0]) and not matching_safety_render(p):
   if main(['render']):return 1
  with lock(p/'.recipe-command.guard'):
   if cmd=='ingest':
    files=rescue.ingest_files(p,read(p/'creator-request.json')['files']['raw'])
    check_ingest_inputs(files,p)
    run_process(p,[sys.executable,str(KIT/'editor/ingest.py'),str(p),*files],'ingest')
   elif cmd=='assemble':
    validate_cut_inputs(p)
    if read(p/'creator-request.json').get('type')=='make':
     from .speech import speech_cut_edges
     with contextlib.suppress(OSError, ValueError, KeyError, TypeError, AttributeError):
      sections,edges=speech_cut_edges(p)
      if edges:
       write(p/'edl.json',sections)
       print(f'Protected {len(edges)} speech boundaries at quiet points.',flush=True)
    aroll=p/'assets/aroll.mp4';plan=read(p/'plan.json')
    before=digest_file(aroll) if aroll.is_file() and plan.get('slots') else None
    run_process(p,script(p,'assemble.py',[]),'assemble')
    if before and before!=digest_file(aroll):
     for slot in plan['slots']:
      if not slot.get('off'):slot.update(off=True,stale_cut=True)
     write(p/'plan.json',plan)
     print('The cut changed. Rebuild the selected effects against the new footage before publishing.')
   elif cmd=='words':
    mode=[] if status(p).get('rescue_override',{}).get('transcribe_chunked') else ['--whole']
    run_process(p,[sys.executable,str(KIT/'editor/transcribe-rescue.py'),str(p),*mode,*args],'words')
    run_process(p,[sys.executable,str(LIB/'effects/type-wall/onsets.py'),'--project',str(p)],'words')
   elif cmd=='layout':
    if status(p).get('rescue_override',{}).get('no_cutout'):
     print('Use front-layer graphics in this edit.');put(p,rescuing=False,failed_step=None);return 0
    run_process(p,script(p,'layout.py',args),'layout')
    full_frame_signature(p,read(p/'creator-request.json'))
   elif cmd=='init':caption_language_notice(p);init(p)
   elif cmd=='reference':print(json.dumps(await_reference(p),indent=2));put(p,rescuing=False,failed_step=None);return 0
   elif cmd=='build':
    request=read(p/'creator-request.json');cfg=request.get('choices',{});choices=cfg.get('library_choices',{});flags=[]
    if choices.get('look'):flags+=['--style',choices['look']['id'].split(':')[-1]]
    if cfg.get('captions',{}).get('enabled') is False or cfg.get('captions_on') is False or choices.get('caption')=='none':flags+=['--caption','none']
    elif isinstance(choices.get('caption'),dict):flags+=['--caption',choices['caption']['id'].split(':')[-1]]
    if status(p).get('rescue_override',{}).get('captions_basic') and ('--caption' not in flags or flags[flags.index('--caption')+1]!='none'):
     if '--caption' in flags:
      i=flags.index('--caption');flags[i+1]='signature'
     else:flags+=['--caption','signature']
    full_frame_signature(p,request)
    from . import plan_input
    try:
     plan=plan_input.load(p,cut_frames(p)/30)
    except plan_input.InvalidPlan as error:
     raise CreativeCheckNeeded(str(error)) from None
    before=copy.deepcopy(plan)
    remove_unselected_effects(p,request,plan)
    if signature_make(request) and not choices.get('caption') and not plan.get('caption'):
     plan['caption']={
      'font':'Inter Tight','weight':800,'size':92,'words':3,'chars':14,
      'mark':'accent','accent':'#F6E6BF','position':'chest','dy':32,
      'css':(".cu .w{text-shadow:0 6px 26px rgba(0,0,0,.5),0 2px 5px rgba(0,0,0,.35)}"
             ".cu .w.m{font-family:'Instrument Serif';font-style:italic;font-weight:400;font-size:1.22em;"
             "text-shadow:0 6px 26px rgba(0,0,0,.55),0 0 2px rgba(60,40,0,.45)}"),
     }
    signature_sound_cues(p,request,plan)
    if plan!=before:write(p/'plan.json',plan)
    build_log=build_with_fallback(p,args,flags)
    if isinstance(build_log,Path):
     warnings=[line for line in build_log.read_text(errors='replace').splitlines()
               if line.startswith('NOTE') and 'do not play in the renderer' in line]
     notice='One animation used a format that does not play in the exported video.'
     notices=[n for n in status(p).get('notices',[]) if n!=notice]
     if warnings:
      notices.append(notice)
      print(*warnings,sep='\n')
     if notices!=status(p).get('notices',[]):put(p,notices=notices)
    if explicit_colour(cfg):
     page=p/'index.html';page.write_text(apply_colour_choice(page.read_text(),read(p/'plan.json').get('grade')))
   elif cmd in ('lint','snapshot','render','base'):
    require_step_file(p, 'index.html', 'missing_composition',
                      'The video composition is missing. Run build in your CreatorCut chat, then retry this step.')
    if cmd != 'lint':
     require_step_file(p, 'assets/aroll.mp4', 'missing_cut',
                       'The prepared video cut is missing. Run assemble, then build, before retrying this step.')
    inline_local_fonts(p/'index.html',p)
    validate_composition_assets(p)
    op='render' if cmd in ('base','render') else cmd
    target='renders/base.mp4' if cmd=='base' else 'renders/final.mp4';pending=p/('renders/base.pending.mp4' if cmd=='base' else 'renders/final.pending.mp4')
    if op=='render' and reuse_render(p,target,cmd):
     if cmd=='render' and status(p).get('failed_step')=='publish':
      put(p,rescuing=False,failed_step=None,rescue_failure=None)
     return 0
    if op=='render':pending.unlink(missing_ok=True)
    flags=['-o',str(pending.relative_to(p)),'--quality','high','--sdr',*args] if op=='render' else args
    if op=='render' and status(p).get('rescuing'):
     if '--workers' in flags:
      i=flags.index('--workers');del flags[i:i+2]
     flags=[flag for flag in flags if not flag.startswith('--workers=')]+['--workers','1']
    recovered=False
    try:run_process(p,script(p,'hf.py',[op,*flags]),cmd)
    except Needed:
     trial=status(p).get('effect_trial')
     if cmd!='render' or not trial or read(p/'cancel.json').get('cancel'):raise
     folder=p/'work/effect-trial';good=p/trial['previous_good'];record=status(p).get('rendered_artifacts',{}).get(trial['previous_good'],{})
     if not good.is_file() or record.get('request_id')!=status(p).get('request_id') or record.get('sha256')!=digest_file(good):raise
     atomic_copy(folder/'plan.json',p/'plan.json');atomic_copy(folder/'index.html',p/'index.html');atomic_copy(good,p/'renders/final.mp4')
     notices=status(p).get('notices',[]);notice='I left '+trial['key'].replace('-',' ').title()+' out: the effect could not be combined in the finished render.'
     put(p,'working',step_label='Finishing your video',notices=list(dict.fromkeys(notices+[notice])),effect_trial=None)
     print('SKIP: '+notice);recovered=True
    if op=='render':
     file=p/target
     if not recovered:
      if not pending.is_file():raise Needed('The video has not finished rendering yet. Please continue in your chat.')
      pending.replace(file)
     else:pending.unlink(missing_ok=True)
     if not file.is_file():raise Needed('The video has not finished rendering yet. Please continue in your chat.')
     records=status(p).get('rendered_artifacts',{});records[str(file.relative_to(p))]={'request_id':st.get('request_id'),'sha256':digest_file(file),'html_sha256':digest_file(p/'index.html'),'inputs_sha256':render_fingerprint(p)}
     put(p,rendered_artifacts=records,effect_trial=None)
     clear_render_temporary(p)
   elif cmd=='fx-new':fx_new(p,args)
   elif cmd=='fx-run':
    extra=args[1:]
    if extra[:1]==['build.py'] and read(p/'studio-picks.json').get('captionStyle')=='none':
     extra=[flag for flag in extra if not flag.startswith('CAPTIONS=')]+['CAPTIONS=0']
    if extra[:1]==['hf']:inline_local_fonts(p/'fx'/args[0]/'index.html',p)
    if extra[:2]==['hf','render'] and '--sdr' not in extra:extra=[*extra,'--sdr']
    run_process(p,[sys.executable,str(SCRIPTS/'fx_run.py'),str(p/'fx'/args[0]),*extra],cmd)
    if extra[:2]==['hf','render']:clear_render_temporary(p)
    if extra[:1]==['check.py'] or extra[:2]==['hf','render'] and not (p/'fx'/args[0]/'check.py').is_file():
     failed=status(p).get('failed_effects',{});failed.pop(args[0],None)
     pending=status(p).get('pending_effect_notices',{});pending.pop(args[0],None)
     prefix='I left '+args[0].replace('-',' ').title()+' out:'
     put(p,failed_effects=failed,pending_effect_notices=pending,notices=[n for n in status(p).get('notices',[]) if not n.startswith(prefix)])
   elif cmd=='fx-add':
    if status(p).get('failed_effects',{}).get(args[0]):raise EffectSkip('its finished effect has not passed its check yet')
    folder=p/'work/effect-trial';folder.mkdir(parents=True,exist_ok=True)
    atomic_copy(p/'plan.json',folder/'plan.json');atomic_copy(p/'index.html',folder/'index.html')
    good=matching_safety_render(p)
    if not good:raise EffectSkip('the current picture still needs its safety render')
    put(p,effect_trial={'key':args[0],'previous_good':good})
    run_process(p,script(p,'fx_add.py',[str(p/'fx'/args[0]),'--picks',str(p/'studio-picks.json'),*args[1:]]),cmd)
    prefix='I left '+args[0].replace('-',' ').title()+' out:';put(p,notices=[n for n in status(p).get('notices',[]) if not n.startswith(prefix)])
   elif cmd=='fx-check':
    result=run_process(p,script(p,'footage_check.py',[*args,'--picks',str(p/'studio-picks.json')]),cmd)
    if isinstance(result,Path):
     unsuitable={}
     for line in result.read_text(errors='replace').splitlines():
      match=re.fullmatch(r'SKIP  ([^:]+): (.+)',line)
      if match:
       title,reason=match.groups()
       if len(reason)<=400 and not TECH.search(reason):
        unsuitable[title]=re.sub(r' \(the head is \d+px wide\)','',reason)
     put(p,unsuitable_effects=unsuitable)
   elif cmd=='check':
    verified=[];frame_args=[];remaining=iter(args)
    for arg in remaining:
     if arg=='--verified-note':
      note=next(remaining,'')
      if not note:raise Needed('Choose the feedback note you checked.')
      verified.append(note)
     else:frame_args.append(arg)
    request=read(p/'creator-request.json')
    if not frame_args or frame_args[0].startswith('--'):
     require_step_file(p,'renders/final.mp4','missing_render','The rendered video is missing. Run render before checking it.')
    if set(verified)-{note['id'] for note in request.get('notes',[])} or (verified and frame_args):
     raise Needed('Check feedback against the finished video for this request.')
    review_args=frame_args if frame_args and not frame_args[0].startswith('--') else ['renders/final.mp4',*frame_args]
    try:run_process(p,script(p,'frames_check.py',review_args),cmd)
    except ReviewTimingNeeded as error:
     if error.reason!='explicit_samples_outside_render' or '--at' not in review_args:raise
     # Repair only the sampling arguments. Do not alter words, footage,
     # selected styles or feedback, and do not render the movie again.
     retry_args=list(review_args);position=retry_args.index('--at');del retry_args[position:position+2]
     print('The review times were outside this export. Checking valid moments from the current export instead; subtitle timings are unchanged.')
     run_process(p,script(p,'frames_check.py',retry_args),cmd)
    from editor.feedback_boundary import review
    boundary=review(p,KIT/'bin/ffmpeg',request,saved_versions(p))
    if boundary.get('message'):print(boundary['message'])
    elif verified:
     boundary.update(verified_notes=verified,video_sha256=digest_file(p/'renders/final.mp4'))
     write(p/'work/feedback-boundary.json',boundary)
   elif cmd in ('frames','look'):
    run_process(p,script(p,'frames_check.py',args if args and not args[0].startswith('--') else ['renders/final.mp4',*args]),cmd)
   elif cmd=='probe':
    file=p/(args[0] if args else 'assets/aroll.mp4');data=json.loads(subprocess.check_output([str(KIT/'bin/ffprobe'),'-v','error','-show_streams','-show_format','-of','json',str(file)]));print(json.dumps(data,indent=2));return 0
   elif cmd=='silence':run_process(p,[str(KIT/'bin/ffmpeg'),'-hide_banner','-i',str(p/'assets/aroll.mp4'),'-af','silencedetect=n=-38dB:d=0.35','-f','null','-'],cmd)
   elif cmd=='music':
    if status(p).get('rescue_override',{}).get('no_music'):
     print('Finishing without the selected music.')
    else:mix_music(p)
   elif cmd=='publish':print(json.dumps(publish(p,args)));return 0
   else:raise Needed('Open your chat to continue this step.')
  from editkit import telemetry
  seconds=round(time.monotonic()-started_at,2)
  audit_event(p,'step.succeeded',request=expected[1],stage=cmd,duration=seconds)
  telemetry.event('edit_step',project=p.name,request=expected[1],step=cmd,seconds=seconds)
  if cmd=='fx-add':telemetry.event('effect_used',project=p.name,request=expected[1],step='fx-add')
  failed=status(p).get('failed_step')
  if status(p).get('rescuing') or failed==cmd or cmd=='render' and failed=='publish':
   from editkit import problem_reports
   attempt=status(p).get('rescue_attempts',{}).get(cmd,0)
   if attempt:
    problem_reports.record_outcome(expected[1],'recovered',step=cmd,attempt=attempt)
   changes={}
   if cmd in ('build','lint'):
    attempts=dict(status(p).get('rescue_attempts',{}));attempts.pop(cmd,None)
    changes['rescue_attempts']=attempts
   put(p,rescuing=False,failed_step=None,rescue_failure=None,**changes)
  corrections=dict(status(p).get('creative_corrections',{}))
  if cmd in corrections:
   corrections.pop(cmd)
   put(p,creative_corrections=corrections)
  print(LABELS.get(cmd,'Editing your video')+' — done.')
  artifacts={'ingest':['sources.json','transcript.txt','words_c1.json','work/sheets.jpg'],'assemble':['assets/aroll.mp4','segments.json'],'words':['words.json','work/onsets.json'],'layout':['layout.json','work/layout/check.jpg'],'init':['plan.json','studio-picks.json'],'build':['index.html'],'snapshot':['snapshots/contact-sheet.jpg'],'base':['renders/base.mp4'],'render':['renders/final.mp4'],'check':['work/check/final.jpg']}
  print(json.dumps({'project':str(p),'artifacts':[str(p/f) for f in artifacts.get(cmd,[]) if (p/f).exists()],'details':str(p/'work'/('last-'+cmd+'.log'))}))
  return 0
 except RenderNeeded as error:
  put(p,'working',step_label='Preparing the latest video',heartbeat=time.time(),
      command_pid=None,eta=None,rescuing=False,failed_step=None,rescue_failure=None)
  print(str(error));return 2
 except Busy as error:
  print(str(error));return 1
 except SpanNeeded as error:
  print(str(error));return 2
 except (Needed,OSError,ValueError,KeyError,subprocess.SubprocessError) as error:
  try:
   p=locals().get('p') if admitted else None
   if p and cmd in ('fx-new','fx-run','fx-add','fx-check') and not read(p/'cancel.json').get('cancel') and not (isinstance(error,Needed) and str(error) in (PLAIN['space'],PLAIN['missing'])):
    if cmd=='fx-run' and args:
     failed=status(p).get('failed_effects',{});failed[args[0]]=True;put(p,failed_effects=failed)
    key=args[0] if args else 'effect';title=key.replace('-',' ').title()
    log=p/'work'/('last-'+cmd+'.log')
    with log.open('rb') if log.is_file() else open(os.devnull,'rb') as stream:
     stream.seek(0,2);stream.seek(max(0,stream.tell()-32768));detail=stream.read().decode(errors='replace')
    from editor import rescue
    failure_class,cause,_=rescue.classify(cmd,error,str(error)+'\n'+detail)
    audit_event(p,'effect.failed',stage=cmd,outcome=cause)
    reason=str(error) if isinstance(error,EffectSkip) else (
     'the effect ran out of working space' if cause=='storage' else
     'the effect took too long to finish' if cause=='timeout' else
     'the effect did not pass its picture check' if cmd=='fx-run' and args[1:2]==['check.py'] else
     'the person cutout did not finish' if cmd=='fx-new' and 'cutout: NOT MADE' in detail else
     'the effect could not be prepared' if cmd=='fx-new' else
     'its video did not finish rendering' if cmd=='fx-add' and 'no render yet:' in detail else
     'the effect rendered but could not be added' if cmd=='fx-add' else
     'the effect could not render')
    notice='I left '+title+' out: '+reason.rstrip('.')+'.'
    if cmd=='fx-run' and args and not isinstance(error,EffectSkip):
     failures=dict(status(p).get('effect_failures') or {})
     failures[key]=failures.get(key,0)+1
     put(p,effect_failures=failures)
     if failures[key]==2:
      put(p,failed_step=cmd,rescue_failure={'step':cmd,'action':'effect-simple','args':args,'reason':'unknown'})
      print('CREATORCUT RESCUE: Ask before simplifying the selected effect. If they agree, run .venv/bin/python edit.py rescue effect-simple '+key+' --accept. Otherwise leave the effect out and finish.')
     pending=status(p).get('pending_effect_notices',{});pending[key]=notice
     put(p,'working',step_label='Adjusting '+title,pending_effect_notices=pending,heartbeat=time.time(),command_pid=None)
    else:
     notes=status(p).get('notices',[]);put(p,'working',step_label='Finishing your video',notices=list(dict.fromkeys(notes+[notice])),heartbeat=time.time(),command_pid=None)
    from editkit import telemetry
    telemetry.event('effect_skipped',project=p.name,request=status(p).get('request_id'),step=cmd)
    print('SKIP: '+notice);return 0
   if p:
    import errno
    message=str(error) if isinstance(error,Needed) and (str(error) in PLAIN.values() or (str(error).startswith('Choose Full access below') or str(error).endswith('Your saved versions are safe. Type continue in your CreatorCut chat to retry.'))) else PLAIN['space'] if isinstance(error,OSError) and error.errno==errno.ENOSPC else PLAIN['failed']
    if isinstance(error,StepNeedsInput):message=str(error)
    if isinstance(error,CreativeCheckNeeded):message='The edit plan or creative files need a correction in your CreatorCut chat.'
    stopped=read(p/'cancel.json').get('cancel')
    if not stopped and cmd in ('assemble','build','lint','snapshot','base','render','check') and _REQUEST_CONTEXT.get():
     from editor import rescue
     if rescue.creative_correction(p,cmd,error,args):
      print(str(error));return 1
    if not stopped and isinstance(error,CreativeCheckNeeded):
     audit_event(p,'step.failed',stage=cmd,outcome='creative_correction_needed')
     attempts=dict(status(p).get('rescue_attempts',{}));attempts[cmd]=2
     put(p,rescue_attempts=attempts)
    stop_message=EDIT_BUDGET_MESSAGE if read(p/'cancel.json').get('reason')=='edit_deadline' else PLAIN['stopped']
    put(p,'stopped' if stopped else 'needs_you',step_label=stop_message if stopped else message,
        question=None if stopped else message,failed_step=None if stopped else cmd,heartbeat=time.time(),command_pid=None,eta=None)
    if isinstance(error,IngestInputNeeded):
     audit_event(p,'step.failed',stage=cmd,outcome=error.symptom or error.reason,clip=error.clip,
                 exit_code=error.exit_code,tool='whisper' if error.reason=='speech_recognition' else 'ffmpeg' if error.symptom=='track_layout' else 'ffprobe' if error.exit_code is not None else None)
    elif isinstance(error,StepNeedsInput) and not error.recorded:
     audit_event(p,'step.failed',stage=cmd,outcome=error.reason,tool=error.tool)
    elif isinstance(error,CreativeCheckNeeded):
     audit_event(p,'step.failed',stage=cmd,outcome='creative_correction_needed')
    if not stopped and str(error)!=PLAIN['silent'] and cmd in (*LABELS,'reference') and _REQUEST_CONTEXT.get():
     from editor import rescue
     result=rescue.failed(p,cmd,error,args)
     if result is not None:return result
  except (OSError,Needed):pass
  import errno
  print(str(error) if isinstance(error,Needed) else PLAIN['space'] if isinstance(error,OSError) and error.errno==errno.ENOSPC else PLAIN['failed']);return 1

 except Exception as error:
  from editkit import util
  # Do not attach a traceback, its message, or tool output to incident data.
  try:
   if admitted and cmd in LABELS and not cancelled(p):
    util.log_exception('CreatorCut editing command', crash=True, project=p, stage=cmd)
    put(p,'needs_you',step_label=PLAIN['failed'],question=PLAIN['failed'],
        failed_step=cmd,command_pid=None,eta=None)
   else:
    util.log_exception('CreatorCut command')
  except (OSError, Needed, util.Fail):pass
  print(PLAIN['failed'])
  return 1

 finally:
  if runner_owned:
   try:put(runner_project,_request=runner_request,command_runner_pid=None,command_runner_birth=None)
   except (OSError,Needed):pass # A full disk cannot turn cleanup into a raw error.
  if request_token is not None:_REQUEST_CONTEXT.reset(request_token)
