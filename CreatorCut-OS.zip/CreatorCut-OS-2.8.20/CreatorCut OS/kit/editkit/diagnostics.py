"""Local bounded operational records, without prompts, tool arguments, media or credentials."""
import os,re,time,math,json
from . import util
LIMIT=500
_FIELDS={'method','item_type','state','previous','duration','outcome','stage','tool','request_id','exit_code','percent','clip','codec','pixel_format','width','height','fps','megabytes','extension','detail_code','exception_type'}

def record(project,kind,**fields):
 if not isinstance(project,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,80}',project):return
 row={'time':time.time(),'event':re.sub(r'[^A-Za-z0-9_.-]','',str(kind))[:64]}
 for key,value in fields.items():
  if key not in _FIELDS:continue
  if type(value) in (int,float) and math.isfinite(value):row[key]=value
  elif isinstance(value,str) and re.fullmatch(r'[A-Za-z0-9_./:-]{0,100}',value):row[key]=value
 file=util.ROOT/'.creatorcut-editor-control'/'diagnostics'/(project+'.jsonl')
 try:
  with util.file_guard(file.with_suffix('.guard'),timeout=.1):
   rows=[]
   if file.exists():
    with file.open('rb') as stream:
     stream.seek(0,2);size=stream.tell();stream.seek(max(0,size-262144));lines=stream.read().splitlines()
    for line in lines:
     try:
      item=json.loads(line)
      if isinstance(item,dict) and isinstance(item.get('event'),str):rows.append(item)
     except (ValueError,TypeError):pass
   rows=(rows+[row])[-LIMIT:];temporary=file.with_suffix('.partial')
   temporary.write_text(''.join(json.dumps(x,separators=(',',':'))+'\n' for x in rows));temporary.replace(file)
 except (OSError,util.Fail):pass  # Diagnostics must not interrupt a valid edit.

def bound(kind,**fields):record(os.environ.get('CREATORCUT_PROJECT'),kind,request_id=os.environ.get('CREATORCUT_REQUEST_ID',''),**fields)

_REPORT_EVENTS = {
    "requested", "claimed", "resumed", "resource.wait", "step.started", "step.succeeded",
    "step.failed", "rescue_used", "customer.input", "published", "stopped", "source.probed",
}
_REPORT_FIELDS = ("stage", "state", "outcome", "duration", "exit_code", "percent", "clip",
                  "codec", "pixel_format", "width", "height", "fps", "megabytes", "extension", "tool", "detail_code", "exception_type")


def report_timeline(project, request):
    """Read only bounded records for this request. Never include process output."""
    if not request or not re.fullmatch(r'[A-Za-z0-9_-]{1,80}', project):
        return []
    file = util.ROOT / '.creatorcut-editor-control' / 'diagnostics' / (project + '.jsonl')
    try:
        with file.open('rb') as stream:
            stream.seek(0, 2)
            stream.seek(max(0, stream.tell() - 262144))
            lines = stream.read().splitlines()
    except OSError:
        return []
    result = []
    for line in lines:
        try:
            row = json.loads(line)
        except (ValueError, UnicodeError):
            continue
        if not isinstance(row, dict) or row.get('request_id') != request or row.get('event') not in _REPORT_EVENTS:
            continue
        timestamp = row.get('time')
        if type(timestamp) not in (int, float) or not 0 < timestamp < 4102444800:
            continue
        item = {'time': timestamp, 'event': row['event']}
        for key in _REPORT_FIELDS:
            value = row.get(key)
            if type(value) in (int, float) and math.isfinite(value) and abs(value) <= 1000000:
                item[key] = value
            elif key == 'exception_type' and value in ('NameError','TypeError','ValueError','KeyError','IndexError','AttributeError','FileNotFoundError','ModuleNotFoundError','RuntimeError','TimeoutError','PermissionError','JSONDecodeError'):
                item[key] = value
            elif key in ('stage', 'state', 'outcome', 'codec', 'pixel_format', 'extension', 'tool', 'detail_code', 'exception_type') and isinstance(value, str) and re.fullmatch(r'[a-z0-9_-]{1,60}', value):
                item[key] = value
        result.append(item)
    return result[-40:]


_FAILURE_PATTERNS = (
    ("connection_refused", r"net::ERR_CONNECTION_REFUSED|ECONNREFUSED"),
    ("connection_reset", r"net::ERR_CONNECTION_RESET|ECONNRESET"),
    ("navigation_timeout", r"navigation timeout|page\.goto.*(?:timed? out|failed)|TimeoutError:.*Navigation"),
    ("missing_asset", r"CREATORCUT_MISSING_ASSET|Failed to load resource.*404"),
    ("invalid_review_time", r"CREATORCUT_REVIEW_TIMING"),
    ("renderer_arguments", r"unknown option|unknown argument|unrecognized arguments|unexpected argument"),
    ("render_composition", r"No compositions found|Missing (?:root )?composition|(?:Error:|error).*composition.*(?:not found|missing|invalid)"),
    ("media_decode", r"Error while decoding|Invalid data found when processing input|Could not find codec parameters"),
    ("browser_closed", r"Target closed|TargetCloseError|Session closed|browser process exited"),
    ("host_denied", r"Permission denied|Operation not permitted|thermal_state_observer_mac"),
    ("storage_full", r"No space left on device|Disk quota exceeded"),
    ("missing_file", r"No such file or directory|FileNotFoundError"),
    ("missing_module", r"ModuleNotFoundError|Cannot find module"),
    ("port_in_use", r"Address already in use|EADDRINUSE"),
    ("invalid_code", r"SyntaxError|ReferenceError"),
    ("invalid_data", r"JSONDecodeError|CREATORCUT_INVALID_CUT"),
    ("encoder_failed", r"Error initializing output stream|Error while opening encoder|Conversion failed"),
)

def failure_facts(output):
    """Only recognized error codes and exception classes leave the local log."""
    text = str(output)[-65536:]
    facts = {}
    for code, pattern in _FAILURE_PATTERNS:
        if re.search(pattern, text, re.I):
            facts["detail_code"] = code
            break
    names = re.findall(r"(?m)^(NameError|TypeError|ValueError|KeyError|IndexError|AttributeError|FileNotFoundError|ModuleNotFoundError|RuntimeError|TimeoutError|PermissionError|JSONDecodeError|SyntaxError|ReferenceError):", text)
    if names:
        facts["exception_type"] = names[-1]
    return facts
