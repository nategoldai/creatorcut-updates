# CreatorCut OS 2.5.0 verification

Make and timeline Update were exercised through actual in-app Studio controls using an isolated four-second clip of the creator's own footage. Make published a reviewed yellow LIVE composition; a note at frame 61 of version 1 requested white DONE with unchanged placement, timing and source voice. Update reused the same persistent Codex project session and published version 2. The note became ready only after that publication. Candidate and saved-version hashes matched.

Studio was restarted during the revision. Its persisted request, job identity, start time, provider session and version-bound note survived. The archived-session failure found during this test was fixed using the documented thread/unarchive operation before resume. No native foreground action receiver was used. Real renderer permission requests were shown and answered in Studio; no sandbox or approval policy was disabled.

The regression suite passes 376 tests, covering exact request/reference preservation, pinned effects, preset/memory scopes, publication gates, provider pipe EOF/timeouts, bounded connection recovery, duplicate dispatch, cancelled jobs, corrupt records, PID reuse, session restoration, resource gates and update preservation. Numerical and structural checks are not a visual quality guarantee. Real render review used full-resolution frame sequences and audio signals, without a perceptual listening claim.

The managed engine uses each creator's signed-in Codex account and its limits. It can display in a supported embedded Codex or Claude preview, but it is not a mirror of the host conversation and does not use Claude subscription credentials. The Claude host lifecycle and Windows installation were not independently exercised in this run. No claim is made that hardware, disk, provider, permission or network failures are impossible; concrete failures preserve work, show their actual state and use bounded safe recovery.

The distributable excludes customer videos, account state, jobs, presets, learned memory and installed runtimes. The update destination remains the configured public repository; this ZIP has not been published there automatically.


## 2.5.1 public-use failure audit — 2026-10-21
397 Python regression cases passed in the bundled Python runtime. Scenarios include repeated clicks, independent jobs, queued cancellation, malformed project isolation, protected active requests/media/references, missing/torn job records, concurrent preference writes and backup recovery. Existing process tests exercise heavy-resource waiting and owner death. These tests are scoped evidence, not a guarantee against every hardware, account, network or renderer failure.

A real four-second managed Make used an attached measured yellow-title reference, a previously reviewed white-title preset and explicit creator voice/no-music memory. It rendered and published yellow CHECK at the requested placement and window, overriding the preset. Full-resolution sampled frames and exact title boundary frames were inspected. Source/candidate audio correlation was 0.999694; no perceptual listening was performed. The reference fixture was hand-measured from an existing real render; this does not benchmark automatic Instagram extraction. Earlier actual Make and frame-feedback Update tests remain recorded above. Independent Claude lifecycle and Windows installation remain unverified.


## 2.5.2 measured render progress and library actions
402 Python checks passed with the bundled runtime. Added regressions for unsuppressed renderer telemetry, stale percentage reset, supported explicit session permission and saving presets without mutating active settings. The actual 33-second customer composition reported measured capture progress after removing --quiet and produced a new normalized candidate, then passed the review gate and published v1 (33.233 seconds, 1080×1920, 30 fps). Existing baked-in captions and graphics were retained; reference fonts are a visual approximation. Review used full-resolution frames and signal analysis, without perceptual playback/listening. Timeline animation is an illustrative editing visualization, not an exact live edit decision list; it adds no completion credit. Its five stage variants, waiting state, many-small-frame fallback and preserved measured percentages were checked with a JavaScript rendering harness. My videos' four controls and draft-preset naming dialog were verified in the embedded browser. Download waits for an available video; deletion waits until active editing stops.

Permission prompts are not silently approved or hidden. Session-scoped approval is an explicit customer action and appears only when supported by that request. No universal zero-failure or automatic artistic-quality guarantee is made.


## 2.5.3 feedback and responsive checks
The executable feedback_ui.cjs regression exercises exact note version/time, input clearing, newest-first order, pause-before-send, per-project sending state and single dispatch under repeated clicks. timeline_ui.cjs verifies the five editing visualizations, measured progress, waiting state, many-small-thumbnail fallback and absence of the old movie player while editing. Both pass. The unchanged Python engine retains its 402 passing checks from 2.5.2.

Embedded-browser viewport tests found no horizontal page overflow: feedback at 320px and 375px; library and active Studio at 375px; Home at 375px and 430px; Studio at 768px; library at 1024px. Feedback was tested as an isolated, clearly labelled rendered UI fixture to avoid changing the customer's notes; other screens used the actual local Studio in same-origin test iframes. Native phone-app embedding, remote connections and mobile-host permissions have not been independently tested. A localhost installation is not automatically available on another device.


## 2.5.4 startup and frame badge
405 Python checks passed. The response schema for installed App Server supports acceptForSession without an availableDecisions field; the old feature detector incorrectly required that nonexistent field. Explicit session responses are tested in the actual RPC shape, and missing consent still declines rather than auto-grants. Standard command approvals are eligible; stdin and broader permission requests are not given that session shortcut. The currently running provider is not interrupted to reload source.
The feedback UI regression now calls its binding with null initial state, which previously produced a startup error. Frame label is a dedicated purple span directly after the blue time. Security approvals are not removed or hidden.


## 2.5.5 reliability sweep
408 Python checks passed. New regressions reproduce the old loaded-version and long-render-output gaps before their fixes. The worker-version case uses a real child supervisor and modifies VERSION while it runs; its next heartbeat keeps the originally loaded version. A stale owned supervisor is terminated for recovery even with an update plus queued job. A 300-event tool-output burst counts as real liveness while persisting once, without reporting a numeric percent.
The real four-note revision of video-1020-2215 completed and published version 2. Live UI verified the 33.233-second movie playing, pausing, seeking, matching frame 362 at 12.067 seconds, and all 12 actual timeline thumbnails loaded. Its release review explicitly used frame inspection and audio signal analysis; it did not claim perceptual listening. These checks are not a guarantee against all host, network, account, permission, disk or renderer failures.

Startup UI also renders immediately before the first network response. A delayed-state regression checks that this remains visible and repeated connect does not create duplicate listeners.


## 2.5.6 reference recovery
415 Python checks passed. Controlled downloader tests cover short-link preflight failure, unusable MP4 responses, an expired Instagram CDN URL followed by another public page, all methods failing, and a cover-only result. UI checks verify that errors, cover-only results even with readout rows, and study errors display the upload instruction with the exact project id. These tests do not claim that external Instagram/TikTok services accept every URL. The chain uses the existing free providers; no paid service or new external destination was added.

Partial reference retry clears stale cover/study failure flags and runs once; an already-complete full scan is left intact.


## 2.5.7 navigation and download
417 Python checks passed. The actual Studio/Editor routing functions were exercised for draft reuse, active and finished output, old deep links, empty/missing projects and accepted Make switching routes without duplicate dispatch. Attachment serving preserves bytes and range requests and sanitizes Unicode/header-control filenames. Percentages refer only to the measured current tool step; planning has no invented completion percentage. The API, persistent project id, request integrity, feedback, preset and memory endpoints are unchanged.


## 2.5.8 comprehensive audit
418 Python tests pass. Seven Node UI suites verify action/API wiring, separate Studio/Editor routes and draft reuse, exact-version feedback, download URLs, timeline state, initial loading and reference recovery. The action suite checks 57 declared bindings and 42 API methods; wiring coverage is not manual end-to-end coverage of every button. Additional races replace project state during an accepted request and fail the next refresh; queued state and one dispatch survive. Draft-creation failure stops automatic repeat submissions and offers an explicit retry. Permission expiry remains a real pause and is no longer described as a user decline.

A real click on My videos Download in the Codex embedded browser saved Feedback preview.mp4 (2,190,034 bytes). Its SHA-256 equals the source saved version: 0f94e5fa2bab524fdd0b738f5d817e6a28a0b87d685710a2da0d4f16ab372d50. Header tests verify attachment names, unchanged bytes and normal seek/range playback. The latest saved version is preferred to a stale preview URL.

An isolated three-second synthetic render passed contract validation, graphics checks, full capture/decode, changing visible frames, timed audio event and bounded mixed-audio checks. It was not a customer edit or artistic-quality evaluation. The guide was rendered and all six pages inspected. Account, security approval, disk, hardware and network requirements remain real. The current customer test 5 stopped after an unanswered renderer-permission request expired; it was not claimed as a completed render. Independent Claude/mobile-host/Windows lifecycle and all-user launch readiness remain unverified. No release-feed publication was performed by this audit.


## 2.6.1 renderer permission correction
432 tests pass, including explicit permission scope=session, scope=turn, decline, timeout, renderer cache ownership and a sandbox-preserving preflight command. A real command/exec probe ran under workspaceWrite with networkAccess=false: cache write passed, loopback bind was blocked. The probe intentionally does not grant access or certify a full render. Required customer consent is retained, and session-scoped authorization is not promised across different project sessions or host restrictions. The current customer edit has not been marked complete by this change.


## 2.7.0 quality-preserving reuse
464 Python tests and eight UI suites passed. New regressions cover same-size/same-timestamp source replacement, changed settings/model weights, corrupt/empty outputs, malformed manifests, path traversal, unavailable cache storage, interrupted capture, source/font/runtime changes, separate draft/final renders, exact note/version context and the single percentage display. A sound-only revision calls capture once across two passes while remix and technical check run twice. Changes to caption text trigger a new capture. Publication/review gates were not weakened.

A real isolated 1.2-second synthetic test joined two clips, reused the prepared movie and rebuilt composition assets twice. Prepared/movie assets remained byte-identical and originals unchanged. Observed microtest timings were about 0.204s versus 0.0007s for preparation and 0.066s versus 0.0022s for composition asset setup. These tiny-fixture timings are not a claimed speedup for customer edits.

An isolated three-second H.264/AAC graphics/audio render passed normal contract/check/capture/decode, moving-video, timed-sound, mix-level and review-evidence checks. A subsequent actual audio-only revision retained the exact raw visual SHA and modification time, changed the candidate audio/output hash, reran technical checks and registered a new candidate with new review evidence. Neither synthetic result was published or evaluated for artistic quality. Required host permissions remain real; this optimization does not remove them. Per-scene rendered-video stitching is intentionally deferred because transition and audio boundaries need separate validation.
