# Single-file publisher updates

Once the publisher repository is configured, replace **CreatorCut-OS.zip** in the public repository’s root using GitHub’s Upload files button. Commit the change. Use the ZIP supplied for that new release; its embedded version must be newer. No separate JSON, GitHub Actions, credentials or release tags are needed.

Apps check on startup and periodically while open. A verified newer ZIP enables **Install update** on Home and Studio. Users click it to install; uploading does not silently overwrite their running app. Active edits are protected. Projects, presets, creator memory, original footage and installed tools survive installation; failures roll back app files.

The publisher channel is stored in kit/update.json as github_repository (owner/repository). The default filename is CreatorCut-OS.zip. It must be a public repository. GitHub’s browser uploader limits files to 25 MiB; the source package is kept below that limit. Runtime tools and customer files are not included. Private code in a public package is publicly downloadable.

The updater reads the repository’s default branch through the Contents API, verifies the exact downloaded Git blob, verifies every packaged file against its SHA-256 manifest, reads the actual embedded version, and caches the verified ZIP. Unchanged files are not downloaded again. Rate limits, offline checks, invalid archives and interrupted downloads produce an honest check error, never a false “latest installed.” Existing manifest-based website feeds remain supported.

Publisher repository: https://github.com/nategoldai/creatorcut-updates

Upload a newer **CreatorCut-OS.zip** to the root of that repository and commit the replacement. Keep the filename exactly the same. The app checks the default branch, reads the ZIP’s embedded version, and offers Install update on Home and Studio. The private nategoldai/nategold website repository is separate and remains private.
