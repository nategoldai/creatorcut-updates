---
name: studio
description: Open CreatorCut Studio in this conversation.
---
Open Studio using `.venv/bin/python edit.py studio open --no-browser` in this installation. Use the host embedded preview with its actual URL. Keep its title CREATORCUT. This visible chat is the only editor. Read AGENTS.md or CLAUDE.md. In Claude, run next and arm wait in the background. In Codex, go/start/continue/update runs next. Follow kit/editor/RECIPE.md for an edit. Studio never sends a clipboard message.
