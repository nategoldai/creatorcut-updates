---
name: cut
description: "Change what's kept in a video: remove a sentence, keep a different take, make it shorter, faster or slower, keep or remove pauses, restore something that was cut. Use when the creator says cut, remove, shorter, tighter, faster, slower, keep that part, or it's too long."
---

# CreatorCut cut

Read AGENTS.md or CLAUDE.md. This visible chat is the editor. For a saved edit, run `.venv/bin/python edit.py next` and follow `kit/editor/RECIPE.md`. Use one edit.py command per call, and Read/Write/Edit for creative files. No alternative control or publication workflow.

Choose clean takes in edl.json. For a revision, edit that decision list, then assemble, words and layout again before rebuilding. Keep natural word endings and use the actual kept-frame timeline.

Speak in one friendly sentence per meaningful step. Keep diagnostics private. Respect host permissions and every denial. Never claim a video is ready before publish succeeds.
