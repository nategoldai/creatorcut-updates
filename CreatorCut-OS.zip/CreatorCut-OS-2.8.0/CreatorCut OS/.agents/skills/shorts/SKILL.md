---
name: shorts
description: "Turn a long video (podcast, YouTube video, livestream, talk) into several short vertical clips: finds the 3-5 strongest standalone moments with a hook and payoff, then edits each one fully. Use when the creator says shorts, clips, repurpose, cut this into TikToks, or drops a long video."
---

# CreatorCut shorts

Read AGENTS.md or CLAUDE.md. This visible chat is the editor. For a saved edit, run `.venv/bin/python edit.py next` and follow `kit/editor/RECIPE.md`. Use one edit.py command per call, and Read/Write/Edit for creative files. No alternative control or publication workflow.

Read the full transcript and identify self-contained moments with a clear opening and payoff. Ask which to use if the customer has not chosen. Use saved Studio requests and the same editing recipe for each selected video.

Speak in one friendly sentence per meaningful step. Keep diagnostics private. Respect host permissions and every denial. Never claim a video is ready before publish succeeds.
