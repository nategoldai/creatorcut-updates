---
name: teach
description: "Turn a reference video into a preset that copies its editing exactly (fonts, sizes, colours, motion, graphic language, pacing, colour grade). The Studio studies every reference automatically; you check the result and write the edit spec. Use when the Studio sends teach.ready, or the creator says copy this look, make it look like this creator, save this style."
---

# CreatorCut teach

Read AGENTS.md or CLAUDE.md. This visible chat is the editor. For a saved edit, run `.venv/bin/python edit.py next` and follow `kit/editor/RECIPE.md`. Use one edit.py command per call, and Read/Write/Edit for creative files. No alternative control or publication workflow.

The creator adds reference files or links in Studio. Read the finished local analysis and annotated frames, then capture concrete typography, motion, pacing and framing observations. Use that design in the recipe and Save as preset. Lasting confirmed preferences go in my-brand/editing-memory.md; one-video notes stay local.

Speak in one friendly sentence per meaningful step. Keep diagnostics private. Respect host permissions and every denial. Never claim a video is ready before publish succeeds.
