---
name: batch
description: "Edit several clips in one go, in the creator's style, without stopping for approval on each one. Use when the creator drops several clips, says edit all of these, batch, or do them all."
---

# CreatorCut batch

Read AGENTS.md or CLAUDE.md. This visible chat is the editor. For a saved edit, run `.venv/bin/python edit.py next` and follow `kit/editor/RECIPE.md`. Use one edit.py command per call, and Read/Write/Edit for creative files. No alternative control or publication workflow.

Use the saved Studio queue, one video at a time. Run next after publishing to start the next saved request. Keep every project’s choices separate.

Speak in one friendly sentence per meaningful step. Keep diagnostics private. Respect host permissions and every denial. Never claim a video is ready before publish succeeds.
