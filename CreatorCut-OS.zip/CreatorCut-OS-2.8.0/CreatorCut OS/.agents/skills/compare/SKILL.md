---
name: compare
description: "Make a before/after video showing the raw footage next to the AI-edited version, side by side, ready to post as content about the edit itself. Use when the creator says before and after, comparison, side by side, show the difference, or wants content showing how CreatorCut OS works."
---

# CreatorCut compare

Read AGENTS.md or CLAUDE.md. This visible chat is the editor. For a saved edit, run `.venv/bin/python edit.py next` and follow `kit/editor/RECIPE.md`. Use one edit.py command per call, and Read/Write/Edit for creative files. No alternative control or publication workflow.

Compare the actual source and finished video using frames and the saved version files. Describe visible differences honestly. Do not claim to have generated a comparison movie unless you actually rendered and inspected it.

Speak in one friendly sentence per meaningful step. Keep diagnostics private. Respect host permissions and every denial. Never claim a video is ready before publish succeeds.
