---
name: captions
description: "Change the captions on a video: size, position, colour, words per line, uppercase, animation (highlight, reveal, pop), boxed subtitles, highlighted keywords, or fix a misspelled or misheard word. Use when the creator mentions captions, subtitles, text on screen size or spelling."
---

# CreatorCut captions

Read AGENTS.md or CLAUDE.md. This visible chat is the editor. For a saved edit, run `.venv/bin/python edit.py next` and follow `kit/editor/RECIPE.md`. Use one edit.py command per call, and Read/Write/Edit for creative files. No alternative control or publication workflow.

Respect Caption Off. Edit words.json and the caption settings in plan.json, preserving actual speech timings. Rebuild, inspect snapshots and render using the recipe. Keep text away from the face and app controls.

Speak in one friendly sentence per meaningful step. Keep diagnostics private. Respect host permissions and every denial. Never claim a video is ready before publish succeeds.
