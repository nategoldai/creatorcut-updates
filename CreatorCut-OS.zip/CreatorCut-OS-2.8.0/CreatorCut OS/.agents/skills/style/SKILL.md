---
name: style
description: "Switch a video to one of the creator's saved presets, or set their default preset. Presets are made only from their own reference videos (Preset Lab); there are no built-in templates to offer. Use when the creator says style, look, preset, make it look like, or wants a video to match another one."
---

# CreatorCut style

Read AGENTS.md or CLAUDE.md. This visible chat is the editor. For a saved edit, run `.venv/bin/python edit.py next` and follow `kit/editor/RECIPE.md`. Use one edit.py command per call, and Read/Write/Edit for creative files. No alternative control or publication workflow.

Read the saved preset design returned in preset-inputs.json and the current Studio choices. Current explicit choices come first. Apply its actual typography, motion and design language through plan.json. Save as preset in Studio keeps the current design for later.

Speak in one friendly sentence per meaningful step. Keep diagnostics private. Respect host permissions and every denial. Never claim a video is ready before publish succeeds.
