---
name: look
description: "Change the colour grade, music, sound effects and zoom energy of a video. Use when the creator says colour, warmer, cinematic, brighter, black and white, add music, change the music, quieter music, sound effects, zooms, more energy, or calmer."
---

# CreatorCut look

Read AGENTS.md or CLAUDE.md. This visible chat is the editor. For a saved edit, run `.venv/bin/python edit.py next` and follow `kit/editor/RECIPE.md`. Use one edit.py command per call, and Read/Write/Edit for creative files. No alternative control or publication workflow.

Use the selected overall style, caption choice and colour from the saved request. Build colour last on footage layers. Use the original effect implementations through fx-new, fx-run and fx-add. Inspect snapshots and actual output.

Speak in one friendly sentence per meaningful step. Keep diagnostics private. Respect host permissions and every denial. Never claim a video is ready before publish succeeds.
