# CreatorCut setup
Open this installation as the project. Explain the one-time Trust click, finish the private tools and decoder check, and then open Studio. Read CLAUDE.md: next reads saved work, and wait runs in the background so Make wakes this visible chat. Keep setup replies short and friendly. Respect host security decisions; do not change global settings or launch another model.
