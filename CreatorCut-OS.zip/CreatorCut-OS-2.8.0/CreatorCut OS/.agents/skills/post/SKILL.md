---
name: post
description: "Create a ready-to-post kit for a finished video: platform-specific caption, hashtags, title options, a pinned comment, the best cover frame with hook text as an image, and posting tips. Use when the creator says post, caption, hashtags, description, title, thumbnail, cover, or what should I write."
---

# CreatorCut post

Read AGENTS.md or CLAUDE.md. This visible chat is the editor. For a saved edit, run `.venv/bin/python edit.py next` and follow `kit/editor/RECIPE.md`. Use one edit.py command per call, and Read/Write/Edit for creative files. No alternative control or publication workflow.

Write concise social post copy based on the creator’s actual video and voice. Do not change an edit, save a preference or publish anywhere unless asked.

Speak in one friendly sentence per meaningful step. Keep diagnostics private. Respect host permissions and every denial. Never claim a video is ready before publish succeeds.
