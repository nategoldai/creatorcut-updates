---
name: creatorcut
description: "Open or resume CreatorCut Studio inside this AI host. Use for /creatorcut, open CreatorCut, or resume editing in CreatorCut."
---

# Open CreatorCut

Use this installed app folder and read AGENTS.md plus kit/skills-src/studio/SKILL.md. Open Studio in the host's embedded preview beside this conversation. Use its native creatorcut_studio tool if configured for this installation; otherwise start the local Studio with private Python and use the host's embedded preview tool with its actual URL. Keep the title CREATORCUT. Never launch an external browser or a second editor/model.

For an invocation outside the app project, read ~/.creatorcut/installations.json to locate the active existing installation. The setup installs this launcher into the user's skill directory so future chats can discover it. Host slash/skill discovery may require reopening the chat. Do not claim an unknown host supports custom slash commands or embedded previews without checking its available tools.


## Continue without Studio
Run `.venv/bin/python edit.py next` in this installation. It resumes the saved active edit before starting the next queued video. Follow kit/editor/RECIPE.md and reuse the completed steps. In Claude, arm `.venv/bin/python edit.py wait` in the background when the queue is empty. Do not launch another model or editor.
