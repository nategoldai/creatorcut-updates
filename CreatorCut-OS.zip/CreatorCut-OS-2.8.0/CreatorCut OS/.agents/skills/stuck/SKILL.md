---
name: stuck
description: "Help when anything goes wrong or the creator has a question about CreatorCut OS: install problems, error messages, how to do something, where files are, what a command does, usage limits. Use when the creator says help, stuck, how do I, what is, doesn't work, or seems confused."
---

# CreatorCut stuck

Read AGENTS.md or CLAUDE.md. This visible chat is the editor. For a saved edit, run `.venv/bin/python edit.py next` and follow `kit/editor/RECIPE.md`. Use one edit.py command per call, and Read/Write/Edit for creative files. No alternative control or publication workflow.

Run next to recover the saved request and completed steps. If a command is still running in the other chat, leave it alone. Use doctor for setup diagnostics. Keep details private and give one plain next step. Never rotate messages, leases or tokens or start a hidden editor.

Speak in one friendly sentence per meaningful step. Keep diagnostics private. Respect host permissions and every denial. Never claim a video is ready before publish succeeds.
