---
name: retention
description: "Find and fix the moments where viewers might scroll away: slow starts, dead spots where nothing changes on screen, long pauses, low pace and length problems. Use when the creator says retention, boring, slow, people drop off, more engaging, or before posting an important video."
---

# CreatorCut retention

Read AGENTS.md or CLAUDE.md. This visible chat is the editor. For a saved edit, run `.venv/bin/python edit.py next` and follow `kit/editor/RECIPE.md`. Use one edit.py command per call, and Read/Write/Edit for creative files. No alternative control or publication workflow.

Review the actual cut and snapshots for a weak opening, repeated lines or long empty moments. Explain the useful changes plainly. Apply requested changes through the recipe without invented scores or automatic extra effects.

Speak in one friendly sentence per meaningful step. Keep diagnostics private. Respect host permissions and every denial. Never claim a video is ready before publish succeeds.
