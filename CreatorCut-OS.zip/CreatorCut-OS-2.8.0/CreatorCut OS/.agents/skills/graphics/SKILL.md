---
name: graphics
description: "Add, remove or change motion graphics on a video: hook titles, lists that build, counters, charts, screenshots and proof images, before/after comparisons, quotes, stickers, name tags and call-to-action buttons. Use when the creator mentions graphics, animations, text on screen, show my screenshot, add a list/number/chart, or wants more or fewer graphics."
---

# CreatorCut graphics

Read AGENTS.md or CLAUDE.md. This visible chat is the editor. For a saved edit, run `.venv/bin/python edit.py next` and follow `kit/editor/RECIPE.md`. Use one edit.py command per call, and Read/Write/Edit for creative files. No alternative control or publication workflow.

Design any original timed HTML, CSS and animation layers in plan.json. Use the local creator material returned in the request. Match their reference and chosen style; preserve original claims and use real supporting images. Follow build, lint, snapshot and render in the recipe.

Speak in one friendly sentence per meaningful step. Keep diagnostics private. Respect host permissions and every denial. Never claim a video is ready before publish succeeds.
