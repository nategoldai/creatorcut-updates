---
name: fix
description: "Fix anything that looks or sounds wrong in a video or in the setup, described in plain words: text cut off, captions covering the face, wrong colours, bad crop, out of sync, a graphic at the wrong time, an error message, something not working. Use when the creator says fix, it's broken, looks wrong, doesn't work, error, or describes a problem."
---

# CreatorCut fix

Read AGENTS.md or CLAUDE.md. This visible chat is the editor. For a saved edit, run `.venv/bin/python edit.py next` and follow `kit/editor/RECIPE.md`. Use one edit.py command per call, and Read/Write/Edit for creative files. No alternative control or publication workflow.

Read the request and the last step’s returned details using Read. Fix the specific creative input, then continue from that step. Use ask for a real customer answer or permission; never restart another editor. Preserve previous versions.

Speak in one friendly sentence per meaningful step. Keep diagnostics private. Respect host permissions and every denial. Never claim a video is ready before publish succeeds.
