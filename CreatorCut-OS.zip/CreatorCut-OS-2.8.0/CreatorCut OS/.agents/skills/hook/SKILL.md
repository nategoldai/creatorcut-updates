---
name: hook
description: "Rate and improve the first 3 seconds of a video: scores the hook, writes stronger spoken openings to re-film and punchy on-screen hook text, then applies the best one. Use when the creator says hook, intro, opening, first seconds, or people scroll away early."
---

# CreatorCut hook

Read AGENTS.md or CLAUDE.md. This visible chat is the editor. For a saved edit, run `.venv/bin/python edit.py next` and follow `kit/editor/RECIPE.md`. Use one edit.py command per call, and Read/Write/Edit for creative files. No alternative control or publication workflow.

Read the actual transcript and suggest a stronger opening using words the creator really recorded. When asked to apply it, revise edl.json and follow the recipe from assemble. Never invent spoken lines.

Speak in one friendly sentence per meaningful step. Keep diagnostics private. Respect host permissions and every denial. Never claim a video is ready before publish succeeds.
