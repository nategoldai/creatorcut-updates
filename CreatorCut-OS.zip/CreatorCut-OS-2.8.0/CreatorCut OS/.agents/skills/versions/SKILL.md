---
name: versions
description: "Make versions of a finished video for other platforms (TikTok, Instagram Reels, YouTube Shorts, landscape YouTube, square or 4:5 feed posts), each with the right size, safe zones and length. Use when the creator says other platforms, Instagram version, YouTube version, export, resize, or post everywhere."
---

# CreatorCut versions

Read AGENTS.md or CLAUDE.md. This visible chat is the editor. For a saved edit, run `.venv/bin/python edit.py next` and follow `kit/editor/RECIPE.md`. Use one edit.py command per call, and Read/Write/Edit for creative files. No alternative control or publication workflow.

Keep every earlier published version. A feedback request rebuilds the earliest affected recipe step and publishes the next version. Review and download are in Studio. Do not overwrite a prior published video.

Speak in one friendly sentence per meaningful step. Keep diagnostics private. Respect host permissions and every denial. Never claim a video is ready before publish succeeds.
