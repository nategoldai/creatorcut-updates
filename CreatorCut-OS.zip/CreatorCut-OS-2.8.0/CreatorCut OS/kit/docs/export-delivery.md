# Final export encoding

Default final delivery is CapCut-style: H.264 High, constant 30 fps, 8-bit yuv420p, approximately 12 Mbps, one-second closed GOP, one B-frame, AAC stereo at 44.1 kHz / 160 kbps and SDR Rec.709. Preserve the planned dimensions and aspect ratio; do not force landscape videos into a vertical crop. Larger canvases use an appropriate H.264 level. HDR is properly tone-mapped, never simply relabelled SDR.

The normalization runs before candidate registration and review. Evidence, audio checks, review hashes, published previews and new version files therefore refer to the normalized candidate. Final export also handles historical reviewed content through the same encoding gate and records both reviewed-source and delivery hashes in render/final-export.json. This legacy technical transcode is not a new creative edit or a claim that identical encoded bytes were reviewed.

Encoding preserves duration, speech, music, composition and playback speed. It does not add slow motion, optical flow, music or a new colour look. It preserves ordinary metadata instead of spoofing CapCut attribution or stripping AI provenance. This is a compatibility profile, not evidence of an AI block or a guarantee about Instagram reach.

Exports are atomic, locked per project and cached against source/output SHA-256 and profile version. Full decoding, duration, audio presence, dimensions and frame-rate checks run before a new delivery is accepted. Failed attempts keep the previous good output. Cached, byte-identical reviewed files are not repeatedly re-encoded.

## ccMixter music credits
Library tracks retain their track-specific Creative Commons BY licence and exact credit. Include the shown credit and source/licence link in the post description. Studio offers Copy credit on the selected track and finished video; each published version keeps a matching vN.credits.txt post-details file. Uploaded music must be supplied with permission. Auto requires a real licensed track with audio.music.src, rights and reason. When offline, choose suitable already-downloaded licensed audio or report the missing input; never silently remove music. No ownership or Content ID promise is made.

The owner must review ccMixter automated-use terms before launch. Downloads currently send the track page as Referer, as required by the service; technical access is not legal approval.

Studio publication keeps every reviewed movie in that video project’s version history (kit/projects/PROJECT/versions), visible in My videos. Download the version from Studio. The optional my-videos/finished folder is used only by explicit final exports and is not where every Studio publish is copied. Never delete project versions to tidy that folder.
