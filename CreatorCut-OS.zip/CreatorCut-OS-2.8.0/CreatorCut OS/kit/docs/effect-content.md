# Effect content — use the customer’s facts

Never invent names, numbers, view counts, comments, achievements or results. Exact transcript words may supply labels/steps. Files and personal results must come from the customer. Optional material is not mandatory.

| Effect | Exact requirement |
|---|---|
| Orbit | a folder of the buyer's own reel cover images (at least 4, 6 fills the default ring). Real view counts only if the buyer gives them |
| Couch Wall | a folder of the buyer's own reel cover images (at least 4, 9 or more looks best). Real view counts only if the buyer gives them |
| UI World | what the screen shows: the buyer's words for the packaged chat screen, or the buyer's own picture or screen recording. Any names on it are generic placeholders |
| Freeze Sticker | the notes |
| The Stack | the buyer's own figures: titles, labels, values and units for one to three small cards |
| Odometer | the real number, from the buyer |
| Comment Bubble | the comment keyword (the cta mark in words.json). The commenter is a generic placeholder, never a real person |
| Freeze and Label | the labels |
| Phone Mockup | the buyer's own screen recording or picture for the phone, or the words for the packaged card |
| Checklist | 2 to 4 steps, in the speaker's own words |
| Headline Wall | the topic. Card text is written for the reel: generic outlets and placeholder names, never a real publication, person, number or made-up proof |
| Before and After | nothing needed. Optional: the buyer's own finished version of the same frames |
| Chart Grow | nothing needed. Optional: the buyer's own real figures and labels for the chart |
| Pointer Callout | the card texts |
| Pull-Back Reveal | the reel's own edit list (steps really done, each shot's length in frames) and, for the counter, a number the speaker says |
| Knockout Tiles | the names the speaker lists; for receipts, the amounts they say |
| Green Screen | the buyer's own video or picture of the thing they are talking about (at least one file in bg/) |
| Inside Out | one b-roll clip or picture from the buyer |
