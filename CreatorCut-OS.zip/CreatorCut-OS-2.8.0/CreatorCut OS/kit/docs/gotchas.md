# When an edit misbehaves

- Keep the exact saved request, project and delivery token. Claim once; a second paste must not start a second writer.
- Make and Update use transport paste. A decorative animation is not evidence of editing.
- No hidden editor or idle chat listener is a fallback. Keep the visible chat open.
- Scene music/voice/colour decisions start from the immutable request, not hard-coded defaults.
- None removes music only; continuous narration still needs audible low background music when requested.
- A zero gain must remain zero. Voice cleanup is off by default unless explicitly selected.
- Original means no creative grade; required output/HDR conversion is distinct.
- Retain old code versions. Do not silently retarget saved picks when fingerprints change.
- Initialize window.__timelines first, then register directly on window.__timelines["main"]. The redundant logical receiver falsely fails lint.
- Use only the installed private renderer. Never npx-download another engine while editing.
- Use style-library.py recipe, not a remembered generic list of commands. Several packs build before baking.
- Use actual word onsets and the effect's boundary rules. Frame Break needs F_IN>=23, F_OUT>=F_IN+45 and two plain tail frames.
- Continuous-shot effects cannot cross real cuts. List spans and loosen the cut or choose another moment.
- Effects require 1080x1920. Explain explicit reframing instead of changing output silently.
- Check measured shot size and background motion before long renders; unknown is not a verified mismatch.
- A clean cutout is different from a quick measuring mask. Show frame progress; the RVM model downloads once at setup.
- Missing personal material requires a plain question. Never retain demonstration names, comments, numbers or results.
- Exact transcript text may provide steps and labels. Timing, counts of real items and geometry are not fabricated customer achievements.
- The video's chosen caption style wins over an effect's subtitle default; graphics labels still need appropriate typography.
- An unsuitable effect may be omitted only for an engine-rechecked constraint and a customer-visible reason. Do not waive a fitting effect with generic prose.
- Use one precedence: this video explicit request, saved style, Studio defaults/picks, effect defaults.
- A completed no-speech transcript permits a visual/music-only plan; an incomplete/failed transcript does not.
- Watcher liveness is not a made-up percentage. Do not show stale-chat warnings while real work moves.
- Unknown CPU is not idle zero. A slow startup gets one safe retry only after the previous guardian exits.
- Stop only owned or identity-verified processes. Detached Chrome needs a per-invocation receipt; never kill Chrome by name.
- A lost watcher pipe is a normal stop, not a traceback. If cleanup is unconfirmed, do not launch a second writer.
- Review and publish the matching newer version before marking feedback ready. Never mark a raw/old movie as finished.
- Studio versions are kept in each project's version history; finished/ is only for explicit exports.
- Preserve previous outputs, originals, presets and memory on failures and updates. Legacy worker retirement precedes new queue reservations.
- Real host trust/permission/usage-limit waits must be explained honestly, never approved or hidden automatically.
- Failed downloads leave the prior choice intact. Retry a saved step; do not silently choose another track, look or reference.
- After an update a running server must restart; copying files does not reload Python modules.
- Automated checks do not prove real browser rendering or aesthetic quality. Read the contact sheets and listen when possible.

## Final update and everyday-use lessons
- Same-PID restart can leave an old child as a zombie. Observe its exit, reap only our exited child, and keep the Studio shell open even when safe retirement needs attention. Never queue past an unverified live worker.
- Import the previous installation-private speech snapshot with pinned hashes at startup. Do not demand a second download for a verified model or reuse an external cache by accident.
- Readiness is version-bound and rechecks itself with backoff. A stale repair banner is not a permanent state.
- Waiting for another video is not rendering progress or a stall. Keep the kernel resource lock and exclude checked queue time from the work budget.
- Unpasted requests stay saved across updates; a real command or active edit still blocks mutation.
- Launch after a folder move with the relative local launcher. Resolve previous app paths without altering immutable request bytes and refresh only queued saved messages.
- Fixed tool routes and a delivery-token argument match the existing project rule; no automatic permission grants or settings expansion. A wrong open workspace gets one clear instruction.
- Verify a download with SHA-256 before installation; no system Python or Command Line Tools bootstrap.
- Encode into a unique sibling, verify it, then replace the last movie. A disk-full failure must keep the last verified movie.
- Before pasting, the editing timeline is a paused saved preview. Actual animation/progress starts only with real editing; the explicit visual-preview route remains available.
- Corrupted project metadata stays listed; never erase it to make the screen load.

## Update-to-first-edit handoff
- Never return an old green readiness record while launching a new version check, even if the older file lacks a version.
- Repeated Make must reuse a compatible pending immutable request across contract upgrades, preserving its ID, token and bytes. Refuse changed captured instructions or feedback; automatic face measurements are not user changes.
- A real failed renderer probe must record a permission/repair wait for its exact current owner, so Studio does not appear silently stuck. A successful rerun clears only that probe’s wait. Never grant permission or clear an unrelated customer question.
