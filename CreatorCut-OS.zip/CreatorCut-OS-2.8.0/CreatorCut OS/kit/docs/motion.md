# CreatorCut motion renderer

Use the installed private tools through `edit.py compose PROJECT`. Read scene-contract.md and style-library.md. Do not install extra skills, Node packages or arbitrary renderers from the editing session.

The main renderer is the pinned HyperFrames engine. The app supplies its private Node, browser, FFmpeg, font cache and one-worker memory limit. The studio style library has its own pinned implementation and font bundle; select and execute that exact code, with measured suitability and real effect slots. Keep the chosen colour recipe and Captions switch. Do not add a pack-wide grade over prepared footage.

Build and inspect a scene plan, compose a candidate, review actual frames and sound signals, then publish through the workflow gates. Rendering is not publication. Remotion remains installed for explicitly authored React scenes; its presence is not required to read these instructions.

The browser must run under the selected host's normal security policy. Test the actual project renderer before expensive work. A permission request requires the creator's real decision. Never add `--no-sandbox`, disable the host sandbox, accept a permission on the creator's behalf, or call an outside service to route around a denied operation. A bounded successful frame probe does not authorize other operations.
