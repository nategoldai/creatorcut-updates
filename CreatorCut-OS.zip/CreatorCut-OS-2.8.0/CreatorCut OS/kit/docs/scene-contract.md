# Scene contract and review

All times are seconds on the final cut. Use UTF-8 JSON and local assets (no remote runtime dependencies). Paths resolve from the project first, then the app root. Reference material must be owned/usable; copying style doesn't authorize copying a soundtrack or creator footage.

## scene-plan.json
```json
{
 "schema":1,
 "brief":"Make a quiet product demo matching the reference, without music.",
 "reference":{"source":"media/reference.mp4","summary":"Minimal UI, restrained motion, serif headline.","evidence":["reference-entry.jpg","reference-hold.jpg"]},
 "decisions":{"colour":"preserve","voice":"preserve","music":"none"},
 "requirements":[{"id":"r1","text":"Show upload at the spoken phrase","scenes":["upload"]}],
 "unresolved":[],
 "scenes":[{"id":"upload","t0":0,"t1":4,"speech":"drop your footage","purpose":"Demonstrate upload","reference":{"t0":2,"t1":6},"layout":"Native composer; face unobstructed","entry":"File follows cursor into drop target","hold":"Upload completes; name stays readable","exit":"Cut to preview","sound":"none","items":["upload-ui"]}]
}
```
Scenes in chronological order cover the full cut, without gaps or overlaps. Use treatment `footage` and items [] for intentional plain footage. Use speech `none` for a non-speaking sequence. Anchors must occur in words.json. Match their exact positions by inspection; substring matching is only an omission check.

No reference? Use reference source "", evidence [], and a top-level `style_direction` describing the customer's request and the Signature fallback for unspecified features (see signature-style.md). Colour choices: preserve/reference/custom; voice preserve/process; music none/provided/licensed. Explain custom colour or voice requests in decisions.reason. List missing assets in unresolved; final rendering blocks until resolved.

## edit-plan.json additions
Keep the existing renderer schema; add unique `id` to every item and list those ids in scene items. Items may span adjacent scenes (for example a persistent title); list the item in every scene it spans. An item must overlap each bound scene, and the bindings must cover its full duration. No implicit rearrangement of overlapping graphics in scene-contract projects. Use `together` only as legacy compatibility.

Audio is explicit:
```json
"audio": {
 "music":{"src":"media/owned-track.wav","volume":0.08,"rights":"Original track provided by customer"},
 "events":[{"scene":"upload","t":1.2,"src":"kit/sfx/click.wav","volume":0.12,"reason":"File lands in the composer"}]
}
```
Omit music for no music. No global automated sound-on-every-scene loop. Voice comes from cut.mp4 unchanged except required resampling/encoding; beds duck under it. Mixed output uses a safety limiter without automatic loudness enhancement. No voice filter strings accepted. Mastering requests require explicit source preparation.

Strip/grid pieces accept video srcs and render muted timed video elements. Use actual video assets long enough for the scene. Images are allowed only when the design calls for stills. Custom HTML/GSAP must be local, deterministic and use the renderer's timeline. Avoid arbitrary scripts from references/sites. Character-safe escaping is your responsibility for custom HTML.

## review.json
`compose` emits render/candidate.json. Copy its sha256 into candidate_sha256. After inspecting evidence and watching/listening, write:
```json
{
 "candidate_sha256":"HASH FROM candidate.json",
 "reviewer":"Codex session xyz",
 "watched_video":true,
 "listened_audio":true,
 "checks":{
  "speech":{"pass":true,"observations":"Full words at cuts; no duplicate opening."},
  "reference":{"pass":true,"observations":"Compared entrance, hold and exit against supplied reference."},
  "typography":{"pass":true,"observations":"Family and weight verified; full message remains visible."},
  "motion":{"pass":true,"observations":"Cursor and upload move together on the spoken phrase."},
  "assets":{"pass":true,"observations":"Correct source, playing footage and customer logo verified."},
  "audio":{"pass":true,"observations":"Narration clear; no music as requested; no cut clicks."},
  "colour":{"pass":true,"observations":"Source appearance preserved; graphics remain white."}
 },
 "scenes":{"upload":{"pass":true,"observations":"Checked entrance at .1s, movement at .8s, hold at 2s and exit at 3.9s."}},
 "issues":[]
}
```
The review is a recorded attestation, not a model-based proof of taste. Never mark a property pass without examining it. Aesthetic agreement still belongs to the customer. All changes to plan/media/fonts invalidate the release approval. Published output is the exact reviewed candidate, never a new unchecked encode.

## Intentional visual findings
Runtime/lint failures block rendering. Layout, motion and contrast findings are carried into the candidate because video designs can deliberately overlap text and a foreground mask or move off canvas. They are not silently discarded: every error-level visual finding in render/check.json needs a specific disposition before release.

Fix a real problem and re-render. For an intentional design, add to review.json:
```json
"exceptions":[{"finding":"layout:text_occluded:#i16w0","reason":"Foreground hair intentionally overlaps this reference-matched title; visible letters remain readable during the hold.","evidence":["render/review-frames/0005.jpg","ref-hold.jpg"]}]
```
Use the exact finding id. Inspect actual pixels and motion, especially transparent masks; bounding-box checks can mistake an alpha video for an opaque rectangle. Never use exceptions to conceal cropped prompts, unreadable words, missing assets or accidental layers. Customer brief/reference determines style; this isn't a blanket WCAG web-page contrast requirement on creative video.

## Hosts with frame-only / signal-only inspection
Never claim native playback or perceptual listening if the host cannot do it. In that case set watched_video/listened_audio false, visual_method "frame_sequence", audio_method "signal_analysis", and a nonempty limitations list. Inspect the generated per-scene image sequences and render/audio-check.json; this report is tied to the candidate hash. All substantive checks and scene observations still apply. State any remaining audio/motion judgement clearly in the release note. Signal levels are not proof that a soundtrack sounds pleasant or matches a reference.

## Video framing and working size
Strip/grid pieces default to uncropped portrait media (`aspect: 0.5625`, `fit: "contain"`). Choose cover/crop only when the requested reference calls for it; aspect is width/height. Grid background is configurable and defaults to transparent. Card video proxies are sized to their rendered use rather than decoding full-resolution phone footage for every small tile. Custom HTML can provide `asset_sizes: {"KEY":[width,height]}` alongside its assets map. Keep enough resolution for intended zooms; do not stretch or crop a UI screenshot to force a match. Browser renders default to one worker to limit RAM pressure; advanced users can set project render_workers from 1 to 4.


Memory application is a render gate: for each rule in customer-memory.json, add an entry to scene-plan.json memory_application with its exact rule, status (applied / overridden / not_applicable), reason and scene ids for applied rules. Current explicit requests may override an old preference, but explain the reason rather than silently ignoring it. Candidate fingerprints include this memory snapshot, so changing it requires fresh review. During review inspect those scenes; this structural gate does not itself prove artistic quality.
Presets can be saved before production from Step 5 with their full entered instructions, look/settings and actual reference analysis pointers. This is a starting recipe, clearly not an approved finished edit. After approval, Update preset with this final video replaces the active recipe using the reviewed plans and custom source evidence. Retained old recipe versions serve existing projects. Empty new briefs inherit the saved template; existing user instructions are never silently replaced. The general memory stays private in background files, with no Profile/Settings/memory page. Users can request changes/forgetting in this native conversation.

## ccMixter music credits
Library tracks retain their track-specific Creative Commons BY licence and exact credit. Include the shown credit and source/licence link in the post description. Studio offers Copy credit on the selected track and finished video; each published version keeps a matching vN.credits.txt post-details file. Uploaded music must be supplied with permission. Auto requires a real licensed track with audio.music.src, rights and reason. When offline, choose suitable already-downloaded licensed audio or report the missing input; never silently remove music. No ownership or Content ID promise is made.

The owner must review ccMixter automated-use terms before launch. Downloads currently send the track page as Referer, as required by the service; technical access is not legal approval.
