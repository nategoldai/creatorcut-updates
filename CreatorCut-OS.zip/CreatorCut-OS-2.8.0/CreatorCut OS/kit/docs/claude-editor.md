# CreatorCut visible-chat editing

Studio saves an immutable request in this installation. The user's visible AI chat is the only editor. Read AGENTS.md or CLAUDE.md, then follow kit/editor/RECIPE.md.

Claude runs `edit.py next` and arms `edit.py wait` in the background. In Codex, go/start/continue/update runs `edit.py next`. Only one edit runs at a time; other requests stay in line. No clipboard message, delivery token, hidden model or permission relay is used.

The engine writes one status file per project. Studio reads that status: waiting for the chat, working, needs you, paused, stopped or done. Progress only rises within a request and reaches 100 when the video is published.

Stop edit preserves originals and versions. Open the same project in the AI and type continue after a closed chat. Respect genuine host permissions. A finished video is technically checked and saved as a new version. One failed effect is left out plainly while the rest finishes.

This documentation is not evidence of a completed customer test. Current build acceptance is recorded truthfully in BUILD.json and the independent validation report.
