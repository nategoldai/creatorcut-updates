# CreatorCut Signature — fallback design system

This is the shipped fallback, not a claim about a customer's taste. Use it whenever the current brief, selected reference/preset and lasting preferences leave a visual choice unclear. Fill gaps per feature, not by replacing an entire reference with this look. An observed absence (no captions, no boxes, no music, no animation) is a choice, not missing evidence.

## Priority and actual engine files
Current explicit brief > clear current reference > deliberately selected saved preset > relevant creator memory > Signature. Only fill unknown fields. A reference can govern typography while leaving colour or cards unspecified. Never add an orbit simply because the reference didn't demonstrate one. It may have deliberately simple composition. Read motion and context, then state the interpretation.

`workflow init PROJECT` writes `style-direction.json`. The editor reads the actual Step 5 brief, customer-memory.json, pinned preset recipe and reference evidence. Write `style-inputs.json` with objects named `memory`, `preset`, `reference`, `brief` containing only their supported design fields, then run workflow init again. These are structured translations of real evidence, NOT a natural-language understanding service. Resolve even negative choices explicitly. Keep evidence and reasoning in scene-plan.json. Do not invent measured reference properties.

The effective direction and field provenance are calculated by `kit/editkit/signature.py`. Files are project-local, included in review fingerprints, and never written to preference memory by this resolver. Use default-sourced fields to fill gaps in a measured plan; preserve observed reference fields. A complete reference with no accent should explicitly set caption/accent colours to its observed values, not inherit yellow. If the font family changes, supply its actual file and weight too. Do not mix incompatible family/file pairs.

Example `style-inputs.json`:
```json
{
  "reference": {"styles": {"caption": {"colour": "#F0F0F0"}, "accent": {"colour": "#F0F0F0"}}, "motion": {"caption": {"ease": "cut", "ms": 1}}},
  "brief": {"sound": {"effects": false}, "layout": {"behind_person": false}}
}
```
This keeps the reference's neutral text and still entry, disables SFX/behind-person words, and falls back for genuinely unspecified choices. Freeform instructions must be understood by the editor before rendering; the example is not a keyword parser. Review the generated plan against those instructions.

## Default look
- Inter Tight 800 for normal words; 900 for selective large emphasis. White #FFFFFF, butter yellow #FAE67A. Use source case so brands/acronyms survive. Negative tracking around -.035em; no subtitle box or thick outline by default.
- Caption size .044 of frame height, big emphasis .115. Start around chest y=.63, centred. Fit actual glyphs and adjust to the person. Do not stretch a single line until unreadably small; split meaningful phrases.
- Word entry `anim: {"ease":"signature-pop", "scale_from":1.12, "ms":180}`; small in-place expansion settles to a fixed position. No side slide. This is implemented by compose.py. Holds/exits are bounded by item times. Intentional stillness is fine.
- Instrument Serif italic is available for a warm editorial variation, not random font roulette. DM Serif remains available for dark editorial requests. Keep body fonts consistent through a scene.
- Real video cards: mild tilt, rounded edges and a brief pop. Use only where the spoken meaning benefits; don't put a card on every sentence. Use existing card, note, burst and html items for scene-specific graphics.
- Gentle contrast and restrained vignette only where the user permits a look; protect skin/bright highlights. An explicit Original colour choice means preserve source appearance. No aggressive dark grade or grain by default. No AI replacement room.
- Small synthesized clicks/pops at actual actions; don't repeat a whoosh on every word. Pick a usable music source only if music is requested/appropriate; don't bundle or redistribute the other repo's sound files.

## Behind-person emphasis — default when suitable
Pick a few meaningful spoken words, not every caption. Use person.make_cutout on the exact locked cut/grade, verify matching duration/frame alignment and alpha edges. The background and subject must share framing and zoom. `signature.emphasis_item` builds a big word with conservative placement from measured head tops; with uncertain/moving placement or unavailable cutout it returns a chest-level foreground word instead. It does not claim to track a face itself. Measure several moments in the actual word interval; inspect hair, hands and letter occlusion at full size. At least most of every letter must remain readable. Cutout errors require foreground fallback, not a broken render.

For 9:16, start with conservative margins around top 11.5%, bottom 23.5%, left 4%, right 9.5%; adapt to the target platform/current footage. These are composition guides, not permanent platform specifications. Horizontal video needs a different layout, not cropped portrait coordinates.

## Starter and production
`design PROJECT` without a usable measured kit now writes a real Signature caption starter from the cut word times. It respects shot boundaries and leaves missing audio/cutout out rather than fabricating them. This is not a finished reel: editor chooses emphasis, generates appropriate cutout/inserts, translates explicit instructions, and writes scene bindings before validate/compose/review/publish. If reference analysis is still running, prepare/transcribe first and revise the starter when evidence arrives. Never approve a default render as a faithful reference match while analysis is incomplete.

On measured reference projects, retain the measured plan and use style-direction.json only to complete unsupported/unclear features. Existing reviewed edits and presets are never retroactively restyled. Preset recipes can record the chosen look, but general memory must come from actual customer feedback, not default-generated decisions.

## Provenance
Visual inspiration reviewed: https://github.com/CreatorCut/video-edit-skill . CreatorCut's resolver, starter, animation component and instructions here are independently authored. The upstream template/code and downloaded sound assets are not redistributed. Inter Tight is sourced directly from Google Fonts under OFL; its complete copyright/license notice is in kit/fonts/licenses/InterTight-OFL.txt. Existing fonts/tools keep their own terms. No claim of pixel-identical output or automatic artistic approval.

Measured kits are completed per absent field by signature.complete_kit before planning: existing colours, font files, size and motion remain untouched; no accent is invented when the reference has only one style. The numerical overrides from older memory do not automatically change a fresh reference draft; the editor assesses their relevance against current instructions.
