"""Bounded ccMixter discovery and streaming through the authenticated Studio server."""
from pathlib import Path
import urllib.request,json,time,threading,re,tempfile,os,hashlib
from urllib.parse import urlencode,urlsplit,unquote
from . import util,bounded_http
CACHE={};LOCK=threading.RLock()
TRACKS={str(t['id']).removeprefix('ccmixter-'):dict(t,id=str(t['id']).removeprefix('ccmixter-')) for t in util.read_json(util.KIT/'studio/app/music-catalogue.json',default={}).get('tracks',[])}
def safe_url(value,prefix):
 try:
  u=urlsplit(value)
  return u.scheme=='https' and u.netloc=='ccmixter.org' and u.path.startswith(prefix) and '..' not in unquote(u.path).split('/') and not u.username and not u.fragment
 except (ValueError,TypeError):return False
def normalized_track(row):
 files=[f for f in row.get('files',[]) if f.get('file_name','').lower().endswith('.mp3') and f.get('download_url','').startswith('https://ccmixter.org/content/')]
 if not files or not safe_url(files[0]['download_url'],'/content/') or not safe_url(row.get('file_page_url',''),'/files/'):return None
 f=files[0];extra=row.get('upload_extra') or {}
 return dict(id=str(row['upload_id']),title=row['upload_name'],artist=row.get('user_real_name') or row['user_name'],url=f['download_url'],duration=f.get('file_format_info',{}).get('ps',''),bpm=extra.get('bpm',''),source=row['file_page_url'],license=row.get('license_url',''),credit='Music: '+row['upload_name']+' by '+(row.get('user_real_name') or row['user_name'])+' · '+row.get('license_url',''),tags=str(extra.get('usertags','')).split(',')[:4])
def lookup(track_id):
 if not re.fullmatch(r'\d{1,12}',track_id):return None
 saved=util.read_json(util.STUDIO_OUT/'music-metadata.json',default={})
 if track_id not in TRACKS and isinstance(saved,dict) and track_id in saved:TRACKS[track_id]=saved[track_id]
 with LOCK:track=TRACKS.get(track_id)
 if track and all(k in track for k in ('title','artist','url','source')):return track
 if not re.fullmatch(r'\d{1,12}',track_id):return None
 try:
  endpoint='https://ccmixter.org/api/query?'+urlencode(dict(f='json',limit=1,ids=track_id,lic='by'))
  items=json.loads(bounded_http.get(endpoint,seconds=8,max_bytes=250000))
  for item in items:
   if str(item.get('upload_id'))==track_id:
    track=normalized_track(item)
    if track:
     with LOCK:
      TRACKS[track_id]=track
      persist()
     return track
 except Exception:pass
 return None
def prune_preview_cache(folder):
 # Only disposable preview files created by this demo, never project/uploaded audio.
 files=[f for f in folder.glob('*.mp3') if re.fullmatch(r'\d{1,12}\.mp3',f.name)]
 files.sort(key=lambda f:f.stat().st_mtime,reverse=True);total=0
 for file in files:
  total+=file.stat().st_size
  if total>96*1024*1024:
   file.unlink(missing_ok=True);file.with_suffix('.json').unlink(missing_ok=True)

def persist():
 rows=dict(list(TRACKS.items())[-1000:]);util.write_durable_json(util.STUDIO_OUT/'music-metadata.json',rows)
def search(query='',page=0):
 query=str(query).strip()[:100]
 if type(page) is not int or not 0<=page<=30:raise util.Fail('Try that search again.')
 key=(query,page)
 with LOCK:cached=CACHE.get(key)
 if cached and time.time()-cached[0]<900:return cached[1]
 params=dict(f='json',limit=8,offset=page*8,lic='by',reqtags='instrumental',sort='rank')
 if query:params.update(search=query,search_type='all')
 try:
  req=urllib.request.Request('https://ccmixter.org/api/query?'+urlencode(params),headers={'User-Agent':'CreatorCut-Music/1.0'})
  raw=bounded_http.get(req.full_url,seconds=10,max_bytes=2_000_000,headers=dict(req.header_items()))
  source=json.loads(raw)
  if not isinstance(source,list):raise ValueError('Invalid response')
  rows=[t for row in source if (t:=normalized_track(row))]
  result=dict(ok=True,tracks=rows,page=page,has_more=len(source)==8,query=query)
  with LOCK:
   TRACKS.update({t['id']:t for t in rows});persist();CACHE[key]=(time.time(),result)
   while len(CACHE)>80:CACHE.pop(next(iter(CACHE)))
   while len(TRACKS)>1000:TRACKS.pop(next(iter(TRACKS)))
  return result
 except Exception as e:raise util.Fail('Search is unavailable just now. Your current tracks are still here.') from e
class Preview:
 def __init__(self,handler):self.handler=handler
 def __getattr__(self,key):return getattr(self.handler,key)
 def reply(self,data,status=200):return self.handler._json(dict(ok=status<400,**data),status)
 def local_audio(self,file):return self.handler._file(util.rel(file),('kit/studio-out/assets/',),private=True)
 def audio(self,track_id):
   track=lookup(track_id)
   if not track:return self.reply({'error':'Search for this track again.'},404)
   if not track['url'].startswith('https://ccmixter.org/content/'):return self.reply({'error':'Preview unavailable.'},400)
   rang=self.headers.get('Range','')
   if rang and not re.fullmatch(r'bytes=\d*-\d*',rang):return self.reply({'error':'Invalid preview range.'},416)
   cache=util.STUDIO_OUT/'assets/music-previews'
   try:cache.mkdir(parents=True,exist_ok=True)
   except OSError:return self.reply({'error':'Preview storage is unavailable. Free some space and try again.'},503)
   cached=cache/(track_id+'.mp3');receipt=cache/(track_id+'.json')
   if cached.exists() and receipt.exists():
    try:
     info=json.loads(receipt.read_text())
     if info.get('url')==track['url'] and info.get('sha256')==hashlib.sha256(cached.read_bytes()).hexdigest():
      os.utime(cached,None);return self.local_audio(cached)
    except Exception:pass
   # Selected library music is already fully downloaded and audio-verified.
   key=hashlib.sha256(track['url'].encode()).hexdigest();prepared=util.STUDIO_OUT/'assets/music'/(key+'.mp3');prepared_receipt=prepared.with_suffix('.json')
   if prepared.exists() and prepared_receipt.exists():
    try:
     data=json.loads(prepared_receipt.read_text())
     if data.get('source')==track['url'] and data.get('sha256')==hashlib.sha256(prepared.read_bytes()).hexdigest():return self.local_audio(prepared)
    except Exception:pass
   # Normal browser compatibility: ccMixter requires a track-page Referer.
   headers={'User-Agent':'Mozilla/5.0 (compatible; CreatorCutMusicDemo/1.0)','Referer':track['source']}
   # Download one complete cache entry; local_audio applies the browser Range.
   try:
    prepared=cache/(track_id+'-'+__import__('secrets').token_hex(8)+'.pending')
    receipt=bounded_http.fetch(track['url'],seconds=60,max_bytes=30_000_000,headers=headers,destination=prepared)
    if not safe_url(receipt['url'],'/content/'):prepared.unlink(missing_ok=True);return self.reply({'error':'Preview unavailable. Choose another track.'},502)
    prepared.replace(cached);receiptfile=cache/(track_id+'.json');receiptfile.write_text(json.dumps({'url':track['url'],'sha256':hashlib.sha256(cached.read_bytes()).hexdigest()}));prune_preview_cache(cache)
    return self.local_audio(cached)
   except Exception:
    try:prepared.unlink(missing_ok=True)
    except (OSError,UnboundLocalError):pass
    return self.reply({'error':'This preview could not load. Choose another track or upload your own music.'},502)
