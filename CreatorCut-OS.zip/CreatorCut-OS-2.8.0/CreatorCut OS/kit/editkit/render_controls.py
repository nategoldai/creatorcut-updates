"""Mechanical Studio controls for the main renderer, separate from creative inference.
Only a verbatim current brief override may waive a selected scalar control.
"""
import copy,math
from . import util

def _settings(p):
 from . import requests
 request=requests.active(p)
 return request.get('settings',{}) if request else {}  # Existing reviewed projects remain valid until their next explicit Studio request.

def normalized(p,plan,scene=None):
 cfg=_settings(p);out=copy.deepcopy(plan);scene=scene or {};overrides=scene.get('studio_control_overrides',{})
 prompt=str(cfg.get('brief',{}).get('prompt',''))
 def enabled(key):
  row=overrides.get(key) if isinstance(overrides,dict) else None
  if row is None:return True
  quote=row.get('quote','') if isinstance(row,dict) else ''
  if not isinstance(quote,str) or len(quote.strip())<12 or quote not in prompt or len(str(row.get('reason','')).strip())<20:
   raise util.Fail('A Studio control override needs the exact current brief sentence and a concrete reason: '+key)
  return False
 if cfg.get('sfx') is False and enabled('sfx'):
  out.setdefault('audio',{})['events']=[]
 if cfg.get('zoom') is False and enabled('zoom'):
  out.setdefault('background',{})['zooms']=[]
 if cfg.get('music')=='none' and enabled('music'):
  out.setdefault('audio',{}).pop('music',None)
 if cfg.get('music_selection') and enabled('music'):
  from . import music_library
  out=music_library.apply_plan(p,cfg,out)
 if 'music_volume' in cfg and enabled('music_volume') and out.get('audio',{}).get('music'):
  value=cfg['music_volume']
  if type(value) not in (int,float) or not math.isfinite(value) or not 0<=value<=.5:raise util.Fail('The saved music volume needs a value between 0 and 0.5.')
  out['audio']['music']['volume']=value
 if type(cfg.get('voice_cleanup')) is bool and enabled('voice_cleanup'):
  out.setdefault('audio',{})['voice_cleanup']=cfg['voice_cleanup']
 volume=cfg.get('overrides',{}).get('sfx',{}).get('volume')
 if volume is not None and enabled('sfx_volume'):
  if type(volume) not in (int,float) or not math.isfinite(volume) or not 0<=volume<=.6:raise util.Fail('Choose an effects level between 0 and 0.6.')
  out.setdefault('audio',{})['sfx_volume']=volume
 if cfg.get('framing'):
  out['studio_framing']=copy.deepcopy(cfg['framing'])
 if (cfg.get('captions') or {}).get('enabled') is False and enabled('captions'):
  out['items']=[item for item in out.get('items',[]) if item.get('type')!='caption']
 if type(cfg.get('progress_bar')) is bool and enabled('progress_bar'):
  out['studio_progress_bar']=cfg['progress_bar']
 return out

def preflight(p):
 plan=util.read_json(p/'edit-plan.json',default={});scene=util.read_json(p/'scene-plan.json',default={})
 actual=normalized(p,plan,scene)
 if actual!=plan:
  # This is called under the per-project lock before render fingerprints are taken.
  util.write_durable_json(p/'edit-plan.json',actual)
 return actual

def prepare(p):
 return preflight(p)

def errors(p,scene,plan):
 try:
  actual=normalized(p,plan,scene)
 except util.Fail as error:return [error.message]
 issues=[]
 if actual.get('audio',{})!=plan.get('audio',{}):
  changed=["audio."+key for key in sorted(set(actual.get('audio',{}))|set(plan.get('audio',{}))) if actual.get('audio',{}).get(key)!=plan.get('audio',{}).get(key)]
  issues.append('Saved Studio controls differ at '+', '.join(changed)+'. Run workflow validate for this project to prepare the saved controls.')
 if actual.get('background',{}).get('zooms')!=plan.get('background',{}).get('zooms'):issues.append('Zoom is off in Studio: remove background punch-ins.')
 if actual.get('studio_framing')!=plan.get('studio_framing'):issues.append('Rebuild the cut and prepare the saved framing before rendering.')
 cfg=_settings(p)
 if cfg.get('framing'):
  receipt=util.read_json(p/'cut-controls.json',default={})
  from .workflow import digest
  if receipt.get('framing')!=cfg['framing'] or not (p/'cut.mp4').is_file() or receipt.get('cut_sha256')!=digest(p/'cut.mp4'):issues.append('The cut does not match the saved framing. Rebuild the cut before styling and rendering.')
 if cfg.get('captions',{}).get('enabled') is False and any(item.get('type')=='caption' for item in plan.get('items',[])):issues.append('Captions are off in the saved request. Remove the caption items before rendering.')
 if str(plan.get('background',{}).get('src','')).startswith('work/style-library/'):
  from . import caption_adjust
  expected=caption_adjust.normalized(cfg.get('captions',{}));execution=util.read_json(p/'work/style-library/execution.json',default={})
  for key in ('zoom','sfx'):
   if key in cfg and execution.get('studio_switches',{}).get(key)!=cfg[key]:issues.append('Rebuild the style composite with the saved '+key+' switch.')
  if execution.get('caption_adjust')!=expected:issues.append('Rebuild the chosen caption recipe with the saved size, position and case.')
 if cfg.get('zoom') is True and not plan.get('background',{}).get('zooms') and not str(plan.get('background',{}).get('src','')).startswith('work/style-library/'):
  issues.append('Zoom was requested. Plan an actual punch-in or turn Zoom off; generic application text does not add one.')
 if cfg.get('sfx') is True and not plan.get('audio',{}).get('events'):
  issues.append('Sound effects were requested. Add actual timed sound cues or turn effects off; generic application text does not add sound.')
 if actual.get('studio_progress_bar')!=plan.get('studio_progress_bar'):issues.append('Apply the saved Studio progress-bar switch before rendering.')
 return issues
