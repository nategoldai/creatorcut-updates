"""Verified process layout only. This record grants no host permissions."""
import hashlib,json
from pathlib import Path
from . import util

def signature():
 from . import motion
 browser=motion.chrome()
 paths=[browser,util.BIN/'node/bin/node',util.KIT/'tools/browser_policy.mjs',util.KIT/'tools/renderer_browser_probe.mjs',util.KIT/'tools/browser_compat.mjs']
 try:
  rows=[(str(p.resolve()),p.stat().st_size,p.stat().st_mtime_ns) for p in paths if p is not None]
  if len(rows)!=len(paths):return None
  return hashlib.sha256(json.dumps(rows).encode()).hexdigest()
 except OSError:return None

def current(project):
 try:row=util.read_json(Path(project)/'browser-runtime.json',default={})
 except (OSError,util.Fail):return None
 sig=signature()
 if sig and row.get('signature')==sig and row.get('verified_frame') is True and row.get('mode') in ('normal','compatibility'):return row['mode']
 return None

def remember(project,mode):
 sig=signature()
 if sig:util.write_durable_json(Path(project)/'browser-runtime.json',{'mode':mode,'signature':sig,'verified_frame':True,'permission_granted':False})

def ensure(project):
 """Verify a real frame in this caller's existing access before expensive rendering."""
 known=current(project)
 if known:return known
 import importlib.util
 path=util.KIT/'tools/renderer_probe.py'
 spec=importlib.util.spec_from_file_location('_creatorcut_renderer_preflight',path)
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 util.step('Checking the video renderer…')
 util.activity('Checking the video renderer')
 okay,message=module.browser_probe(Path(project))
 if not okay:raise util.Fail(message,'Check the renderer in this same chat, then retry the saved render once. Do not start another editor or change host permissions automatically.')
 return current(project)
