"""Executable Studio colour choices. No implicit creative look or reference substitution."""
from pathlib import Path
import hashlib,math,shutil
from . import util,look
ALIASES={'original':'natural','none':'natural','mono':'bw','clean':'bright'}
PRESETS={'natural':'','bright':"eq=brightness=0.065:contrast=0.96:saturation=1.06",'warm':look.GRADES['warm']['filter'],'cinematic':look.GRADES['cinematic']['filter'],'moody':look.GRADES['moody']['filter'],'bw':look.GRADES['mono']['filter'],**{k:look.GRADES[k]['filter'] for k in ('punchy','soft','luxe','film')}}
VERSION=2

def choice(cfg):
 value=cfg.get('grade') if cfg.get('grade') is not None else (cfg.get('look') or 'natural')
 value=ALIASES.get(value,value)
 if value not in PRESETS and value not in ('reference','custom'):raise util.Fail('Choose a supported colour look in Studio; no replacement grade has been applied.')
 return value

def digest(path):
 from .workflow import digest as stream_digest
 return stream_digest(Path(path))

def pin(cfg):
 key=choice(cfg)
 if key in ('reference','custom'):return None
 saved=cfg.get('colour_recipe')
 if isinstance(saved,dict) and saved.get('choice')==key:
  if saved.get('version') not in (1,VERSION) or not isinstance(saved.get('filter'),str):raise util.Fail('This saved colour recipe needs its supported version; no generic replacement was applied.')
  if key=='natural' and saved['filter']:raise util.Fail('Original colour cannot include a creative filter.')
  if key!='natural' and not saved['filter'].strip():raise util.Fail('This saved colour look has no executable filter. Choose its preset again.')
  return dict(saved)
 return {'version':VERSION,'choice':key,'filter':PRESETS[key]}

def reference(p):
 from . import refs
 attached=refs.for_project(p.name)
 data=util.read_json(p/'style-inputs.json',default={}).get('reference',{})
 value=data.get('colour') if isinstance(data,dict) else None
 if attached:
  current=attached[-1]
  if current.get('status')!='done' or current.get('study_error') or current.get('cover_only'):raise util.Fail('Finish scanning the current reference video before matching its colour.')
  value=util.read_json(refs._ref_dir(current['id'])/'kit.json',default={}).get('colour')
  if not value:raise util.Fail('The current reference has no measured colour yet. Scan it again; no older preset was substituted.')
 if not value:
  from . import styles
  cfg=util.read_json(p/'project.json');file=styles.style_path(cfg.get('reference_style') or cfg.get('style',''))
  value=(util.read_json(file,default={}).get('kit') or {}).get('colour') if file else None
 if not isinstance(value,dict) or not all(type(value.get(k)) in (int,float) and math.isfinite(value[k]) for k in ('lum','contrast','sat','warm')):
  raise util.Fail('The reference colour has not been measured. Scan the reference video before matching its colour.')
 return {k:value[k] for k in ('lum','contrast','sat','warm')}

def recipe(p):
 cfg=util.read_json(p/'project.json');key=choice(cfg);out=pin(cfg) or {'version':VERSION,'choice':key,'filter':PRESETS.get(key)}
 if key=='reference':out['reference']=reference(p)
 if key=='custom':
  from . import styles
  style=styles.for_project(cfg);vf=style.get('grade_filter')
  if not vf:raise util.Fail('This preset has no saved custom colour filter. Choose a look or scan its reference again.')
  out['filter']=vf
 return out

def ensure_cut(p):
 from . import resources
 with resources.heavy():
  src=p/'cut.mp4'
  if not src.is_file():raise util.Fail('Finish the source cut before preparing its colour.')
  spec=recipe(p);source_hash=digest(src);out=p/'graded.mp4';record=p/'render/grade.json';saved=util.read_json(record,default={})
  prepared=src if spec['choice']=='natural' else out
  if saved.get('recipe')==spec and saved.get('source_sha256')==source_hash and prepared.is_file() and saved.get('output_sha256')==digest(prepared):return prepared
  if spec['choice']=='natural':
   util.write_json(record,{'filter':'','applied':False,'recipe':spec,'source_sha256':source_hash,'output_sha256':source_hash})
   return src
  temp=p/'graded.pending.mp4'
  try:
   if spec['choice']=='natural':shutil.copy2(src,temp);result={'filter':'','applied':False}
   elif spec['choice']=='reference':
    from . import grade
    result=grade.match(spec['reference'],src,temp)
   else:
    util.run([util.ffmpeg_bin(),'-nostdin','-v','error','-y','-i',str(src),'-vf',spec['filter'],'-c:v','libx264','-preset','veryfast','-crf','16','-pix_fmt','yuv420p','-g','30','-c:a','copy',str(temp)])
    result={'filter':spec['filter'],'applied':True}
   if digest(src)!=source_hash:raise util.Fail('The source cut changed during colour preparation. Prepare the current cut again.')
   temp.replace(out);util.write_json(record,dict(result,recipe=spec,source_sha256=source_hash,output_sha256=digest(out)))
  finally:temp.unlink(missing_ok=True)
  return src if spec['choice']=='natural' else out

def prepare_plan(p):
 plan=util.read_json(p/'edit-plan.json',default={});bg=plan.get('background',{})
 if bg.get('src') not in ('cut.mp4','graded.mp4'):return
 source=ensure_cut(p).relative_to(p).as_posix()
 if bg['src']!=source:bg['src']=source;util.write_json(p/'edit-plan.json',plan)

def errors(p,doc,plan):
 cfg=util.read_json(p/'project.json',default={})
 if 'look' not in cfg and cfg.get('grade') is None:return []
 try:spec=recipe(p)
 except util.Fail as e:return [str(e)]
 expected='preserve' if spec['choice']=='natural' else 'reference' if spec['choice']=='reference' else 'custom'
 out=[]
 if doc.get('decisions',{}).get('colour')!=expected:out.append('Scene colour decision does not match the explicit Studio colour choice: '+spec['choice'])
 bg=plan.get('background',{}).get('src','')
 if spec['choice']=='natural' and bg=='cut.mp4':return out
 report=util.read_json(p/'render/grade.json',default={})
 cut=p/'cut.mp4';graded=cut if spec['choice']=='natural' else p/'graded.mp4'
 if report.get('recipe')!=spec or not cut.is_file() or report.get('source_sha256')!=digest(cut) or not graded.is_file() or report.get('output_sha256')!=digest(graded):
  return out+['Prepare the selected colour from the current cut before rendering; its colour receipt is missing or stale.']
 if bg=='graded.mp4':return out
 execution=util.read_json(p/'work/style-library/execution.json',default={})
 if execution.get('source',{}).get('sha256')!=digest(graded if spec['choice']!='natural' else cut):out.append('Rebuild the selected style from the current colour-prepared cut; do not reuse an older graded composite.')
 return out

def lock_library_colour(workspace):
 """The selected colour recipe is already in arroll. Suppress only pack-wide footage grading.

 Do not mutate pinned effect code or remove graphics, masks, transitions, typography or blur on other layers.
 """
 file=workspace/'index.html';html=file.read_text()
 policy='<style id="creatorcut-colour-policy">#plate,#cutw,.gr{filter:none!important}.vgtint,.vgvig{display:none!important}</style>'
 vignette='<div class="full" style="background:radial-gradient(120% 75% at 50% 45%,rgba(0,0,0,0) 50%,rgba(20,10,5,.42) 100%)"></div>'
 html=html.replace(vignette,'')
 if '</head>' not in html:raise util.Fail('The selected style did not build a complete composition.')
 html=html.replace('</head>',policy+'</head>',1);util.write_text(file,html)
 util.write_json(workspace/'colour-policy.json',{'schema':1,'scope':'disable additional reel-wide library grades; source already prepared','html_sha256':digest(file),'implementation_sha256':digest(Path(__file__))})
