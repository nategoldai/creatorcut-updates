"""Schema-checked, crash-recoverable plan writes. No evaluation of model-authored text."""
import json
from . import util

def validate(scene,plan):
 try:json.dumps([scene,plan],allow_nan=False)
 except (TypeError,ValueError):raise util.Fail('The edit plans contain an unsupported value or invalid number.')
 errors=[]
 for label,doc,required in [('scene plan',scene,{'scenes':list,'decisions':dict,'reference':dict,'requirements':list}),('edit plan',plan,{'items':list,'canvas':dict,'fonts':dict,'styles':dict,'background':dict})]:
  if not isinstance(doc,dict):errors.append(label+' must be an object.');continue
  for key,kind in required.items():
   if not isinstance(doc.get(key),kind):errors.append(label+'.'+key+' must be a '+kind.__name__+'.')
 if isinstance(scene,dict) and isinstance(scene.get('scenes'),list):
  ids=[x.get('id') for x in scene['scenes'] if isinstance(x,dict)]
  if len(ids)!=len(scene['scenes']) or any(not isinstance(x,str) or not x for x in ids) or len(set(ids))!=len(ids):errors.append('Each scene needs one unique string id.')
 if isinstance(plan,dict) and isinstance(plan.get('items'),list) and any(not isinstance(x,dict) for x in plan['items']):errors.append('Each render item must be an object.')
 if errors:raise util.Fail('The plans need corrections before saving.','\n'.join(errors))

def recover(p):
 journal=p/'plan-transaction.json';doc=util.read_json(journal,default={})
 if not doc or doc.get('phase')=='committed':return False
 if doc.get('phase')!='applying':raise util.Fail('The saved plan transaction needs recovery.')
 from . import requests
 if doc.get('request_id')!=requests.active(p).get('id'):raise util.Fail('An interrupted plan belongs to an earlier request. Save both current plans together again.')
 validate(doc.get('scene'),doc.get('plan'))
 util.write_durable_json(p/'scene-plan.json',doc['scene']);util.write_durable_json(p/'edit-plan.json',doc['plan'])
 util.write_durable_json(journal,dict(doc,phase='committed'));return True

def save(p,scene,plan):
 validate(scene,plan)
 from . import requests
 with util.project_lock(p,heavy_work=False),util.file_guard(p/'.plan-save.guard',timeout=5):
  request=requests.active(p)
  if request and scene.get('request_id')!=request['id']:raise util.Fail('Bind the scene plan to the current saved request before saving.')
  doc={'phase':'applying','request_id':request.get('id'),'scene':scene,'plan':plan}
  util.write_durable_json(p/'plan-transaction.json',doc)
  recover(p)
 return {'ok':True,'scene_count':len(scene['scenes']),'item_count':len(plan['items'])}
