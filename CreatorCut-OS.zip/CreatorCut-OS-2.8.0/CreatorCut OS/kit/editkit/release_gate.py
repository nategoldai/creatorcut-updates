"""Release admission uses evidence bound to this source, never historical green flags."""
import json,hashlib,re,datetime
from pathlib import Path
HOST_REQUIRED={host:tuple(key+'_'+host for key in ('clean_install','make_publish','revision')) for host in ('codex','claude')}
COMMON_REQUIRED=('reference_and_choices','download_saved_video','update_and_rollback','backend_and_ui','release_e2e','customer_journey')

REQUIRED=HOST_REQUIRED['claude']+COMMON_REQUIRED

def errors(source,evidence):
 source=Path(source);evidence=Path(evidence);issues=[]
 def read(file):
  try:
   value=json.loads(file.read_text())
   return value if isinstance(value,dict) else {}
  except (OSError,ValueError):return {}
 build=read(source/'BUILD.json');receipt=read(evidence)
 policy=read(source/'kit/execution-policy.json')
 if policy.get('default_editor_mode')!='chat':issues.append('The customer execution policy must default to visible-chat editing.')
 version=(source/'kit/VERSION').read_text().strip()
 if build.get('version')!=version:issues.append('Build metadata and the app version differ.')
 if build.get('status')!='release' and not (build.get('status')=='candidate' and receipt.get('owner_release_approved') is True):issues.append('This app is a candidate, not an approved customer release.')
 if receipt.get('version')!=version:issues.append('Acceptance evidence is missing for this exact version.')
 manifest=receipt.get('source_manifest',{})
 if not isinstance(manifest,dict) or not manifest:issues.append('A source-bound verification manifest is required.')
 else:
  for name,want in manifest.items():
   rel=Path(name) if isinstance(name,str) else Path('..')
   if rel.is_absolute() or '..' in rel.parts or not isinstance(want,str) or not re.fullmatch('[0-9a-f]{64}',want):issues.append('The acceptance manifest contains an invalid file.');break
   file=source/rel
   if file.is_symlink() or not file.is_file() or not file.resolve().is_relative_to(source.resolve()):issues.append('A verified source file is missing: '+name);continue
   if hashlib.sha256(file.read_bytes()).hexdigest()!=want:issues.append('Source changed after verification: '+name)
  for name in ('edit.py','AGENTS.md','CLAUDE.md','Studio.html','BUILD.json','kit/VERSION','kit/execution-policy.json','README.md','.claude/settings.json','.claude/launch.json'):
   if name not in manifest:issues.append('Acceptance manifest omits required source: '+name)
  # A manifest cannot approve only a convenient subset of the implementation.
  required=set()
  for root in ('kit/editor','kit/editkit','kit/tools','kit/setup','kit/studio/app','kit/style-library','kit/styles','kit/fonts','kit/sfx','kit/skills-src','kit/docs','kit/render/package.json','kit/render/package-lock.json'):
   location=source/root
   for file in location.rglob('*') if location.is_dir() else [location]:
    if file.is_file() and file.suffix!='.pyc' and file.name!='.DS_Store' and '__pycache__' not in file.parts:required.add(file.relative_to(source).as_posix())
  for skill in (source/'kit/skills-src').rglob('*'):
   if not skill.is_file() or '__pycache__' in skill.parts or skill.suffix=='.pyc':continue
   for host in ('.agents/skills','.claude/skills'):
    clone=source/host/skill.relative_to(source/'kit/skills-src')
    required.add(clone.relative_to(source).as_posix())
    if not clone.is_file() or clone.read_bytes()!=skill.read_bytes():issues.append('Host skill differs from its verified instructions: '+clone.relative_to(source).as_posix())
  for name in sorted(required-set(manifest)):issues.append('Acceptance manifest omits implementation: '+name)
 checks=receipt.get('checks',{})
 hosts=receipt.get('release_hosts',build.get('release_hosts',['claude'])) if receipt.get('owner_release_approved') is True else build.get('release_hosts',['claude'])
 if not isinstance(hosts,list) or not hosts or any(h not in HOST_REQUIRED for h in hosts):issues.append('Declare the actual accepted release hosts.');hosts=['claude']
 required=tuple(dict.fromkeys((*COMMON_REQUIRED,*(key for host in hosts for key in HOST_REQUIRED[host]))))
 launch=read(source/'kit/style-library/launch-list.json')
 if launch:
  if any(host not in launch.get('hosts',[]) for host in hosts):issues.append('This host is not in the frozen launch scope.')
  # A hidden reference is not a claim that a reference journey passed.
  if launch.get('reference_enabled') is False:required=tuple('choices' if key=='reference_and_choices' else key for key in required)
  # Owner's release decision: two final-seal journeys plus explicit hands-on
  # approval. The earlier four remain immutable history, not a green gate.
  required=('after_final_check_2',)
  approval=receipt.get('owner_approval',{})
  if receipt.get('owner_release_approved') is not True:issues.append('The owner has not approved this exact tested candidate.')
  if not isinstance(approval,dict):approval={}
  if str(approval.get('exact_words','')).strip().lower() not in ('owner test passed','approve release'):issues.append('Record the owner\'s explicit test/release words; never infer approval.')
  try:datetime.datetime.fromisoformat(approval.get('at','').replace('Z','+00:00'))
  except (TypeError,ValueError,AttributeError):issues.append('Record the time of the owner\'s explicit approval.')
  candidate=receipt.get('candidate_sha256')
  if not isinstance(candidate,str) or not re.fullmatch('[0-9a-f]{64}',candidate) or approval.get('candidate_sha256')!=candidate:issues.append('Owner approval must match the exact tested package SHA.')
  for key in ('final_check','after_final_check'):
   link=approval.get(key,{})
   if not isinstance(link,dict):link={}
   rel=Path(link.get('evidence','..'));proof=evidence.parent/rel
   if rel.is_absolute() or '..' in rel.parts or proof.is_symlink() or not proof.is_file() or not proof.resolve().is_relative_to(evidence.parent.resolve()) or hashlib.sha256(proof.read_bytes()).hexdigest()!=link.get('sha256'):issues.append('Owner approval is missing its unchanged '+key+' record.')
   if key=='after_final_check' and isinstance(checks,dict) and any(link.get(k)!=checks.get('after_final_check_2',{}).get(k) for k in ('evidence','sha256')):issues.append('Owner approval and final journey proof differ.')
 for name in required:
  row=checks.get(name,{}) if isinstance(checks,dict) else {}
  if not isinstance(row,dict) or (row.get('passed') is not True and not (name=='after_final_check_2' and row.get('completed') is True)) or row.get('mode')!='actual':issues.append('Actual acceptance has not passed: '+name);continue
  proof=row.get('evidence')
  rel=Path(proof) if isinstance(proof,str) and proof else Path('..')
  file=evidence.parent/rel
  want=row.get('sha256')
  if rel.is_absolute() or '..' in rel.parts or file.is_symlink() or not file.is_file() or not file.resolve().is_relative_to(evidence.parent.resolve()) or not isinstance(want,str) or hashlib.sha256(file.read_bytes()).hexdigest()!=want:
   issues.append('Acceptance evidence is unavailable or changed: '+name)
  elif name in ('final_check_4','after_final_check_2'):
   gate=read(file);runs=gate.get('journeys',[]);archive=gate.get('candidate_sha256')
   expected=['claude','claude','codex','codex'] if name=='final_check_4' else ['claude','codex']
   limit=2400 if name=='final_check_4' else 2700
   valid=isinstance(runs,list) and len(runs)==len(expected) and isinstance(archive,str) and bool(re.fullmatch('[0-9a-f]{64}',archive))
   if name=='after_final_check_2' and archive!=receipt.get('candidate_sha256'):valid=False
   seen=set()
   for i,run in enumerate(runs if isinstance(runs,list) else []):
    if not isinstance(run,dict):valid=False;continue
    path=Path(run.get('result','..'));result_file=file.parent/path
    if path.is_absolute() or '..' in path.parts or result_file.is_symlink() or not result_file.is_file() or not result_file.resolve().is_relative_to(file.parent.resolve()):valid=False;continue
    if hashlib.sha256(result_file.read_bytes()).hexdigest()!=run.get('sha256'):valid=False;continue
    resolved=str(result_file.resolve())
    if resolved in seen:valid=False
    seen.add(resolved);result=read(result_file);media=result.get('media',{});timings=media.get('timings',{})
    elapsed=timings.get('make_to_download',timings.get('install_or_clone_to_download',0))
    media_checks=media.get('checks',{})
    # A6 explicitly accepts slowness. Preserve raw FAIL, and admit only a
    # completely checked time-only overrun, never a missing/incorrect output.
    complete=('browser_controls_completed','no_technical_dom_text','host_start_instruction_correct','v1_v2_preserved','v1_1080x1920','v1_audio_stream','v1_playable_duration','v1_audible','v1_hash_is_actual','v2_1080x1920','v2_audio_stream','v2_playable_duration','v2_audible','v2_hash_is_actual','studio_note_applied_to_v2','download_matches_v2','reference_use_recorded','real_media_review_recorded')
    slow=name=='after_final_check_2' and run.get('accepted_time_overrun') is True and result.get('passed') is False and media.get('passed') is False and media.get('blocker')=='journey_finishes_within_45_minutes' and media_checks.get('journey_finishes_within_45_minutes') is False and all(media_checks.get(k) is True for k in complete) and all(v is True for k,v in media_checks.items() if k!='journey_finishes_within_45_minutes')
    if (result.get('passed') is not True and not slow) or i>=len(expected) or result.get('host')!=expected[i] or result.get('package_sha256')!=archive or not result.get('v1') or not result.get('v2'):valid=False
    if (media.get('passed') is not True and not slow) or not isinstance(elapsed,(int,float)) or not 0<elapsed or (elapsed>limit and not slow):valid=False
    if result.get('permission_denials') or result.get('technical_chat_text_hits') or result.get('manual_help'):valid=False
    if result.get('host_start_instruction_correct') is not True:valid=False
    if not all(media_checks.get(key) is True for key in ('v1_v2_preserved','download_matches_v2','real_media_review_recorded')):valid=False
    if name=='after_final_check_2' and result.get('reference_added') is not True:valid=False
   if not valid:issues.append('The actual '+name+' journeys have not all passed on their recorded candidate.')
 return issues
