"""Evidence-based editing milestones, not elapsed time or a completion ETA."""
import math
from pathlib import Path
from . import util

def measure(p,job,activity=None):
    if not job:return {}
    activity=activity or {}
    try:created=float(job.get('created') or 0)
    except (TypeError,ValueError):created=float('nan')
    if not math.isfinite(created) or created<0:created=__import__('time').time()
    def doc(name):
        try:
            d=util.read_json(p/name,default={});return d if isinstance(d,dict) else {}
        except (OSError,ValueError,util.Fail):return {}
    def modified(name):
        try:return (p/name).stat().st_mtime
        except OSError:return None
    def fresh(name):
        stamp=modified(name)
        return stamp is not None and stamp>=created
    source=doc('source.json');request=doc('active-edit-request.json')
    settings=request.get('settings') if isinstance(request.get('settings'),dict) else {}
    media=settings.get('media') if isinstance(settings.get('media'),list) else []
    captured=[str((util.ROOT/m['file']).resolve()) for m in media if isinstance(m,dict) and m.get('kind')=='raw' and isinstance(m.get('file'),str)]
    source_path=str(Path(source['path']).resolve()) if isinstance(source.get('path'),str) and source['path'] else ''
    direct=bool(len(captured)==1 and source_path==captured[0])
    joined=bool(len(captured)>1 and source_path==str((p/'media/joined.mp4').resolve()) and source.get('inputs')==captured)
    source_ok=direct or joined

    transcript=doc('transcript.json');words=transcript.get('words')
    no_audio=source.get('has_audio') is False and transcript.get('speech_status')=='not_applicable_no_audio' and isinstance(words,list) and not words and isinstance(transcript.get('source_sha256'),str) and len(transcript['source_sha256'])==64
    transcript_stamp,source_stamp=modified('transcript.json'),modified('source.json')
    transcript_ok=bool(source_ok and isinstance(words,list) and (words or no_audio) and transcript_stamp is not None and source_stamp is not None and transcript_stamp>=source_stamp)
    scene=doc('scene-plan.json');plan=doc('edit-plan.json')
    plan_ok=bool(transcript_ok and fresh('scene-plan.json') and fresh('edit-plan.json') and scene.get('scenes') and plan)
    candidate=doc('render/candidate.json')
    rendered=bool(plan_ok and candidate.get('sha256') and type(candidate.get('created')) in (int,float) and candidate['created']>=created and fresh('render/candidate.json'))
    review=doc('render/release-review.json')
    reviewed=bool(rendered and fresh('render/release-review.json') and review.get('candidate_sha256')==candidate.get('sha256'))
    done=job.get('state')=='succeeded'
    checks=[('Footage prepared',source_ok,10),('Audio checked' if no_audio else 'Speech transcribed',transcript_ok,15),('Edit designed',plan_ok,20),('Video rendered',rendered,40),('Video reviewed',reviewed,10),('Video saved',done,5)]
    percent=sum(weight for _,ok,weight in checks if ok)
    tool=activity.get('percent')
    render_activity=str(activity.get('detail') or '').startswith(('Drawing every frame','Encoding','Adding the sound','Rendering','Exporting in full quality'))
    if render_activity and plan_ok and not rendered and activity.get('project')==p.name and activity.get('running') and not activity.get('waiting_resources') and activity.get('cmd') in ('render','compose') and type(tool) in (int,float) and math.isfinite(tool):
        percent+=40*max(0,min(100,tool))/100
    return {'percent':100 if done else min(95,round(percent)), 'basis':'completed_milestones', 'completed':sum(bool(ok) for _,ok,_ in checks), 'total':len(checks), 'steps':[{'label':label,'done':bool(ok)} for label,ok,_ in checks]}
