"""Adjust only rendered caption containers, preserving each recipe's text/font/timing."""
from html.parser import HTMLParser
from pathlib import Path
import math,json
from . import util

def normalized(caps):
 out={}
 for key,lo,hi in [('size',40,140),('y',.45,.8)]:
  if key in caps:
   value=caps[key]
   if type(value) not in (int,float) or not math.isfinite(value) or not lo<=value<=hi:raise util.Fail('Choose a supported caption '+key+' in Adjust, then retry.')
   out[key]=value
 if 'uppercase' in caps:
  if type(caps['uppercase']) is not bool:raise util.Fail('Choose All caps on or off.')
  out['uppercase']=caps['uppercase']
 if caps.get('mode'):raise util.Fail('This caption animation is part of its selected recipe. Choose the caption style again to reset the old animation override.')
 return out

class Containers(HTMLParser):
 def __init__(self,text):
  super().__init__(convert_charrefs=False);self.text=text;self.lines=text.splitlines(keepends=True);self.offsets=[0]
  for line in self.lines:self.offsets.append(self.offsets[-1]+len(line))
  self.stack=[];self.spans=[]
 def position_offset(self):line,col=self.getpos();return self.offsets[line-1]+col
 def handle_starttag(self,tag,attrs):
  if tag=='div':self.stack.append((dict(attrs).get('id'),self.position_offset()))
 def handle_endtag(self,tag):
  if tag=='div' and self.stack:
   ident,start=self.stack.pop()
   if ident in ('caps','caption-back'):self.spans.append((start,self.position_offset()+len('</div>')))

def apply(workspace,caps):
 settings=normalized(caps);file=Path(workspace)/'index.html';text=file.read_text();parser=Containers(text);parser.feed(text)
 if settings and not parser.spans:raise util.Fail('This recipe has no supported caption layer. Choose a caption style in Studio before adjusting it.')
 scale=settings.get('size',80)/80;shift=(settings.get('y',.66)-.66)*1920
 css=f'position:absolute;inset:0;transform:translateY({shift:.3f}px) scale({scale:.5f});transform-origin:540px 1267px;'
 if settings.get('uppercase') is True:css+='text-transform:uppercase;'
 for start,end in sorted(parser.spans,reverse=True):text=text[:start]+'<div class="creatorcut-caption-adjust" style="'+css+'">'+text[start:end]+'</div>'+text[end:]
 # The wrapper keeps GSAP transforms on the original ids independent of this adjustment.
 file.write_text(text);util.write_json(Path(workspace)/'caption-adjust.json',settings)
 return settings
