"""First draft of an edit plan from a style kit: the mechanical part, done the same way every time.

It applies the reference's measured rules to the creator's transcript and footage:
  - one caption size per shot, alternating between the reference's sizes across cuts (with a punch-in zoom)
  - words per caption as in the reference (mostly 1, sometimes 2 for short words)
  - the hinge word of each sentence in the accent style
  - captions placed relative to the creator's face (the reference's distance below the chin), never on the face
The agent then makes the creative calls on top (notes, cards, bursts, custom graphics) and runs the checks."""
from __future__ import annotations

import re
import statistics as stx
from pathlib import Path

from . import stylekit, util

SHORT = set("a an and are as at be but by do for from if in is it of on or so the to up we i you my our".split())


def face_box(video: Path) -> tuple[float, float, float, float] | None:
    """Median face box (x, y, w, h as fractions) over the clip."""
    import cv2
    import numpy as np
    face = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    cap = cv2.VideoCapture(str(video))
    dur = (cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0) / (cap.get(cv2.CAP_PROP_FPS) or 30)
    boxes = []
    for t in np.linspace(0.5, max(0.6, dur - 0.5), 18):
        cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
        ok, fr = cap.read()
        if not ok:
            continue
        g = cv2.cvtColor(fr, cv2.COLOR_BGR2GRAY)
        fs = face.detectMultiScale(g, 1.1, 5, minSize=(g.shape[1] // 12, g.shape[1] // 12))
        if len(fs):
            x, y, w, h = max(fs, key=lambda f: f[2])
            boxes.append((x / g.shape[1], y / g.shape[0], w / g.shape[1], h / g.shape[0]))
    cap.release()
    if not boxes:
        return None
    return tuple(stx.median(b[i] for b in boxes) for i in range(4))


def draft(project: Path, kit: dict, ref_face_h: float = 0.10, ref_below_chin: float = 0.9, hook: bool = True) -> dict:
    wj = util.read_json(project / "words.json")
    words, dur = wj["words"], wj["duration"]
    segs = util.read_json(project / "segments.json", default={"segments": []})["segments"]
    cuts = [s["start"] for s in segs[1:]] if segs else []
    fb = face_box(project / "cut.mp4")
    styles = kit["styles"]
    by_role = sorted(styles.items(), key=lambda kv: -kv[1]["count"])
    # the main caption style is the one the reference uses most, whatever its colour (an icy blue stays icy blue)
    caps_ = [(k, s) for k, s in by_role if s["role"] == "caption"] or by_role
    body = next((k for k, s in caps_ if s["size_class"] == "body"), caps_[0][0])

    def _rgb(c):
        c = (c or "#ffffff").lstrip("#")
        return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4)) if len(c) == 6 else (255, 255, 255)

    def _same_look(a, b):                     # two measurements of one style (OCR colour/size noise)
        ca, cb = _rgb(styles[a]["colour"]), _rgb(styles[b]["colour"])
        light = min(sum(ca), sum(cb)) > 600
        near = sum(abs(x - y) for x, y in zip(ca, cb)) < 140
        return (light or near) and abs(styles[a].get("y", 0.5) - styles[b].get("y", 0.5)) < 0.06 and \
            0.75 < styles[a]["size"] / max(1e-6, styles[b]["size"]) < 1.33
    big = next((k for k, s in caps_ if s["size_class"] == "big" and s["colour_family"] == styles[body]["colour_family"]), body)
    # an accent only when the reference really has one: a clearly different colour used for some words, not a duplicate
    accent = next((k for k, s in caps_ if k != body and not _same_look(k, body) and s["colour_family"] != styles[body]["colour_family"]
                   and s["count"] <= styles[body]["count"]), None)
    # size: the reference's frame-relative size, scaled up a little for tighter framing (capped so it stays tasteful)
    scale = 1.0
    if fb:
        scale = max(1.0, min(1.3, (fb[3] / ref_face_h) ** 0.35))
    sizes = {k: round(s["size"] * scale, 4) for k, s in styles.items()}
    y = 0.62
    if fb:
        chin = fb[1] + fb[3]
        y = min(0.76, max(chin + 0.06, chin + fb[3] * ref_below_chin * 0.55))
        rf, ry = kit.get("face"), (kit.get("captions") or {}).get("y_median")
        if rf and ry is not None:                  # where the reference puts captions, measured in face heights from its face
            rchin = rf[1] + rf[3]
            if ry >= rchin:                        # below the chin (chest, waist): same distance in face heights
                y = chin + (ry - rchin) / max(rf[3], 1e-3) * fb[3]
            elif ry <= rf[1]:                      # above the head: same gap above the forehead
                y = fb[1] - (rf[1] - ry) / max(rf[3], 1e-3) * fb[3]
            y = min(0.8, max(0.1, y))
            if fb[1] - 0.02 < y < chin + 0.04:     # never across the face
                y = chin + 0.06
    # legibility: where the background behind text is bright (white walls), the soft shadow gets stronger
    bright_top, bright_cap = _brightness(project / "cut.mp4", 0.15), _brightness(project / "cut.mp4", y)
    plan_styles = {}
    for name, sid in (("caption", body), ("big", big), ("accent", accent)):
        if sid is None:
            continue
        s = styles[sid]
        plan_styles[name] = {"font": name, "size": sizes[sid], "colour": s["colour"], "case": s["case"], "tracking": s.get("tracking", -.035), "line": s.get("line", .96),
                             "shadow": 0.5 if bright_cap > 0.62 else 0.28}
    plan_styles_top_shadow = 0.55 if bright_top > 0.62 else 0.3
    fonts = {name: styles[sid]["font"] for name, sid in (("caption", body), ("big", big), ("accent", accent)) if sid}
    # blocks: as many words as the reference shows at once (measured), never across a sentence end or a cut
    capm = (kit.get("blueprint") or {}).get("captions") or {}
    per_block = int(capm.get("words") or 1)
    build = bool(capm.get("build"))
    n_lines = int(capm.get("lines") or 1)
    if build and per_block > 4:
        n_lines = max(n_lines, 2)                    # long building blocks wrap onto two lines, like the reference
    blocks, cur = [], []
    for i, w in enumerate(words):
        cur.append(w)
        nxt = words[i + 1] if i + 1 < len(words) else None
        end = w["w"].rstrip().endswith((".", "!", "?"))
        comma = w["w"].rstrip().endswith((",", ":", ";"))
        cut_between = nxt and any(w["end"] <= c <= nxt["start"] + 0.01 for c in cuts)
        if per_block <= 2:
            short = re.sub(r"\W", "", w["w"].lower()) in SHORT and len(cur) == 1 and nxt and not (end or comma)
            close = not short or end or comma or len(cur) >= 2
        else:
            close = end or len(cur) >= per_block or (comma and len(cur) >= max(2, per_block // 2))
        if close or cut_between or nxt is None:
            blocks.append(cur); cur = []
    if cur:
        blocks.append(cur)
    # sentence keywords -> accent style
    sentence, accents = [], set()
    for b in blocks:
        sentence.extend(b)
        if b[-1]["w"].rstrip().endswith((".", "!", "?")) or b is blocks[-1]:
            k = stylekit.keyword([w["w"] for w in sentence])
            if k is not None:
                accents.add(id(sentence[k]))
            sentence = []
    shot_of = lambda t: sum(1 for c in cuts if c <= t)
    items, zooms = [], []
    for n, b in enumerate(blocks):
        t0 = b[0]["start"]
        t1 = blocks[n + 1][0]["start"] if n + 1 < len(blocks) else min(dur, b[-1]["end"] + 0.4)
        if n + 1 >= len(blocks):
            t1 = max(t1, t0 + 0.18)
        shot = shot_of(t0)
        base = "big" if shot % 2 == 1 and "big" in plan_styles else "caption"
        ws = []
        for w in b:
            st = "accent" if id(w) in accents and accent else base
            ws.append({"w": w["w"].strip().lower() if plan_styles[base]["case"] == "lower" else w["w"].strip(), "t": w["start"], "style": st})
        a = styles[big if base == "big" else body]["anim"]
        if build:                                     # words revealed in place, one by one: a hard cut, never a bounce
            a = dict(a, ease="cut", scale_from=1.0, dy_from=0.0)
        it = {"type": "caption", "t0": round(t0, 3), "t1": round(t1, 3), "x": 0.5, "y": round(y, 3), "words": ws,
              "anim": {"ease": a["ease"], "scale_from": a["scale_from"], "dy_from": a["dy_from"], "ms": a["ms"], "opacity_from": 1 if a["ease"] == "cut" else 0}}
        if build and len(ws) > 1:
            it["reveal"] = "word"                       # the reference builds each caption word by word
        if n_lines >= 2 and len(ws) >= 4:
            half = (len(ws) + 1) // 2
            it["lines"] = [list(range(0, half)), list(range(half, len(ws)))]
        items.append(it)
    # the hook: the first sentence set big, like the reference's opening, where the background is dark enough to
    # read (top if the top is darker, else below the chin); regular captions pause while it's on screen
    hook_words, k = [], 0
    while k < len(words) and len(hook_words) < 9:
        nxt = re.sub(r"\W", "", words[k]["w"].lower())
        if len(hook_words) >= 4 and nxt in ("and", "but", "so", "because", "then"):
            break                                   # end on a natural break, never mid-thought
        hook_words.append(words[k])
        if words[k]["w"].rstrip().endswith((".", "!", "?", ",")) and len(hook_words) >= 3:
            break
        k += 1
    if hook and "big" in plan_styles and len(hook_words) >= 3:
        acc_i = stylekit.keyword([w["w"] for w in hook_words])
        n = len(hook_words)
        per = 3 if n > 4 else 2
        lines = [list(range(j, min(n, j + per))) for j in range(0, n, per)]
        hy = 0.15 if bright_top < 0.72 or not fb else min(0.8, y + 0.04)
        h0, h1 = hook_words[0]["start"], min(dur, hook_words[-1]["end"] + 0.35)
        plan_styles["hook"] = dict(plan_styles["big"], size=round(min(0.09, max(0.06, plan_styles["big"]["size"] * 0.66)), 4), line=0.98,
                                   shadow=max(plan_styles["big"]["shadow"], plan_styles_top_shadow if hy < 0.3 else 0.3))
        if "accent" in plan_styles:
            plan_styles["hook_accent"] = dict(plan_styles["accent"], size=round(min(0.105, max(0.07, plan_styles["accent"]["size"] * 0.7)), 4),
                                              line=0.98, shadow=plan_styles["hook"]["shadow"])
        fonts["hook"] = fonts["big"]
        if "accent" in fonts:
            fonts["hook_accent"] = fonts["accent"]
        ws = [{"w": w["w"].strip().lower() if plan_styles["big"]["case"] == "lower" else w["w"].strip(), "t": w["start"],
               "style": "hook_accent" if (j == acc_i and "hook_accent" in plan_styles) else "hook"} for j, w in enumerate(hook_words)]
        items = [i for i in items if i["t1"] <= h0 + 0.01 or i["t0"] >= h1 - 0.01]
        items.append({"type": "caption", "role": "hook", "t0": round(h0, 3), "t1": round(h1, 3), "x": 0.5, "y": hy, "lines": lines,
                      "words": ws, "reveal": "word", "anim": {"ease": "pop", "scale_from": 0.95, "dy_from": 0.005, "ms": 90, "opacity_from": 0}})
    edges = [0.0] + cuts + [dur]
    zoom_ok = (kit.get("blueprint") or {}).get("zoom", float(kit.get("cuts_per_minute") or 30) >= 12)
    for k in range(len(edges) - 1):
        if k % 2 == 1 and zoom_ok:                  # punch-ins hide jump cuts; a calm reference has none
            zooms.append({"t0": edges[k], "t1": edges[k + 1], "scale": float((kit.get("blueprint") or {}).get("zoom_scale") or 1.12),
                          "x": 0.5, "y": (fb[1] + fb[3] / 2) if fb else 0.4})
    from . import library
    if library.choices(project).get('caption')=='none':items=[i for i in items if i.get('type')!='caption']
    return {"duration": dur, "canvas": {"w": 1080, "h": 1920, "fps": 30},
            "background": {"src": "cut.mp4", "zooms": zooms}, "fonts": fonts, "styles": plan_styles, "items": items,
            "_facts": {"face": fb, "caption_y": y, "size_scale": round(scale, 2), "cuts": cuts,
                       "background_brightness": {"top": round(bright_top, 2), "captions": round(bright_cap, 2)},
                       "top_text_shadow": plan_styles_top_shadow}}


def behind_y(video: Path, face, size: float, lines: int) -> float:
    """Where a block of text sits so it passes *behind* the head but stays readable: its last line overlaps the top
    of the head by about a third of a line, the rest is above (the look in references, without hiding the words)."""
    if not face:
        return 0.2
    block = size * 1.0 * lines
    head_top = face[1] - face[3] * 0.18            # hair above the face box
    return round(max(0.08 + block / 2, head_top - block / 2 + size * 0.35), 3)


def _brightness(video: Path, y: float, band: float = 0.12) -> float:
    """Mean brightness (0-1) of a horizontal band of the frame around height y, over the clip."""
    import cv2
    import numpy as np
    cap = cv2.VideoCapture(str(video))
    n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    vals = []
    for k in range(8):
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(n * (k + 0.5) / 8))
        ok, fr = cap.read()
        if ok:
            h = fr.shape[0]
            vals.append(float(cv2.cvtColor(fr[int(max(0, y - band / 2) * h):int(min(1, y + band / 2) * h)], cv2.COLOR_BGR2GRAY).mean()) / 255)
    cap.release()
    return float(np.median(vals)) if vals else 0.5
