"""Style DNA: frame-by-frame study of a reference video.

Reads the reference at 10 frames per second (first 60 s) and measures what the quick pass in teach.py can't:

  zooms       scale change between frames (ORB features + RANSAC): punch-in size at cuts, slow push-ins within shots
  b-roll      shots with no face while the person keeps talking = cutaways (Haar face detector)
  captions    when captions change (≈ words per caption), how they enter (pop / slide / reveal / highlight),
              upper or mixed case, and the closest font in our library (glyph shape statistics)
  colour      a custom grade: brightness, contrast, saturation and warmth relative to a neutral image
  audio       tempo (beats per minute) and integrated loudness
  structure   hook (first sentence), call to action (last sentence asking for something)

Everything here is a measurement. The agent looks at the contact sheet and makes the final call."""
from __future__ import annotations

import re
from collections import Counter
from pathlib import Path

from . import util

FPS = 10
MAX_SECONDS = 60


def _frames(src: Path):
    """Yield (t, bgr_frame) at ~10 fps, resized to 360 px wide."""
    import cv2
    cap = cv2.VideoCapture(str(src))
    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    step = max(1, int(round(fps / FPS)))
    i = 0
    while True:
        ok = cap.grab()
        if not ok:
            break
        if i % step == 0:
            ok, fr = cap.retrieve()
            if not ok:
                break
            t = i / fps
            if t > MAX_SECONDS:
                break
            h, w = fr.shape[:2]
            fr = cv2.resize(fr, (360, int(h * 360 / w)))
            yield t, fr
        i += 1
    cap.release()


def _scale_between(a, b, orb, bf) -> float | None:
    """Relative scale from frame a to frame b (1.10 = b is zoomed in 10%)."""
    import cv2
    import numpy as np
    ka, da = orb.detectAndCompute(a, None)
    kb, db = orb.detectAndCompute(b, None)
    if da is None or db is None or len(ka) < 12 or len(kb) < 12:
        return None
    matches = bf.match(da, db)
    if len(matches) < 12:
        return None
    pa = np.float32([ka[m.queryIdx].pt for m in matches])
    pb = np.float32([kb[m.trainIdx].pt for m in matches])
    M, inl = cv2.estimateAffinePartial2D(pa, pb, method=cv2.RANSAC, ransacReprojThreshold=3.0)
    if M is None or inl is None or inl.sum() < 10:
        return None
    return float(np.sqrt(M[0, 0] ** 2 + M[1, 0] ** 2))


def _band(gray, region=None):
    """Caption band rows (top, bottom) by density of strong horizontal edges, or None. `region` (top, bottom
    fractions from _caption_region) keeps the search where the captions actually are."""
    import numpy as np
    h = gray.shape[0]
    g = gray.astype(np.float32) / 255.0
    edge = (np.abs(np.diff(g, axis=1)) > 0.35).mean(axis=1)
    r0, r1 = region or (0.06, 0.92)
    edge[: int(h * r0)] = 0
    edge[int(h * r1):] = 0
    if edge.max() < 0.04:
        return None
    sm = np.convolve(edge, np.ones(7) / 7, mode="same")
    peak = int(sm.argmax())
    thr = sm[peak] * 0.45
    top, bot = peak, peak
    while top > 0 and sm[top - 1] > thr:
        top -= 1
    while bot < h - 1 and sm[bot + 1] > thr:
        bot += 1
    return top, bot


def _text_mask(crop_gray):
    """Bright text pixels inside a caption crop (white or coloured fill with dark outline)."""
    import cv2
    _, m = cv2.threshold(crop_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    if m.mean() > 127:          # text darker than background: invert
        m = 255 - m
    return m


def _glyph_stats(mask) -> dict | None:
    """Shape statistics of the letters in a binary text mask: width/height (condensed vs wide), stroke
    thickness relative to letter height (weight), ink fill, slant (italic) and how many letters reach the full
    letter height (all caps ≈ 1, lowercase ≈ 0.3–0.5 because x-height letters are shorter)."""
    import cv2
    import numpy as np
    n, lab, st, _ = cv2.connectedComponentsWithStats(mask, 8)
    comps = [i for i in range(1, n) if st[i][cv2.CC_STAT_HEIGHT] > mask.shape[0] * 0.18 and st[i][cv2.CC_STAT_AREA] > 12]
    if len(comps) < 3:
        return None
    hs = np.array([st[i][cv2.CC_STAT_HEIGHT] for i in comps], dtype=float)
    ws = np.array([st[i][cv2.CC_STAT_WIDTH] for i in comps], dtype=float)
    areas = np.array([st[i][cv2.CC_STAT_AREA] for i in comps], dtype=float)
    top = float(np.percentile(hs, 90))
    tall = hs >= top * 0.8
    dist = cv2.distanceTransform(mask, cv2.DIST_L2, 3)
    stroke = float(np.median(dist[dist > 0]) * 2) if (dist > 0).any() else 1.0
    slants = []
    for i in comps:
        ys, xs = np.where(lab == i)
        if len(ys) > 20:
            yc, xc = ys - ys.mean(), xs - xs.mean()
            v = float((yc * yc).mean())
            if v > 0:
                slants.append(-float((xc * yc).mean()) / v)
    H = float(np.median(hs[tall])) if tall.any() else top
    # stroke contrast: thick vs thin parts of the letters (serif and display fonts ≈ 2+, plain sans ≈ 1.2-1.5)
    ridge = (dist >= cv2.dilate(dist, np.ones((3, 3), np.uint8))) & (dist > 0.8)
    rv = dist[ridge]
    contrast = float(np.percentile(rv, 85) / max(np.percentile(rv, 35), 0.5)) if rv.size > 20 else 1.4
    return {"contrast": contrast,"aspect": float(np.median(ws[tall] / hs[tall])) if tall.any() else float(np.median(ws / hs)),
            "weight": stroke / max(H, 1), "fill": float(np.median(areas / (ws * hs))),
            "caps": float(tall.mean()), "slant": float(np.median(slants)) if slants else 0.0}


def _letters(crop_bgr, colour: str = "white"):
    """Mask of caption letters in a crop: bright glyphs that don't touch the crop edge (backgrounds do).
    colour "white" keeps the unsaturated fill, "accent" the saturated highlight words, "any" both."""
    import cv2
    import numpy as np
    hsv = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2HSV)
    v, s = hsv[..., 2] / 255.0, hsv[..., 1] / 255.0
    bright = v > 0.72
    want = bright & (s < 0.35) if colour == "white" else bright & (s >= 0.4) if colour == "accent" else bright
    m = want.astype(np.uint8) * 255
    n, lab, st, _ = cv2.connectedComponentsWithStats(m, 8)
    ch, cw = m.shape
    keep = [i for i in range(1, n) if st[i][4] > 15 and st[i][0] > 0 and st[i][1] > 0
            and st[i][0] + st[i][2] < cw and st[i][1] + st[i][3] < ch and st[i][4] < ch * cw * 0.2]
    return (np.isin(lab, keep).astype(np.uint8) * 255) if keep else None


_FONT_STATS: dict = {}


def _font_stats(key: str, upper: bool, text: str = "") -> dict | None:
    from PIL import Image, ImageDraw, ImageFont
    import numpy as np
    cache_key = (key, upper, text)
    if cache_key in _FONT_STATS:
        return _FONT_STATS[cache_key]
    from . import styles as st
    f = st.FONTS.get(key)
    if not f or not (util.FONTS_DIR / f["file"]).exists():
        return None
    text = text or "the best edits save hours"
    text = text.upper() if upper else text.lower()
    font = ImageFont.truetype(str(util.FONTS_DIR / f["file"]), 64)
    im = Image.new("L", (64 * max(8, len(text)) + 40, 140), 0)
    ImageDraw.Draw(im).text((20, 24), text, font=font, fill=255)
    stats = _glyph_stats(np.array(im))
    _FONT_STATS[cache_key] = stats
    return stats


_GLYPHS: dict = {}
G = 28


def _norm_glyph(m):
    """A letter mask cropped to its box, padded square (keeps its proportions) and scaled to G×G."""
    import cv2
    import numpy as np
    ys, xs = np.where(m > 0)
    if len(ys) < 8:
        return None
    c = m[ys.min(): ys.max() + 1, xs.min(): xs.max() + 1]
    h, w = c.shape
    n = max(h, w)
    sq = np.zeros((n, n), np.uint8)
    sq[(n - h) // 2:(n - h) // 2 + h, (n - w) // 2:(n - w) // 2 + w] = c
    return (cv2.resize(sq, (G, G), interpolation=cv2.INTER_AREA) > 96).astype(np.float32).ravel()


def _font_glyphs(key: str, upper: bool):
    """Every letter of a font, rendered and normalised like the letters found in a reference."""
    import numpy as np
    from PIL import Image, ImageDraw, ImageFont
    from . import styles as st
    ck = (key, upper)
    if ck in _GLYPHS:
        return _GLYPHS[ck]
    f = st.FONTS.get(key)
    if not f or not (util.FONTS_DIR / f["file"]).exists():
        return None
    font = ImageFont.truetype(str(util.FONTS_DIR / f["file"]), 72)
    out = []
    for ch in ("ABCDEFGHIJKLMNOPRSTUVWY" if upper else "abcdefghkmnoprstuvwy"):   # skip i/j/l: too simple to tell fonts apart
        im = Image.new("L", (140, 140), 0)
        ImageDraw.Draw(im).text((30, 20), ch, font=font, fill=255)
        g = _norm_glyph(np.array(im))
        if g is not None:
            out.append(g)
    _GLYPHS[ck] = np.array(out) if out else None
    return _GLYPHS[ck]


def _letter_masks(masks: list) -> list:
    """Single letters cut from caption masks (connected parts with a letter-like size)."""
    import cv2
    out = []
    for m in masks:
        if m is None:
            continue
        n, lab, st, _ = cv2.connectedComponentsWithStats(m, 8)
        hs = [st[i][3] for i in range(1, n)]
        if not hs:
            continue
        top = sorted(hs)[int(len(hs) * 0.9)]
        for i in range(1, n):
            x, y, w, h, a = st[i]
            if h >= top * 0.45 and a > 30 and 0.2 < w / max(h, 1) < 1.6:
                g = _norm_glyph((lab[y:y + h, x:x + w] == i).astype("uint8") * 255)
                if g is not None:
                    out.append(g)
    return out[:240]


def _glyph_score(letters, glyphs) -> float:
    """How well a font's letters explain the observed ones: mean over observed letters of the best IoU."""
    import numpy as np
    if glyphs is None or not len(letters):
        return 0.0
    L = np.array(letters)
    inter = L @ glyphs.T
    union = L.sum(1, keepdims=True) + glyphs.sum(1)[None, :] - inter
    return float(np.mean(np.max(inter / np.maximum(union, 1), axis=1)))


def match_font(masks: list, upper: bool, text: str = "", accent: bool = False) -> list[dict]:
    """Closest fonts in the library to the caption letters (top 3 with a confidence 0-1). `masks` are letter
    masks from _letters(); `text` is what was being said (rendered in each font, so like is compared with like)."""
    import numpy as np
    from . import styles as st
    obs = [s for s in (_glyph_stats(m) for m in masks if m is not None) if s]
    if not obs:
        return []
    o = {k: float(np.median([s[k] for s in obs])) for k in ("aspect", "weight", "fill", "slant", "contrast")}
    letters = _letter_masks(masks)
    scored, scored_g = [], {}
    for key in st.FONTS:
        if not accent and key.startswith(("lora-italic", "instrument-serif-italic")):
            continue
        fs = _font_stats(key, upper, text)
        if not fs:
            continue
        g = _glyph_score(letters, _font_glyphs(key, upper))
        d = ((1 - g) / 0.03) ** 2 + 0.25 * (((o["aspect"] - fs["aspect"]) / 0.15) ** 2 + ((o["weight"] - fs["weight"]) / 0.04) ** 2
             + ((o["fill"] - fs["fill"]) / 0.12) ** 2 + ((o["slant"] - fs["slant"]) / 0.08) ** 2
             + ((o["contrast"] - fs["contrast"]) / 0.18) ** 2)
        scored_g[key] = g
        scored.append((d, key))
    scored.sort()
    return [{"key": k, "label": st.FONTS[k].get("label") or st.FONTS[k]["ass"], "confidence": round(scored_g.get(k, 0.0), 2)}
            for d, k in scored[:3]]


def _tempo(src: Path) -> float | None:
    """Rough music tempo from the onset envelope's autocorrelation (60-180 bpm)."""
    try:
        import numpy as np
        from .teach import _audio_pcm
        x = _audio_pcm(src)
        if x is None or len(x) < 16000 * 6:
            return None
        hop = 256
        n = len(x) // hop
        env = np.sqrt((x[: n * hop].reshape(n, hop) ** 2).mean(axis=1))
        on = np.maximum(0, np.diff(env))
        on = on - on.mean()
        ac = np.correlate(on, on, mode="full")[len(on) - 1:]
        fps = 16000 / hop
        lo, hi = int(fps * 60 / 180), int(fps * 60 / 60)
        if hi >= len(ac):
            return None
        lag = lo + int(np.argmax(ac[lo:hi]))
        return round(60 * fps / lag)
    except Exception:
        return None


def _loudness(src: Path) -> float | None:
    p = util.run([util.ffmpeg_bin(), "-hide_banner", "-i", str(src), "-vn", "-af", "ebur128", "-f", "null", "-"], check=False)
    m = re.findall(r"I:\s+(-?[0-9.]+) LUFS", p.stderr or "")
    return float(m[-1]) if m else None


def custom_grade(c: dict) -> dict:
    """An FFmpeg colour grade that moves neutral footage towards the reference's colour."""
    b = (c.get("brightness") or 0.5) - 0.5
    s = c.get("saturation") or 0.3
    k = c.get("contrast") or 0.45
    t = c.get("temperature") or 0.04
    eq = {"brightness": round(max(-0.06, min(0.06, b * 0.18)), 3), "contrast": round(max(0.9, min(1.18, 1 + (k - 0.45) * 0.6)), 3),
          "saturation": round(max(0.75, min(1.35, 1 + (s - 0.32) * 1.2)), 3)}
    warm = round(max(-0.05, min(0.05, (t - 0.04) * 0.25)), 3)
    filt = (f"eq=brightness={eq['brightness']}:contrast={eq['contrast']}:saturation={eq['saturation']},"
            f"colorbalance=rm={warm}:bm={-warm}:rh={warm / 2}:bh={-warm / 2}")
    return {"filter": filt, **eq, "warmth": warm}


def _edge_profile(gray):
    """Per-row density of strong horizontal edges (text is dense in edges)."""
    import numpy as np
    g = gray.astype(np.float32) / 255.0
    return (np.abs(np.diff(g, axis=1)) > 0.35).mean(axis=1)


def _caption_region(profiles: list, cuts: set) -> tuple[float, float] | None:
    """Rows where the edge pattern keeps changing inside a shot: captions swap every few words, while
    backgrounds, sofas and static notes stay put. Returns (top, bottom) as fractions of the frame height."""
    import numpy as np
    if len(profiles) < 10:
        return None
    acc, n = None, 0
    for (t0, p0), (t1, p1) in zip(profiles, profiles[1:]):
        if t1 in cuts:
            continue
        d = np.abs(p1 - p0)
        acc = d if acc is None else acc + d
        n += 1
    if not n:
        return None
    e = np.convolve(acc / n, np.ones(9) / 9, mode="same")
    h = len(e)
    e[: int(h * 0.06)] = 0
    e[int(h * 0.94):] = 0
    if e.max() <= 0:
        return None
    peak = int(e.argmax())
    thr = e[peak] * 0.3
    top, bot = peak, peak
    while top > 0 and e[top - 1] > thr:
        top -= 1
    while bot < h - 1 and e[bot + 1] > thr:
        bot += 1
    pad = int(h * 0.03)
    return max(0, top - pad) / h, min(h - 1, bot + pad) / h


def analyze(src: Path, words: list[dict], frames_dir: Path, progress=None) -> dict:
    """Frame-by-frame measurements for one reference video."""
    import cv2
    import numpy as np
    say = progress or (lambda *_: None)
    say("Reading every frame…", 0.6)
    orb = cv2.ORB_create(500)
    bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    face = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    prev_gray = prev_hist = prev_small = None
    scales, diffs, hard, faces, profiles = {}, [], set(), [], []
    total = max(0.1, min(MAX_SECONDS, util.probe(src)["duration"]))
    for t, fr in _frames(src):
        if len(profiles) % 40 == 0:
            say(f"Reading every frame… {min(100, round(t / total * 100))}%", 0.6 + 0.2 * min(1.0, t / total))
        gray = cv2.cvtColor(fr, cv2.COLOR_BGR2GRAY)
        hist = cv2.calcHist([fr], [0, 1, 2], None, [8, 8, 8], [0, 256] * 3).flatten()
        hist /= hist.sum() + 1e-9
        small = cv2.resize(gray, (48, 85)).astype(np.float32)
        if prev_gray is not None:
            if float(np.minimum(hist, prev_hist).sum()) < 0.55:
                hard.add(t)
            diffs.append((t, float(np.abs(small - prev_small).mean())))
            sc = _scale_between(prev_gray, gray, orb, bf)
            if sc:
                scales[t] = sc
        if int(round(t * FPS)) % 5 == 0:   # faces twice a second
            fs = face.detectMultiScale(gray, 1.15, 4, minSize=(36, 36))
            faces.append((t, len(fs) > 0))
        profiles.append((t, _edge_profile(gray)))
        prev_gray, prev_hist, prev_small = gray, hist, small

    # cuts: hard colour changes plus jump cuts (a spike in frame difference far above the shot's own motion)
    cuts = set(hard)
    vals = [d for _, d in diffs]
    for i, (t, d) in enumerate(diffs):
        local = vals[max(0, i - 10): i] + vals[i + 1: i + 11]
        base = float(np.median(local)) if local else 0.0
        if d > max(7.0, base * 3.0) and d >= max(vals[max(0, i - 2): i + 3]):
            cuts.add(t)
    cuts = sorted(c for k, c in enumerate(sorted(cuts)) if k == 0 or c - sorted(cuts)[k - 1] > 0.25)
    punch = []
    for c in cuts:
        sc = scales.get(c)
        if sc and 1.03 < sc < 1.6:
            punch.append(sc)
        elif sc and 0.62 < sc < 0.97:
            punch.append(1 / sc)
    shot_scales = [(t, sc) for t, sc in scales.items() if t not in set(cuts)]

    say("Measuring zooms, captions and cutaways…", 0.8)
    dur = max(0.1, min(MAX_SECONDS, util.probe(src)["duration"]))
    rates = [sc for _, sc in shot_scales if 0.98 < sc < 1.05]
    push = float(np.median(rates)) if rates else 1.0
    zoom = {"punch_in": round(float(np.median(punch)), 3) if punch else None, "punch_ins_per_min": round(len(punch) / dur * 60, 1),
            "slow_push": push > 1.0015, "push_per_second": round((push - 1) * FPS, 4)}
    # b-roll: stretches without a face while words are being spoken
    broll, run = [], None
    spoken = lambda t: any(w["start"] - 0.2 <= t <= w["end"] + 0.2 for w in words) if words else True
    for t, has in faces:
        if not has and spoken(t):
            run = run or [t, t]
            run[1] = t
        elif run:
            if run[1] - run[0] >= 0.4:
                broll.append(run)
            run = None
    if run and run[1] - run[0] >= 0.4:
        broll.append(run)
    face_share = sum(1 for _, h in faces if h) / max(1, len(faces))
    brolls = {"count": len(broll), "per_minute": round(len(broll) / dur * 60, 1), "avg_seconds": round(float(np.mean([b[1] - b[0] + 0.5 for b in broll])), 1) if broll else 0,
              "talking_head_share": round(face_share, 2)}

    # captions: second pass inside the region where text keeps changing
    caps = None
    band_events: list[float] = []
    region = _caption_region(profiles, set(cuts))
    if region:
        say("Reading the captions…", 0.84)
        r0, r1 = region
        band_hist, crops_full = [], []
        last = None
        h0 = len(profiles[0][1])
        a_, b_ = int(r0 * h0), int(r1 * h0) + 1
        steps = [float(np.abs(p1[a_:b_] - p0[a_:b_]).mean()) for (_, p0), (_, p1) in zip(profiles, profiles[1:])]
        change_thr = max(0.003, 3 * float(np.median(steps))) if steps else 0.003
        last_hit = -1.0
        cap = cv2.VideoCapture(str(src))
        H = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)) or 1920
        for t, prof in profiles:
            h = len(prof)
            sub = prof.copy()
            sub[: int(r0 * h)] = 0
            sub[int(r1 * h) + 1:] = 0
            if sub.max() < 0.03:
                last = None
                continue
            sm = np.convolve(sub, np.ones(5) / 5, mode="same")
            pk = int(sm.argmax()); thr = sm[pk] * 0.4
            top, bot = pk, pk
            while top > 0 and sm[top - 1] > thr:
                top -= 1
            while bot < h - 1 and sm[bot + 1] > thr:
                bot += 1
            band_hist.append((t, top / h, (bot - top) / h))
            sig = prof[int(r0 * h): int(r1 * h) + 1]
            if last is None or float(np.abs(sig - last).mean()) > change_thr:
                if t - last_hit > 0.15:          # a run of changing frames (one animated entry) counts once
                    band_events.append(t)
                last_hit = t
            last = sig
        # full-resolution crops at spoken-word times for colours, case and font
        times = [(w["start"] + w["end"]) / 2 for w in words][::2][:40] if words else [t for t, _, _ in band_hist][::5][:40]
        for t in times:
            fr = _frame_at(cap, t)
            if fr is None:
                continue
            y0, y1 = int(r0 * fr.shape[0]), int(r1 * fr.shape[0])
            near = " ".join(w["w"].strip(" ,.!?") for w in words if abs((w["start"] + w["end"]) / 2 - t) < 0.7) if words else ""
            crops_full.append((fr[y0:y1], near))
        cap.release()
        if band_hist and len(band_hist) > len(profiles) * 0.2:
            ys = [b[1] for b in band_hist]
            hs = [b[2] for b in band_hist]
            cps = len(band_events) / dur
            wps = (len(words) / dur) if words else 2.6
            per = max(1, min(6, round(wps / cps))) if cps > 0.2 else 3
            anim = Counter()
            hist_by_t = {round(t, 1): (y, hh) for t, y, hh in band_hist}
            for e in band_events[:60]:
                seq = [hist_by_t.get(round(e + k / FPS, 1)) for k in range(0, 4)]
                seq = [x for x in seq if x]
                if len(seq) < 3:
                    continue
                h0, h2 = seq[0][1], seq[-1][1]
                y0, y2 = seq[0][0], seq[-1][0]
                if h2 > 0 and h0 < h2 * 0.85:
                    anim["pop"] += 1
                elif abs(y2 - y0) > 0.015:
                    anim["slide"] += 1
                else:
                    anim["cut"] += 1
            white = [(_letters(c, "white"), txt) for c, txt in crops_full]
            white = [(m, txt) for m, txt in white if m is not None and (m > 0).sum() > 80]
            stats = [x for x in (_glyph_stats(m) for m, _ in white) if x]
            upper = bool(stats) and float(np.median([x["caps"] for x in stats])) > 0.75
            sample = " ".join(t for _, t in white[:6] if t)[:60]
            fonts = match_font([m for m, _ in white], upper, sample)
            accent_masks = [m for m in (_letters(c, "accent") for c, _ in crops_full) if m is not None and (m > 0).sum() > 60]
            accent = None
            if len(accent_masks) >= 2:
                am = match_font(accent_masks, False, sample, accent=True)
                ast = [x for x in (_glyph_stats(m) for m in accent_masks) if x]
                accent = {"frames": len(accent_masks), "font_match": am,
                          "italic": bool(ast) and float(np.median([x["slant"] for x in ast])) > 0.12}
            caps = {"y": round(float(np.median(ys)) + float(np.median(hs)) / 2, 3), "height": round(float(np.median(hs)), 3),
                    "region": [round(r0, 3), round(r1, 3)],
                    "changes_per_second": round(cps, 2), "words_per_caption": per,
                    "animation": (anim.most_common(1)[0][0] if anim else "cut"), "animation_votes": dict(anim),
                    "uppercase": upper, "font_match": fonts, "accent": accent}
            for i, (c, _) in enumerate(crops_full[:6]):
                cv2.imwrite(str(frames_dir / f"cap{i:02d}.jpg"), c)
    # structure from the words
    struct = None
    if words:
        text = " ".join(w["w"] for w in words)
        sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if s.strip()]
        cta = next((s for s in reversed(sentences) if re.search(r"\b(follow|comment|link|subscribe|save|share|dm|download|join)\b", s, re.I)), None)
        struct = {"hook": sentences[0][:160] if sentences else "", "hook_seconds": next((w["end"] for w in words if w["w"].rstrip().endswith((".", "!", "?"))), None),
                  "cta": cta[:160] if cta else None, "sentences": len(sentences)}
    say("Listening to the music…", 0.9)
    return {"_band_events": band_events[:40], "_cuts": cuts[:40], "cuts_10fps": len(cuts), "cuts_per_minute": round(len(cuts) / dur * 60, 1), "zoom": zoom, "broll": brolls, "captions": caps, "structure": struct,
            "tempo_bpm": _tempo(src), "loudness_lufs": _loudness(src)}


def _frames_count(dur: float):
    return range(int(min(dur, MAX_SECONDS) * FPS))


# ---------------------------------------------------------------- rulebook ----
def rulebook(r: dict, style: dict, name: str) -> str:
    """Plain-language editing rules the agent follows for every video in this style."""
    caps = r.get("captions") or {}
    deep = r.get("deep") or {}
    z = deep.get("zoom") or {}
    b = deep.get("broll") or {}
    lines = [f"# {style.get('name', name)}: edit spec", "",
             f"Measured frame by frame from {r.get('references', 0)} reference video(s). Every video with this preset must match it.", ""]
    hook = r.get("hook_seconds")
    lines += ["## Hook", f"- Start on the strongest sentence. Get to the point within {max(1.0, min(3.0, hook or 1.5)):.1f}s.",
              "- Put a 3–6 word title on screen for the first 2 seconds." if style.get("graphics", {}).get("title_style") else ""]
    mp = style.get("pacing", {}).get("max_pause", 0.2)
    lines += ["", "## Cuts", f"- Cut every pause longer than {mp:.2f}s. Remove false starts, repeats and filler words.",
              f"- About {r.get('cuts_per_minute') or '—'} cuts a minute in the references; keep a similar rhythm."]
    if z.get("punch_in"):
        lines.append(f"- Punch in about {int((z['punch_in'] - 1) * 100)}% on cuts (alternate in and out).")
    if z.get("slow_push"):
        lines.append("- Use slow push-ins inside longer shots.")
    rep = r.get("replica") or {}
    rc = rep.get("captions") or {}
    if rc:
        lines += ["", "## Captions: measured exactly",
                  f"- Fill {rc.get('fill')}, outline {rc.get('outline') or 'none'} ({rc.get('outline_rel')} of letter height), highlight {rc.get('highlight') or 'none'}.",
                  f"- Letter height {rc.get('cap_height', 0) * 100:.2f}% of the frame, centred at x={rc.get('x')} y={rc.get('y')}, {rc.get('lines')} line(s), {'on a box ' + str(rc.get('box_color')) if rc.get('box') else 'no box'}."]
    if rep.get("pop"):
        p_ = rep["pop"]
        lines.append(f"- Entry: {'pops from ' + str(p_['from']) + 'x to ' + str(p_['peak']) + 'x in ' + str(p_['in_ms']) + ' ms' if p_.get('animated') else 'appears instantly (no animation)'}.")
    if rep.get("lead_ms") is not None:
        lines.append(f"- Captions appear {rep['lead_ms']} ms before the word is spoken.")
    if rep.get("transitions"):
        lines.append(f"- Shot transitions: {', '.join(f'{k} ×{v}' for k, v in rep['transitions'].items())}.")
    lines += ["", "## Captions",
              f"- Font: {style['fonts']['caption']}. {'ALL CAPS.' if style['captions'].get('uppercase') else 'Normal case.'} "
              f"{style['captions'].get('max_words', 3)} words at a time.",
              f"- Animation: {style['captions'].get('mode', 'highlight')}. Highlight colour {style['colors']['accent']}.",
              f"- Position: {int(style['captions'].get('y', 0.66) * 100)}% down the frame. {'On a box.' if style['captions'].get('box') else 'Outlined text.'}"]
    if b.get("count"):
        lines += ["", "## B-roll", f"- Cut away to B-roll about {b.get('per_minute')} times a minute, ~{b.get('avg_seconds')}s each, "
                  "whenever the creator talks about something you can show."]
    lines += ["", "## Look and sound", f"- Colour: {style.get('grade')}{' (custom grade measured from the references)' if style.get('grade') == 'custom' else ''}.",
              f"- Music: {'yes, quiet under the voice' if r.get('music') else 'voice only'}" + (f", around {deep.get('tempo_bpm')} bpm." if deep.get("tempo_bpm") and r.get("music") else "."),
              f"- Sound effects: {'on transitions and pop-ups' if style.get('sfx', {}).get('enabled', True) else 'none'}."]
    st = deep.get("structure") or {}
    if st.get("cta"):
        lines += ["", "## Ending", f"- End with a clear call to action, like the references (\"{st['cta'][:80]}\")."]
    lines += ["", "## Never", "- Never copy the reference creators' logos, names, footage or signature graphics."]
    return "\n".join(l for l in lines if l is not None)


# ================================================================== replica ====
def _frame_at(cap, t: float):
    import cv2
    cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
    ok, fr = cap.read()
    return fr if ok else None


def frame_sheets(src: Path, out_dir: Path, fps: float = 4.0, per_page: int = 24, progress=None) -> list[str]:
    """The whole reference as numbered contact-sheet pages (4 frames a second, timecoded), for the agent to read
    through like an editor scrubbing the timeline."""
    import cv2
    import numpy as np
    out_dir.mkdir(parents=True, exist_ok=True)
    cap = cv2.VideoCapture(str(src))
    dur = min(MAX_SECONDS, (cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0) / (cap.get(cv2.CAP_PROP_FPS) or 30))
    times = [i / fps for i in range(int(dur * fps))]
    pages, tiles = [], []
    for sample,t in enumerate(times):
        if progress:progress(f"Reading reference preview {sample + 1} of {len(times)}", sample/max(1,len(times)))
        fr = _frame_at(cap, t)
        if fr is None:
            continue
        h, w = fr.shape[:2]
        th = cv2.resize(fr, (180, int(h * 180 / w)))
        cv2.putText(th, f"{t:5.2f}s", (4, 14), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (0, 0, 0), 3, cv2.LINE_AA)
        cv2.putText(th, f"{t:5.2f}s", (4, 14), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (255, 255, 255), 1, cv2.LINE_AA)
        tiles.append(th)
    cap.release()
    for p in range(0, len(tiles), per_page):
        chunk = tiles[p:p + per_page]
        hmax = max(t.shape[0] for t in chunk)
        rows = []
        for r in range(0, len(chunk), 6):
            row = [np.pad(t, ((0, hmax - t.shape[0]), (0, 4), (0, 0))) for t in chunk[r:r + 6]]
            while len(row) < 6:
                row.append(np.zeros((hmax, 184, 3), np.uint8))
            rows.append(np.hstack(row))
        sheet = np.vstack([np.pad(r, ((0, 4), (0, 0), (0, 0))) for r in rows])
        f = out_dir / f"page-{p // per_page + 1:02d}.jpg"
        cv2.imwrite(str(f), sheet, [cv2.IMWRITE_JPEG_QUALITY, 82])
        pages.append(util.rel(f))
    if progress:progress("Reference previews ready",1.0)
    return pages


def _caption_style(crop_bgr) -> dict | None:
    """Exact caption look from one full-resolution caption crop: fill / outline / highlight colours, outline
    thickness, letter (cap) height, number of lines, box."""
    import cv2
    import numpy as np
    hsv = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2HSV)
    v, s = hsv[..., 2].astype(np.float32) / 255, hsv[..., 1].astype(np.float32) / 255
    bright = (v > 0.72)
    if bright.mean() < 0.01:
        return None
    mask = bright.astype(np.uint8) * 255
    n, lab, st, _ = cv2.connectedComponentsWithStats(mask, 8)
    ch, cw = crop_bgr.shape[:2]

    def is_letter(i):
        x, y, w, h, a = st[i]
        touches = x <= 0 or y <= 0 or x + w >= cw or y + h >= ch      # backgrounds touch the crop edge, letters don't
        return h > ch * 0.18 and a > 20 and not touches and a < ch * cw * 0.2
    comps = [i for i in range(1, n) if is_letter(i)]
    if len(comps) < 2:
        return None
    letters = np.isin(lab, comps)
    inner = cv2.erode(letters.astype(np.uint8), np.ones((3, 3), np.uint8)) > 0
    px = crop_bgr[inner if inner.any() else letters]
    sat = s[inner if inner.any() else letters]
    white_like = px[sat < 0.35]
    vivid = px[sat >= 0.45]
    def hexc(a):
        b, g, r = (int(x) for x in np.median(a, axis=0))
        return "#%02X%02X%02X" % (r, g, b)
    fill = hexc(white_like) if len(white_like) > 20 else (None if len(vivid) > len(px) * 0.5 else hexc(px))
    highlight = hexc(vivid) if len(vivid) > 30 and len(vivid) > len(px) * 0.08 else None
    # outline: grow the letters until the ring stops being dark
    thick, ring_cols = 0, []
    cur = letters.astype(np.uint8)
    for k in range(1, 12):
        grown = cv2.dilate(cur, np.ones((3, 3), np.uint8))
        ring = (grown > 0) & (cur == 0)
        if not ring.any():
            break
        if float(np.median(v[ring])) < 0.3:
            thick = k
            ring_cols.append(crop_bgr[ring])
            cur = grown
        else:
            break
    hs = sorted(st[i][cv2.CC_STAT_HEIGHT] for i in comps)
    cap_h = float(np.median(hs[len(hs) // 3:]))
    rows = np.where(letters.any(axis=1))[0]
    gaps = np.diff(rows) if len(rows) > 1 else np.array([0])
    lines = 1 + int((gaps > cap_h * 0.25).sum())
    ys, xs = np.where(letters)
    bg = crop_bgr[~cv2.dilate(letters.astype(np.uint8), np.ones((9, 9), np.uint8)).astype(bool)]
    box = bool(len(bg) > 50 and float(np.std(cv2.cvtColor(bg.reshape(-1, 1, 3), cv2.COLOR_BGR2GRAY))) < 14)
    return {"fill": fill, "highlight": highlight, "outline": hexc(np.concatenate(ring_cols)) if ring_cols else None,
            "outline_px": thick, "cap_px": cap_h, "lines": lines, "box": box, "box_color": hexc(bg) if box else None,
            "x_center": float(xs.mean() / crop_bgr.shape[1]) if len(xs) else 0.5}


def replica(src: Path, words: list[dict], deep: dict, out_dir: Path, progress=None) -> dict:
    """Measurements precise enough to rebuild the look: run after analyze()."""
    import cv2
    import numpy as np
    say = progress or (lambda *_: None)
    say("Measuring caption colours, size and motion…", 0.92)
    cap = cv2.VideoCapture(str(src))
    W = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)) or 1080
    H = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)) or 1920
    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    region = (((deep or {}).get("captions") or {}).get("region")) or None
    times = [(w["start"] + w["end"]) / 2 for w in words][::2][:30] if words else [i * 0.5 for i in range(40)]
    styles_ = []
    for sample,t in enumerate(times):
        say(f"Measuring caption sample {sample + 1} of {len(times)}", .92 + .025 * sample/max(1,len(times)))
        fr = _frame_at(cap, t)
        if fr is None:
            continue
        g = cv2.cvtColor(cv2.resize(fr, (360, int(H * 360 / W))), cv2.COLOR_BGR2GRAY)
        b = _band(g, region)
        if not b:
            continue
        k = H / g.shape[0]
        top, bot = int(max(0, b[0] - 3) * k), int(min(g.shape[0], b[1] + 4) * k)
        st = _caption_style(fr[top:bot])
        if st:
            st["y"] = (top + bot) / 2 / H
            styles_.append(st)
    res: dict = {"frame": [W, H]}
    if styles_:
        def mode(key):
            vals = [s[key] for s in styles_ if s.get(key)]
            return Counter(vals).most_common(1)[0][0] if vals else None
        cap_px = float(np.median([s["cap_px"] for s in styles_]))
        res["captions"] = {"fill": mode("fill"), "highlight": mode("highlight"), "outline": mode("outline"),
                           "outline_rel": round(float(np.median([s["outline_px"] for s in styles_])) / max(cap_px, 1), 3),
                           "cap_height": round(cap_px / H, 4),
                           "cap_height_big": round(float(np.percentile([s["cap_px"] for s in styles_], 90)) / H, 4), "lines": int(Counter(s["lines"] for s in styles_).most_common(1)[0][0]),
                           "box": sum(s["box"] for s in styles_) > len(styles_) / 2, "box_color": mode("box_color"),
                           "y": round(float(np.median([s["y"] for s in styles_])), 3),
                           "x": round(float(np.median([s["x_center"] for s in styles_])), 3), "samples": len(styles_)}
    # pop motion at the native frame rate: letter height over the first frames after a caption change
    events = []
    dc = (deep or {}).get("captions") or {}
    changes = [t for t in (deep or {}).get("_band_events", [])][:12]
    curves = []
    for sample,t0 in enumerate(changes):
        say(f"Measuring caption motion {sample + 1} of {len(changes)}", .945 + .025 * sample/max(1,len(changes)))
        hs = []
        for f in range(0, 8):
            fr = _frame_at(cap, t0 - 0.05 + f / fps)
            if fr is None:
                break
            g = cv2.cvtColor(cv2.resize(fr, (360, int(H * 360 / W))), cv2.COLOR_BGR2GRAY)
            b = _band(g, region)
            hs.append((b[1] - b[0]) if b else 0)
        if hs and max(hs) > 0:
            final = hs[-1] or max(hs)
            curves.append([h / final for h in hs])
    if curves:
        arr = np.array([c for c in curves if len(c) == len(curves[0])])
        if len(arr):
            med = np.median(arr, axis=0)
            start = float(next((x for x in med if x > 0.2), 1.0))
            peak_i = int(np.argmax(med))
            res["pop"] = {"from": round(min(1.0, start), 2), "peak": round(float(med.max()), 2),
                          "in_ms": int(max(1, peak_i) / fps * 1000), "animated": start < 0.93 or float(med.max()) > 1.04}
    # caption lead: how early a caption appears before its first word is spoken
    if words and changes:
        leads = []
        for t0 in changes:
            nxt = next((w["start"] for w in words if w["start"] >= t0 - 0.3), None)
            if nxt is not None and abs(nxt - t0) < 0.5:
                leads.append(nxt - t0)
        if leads:
            res["lead_ms"] = int(float(np.median(leads)) * 1000)
    # transitions between shots
    trans = Counter()
    cuts=(deep or {}).get("_cuts", [])[:20]
    for sample,t0 in enumerate(cuts):
        say(f"Measuring transition {sample + 1} of {len(cuts)}", .97 + .015 * sample/max(1,len(cuts)))
        frames = [_frame_at(cap, t0 - 2 / fps + f / fps) for f in range(5)]
        frames = [cv2.cvtColor(cv2.resize(f, (180, 320)), cv2.COLOR_BGR2GRAY) for f in frames if f is not None]
        if len(frames) < 5:
            continue
        d = [float(np.abs(frames[i + 1].astype(int) - frames[i].astype(int)).mean()) for i in range(4)]
        sharp = [cv2.Laplacian(f, cv2.CV_64F).var() for f in frames]
        if sorted(d)[-2] > max(d) * 0.5:
            trans["fade"] += 1
        elif min(sharp) < np.median(sharp) * 0.35:
            trans["whip"] += 1
        else:
            trans["cut"] += 1
    if trans:
        res["transitions"] = dict(trans)
    cap.release()
    res["sheets"] = frame_sheets(src, out_dir / "sheets", progress=lambda msg,fraction:say(msg,.985+.015*fraction))
    return res
