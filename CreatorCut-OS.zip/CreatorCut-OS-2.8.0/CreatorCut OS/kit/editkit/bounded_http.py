"""Strict wall-clock budgets include DNS/TLS and buffered network waits."""
import json,subprocess,sys,tempfile,shutil
from pathlib import Path
from . import util

def fetch(url,*,seconds=30,max_bytes=2_000_000,headers=None,destination=None):
 folder=util.STUDIO_OUT/'http-work';folder.mkdir(parents=True,exist_ok=True)
 with tempfile.TemporaryDirectory(prefix='request-',dir=folder) as td:
  file=Path(td)/'download';spec={'url':str(url),'seconds':seconds,'max_bytes':max_bytes,'headers':headers or {},'file':str(file)}
  try:out=subprocess.run([sys.executable,str(util.KIT/'tools/http_fetch.py')],input=json.dumps(spec),text=True,capture_output=True,timeout=seconds)
  except subprocess.TimeoutExpired as error:raise util.Fail('This download took too long. Your previous choice is safe.','Check your connection and retry, or use a file already on your Mac.') from error
  try:receipt=json.loads(out.stdout)
  except (ValueError,TypeError):receipt={}
  if out.returncode or not receipt.get('ok'):raise util.Fail('This download could not finish. Your previous choice is safe.','Check your connection, then retry or choose a local file.')
  if not file.is_file() or file.stat().st_size>max_bytes:raise util.Fail('This download was incomplete. Retry it or use a local file.')
  if destination is not None:shutil.copyfile(file,destination);return receipt
  return file.read_bytes(),receipt

def get(url,*,seconds=15,max_bytes=2_000_000,headers=None):return fetch(url,seconds=seconds,max_bytes=max_bytes,headers=headers)[0]
