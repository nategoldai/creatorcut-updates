"""Watch actual renderer advances; repeated logs cannot extend a stalled frame deadline."""
import json,time
from . import util
class FrameWatchdog:
 def __init__(self,seconds=120,clock=time.monotonic):
  self.clock=clock;self.seconds=seconds;self.last=clock();self.high={}
 def observe(self,line):
  if line.startswith('@hf-progress '):
   try:
    value=json.loads(line.split(' ',1)[1]);code=value.get('code');pct=float(value['pct'])
    if code in ('capture','encode','assemble') and 0<=pct<=100 and pct>self.high.get(code,-1):
     self.high[code]=pct;self.last=self.clock()
   except (ValueError,KeyError,TypeError):pass
  self.check()
 def check(self):
  if self.clock()-self.last>=self.seconds:
   raise util.Fail('The renderer stopped advancing for two minutes. Your footage and saved versions are safe.','Retry this render once in the same chat; do not start another editor.')
