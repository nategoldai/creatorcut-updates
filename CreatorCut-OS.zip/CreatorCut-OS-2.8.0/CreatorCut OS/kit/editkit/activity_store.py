"""Worker-owned activity. One process can never finish another project's step."""
import contextvars, os, time, uuid, math, functools, threading
from . import util
_current = contextvars.ContextVar('creatorcut_activity', default=None)
_writer_lock=threading.RLock()
_heartbeat_stop=None
_heartbeat_thread=None
_read_snapshot = contextvars.ContextVar('creatorcut_activity_read_snapshot',default=None)

def begin(project, **fields):
    path = util.STUDIO_OUT / 'activities' / (str(os.getpid()) + '-' + uuid.uuid4().hex + '.json')
    _current.set(path)
    now=time.time()
    util.write_json(path, dict(fields, project=project, pid=os.getpid(), birth=util.process_identity(os.getpid()), running=True, started=now, updated=now, progress_at=now))
    return path

def update(**fields):
    path = _current.get()
    if path is None:return
    with _writer_lock:
        record = util.read_json(path, default={})
        now=time.time()
        advanced=any(key in fields and fields[key]!=record.get(key) for key in ('detail','percent','phase'))
        progress=now if advanced else record.get('progress_at',record.get('started',now))
        record.update(fields, updated=now)
        # A repeated log line, liveness pulse or queue poll is not new work.
        record['progress_at']=progress
        util.write_json(path, record)

def start_heartbeat(interval=5):
    global _heartbeat_stop,_heartbeat_thread
    stop_heartbeat()
    path=_current.get()
    if path is None:return
    stop=threading.Event();_heartbeat_stop=stop
    def beat():
        while not stop.wait(interval):
            try:
                with _writer_lock:
                    if stop.is_set():return
                    record=util.read_json(path,default={})
                    if not record.get('running'):return
                    record['heartbeat']=time.time()
                    util.write_json(path,record)
            except (OSError,util.Fail):return
    worker=threading.Thread(target=beat,name='creatorcut-step-heartbeat',daemon=True)
    _heartbeat_thread=worker
    try:worker.start()
    except RuntimeError:
        stop.set();_heartbeat_thread=None;_heartbeat_stop=None
        util.log('The activity heartbeat could not start; command output remains the progress source.')

def stop_heartbeat():
    global _heartbeat_stop,_heartbeat_thread
    stop,worker=_heartbeat_stop,_heartbeat_thread
    _heartbeat_stop=None;_heartbeat_thread=None
    if stop:stop.set()
    # Finish an in-flight write before the caller closes or cleans this operation.
    if worker and worker is not threading.current_thread():worker.join(timeout=2)


def detail(text='', percent=None):
    path = _current.get()
    if path is None: return
    with _writer_lock:
        record = util.read_json(path, default={})
        if text:
            if percent is None and text[:120] != record.get('detail'):
                record['percent'] = None  # A new unmeasured stage must not inherit a stale 100%.
            record['detail'] = text[:120]
            log = record.get('log', [])
            if not log or log[-1] != record['detail']: log.append(record['detail'])
            record['log'] = log[-12:]
        if percent is not None: record['percent'] = round(max(0., min(100.,percent)),1)
        update(**record)


def records():
    cached=_read_snapshot.get()
    if cached is not None:return [dict(row) for row in cached]
    result = []
    identities={}
    for path in (util.STUDIO_OUT / 'activities').glob('*.json'):
        try: a = util.read_json(path, default={})
        except (OSError, util.Fail): continue
        if not isinstance(a, dict): continue
        try:
            a['updated'] = float(a.get('updated') or 0)
            if not math.isfinite(a['updated']): continue
        except (ValueError, TypeError): continue
        if a.get('running'):
            try:
                pid = int(a.get('pid') or 0)
                if pid <= 0: raise ValueError()
                if not util.process_alive(pid):raise ProcessLookupError()
                if a.get('birth'):
                    if pid not in identities:identities[pid]=util.process_identity(pid)
                    if identities[pid] and identities[pid]!=a['birth']:
                        a.update(running=False,interrupted=True,pid_reused=True)
            except (ProcessLookupError, ValueError, TypeError):
                a.update(running=False, interrupted=True)
            except PermissionError: pass
        result.append(a)
    return result

def latest(project=None):
    rows = [a for a in records() if project is None or a.get('project') == project]
    return max(rows, key=lambda a:(bool(a.get('running')), a.get('updated',0)), default={})


def consistent_snapshot(fn):
    """Read worker files once per HTTP snapshot, not once per displayed project."""
    @functools.wraps(fn)
    def wrapped(*args,**kwargs):
        if _read_snapshot.get() is not None:return fn(*args,**kwargs)
        token=_read_snapshot.set(records())
        try:return fn(*args,**kwargs)
        finally:_read_snapshot.reset(token)
    return wrapped


def prune_finished(keep_per_project=2):
    """Prune only obsolete operation records; preserve active work and latest project history."""
    finished={};removed=[]
    for file in (util.STUDIO_OUT/'activities').glob('*.json'):
        try:
            row=util.read_json(file,default={})
            if not isinstance(row,dict) or row.get('running'):continue
            stamp=file.stat().st_mtime_ns
            finished.setdefault(row.get('project'),[]).append((stamp,file))
        except (OSError,util.Fail):continue
    for rows in finished.values():
        for stamp,file in sorted(rows,reverse=True)[keep_per_project:]:
            try:
                if file.stat().st_mtime_ns==stamp:file.unlink();removed.append(file.name)
            except OSError:pass
    return removed


def watched_step(project):
    """Fresh guardian observations are liveness, never a fabricated percent."""
    now=time.time();rows=[]
    for path in util.STUDIO_OUT.glob('.stepguard-*/watcher.json'):
        try:
            row=util.read_json(path,default={});age=now-float(row.get('checked_at',0))
            if row.get('project')!=project or row.get('state')!='running' or not 0<=age<15:continue
            if not util.process_alive(row.get('guardian_pid')) or not util.process_alive(row.get('watcher_pid')):continue
            rows.append(row)
        except (OSError,ValueError,TypeError,util.Fail):continue
    return max(rows,key=lambda row:row['checked_at'],default={})
