"""Cheap local health: no provider calls, tool launches, media reads or credentials."""
import shutil,time,math,os
from . import util

def snapshot():
 from . import editor,jobs,readiness,maintenance
 def read(path):
  try:return util.read_json(path,default={})
  except (OSError,util.Fail):return {}
 worker=read(editor.control()/'worker.json');account=read(editor.root()/'account.json')
 active=[{'project':j.get('project'),'state':j.get('state'),'attempts':j.get('attempts',0)} for j in editor.pending_jobs()]
 disk=shutil.disk_usage(util.ROOT);age=editor.supervisor_age(worker)
 alive=editor.same_process(worker.get('pid'),worker.get('birth'))
 model=util.load_profile().get('whisper_model','small')
 return {'schema':2,'time':time.time(),'server':{'alive':True,'pid':os.getpid(),'maintenance':maintenance.active()},
  'version':(util.KIT/'VERSION').read_text().strip() if (util.KIT/'VERSION').is_file() else 'unknown',
  'disk':{'free_bytes':disk.free,'minimum_edit_bytes':2_500_000_000,'can_start_edit':disk.free>=2_500_000_000},
  'supervisor':{'alive':alive,'responsive':alive and age<30,'age':age if math.isfinite(age) else None},
  'account':{'state':account.get('state','unknown'),'provider':editor.provider_name(),'checked_at':account.get('updated')},
  'consent':editor.local_rendering_status(),'queue':active,
  'background_jobs':len([j for j in jobs.all_jobs() if j['state'] in ('queued','running','waiting')]),
  'renderer':{'installed':(util.KIT/'render/node_modules/hyperframes/package.json').is_file(),'verified_by':'readiness'},
  'speech':{'selected':model,'receipt_present':(util.KIT/'models'/model/'model-receipt.json').is_file()},
  'readiness':readiness.status()}
