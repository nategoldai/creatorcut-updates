"""The paper edit: split speech into phrases, find bad takes, restarts and fillers, and decide what to keep."""
from __future__ import annotations

import re
from difflib import SequenceMatcher
from pathlib import Path

from . import util

# sounds that are never words worth keeping


FILLERS = {"um", "uh", "erm", "uhm", "umm", "uhh", "hmm", "mm", "ah", "eh", "er"}
# what people say when they mess up and start a sentence again
RESET_CUES = ["again", "let me start over", "start over", "let me try again", "one more time", "take two",
              "sorry", "wait", "no wait", "let me redo that", "scratch that", "cut that", "from the top"]


def norm(word: str) -> str:
    return re.sub(r"[^a-z0-9']", "", word.lower())


def build_phrases(words: list[dict], gap: float = 0.42) -> list[dict]:
    """Group words into phrases: a new phrase starts after a pause or at the end of a sentence."""
    phrases, cur = [], []
    for i, w in enumerate(words):
        if cur and (w["start"] - words[cur[-1]]["end"] > gap or re.search(r"[.!?]$", words[cur[-1]]["w"])):
            phrases.append(cur)
            cur = []
        cur.append(i)
    if cur:
        phrases.append(cur)
    out = []
    for n, idx in enumerate(phrases):
        out.append({"id": n + 1, "first": idx[0], "last": idx[-1], "start": words[idx[0]]["start"],
                    "end": words[idx[-1]]["end"], "text": " ".join(words[i]["w"] for i in idx),
                    "keep": True, "reason": ""})
    return out


def _tokens(words, ph):
    return [t for t in (norm(words[i]["w"]) for i in range(ph["first"], ph["last"] + 1)) if t and t not in FILLERS]


LEAD_INS = {"so", "and", "okay", "ok", "alright", "right", "well", "like", "now", "but", "yeah", "basically", "anyway"}


def _strip_lead(toks: list[str]) -> list[str]:
    i = 0
    while i < len(toks) - 1 and i < 3 and toks[i] in LEAD_INS:
        i += 1
    return toks[i:]


def detect_retakes(words: list[dict], phrases: list[dict]) -> None:
    for i, ph in enumerate(phrases):
        toks = _tokens(words, ph)
        text = " ".join(toks)
        # 1. reset cues ("again", "let me start over"...) that are basically the whole phrase
        if toks and any(text == cue or (text.endswith(cue) and len(toks) <= len(cue.split()) + 2) for cue in RESET_CUES):
            ph["keep"], ph["reason"] = False, "you restarted here"
            if i > 0 and phrases[i - 1]["keep"]:
                phrases[i - 1]["keep"], phrases[i - 1]["reason"] = False, "bad take (you said a restart cue after it)"
            continue
        if not toks:
            ph["keep"], ph["reason"] = False, "only filler sounds"
            continue
        # 2. the same opening is said again a little later -> the earlier one is the bad take
        for j in range(i + 1, min(i + 5, len(phrases))):
            later = _tokens(words, phrases[j])
            if not later:
                continue
            k = min(len(toks), len(later), 4)
            same_open = k >= 2 and toks[:k] == later[:k]
            sim = SequenceMatcher(None, toks, later[:len(toks) + 2]).ratio() if len(toks) >= 3 else 0
            t2, l2 = _strip_lead(toks), _strip_lead(later)
            restarted = len(t2) >= 2 and l2[:len(t2)] == t2 and len(l2) > len(t2)   # "so the first tip." → "the first tip is …"
            if (same_open and len(toks) <= len(later) + 1) or sim >= 0.78 or restarted:
                ph["keep"], ph["reason"] = False, f"bad take (you said it again in phrase {phrases[j]['id']})"
                break
        # 3. a short fragment that trails off straight into a new attempt
        if ph["keep"] and len(toks) <= 3 and i + 1 < len(phrases):
            nxt = _strip_lead(_tokens(words, phrases[i + 1]))
            t2 = _strip_lead(toks)
            # "Um, so first." → "First, no phone…": a stumble that restarts with the same word
            if nxt and t2 and nxt[0] == t2[-1] or (nxt and nxt[0] == toks[0] and not re.search(r"[.!?]$", words[ph["last"]]["w"])):
                ph["keep"], ph["reason"] = False, "false start"


def detect_word_issues(words: list[dict], phrases: list[dict]) -> tuple[list[int], dict, list[str]]:
    """Bad takes inside a sentence, which the phrase-level check can't see:
    - restarts: a run of 1-4 words said twice in a row ("and this, and this really") -> drop the first try
    - stretched words: a word lasting far longer than it can be spoken hides a hesitation or a mumbled restart
      (speech recognisers glue those onto the nearest word) -> keep only the spoken length
    - a lead-in as the very first word of the video ("So, we learned…") -> start on the real first word"""
    drop: set[int] = set()
    trim: dict[str, float] = {}
    why: list[str] = []
    kept = [ph for ph in phrases if ph["keep"]]
    for ph in kept:
        idx = [i for i in range(ph["first"], ph["last"] + 1) if norm(words[i]["w"]) not in FILLERS]
        toks = [norm(words[i]["w"]) for i in idx]
        k = 0
        while k < len(toks):
            hit = False
            for n in (4, 3, 2, 1):
                if k + 2 * n <= len(toks) and toks[k:k + n] == toks[k + n:k + 2 * n] and all(toks[k:k + n]):
                    if n == 1 and toks[k] in ("very", "really", "so", "no", "yes", "bye", "ha", "go"):
                        continue                         # "very very", "no no" can be intentional
                    for j in idx[k:k + n]:
                        drop.add(j)
                    why.append(f"restart: \"{' '.join(words[i]['w'] for i in idx[k:k + 2 * n])}\" -> kept the second try")
                    k += n
                    hit = True
                    break
            if not hit:
                k += 1
    # abandoned attempts: "this is one of - this is one of the most important tools you can - this is one of the most
    # important skills you can learn". The same opening (3+ words) is said again a little later and the earlier try never
    # finished (no comma or full stop before the retry) -> only the last try stays. Lists ("it's not a breathwork
    # practice, it's not a somatic practice") end each item with a comma, so they're never touched.
    changed = True
    while changed:
        changed = False
        flat = [i for ph in kept for i in range(ph["first"], ph["last"] + 1)
                if i not in drop and norm(words[i]["w"]) and norm(words[i]["w"]) not in FILLERS]
        ft = [norm(words[i]["w"]) for i in flat]
        for k in range(len(ft) - 3):
            for m in range(min(len(ft) - 3, k + 30), k, -1):
                n = 0
                while m + n < len(ft) and k + n < m and ft[k + n] == ft[m + n]:
                    n += 1
                span = m - k
                if n < 3 or span > 16 or span < n:
                    continue
                if any(re.search(r"[.!?,;:]$", words[flat[x]]["w"].strip()) for x in range(k, m)):
                    continue                                 # the earlier try was a finished clause
                if any(t in ("and", "or", "but", "nor", "then", "because", "while") for t in ft[max(k, m - 3):m]):
                    continue                                 # "we learned to yap and we learned to edit": on purpose
                for x in range(k, m):
                    drop.add(flat[x])
                why.append('false start: "' + " ".join(words[flat[x]]["w"] for x in range(k, m)) + '" -> kept the last try')
                changed = True
                break
            if changed:
                break
    # marks the recogniser writes for a cut-off word ("-", "--", "…") are not words
    for i, w in enumerate(words):
        if not re.sub(r"[\W_]", "", w["w"]) and i not in drop:
            drop.add(i)
    # a sentence said twice ("...talked about by every ancient wisdom culture. And it's been talked about by every ancient
    # wisdom culture...") -> one of them goes: the earlier if it was the whole sentence, else the later (no half sentences)
    flat = [i for ph in kept for i in range(ph["first"], ph["last"] + 1) if i not in drop and norm(words[i]["w"])]
    sents, cur = [], []
    for i in flat:
        cur.append(i)
        if re.search(r"[.!?]$", words[i]["w"].strip()):
            sents.append(cur); cur = []
    if cur:
        sents.append(cur)
    for a in range(len(sents)):
        for b in range(a + 1, min(len(sents), a + 4)):
            ta = [norm(words[i]["w"]) for i in sents[a] if norm(words[i]["w"]) not in FILLERS]
            tb = [norm(words[i]["w"]) for i in sents[b] if norm(words[i]["w"]) not in FILLERS]
            if len(tb) < 6 or len(ta) < 6 or any(i in drop for i in sents[a] + sents[b]):
                continue
            tail = ta[-len(tb):]
            if SequenceMatcher(None, tail, tb).ratio() >= 0.75:
                gone = sents[a] if len(ta) <= len(tb) + 2 else sents[b]
                for i in gone:
                    drop.add(i)
                why.append('said twice: "' + " ".join(words[i]["w"] for i in gone)[:80] + '" -> kept one')
    for i, w in enumerate(words):
        letters = len(re.sub(r"[^A-Za-z0-9]", "", w["w"]))
        spoken = 0.16 + 0.075 * max(1, letters)                # generous: slow speakers stay untouched
        if w["end"] - w["start"] > max(0.6, spoken * 2.2):
            trim[str(i)] = round(w["start"] + spoken * 1.3, 3)
            why.append(f"stretched word: \"{w['w']}\" lasted {w['end'] - w['start']:.1f}s -> trimmed to {spoken * 1.3:.1f}s")
    # a mumbled fragment: a one-word "sentence" the recogniser wasn't sure about, wedged between real sentences
    standalone = {"seriously", "yes", "no", "yeah", "right", "exactly", "wow", "okay", "ok", "true", "boom", "done", "why", "nope", "honestly"}
    for i in range(1, len(words) - 1):
        w = words[i]
        ends_prev = words[i - 1]["w"].rstrip().endswith((".", "!", "?"))
        ends_self = w["w"].rstrip().endswith((".", "!", "?", ","))
        if ends_prev and ends_self and norm(w["w"]) not in standalone and w.get("p", 1) < 0.8 and i not in drop:
            drop.add(i)
            why.append(f"mumbled fragment: \"{w['w']}\" ({round(w.get('p', 1) * 100)}% sure) -> removed")
    if kept:
        first = next((i for i in range(kept[0]["first"], kept[0]["last"] + 1) if i not in drop), None)
        if first is not None and first < kept[0]["last"] and norm(words[first]["w"]) in {"so", "and", "okay", "ok", "alright", "um", "uh"}:
            drop.add(first)
            why.append(f"lead-in at the very start: \"{words[first]['w']}\" -> starts on \"{words[first + 1]['w']}\"")
    return sorted(drop), trim, why


def _voiced(src: str, a: float, b: float) -> tuple[float, float] | None:
    """Where the voice really is between a and b (seconds), from the audio's loudness in 20 ms steps.
    Speech recognisers glue silence or a hesitation onto a word; this finds the spoken part."""
    try:
        import numpy as np
        pad = 0.05
        import subprocess
        raw = subprocess.run([util.ffmpeg_bin(), "-v", "error", "-ss", f"{max(0, a - pad):.3f}", "-t", f"{b - a + 2 * pad:.3f}", "-i", src,
                              "-ac", "1", "-ar", "16000", "-f", "s16le", "-"], capture_output=True, timeout=60)
        x = np.frombuffer(raw.stdout, dtype=np.int16).astype(np.float32)
    except Exception:
        return None
    if x.size < 640:
        return None
    hop = 320
    rms = np.sqrt(np.array([np.mean(x[k:k + hop] ** 2) for k in range(0, x.size - hop, hop)]) + 1e-6)
    on = rms > max(rms.max() * 0.18, 300)
    if not on.any():
        return None
    # separate bursts of voice (a pause of 120 ms or more splits them); the word is the first real burst, the rest
    # is a hesitation or a restart the recogniser glued on
    step = hop / 16000
    runs, cur, gap = [], None, 0
    for k, v in enumerate(on):
        if v:
            if cur is None:
                cur = [k, k]
            cur[1], gap = k, 0
        elif cur is not None:
            gap += 1
            if gap * step >= 0.12:
                runs.append(cur); cur, gap = None, 0
    if cur is not None:
        runs.append(cur)
    runs = [r for r in runs if (r[1] - r[0] + 1) * step >= 0.1 and max(0, a - pad) + r[1] * step > a + 0.02]
    if not runs:
        return None
    r = runs[0]
    s = max(0, a - pad) + r[0] * step
    e = max(0, a - pad) + (r[1] + 1) * step
    return round(max(a - 0.02, s - 0.04), 3), round(min(b, e + 0.06), 3)


def _pace(cfg: dict, default: float) -> float:
    """Pauses kept inside sentences: what the creator taught us, else the reference's measured rhythm, else the style."""
    try:
        from . import learn, styles
        lp = learn.adjustments(cfg.get("style")).get("max_pause")
        if lp:
            return float(lp)
        path = styles.style_path(cfg.get("style", ""))
        bp = (util.read_json(path) if path else {}).get("blueprint") or {}
        return float(bp.get("pacing", {}).get("max_pause") or default)
    except Exception:
        return default


def _min_cut(cfg: dict) -> float:
    """A pause is cut only when that saves at least this much (seconds): a calm reference has no jump cuts for 0.3 s."""
    try:
        from . import learn, styles
        if learn.adjustments(cfg.get("style")).get("max_pause"):
            return 0.0
        path = styles.style_path(cfg.get("style", ""))
        bp = (util.read_json(path) if path else {}).get("blueprint") or {}
        return float(bp.get("pacing", {}).get("min_cut") or 0.0)
    except Exception:
        return 0.0


def make_plan(project: Path, max_pause: float | None = None, remove_fillers: bool | None = None, ranges: list[dict] | None = None) -> dict:
    tr = util.read_json(project / "transcript.json")
    cfg = util.read_json(project / "project.json")
    words = tr["words"]
    if not words:
        if tr.get('speech_status') in ('not_applicable_no_audio','not_applicable_no_speech'):
            from .artifact_cache import digest
            source=util.read_json(project/'source.json');path=Path(source['path']);actual=util.probe(path)
            if (tr.get('speech_status')=='not_applicable_no_audio' and actual.get('has_audio') is not False) or tr.get('source_sha256')!=digest(path):
                raise util.Fail('The footage changed after its audio check. Run transcribe again before planning.')
            duration=actual['duration']
            plan={'mode':'visual','phrases':[],'ranges':ranges if ranges is not None else [{'start':0.0,'end':duration}],
                  'settings':{'max_pause':0.0,'lead_in':0.0,'tail':0.0,'remove_fillers':False},
                  'source_sha256':tr['source_sha256'],'drop':[],'trim':{},'word_notes':[],
                  'notes':('Measured no audio track.' if tr.get('speech_status')=='not_applicable_no_audio' else 'No spoken words detected by the completed transcript.')+' These explicit source ranges preserve footage and its sound; no speech, retakes or silence cuts are invented.'}
            segments_from_plan(plan,words,duration)
            util.write_json(project/'plan.json',plan)
            write_plan_md(project,plan,words,duration)
            util.activity('Visual edit ranges prepared',100)
            return plan
        raise util.Fail("No speech was found in this video.",
                        "Check that the video has sound. If it's a music-only video, use /edit with captions off.")
    if ranges is not None:
        raise util.Fail('Explicit visual ranges apply only to footage verified to have no audio track. Use the speech edit plan for this clip.')
    from . import styles
    style = styles.for_project(cfg)
    pacing = style["pacing"]
    phrases = build_phrases(words)
    detect_retakes(words, phrases)
    drop, trim, why = detect_word_issues(words, phrases)
    src = util.read_json(project / "source.json", default={}).get("path")
    if src and Path(src).exists():
        for k in list(trim):
            w = words[int(k)]
            v = _voiced(src, w["start"], w["end"])
            if v and v[1] - v[0] > 0.08:
                trim[k] = [v[0], v[1]]          # keep exactly the spoken part, wherever it is inside the word
    plan = {
        "phrases": phrases,
        "settings": {
            "max_pause": max_pause if max_pause is not None else _pace(cfg, pacing["max_pause"]),
            "min_cut": 0.0 if max_pause is not None else _min_cut(cfg),
            "remove_fillers": pacing["remove_fillers"] if remove_fillers is None else remove_fillers,
            "lead_in": pacing["lead_in"], "tail": pacing["tail"],
        },
        "drop": drop, "trim": trim, "word_notes": why,
        "notes": "Set keep to false/true on any phrase, then run: edit.py cut <project>. "
                 "'drop' lists single words removed (restarts, a lead-in at the very start); 'trim' shortens stretched words.",
    }
    util.write_json(project / "plan.json", plan)
    removed = [p for p in phrases if not p["keep"]]
    util.activity(f"Found {len(removed)} bad take{'s' if len(removed) != 1 else ''} in {len(phrases)} phrases", 100)
    write_plan_md(project, plan, words, tr.get("duration", 0))
    return plan


def segments_from_plan(plan: dict, words: list[dict], duration: float) -> list[dict]:
    """Turn kept phrases into keep-segments on the source timeline, trimming fillers and long pauses."""
    if plan.get('mode')=='visual':
        import math
        ranges=plan.get('ranges')
        if words or not isinstance(ranges,list) or not ranges or len(ranges)>1000 or type(duration) not in (int,float) or not math.isfinite(duration) or duration<=0:
            raise util.Fail('A visual edit needs valid nonempty ranges and verified footage without spoken words.')
        result=[];previous=0.0
        for row in ranges:
            if not isinstance(row,dict):raise util.Fail('Each visual range needs a start and end time.')
            start,end=row.get('start'),row.get('end')
            if any(type(x) not in (int,float) or not math.isfinite(x) for x in (start,end)) or start<previous or end<=start or end>duration:
                raise util.Fail('Visual ranges must be ordered, nonoverlapping and inside the source video.')
            result.append({'start':float(start),'end':float(end),'words':[]});previous=end
        return result
    s = plan["settings"]
    max_pause, lead, tail = s["max_pause"], s["lead_in"], s["tail"]
    min_cut = float(s.get("min_cut", 0.0))
    kept = []
    drop = set(plan.get("drop", []))
    trim = {int(k): v for k, v in plan.get("trim", {}).items()}
    words = [(dict(w, start=trim[i][0], end=trim[i][1]) if isinstance(trim[i], list) else dict(w, end=min(w["end"], trim[i])))
             if i in trim else w for i, w in enumerate(words)]
    for ph in plan["phrases"]:
        if not ph["keep"]:
            continue
        for i in range(ph["first"], ph["last"] + 1):
            if s["remove_fillers"] and norm(words[i]["w"]) in FILLERS:
                continue
            if i in drop:
                continue
            kept.append(i)
    if not kept:
        raise util.Fail("Every phrase is marked as removed, so there's nothing left to cut.",
                        "Open plan.md, set keep back to true on the phrases you want, then run cut again.")
    segs = []
    seg = {"start": max(0.0, words[kept[0]]["start"] - lead), "end": words[kept[0]]["end"], "words": [kept[0]]}
    for prev, cur in zip(kept, kept[1:]):
        gap = words[cur]["start"] - words[prev]["end"]
        contiguous = cur == prev + 1
        if contiguous and (gap <= max_pause or gap - max_pause < min_cut):   # a cut that saves almost nothing is only a jump
            seg["end"] = words[cur]["end"]
            seg["words"].append(cur)
        else:
            # close current segment with a short natural tail, open a new one with a short lead
            keep_gap = min(gap, max_pause) if contiguous else 0.0
            seg["end"] = min(words[prev]["end"] + max(keep_gap / 2, 0.04), words[cur]["start"])
            segs.append(seg)
            start = max(words[cur]["start"] - max(keep_gap / 2, 0.04), words[prev]["end"])
            seg = {"start": start, "end": words[cur]["end"], "words": [cur]}
    seg["end"] = min(duration, seg["end"] + tail)
    segs.append(seg)
    # merge micro-segments
    merged = []
    for sg in segs:
        if merged and sg["start"] - merged[-1]["end"] < 0.02:
            merged[-1]["end"] = sg["end"]
            merged[-1]["words"] += sg["words"]
        else:
            merged.append(sg)
    # never a piece shorter than half a second: a one-word flash between two cuts looks like a glitch.
    # Join it to its neighbour and keep the (short) pause between them instead.
    out = []
    for sg in merged:
        prev = out[-1] if out else None
        short_prev = prev and prev["end"] - prev["start"] < 0.5
        short_cur = sg["end"] - sg["start"] < 0.5
        if prev and (short_prev or short_cur) and sg["start"] - prev["end"] < 0.75 and \
                all(i == j + 1 for i, j in zip(sg["words"][:1], prev["words"][-1:])):
            prev["end"] = sg["end"]
            prev["words"] += sg["words"]
        else:
            out.append(sg)
    return out


def write_plan_md(project: Path, plan: dict, words: list[dict], duration: float) -> None:
    segs = segments_from_plan(plan, words, duration)
    new_len = sum(s["end"] - s["start"] for s in segs)
    if plan.get('mode')=='visual':
        lines=[f'# Visual edit: {project.name}','',('No spoken words were detected. Keep the original sound and these source sections:' if util.read_json(project/'transcript.json',default={}).get('speech_status')=='not_applicable_no_speech' else 'No audio track was found. Keep these source sections:'),'']
        lines += [f"- {s['start']:.3f}s to {s['end']:.3f}s" for s in segs]
        lines += ['',f'Total: {new_len:.3f}s. No speech or silence removal is claimed.']
        (project/'plan.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
        return
    removed = [p for p in plan["phrases"] if not p["keep"]]
    lines = [
        f"# Edit plan: {project.name}",
        "",
        f"Original: **{util.fmt_time(duration)}**  →  After cuts: **{util.fmt_time(new_len)}** "
        f"({len(removed)} phrases removed, pauses over {plan['settings']['max_pause']:.2f}s tightened"
        + (", filler sounds removed" if plan["settings"]["remove_fillers"] else "") + ")",
        "",
        "| # | Time | Keep | What you said | Why removed |",
        "|---|---|---|---|---|",
    ]
    for p in plan["phrases"]:
        text = p["text"] if len(p["text"]) < 90 else p["text"][:87] + "…"
        lines.append(f"| {p['id']} | {util.fmt_time(p['start'])} | {'✓' if p['keep'] else '✗'} | {text} | {p['reason']} |")
    if plan.get("word_notes"):
        lines += ["", "## Inside sentences", ""] + [f"- {n}" for n in plan["word_notes"]]
    (project / "plan.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
