"""Job transition policy. Late events cannot revive a stopped or finished job."""
from . import util
ACTIVE=frozenset({'queued','starting','editing','waiting_approval','recovering'})
TERMINAL=frozenset({'succeeded','failed','cancelled','needs_attention','needs_setup'})
TRANSITIONS={state:ACTIVE|TERMINAL for state in ACTIVE}
TRANSITIONS.update({state:frozenset({state,'queued'}) for state in TERMINAL-{'succeeded'}})
TRANSITIONS['succeeded']=frozenset({'succeeded'})

def check(previous,current):
 if not previous:return
 same=previous.get('id')==current.get('id')
 if not same:
  if previous.get('state') in ACTIVE:raise util.Fail('The previous edit still owns this video. Stop it before starting a different request.')
  if current.get('state')!='queued':raise util.Fail('A new editing job must enter its queue first.')
  return
 before,after=previous.get('state'),current.get('state')
 if after not in TRANSITIONS.get(before,()):raise util.Fail('This edit has already stopped. Start a fresh retry to continue; late events cannot restart it.')
 if previous.get('cancel') and after in ACTIVE and after!='queued' and not current.get('cancel'):
  raise util.Fail('This edit was stopped. A late update cannot clear its stop request.')
