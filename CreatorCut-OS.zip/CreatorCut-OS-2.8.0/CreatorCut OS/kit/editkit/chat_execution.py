"""Read-only compatibility for older core modules. Customer work is in editor.director."""
from contextlib import contextmanager
def mode():return 'chat'
def paste_only():return False
def inherited_fds():return ()
@contextmanager
def command_guard(p):
 from . import util
 with util.file_guard(p/'.recipe-command.guard'):yield
