"""Identity-verified detached Chrome cleanup from private per-invocation receipts."""
import json,os,secrets,signal,time
from pathlib import Path
from . import util

def configure(env,folder):
 folder=Path(folder)/'owned-browsers';folder.mkdir(mode=0o700,exist_ok=True)
 scope=secrets.token_hex(24);env['CREATORCUT_BROWSER_REGISTRY']=str(folder);env['CREATORCUT_BROWSER_SCOPE']=scope
 preload=(util.KIT/'tools/browser_ownership.mjs').as_uri();env['NODE_OPTIONS']=(env.get('NODE_OPTIONS','')+' --import='+preload).strip()
 return folder,scope

def cleanup(folder,scope):
 clean=True;private=(util.KIT/'render/node_modules/.remotion').resolve()
 for file in Path(folder).glob('*.json'):
  try:
   row=json.loads(file.read_text());pid=row['pid'];birth=row.get('birth');exe=Path(row['executable']).resolve()
   if row.get('scope')!=scope or type(pid) is not int or pid<=1 or not exe.is_relative_to(private):continue
   if not util.process_alive(pid):continue
   if not birth or util.process_identity(pid)!=birth:
    clean=False;util.log('Browser cleanup needs identity access; no unknown process was signalled.');continue
   group=bool(row.get('detached')) and os.getpgid(pid)==pid
   def stop(sig):
    if util.process_identity(pid)!=birth:return
    try:os.killpg(pid,sig) if group and os.getpgid(pid)==pid else os.kill(pid,sig)
    except ProcessLookupError:pass
   stop(signal.SIGTERM);deadline=time.monotonic()+2
   while util.process_alive(pid) and time.monotonic()<deadline:time.sleep(.05)
   if util.process_alive(pid):stop(signal.SIGKILL)
  except (OSError,ValueError,KeyError,TypeError):clean=False
 return clean
