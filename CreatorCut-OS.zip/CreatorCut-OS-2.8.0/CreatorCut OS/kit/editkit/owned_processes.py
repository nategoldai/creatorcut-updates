"""Escalate shutdown only for identity-verified app-owned records, never arbitrary job PIDs."""
import os,signal,time,hashlib,math
from . import util

def stop(record,label):
 from . import editor
 pid,birth=record.get('pid'),record.get('birth')
 if type(pid) is not int or pid<=1 or not birth or not editor.same_process(pid,birth):return 'gone'
 # Callers supply supervisor-private registry records; project/model metadata is never accepted.
 key=hashlib.sha256((str(pid)+':'+str(birth)+':'+label).encode()).hexdigest()[:24]
 file=editor.control()/'shutdown'/f'{key}.json'
 with util.file_guard(file.with_suffix('.guard'),timeout=.2):
  saved=editor.safe_json(file)
  now=time.monotonic();since=saved.get('since')
  if type(since) not in (int,float) or not math.isfinite(since) or since>now:since=now
  signal_value=getattr(signal,'SIGKILL',signal.SIGTERM) if now-since>=5 else signal.SIGTERM
  # Re-check immediately before the signal in case the process exited or its PID was reused.
  if not editor.same_process(pid,birth):return 'gone'
  try:os.kill(pid,signal_value)
  except ProcessLookupError:return 'gone'
  util.write_durable_json(file,{'pid':pid,'birth':birth,'since':since,'signal':int(signal_value)})
  return 'killing' if signal_value==getattr(signal,'SIGKILL',signal.SIGTERM) else 'stopping'
