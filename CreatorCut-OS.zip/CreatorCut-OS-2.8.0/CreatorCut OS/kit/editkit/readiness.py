"""Opening Studio is independent of readiness to edit. Checks are single-flight and observable."""
import threading,time,sys
from . import util
_lock=threading.Lock();_memory={};_memory_root=None
_last_started=0.;_last_root=None
def _save(value):
 global _memory,_memory_root
 value=dict(value,version=(util.KIT/'VERSION').read_text().strip() if (util.KIT/'VERSION').is_file() else '')
 _memory=value;_memory_root=util.ROOT
 try:util.write_json(util.STUDIO_OUT/'readiness.json',value)
 except OSError:util.log('Readiness status kept in memory; storage is not writable.')
def _snapshot():
 try:
  value=util.read_json(util.STUDIO_OUT/'readiness.json',default=_memory if _memory_root==util.ROOT else {})
  if not isinstance(value,dict) or (value and value.get('state') not in ('ready','checking','repair')):raise util.Fail('Invalid readiness record.')
  proof=util.read_json(util.STUDIO_OUT/'setup-ready.json',default={})
  if proof.get('state')=='ready' and proof.get('version')==(util.KIT/'VERSION').read_text().strip() and float(proof.get('updated',0))>=float(value.get('updated',0)):
   return {'state':'ready','version':proof['version'],'updated':proof['updated'],'message':''}
  if value.get('state')=='checking' and time.time()>float(value.get('deadline_at') or float(value.get('updated',0))+330):
   return dict(value,state='repair',message='The setup check took too long. Your files are safe. Click Check again, or ask your chat to finish setup.')
  return value
 except (util.Fail,OSError,ValueError,TypeError):return {'state':'repair','message':'The saved setup status could not be read. Run the setup check again.'}
def status():
 value=_snapshot();version=(util.KIT/'VERSION').read_text().strip() if (util.KIT/'VERSION').is_file() else ''
 stale=bool(version) and (value.get('version') not in (None,version) or value.get('state')=='ready' and value.get('version')!=version)
 retry=value.get('state') in ('repair','checking') and (value.get('state')!='checking' or time.time()>float(value.get('deadline_at') or value.get('updated',0)+330))
 can_start=not _lock.locked() and (_last_root!=util.ROOT or time.time()-_last_started>=30)
 if stale:
  # Never return the previous release's green status while a new check starts.
  if can_start:return start()
  return dict(value,state='checking' if _lock.locked() else 'repair',message='Checking the updated editing tools. Your files are saved.')
 if retry and can_start:start()
 return value

def start():
 global _last_started,_last_root
 if not _lock.acquire(blocking=False):return _snapshot()
 _last_started=time.time();_last_root=util.ROOT
 _save({'state':'checking','updated':time.time(),'deadline_at':time.time()+330,'message':'Checking your editing tools'})
 def check():
  try:
   # Native-library imports can hold the Python interpreter lock for minutes on
   # a cold Mac. Keep them out of the HTTP server, and bound the owned child.
   code="import sys;from pathlib import Path;sys.path.insert(0,str(Path(sys.argv[1])/'kit'));from editkit import setup,util\ntry:setup.require_open_ready();print('CREATORCUT_SETUP_READY')\nexcept util.Fail as error:print(error.message)"
   result=util.run([sys.executable,'-c',code,str(util.ROOT)],cwd=util.ROOT,timeout=300)
   if 'CREATORCUT_SETUP_READY' not in result.stdout:raise util.Fail(result.stdout.strip()[-300:] or 'The tool check did not confirm readiness. Click Check again; your files are saved.')
   _save({'state':'ready','updated':time.time(),'message':''})
  except Exception as e:
   util.log_exception('Editing readiness')
   _save({'state':'repair','updated':time.time(),'message':str(e)[:400] if isinstance(e,util.Fail) else 'The editing tools need a setup check. Your videos are saved.'})
  finally:_lock.release()
 try:threading.Thread(target=check,name='creatorcut-readiness',daemon=True).start()
 except RuntimeError:
  _save({'state':'repair','updated':time.time(),'message':'The setup check could not start. Close unused apps and check again.'});_lock.release()
 return _snapshot()
