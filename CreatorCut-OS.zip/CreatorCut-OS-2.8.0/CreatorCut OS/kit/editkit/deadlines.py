"""Bound short interactive waits across sleep/resume and wall-clock corrections."""
import time

def after(seconds):
    return (time.monotonic()+seconds,time.time()+seconds)

def remaining(deadline):
    # macOS monotonic time can pause in sleep. Wall time covers that gap;
    # monotonic time still bounds the wait if the clock moves backwards.
    return max(0.0,min(deadline[0]-time.monotonic(),deadline[1]-time.time()))
