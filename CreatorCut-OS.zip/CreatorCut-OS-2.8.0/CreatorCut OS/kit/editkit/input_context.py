"""Small immutable per-request inputs. Media bytes stay separately hash-bound by the render contract."""
import hashlib,json,re
from . import util
KEYS={'memory','resolved-style'}
def _file(p,key):
 if key not in KEYS:raise util.Fail('Unsupported saved input type.')
 from . import requests
 request=requests.active(p)
 return p/'edit-requests'/request['id']/'inputs'/(key+'.json') if request else None

def read(p,key):
 file=_file(p,key)
 if file is None or not file.exists():return None
 doc=util.read_json(file)
 if not isinstance(doc,dict) or not isinstance(doc.get('value'),dict) or doc.get('sha256')!=hashlib.sha256(json.dumps(doc.get('value'),sort_keys=True).encode()).hexdigest():raise util.Fail('A saved request input needs recovery. Keep the original request and start a fresh edit.')
 return doc['value']

def save(p,key,value):
 file=_file(p,key)
 if file is None:return value
 with util.file_guard(p/'.input-context.guard',timeout=5):
  existing=read(p,key)
  if existing is not None:return existing
  util.write_durable_json(file,{'value':value,'sha256':hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest()})
 return value

def project(cfg):
 pid=cfg.get('name')
 if not isinstance(pid,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,80}',pid):return None
 p=util.PROJECTS/pid
 return p if (p/'active-edit-request.json').is_file() else None
