"""CreatorCut's independently authored fallback design, not customer taste memory.

Resolve individual fields; explicit false/null/empty choices remain choices.
The editor translates natural-language/reference evidence into style-inputs.json;
this module never pretends to infer taste from arbitrary prose.
"""
from __future__ import annotations
import copy
from pathlib import Path
from . import util

ID = "creatorcut-signature"

def base() -> dict:
    return {
        "captions": {"enabled": True},
        "fonts": {
            "caption": {"family": "Inter Tight", "file": "kit/fonts/InterTight-Variable.ttf", "weight": 800},
            "accent": {"family": "Inter Tight", "file": "kit/fonts/InterTight-Variable.ttf", "weight": 900},
            "serif": {"family": "Instrument Serif", "file": "kit/fonts/InstrumentSerif-Italic.ttf", "weight": 400, "italic": True}},
        "styles": {
            "caption": {"font": "caption", "size": .044, "colour": "#FFFFFF", "tracking": -.035, "line": .96, "shadow": .4, "case": "as-is"},
            "accent": {"font": "accent", "size": .044, "colour": "#FAE67A", "tracking": -.035, "line": .96, "shadow": .4, "case": "as-is"},
            "big": {"font": "accent", "size": .115, "colour": "#FFFFFF", "tracking": -.04, "line": .94, "shadow": .35, "case": "as-is"},
            "serif": {"font": "serif", "size": .09, "colour": "#FAE67A", "line": 1.0, "shadow": .3, "case": "as-is"}},
        "motion": {"caption": {"ease": "signature-pop", "scale_from": 1.12, "ms": 180}, "card": {"enter": "pop", "exit": "shrink", "ms": 320}},
        "layout": {"caption_x": .5, "caption_y": .63, "safe": {"top": .115, "bottom": .235, "left": .04, "right": .095}, "behind_person": "selective_after_mask_review"},
        "colour": {"mode": "gentle_subject_safe", "film_grain": False},
        "sound": {"effects": True, "level": "subtle", "music": "none_until_usable_source_selected"},
        "graphics": {"density": "selective", "radius": .018, "tilt_degrees": 5, "real_playing_media": True}}


def resolve(inputs: dict | None = None) -> dict:
    """Only supplied leaves override; absence is unknown, false is a decision.

    Precedence, low to high: default, memory, preset, reference, explicit feature choices, brief.
    In particular an observed reference with no boxes has box=false, not an
    omitted field. Do not mark an unmeasured reference feature as observed.
    """
    effective = base()
    sources = {}
    def overlay(dst, src, origin, prefix=""):
        for key, value in src.items():
            path = prefix + key
            if isinstance(value, dict) and value:
                if not isinstance(dst.get(key), dict): dst[key] = {}
                overlay(dst[key], value, origin, path + ".")
            else:
                dst[key] = copy.deepcopy(value)
                sources[path] = origin
    overlay({}, effective, "default")
    for origin in ("memory", "preset", "reference", "choices", "brief"):
        values = (inputs or {}).get(origin, {})
        if not isinstance(values, dict): raise util.Fail("Style inputs must contain objects for each source.")
        overlay(effective, values, origin)
    # Recompute provenance at effective leaves after whole-branch replacement.
    def provenance(obj, prefix=""):
        result = {}
        for k, v in obj.items():
            path = prefix + k
            if isinstance(v, dict) and v: result.update(provenance(v, path + "."))
            else:
                candidates = [x for x in sources if path == x or path.startswith(x + ".")]
                result[path] = sources[max(candidates, key=len)] if candidates else "default"
        return result
    return {"schema": 1, "fallback": ID, "effective": effective, "sources": provenance(effective),
            "is_customer_preference": False, "review_required": True}


def write_direction(project: Path) -> dict:
    inputs = util.read_json(project / "style-inputs.json", default={})
    cfg = util.read_json(project / "project.json", default={})
    from . import styles
    sid = cfg.get("style")
    if sid and sid != ID and styles.style_path(sid):
        selected = styles.load(sid)
        def font(key):
            f = styles.resolve_font(key)
            path = Path(f["file"])
            return {"family": f["ass"], "file": str(path.relative_to(util.ROOT)) if path.is_relative_to(util.ROOT) else str(path),
                    "weight": 700 if f.get("bold") else 400, "italic": bool(f.get("italic"))}
        cap = selected["captions"]
        preset = {"fonts": {"caption": font(selected["fonts"]["caption"]), "accent": font(selected["fonts"]["heading"])},
                  "captions": {"enabled": cap.get("enabled", True)},
                  "styles": {"caption": {"size": cap.get("size",84)/1920, "colour": selected["colors"]["text"], "case":"upper" if cap.get("uppercase") else "as-is"},
                             "accent": {"colour": selected["colors"]["accent"]}},
                  "layout": {"caption_y":cap.get("y",.63)},
                  "motion": {"caption": {"ease":"pop" if cap.get("pop") else "cut", "scale_from":.94, "ms":160}},
                  "sound": {"effects": selected["sfx"].get("enabled",True)}}
        # A saved reviewed recipe owns its actual static typography, not the
        # generic style defaults returned for a user-created style name.
        from . import presets
        recipe = presets.recipe_context(sid, cfg.get("preset_version"))
        if recipe.get("kind") == "reviewed":
            frozen = util.read_json(util.ROOT / recipe["folder"] / "plan.json", default={})
            if not isinstance(frozen.get("fonts"), dict) or not frozen["fonts"] or not isinstance(frozen.get("styles"), dict) or not frozen["styles"]:
                raise util.Fail("This saved style is missing its typography recipe. Choose another saved version or save it again.")
            captured = {"fonts": copy.deepcopy(frozen["fonts"]), "styles": copy.deepcopy(frozen["styles"])}
            caption = next((item for item in frozen.get("items", []) if item.get("type") == "caption"), None)
            if caption:
                captured["layout"] = {"caption_" + key: caption[key] for key in ("x", "y") if isinstance(caption.get(key), (int, float))}
                if isinstance(caption.get("anim"), dict): captured["motion"] = {"caption": copy.deepcopy(caption["anim"])}
            preset = styles._deep_merge(preset, captured)
        inputs = dict(inputs, preset=styles._deep_merge(preset, inputs.get("preset", {})))
    d = resolve(inputs)
    enabled=cfg.get('captions',{}).get('enabled')
    if type(enabled) is bool:
        d['effective'].setdefault('captions',{})['enabled']=enabled
        d['sources']['captions.enabled']='choices'
    d["context"] = {"style": cfg.get("style"), "reference_style":cfg.get("reference_style"), "manual_library_choices":cfg.get("library_choices",{}), "brief": cfg.get("brief", {}),
                    "note": "Read the actual brief, selected recipe, memory and reference. Translate clear choices into style-inputs.json; unresolved fields use defaults. This snapshot is not approval or inferred memory."}
    util.write_json(project / "style-direction.json", d)
    return d


def seed(project: Path, canvas: dict, duration: float) -> dict:
    """A caption starter for an unmeasured project. Never a finished creative edit.

    No imaginary cutout, music or downloaded media is added. Agent must adapt
    to full brief/reference and write scene bindings before production review.
    """
    d = write_direction(project)
    e = d["effective"]
    word_doc = util.read_json(project / "words.json", default={"words": []})
    segs = util.read_json(project / "segments.json", default={"segments": []})
    if isinstance(segs, dict): segs = segs.get("segments", [])
    cuts = sorted(float(s.get("start", s.get("frame", 0) / canvas.get("fps", 30))) for s in segs)
    words = [w for w in word_doc["words"] if isinstance(w, dict) and str(w.get("w", "")).strip()]
    if e.get("captions", {}).get("enabled") is False: words = []
    groups, group = [], []
    for w in words:
        start = float(w.get("start", w.get("t", 0)))
        if group and (len(group) >= 3 or start - float(group[-1].get("end", start)) > .22 or any(float(group[-1].get("start", 0)) < c <= start for c in cuts)):
            groups.append(group); group = []
        group.append(w)
        if str(w["w"]).endswith((".", "!", "?")): groups.append(group); group = []
    if group: groups.append(group)
    items = []
    for n, group in enumerate(groups):
        a = max(0., float(group[0].get("start", 0)))
        b = min(duration, float(group[-1].get("end", a + .3)) + .06)
        if n + 1 < len(groups): b = min(b, float(groups[n+1][0].get("start", b)))
        if b <= a: continue
        items.append({"id": f"signature-caption-{n}", "type": "caption", "t0": a, "t1": b,
                      "x": e["layout"]["caption_x"], "y": e["layout"]["caption_y"], "reveal": "word",
                      "words": [{"w": str(w["w"]), "t": max(a, float(w.get("start", a))), "style": "accent" if w is group[-1] and len(str(w["w"]).strip(".!?,")) >= 5 and str(w["w"]).endswith((".", "!", "?")) else "caption"} for w in group],
                      "anim": copy.deepcopy(e["motion"].get("caption") or {"ease":"cut"})})
    return {"canvas": canvas, "duration": duration, "background": {"src": "cut.mp4", "zooms": []},
            "fonts": copy.deepcopy(e["fonts"]), "styles": copy.deepcopy(e["styles"]), "items": items,
            "audio": {"events": []}, "design_basis": {"fallback": ID, "starter_only": True, "sources": d["sources"]}}


def behind_placement(head_top: float, size: float, safe_top: float = .115) -> float | None:
    """Conservative centre position; actual glyph/moving-mask review is mandatory.

    Returns None if safe area cannot accommodate readable type. Inputs relative
    to canvas height. Intended for selected emphasis words, not every caption.
    """
    if not (0 < head_top < 1 and 0 < size < .3): return None
    centre = head_top - size * .25
    return centre if centre - size * .5 >= safe_top else None


def emphasis_item(text: str, t0: float, t1: float, head_tops: list[float], cutout_available: bool = False, size: float = .115, allow_behind: bool = True) -> dict:
    """Make one emphasis item using measured interval samples, no fake tracking.

    A false/uncertain cutout or moving head safely falls back to foreground.
    Caller must attach the real person_cutout to the plan when behind=True.
    """
    import math
    if not text.strip() or not (math.isfinite(t0) and math.isfinite(t1) and 0 <= t0 < t1):
        raise util.Fail("Emphasis needs real text and a valid spoken interval.")
    good = [v for v in head_tops if isinstance(v, (int, float)) and math.isfinite(v) and 0 < v < 1]
    y = behind_placement(min(good), size) if len(good) >= 3 and max(good)-min(good) <= .025 else None
    behind = bool(allow_behind and cutout_available and y is not None)
    return {"type":"caption", "t0":t0, "t1":t1, "x":.5, "y":y if behind else .63,
            "behind":behind, "words":[{"w":text, "t":t0, "style":"big"}], "reveal":"block",
            "anim":{"ease":"signature-pop", "scale_from":1.12, "ms":180}}


def complete_kit(kit: dict) -> dict:
    """Fill absent measured-kit fields without overwriting observed values.

    Do not invent a second accent style for a single-style reference.
    A supplied font must have its actual file, never a mismatched fallback.
    """
    from .styles import _deep_merge
    out = copy.deepcopy(kit)
    if not isinstance(out.get("styles"), dict) or not out["styles"]:
        raise util.Fail("No reference typography is measured yet.")
    d = base()
    fallback = {"role":"caption", "colour_family":"white", "size_class":"body", "count":1,
                "font": d["fonts"]["caption"], "size":d["styles"]["caption"]["size"], "colour":"#FFFFFF", "case":"as-is",
                "tracking":-.035, "line":.96, "examples":[],
                "anim":dict(d["motion"]["caption"],dy_from=0)}
    for key, style in out["styles"].items():
        if style.get("font") and not style["font"].get("file"):
            raise util.Fail("A measured reference font has no local file.", "Resolve that specific font instead of substituting a different family.")
        out["styles"][key] = _deep_merge(fallback, style)
    out["captions"] = _deep_merge({"words_per_block":{"median":3},"lines_max":1,"y_median":.63},out.get("captions",{}))
    return out
