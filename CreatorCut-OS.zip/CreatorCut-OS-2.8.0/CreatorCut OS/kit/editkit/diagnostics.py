"""Local bounded operational records, without prompts, tool arguments, media or credentials."""
import os,re,time,math,json
from . import util
LIMIT=500
_FIELDS={'method','item_type','state','previous','duration','outcome','stage','request_id'}

def record(project,kind,**fields):
 if not isinstance(project,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,80}',project):return
 row={'time':time.time(),'event':re.sub(r'[^A-Za-z0-9_.-]','',str(kind))[:64]}
 for key,value in fields.items():
  if key not in _FIELDS:continue
  if type(value) in (int,float) and math.isfinite(value):row[key]=value
  elif isinstance(value,str) and re.fullmatch(r'[A-Za-z0-9_./:-]{0,100}',value):row[key]=value
 file=util.ROOT/'.creatorcut-editor-control'/'diagnostics'/(project+'.jsonl')
 try:
  with util.file_guard(file.with_suffix('.guard'),timeout=.1):
   rows=[]
   if file.exists():
    with file.open('rb') as stream:
     stream.seek(0,2);size=stream.tell();stream.seek(max(0,size-262144));lines=stream.read().splitlines()
    for line in lines:
     try:
      item=json.loads(line)
      if isinstance(item,dict) and isinstance(item.get('event'),str):rows.append(item)
     except (ValueError,TypeError):pass
   rows=(rows+[row])[-LIMIT:];temporary=file.with_suffix('.partial')
   temporary.write_text(''.join(json.dumps(x,separators=(',',':'))+'\n' for x in rows));temporary.replace(file)
 except (OSError,util.Fail):pass  # Diagnostics must not interrupt a valid edit.

def bound(kind,**fields):record(os.environ.get('CREATORCUT_PROJECT'),kind,request_id=os.environ.get('CREATORCUT_REQUEST_ID',''),**fields)
