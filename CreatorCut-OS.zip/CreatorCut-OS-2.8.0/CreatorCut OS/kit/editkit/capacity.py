"""Render working-space estimates. Never treat capacity as a promise of completion."""
import math,os,shutil,sys
from pathlib import Path
from . import util

def mac_available(path):
 if sys.platform!='darwin':return None
 import ctypes as c
 url=value=error=None
 try:
  cf=c.CDLL('/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation')
  cf.CFURLCreateFromFileSystemRepresentation.argtypes=[c.c_void_p,c.c_char_p,c.c_long,c.c_bool];cf.CFURLCreateFromFileSystemRepresentation.restype=c.c_void_p
  cf.CFURLCopyResourcePropertyForKey.argtypes=[c.c_void_p,c.c_void_p,c.POINTER(c.c_void_p),c.POINTER(c.c_void_p)];cf.CFURLCopyResourcePropertyForKey.restype=c.c_bool
  cf.CFNumberGetValue.argtypes=[c.c_void_p,c.c_int,c.c_void_p];cf.CFNumberGetValue.restype=c.c_bool
  cf.CFRelease.argtypes=[c.c_void_p]
  raw=os.fsencode(Path(path).resolve());url=cf.CFURLCreateFromFileSystemRepresentation(None,raw,len(raw),True)
  if not url:return None
  key=c.c_void_p.in_dll(cf,'kCFURLVolumeAvailableCapacityForImportantUsageKey');value=c.c_void_p();error=c.c_void_p()
  if not cf.CFURLCopyResourcePropertyForKey(url,key,c.byref(value),c.byref(error)):return None
  amount=c.c_longlong()
  if cf.CFNumberGetValue(value,4,c.byref(amount)) and amount.value>=0:return amount.value
 except (OSError,AttributeError,ValueError):return None
 finally:
  if 'cf' in locals():
   for item in (value,error,url):
    if item:cf.CFRelease(item)
 return None

def available(path):
 measured=mac_available(path)
 return measured if measured is not None else shutil.disk_usage(path).free

def required(plan):
 def number(x,default):
  try:
   value=float(x)
   return value if math.isfinite(value) and value>0 else default
  except (TypeError,ValueError):return default
 canvas=plan.get('canvas') or {};duration=number(plan.get('duration'),60)
 pixels=number(canvas.get('w'),1080)*number(canvas.get('h'),1920)
 fps=number(canvas.get('fps'),30)
 # Conservative working estimate: frame captures + intermediate and final encodes,
 # plus a fixed reserve for review/browser work. Not an exact codec size prediction.
 return max(2_500_000_000,int(768*1024**2+duration*fps*pixels*.22+duration*4_000_000))

def check(p,plan):
 need=required(plan);free=available(p)
 if free<need:
  raise util.Fail(f'This video needs about {need/1e9:.2f} GB of working space; {free/1e9:.2f} GB is available.',
                  'Your footage and saved versions are kept. Run workflow clean-cache for this project or free space, then retry this step.')
 return dict(available_bytes=free,required_bytes=need,estimate=True)

def clean_project_cache(p):
 """Explicit recovery only: fixed regenerable paths, no candidates or versions."""
 from . import activity_store
 p=Path(p).resolve()
 with util.file_guard(p/'.chat-command.guard','Stop the current editing step before clearing its temporary files.'),util.project_lock(p,heavy_work=False):
  if any(row.get('project')==p.name and row.get('running') for row in activity_store.records()):
   raise util.Fail('Stop this editing step before clearing its temporary files.')
  removed=[]
  for name in ('.creatorcut-render-cache','work/.creatorcut-render-cache'):
   folder=p/name
   if folder.is_symlink() or not folder.resolve().is_relative_to(p):continue
   if folder.is_dir():shutil.rmtree(folder);removed.append(name)
  return {'removed':removed,'originals_and_versions_preserved':True,'next_step':'Retry the saved editing step.'}
