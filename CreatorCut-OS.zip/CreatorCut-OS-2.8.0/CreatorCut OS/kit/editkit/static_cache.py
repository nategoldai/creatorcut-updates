"""Small public-file-only compression/version cache; no customer content."""
from pathlib import Path
from collections import OrderedDict
import gzip,hashlib,threading
_LOCK=threading.Lock();_GZIP=OrderedDict();_BYTES=0;_VERSION={}
def signature(file):
 stat=file.stat();return (str(file),stat.st_ino,stat.st_mtime_ns,stat.st_ctime_ns,stat.st_size)
def compressed(file):
 global _BYTES
 file=Path(file);key=signature(file)
 with _LOCK:
  if key in _GZIP:_GZIP.move_to_end(key);return _GZIP[key]
 data=gzip.compress(file.read_bytes(),compresslevel=5)
 if signature(file)!=key:return data
 with _LOCK:
  if key not in _GZIP:_GZIP[key]=data;_BYTES+=len(data)
  while _BYTES>8*1024*1024 or len(_GZIP)>64:
   _,old=_GZIP.popitem(last=False);_BYTES-=len(old)
 return data
def version(folder):
 files=sorted(p for p in Path(folder).iterdir() if p.is_file());key=tuple(signature(p) for p in files)
 with _LOCK:
  if _VERSION.get('key')==key:return _VERSION['hash']
 value=hashlib.sha256(b''.join(p.read_bytes() for p in files)).hexdigest()[:16]
 with _LOCK:_VERSION.update(key=key,hash=value)
 return value
