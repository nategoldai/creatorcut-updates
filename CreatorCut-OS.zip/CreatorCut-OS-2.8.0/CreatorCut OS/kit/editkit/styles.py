"""Styles: load a style file, fill in defaults, apply the user's brand, resolve fonts and colours."""
from __future__ import annotations

import copy
import os
from pathlib import Path

from . import util

# Every font the engine knows. `ass` is the family name libass matches; `bold` is the ASS bold flag.
# Bundled fonts ship in kit/fonts. Pack fonts are downloaded by the installer (kit/setup) (Google Fonts, open licence).
FONTS = {
    "inter-tight": {"file": "InterTight-Variable.ttf", "ass": "Inter Tight", "bold": 1, "bundled": True},
    # bundled
    "inter":               {"file": "Inter-Regular.otf",        "ass": "Inter",                "bold": 0, "bundled": True},
    "inter-medium":        {"file": "Inter-Medium.otf",         "ass": "Inter Medium",         "bold": 0, "bundled": True},
    "inter-semibold":      {"file": "Inter-SemiBold.otf",       "ass": "Inter SemiBold",       "bold": 0, "bundled": True},
    "inter-bold":          {"file": "Inter-Bold.otf",           "ass": "Inter",                "bold": 1, "bundled": True},
    "inter-extrabold":     {"file": "Inter-ExtraBold.otf",      "ass": "Inter ExtraBold",      "bold": 0, "bundled": True},
    "inter-black":         {"file": "Inter-Black.otf",          "ass": "Inter Black",          "bold": 0, "bundled": True},
    "inter-display-semibold": {"file": "InterDisplay-SemiBold.otf", "ass": "Inter Display SemiBold", "bold": 0, "bundled": True},
    "inter-display-bold":  {"file": "InterDisplay-Bold.otf",    "ass": "Inter Display",        "bold": 1, "bundled": True},
    "inter-display-black": {"file": "InterDisplay-Black.otf",   "ass": "Inter Display Black",  "bold": 0, "bundled": True},
    "poppins":             {"file": "Poppins-Regular.ttf",      "ass": "Poppins",              "bold": 0, "bundled": True},
    "poppins-medium":      {"file": "Poppins-Medium.ttf",       "ass": "Poppins Medium",       "bold": 0, "bundled": True},
    "poppins-bold":        {"file": "Poppins-Bold.ttf",         "ass": "Poppins",              "bold": 1, "bundled": True},
    "lora":                {"file": "Lora-Variable.ttf",        "ass": "Lora",                 "bold": 0, "bundled": True},
    "lora-italic":         {"file": "Lora-Italic-Variable.ttf", "ass": "Lora",                 "bold": 0, "italic": 1, "bundled": True},
    # font pack (downloaded during setup)
    "anton":            {"file": "Anton-Regular.ttf",          "ass": "Anton",            "bold": 0, "fallback": "inter-display-black",
                         "url": "ofl/anton/Anton-Regular.ttf"},
    "bebas":            {"file": "BebasNeue-Regular.ttf",      "ass": "Bebas Neue",       "bold": 0, "fallback": "inter-display-black",
                         "url": "ofl/bebasneue/BebasNeue-Regular.ttf"},
    "archivo-black":    {"file": "ArchivoBlack-Regular.ttf",   "ass": "Archivo Black",    "bold": 0, "fallback": "inter-black",
                         "url": "ofl/archivoblack/ArchivoBlack-Regular.ttf"},
    "dm-serif":         {"file": "DMSerifDisplay-Regular.ttf", "ass": "DM Serif Display", "bold": 0, "fallback": "lora",
                         "url": "ofl/dmserifdisplay/DMSerifDisplay-Regular.ttf"},
    "instrument-serif": {"file": "InstrumentSerif-Regular.ttf", "ass": "Instrument Serif", "bold": 0, "fallback": "lora",
                         "url": "ofl/instrumentserif/InstrumentSerif-Regular.ttf"},
    "instrument-serif-italic": {"file": "InstrumentSerif-Italic.ttf", "ass": "Instrument Serif", "bold": 0, "italic": 1,
                         "fallback": "lora-italic", "url": "ofl/instrumentserif/InstrumentSerif-Italic.ttf"},
    "permanent-marker": {"file": "PermanentMarker-Regular.ttf", "ass": "Permanent Marker", "bold": 0, "fallback": "poppins-bold",
                         "url": "apache/permanentmarker/PermanentMarker-Regular.ttf"},
    "space-mono":       {"file": "SpaceMono-Bold.ttf",         "ass": "Space Mono",       "bold": 1, "fallback": "inter-bold",
                         "url": "ofl/spacemono/SpaceMono-Bold.ttf"},
    # creator font library (bundled, OFL/Apache; names normalised so each weight is its own family)
    "montserrat-black": {"file": "montserrat-900.ttf", "ass": "Montserrat Black CC", "bold": 0, "bundled": True, "label": "Montserrat Black"},
    "montserrat-extrabold": {"file": "montserrat-800.ttf", "ass": "Montserrat ExtraBold CC", "bold": 0, "bundled": True, "label": "Montserrat ExtraBold"},
    "tiktok-sans": {"file": "tiktok-sans-800.ttf", "ass": "TikTok Sans ExtraBold CC", "bold": 0, "bundled": True, "label": "TikTok Sans ExtraBold"},
    "tiktok-sans-black": {"file": "tiktok-sans-900.ttf", "ass": "TikTok Sans Black CC", "bold": 0, "bundled": True, "label": "TikTok Sans Black"},
    "oswald-bold": {"file": "oswald-700.ttf", "ass": "Oswald Bold CC", "bold": 0, "bundled": True, "label": "Oswald Bold"},
    "league-spartan": {"file": "league-spartan-800.ttf", "ass": "League Spartan ExtraBold CC", "bold": 0, "bundled": True, "label": "League Spartan ExtraBold"},
    "barlow-condensed": {"file": "barlow-condensed-800.ttf", "ass": "Barlow Condensed ExtraBold CC", "bold": 0, "bundled": True, "label": "Barlow Condensed ExtraBold"},
    "luckiest-guy": {"file": "luckiest-guy-400.ttf", "ass": "Luckiest Guy CC", "bold": 0, "bundled": True, "label": "Luckiest Guy"},
    "bangers": {"file": "bangers-400.ttf", "ass": "Bangers CC", "bold": 0, "bundled": True, "label": "Bangers"},
    "lilita-one": {"file": "lilita-one-400.ttf", "ass": "Lilita One CC", "bold": 0, "bundled": True, "label": "Lilita One"},
    "fredoka": {"file": "fredoka-700.ttf", "ass": "Fredoka Bold CC", "bold": 0, "bundled": True, "label": "Fredoka Bold"},
    "rubik-black": {"file": "rubik-900.ttf", "ass": "Rubik Black CC", "bold": 0, "bundled": True, "label": "Rubik Black"},
    "outfit": {"file": "outfit-700.ttf", "ass": "Outfit Bold CC", "bold": 0, "bundled": True, "label": "Outfit Bold"},
    "playfair": {"file": "playfair-display-700.ttf", "ass": "Playfair Display Bold CC", "bold": 0, "bundled": True, "label": "Playfair Display Bold"},
    "caveat": {"file": "caveat-700.ttf", "ass": "Caveat Bold CC", "bold": 0, "bundled": True, "label": "Caveat Bold"},
    "dm-sans": {"file": "dm-sans-700.ttf", "ass": "DM Sans Bold CC", "bold": 0, "bundled": True, "label": "DM Sans Bold"},
    "lexend": {"file": "lexend-800.ttf", "ass": "Lexend ExtraBold CC", "bold": 0, "bundled": True, "label": "Lexend ExtraBold"},
    "roboto-black": {"file": "roboto-900.ttf", "ass": "Roboto Black CC", "bold": 0, "bundled": True, "label": "Roboto Black"},
    "open-sans": {"file": "open-sans-800.ttf", "ass": "Open Sans ExtraBold CC", "bold": 0, "bundled": True, "label": "Open Sans ExtraBold"},
    "nunito-black": {"file": "nunito-900.ttf", "ass": "Nunito Black CC", "bold": 0, "bundled": True, "label": "Nunito Black"},
    "kanit": {"file": "kanit-800.ttf", "ass": "Kanit ExtraBold CC", "bold": 0, "bundled": True, "label": "Kanit ExtraBold"},
    "raleway-black": {"file": "raleway-900.ttf", "ass": "Raleway Black CC", "bold": 0, "bundled": True, "label": "Raleway Black"},
    "sora": {"file": "sora-800.ttf", "ass": "Sora ExtraBold CC", "bold": 0, "bundled": True, "label": "Sora ExtraBold"},
    "syne": {"file": "syne-800.ttf", "ass": "Syne ExtraBold CC", "bold": 0, "bundled": True, "label": "Syne ExtraBold"},
    "poppins-black": {"file": "poppins-900.ttf", "ass": "Poppins Black CC", "bold": 0, "bundled": True, "label": "Poppins Black"},
    "poppins-extrabold": {"file": "poppins-800.ttf", "ass": "Poppins ExtraBold CC", "bold": 0, "bundled": True, "label": "Poppins ExtraBold"},
}

FONT_PACK_BASE = "https://github.com/google/fonts/raw/main/"

DEFAULTS = {
    "id": "custom", "name": "Custom", "tagline": "", "best_for": [], "energy": 3,
    "fonts": {"caption": "inter-black", "heading": "inter-display-black", "body": "inter-semibold"},
    "colors": {"text": "#FFFFFF", "accent": "#FFD60A", "outline": "#000000", "card": "#111113",
               "card_text": "#FFFFFF", "muted": "#A1A1AA", "bg": "#0B0B0C"},
    "captions": {"enabled": True, "mode": "highlight", "max_words": 3, "max_chars": 18, "size": 84,
                 "y": 0.66, "uppercase": False, "outline": 5, "shadow": 2, "box": False,
                 "box_color": "#000000", "box_alpha": 0.55, "highlight": "both", "pop": True,
                 "keyword_accent": True, "spacing": 0},
    "graphics": {"card_radius": 26, "card_alpha": 0.94, "shadow": True, "entrance": "slide",
                 "title_case": False,
                 "sticker": False, "position": "top", "density": "medium", "accent_bar": True},
    "zoom": {"punch_in": 1.07, "pattern": "alternate", "emphasis": 1.14, "focus_y": 0.38},
    "grade": "natural",
    "sfx": {"enabled": True, "volume": 0.32, "entrance": "whoosh", "emphasis": "pop", "counter": "tick",
            "cta": "ding", "list": "click"},
    "pacing": {"max_pause": 0.22, "remove_fillers": True, "lead_in": 0.06, "tail": 0.14},
    "progress_bar": False,
    "music": {"volume": 0.16, "duck": True},
}


def _deep_merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def style_path(style_id: str) -> Path | None:
    for d in (util.USER_STYLES_DIR, util.STYLES_DIR):
        p = d / f"{style_id}.json"
        if p.exists():
            return p
    return None


def list_styles() -> list[dict]:
    seen, out = set(), []
    for d, origin in ((util.USER_STYLES_DIR, "yours"), (util.STYLES_DIR, "toolkit")):
        if not d.exists():
            continue
        for p in sorted(d.glob("*.json")):
            if p.stem in seen:
                continue
            seen.add(p.stem)
            s = util.read_json(p)
            out.append({"id": p.stem, "name": s.get("name", p.stem), "tagline": s.get("tagline", ""),
                        "best_for": s.get("best_for", []), "energy": s.get("energy", 3), "origin": origin,
                        "colors": s.get("colors", {}), "hidden": bool(s.get("hidden"))})
    return out


def load(style_id: str, apply_brand: bool = True) -> dict:
    p = style_path(style_id)
    if p is None:
        names = ", ".join(s["id"] for s in list_styles())
        raise util.Fail(f"There's no style called '{style_id}'.", f"Available styles: {names}")
    raw = util.read_json(p)
    s = _deep_merge(DEFAULTS, raw)
    s["id"] = p.stem
    if apply_brand:
        prof = util.load_profile()
        brand = prof.get("brand", {})
        if brand.get("accent") and s.get("use_brand_accent", True):
            s["colors"]["accent"] = brand["accent"]
    return s


def for_project(cfg: dict) -> dict:
    """The project's style plus any per-video tweaks saved under "overrides" in project.json."""
    from . import input_context,refs
    project=input_context.project(cfg)
    if project is not None:
        saved=input_context.read(project,'resolved-style')
        if saved is not None:return saved
    s = load(cfg.get("style") or "creatorcut-signature")
    if cfg.get('reference_style'):
        reference_file=style_path(cfg['reference_style'])
        if reference_file is None:raise util.Fail('The selected reference style is missing. Scan the reference again; no generic style was substituted.')
        raw=util.read_json(reference_file)
        # Only supplied reference values replace the preset. Do not fill defaults a second time.
        s=_deep_merge(s,raw)
    result=_deep_merge(s, cfg.get("overrides") or {})
    if project is not None and os.environ.get('CREATORCUT_PROJECT')==project.name and os.environ.get('CREATORCUT_MANAGED_EDITOR')=='1':
        attached=refs.for_project(project.name)
        ready=not attached or cfg.get('reference_style') and all(ref.get('status')=='done' and not ref.get('study_error') for ref in attached)
        if ready:return input_context.save(project,'resolved-style',result)
    return result


# ----------------------------------------------------------------- fonts ----
def resolve_font(key: str) -> dict:
    """Use the exact requested installed font; never silently substitute another."""
    f=FONTS.get(key)
    if f is None:raise util.Fail('The selected font is not available: '+str(key),'Choose an installed font explicitly.')
    path=util.FONTS_DIR/f['file']
    if not path.is_file():raise util.Fail('The selected font file is missing: '+f['file'],'Repair the font download before rendering; no substitute was used.')
    return {'key':key,'file':str(path),'ass':f['ass'],'bold':f.get('bold',0),'italic':f.get('italic',0),'requested':key}


_METRICS_FILE = util.FONTS_DIR / "metrics.json"
REF_FONT = "Inter-Black.otf"


def _load_metrics() -> dict:
    try:
        return util.read_json(_METRICS_FILE, default={})
    except util.Fail:
        return {}


def _measure(font: dict) -> dict:
    """Render 'HHHH' with libass at size 200 and measure the real pixels (cap height and width)."""
    import tempfile
    from PIL import Image
    from . import ass as assmod
    tmp = Path(tempfile.mkdtemp(prefix="aied-font-"))
    doc = assmod.Doc(1600, 600)
    doc.add_style("M", font, 200, primary="#FFFFFF", align=5)
    doc.dialogue(0, 1, "{\\an5\\pos(800,300)\\bord0\\shad0}HHHH", "M")
    (tmp / "m.ass").write_text(doc.render(), encoding="utf-8")
    fontsdir = Path(font["file"]).parent
    util.run([util.ffmpeg_bin(), "-y", "-hide_banner", "-f", "lavfi", "-i", "color=c=black:s=1600x600:d=1",
              "-vf", f"ass=m.ass:fontsdir={os.path.relpath(fontsdir, tmp).replace(os.sep, '/')}", "-frames:v", "1", "m.png"], cwd=tmp)
    im = Image.open(tmp / "m.png").convert("L").point(lambda v: 255 if v > 128 else 0)
    bbox = im.getbbox() or (0, 0, 1, 1)
    return {"cap": bbox[3] - bbox[1], "width": bbox[2] - bbox[0]}


def size_mult(font: dict) -> float:
    """libass sizes text by the font's internal line metrics, so some fonts look small. Normalise every font
    to Inter's visual size. Measured once per font and cached in kit/fonts/metrics.json."""
    m = _load_metrics()
    name = Path(font["file"]).name
    if name not in m or REF_FONT not in m:
        try:
            for fname, fobj in ((REF_FONT, {"file": str(util.FONTS_DIR / REF_FONT), "ass": "Inter Black", "bold": 0}), (name, font)):
                if fname not in m:
                    m[fname] = _measure(fobj)
            util.write_json(_METRICS_FILE, m)
        except Exception:
            return 1.0
    ref, cur = m[REF_FONT]["cap"], m[name]["cap"]
    return max(0.7, min(1.6, ref / cur)) if cur else 1.0


def width_fix(font: dict) -> float:
    """Correction between Pillow's width estimate and libass's real width for this font."""
    m = _load_metrics()
    name = Path(font["file"]).name
    rec = m.get(name)
    if not rec:
        return 1.0
    if "wfix" not in rec:
        try:
            from PIL import ImageFont
            ft = ImageFont.truetype(font["file"], 200)
            asc, desc = ft.getmetrics()
            est = ft.getlength("HHHH") * 200 / float(asc + desc)
            rec["wfix"] = round(rec["width"] / est, 4) if est else 1.0
            util.write_json(_METRICS_FILE, m)
        except Exception:
            return 1.0
    return rec["wfix"]


def fs(font: dict, size: float) -> float:
    """ASS font size that gives the same visual size as Inter at `size`."""
    return size * size_mult(font)


def calibrate_all() -> int:
    """Measure every installed font once (so sizes look the same in every font). Returns how many were measured."""
    n = 0
    for key, f in FONTS.items():
        if (util.FONTS_DIR / f["file"]).exists():
            font = resolve_font(key)
            size_mult(font)
            width_fix(font)
            n += 1
    util.ok(f"Fonts calibrated ({n})")
    return n


def missing_pack_fonts() -> list[str]:
    return [k for k, f in FONTS.items() if not f.get("bundled") and not (util.FONTS_DIR / f["file"]).exists()]


def hex_rgb(h: str) -> tuple[int, int, int]:
    h = (h or "#000000").lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def ass_color(h: str) -> str:
    """#RRGGBB -> ASS &HBBGGRR&"""
    r, g, b = hex_rgb(h)
    return f"&H{b:02X}{g:02X}{r:02X}&"


def ass_alpha(opacity: float) -> str:
    """Opacity 0-1 -> ASS alpha (00 = opaque, FF = invisible)."""
    return f"&H{int(round((1 - max(0.0, min(1.0, opacity))) * 255)):02X}&"


def luminance(h: str) -> float:
    r, g, b = (c / 255.0 for c in hex_rgb(h))
    return 0.2126 * r + 0.7152 * g + 0.0722 * b
