"""Health check and installer. `doctor` explains in plain words what's ready and how to fix what isn't."""
from __future__ import annotations

import importlib
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

from . import styles as st, util

VENV = util.ROOT / ".venv"


def venv_python() -> Path:
    return VENV / ("Scripts/python.exe" if util.os_name() == "windows" else "bin/python")


INSTALL_CMD = {"windows": "powershell -NoProfile -ExecutionPolicy Bypass -File kit/setup/install.ps1"}.get(
    util.os_name(), "bash kit/setup/install.sh")


def ffmpeg_install_hint() -> str:
    return f"Run the installer again: {INSTALL_CMD}  (it downloads a private copy of FFmpeg into kit/bin; no password needed)"


def _model_cached(model: str) -> bool:
    from . import speech_models
    return speech_models.cached(model)


def doctor() -> dict:
    checks = []

    def add(key, label, okay, detail="", fix="", required=True):
        checks.append({"key": key, "label": label, "ok": bool(okay), "detail": detail, "fix": fix, "required": required})

    try:
        from editor.audio_check import check
        check(util.ROOT);add('speech_decoder','Speech decoder',True,'ready')
    except Exception:add('speech_decoder','Speech decoder',False,'needs setup','Run setup again to finish the speech tools.')

    pyv = sys.version_info
    add("python", "Private Python 3.12", pyv[:2] == (3, 12), f"{pyv.major}.{pyv.minor}.{pyv.micro}",
        f"Run the installer: {INSTALL_CMD}")
    if pyv >= (3, 14):
        checks[-1]["detail"] += " (very new; if transcription won't install, use Python 3.12)"
    add("venv", "Private Python environment (.venv)", venv_python().exists(), util.rel(VENV), f"Run the installer: {INSTALL_CMD}")

    ff = util.which("ffmpeg")
    try:
        ff = util.ffmpeg_bin()
        ver = util.run([ff, "-hide_banner", "-version"]).stdout.splitlines()[0]
        has_ass = util.ffmpeg_has_filter("ass")
        add("ffmpeg", "FFmpeg (cuts and renders video)", True, " ".join(ver.split()[:3]).replace(" version", ""))
        add("libass", "FFmpeg captions & graphics support (libass)", has_ass,
            "ready" if has_ass else "your FFmpeg build can't draw captions",
            ffmpeg_install_hint())
        add("hdr", "iPhone HDR colour conversion (zscale)", util.ffmpeg_has_filter("zscale"),
            "optional", "Optional. Or turn off HDR video on your phone camera.", required=False)
    except util.Fail:
        add("ffmpeg", "FFmpeg (cuts and renders video)", False, "not installed", ffmpeg_install_hint())
    try:
        util.ffprobe_bin()
        add("ffprobe", "ffprobe (reads video info)", True, "ready")
    except util.Fail:
        add("ffprobe", "ffprobe (reads video info)", False, "not installed", "Comes with FFmpeg: " + ffmpeg_install_hint())
    from . import motion
    m = motion.status()
    add("motion", "Motion graphics (HyperFrames, Remotion, browser)", m["ready"], m["detail"], f"Run the installer: {INSTALL_CMD}")
    pack = util.KIT / "render/node_modules/hyperframes-library"
    pinned = util.read_json(pack / "package.json", default={}).get("version") == "0.8.34" and (pack / "bin/hyperframes.mjs").is_file()
    add("style_renderer", "Style and effect renderer", pinned, "ready" if pinned else "not installed", f"Run the installer: {INSTALL_CMD}")
    add("vision", "Reference reading (text recognition, person detection)", motion.vision_ready(), "ready" if motion.vision_ready() else "not installed",
        f"Run the installer: {INSTALL_CMD}")
    from . import library
    matte_ready=library.matting_ready()
    add('matting','Person cutout model',matte_ready,'ready' if matte_ready else 'needs setup','Finish CreatorCut setup to download its private cutout model.')

    for mod, label in (("PIL", "Pillow (images, covers)"), ("faster_whisper", "faster-whisper (hears every word)")):
        try:
            importlib.import_module(mod)
            add(mod, label, True, "ready")
        except Exception:
            add(mod, label, False, "not installed", f"Run the installer: {INSTALL_CMD}")

    from . import editor
    label='Claude' if editor.provider_name()=='claude' else 'Codex'
    from . import chat_execution
    available=chat_execution.mode()=='chat' or editor.runtime_available()
    add('editor_cli','AI editor ('+label+')',available,'installed' if available else 'not installed','Run setup to install and connect '+label+'. Your account usage limits apply.')
    prof = util.load_profile()
    model = prof.get("whisper_model", "small")
    add("model", f"Speech model '{model}' downloaded", _model_cached(model), "downloads once (~500 MB)",
        "edit.py model (finish the private download before editing)")
    missing = st.missing_pack_fonts()
    add("fonts", "Premium font pack", not missing, "all fonts ready" if not missing else f"{len(missing)} fonts to download",
        "edit.py fonts")
    sfx = list(util.SFX_DIR.glob("*.wav"))
    add("sfx", "Sound-effects library", len(sfx) >= 6, f"{len(sfx)} sounds", "edit.py sfx")
    add("profile", "Your setup answers (name)", bool(prof.get("name")),
        prof.get("name", "not set yet"), "Open the Studio and tell it your name (first screen)", required=False)
    free = shutil.disk_usage(util.ROOT).free / 1e9
    add("disk", "Free disk space", free > 3, f"{free:.0f} GB free", "Free up a few GB; video files are big.", required=False)

    ready = all(c["ok"] for c in checks if c["required"])
    result = {"ready": ready, "os": util.os_name(), "machine": platform.machine(), "checks": checks}
    util.write_json(util.STUDIO_OUT / "checks.json", result)
    return result


def print_doctor(res: dict) -> None:
    util.say(f"\nCreatorCut OS: system check ({res['os']}, {res['machine']})\n")
    for c in res["checks"]:
        mark = "✓" if c["ok"] else ("✗" if c["required"] else "○")
        util.say(f" {mark} {c['label']}: {c['detail']}")
        if not c["ok"] and c["fix"]:
            util.say(f"     fix → {c['fix']}")
    util.say("\n" + ("READY: everything needed is installed." if res["ready"] else "NOT READY: fix the ✗ items above."))


def install(model: str | None = None, skip_model: bool = False) -> None:
    """Everything is installed by kit/setup/install.sh (Mac/Linux) or install.ps1 (Windows); this just runs it."""
    if util.os_name() == "windows":
        cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(util.KIT / "setup" / "install.ps1")]
    else:
        cmd = ["bash", str(util.KIT / "setup" / "install.sh")]
    if util.os_name()=='windows':raise util.Fail('Mac only for now. Your files have not been changed.')
    sys.exit(subprocess.call(cmd, cwd=str(util.ROOT)))


def install_stage2(model: str | None, skip_model: bool) -> None:
    download_fonts()
    from . import styles as st2
    util.step("Calibrating fonts so every style looks right…")
    st2.calibrate_all()
    from . import sfx
    sfx.ensure()
    from . import library
    util.step('Getting the clean subject model ready (15 MB once)…')
    library.ensure_matting()
    if not skip_model:
        prof = util.load_profile()
        model = model or prof.get("whisper_model", "small")
        util.step(f"Downloading the speech model '{model}' (one time, ~250-500 MB)…")
        try:
            from faster_whisper import WhisperModel  # type: ignore
            from . import speech_models
            speech_models.install(model)
            util.ok("Speech model ready")
        except Exception as e:
            util.warn(f"Couldn't download the speech model yet ({e}). Run setup again to finish the private model download.")
    print_doctor(doctor())


def download_fonts() -> None:
    import ssl
    import urllib.request
    missing = st.missing_pack_fonts()
    if not missing:
        util.ok("Font pack already installed")
        return
    try:
        import certifi  # type: ignore
        ctx = ssl.create_default_context(cafile=certifi.where())
    except Exception:
        ctx = ssl.create_default_context()
    got = 0
    for key in missing:
        f = st.FONTS[key]
        url = st.FONT_PACK_BASE + f["url"]
        dest = util.FONTS_DIR / f["file"]
        try:
            from . import bounded_http
            data=bounded_http.get(url,seconds=60,max_bytes=25_000_000)
            if len(data) < 10000:
                raise ValueError("file too small")
            dest.write_bytes(data)
            got += 1
        except Exception as e:
            util.warn(f"Couldn't download {f['file']} ({e}); run setup again to finish this font; no substitute will be used.")
    util.ok(f"Downloaded {got} premium fonts (Google Fonts, open licence)")


def download_model(model: str | None = None) -> bool:
    prof = util.load_profile()
    model = model or prof.get("whisper_model", "small")
    if _model_cached(model):
        util.ok(f"Speech model '{model}' already downloaded")
        return True
    util.step(f"Downloading the speech model '{model}' (one time, about 500 MB)…")
    try:
        from faster_whisper import WhisperModel  # type: ignore
        from . import speech_models
        speech_models.install(model)
        util.ok("Speech model ready")
        return True
    except Exception as e:
        util.warn(f"Couldn't download the speech model yet ({str(e)[:160]}). Run setup again to finish the private speech model.")
        return False


def ensure_render_compatibility():
    """Migrate older updater versions before any editor session is opened.

    Older releases did not track adapter-only dependency changes. Startup is
    therefore a second installation gate, not an editing-model workaround.
    """
    render=util.KIT/'render';helper=util.KIT/'tools/patch_render_runtime.py'
    if not (render/'node_modules/hyperframes/package.json').is_file():return
    if not helper.is_file():raise util.Fail('Finish updating the video tools before opening Studio.')
    import subprocess,sys,hashlib,json
    stamp=util.STUDIO_OUT/'renderer-compatibility.json'
    files=[helper,render/'node_modules/hyperframes/package.json',*(render/'node_modules/hyperframes/dist').glob('chunk-*.js'),render/'node_modules/hyperframes-library/package.json',render/'node_modules/hyperframes-library/dist/cli.js',render/'node_modules/hyperframes-library/dist/fontLocalizeCli.js']
    signature={str(p.relative_to(util.ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
    try:
        if util.read_json(stamp,default={}).get('files')==signature:return
    except (OSError,util.Fail):pass
    # A verified existing patch needs no write lock, even while another video renders.
    try:
        subprocess.run([sys.executable,str(helper),str(render),'--verify'],cwd=util.ROOT,check=True,capture_output=True,text=True,timeout=15)
        util.write_json(stamp,{'files':signature});return
    except (OSError,subprocess.SubprocessError):pass
    with util.file_guard(util.STUDIO_OUT/'.heavy.guard','A video is still rendering. Finish it before repairing the video tools.',timeout=1):
        try:subprocess.run([sys.executable,str(helper),str(render)],cwd=util.ROOT,check=True,capture_output=True,text=True,timeout=60)
        except (OSError,subprocess.SubprocessError) as error:
            util.log('Renderer compatibility setup: '+str(error))
            raise util.Fail('The video tools need repair before editing can start.','Run setup again; your videos and presets are kept.') from error
        signature={str(p.relative_to(util.ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
        util.write_json(stamp,{'files':signature})


def require_open_ready() -> dict:
    """Verify editing readiness; reopening Studio runs this after serving its shell.

    The first installer still requires these checks before it announces completion.
    """
    ensure_render_compatibility()
    from . import speech_models
    speech_models.migrate_legacy(util.load_profile().get('whisper_model') or 'small')
    res=doctor()
    if any(c['key']=='matting' and not c.get('ok') for c in res['checks']) and all(c.get('ok') for c in res['checks'] if c.get('required') and c['key']!='matting'):
        # An older installation has the large model, not the launch model.
        # Restore the new verified asset during setup, before Make is enabled.
        from . import library
        library.ensure_matting()
        res=doctor()
    required={'model','fonts','sfx'}
    missing=[c['label'] for c in res['checks'] if (c.get('required') or c['key'] in required) and not c.get('ok')]
    if missing:
        raise util.Fail('Your editing tools need one more step. In your chat, say: Finish CreatorCut setup. Your videos are saved.',
                        'Missing tools: '+', '.join(missing))
    import time
    util.write_json(util.STUDIO_OUT/'setup-ready.json',{'state':'ready','version':(util.KIT/'VERSION').read_text().strip(),'updated':time.time()})
    return res
