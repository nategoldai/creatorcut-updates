"""Graphics tracker: every card, screenshot and burst of images in a reference, with its motion.

Text is measured by refmap; this measures the rest of the editing: B-roll on cards, image clouds, white UI cards.
How it works (frames at 10 a second, 360 px wide):
  1. something appears: inside one shot, a region changes at once and is (nearly) a rectangle -> a new graphic
     (a cut changes the whole frame; arms and faces aren't rectangles; captions are thin and are excluded by OCR)
  2. follow it: template matching frame by frame, near where it was, until it's gone or a cut
  3. describe it: size, centre, tilt, how long it stays, how it entered (scale / offset in its first frames), how it
     drifts while visible, whether it sits behind the person (the person's outline covers part of it), what it holds
     (video, still, white UI card)
  4. many small images appearing within half a second = a burst (count, spread, size)
Everything is in fractions of the frame and seconds, so the planner can place the creator's B-roll the same way."""
from __future__ import annotations

from pathlib import Path

from . import util

SW = 360                      # analysis width


def _gray(path: Path, sw: int = SW):
    import numpy as np
    from PIL import Image
    im = Image.open(path).convert("RGB")
    sh = int(im.height * sw / im.width)
    rgb = np.asarray(im.resize((sw, sh)), dtype=np.uint8)
    g = (rgb[..., 0] * 0.299 + rgb[..., 1] * 0.587 + rgb[..., 2] * 0.114).astype(np.uint8)
    return rgb, g


def _rect_components(mask, min_area: float, max_area: float, min_fill: float = 0.62):
    """Connected regions of a change mask that are (rotated) rectangles: (cx, cy, w, h, angle, fill) in pixels."""
    import cv2
    import numpy as np
    h, w = mask.shape
    m = cv2.morphologyEx(mask.astype(np.uint8) * 255, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    cnts, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    out = []
    for c in cnts:
        a = cv2.contourArea(c)
        if a < min_area * w * h or a > max_area * w * h:
            continue
        (cx, cy), (rw, rh), ang = cv2.minAreaRect(c)
        if rw < 2 or rh < 2:
            continue
        fill = a / (rw * rh)
        if fill < min_fill:
            continue
        while ang > 45:                              # OpenCV versions report 0..90 or -90..0: make it a small signed tilt
            ang -= 90
            rw, rh = rh, rw
        while ang <= -45:
            ang += 90
            rw, rh = rh, rw
        ar = rh / rw
        if not 0.3 < ar < 3.2:
            continue
        out.append((cx, cy, rw, rh, ang, fill))
    return out


def _text_boxes(ocr_frame: list[dict], w: int, h: int):
    return [(b["x"] * w, b["y"] * h, (b["x"] + b["w"]) * w, (b["y"] + b["h"]) * h) for b in (ocr_frame or [])]


def _mostly_text(c, tboxes) -> bool:
    cx, cy, rw, rh = c[:4]
    x0, y0, x1, y1 = cx - rw / 2, cy - rh / 2, cx + rw / 2, cy + rh / 2
    inter = 0.0
    for a0, b0, a1, b1 in tboxes:
        ix, iy = max(0, min(x1, a1) - max(x0, a0)), max(0, min(y1, b1) - max(y0, b0))
        inter += ix * iy
    return inter > 0.45 * rw * rh


def track(frames: list[Path], cuts: list[float], ocr: list[list[dict]] | None = None, fps: float = 10.0,
          person_mask=None, progress=None) -> dict:
    """frames: the reference's frames at `fps`. Returns {"cards": [...], "bursts": [...], "stats": {...}}."""
    import cv2
    import numpy as np
    say = progress or (lambda *_: None)
    if len(frames) < 3:
        return {"cards": [], "bursts": [], "stats": {}}
    grays, rgbs = [], []
    for k, f in enumerate(frames):
        rgb, g = _gray(f)
        grays.append(g)
        rgbs.append(rgb)
        if k % 10 == 0 or k == len(frames) - 1:
            say(f'Read {k + 1} of {len(frames)} tracking frames', 0.08 * (k + 1) / len(frames))
    H, W = grays[0].shape
    cut_frames = {int(round(c * fps)) for c in cuts}
    near_cut = lambda i: any(abs(i - c) <= 1 for c in cut_frames)
    say("Finding cards and images…", 0.1)

    # 1. appearances
    births = []                                       # (frame, comp)
    small_births = []
    for i in range(1, len(grays)):
        if i % 10 == 0 or i == len(grays) - 1:
            say(f'Following image changes in frame {i + 1} of {len(grays)}', 0.1 + 0.2 * i / len(grays))
        if near_cut(i):
            continue
        d = cv2.absdiff(grays[i], grays[i - 1])
        if d.mean() > 38:                             # the whole picture changed: a cut we didn't catch
            continue
        mask = d > 28
        tb = _text_boxes(ocr[i] if ocr and i < len(ocr) else [], W, H)
        for c in _rect_components(mask, 0.02, 0.55):
            if c[2] < 0.12 * W or c[3] < 0.08 * H or _mostly_text(c, tb):
                continue
            births.append((i, c))
        for c in _rect_components(mask, 0.0025, 0.02, 0.55):
            if not _mostly_text(c, tb):
                small_births.append((i, c))

    # 2. follow each appearance (merge appearances that are the same card growing in)
    cards = []
    taken = []                                        # (frame range, box) already tracked
    for birth_index, (i, c) in enumerate(births):
        say(f'Following image {birth_index + 1} of {len(births)}', 0.3 + 0.45 * birth_index / max(1, len(births)))
        cx, cy, rw, rh, ang, fill = c
        if any(a <= i <= b and abs(cx - bx) < rw * 0.5 and abs(cy - by) < rh * 0.5 for a, b, bx, by in taken):
            continue
        # settle: the box a couple of frames later is the card at rest
        j = min(len(grays) - 1, i + 2)
        x0, y0 = int(max(0, cx - rw / 2)), int(max(0, cy - rh / 2))
        x1, y1 = int(min(W, cx + rw / 2)), int(min(H, cy + rh / 2))
        if x1 - x0 < 8 or y1 - y0 < 8:
            continue
        tmpl = grays[j][y0:y1, x0:x1]
        path = [(i, cx, cy)]
        last = (x0, y0)
        end = i
        for k in range(i + 1, len(grays)):
            if k % 10 == 0:
                say(f'Tracked image {birth_index + 1} to frame {k + 1}', 0.3 + 0.45 * (birth_index + (k - i) / max(1, len(grays) - i)) / max(1, len(births)))
            if k in cut_frames:
                break
            sx0, sy0 = max(0, last[0] - int(0.12 * W)), max(0, last[1] - int(0.08 * H))
            sx1, sy1 = min(W, last[0] + (x1 - x0) + int(0.12 * W)), min(H, last[1] + (y1 - y0) + int(0.08 * H))
            win = grays[k][sy0:sy1, sx0:sx1]
            if win.shape[0] < tmpl.shape[0] or win.shape[1] < tmpl.shape[1]:
                break
            r = cv2.matchTemplate(win, tmpl, cv2.TM_CCOEFF_NORMED)
            _, score, _, loc = cv2.minMaxLoc(r)
            if score < 0.45:
                break
            last = (sx0 + loc[0], sy0 + loc[1])
            path.append((k, last[0] + (x1 - x0) / 2, last[1] + (y1 - y0) / 2))
            end = k
            if k - j > 3 and k % 3 == 0:              # refresh slowly: cards drift and tilt
                tmpl = grays[k][last[1]:last[1] + (y1 - y0), last[0]:last[0] + (x1 - x0)]
                if tmpl.shape[0] < 8 or tmpl.shape[1] < 8:
                    break
        dur = (end - i + 1) / fps
        if dur < 0.3:
            continue
        taken.append((i, end, cx, cy))
        mid = (i + end) // 2
        # what it holds: a white UI card, a still, or a moving clip
        patch = rgbs[mid][int(max(0, cy - rh / 2)):int(min(H, cy + rh / 2)), int(max(0, cx - rw / 2)):int(min(W, cx + rw / 2))]
        white = float((patch.mean(axis=2) > 225).mean()) if patch.size else 0
        if end - i >= 3:
            a = grays[i + 1][y0:y1, x0:x1].astype(np.float32)
            b = grays[min(end, i + 3)][y0:y1, x0:x1].astype(np.float32)
            moving = a.shape == b.shape and float(np.abs(a - b).mean()) > 6
        else:
            moving = False
        kind = "ui" if white > 0.45 else ("clip" if moving else "image")
        if rw / W > 0.75 and rh / H > 0.45:
            kind = "fullscreen"                      # a cutaway over the whole picture, not a card
        behind = None
        if person_mask is not None:
            try:
                pm = person_mask(str(frames[mid]))
                if pm is not None:
                    pm = cv2.resize(pm, (W, H)) > 127
                    n, lab, st, _ = cv2.connectedComponentsWithStats(pm.astype(np.uint8), 8)
                    if n > 1:
                        main = 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA]))
                        reg = (lab == main)[int(max(0, cy - rh / 2)):int(min(H, cy + rh / 2)), int(max(0, cx - rw / 2)):int(min(W, cx + rw / 2))]
                        behind = bool(reg.size and reg.mean() > 0.05)
            except Exception as e:
                util.log(f"reftrack mask: {e}")
        p0, p1 = path[min(len(path) - 1, 2)], path[-1]
        cards.append({
            "t_in": round(i / fps, 2), "t_out": round((end + 1) / fps, 2), "duration": round(dur, 2),
            "x": round(cx / W, 3), "y": round(cy / H, 3), "w": round(rw / W, 3), "h": round(rh / H, 3), "rot": round(-ang, 1),
            "kind": kind, "behind": behind,
            "drift": {"dx": round((p1[1] - p0[1]) / W, 3), "dy": round((p1[2] - p0[2]) / H, 3)},
        })

    # 3. bursts: many small images within half a second
    say("Finding bursts of images…", 0.8)
    bursts = []
    small_births.sort()
    k = 0
    while k < len(small_births):
        f0 = small_births[k][0]
        grp = [b for b in small_births[k:] if b[0] - f0 <= 5]
        if len(grp) >= 10:                          # a burst is a cloud of many images (6 shapes are a chart's dots)
            xs = [c[0] / W for _, c in grp]
            ys = [c[1] / H for _, c in grp]
            sz = sorted(c[2] / W for _, c in grp)[len(grp) // 2]
            end = grp[-1][0]
            # how long the cloud stays: until a cut or the frame calms down again
            stay = next((c for c in sorted(cut_frames) if c > end), len(grays)) - f0
            bursts.append({"t_in": round(f0 / fps, 2), "duration": round(min(stay, 30) / fps, 2), "count": len(grp),
                           "x": round(float(np.median(xs)), 3), "y": round(float(np.median(ys)), 3),
                           "spread": round(float(max(np.ptp(xs), np.ptp(ys))) / 2, 3), "size": round(sz, 3)})
            k += len(grp)
        else:
            k += 1
    cards.sort(key=lambda c: c["t_in"])
    # the moments worth a close look (the agent reads dense frames around each one)
    moments = sorted({round(max(0.0, c["t_in"] - 0.3), 1) for c in cards} | {round(max(0.0, b["t_in"] - 0.3), 1) for b in bursts})
    merged = []
    for m in moments:
        if not merged or m - merged[-1] > 1.6:
            merged.append(m)

    # 4. the editor's habits, as numbers the planner uses
    dur = len(frames) / fps
    stats = {}
    if cards:
        import statistics as sx
        stats = {
            "cards_per_minute": round(len(cards) / max(dur, 1) * 60, 1),
            "size": {"w": round(sx.median(c["w"] for c in cards), 3), "h": round(sx.median(c["h"] for c in cards), 3)},
            "duration": round(sx.median(c["duration"] for c in cards), 2),
            "rot": round(sx.median(abs(c["rot"]) for c in cards if c["kind"] != "fullscreen") if any(c["kind"] != "fullscreen" for c in cards) else 0, 1),
            "y": round(sx.median(c["y"] for c in cards), 3),
            "sides": {"left": sum(1 for c in cards if c["x"] < 0.42), "right": sum(1 for c in cards if c["x"] > 0.58),
                      "middle": sum(1 for c in cards if 0.42 <= c["x"] <= 0.58)},
            "behind_share": round(sum(1 for c in cards if c.get("behind")) / len(cards), 2),
            "max_at_once": max(sum(1 for d in cards if d["t_in"] <= c["t_in"] < d["t_out"]) for c in cards),
            "kinds": {k: sum(1 for c in cards if c["kind"] == k) for k in ("clip", "image", "ui")},
            "drift": {"dx": round(sx.median(c["drift"]["dx"] for c in cards), 3), "dy": round(sx.median(c["drift"]["dy"] for c in cards), 3)},
        }
    if bursts:
        stats["bursts"] = len(bursts)
    return {"cards": cards, "bursts": bursts, "stats": stats, "moments": merged}


def dense_sheet(video: Path, t: float, out: Path, length: float = 2.4) -> Path | None:
    """10 frames a second around one moment of a reference, as one sheet the agent reads to copy its motion."""
    from PIL import Image, ImageDraw
    import shutil
    import tempfile
    tmp = Path(tempfile.mkdtemp(prefix="cc-dense-"))
    try:
        util.run([util.ffmpeg_bin(), "-v", "error", "-y", "-ss", f"{t:.2f}", "-t", f"{length:.2f}", "-i", str(video),
                  "-vf", "fps=10,scale=200:-2", str(tmp / "%03d.jpg")], check=False)
        fr = sorted(tmp.glob("*.jpg"))
        if not fr:
            return None
        w, h = Image.open(fr[0]).size
        cols = 8
        rows = (len(fr) + cols - 1) // cols
        sheet = Image.new("RGB", (cols * w, rows * (h + 16)), (16, 16, 18))
        d = ImageDraw.Draw(sheet)
        for k, f in enumerate(fr):
            x, y = (k % cols) * w, (k // cols) * (h + 16)
            sheet.paste(Image.open(f), (x, y + 16))
            d.text((x + 4, y + 2), f"{t + k / 10:.1f}s", fill=(220, 220, 225))
        out.parent.mkdir(parents=True, exist_ok=True)
        sheet.save(out, quality=85)
        return out
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
