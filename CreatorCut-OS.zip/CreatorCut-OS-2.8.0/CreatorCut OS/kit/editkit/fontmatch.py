"""Compare reference lettering with installed fonts, without downloads during a scan.
Saved matches are labelled closest-installed-face, not an assertion of exact identity.
Explicit font-catalogue helpers remain available separately.
"""
from __future__ import annotations

import json
import re
import urllib.request
from pathlib import Path

from . import util

GF = util.FONTS_DIR / "google"
_PROBE = None
_PROBE_ROOT = None
META_URL = "https://fonts.google.com/metadata/fonts"
CSS_URL = "https://fonts.googleapis.com/css2?family={fam}:ital,wght@{axes}&display=swap"


# ---------------------------------------------------------- the catalogue ----
def catalogue() -> list[dict]:
    f = GF / "metadata.json"
    if not f.exists() or f.stat().st_size < 1000:
        GF.mkdir(parents=True, exist_ok=True)
        with urllib.request.urlopen(META_URL, timeout=40) as r:
            data = r.read().decode("utf-8")
        data = data[data.index("{"):]
        fams = [{"family": x["family"], "category": x["category"], "popularity": x.get("popularity", 9999),
                 "fonts": sorted(x.get("fonts", {}).keys()), "subsets": x.get("subsets", [])}
                for x in json.loads(data)["familyMetadataList"]
                if "latin" in x.get("subsets", ["latin"]) and x.get("primaryScript", "") in ("", "Latn") and not x.get("isNoto")
                and not re.search(r"\b(JP|KR|SC|TC|HK)$", x["family"])]
        util.write_json(f, fams)
    return util.read_json(f)


def font_file(family: str, weight: int = 400, italic: bool = False) -> Path | None:
    """Download one style of a Google font as TTF (cached)."""
    slug = re.sub(r"[^a-z0-9]+", "-", family.lower()).strip("-")
    out = GF / f"{slug}-{weight}{'i' if italic else ''}.ttf"
    if out.exists() and out.stat().st_size > 1000:
        return out
    GF.mkdir(parents=True, exist_ok=True)
    url = CSS_URL.format(fam=family.replace(" ", "+"), axes=f"{1 if italic else 0},{weight}")
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "curl/8"}), timeout=30) as r:
            css = r.read().decode("utf-8")
        m = re.findall(r"url\((https://[^)]+\.ttf)\)", css)
        if not m:
            return None
        with urllib.request.urlopen(m[-1], timeout=60) as r:       # the last block is the latin subset
            out.write_bytes(r.read())
        return out
    except Exception as e:
        util.log(f"google font {family} {weight}{italic}: {e}")
        return None


# ------------------------------------------------------------- the samples ----
def ink_mask(frame_path: str, box: dict, colour: str, pad: float = 0.25, before_path: str | None = None):
    """The letters of one word as a tight binary mask. Best: the difference with the frame just before the word
    appeared (only the letters changed); also requires the style's colour. Falls back to colour alone."""
    import numpy as np
    from PIL import Image
    im = np.asarray(Image.open(frame_path).convert("RGB")).astype(np.int32)
    H, W = im.shape[:2]
    x0 = int(max(0, box["x"] - box["w"] * 0.06) * W); x1 = int(min(1, box["x"] + box["w"] * 1.06) * W)
    y0 = int(max(0, box["y"] - box["h"] * pad) * H); y1 = int(min(1, box["y"] + box["h"] * (1 + pad)) * H)
    crop = im[y0:y1, x0:x1]
    if crop.size == 0:
        return None
    c = np.array([int(colour[i:i + 2], 16) for i in (1, 3, 5)])
    near = np.sqrt(((crop - c) ** 2).sum(axis=2)) < 90
    if before_path:
        prev = np.asarray(Image.open(before_path).convert("RGB")).astype(np.int32)[y0:y1, x0:x1]
        changed = np.abs(crop - prev).max(axis=2) > 45
        m = changed & near
        if m.sum() < 25:
            return None
    else:
        m = near
    import cv2
    m = cv2.morphologyEx(m.astype("uint8"), cv2.MORPH_OPEN, np.ones((2, 2), np.uint8)) > 0
    ys, xs = np.where(m)
    if len(ys) < 25:
        return None
    return m[ys.min():ys.max() + 1, xs.min():xs.max() + 1]


def render_mask(font: Path, text: str, height: int):
    """The same word in a candidate font, ink cropped, scaled so its ink height matches."""
    import numpy as np
    from PIL import Image, ImageDraw, ImageFont
    f = ImageFont.truetype(str(font), 120)
    im = Image.new("L", (120 * max(2, len(text)) + 80, 260), 0)
    ImageDraw.Draw(im).text((40, 40), text, font=f, fill=255)
    a = np.asarray(im) > 110
    ys, xs = np.where(a)
    if len(ys) < 10:
        return None
    a = a[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    k = height / a.shape[0]
    out = Image.fromarray((a * 255).astype("uint8")).resize((max(1, int(a.shape[1] * k)), height), Image.BILINEAR)
    return np.asarray(out) > 127


def score(font: Path, samples: list) -> float:
    """Letter-shape agreement with the reference words (0-1): the rendered word is fitted to the reference word's
    exact box and the ink overlap measured (shapes, weight, slant, serifs), times how well its width matches."""
    import numpy as np
    from PIL import Image
    vals = []
    for text, obs in samples:
        r = render_mask(font, text, obs.shape[0])
        if r is None:
            continue
        fitted = np.asarray(Image.fromarray((r * 255).astype("uint8")).resize((obs.shape[1], obs.shape[0]), Image.BILINEAR)) > 127
        iou = (obs & fitted).sum() / max(1, (obs | fitted).sum())
        aspect = min(obs.shape[1], r.shape[1]) / max(obs.shape[1], r.shape[1])
        vals.append(iou * aspect ** 1.5)
    return float(np.mean(vals)) if vals else 0.0


def samples_for(refmap: dict, frames_dir: Path, style_id: int, n: int = 12) -> list:
    """(text, ink mask) pairs for one style, from words with 3+ letters seen clearly."""
    st = next(s for s in refmap["styles"] if s["id"] == style_id)
    out = []
    for e in refmap["elements"]:
        if e.get("style") != style_id or len(re.sub(r"\W", "", e["text"])) < 3 or not e.get("colour"):
            continue
        i = int(round(e["t_in"] * 10)) + 1                  # first frames after it appeared (settled)
        b = int(round(e["t_in"] * 10)) - 1                  # the frame before it appeared
        cuts = [c for c in refmap.get("cuts", []) if b / 10 - 0.05 <= c <= i / 10 + 0.05]
        f, fb = frames_dir / f"{i + 1:04d}.jpg", frames_dir / f"{b + 1:04d}.jpg"
        if not f.exists():
            continue
        # the frame before the word is the cleanest way to see only its letters; across a cut (fast edits) or at the
        # very start, fall back to the style's colour alone
        clean_before = b >= 0 and fb.exists() and not cuts
        m = ink_mask(str(f), e, st["colour"] or e["colour"], before_path=str(fb) if clean_before else None)
        if m is not None and m.shape[0] > 12 and _clean(m, e["text"]) and _fits(m, e["text"]):
            out.append((re.sub(r"[^\w'.,!?-]", "", e["text"]), m))
        if len(out) >= n:
            break
    return out


# ---------------------------------------------------------------- matching ----
# fonts short-form editors use most (CapCut, Edits, Instagram, Premiere templates): always in the first round
CREATOR_FONTS = {
    "Inter", "Inter Tight", "Poppins", "Montserrat", "DM Sans", "Plus Jakarta Sans", "Manrope", "Outfit", "Urbanist",
    "Figtree", "Geist", "Instrument Sans", "Space Grotesk", "Bricolage Grotesque", "Syne", "Archivo", "Archivo Black",
    "Roboto", "Arimo", "Helvetica", "Work Sans", "Rubik", "Nunito", "Lexend", "Sora", "League Spartan", "Kanit",
    "Bebas Neue", "Anton", "Oswald", "Barlow Condensed", "Fjalla One", "Luckiest Guy", "Bangers", "Lilita One",
    "Instrument Serif", "Playfair Display", "DM Serif Display", "DM Serif Text", "Fraunces", "Cormorant Garamond",
    "EB Garamond", "Libre Caslon Text", "Lora", "Newsreader", "Gloock", "Young Serif", "Crimson Pro", "Bodoni Moda",
    "Caveat", "Kalam", "Shadows Into Light", "Gochi Hand", "Permanent Marker", "Patrick Hand", "Indie Flower",
    "Reenie Beanie", "Nothing You Could Do", "Homemade Apple", "Dancing Script", "Pacifico", "Satisfy",
    # geometric and rounded sans (single-storey a, wide rounds): the look of many caption presets
    "Montserrat Alternates", "Jost", "Quicksand", "Comfortaa", "Varela Round", "Nunito Sans", "Raleway", "Josefin Sans",
    "Kumbh Sans", "Red Hat Display", "Gabarito", "Onest", "Albert Sans", "Lexend Deca", "Questrial", "Mulish",
    "Be Vietnam Pro", "Epilogue", "Public Sans", "Hanken Grotesk", "Schibsted Grotesk", "Familjen Grotesk", "Unbounded",
    "Righteous", "Fredoka", "Baloo 2", "M PLUS Rounded 1c", "Chivo", "Space Grotesk", "Syne", "Clash Display",
    "Oswald", "Teko", "Big Shoulders Display", "Alfa Slab One", "Abril Fatface", "Playfair Display SC", "Cinzel",
}


def installed_candidates():
    """Use the actual installed font faces; scans never fetch hundreds of unused fonts."""
    from PIL import ImageFont
    roots=[util.FONTS_DIR,util.KIT/'style-library/engine/fonts']
    found=[];seen=set()
    for root in roots:
        for path in sorted(root.rglob('*')):
            if path.suffix.lower() not in ('.ttf','.otf') or not path.is_file():continue
            try:
                family,style=ImageFont.truetype(str(path),64).getname()
                key=(family,style)
                if key in seen:continue
                seen.add(key);name=(family+' '+style).lower();weight=400
                for label,value in [('thin',100),('light',300),('medium',500),('semibold',600),('bold',700),('extrabold',800),('black',900)]:
                    if label in name:weight=value
                found.append({'family':family,'weight':weight,'italic':'italic' in name,'category':'Installed','file':util.rel(path)})
            except (OSError,ValueError):continue
    return found

def match(samples: list, top: int = 5, per_category: int = 30, progress=None) -> list[dict]:
    """Compare the reference letters against every available local face, honestly labelled a match."""
    say=progress or (lambda *_:None)
    if not samples:return []
    candidates=installed_candidates();scored=[]
    for k,row in enumerate(candidates):
        say('Comparing installed fonts…',k/max(1,len(candidates)))
        try:scored.append(dict(row,score=round(score(util.ROOT/row['file'],samples),3),match_method='closest-installed-face'))
        except (OSError,ValueError):continue
    return sorted(scored,key=lambda row:-row['score'])[:top]

def _fits(m, text: str) -> bool:
    """The crop really is this word: its width/height is close to the word set in a plain sans (wide enough a range
    for condensed caption fonts like Anton, Bebas or Oswald and for wide ones like Archivo Black)."""
    global _PROBE,_PROBE_ROOT
    if _PROBE_ROOT != util.ROOT or _PROBE is None:
        faces=installed_candidates()
        preferred=next((row for row in faces if row['family'].lower() in ('inter','arimo','arial','montserrat')),faces[0] if faces else None)
        _PROBE=util.ROOT/preferred['file'] if preferred else None
        _PROBE_ROOT=util.ROOT
    if not _PROBE:
        return True
    r = render_mask(_PROBE, re.sub(r"[^\w'.,!?-]", "", text), m.shape[0])
    if r is None:
        return True
    a, b = m.shape[1] / m.shape[0], r.shape[1] / r.shape[0]
    return 0.4 < a / b < 1.8


def _clean(m, text: str) -> bool:
    """A usable sample: about one connected shape per letter (no merged neighbours, no half-erased word)."""
    import cv2
    n = cv2.connectedComponentsWithStats(m.astype("uint8"), 8)[0] - 1
    letters = len(re.sub(r"[^A-Za-z0-9]", "", text))
    return letters * 0.6 <= n <= letters + 3


def _slant(samples) -> float:
    """Median letter slant of the observed ink (italic ≈ 0.15+)."""
    import numpy as np
    vals = []
    for _, m in samples:
        ys, xs = np.where(m)
        if len(ys) > 30:
            yc, xc = ys - ys.mean(), xs - xs.mean()
            v = float((yc * yc).mean())
            if v:
                vals.append(-float((xc * yc).mean()) / v)
    return float(np.median(vals)) if vals else 0.0


LOOKALIKES = [("Montserrat Alternates", 600), ("Montserrat Alternates", 700), ("Jost", 600), ("Outfit", 600), ("Poppins", 600),
              ("Montserrat", 700), ("TikTok Sans", 600), ("Lexend", 600), ("Quicksand", 700), ("Inter", 700), ("Arimo", 700),
              ("Figtree", 700), ("Nunito Sans", 700), ("DM Sans", 700), ("Archivo", 700), ("Plus Jakarta Sans", 700)]


def lookalikes(samples: list, progress=None) -> list[dict]:
    """The same available face comparison; no second network search."""
    return match(samples,top=8,progress=progress)

def compare_sheet(samples: list, candidates: list[dict], out: Path, n: int = 5) -> str:
    """Reference words (top row) above the same words in each candidate font: for an eye check."""
    import numpy as np
    from PIL import Image, ImageDraw
    rows = [("reference", [m for _, m in samples[:n]])]
    for c in candidates[:8]:
        ms = []
        for text, obs in samples[:n]:
            r = render_mask(util.ROOT / c["file"], text, obs.shape[0])
            ms.append(r if r is not None else np.zeros((obs.shape[0], 10), bool))
        rows.append((f'{c["family"]} {c["weight"]}{" italic" if c["italic"] else ""}  {c["score"]}', ms))
    H = 64
    lines = []
    for label, ms in rows:
        tiles = [Image.fromarray((m * 255).astype("uint8")).resize((max(1, int(m.shape[1] * H / m.shape[0])), H)) for m in ms]
        w = 300 + sum(t.width + 16 for t in tiles)
        row = Image.new("L", (w, H + 10), 20)
        ImageDraw.Draw(row).text((6, H // 2), label, fill=200)
        x = 300
        for t in tiles:
            row.paste(t, (x, 5)); x += t.width + 16
        lines.append(row)
    sheet = Image.new("L", (max(r.width for r in lines), sum(r.height for r in lines)), 20)
    y = 0
    for r in lines:
        sheet.paste(r, (0, y)); y += r.height
    out.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(out)
    return util.rel(out) if str(out).startswith(str(util.ROOT)) else str(out)
