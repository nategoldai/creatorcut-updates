"""Drain admitted HTTP work before replacing code; serve saved status during the switch."""
from contextlib import contextmanager
import threading,time,functools
from . import util
_condition=threading.Condition();_readers=0;_active=False;_restart_failed=False

def restart_failed():
 global _restart_failed
 with _condition:_restart_failed=True;_condition.notify_all()
class Busy(util.Fail):pass

def active():
 with _condition:return _active

@contextmanager
def read():
 global _readers
 with _condition:
  if _active:raise Busy('Your update is being installed. Your videos and settings are kept.')
  _readers+=1
 try:yield
 finally:
  with _condition:_readers-=1;_condition.notify_all()

@contextmanager
def writing(timeout=35,hold_until_restart=False):
 global _active
 deadline=time.monotonic()+timeout
 with _condition:
  if _active:raise Busy('Another update is still finishing.')
  _active=True
  while _readers:
   remaining=deadline-time.monotonic()
   if remaining<=0:_active=False;_condition.notify_all();raise util.Fail('An open request is still finishing. Retry the update shortly; your app has not changed.')
   _condition.wait(remaining)
 succeeded=False
 try:
  yield;succeeded=True
 finally:
  with _condition:
   if not (succeeded and hold_until_restart):_active=False
   _condition.notify_all()

# API handlers reject new mutations while a Studio update is changing its code.
# State/SSE serve the last complete snapshot instead of importing mixed versions.
def handler(fn):
 @functools.wraps(fn)
 def wrapped(self,*args,**kwargs):
  from urllib.parse import urlparse
  path=urlparse(self.path).path
  if path in ('/api/state','/api/events/stream','/api/ping'):return fn(self,*args,**kwargs)
  try:
   with read():return fn(self,*args,**kwargs)
  except Busy:
   self.close_connection=True
   if path in ('/','/index.html','/Studio.html'):
    if _restart_failed:
     return self._send(200,b'<html><head><title>CREATORCUT</title></head><body style="font:18px system-ui;padding:48px">Your update is installed.<br><small>Close and reopen CreatorCut to finish. Your videos and presets are saved.</small></body></html>','text/html; charset=utf-8')
    return self._send(200,b'<html><head><meta http-equiv="refresh" content="2"></head><body style="font:18px system-ui;padding:48px">Updating CreatorCut\xe2\x80\xa6<br><small>Your videos and presets are saved. Studio will reopen automatically.</small></body></html>','text/html; charset=utf-8')
   return self._json({'error':'Your update is finishing. Try again in a moment.','updating':True},503)
 return wrapped
