"""Mechanically check saved choices; generic application prose is not evidence."""
import math,re
from html.parser import HTMLParser
from . import util

def length_bounds(value):
 if value in (None,'','best','auto'):return None
 text=str(value).strip().lower().replace('–','-').replace('—','-')
 if re.fullmatch(r'\d+:\d{2}',text):
  m,s=map(int,text.split(':'));return (m*60+s,m*60+s)
 match=re.fullmatch(r'(\d+(?:\.\d+)?)(?:\s*-\s*(\d+(?:\.\d+)?))?\s*(s|sec|secs|second|seconds|m|min|mins|minute|minutes)?',text)
 if not match:raise util.Fail('Choose a video length in seconds, a range such as 20-30 seconds, or Best.')
 a=float(match[1]);b=float(match[2] or match[1]);scale=60 if (match[3] or '').startswith('m') else 1
 if not 0<a<=b<=14400/scale:raise util.Fail('Choose a video length between 0 and four hours.')
 return a*scale,b*scale

class VisibleText(HTMLParser):
 def __init__(self):super().__init__();self.skip=0;self.text=[]
 def handle_starttag(self,tag,attrs):
  if tag in ('script','style'):self.skip+=1
 def handle_endtag(self,tag):
  if tag in ('script','style'):self.skip=max(0,self.skip-1)
 def handle_data(self,text):
  if not self.skip:self.text.append(text)

def tokens(value):return ' '.join(re.findall(r'[^\W_]+',str(value).casefold(),re.UNICODE))
def errors(p,scene,plan,settings):
 issues=[];dur=plan.get('duration')
 if type(dur) not in (int,float) or not math.isfinite(dur):return issues # structural validation owns this error
 try:bounds=length_bounds(settings.get('brief',{}).get('length'))
 except util.Fail as error:issues.append(error.message);bounds=None
 if bounds and not bounds[0]-.5<=dur<=bounds[1]+.5:issues.append('The planned video is '+str(dur)+' seconds; the saved length is '+str(settings['brief']['length'])+'. Match that length before rendering.')
 canvas=plan.get('canvas',{});w,h=canvas.get('w'),canvas.get('h')
 if settings.get('platform') and type(w) is int and type(h) is int and min(w,h)>0:
  from . import platforms
  target=platforms.get(settings['platform']);want=target['width']/target['height']
  if (w,h)!=(target['width'],target['height']):issues.append('The render canvas does not match the saved platform shape and resolution.')
 # CTA must be present in actual narration words or render item text. Scene
 # descriptions and request_application reasons cannot satisfy this check.
 cta=settings.get('cta','')
 if cta:
  texts=[]
  def collect(value):
   if isinstance(value,str):texts.append(value)
   elif isinstance(value,list):
    for v in value:collect(v)
   elif isinstance(value,dict):
    for k in ('w','text','t','s','title','body','label','words'):
     if k in value:collect(value[k])
  collect(util.read_json(p/'words.json',default={}).get('words',[]))
  for item in plan.get('items',[]):
   collect(item)
   if item.get('type')=='html':
    parser=VisibleText();parser.feed(str(item.get('html','')));texts.extend(parser.text)
  if tokens(cta) not in tokens(' '.join(texts)):
   issues.append('The saved call to action is missing from narration or visible render text: '+str(cta)+'. Add it before rendering; a generic request-application reason does not count.')
 return issues
