#!/bin/sh
# Resolve only this installation; safe after moving or renaming its folder.
CC_BIN=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P) || exit 1
CC_KIT=$(CDPATH= cd -- "$CC_BIN/.." && pwd -P) || exit 1
export PATH="$CC_BIN/node/bin:$CC_BIN:$PATH"
export HYPERFRAMES_SKIP_SKILLS=1 HYPERFRAMES_NO_TELEMETRY=1 DO_NOT_TRACK=1
for CC_BROWSER in "$CC_KIT"/render/node_modules/.remotion/chrome-headless-shell/*/chrome-headless-shell-*/chrome-headless-shell; do
  if [ -f "$CC_BROWSER" ]; then export HYPERFRAMES_BROWSER_PATH="$CC_BROWSER"; break; fi
done
case "$(basename -- "$0")" in
  hyperframes) exec "$CC_BIN/node/bin/node" "$CC_KIT/render/node_modules/hyperframes/bin/hyperframes.mjs" "$@" ;;
  remotion) exec "$CC_KIT/render/node_modules/.bin/remotion" "$@" ;;
  *) echo "Run this launcher as hyperframes or remotion." >&2; exit 1 ;;
esac
