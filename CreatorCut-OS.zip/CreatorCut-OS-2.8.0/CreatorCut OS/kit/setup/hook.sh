#!/bin/bash
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
PY="$ROOT/.venv/bin/python"
if [ ! -x "$PY" ]; then
  if [ "${1:-}" = start ]; then echo 'Install CreatorCut in this folder, then open Studio. Click Trust when Claude asks about this folder.'; fi
  exit 0
fi
cd "$ROOT" || exit 0
export PYTHONPATH="$ROOT/kit"
exec "$PY" -m editor.hooks "${1:-stop}"
