# Generated from binary-pins.json; package hashes protect both files.
cc_pin() {
  local arch="$3"; case "$arch" in aarch64) arch=arm64 ;; amd64) arch=x86_64 ;; esac
  case "$1:$2:$arch" in
    ffmpeg:linux:arm64) PIN_URL='https://ffmpeg.martin-riedl.de/download/linux/arm64/1789931697_9.0.2/ffmpeg.zip'; PIN_SHA='93a76ae90db5474eecdf951a729857c64f3de23567228d6a7d5e6e8e3cd1021b'; PIN_NAME='ffmpeg.zip'; PIN_VERSION='9.0.2' ;;
    ffmpeg:linux:x86_64) PIN_URL='https://ffmpeg.martin-riedl.de/download/linux/amd64/1789931100_9.0.2/ffmpeg.zip'; PIN_SHA='fa8ecf4abbd290d98f7d188b8649cc6b391ae209a98452be955a15aab1909d7f'; PIN_NAME='ffmpeg.zip'; PIN_VERSION='9.0.2' ;;
    ffmpeg:mac:arm64) PIN_URL='https://ffmpeg.martin-riedl.de/download/macos/arm64/1789931890_9.0.2/ffmpeg.zip'; PIN_SHA='c8ed4c4e6978a03c485edbfe4e0a5dc2380f8a30bba5150531b31b094492d924'; PIN_NAME='ffmpeg.zip'; PIN_VERSION='9.0.2' ;;
    ffmpeg:mac:x86_64) PIN_URL='https://ffmpeg.martin-riedl.de/download/macos/amd64/1789931006_9.0.2/ffmpeg.zip'; PIN_SHA='7c6b4125b191cbf773832dc51f424cf2b6bb7da43007d1e066f95909e47cacd4'; PIN_NAME='ffmpeg.zip'; PIN_VERSION='9.0.2' ;;
    ffprobe:linux:arm64) PIN_URL='https://ffmpeg.martin-riedl.de/download/linux/arm64/1789931697_9.0.2/ffprobe.zip'; PIN_SHA='bcbe80fb741c180083327afaf5434812e006b33cacde2016b9aeaf6936128330'; PIN_NAME='ffprobe.zip'; PIN_VERSION='9.0.2' ;;
    ffprobe:linux:x86_64) PIN_URL='https://ffmpeg.martin-riedl.de/download/linux/amd64/1789931100_9.0.2/ffprobe.zip'; PIN_SHA='3f428c49070be3d24ec338602b76d412e401ffcb8a5641ef0e729181a232fc32'; PIN_NAME='ffprobe.zip'; PIN_VERSION='9.0.2' ;;
    ffprobe:mac:arm64) PIN_URL='https://ffmpeg.martin-riedl.de/download/macos/arm64/1789931890_9.0.2/ffprobe.zip'; PIN_SHA='fcbe839537485eaee7a7a8bc5cbc0f90d53617e80943e8a5b2e31cb851197ea6'; PIN_NAME='ffprobe.zip'; PIN_VERSION='9.0.2' ;;
    ffprobe:mac:x86_64) PIN_URL='https://ffmpeg.martin-riedl.de/download/macos/amd64/1789931006_9.0.2/ffprobe.zip'; PIN_SHA='2322438ed2f6319a691291b247d09c69dcaa3a982460d1f269a7e1af335cfdfd'; PIN_NAME='ffprobe.zip'; PIN_VERSION='9.0.2' ;;
    node:linux:arm64) PIN_URL='https://nodejs.org/dist/v22.23.3/node-v22.23.3-linux-arm64.tar.gz'; PIN_SHA='5ced2d48d1d7198739b7f86804de0171aefb6823b684b12341d3321afc3cb0b2'; PIN_NAME='node-v22.23.3-linux-arm64.tar.gz'; PIN_VERSION='22.23.3' ;;
    node:linux:x86_64) PIN_URL='https://nodejs.org/dist/v22.23.3/node-v22.23.3-linux-x64.tar.gz'; PIN_SHA='1084aa36196bba4c3a5e69a1ee388a6e4ff729dad09445fbcd434b28fe3c24af'; PIN_NAME='node-v22.23.3-linux-x64.tar.gz'; PIN_VERSION='22.23.3' ;;
    node:mac:arm64) PIN_URL='https://nodejs.org/dist/v22.23.3/node-v22.23.3-darwin-arm64.tar.gz'; PIN_SHA='23b25245dcfb9af7262f8ff142e9e2e0af025368117329e7a7458a51e5922f53'; PIN_NAME='node-v22.23.3-darwin-arm64.tar.gz'; PIN_VERSION='22.23.3' ;;
    node:mac:x86_64) PIN_URL='https://nodejs.org/dist/v22.23.3/node-v22.23.3-darwin-x64.tar.gz'; PIN_SHA='8a677b0219178efd6eb0e475457c4afb452b521a92f6e67845a73bd85727f2a8'; PIN_NAME='node-v22.23.3-darwin-x64.tar.gz'; PIN_VERSION='22.23.3' ;;
    uv:linux:arm64) PIN_URL='https://github.com/astral-sh/uv/releases/download/0.13.1/uv-aarch64-unknown-linux-gnu.tar.gz'; PIN_SHA='9041c73c99fdc5892cf128140beb354eca9231d502068cc36e6cb53a8e59ad14'; PIN_NAME='uv-aarch64-unknown-linux-gnu.tar.gz'; PIN_VERSION='0.13.1' ;;
    uv:linux:x86_64) PIN_URL='https://github.com/astral-sh/uv/releases/download/0.13.1/uv-x86_64-unknown-linux-gnu.tar.gz'; PIN_SHA='eadd9d27c134ab5ac1ffd4473b97a741407f3ea238288f03121fc4deddf90220'; PIN_NAME='uv-x86_64-unknown-linux-gnu.tar.gz'; PIN_VERSION='0.13.1' ;;
    uv:mac:arm64) PIN_URL='https://github.com/astral-sh/uv/releases/download/0.13.1/uv-aarch64-apple-darwin.tar.gz'; PIN_SHA='cfe454573412ff7380d15fc7dae5997ab53ffce72fce0a78e91ddbc84001acd2'; PIN_NAME='uv-aarch64-apple-darwin.tar.gz'; PIN_VERSION='0.13.1' ;;
    uv:mac:x86_64) PIN_URL='https://github.com/astral-sh/uv/releases/download/0.13.1/uv-x86_64-apple-darwin.tar.gz'; PIN_SHA='bb7b805bdcf3d0bc8c74ceb94569e6b3e8aa35bd492acdbb9d46bf46d9d4ff6b'; PIN_NAME='uv-x86_64-apple-darwin.tar.gz'; PIN_VERSION='0.13.1' ;;
    *) return 1 ;;
  esac
}
