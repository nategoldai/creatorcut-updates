/* Studio exchanges files with the visible chat. There is no message transport. */
(function () {
  'use strict';
  const A = window.AIE;
  A.nativeChat = {
    available: false, pending: false, uncertain: false,
    syncReceiver() {}, confirmStarted() {}, confirmRetry() {},
    async send() { throw new Error('Open your CreatorCut chat and type go.'); }
  };
})();
