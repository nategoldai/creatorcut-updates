"""Advisory revision comparison; cannot block a customer publication."""
import json,re,subprocess
from pathlib import Path

def ranges(notes):
 result=[]
 for note in notes:
  text=note.get('text','').lower()
  # Only a named bounded appearance change; a point note is not a time range.
  if not re.search(r'text|caption|font|word|effect',text):continue
  match=re.search(r'first\s+(\d+(?:\.\d+)?|five|ten)\s*(?:seconds?|s\b)',text)
  if match:
   value={'five':5,'ten':10}.get(match[1]);end=float(value if value is not None else match[1]);result.append((0.,end))
  elif isinstance(note.get('end'),(float,int)) and isinstance(note.get('time'),(float,int)) and note['end']>note['time']:
   result.append((float(note['time']),float(note['end'])))
 return result

def sample(ff,file,t):
 import numpy as np
 raw=subprocess.check_output([str(ff),'-nostdin','-v','error','-ss',str(t),'-i',str(file),'-frames:v','1','-vf','scale=270:480','-pix_fmt','rgb24','-f','rawvideo','-'],timeout=30)
 return np.frombuffer(raw,dtype='uint8').reshape(480,270,3).astype(float)

def compare(ff,previous,current,windows):
 import numpy as np
 rows=[]
 for start,end in windows:
  # Derive the changed region from actual in-range frames, not a guessed caption box.
  a=sample(ff,previous,(start+end)/2);b=sample(ff,current,(start+end)/2)
  delta=np.mean(np.abs(a-b),axis=2);mask=delta>8
  # Reject tiny codec-noise specks; retain all genuinely changed areas.
  if int(mask.sum())<12:mask=np.ones(mask.shape,dtype=bool)
  for t in (end+.1,end+.5):
   a=sample(ff,previous,t);b=sample(ff,current,t);difference=float(np.mean(np.mean(np.abs(a-b),axis=2)[mask]))
   rows.append({'at':t,'changed_pixels':int(mask.sum()),'mean_rgb_difference':difference,'matches':difference<=4})
 return rows

def review(p,ff,request,versions):
 from editor.director import read,write
 p=Path(p);file=p/'work/feedback-boundary.json';windows=ranges(request.get('notes',[]))
 result={'request_id':request.get('id'),'advisory_only':True,'checks':[],'notices':[]}
 if not windows or not versions:
  write(file,result);return result
 previous=p.parents[2]/versions[-1]['file'];current=p/'renders/final.mp4'
 old=read(file);attempt=old.get('attempt',0)+1 if old.get('request_id')==request.get('id') else 1;result['attempt']=attempt
 try:
  result['checks']=compare(ff,previous,current,windows);bad=any(not r['matches'] for r in result['checks'])
  if bad:
   if attempt==1:result['message']='Restore the previous text appearance completely at the requested end time, including its fade, then check once more.'
   else:
    result['message']='I saved the best version; the text just after your requested time still differs slightly.'
    result['notices']=[result['message']]
 except (OSError,ValueError,subprocess.SubprocessError,IndexError,KeyError) as error:
  result['not_measured']=type(error).__name__;result['message']='Compare the text just after your requested end time with the previous video before saving.'
 write(file,result);return result
