"""Read-only identity of the visible host process; never signal a chat."""
import os
from pathlib import Path
import subprocess
from editkit import util


def capture():
    pid = os.getppid()
    for _ in range(8):
        if pid <= 1:
            break
        try:
            value = subprocess.check_output(
                ['/bin/ps', '-o', 'ppid=', '-o', 'comm=', '-p', str(pid)],
                text=True, stderr=subprocess.DEVNULL, timeout=2).strip()
            parent, command = value.split(None, 1)
            if Path(command.strip()).name.lower() in ('claude', 'claude.exe', 'codex', 'codex.exe'):
                birth = util.process_identity(pid)
                return {'pid': pid, 'birth': birth} if birth else None
            pid = int(parent)
        except (OSError, ValueError, subprocess.SubprocessError):
            break
    return None


def alive(record):
    """True=that process lives, False=proven gone, None=not provable."""
    if not isinstance(record, dict) or type(record.get('pid')) is not int or not 1 < record['pid'] <= 2147483647 or not isinstance(record.get('birth'), str) or not record['birth']:
        return None
    if not util.process_alive(record['pid']):
        return False
    current = util.process_identity(record['pid'])
    return current == record['birth'] if current else None
