"""The decoder self-test used during setup and doctor. No model download."""
import tempfile,wave,os
from pathlib import Path
def check(root):
 from faster_whisper.audio import decode_audio
 import av
 if int(av.__version__.split('.')[0])>=19:raise RuntimeError('The speech decoder needs its compatible installed version.')
 folder=Path(root)/'kit/studio-out';folder.mkdir(parents=True,exist_ok=True)
 with tempfile.NamedTemporaryFile(suffix='.wav',dir=folder,delete=False) as f:path=Path(f.name)
 try:
  with wave.open(str(path),'wb') as f:f.setnchannels(1);f.setsampwidth(2);f.setframerate(16000);f.writeframes(bytes(3200))
  samples=decode_audio(str(path),sampling_rate=16000)
  if len(samples)!=1600:raise RuntimeError('The speech decoder did not finish its check.')
  return True
 finally:path.unlink(missing_ok=True)
