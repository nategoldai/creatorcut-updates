"""A bounded local cutout job, not an AI editor. All work shares the heavy gate."""
import os
import json
import subprocess
import sys
import threading
import time
from pathlib import Path
from editor import director as d
from editkit import resources,util


def start(project,request=None):
    request=request or d.status(project).get("request_id")
    if not request or d.status(project).get("state")!="working":return
    selected = d.read(project/'creator-request.json').get('choices',{}).get('library_choices',{}).get('effects',[])
    launch = d.read(d.LIB/'launch-list.json').get('effects',[])
    cutouts = {row['key'] for row in d.read(d.LIB/'catalogue.json').get('entries',[])
               if row.get('kind') == 'effect' and row.get('cutout') not in (None, '', 'none', 'no')}
    launch = set(launch).intersection(cutouts)
    if not any(str(row.get('id','')).split(':')[-1] in launch for row in selected):
        return
    # The worker's kernel lock makes double starts harmless; no recorded PID is
    # ever signalled here. Stop is observed through this project's cancel file.
    try:
        with (project/'work/matte-worker.log').open('a') as stream:
            subprocess.Popen([sys.executable,str(d.ROOT/'edit.py'),'_matte',project.name,request],
                             cwd=d.ROOT,stdin=subprocess.DEVNULL,stdout=stream,
                             stderr=subprocess.STDOUT,start_new_session=True)
    except OSError:
        # The later effect can still prepare its matte synchronously.
        return


def run(name,request=None):
    project=d.project(name)
    owned=False
    guard=d.lock(project/'work/.matte-worker.guard')
    try:
        guard.__enter__()
        owned=True
        if not request or d.status(project).get("request_id")!=request:return
        d.write(project/'work/matte-worker.json',dict(pid=os.getpid(),birth=util.process_identity(os.getpid())))
        if d.read(project/'cancel.json').get('cancel') or d.status(project).get('request_id')!=request:
            return
        title=d.read(project/'project.json').get('title') or 'your video'
        d.write(project/'work/matte-progress.json',dict(percent=0,eta=None))
        def waiting(_holder):
            if d.read(project/'cancel.json').get('cancel') or d.status(project).get('request_id')!=request:
                raise d.Needed(d.PLAIN['stopped'])
        with resources.heavy('Preparing the person cutout for '+title,project=project.name,on_wait=waiting,request=request):
            if d.read(project/'cancel.json').get('cancel') or d.status(project).get('request_id')!=request:
                return
            env=d.environment(project)
            from editkit import library
            library.ensure_matting()
            env['TMPDIR']=str(project/'work/matte-tmp')
            Path(env['TMPDIR']).mkdir(parents=True,exist_ok=True)
            child=subprocess.Popen(d.script(project,'rvm_cut.py',[]),cwd=project,
                    env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                    text=True,start_new_session=True,pass_fds=resources.inherited_fds())
            stop=threading.Event();started=time.monotonic()
            limit=max(300,min(900,120+float(d.read(project/'plan.json').get('duration',0))*15))
            def watch():
                while not stop.wait(1):
                    if d.read(project/'cancel.json').get('cancel') or d.status(project).get('request_id')!=request or time.monotonic()-started>limit:
                        d.stop_child(child)
                        return
            thread=threading.Thread(target=watch,daemon=True);thread.start()
            try:
                for line in child.stdout:
                    print(line,end='',flush=True)
                    try:percent=json.loads(line).get('percent')
                    except (ValueError,AttributeError):percent=None
                    if request and isinstance(percent,(float,int)):
                        d.put(project,_request=request,overall_percent=55+3*min(100,max(0,percent))/100,heartbeat=time.time())
                code=child.wait()
                d.write(project/'work/matte-result.json',dict(exit_code=code,seconds=time.monotonic()-started))
                if code==0:
                    d.write(project/'work/matte-progress.json',dict(percent=100,eta=0))
                    if request:d.put(project,_request=request,overall_percent=58,heartbeat=time.time())
            finally:
                stop.set();thread.join(timeout=6);d.stop_child(child)
                child.stdout.close()
    except d.Busy:
        return
    except (d.Needed,util.Fail,OSError):
        # This companion must never write another project's current status.
        d.write(project/'work/matte-result.json',dict(exit_code=1,message='The person cutout could not finish.'))

    finally:
        if owned:
            try:d.write(project/'work/matte-worker.json',dict(pid=None))
            finally:guard.__exit__(None,None,None)
