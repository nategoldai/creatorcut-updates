# Your first CreatorCut video

Open the CreatorCut folder in **Claude Code or Codex**. Ask: **Install CreatorCut here and open Studio when ready.** Wait for setup to finish.

**Claude Code:** click Trust once for this folder. Keep its chat open.
**Codex:** choose Full access once for this chat. This lets the local video tools run. Do not change global settings or bypass a refusal.

In Studio, add your raw files and B-roll. Use a raw clip without words already burned into the picture. Choose your style, captions, colour and music, and up to two effects. Open **What it needs** to see whether an effect needs a wider shot, your numbers or your own pictures.

You can drop a reference video or paste a TikTok, Instagram or YouTube link. A scan can take about six minutes. If a link cannot be read, download the video yourself and drop the file instead.

Press **Make my video**. Claude starts by itself while its chat is open. In Codex, type **go** in the chat. Editor shows real progress. If your chat needs an answer or genuine permission, answer there yourself.

When ready, play or **Download** your video. Pause on its timeline, write one edit, press **Add edit**, then **Update video**. In Codex, type **go** again. The earlier version stays saved.

**Save as preset** keeps a style for next time. Tell your chat when you want a preference remembered. **Stop edit** stops safely. If your chat closes, reopen this folder and type **continue**; another active editor is left alone.

Keep your Mac awake, close heavy apps and leave several GB free plus2.5GB per edit. If something fails, send a screenshot of the chat. Windows setup is unavailable until tested.
