# Start here

Open the CreatorCut folder as a project in your AI coding app.

1. Open the downloaded ZIP. Open its folder. Drag the inner **CreatorCut OS** folder into a new your AI coding app project.
2. Type **Install CreatorCut here and open it when everything is ready.** Keep the whole app folder together.
3. Let setup finish. It downloads the video tools once. Keep several GB free, plus at least 2.5 GB for each edit. Keep the lid open and close heavy apps.
4. Complete any real trust, sign-in or permission prompt yourself. No API key is prescribed by this setup.
5. In Studio, add your raw files and B-roll. Add a reference, choose styles, captions, colour and music, and write what you want. **Adjust** has the extra options.
6. Press **Make my video**. Paste its saved message into this your AI coding app chat and send it. Keep the chat open; it is doing the editing. Editor shows its reported progress.
7. Watch the finished video. Pause on the timeline, write feedback and press **Add edit**. Press **Update video**, then paste its new message into the chat.
8. Download the finished version. Save a named preset to reuse the look; your private editing preferences stay in this app folder.
9. If work stops, open its chat for the next action. To move it, press **Continue in a new chat** and wait for the old step to stop. Or choose **Stop edit**, wait, then **Try again**. Your earlier versions stay saved.
10. If anything fails, send a screenshot of the chat and say which button you pressed. Do not share passwords or sign-in codes.

Use **Download new version** when an update is available. It preserves your videos, presets and editing memory.
