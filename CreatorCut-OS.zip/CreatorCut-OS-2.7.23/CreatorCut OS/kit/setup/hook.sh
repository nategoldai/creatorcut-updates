#!/usr/bin/env bash
# Claude Code hooks for CreatorCut OS (settings.json). Works before anything is installed.
#   hook.sh start   SessionStart: tells the agent to install (fresh folder) or to connect to the app
#   hook.sh stop    Stop: no delivery in paste mode; no idle continuation
if [ "${CREATORCUT_MANAGED_EDITOR:-}" = 1 ]; then exit 0; fi
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
PY="$ROOT/.venv/bin/python"; [ -x "$PY" ] || PY="$ROOT/.venv/Scripts/python.exe"
if [ ! -x "$PY" ] || [ ! -d "$ROOT/kit/bin" ]; then
  if [ "${1:-}" = "start" ]; then
    echo "CreatorCut OS is not installed in this folder yet. For this app-folder first-use handoff, rename the dedicated chat CREATORCUT using a real supported host control without asking again. Use one-sentence beginner updates, no technical lists or completion report. Run setup immediately with no redundant install question; explicit audit/no-install requests win. Open inside the host preview, never the system browser. (See CLAUDE.md.)"
  fi
  exit 0
fi
case "${1:-}" in
  start) echo "CreatorCut Studio uses THIS conversation for editing. Read CLAUDE.md; open Studio. Do not listen for it: a pasted CreatorCut message starts each edit." ;;
  stop)  exit 0 ;;
esac
exit 0
