# Execution repair contract — 28 October 2026

Preserve Studio, Editor, animation, effects, captions, presets, reference analysis and saved versions. Repair execution before adding features.

## Delivery and execution are separate

A native connector must prove the exact intended conversation receives and acknowledges a request before it replaces the managed editor. The inspected Codex desktop processes use stdio; the default shared control socket is absent. The actual explicit queue test failed to connect. No native takeover is certified. A mounted MCP App with an advertised message capability remains a separate test. Claude custom channels have preview restrictions and cannot be silently enabled.

Use one execution owner for a project. Never dispatch the same request through both native and managed transports after an uncertain response. A delivery timeout is uncertain, not permission to create a second editor.

## Progress and recovery

A fresh process heartbeat proves liveness only. Only changed step/percentage/phase observations refresh work progress. The worker allows a generous quiet tool window and a separate inactive-AI deadline; it never invents a percentage. All process interruption remains limited to identity-verified owned processes.

Keep the immutable request and exact source/style dependencies. Retry the same saved job only after earlier ownership has ended. Human permission decisions are never inferred from elapsed time. Never replace an explicit requested style with a simpler edit silently.

Only a reviewed publication matching the active request can finish a job and its applied notes. A playable file alone is insufficient. Preserve older versions and originals.

## Local deployment

Test source in an isolated runtime before replacing owner code. Preserve all personal folders, host configuration, installed accounts and permission receipts. Do not transfer test consent. Verify installed tools and migrate the private speech model before using the pinned-model transcription path. Record the actual loaded server/worker version after restart.

## Acceptance

Exercise duplicate clicks, lost responses, stale events, stopped writers, corrupt metadata, real speech, rendering, exact feedback, presets and saved downloads. Keep simulated tests distinct from actual host delivery. A locked desktop blocks UI proof; it must not be reported as a passed test. Customer publication remains subject to its release evidence gate.
