# CreatorCut: visible-chat editing

Paste into this visible chat is the only customer path. Studio saves all choices, references and notes; THIS Claude Code or Codex conversation edits. Development editor modules are not a customer fallback and must not run under the shipped paste policy.

Open Studio with the normal supported host preview. Customer edits start only from the saved message pasted into the visible chat. Make and Update save the immutable request and show the Start in your chat card, which copies a message. Pasting that message into a Claude Code or Codex conversation is the only way an edit starts. It costs no idle usage and works in any open chat.

Read the exact request, then `workflow claim PROJECT --request REQUEST --delivery TOKEN` (no --owner; keep the unique owner ID it prints). Use `.venv/bin/python edit.py --delivery-token TOKEN ...` for editing commands in this app folder. A request is Saved until claimed. One request owns the project; a newer resume message makes an older one unable to write.

Every heavy command runs under a watcher. It ends a step that stops moving and restarts it once, ends any step past its hard limit, ends the step within seconds of Studio Stop, and ends it if the chat disappears. On the supported host, the watcher bounds the step. The watcher owns its unreaped child and does not require process-table visibility to stop that child. Keep all other normal host permissions; never bypass a denial. If it reports that it stopped responding, tell the customer plainly and run the same step once more; it continues from saved work.

Run the normal engine, exact choices, reference, memory, review and publication checks. Frame/signal-only review must disclose its limits. Existing files or a textual answer cannot finish a request. Reviewed publication for this exact request updates Studio and matching feedback. Failed or cancelled revisions return unapplied notes to the saved list. Preserve previous versions and originals.

One visible chat normally works on one video at a time. Extra requests stay saved. If the user pastes another video in a second chat, per-project ownership and serialized heavy work still apply.

## Continue an interrupted edit
After compaction, a cut-off reply, or a tool interruption, call `edit.py workflow next PROJECT --owner YOUR_CLAIMED_OWNER`. Keep the explicit owner used when claiming even if a host environment ID changes. The response restores the exact request, delivery capability, verified artifacts and next step; never expose it to another conversation. Carry the exact delivery with `--delivery-token TOKEN` on each edit.py command. Read the result, finish that step, then continue through review and publication. Do not end an edit turn until publication, a real `workflow block`, or a clear explanation of the permission/user answer you are waiting for.

Run long commands individually. In Claude Code, if Bash returns a background task ID, keep that ID, read its output and await its completion notification before the next step; do not lose ownership or launch a second command because the tool returned. In Codex, retain and poll the running command session until its exit. A live process heartbeat alone is not editing progress.

If this chat is gone, use **Continue in a new chat** in Studio. It safely requests that the current step stop before returning a fresh saved message. If you instead press **Stop edit**, wait for it to finish, then press **Try again**. Paste the fresh message into the chosen chat, claim it once without --owner and reuse verified completed work. Do not start a second writer while the current step is closing. Direct filesystem changes remain subject to normal host file permissions.

## Preflight and recovery boundaries
`workflow validate` through the CLI checks saved choices, asset/font paths, audio, memory rules, note keys and true reference windows before checking the actual host browser and estimated working space. The Python metadata-only validator labels its runtime checks as not performed; it is not a renderer readiness certificate. Duration/resolution estimates reserve space for frames and intermediate encodes. macOS uses its Important Usage capacity when available, with physical free space as fallback. Render-time physical-space checks still stop a job safely if the disk fills.

For a space blocker, `edit.py workflow clean-cache PROJECT` removes only that project's named regenerable font/history caches after confirming no command is active. It keeps the candidate, originals and versions; if those small caches do not free enough, free space elsewhere and retry the same saved step. A killed process releases its kernel locks; a live child retains the command fence until it exits.

When waiting for a real user answer or a known host permission, record it with `edit.py workflow wait PROJECT --reason user|permission --note "The exact next action"` using the current delivery token. Do not mark a wait as active rendering or invent progress. A later command reporting actual progress automatically restores the working display. Never auto-answer the permission. If the host pauses before you can record its prompt, do not claim Studio can observe that unseen prompt.

The watcher can detect the death of its owning tool process through its separate reaper. Merely closing a chat tab may leave the host tool process alive; that real-host case is unverified. It is not a guarantee that a closed chat wakes or resumes itself.
