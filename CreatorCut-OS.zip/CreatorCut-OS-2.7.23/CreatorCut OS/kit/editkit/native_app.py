"""Embedded Studio and visible-chat action tools. Managed tools are opt-in only."""
from __future__ import annotations
import contextlib,io,json,secrets,sys,time,threading
from pathlib import Path
from urllib.parse import urlparse
from . import util,videos

URI='ui://creatorcut/studio-'+(util.KIT/'VERSION').read_text().strip()+'.html'
MIME='text/html;profile=mcp-app'
_studio_info_lock=threading.Lock()

def grant(origin: str) -> str:
    if urlparse(origin).hostname not in {'127.0.0.1','localhost'}:
        raise util.Fail('The Studio must be local.')
    f=util.STUDIO_OUT/'embed-grants.json'
    d={k:v for k,v in util.read_json(f,default={}).items() if v.get('expires',0)>time.time()}
    nonce=secrets.token_urlsafe(32)
    d[nonce]={'expires':time.time()+3600,'origin':origin}
    util.write_json(f,d)
    return nonce

def tools():
    from . import project_tools
    if project_tools.bound_project():return project_tools.tools()
    result = [
      {'name':'creatorcut_wait_for_action','description':'Development-only transport fixture, disabled in customer paste mode. Customer Make and Update provide a saved message to paste into the visible chat. Respect normal host permissions.', 'inputSchema':{'type':'object','properties':{'conversation':{'type':'string','description':'Actual current native conversation ID.'},'seconds':{'type':'integer','minimum':1,'maximum':25}},'required':['conversation'],'additionalProperties':False}},
      {'name':'creatorcut_feedback','description':'Save actual editing feedback from THIS conversation immediately. Use project scope for scene-specific corrections; creator for clearly lasting general preferences; preset for lasting feedback about the selected style. Do not infer global scope from a one-off correction. This updates persistent local skills without another model. Use replace to supersede an exact old rule.', 'inputSchema':{'type':'object','properties':{'project':{'type':'string'},'text':{'type':'string'},'scope':{'type':'string','enum':['project','preset','creator']},'rule':{'type':'string'},'preset':{'type':'string'},'replace':{'type':'string'},'topic':{'type':'string','description':'Stable preference topic such as sound.effects or captions.entry; new feedback on this topic replaces a contradictory old rule.'},'remember_selected':{'type':'array','items':{'type':'string','enum':['caption','look','effects']},'description':'Only for an explicit lasting request to remember the currently selected executable style feature.'},'basis':{'type':'string','enum':['explicit','inferred'],'description':'Explicit lasting requests apply immediately. Inferred preferences require consistent evidence from two separate projects before becoming general.'}},'required':['project','text','scope'],'additionalProperties':False}},
      {'name':'creatorcut_studio','title':'CREATORCUT','description':'Open CreatorCut inside this host. Studio saves video choices. Paste the saved Make or Update message into THIS conversation to start editing. Keep normal host permissions.', 'inputSchema':{'type':'object','properties':{},'additionalProperties':False},'_meta':{'ui':{'resourceUri':URI},'openai/outputTemplate':URI,'openai/widgetAccessible':True}},
      {'name':'creatorcut_reply','description':'Legacy compatibility only: store an actual native reply in older Studio history. Current Studio has no duplicate chat box; normally reply in the host conversation itself. Never generate a canned status or claim another editor is needed. Use the same answer text you give in the native conversation. This writes display history only and performs no inference.', 'inputSchema':{'type':'object','properties':{'project':{'type':'string'},'text':{'type':'string'},'reply_id':{'type':'string'}},'required':['project','text'],'additionalProperties':False}},
      {'name':'creatorcut_context','description':'Read the Studio project, assets, settings and current editing state for this native conversation.', 'inputSchema':{'type':'object','properties':{},'additionalProperties':False}}
    ]
    from . import chat_execution
    if chat_execution.paste_only():
        result=[row for row in result if row['name']!='creatorcut_wait_for_action']
        for row in result:
            if row['name']=='creatorcut_studio':row['description']='Open CreatorCut. THIS conversation edits after you paste the saved Make or Update message here. Do not listen or start another AI.'
    return result


def _studio_info():
    from . import server
    util.STUDIO_OUT.mkdir(parents=True,exist_ok=True)
    # Keep stdout exclusively JSON-RPC.
    with _studio_info_lock:
        with contextlib.redirect_stdout(sys.stderr):
            return server.start_detached()

def resource():
    info=_studio_info();origin=f"http://localhost:{info['port']}"
    nonce=grant(origin)
    cfg=json.dumps({'url':origin+'/?cc_embed='+nonce,'nonce':nonce,'version':(util.KIT/'VERSION').read_text().strip()}).replace('<','\\u003c')
    js=(util.KIT/'studio/app/native-host.js').read_text().replace('</script','<\\/script')
    html='<!doctype html><html><head><meta charset="utf-8"><title>CREATORCUT</title><style>html,body{margin:0;height:100%;background:#f8f7f5}iframe{border:0;width:100%;height:100vh;min-height:640px}</style></head><body><iframe id="studio" title="CreatorCut Studio" sandbox="allow-scripts allow-same-origin allow-forms allow-downloads" src="'+origin+'/?cc_embed='+nonce+'"></iframe><script>window.CREATORCUT_EMBED='+cfg+';</script><script>'+js+'</script></body></html>'
    return {'uri':URI,'mimeType':MIME,'text':html,'_meta':{'ui':{'csp':{'frameDomains':[origin],'connectDomains':[origin],'resourceDomains':[origin]},'prefersBorder':False}}}

def call_tool(name,args,cancelled=None):
    from . import project_tools
    project=project_tools.bound_project()
    if project:
        result=project_tools.call(project,name,args)
        return {'content':[{'type':'text','text':json.dumps(result,ensure_ascii=False)}]}
    if name=='creatorcut_wait_for_action':
        from .native_receiver import wait
        result=wait(min(25,int(args.get('seconds',25))),args.get('conversation'),cancelled)
        return {'content':[{'type':'text','text':json.dumps(result,ensure_ascii=False)}],'structuredContent':result}
    if name=='creatorcut_feedback':
        from . import learn
        payload=dict(args);parts=payload.pop('remember_selected',None)
        result=learn.capture_feedback(**payload)
        if parts:result['executable_preference']=learn.bind_library_preference(payload['project'],payload.get('rule',''),payload['scope'],parts,payload.get('preset',''))
        return {'content':[{'type':'text','text':json.dumps(result)}],'structuredContent':result}
    if name=='creatorcut_studio':
        info=_studio_info()
        return {'content':[{'type':'text','text':'CreatorCut is open beside THIS editing conversation. Make and Update provide a saved message to paste into this chat. Do not listen or poll. Claim each exact request/delivery before editing. The paste card is the normal delivery path. Never start a second editor; retain normal permissions.'}], 'structuredContent':{'studioUrl':info['url'],'conversation':'current visible conversation','requires':'Video tools and the normal permissions of this native host'}}
    if name=='creatorcut_context':
        return {'content':[{'type':'text','text':videos.context_text()}]}
    if name=='creatorcut_reply':
        pid=str(args.get('project',''));text=str(args.get('text','')).strip()
        if not text or len(text)>6000:raise util.Fail('A non-empty actual reply up to 6000 characters is required.')
        videos.load(pid)
        rid=str(args.get('reply_id',''))[:128]
        if rid and any(m.get('native_reply_id')==rid for m in videos.chat(pid)):
            return {'content':[{'type':'text','text':'Already mirrored.'}]}
        msg=videos.say(pid,'editor',text,native=True,native_reply_id=rid)
        return {'content':[{'type':'text','text':'Reply mirrored from this conversation.'}], 'structuredContent':{'message_id':msg['id']}}
    raise util.Fail('Unknown CreatorCut tool.')

def handle(req,cancelled=None):
    method=req.get('method');params=req.get('params') or {}
    if method=='initialize':
        from . import project_tools
        if project_tools.bound_project():return {'protocolVersion':params.get('protocolVersion','2025-06-18'),'capabilities':{'tools':{}},'serverInfo':{'name':'creatorcut-project','version':'1.0.0'},'instructions':'This is the assigned persistent video editor. Read creatorcut_project_context and use creatorcut_plan_save for validated JSON plans. These tools are bound to this one project. Complete the existing immutable request; do not start another editor or wait for a native chat. Rendering commands still use the normal host permissions.'}
        return {'protocolVersion':params.get('protocolVersion','2025-06-18'),'capabilities':{'tools':{},'resources':{}},'serverInfo':{'name':'creatorcut-native','version':(util.KIT/'VERSION').read_text().strip()},'instructions':'You are the editor in THIS visible native conversation. CreatorCut is its interface. Open Studio. Make, Update and resume provide a saved message to paste into this chat. Do not listen or poll. Claim the exact request/delivery and edit here; no second model or managed session. Each pasted message names the exact saved request. Local commands retain normal host permissions.'}
    if method=='ping':return {}
    if method=='tools/list':return {'tools':tools()}
    if method=='resources/list':return {'resources':[{'uri':URI,'name':'CREATORCUT','mimeType':MIME}]}
    if method=='resources/templates/list':return {'resourceTemplates':[]}
    if method=='resources/read':
        if params.get('uri')!=URI:raise util.Fail('Unknown resource.')
        return {'contents':[resource()]}
    if method=='tools/call':return call_tool(params.get('name'),params.get('arguments') or {},cancelled)
    raise util.Fail('Unsupported MCP method.')

def serve():
    import threading
    from concurrent.futures import ThreadPoolExecutor
    output=sys.stdout
    write_lock=threading.Lock();pending_lock=threading.Lock();pending={}
    pool=ThreadPoolExecutor(max_workers=4)
    def write(out):
        with write_lock:
            print(json.dumps(out,ensure_ascii=False),file=output,flush=True)
    def execute(req,cancelled):
        try:
            if cancelled.is_set():
                out={'jsonrpc':'2.0','id':req['id'],'error':{'code':-32800,'message':'Request cancelled.'}}
            else:
                result=handle(req,cancelled)
                out={'jsonrpc':'2.0','id':req['id'],'result':result}
        except (util.Fail,ValueError,TypeError) as e:
            out={'jsonrpc':'2.0','id':req['id'],'error':{'code':-32602,'message':str(e)}}
        except Exception:
            util.log_exception('native MCP request')
            out={'jsonrpc':'2.0','id':req['id'],'error':{'code':-32603,'message':'The Studio tool failed. Inspect its local log; your conversation remains in the host.'}}
        finally:
            with pending_lock:pending.pop(req['id'],None)
        write(out)
    try:
        for line in sys.stdin:
            try:
                if len(line)>1000000:continue
                req=json.loads(line)
                if not isinstance(req,dict):continue
                if req.get('method')=='notifications/cancelled':
                    with pending_lock:
                        event=pending.get((req.get('params') or {}).get('requestId'))
                        if event:event.set()
                    continue
                if 'id' not in req:continue
                cancelled=threading.Event()
                with pending_lock:
                    if len(pending) >= 64:
                        write({'jsonrpc':'2.0','id':req['id'],'error':{'code':-32000,'message':'Too many active requests. Let the current operation finish.'}})
                        continue
                    if req['id'] in pending:
                        write({'jsonrpc':'2.0','id':req['id'],'error':{'code':-32600,'message':'Request ID is already active.'}})
                        continue
                    pending[req['id']]=cancelled
                if req.get('method') == 'tools/call':
                    pool.submit(execute,req,cancelled)
                else:
                    execute(req,cancelled)
            except (json.JSONDecodeError,TypeError):
                write({'jsonrpc':'2.0','id':None,'error':{'code':-32700,'message':'Invalid JSON request.'}})
    finally:
        with pending_lock:
            for event in pending.values():event.set()
        # Return cancellation responses for queued tools rather than silently
        # dropping their request IDs on a half-closed stdio connection.
        pool.shutdown(wait=True,cancel_futures=False)

def configure(project_root=None):
    """Register in the host's actual project, which may differ from the app folder.

    This only registers tools; the host must trust/reload to load the UI.
    Managed Make/Update execution is independent of native ui/message.
    """
    root=Path(project_root).expanduser().resolve() if project_root else util.ROOT.resolve()
    if not root.is_dir() or root == Path.home().resolve() or root == Path(root.anchor):
        raise util.Fail('Choose the actual project folder, not your home or system folder.')
    cmd=str(Path(sys.executable).resolve());entry=str(util.KIT/'tools/native_mcp.py')
    mcp_file=root/'.mcp.json';d=util.read_json(mcp_file,default={})
    d.setdefault('mcpServers',{})['creatorcut']={'command':cmd,'args':[entry]}
    # Validate both formats before modifying either configuration.
    # Add only our own project MCP block; preserve all existing unrelated config.
    from . import editor
    if editor.provider_name()=='claude':
        util.write_json(mcp_file,d)
        return {'registered':'project only','project':str(root),'connected':False,'requires':'Native Claude Code tools and normal project permissions.'}
    f=root/'.codex/config.toml'
    text=f.read_text() if f.exists() else ''
    import re
    text=re.sub(r'(?ms)^# BEGIN CREATORCUT MCP\n.*?^# END CREATORCUT MCP\n?', '',text)
    if re.search(r'^\[mcp_servers\.creatorcut\]',text,re.M):
        raise util.Fail('An existing creatorcut MCP entry needs review before replacement.')
    text+='\n# BEGIN CREATORCUT MCP\n[mcp_servers.creatorcut]\ncommand = '+json.dumps(cmd)+'\nargs = ['+json.dumps(entry)+']\n# END CREATORCUT MCP\n'
    import tomllib
    tomllib.loads(text)
    util.write_json(mcp_file,d)
    f.parent.mkdir(parents=True,exist_ok=True)
    f.write_text(text)
    return {'registered':'project only','project':str(root),'connected':False,'requires':'Respect host MCP trust/reload. Make and Update save a message to paste into this conversation. Normal project permissions remain in force.'}
