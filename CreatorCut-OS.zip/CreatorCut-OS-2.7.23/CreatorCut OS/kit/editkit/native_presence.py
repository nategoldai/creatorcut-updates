"""Authenticated Studio view presence; ephemeral leases, never a persistent editor."""
import threading,time
from . import deadlines
_lock=threading.Lock()
_views={}
def touch(view,opened=True):
 if not isinstance(view,str) or not 1<=len(view)<=96:return status()
 with _lock:
  if opened:_views[view]=deadlines.after(65)
  else:_views.pop(view,None)
 return status()
def status():
 with _lock:
  now=time.monotonic()
  for key in list(_views):
   if deadlines.remaining(_views[key])<=0:_views.pop(key,None)
  return {'open':bool(_views)}
