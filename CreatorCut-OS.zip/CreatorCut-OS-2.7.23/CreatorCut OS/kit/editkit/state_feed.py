"""Coalesce simultaneous tabs; never import changing modules during an update."""
import threading,time,copy
from . import util,maintenance
_lock=threading.Lock();_snapshot=None;_root=None;_at=0

def snapshot():
 global _snapshot,_root,_at
 with _lock:
  if maintenance.active():
   result=copy.deepcopy(_snapshot) if _root==util.ROOT and _snapshot else {'projects':[],'version':''}
   result['update']=util.read_json(util.STUDIO_OUT/'update.json',default={})
   return result
  if _root==util.ROOT and _snapshot is not None and time.monotonic()-_at<.4:return copy.deepcopy(_snapshot)
  try:
   with maintenance.read():
    from . import state
    result=state.snapshot()
  except maintenance.Busy:return copy.deepcopy(_snapshot or {'projects':[],'version':''})
  _snapshot=copy.deepcopy(result);_root=util.ROOT;_at=time.monotonic();return result
