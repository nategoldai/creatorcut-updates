"""Foreground native-conversation client for Studio actions. No inference."""
import json
import os
import time
import urllib.request
import urllib.error
from . import util,deadlines


def wait(seconds=100, conversation=None, cancelled=None, require_open=True):
    from . import chat_execution
    if chat_execution.paste_only():return {'native_action':None,'state':'paste_only','message':'Make gives a saved message to paste into your chat. No background message connection is needed.'}
    receiver = conversation or os.environ.get('CODEX_THREAD_ID') or os.environ.get('CLAUDE_SESSION_ID')
    if not receiver:
        raise util.Fail('Call this tool from the existing editing conversation with its conversation ID.')
    def post(path, body):
        # Studio can restart or move to a free port while this native turn
        # remains open. Never retain the old token/port for the whole wait.
        info = util.read_json(util.STUDIO_OUT / 'server.json')
        credentials = util.read_json(util.STUDIO_OUT / 'native-agent.json')
        origin = 'http://127.0.0.1:' + str(int(info['port']))
        req = urllib.request.Request(origin + '/api/native/' + path, data=json.dumps(body).encode(),
            headers={'Content-Type': 'application/json', 'X-AIE-Token': credentials['api_token'], 'X-CreatorCut-Agent': credentials['key']})
        with urllib.request.urlopen(req, timeout=4) as response:
            return json.load(response)

    deadline = deadlines.after(min(100, max(1, seconds)))
    interrupted = False
    while deadlines.remaining(deadline) > 0:
        if cancelled is not None and cancelled.is_set():
            return {'native_action': None, 'state': 'cancelled'}
        # A killed/disconnected caller must not leave Studio showing a live
        # receiver for another 25 seconds. Leases expire within one second.
        try:
            if require_open:
                opened=post('presence-status',{}).get('open')
                if cancelled is not None and cancelled.is_set():return {'native_action':None,'state':'cancelled'}
                if not opened:return {'native_action':None,'state':'studio_closed'}
            result = post('receive', {'receiver': receiver, 'timeout': min(1, deadlines.remaining(deadline))})
            interrupted = False
        except urllib.error.HTTPError as error:
            # A changed server has new credentials. Only authorization/server
            # restart errors are retried; a conflicting consumer stays explicit.
            if error.code not in (401, 403, 502, 503, 504):
                raise
            interrupted = True
        except (OSError, ValueError, util.Fail):
            interrupted = True
        if interrupted:
            delay = min(.2, max(0, deadlines.remaining(deadline)))
            if cancelled is not None:
                cancelled.wait(delay)
            else:
                time.sleep(delay)
            continue
        action = result.get('action')
        if action:
            if cancelled is not None and cancelled.is_set():
                return {'native_action': None, 'state': 'cancelled'}
            # Once received, never lose the actual action just because the
            # acknowledgement connection broke. Returning it lets this native
            # editor claim the project; Studio reconciles that real claim.
            try:
                receipt = post('ack', {'receiver': receiver, 'request_id': action['request_id']})
            except (OSError, ValueError, util.Fail):
                receipt = {'accepted': False, 'state': 'unconfirmed'}
            action['state'] = 'delivered' if receipt.get('accepted') else 'receipt_unconfirmed'
            return {'native_action': action, 'receipt': receipt, 'instruction': 'Development transport returned a saved action. Read its exact brief and claim before editing here. Customer requests use a saved message pasted into this chat; never launch another model.'}
    return {'native_action': None, 'state': 'connection_unavailable' if interrupted else 'wait_finished', 'instruction': 'No development action arrived. End this bounded operation. Customer Make and Update provide saved messages to paste into the visible chat.'}


def studio_open():
 info=util.read_json(util.STUDIO_OUT/'server.json')
 credentials=util.read_json(util.STUDIO_OUT/'native-agent.json')
 request=urllib.request.Request('http://127.0.0.1:'+str(int(info['port']))+'/api/native/presence-status',data=b'{}',headers={'Content-Type':'application/json','X-AIE-Token':credentials['api_token'],'X-CreatorCut-Agent':credentials['key']})
 with urllib.request.urlopen(request,timeout=2) as response:return json.load(response).get('open') is True
