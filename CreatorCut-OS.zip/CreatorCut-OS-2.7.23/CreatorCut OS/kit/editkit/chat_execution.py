"""Visible-conversation execution. Durable requests; no model, provider or daemon launch."""
import os,secrets,time,contextvars
from contextlib import contextmanager
_command_fd=contextvars.ContextVar("creatorcut_native_command_fd",default=None)

def inherited_fds():
 fd=_command_fd.get()
 return () if fd is None else (fd,)

@contextmanager
def command_guard(p):
 with util.file_guard(p/".chat-command.guard","Another editing step is running. Wait for it to finish.",retain_in_children=True) as stream:
  token=_command_fd.set(stream.fileno())
  try:yield
  finally:_command_fd.reset(token)

from . import util

def mode():
 # Package delivery policy wins over an older installation's managed config.
 if paste_only():return 'chat'
 from . import editor
 policy=util.read_json(util.ROOT/'kit/execution-policy.json',default={})
 value=editor.config().get('editor_mode',policy.get('default_editor_mode','managed'))
 if value not in ('chat','managed'):raise util.Fail('The saved editor mode is invalid. Choose chat or managed.')
 return value

def paste_only():
 return util.read_json(util.ROOT/'kit/execution-policy.json',default={}).get('chat_delivery')=='paste'

def configure(value):
 from . import editor,activity_store
 if value not in ('chat','managed'):raise util.Fail('Choose chat or managed editing.')
 if value=='managed' and paste_only():raise util.Fail('This CreatorCut installation edits in your visible chat. Use the saved paste message to start.')
 with util.file_guard(editor.control()/'configuration.guard',timeout=5):
  if any(editor.read(pid).get('state') in editor.ACTIVE for pid in editor.all_projects()) or any(row.get('running') for row in activity_store.records()):
   raise util.Fail('Finish or stop your current edit before changing its editing connection.')
  worker=editor.safe_json(editor.control()/'worker.json')
  if value=='chat' and editor.same_process(worker.get('pid'),worker.get('birth')):
   raise util.Fail('Close the managed editor service before switching this installation to chat mode.')
  cfg=editor.config();cfg['editor_mode']=value;util.write_durable_json(editor.root()/'config.json',cfg)
 return {'mode':value,'changed':True,'starts_editor':False}

def message(pid,rid,update=False,token=None):
 from . import videos
 title=str(videos.load(pid).get('title') or pid).replace('\n',' ')[:70]
 if paste_only():
  engine=str(util.ROOT.resolve()/'edit.py')
  return ('CreatorCut: '+('update' if update else 'make')+' my video "'+title+'"\nEngine: '+engine+'\nProject: '+pid+'\nRequest: '+rid+'\nDelivery: '+str(token or '')+
          '\nOpen that engine’s folder as this chat’s project. Use its working directory and .venv/bin/python edit.py --delivery-token '+str(token or '')+' for editing commands. Follow AGENTS.md beside that engine. Read the saved request with the engine\'s studio context command, claim it with workflow claim using this project, request and delivery without --owner; keep the unique owner ID printed by claim, then edit it here with the CreatorCut edit skill.')
 text=('CreatorCut: '+('update' if update else 'make')+' my video "'+title+'"\n'
         '(project '+pid+', request '+rid+', delivery '+str(token or '')+') — read it with edit.py studio context '+pid+
         ', claim it with edit.py workflow claim '+pid+' --request '+rid+(' --delivery '+token if token else '')+
         ' --owner DEV_OWNER_ID, then edit it in this chat with the CreatorCut edit skill.')
 if len(text)>499:
  text=('CreatorCut: '+('update' if update else 'make')+' my video "'+title[:30]+'"\n'
        'project='+pid+' request='+rid+' delivery='+str(token or '')+'; read edit.py studio context "$project"; claim edit.py workflow claim "$project" --request "$request" --delivery "$delivery" --owner DEV_OWNER_ID; then edit here with the CreatorCut edit skill.')
 return text

def refresh_moved_messages():
 from . import editor
 for pid in editor.all_projects():
  job=editor.read(pid)
  if job.get('execution_mode')=='chat' and job.get('state')=='queued' and not job.get('claimed_owner'):
   new=message(pid,job['request_id'],job.get('previous_version',0)>0,job.get('delivery_token'))
   if job.get('native_message')!=new:job['native_message']=new;editor.store_job(pid,job)


def response(job,deliver=False):
 return {'accepted':True,'project':job['project'],'request_id':job['request_id'],'job':job['id'],'state':job['state'],'state_seq':job.get('state_seq',0),'updated':job['updated'],'message':job['message'],'transport':'native_chat','deliver':deliver,'native_message':job['native_message'],'delivery_state':job.get('delivery_state','unknown'),'delivery_id':job.get('delivery_id',job['request_id']),'delivery_token':job.get('delivery_token'),'delivery_generation':job.get('delivery_generation',0),'paste_only':paste_only(),'foreground_queued':not paste_only() and job.get('native_transport')=='foreground'}

def finished_response(pid,rid,job):
 from . import videos
 from .workflow import digest
 if job.get('state')!='succeeded' or job.get('request_id')!=rid:return None
 p=videos._dir(pid)
 for version in reversed(videos.versions(pid)):
  movie=util.ROOT/version['file'];review=util.read_json(util.ROOT/version.get('review_file',''),default={}) if version.get('review_file') else {}
  scenes=util.read_json(p/'versions'/f"v{version['n']}.scenes.json",default={})
  if not(version['n']==job.get('version') or scenes.get('request_id')==rid):continue
  expected=version.get('candidate_sha256')
  if not expected or review.get('candidate_sha256')!=expected or not movie.is_file() or digest(movie)!=expected:continue
  result=response(dict(job,execution_mode='chat',native_message='',delivery_state='finished',delivery_token=job.get('delivery_token','')))
  return dict(result,already_finished=True,version=version['n'],message='Opening your saved video.')
 return None

def reserve(pid,rid,transport="foreground"):
 from . import editor,videos,requests
 p=videos._dir(pid)
 completed=finished_response(pid,rid,editor.read(pid))
 if completed:return completed
 from . import readiness
 if readiness.status().get('state') in ('checking','repair'):raise util.Fail('Your editing tools are still being prepared. Your footage and choices are saved.','Finish setup or check the tools again, then make this video.')
 if transport not in ('foreground','mcp','paste'):raise util.Fail('Unsupported native editing connection.')
 import shutil
 if shutil.disk_usage(p).free<2_500_000_000:raise util.Fail('Free at least 2.5 GB before editing. Your footage and settings are saved.')
 old=editor.read(pid)
 if old.get('request_id')==rid and old.get('state')!='succeeded':
  if paste_only() and old.get('execution_mode')!='chat':return migrate_legacy_request(pid,expected_request_id=rid)
  if old.get('execution_mode')=='chat' and old.get('state') in editor.TERMINAL:return recover(pid,expected_request_id=rid)
 with editor.paste_worker_guard(),util.file_guard(p/'.request.guard',timeout=5),util.file_guard(p/'.editor-job.guard',timeout=5):
  request=requests.active(p)
  if not request or request['id']!=rid:raise util.Fail('Save the current video settings before starting this edit.')
  old=editor.read(pid)
  if old.get('request_id')==rid:
   if old.get('execution_mode')!='chat':raise util.Fail('This request already belongs to another editing connection.')
   return response(old)
  if old.get('state') in editor.ACTIVE:raise util.Fail('This video already has an editor. Your new settings are saved.')
  now=time.time();job={'schema':1,'id':secrets.token_hex(16),'project':pid,'request_id':rid,'execution_mode':'chat','state':'queued','message':'Waiting for your chat to receive this edit','created':now,'updated':now,'activity_at':now,'attempts':0,'provider':'native','previous_version':max((v['n'] for v in videos.versions(pid)),default=0),'delivery_state':'reserved','native_message':message(pid,rid,bool(request.get('batch')))}
  _new_delivery(job,transport)
  if paste_only():job['delivery_state']='unavailable'
  elif transport=='foreground':
   from .native_actions import BROKER
   if not BROKER.status().get('connected'):job['delivery_state']='unavailable'
  editor.store_job(pid,job)
  # Only the first reservation authorizes a send. Lost replies never authorize another.
  return response(job,deliver=transport=="mcp" and not paste_only())

def delivery(pid,rid,outcome,token=None):
 from . import editor,videos
 if outcome not in ('delivered','unconfirmed','unavailable'):raise util.Fail('Invalid conversation delivery result.')
 p=videos._dir(pid)
 with util.file_guard(p/'.editor-job.guard',timeout=5):
  job=editor.read(pid)
  if job.get('execution_mode')!='chat' or job.get('request_id')!=rid:raise util.Fail('This delivery belongs to a different edit.')
  if token is not None and token!=job.get('delivery_token'):return response(job)
  if job.get('state')!='queued':return response(job)
  if job.get('delivery_state')=='delivered':return response(job)
  job.update(delivery_state=outcome,message='Waiting for your chat to start the saved edit' if outcome=='delivered' else 'Open your connected editing chat to start this saved edit' if outcome=='unavailable' else 'Delivery is unconfirmed. Check your chat before resending.',updated=time.time());editor.store_job(pid,job)
  return response(job)

def claim(p,request_id,owner,delivery_token=None):
 from . import editor,requests
 message='This edit is already running in a chat. Continue there with workflow next, or choose Continue in a new chat in Studio.'
 with util.file_guard(p/'.request.guard',message,timeout=5),util.file_guard(p/'.editor-job.guard',message,timeout=5):
  job=editor.read(p.name);request=requests.active(p)
  if job.get('execution_mode')!='chat':raise util.Fail('This request is not assigned to visible-chat editing.')
  if not request_id or request.get('id')!=request_id or job.get('request_id')!=request_id:raise util.Fail('Claim the exact saved video request; a different request cannot start.')
  if job.get('delivery_token') and delivery_token!=job['delivery_token']:raise util.Fail('This delivery was replaced. Read the newest saved request; this older message cannot start editing.')
  if job.get('cancel') or job.get('state') in editor.TERMINAL:raise util.Fail('This saved edit has stopped or finished. Do not start another writer.')
  conversation=owner.strip()
  if not conversation:raise util.Fail('Identify the conversation doing this edit.')
  if job.get('delivered_to') and conversation!=job['delivered_to']:raise util.Fail('This request was delivered to another conversation.')
  if paste_only() and job.get('claimed_owner'):raise util.Fail('This edit is already running in a chat. Continue there with workflow next, or choose Continue in a new chat in Studio to stop it and get a new message.')
  if job.get('claimed_owner') and job['claimed_owner']!=conversation:raise util.Fail('Another conversation already claimed this edit.')
  job.update(state='editing',claimed_delivery=job.get('delivery_token'),claimed_owner=conversation,claimed_at=time.time(),claimed_host_id=os.environ.get('CODEX_THREAD_ID') or os.environ.get('CLAUDE_SESSION_ID') or '',activity_at=time.time(),updated=time.time(),message='Editing in your conversation');editor.store_job(p.name,job)
  return job

def wait_for_user(p,kind,note):
 """Record an explicit real wait, never infer approval or manufacture work."""
 from . import editor
 if kind not in ('permission','user') or not str(note).strip():raise util.Fail('Describe the permission or user answer this edit is waiting for.')
 with util.file_guard(p/'.editor-job.guard',timeout=5):
  require_owner(p)
  job=editor.read(p.name);job.update(waiting={'kind':kind,'note':str(note)[:500],'since':time.time()},updated=time.time())
  editor.store_job(p.name,job)
 return status(p.name)

def reconcile(pid):
 from . import editor
 job=editor.read(pid)
 if job.get('execution_mode')!='chat':return
 if job.get('state')=='succeeded':return
 version=editor.published(job)
 if version:editor.finish_success(job,version)

def status(pid):
 from . import editor
 job=editor.read(pid)
 if job.get('execution_mode')!='chat':return None
 if job.get('cancel') and job.get('state') not in editor.TERMINAL:
  # Cancellation can arrive during a render. Finish stopping once that owned
  # command exits; a dead chat must not leave this video marked editing forever.
  editor.cancel(pid);job=editor.read(pid)
 result={k:job[k] for k in ('id','state_seq','state','message','created','updated','activity_at','request_id','version','delivery_state','execution_mode','native_message','delivery_token','delivery_id','delivery_expires_at') if k in job}
 if job.get('state')=='queued' and paste_only():result.update(native_saved=True,message='Saved. Paste the message in your chat to start.')
 if job.get('state')=='queued' and not paste_only() and job.get('delivery_expires_at',float('inf'))<time.time():
  result.update(native_saved=True,message='Waiting for your chat to start…')
 if job.get('state')=='editing':
  from . import activity_store
  work=activity_store.latest(pid);last=max(float(job.get('activity_at',0)),float(work.get('progress_at',0)))
  result['last_update_seconds']=max(0,int(time.time()-last))
  watched=activity_store.watched_step(pid)
  working=bool(watched) or bool(work.get('running') and -5<=time.time()-max(float(work.get('heartbeat') or work.get('updated') or 0),float(work.get('progress_at') or 0))<15)
  result['activity_state']='working' if working else 'no_activity'
  if watched:result['watched_step']=watched.get('step')
  waiting=job.get('waiting') or {}
  if not working and waiting.get('kind') in ('permission','user') and last<=float(waiting.get('since',0)):
   result.update(waiting=waiting,activity_state='waiting_'+waiting['kind'],message=waiting.get('note','Open your chat to continue.'))
  elif not working:
   result['chat_hint']='Your request is saved. Open your chat to continue.'
   if time.time()-last>600:result.update(stalled=True,message="Your chat hasn't reported work for 10 minutes. Open it to continue. Your edit is saved.")
 if job.get('state')=='queued' and not paste_only():
  queue=sorted((editor.read(pid) for pid in editor.all_projects()),key=lambda row:row.get('created',0))
  ahead=sum(1 for row in queue if row.get('execution_mode')=='chat' and row.get('id')!=job.get('id') and not row.get('cancel') and (row.get('state')=='editing' or row.get('state')=='queued' and row.get('created',0)<job.get('created',0)))
  result['queue_position']=ahead+1
 return result


def _new_delivery(job,transport):
 token=secrets.token_hex(16);now=time.time()
 job.update(delivery_token=token,delivery_id=job['request_id']+':'+token,
            delivery_generation=job.get('delivery_generation',0)+1,native_transport=transport,
            delivery_state='reserved',delivery_started_at=now,delivery_expires_at=now+90)
 job['native_message']=message(job['project'],job['request_id'],job.get('previous_version',0)>0,token)
 job.pop('delivered_to',None)

def resend(pid,transport='foreground'):
 from . import editor,videos
 p=videos._dir(pid)
 with util.file_guard(p/'.request.guard',timeout=5),util.file_guard(p/'.editor-job.guard',timeout=5):
  job=editor.read(pid)
  if job.get('execution_mode')!='chat' or job.get('state')!='queued' or job.get('claimed_owner') or job.get('cancel'):
   raise util.Fail('This edit has already started or stopped. Continue it in the owning conversation.')
  if transport not in ('foreground','mcp','paste'):raise util.Fail('Unsupported native editing connection.')
  if job.get('delivery_state')!='unavailable' and time.time()<job.get('delivery_expires_at',float('inf')):
   return response(job)
  _new_delivery(job,transport);job.update(message='Saved. Open your CreatorCut chat to start.',updated=time.time())
  editor.store_job(pid,job);return response(job,deliver=transport=='mcp')

def validate_receiver(receiver):
 from . import editor
 for pid in editor.all_projects():
  job=editor.read(pid)
  if job.get('execution_mode')=='chat' and job.get('state')=='editing' and job.get('delivered_to') and job.get('delivered_to')!=receiver:
   raise util.Fail('Another CreatorCut chat is editing for this installation. Use the paste card in a second chat for a separate video.')

def take_pending(receiver):
 from . import editor
 if mode()!='chat' or paste_only():return None
 validate_receiver(receiver)
 # A receiver handles one project at a time, including the delivery-to-claim gap.
 for pid in editor.all_projects():
  active=editor.read(pid)
  if active.get('execution_mode')=='chat' and not active.get('cancel') and ((active.get('state')=='editing' and active.get('claimed_owner')==receiver) or (active.get('state')=='queued' and active.get('delivered_to')==receiver and active.get('delivery_state') in ('sent','delivered'))):return None
 rows=[]
 for pid in editor.all_projects():
  try:
   row=editor.read(pid)
   if (row.get('execution_mode')=='chat' and row.get('state')=='queued' and not row.get('cancel')
       and row.get('native_transport')=='foreground' and row.get('delivery_state') in ('reserved','unavailable')):rows.append(row)
  except (OSError,util.Fail):continue
 for row in sorted(rows,key=lambda x:x.get('created',0)):
  p=util.PROJECTS/row['project']
  with util.file_guard(p/'.editor-job.guard',timeout=1):
   job=editor.read(row['project'])
   if job.get('state')!='queued' or job.get('delivery_token')!=row.get('delivery_token') or job.get('delivery_state') not in ('reserved','unavailable'):continue
   job.update(delivery_state='sent',delivered_to=receiver,delivery_expires_at=time.time()+90,updated=time.time(),message='Delivered. Waiting for your chat to claim the edit.')
   editor.store_job(job['project'],job)
   return {'request_id':job['delivery_id'],'immutable_request_id':job['request_id'],'delivery_token':job['delivery_token'],'project':job['project'],'text':job['native_message'],'state':'delivering','time':time.time()}
 return None

def acknowledge(action):
 from . import editor
 if not action or not action.get('immutable_request_id'):return
 job=editor.read(action['project'])
 if job.get('delivery_id')==action['request_id']:
  delivery(action['project'],job['request_id'],'delivered',action.get('delivery_token'))

def require_owner(p):
 from . import editor
 job=editor.read(p.name)
 if job.get('execution_mode')!='chat' or not job.get('delivery_token'):return
 if job.get('state')!='editing' or job.get('cancel') or job.get('claimed_delivery')!=job['delivery_token']:
  raise util.Fail('Claim the newest saved native request before editing this project.')
 if os.environ.get('CREATORCUT_NATIVE_DELIVERY')!=job['delivery_token']:
  raise util.Fail('Use the current native delivery token with this command. An older delivery cannot edit this video.')

def recover(pid,expected_request_id=None):
 """User-directed same-request takeover; serialize with every native CLI writer."""
 from . import editor,videos,activity_store,requests
 p=videos._dir(pid)
 with editor.paste_worker_guard(),util.file_guard(p/'.chat-command.guard','Stop the current editing step before resuming in another chat.'),util.file_guard(p/'.editor.guard',timeout=5),util.file_guard(p/'.request.guard',timeout=5),util.file_guard(p/'.editor-job.guard',timeout=5):
  job=editor.read(pid)
  if expected_request_id is not None and job.get('request_id')!=expected_request_id:raise util.Fail('This saved request changed. Use the newest message from Studio.')
  if job.get('execution_mode')!='chat':raise util.Fail('This saved request uses another editing connection.')
  if job.get('state')=='succeeded':raise util.Fail('This edit is already finished. Open its saved video.')
  if any(row.get('running') and row.get('project')==pid for row in activity_store.records()):
   raise util.Fail('Stop the current editing step before resuming in another chat. Your request is saved.')
  if requests.active(p).get('id')!=job.get('request_id'):raise util.Fail('Your choices changed. Make the video with your current settings.')
  if job.get('state')=='editing' and not job.get('cancel') and time.time()-float(job.get('activity_at',0))<=600:
   raise util.Fail('This chat may still be editing. Stop this edit before moving it to another chat.')
  # Revoke first. A crash between these atomic file replacements leaves a queued,
  # unclaimed job, never two writers. A repeated recovery repairs the stale lease.
  fresh=job.get('state')=='queued' and not job.get('claimed_owner') and not job.get('cancel') and job.get('recovery_delivery')==job.get('delivery_token') and bool(job.get('delivery_token'))
  job.update(state='queued',cancel=False,updated=time.time(),message='Your edit is saved. Paste the new start message in your chat.')
  for key in ('claimed_owner','claimed_host_id','claimed_delivery','failure_note','waiting'):job.pop(key,None)
  if not fresh:
   _new_delivery(job,'foreground');job['recovery_delivery']=job['delivery_token']
  job['delivery_state']='unavailable'
  editor.store_job(pid,job)
  flow=util.read_json(p/'workflow.json',default={})
  flow.update(owner=None,lease_until=0,phase='waiting_editor',request_id=job['request_id'],updated=time.time(),message='Saved. Continue in your chat.')
  util.write_durable_json(p/'workflow.json',flow)
  return response(job)

def retry(pid):
 from . import editor
 job=editor.read(pid)
 if job.get('state') not in editor.TERMINAL-{'succeeded'}:return response(job)
 return recover(pid)

def continue_in_new_chat(pid):
 """Stop first; rotate only after the watcher and its children release ownership."""
 from . import editor
 job=editor.read(pid)
 if paste_only() and job.get('execution_mode')!='chat':return migrate_legacy_request(pid)
 if job.get('state')=='succeeded':return dict(response(job),finished=True)
 if job.get('state')=='queued' and not job.get('claimed_owner'):return response(job)
 stopped=editor.cancel(pid)
 if stopped.get('state') not in ('cancelled','failed'):return {'stopping':True,'project':pid,'request_id':job.get('request_id'),'message':'Stopping the current step. Your finished work is kept.'}
 try:return recover(pid)
 except util.LockBusy:return {'stopping':True,'project':pid,'request_id':job.get('request_id'),'message':'The current step is closing. Your finished work is kept.'}

@contextmanager
def renderer_check_guard(p):
 """Setup scratch checks have no job; claimed checks share the edit's fence."""
 from . import editor
 if p.resolve().parent!=util.PROJECTS.resolve() or editor.read(p.name).get('execution_mode')!='chat':
  yield None;return
 with command_guard(p):
  require_owner(p);job=editor.read(p.name)
  import hashlib
  yield {'request_id':job['request_id'],'delivery_sha256':hashlib.sha256(job['delivery_token'].encode()).hexdigest()}
  require_owner(p)

def record_renderer_check(p,result,binding):
 """Explain a real prerequisite stop; never create or approve a permission."""
 if binding is None:return
 from . import editor
 require_owner(p)
 with util.file_guard(p/'.editor-job.guard',timeout=5):
  require_owner(p);job=editor.read(p.name);now=time.time()
  if result.get('prerequisites_passed') is True:
   if (job.get('waiting') or {}).get('source')=='renderer_check':
    job.pop('waiting',None);job.update(message='Editing in your conversation',updated=now);editor.store_job(p.name,job)
   return
  needed=result.get('requested_permissions') or {}
  if needed.get('command_approval'):
   note=needed['command_approval']['request']
  elif needed.get('network',{}).get('enabled'):
   note='Open your chat for the renderer’s network access request. That permission also allows internet access; only you can approve it.'
  elif needed.get('file_system'):
   paths=needed['file_system'].get('write',[])
   note='Open your chat to allow access to the requested CreatorCut folder'+(': '+', '.join(paths) if paths else '')+'.'
  else:note='The renderer check needs a repair. In your chat, say: Finish CreatorCut setup. Your edit is saved.'
  job.update(waiting={'kind':'permission' if needed else 'user','source':'renderer_check','since':now,'note':note},message=note,updated=now)
  editor.store_job(p.name,job)


def require_probe(p):
 from . import editor
 if not paste_only():return
 job=editor.read(p.name)
 if job.get('execution_mode')!='chat':return
 proof=util.read_json(p/'renderer-capabilities.json',default={})
 import hashlib
 binding=proof.get('editing_binding')
 wrong_binding=binding is not None and binding!={'request_id':job.get('request_id'),'delivery_sha256':hashlib.sha256(str(job.get('delivery_token','')).encode()).hexdigest()}
 if wrong_binding or proof.get('prerequisites_passed') is not True or float(proof.get('checked') or 0)<float(job.get('claimed_at') or 0):
  raise util.Fail('Check the renderer in this chat before editing.', 'Run edit.py renderer-probe --project with this exact project folder and the saved delivery token. Continue only if prerequisites_passed is true; report any host permission without bypassing it.')


def fail(p,note):
 from . import editor,annotations
 require_owner(p)
 with util.file_guard(p/'.editor-job.guard',timeout=5):
  job=editor.read(p.name)
  if any(row.get('running') and row.get('project')==p.name for row in __import__('editkit.activity_store',fromlist=['records']).records()):raise util.Fail('Finish or stop the current command before closing this edit.')
  job.update(state='failed',message='This edit could not finish. Your footage and saved versions are safe.',failure_note=str(note)[:1000],updated=time.time())
  editor.store_job(p.name,job)
 annotations.recover_unpublished_batch(p.name,job.get('request_id'),job.get('previous_version',0))
 return response(job)


def unfinished():
 """List saved native requests without inferring a project or needing Studio."""
 from . import editor,requests,videos
 rows=[]
 for pid in editor.all_projects():
  job=editor.read(pid)
  if job.get('execution_mode')!='chat' or job.get('state')=='succeeded':continue
  p=videos._dir(pid)
  if requests.active(p).get('id')!=job.get('request_id'):continue
  rows.append({'project':pid,'title':videos.load(pid).get('title') or pid,'state':job['state'],'request_id':job['request_id']})
 return {'unfinished':rows,'instruction':'Choose the exact project before workflow resume. Never guess between videos.'}


def migrate_legacy_request(pid,expected_request_id=None):
 """An explicit customer recovery, not an automatic hidden-editor restart."""
 from . import editor,videos,requests,activity_store
 if not paste_only():raise util.Fail('Use the existing editor recovery for this installation.')
 p=videos._dir(pid)
 with editor.paste_worker_guard(),util.file_guard(p/'.chat-command.guard','The previous editing step is still closing.'),util.file_guard(p/'.editor.guard','The previous editor is still closing.'),util.file_guard(p/'.render.guard','The previous render is still closing.'),util.file_guard(p/'.request.guard',timeout=5),util.file_guard(p/'.editor-job.guard',timeout=5):
  job=editor.read(pid)
  if job.get('state')=='succeeded':return {'finished':True,'project':pid}
  if job.get('execution_mode')=='chat':return response(job)
  request=requests.active(p)
  if not request or request.get('id')!=job.get('request_id') or expected_request_id is not None and request['id']!=expected_request_id:
   raise util.Fail('The saved video choices changed. Keep this saved request and make the video with your current settings.')
  for row in activity_store.records():
   if row.get('project')==pid and row.get('running'):
    raise util.Fail('The previous editing step has not confirmed it stopped. Close that old editing session, then press Continue in a new chat. Your saved work is kept.')
  # No grant, permission answer or provider capability survives this handoff.
  for key in ('approval','approval_answer','approval_outcome','provider_pid','provider_birth','worker_pid','worker_birth','claimed_owner','claimed_delivery','claimed_host_id','failure_note','waiting'):
   job.pop(key,None)
  now=time.time();job.update(execution_mode='chat',provider='native',state='queued',cancel=False,retry_after=0,updated=now,activity_at=now,message='Your saved edit is ready. Paste the new message in your chat.')
  _new_delivery(job,'foreground');job['delivery_state']='unavailable';editor.store_job(pid,job)
  flow=util.read_json(p/'workflow.json',default={});flow.update(owner=None,lease_until=0,phase='waiting_editor',request_id=request['id'],updated=now,message=job['message']);util.write_durable_json(p/'workflow.json',flow)
  return response(job)
