"""Pinned executable style library. UI choices are data, never generated substitutes.
All heavy steps use the installation resource gate. Original plugin data is never read.
"""
from __future__ import annotations
import ast, copy, hashlib, json, math, os, shutil, sys
from pathlib import Path
from . import util


def launch_limit(identifier):
    return next((row.get('max_seconds') for row in util.read_json(util.KIT/'effect-release-list.json',default={}).get('effects',[]) if row['id']==identifier),None)


def digest_file(path):
    from .workflow import digest
    return digest(path)


def catalogue():
    return util.read_json(util.KIT/'style-library/catalogue.json')


def entry(identifier, version=None, verify=False):
    candidates=[(util.KIT/'style-library',catalogue())]
    shipped=util.KIT/'style-library-versions'
    if version:
        for manifest in shipped.glob('*/catalogue.json'):
            candidates.append((manifest.parent,util.read_json(manifest)))
    cache=util.STUDIO_OUT/'library-versions'
    if version:
        for manifest in cache.glob('*/catalogue.json'):
            try:candidates.append((manifest.parent,util.read_json(manifest)))
            except util.Fail:continue
    for root,doc in candidates:
        row=next((x for x in doc['entries'] if x['id']==identifier and (not version or x['version']==version)),None)
        if not row:continue
        if verify:
            for rel,want in dict(doc.get('common_files',{}),**row['files']).items():
                f=root/rel
                if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest()!=want:
                    raise util.Fail('The selected effect code failed its integrity check: '+rel)
        return dict(row,_root=str(root))
    raise util.Fail('That saved style version is unavailable. Choose its current version explicitly; the preset has not been changed.')


def pin_choices(value):
    """Retain selected executable source under protected user state before future app updates."""
    c=validate_choices(value)
    items=[c[k] for k in ('look','caption') if isinstance(c.get(k),dict)]+c['effects']
    if not items:return c
    roots={Path(entry(i['id'],i['version'],True)['_root']) for i in items}
    destination=util.STUDIO_OUT/'library-versions';destination.mkdir(parents=True,exist_ok=True)
    with util.file_guard(destination/'.pin.guard',timeout=10):
        for root in roots:
            if destination.resolve() in root.resolve().parents:continue
            doc=util.read_json(root/'catalogue.json')
            bundle=hashlib.sha256(json.dumps(doc,sort_keys=True).encode()).hexdigest()[:24]
            out=destination/bundle
            if out.exists():continue
            temporary=destination/(bundle+'.pending')
            shutil.rmtree(temporary,ignore_errors=True)
            try:
                shutil.copytree(root,temporary,ignore=shutil.ignore_patterns('__pycache__','*.pyc','previews'))
                temporary.replace(out)
            finally:shutil.rmtree(temporary,ignore_errors=True)
    return c


def validate_choices(value):
    if not isinstance(value,dict) or set(value)-{'look','caption','effects','placements','effects_mode'}: raise util.Fail('Invalid style choices.')
    result={}
    for kind in ('look','caption'):
        key=value.get(kind)
        if key is not None:
            if key=='none' and kind=='caption': result[kind]='none'; continue
            if not isinstance(key,dict): raise util.Fail('Styles need an id and code version.')
            e=entry(key.get('id'),key.get('version'))
            if e['kind']!=kind: raise util.Fail('Incorrect style category.')
            result[kind]={'id':e['id'],'version':e['version']}
    selected=value.get('effects',[])
    if not isinstance(selected,list) or len(selected)>12: raise util.Fail('Choose up to twelve effects.')
    mode=value.get('effects_mode','replace' if 'effects' in value else 'inherit')
    if mode not in ('inherit','replace'):raise util.Fail('Invalid effect selection mode.')
    result['effects_mode']=mode
    result['effects']=[]
    for key in selected:
        if not isinstance(key,dict): raise util.Fail('Effects need an id and code version.')
        e=entry(key.get('id'),key.get('version'))
        if e['kind']!='effect': raise util.Fail('Incorrect effect category.')
        if any(x['id']==e['id'] for x in result['effects']): continue
        result['effects'].append({'id':e['id'],'version':e['version']})
    placements=value.get('placements',{})
    if not isinstance(placements,dict): raise util.Fail('Invalid effect placement.')
    result['placements']={}
    for key,where in placements.items():
        if key not in [x['id'] for x in result['effects']]: continue
        if isinstance(where,dict):
            a,b=where.get('start'),where.get('end')
            if where.get('mode')!='range' or not all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) for v in (a,b)) or not 0<=a<b<=14400:
                raise util.Fail('Choose valid From and To seconds for this effect.')
            result['placements'][key]={'mode':'range','start':a,'end':b}
        else:
            if where not in ('auto','hook','middle','end'): raise util.Fail('Choose a supported placement.')
            result['placements'][key]=where
    return result


def choices(p, include_disabled=False):
    cfg=util.read_json(p/'project.json')
    manual=validate_choices(cfg.get('library_choices',{}))
    from . import learn
    memory={}
    for rule in learn._load().get('creator',[]):
        for kind,value in rule.get('library_choices',{}).items():memory[kind]=value
    for rule in learn._load().get('presets',{}).get(cfg.get('style',''),[]):
        for kind,value in rule.get('library_choices',{}).items():memory[kind]=value
    # A named preset beats universal defaults; both remain below a new reference.
    inherited=dict(memory,**cfg.get('preset_library_choices',{}))
    preset=validate_choices(inherited)
    ref=util.read_json(p/'style-inputs.json',default={}).get('reference',{})
    # A measured reference feature can be custom, rather than a library key. Do not force an old preset over it.
    if ref:
        if any(k in ref for k in ('fonts','styles','captions','motion','colour','graphics')):preset.pop('look',None)
        if any(k in ref for k in ('captions','fonts','styles')):preset.pop('caption',None)
        if any(k in ref for k in ('effects','graphics','motion')):preset['effects']=[]
    result=dict(preset)
    for k in ('look','caption'):
        if k in manual:result[k]=manual[k]
    result['effects']=manual['effects'] if manual['effects_mode']=='replace' else list({x['id']:x for x in preset.get('effects',[])+manual.get('effects',[])}.values())
    if not include_disabled and cfg.get('captions',{}).get('enabled') is False:result['caption']='none'
    elif cfg.get('captions',{}).get('enabled') is True and result.get('caption')=='none':
        default=entry('caption:signature');result['caption']={'id':default['id'],'version':default['version']}
    result['effects_mode']='replace'
    result['placements']={**preset.get('placements',{}),**manual.get('placements',{})}
    return result


def context(p):
    selected=choices(p)
    out={'schema':1,'choices':selected,'precedence':'this video explicit request (including explicit Studio choices and requested reference) > saved style > Studio defaults/picks > effect defaults',
         'constraints':[],'content_questions':[]}
    from . import style_recipe
    for item in selected.get('effects',[]):
        e=entry(item['id'],item['version'],True)
        out['constraints'].append({k:e.get(k) for k in ('id','version','shot','camera','wall','material','notes','slot')})
        question=style_recipe.input_question(e)
        if question:out['content_questions'].append({'effect':e['id'],'question':question,'before_work':True})
    util.write_json(p/'selected-library.json',out)
    return out


def preflight(identifier, evidence, version=None):
    """Measured suitability, separate from semantic/visual review. No guessed head geometry."""
    e=entry(identifier,version,verify=True); issues=[]
    for field in ('shot','camera'):
        if not evidence.get(field): issues.append('Measure '+field+' first.')
        elif evidence[field]!='unknown' and e.get(field) and evidence[field] not in e[field]: issues.append('This effect does not support this '+field+'.')
    slot=e.get('slot',{})
    if slot.get('cutout') not in (None,'none') and not evidence.get('clean_cutout'): issues.append('A reviewed clean subject cutout is required.')
    if e.get('material') and not str(e['material']).lower().startswith(('none','nothing needed')) and not evidence.get('assets'): issues.append('Add the required material: '+e['material'])
    if not evidence.get('semantic_reason'): issues.append('Anchor the effect to the actual spoken words or visual action.')
    if not evidence.get('layout_reviewed'): issues.append('Review the face, text safe zones and open space.')
    return {'ok':not issues,'issues':issues,'id':e['id'],'version':e['version']}


def _env():
    env=dict(os.environ,CREATORCUT_KIT=str(util.KIT),CREATORCUT_LIBRARY_STATE=str(util.STUDIO_OUT/'library-runtime'))
    node=util.which('node')
    paths=([str(Path(node).parent)] if node else [])+[str(util.BIN),env.get('PATH','')]
    env['PATH']=os.pathsep.join(paths)
    env['PYTHONUNBUFFERED']='1'
    env.update(WORKERS='1',BAKE_WORKERS='1',OMP_NUM_THREADS='1')
    return env


def normalize_generated_registration(slot):
    html=Path(slot)/'index.html'
    if not html.is_file():return
    before=html.read_text();after=before.replace('(window.__timelines || (window.__timelines = new Object()))["main"] = tl;', 'window.__timelines = window.__timelines || new Object(); window.__timelines["main"] = tl;')
    if after!=before:
        html.write_text(after)
        util.write_json(Path(slot)/'lint-compatibility.json',{'adapter':'explicit timeline registry v1','before_sha256':hashlib.sha256(before.encode()).hexdigest(),'after_sha256':hashlib.sha256(after.encode()).hexdigest(),'pinned_sources_changed':False})


def adapt_post_counter(slot,key):
    """Repair only the known CSV counter in a working copy, preserving saved pins."""
    if key not in ('digital-zoom','rack-focus'):return
    slot=Path(slot);file=slot/'post.py'
    if not file.is_file():return
    text=file.read_text();tree=ast.parse(text);old=next((n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='count'),None)
    if old is None:return
    body=ast.get_source_segment(text,old)
    if 'csv=p=0' not in body or 'return int(subprocess.run' not in body:return
    current=entry('effect:'+key,verify=True);trusted=Path(current['_root'])/'effects'/key/'post.py';replacement=trusted.read_text();fn=next(n for n in ast.parse(replacement).body if isinstance(n,ast.FunctionDef) and n.name=='count')
    before=hashlib.sha256(text.encode()).hexdigest();lines=text.splitlines(keepends=True);lines[old.lineno-1:old.end_lineno]=[ast.get_source_segment(replacement,fn)+'\n'];updated=''.join(lines);ast.parse(updated);file.write_text(updated)
    util.write_json(slot/'post-count-compatibility.json',{'adapter':'ffprobe-json-counter-v1','before_sha256':before,'after_sha256':hashlib.sha256(updated.encode()).hexdigest(),'pinned_source_changed':False})
    receipt=util.read_json(slot/'creatorcut-receipt.json',default={})
    if receipt:receipt['implementation']=_slot_sources(slot);util.write_json(slot/'creatorcut-receipt.json',receipt)


def run_script(p, script, args=(), timeout=3600, library_root=None):
    from . import resources
    root=Path(library_root or util.KIT/'style-library')
    if script=='fx_run.py' and args:
        if len(args)>2 and str(args[1])=='hf' and str(args[2])=='lint':normalize_generated_registration(args[0])
        receipt=Path(str(args[0]))/'creatorcut-receipt.json'
        if receipt.is_file():
            r=verify_slot(receipt.parent)
            if len(args)>1 and str(args[1])=='post.py':adapt_post_counter(receipt.parent,r['id'].split(':')[-1])
            root=Path(entry(r['id'],r['version'],True)['_root'])
    file=root/'scripts'/script
    if file.parent!=root/'scripts' or not file.is_file(): raise util.Fail('Unknown library tool.')
    import tempfile
    tmp=p/'work/library-temp';tmp.mkdir(parents=True,exist_ok=True)
    with resources.heavy(),tempfile.TemporaryDirectory(prefix='run-',dir=tmp) as folder:
        fonts=Path(p).resolve()/'.creatorcut-render-cache/fonts'
        fonts.mkdir(parents=True,exist_ok=True)
        env=dict(_env(),TMPDIR=folder,TMP=folder,TEMP=folder,
                 HYPERFRAMES_FONT_CACHE_DIR=str(fonts),HYPERFRAMES_HISTORY_ROOT=str(fonts.parent/'history'),HYPERFRAMES_EXTRACT_CACHE_DIR=str(Path(folder)/'extract'),
                 HYPERFRAMES_SKIP_SKILLS='1',DO_NOT_TRACK='1')
        owner=p if (p/'project.json').is_file() else p.parent.parent if p.name=='style-library' and p.parent.name=='work' else None
        if owner:
            owner_cfg=util.read_json(owner/'project.json')
            if owner_cfg.get('zoom') is False:env['CREATORCUT_DISABLE_ZOOM']='1'
            if owner_cfg.get('sfx') is False:env['SFX']='0'
            if script=='fx_run.py' and isinstance(choices(owner).get('caption'),dict):env['CAPTIONS']='0'
        import subprocess,time,re
        from collections import deque
        from . import activity_store
        stage={'layout.py':'Measuring your frame','build_reel.py':'Building your selected style','hf.py':'Rendering your selected style','fx_new.py':'Preparing your effect','fx_add.py':'Placing your effect'}.get(script,'Applying your effect')
        if script=='fx_run.py' and len(args)>1:stage={'prep.py':'Measuring your effect','bake.py':'Drawing your effect','build.py':'Building your effect','hf':'Rendering your effect','check.py':'Checking your effect'}.get(str(args[1]),'Preparing your effect')
        activity_store.update(label='Applying your selected style',detail=stage,percent=None,last_output=time.time(),estimated_remaining_seconds=None,estimate_basis=None)
        matting_frames=0
        if script=='fx_new.py' and '--from' in args and '--to' in args:matting_frames=round(float(args[list(args).index('--to')+1])*30)-round(float(args[list(args).index('--from')+1])*30)
        elif args and (Path(str(args[0]))/'clip.json').is_file():matting_frames=int(util.read_json(Path(str(args[0]))/'clip.json').get('frames') or 0)
        elif script=='rvm_cut.py' and args and (Path(str(args[0]))/'assets/aroll.mp4').is_file():matting_frames=round(util.probe(Path(str(args[0]))/'assets/aroll.mp4')['duration']*30)
        from . import browser_cleanup
        browser_registry,browser_scope=browser_cleanup.configure(env,folder)
        proc=util.spawn([sys.executable,str(file),*[str(a) for a in args]],cwd=p,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace')
        output=deque(maxlen=2000);last_pulse=[0.]
        def pulse():
            now=time.time()
            if now-last_pulse[0]>=10:
                activity_store.update(heartbeat=now)
                last_pulse[0]=now
        try:
            for line in util.progress_lines(proc,timeout=timeout,idle_timeout=min(timeout,600),on_tick=pulse):
                output.append(line)
                if 'stage still running' in line:
                    activity_store.update(heartbeat=time.time())
                    continue
                activity_store.update(last_output=time.time())
                matting=re.search(r'(\d+) frames done, ([0-9.]+)s per frame',line)
                if matting and args:
                    count=matting_frames;done=int(matting[1])
                    if count:
                        remaining=max(0,count-done)*float(matting[2]);activity_store.update(estimated_remaining_seconds=round(remaining),estimate_basis='Measured cut-out frames; later render not included')
                        util.activity('Cutting out your subject · about '+str(max(1,round(remaining/60)))+' min left for this cut-out',min(100,100*done/count));continue
                activity_store.update(estimated_remaining_seconds=None,estimate_basis=None)
                m=re.search(r'^(?:.*(?:render|matting|bake|frame)[^0-9]*)?(\d+)\s*/\s*(\d+)\s*$',line.strip(),re.I)
                if m and int(m[2])>0:util.activity(stage,100*int(m[1])/int(m[2]))
                else:util.activity(stage)
                print(line,end='',flush=True)
            text=''.join(output)
            if proc.returncode:raise util.Fail(stage+' failed:\n'+'\n'.join(text.strip().splitlines()[-12:]))
            return subprocess.CompletedProcess(proc.args,proc.returncode,text,'')
        finally:
            util.stop_process(proc)
            browser_cleanup.cleanup(browser_registry,browser_scope)


def _copy_style_fonts(workspace, choices):
    """Install the exact selected engine's font bundle; never render a silent fallback."""
    import re
    primary=next((choices[k] for k in ('look','caption') if isinstance(choices.get(k),dict)),None)
    if primary is None:primary=next(iter(choices.get('effects',[])),None)
    root=Path(entry(primary['id'],primary['version'],True)['_root']) if primary else util.KIT/'style-library'
    source=root/'engine/fonts';css=source/'fonts.css'
    if not css.is_file():raise util.Fail('The selected style font bundle is missing. Repair the installation before rendering.')
    required=re.findall(r"url\(['\"]?([^)'\"]+)",css.read_text())
    for rel in required:
        file=(source/rel).resolve()
        if source.resolve() not in file.parents or not file.is_file():raise util.Fail('A selected style font is missing: '+rel)
    destination=workspace/'assets/fonts'
    shutil.copytree(source,destination,dirs_exist_ok=True)
    for rel in ['fonts.css',*required]:
        if hashlib.sha256((source/rel).read_bytes()).digest()!=hashlib.sha256((destination/rel).read_bytes()).digest():raise util.Fail('A selected font did not copy correctly: '+rel)
    return destination


def prepare(p):
    """Adapt only this video's cut/word data to the unchanged caption/effect engine."""
    from . import resources
    with resources.heavy(), util.file_guard(p/'.library.guard',timeout=5):
        w=p/'work/style-library';(w/'assets').mkdir(parents=True,exist_ok=True)
        from . import colour_choice
        src=colour_choice.ensure_cut(p)
        if not src.is_file(): raise util.Fail('Finish the best-take cut before building styles.')
        info=util.probe(src)
        if (info['width'],info['height'])!=(1080,1920): raise util.Fail('This style needs a vertical 1080 × 1920 video. Choose Reels, TikTok or Shorts in Studio, then rebuild the cut before applying it.')
        # One content fingerprint protects against using slots from an earlier cut.
        from .workflow import digest
        sig=digest(src)
        previous=util.read_json(w/'source.json',default={})
        if previous and previous.get('sha256')!=sig and (w/'fx').exists():
            raise util.Fail('The cut changed. Archive the previous style workspace and re-anchor its effects before continuing.')
        dest=w/'assets/aroll.mp4'
        colour_contract='limited-rec709-v2'
        if not dest.exists() or previous.get('sha256')!=sig or previous.get('colour_contract')!=colour_contract:
            temporary=dest.with_suffix('.pending.mp4')
            try:
                from .cut import tonemap_filter
                matrix=info.get('colorspace')
                matrix=matrix if matrix in ('bt709','bt470bg','smpte170m','bt2020nc') else 'bt709'
                vf=tonemap_filter(info) if info.get('hdr') else ''
                if not info.get('hdr'):
                    vf=f"scale=in_color_matrix={matrix}:out_color_matrix=bt709:in_range={'pc' if info.get('color_range')=='pc' else 'tv'}:out_range=tv:flags=accurate_rnd+full_chroma_int,"
                util.run([util.ffmpeg_bin(),'-nostdin','-y','-v','error','-i',str(src),'-map','0:v:0','-map','0:a:0?',
                    '-vf',vf+'fps=30,setsar=1,format=yuv420p','-c:v','libx264','-preset','fast','-crf','14',
                    '-pix_fmt','yuv420p','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-color_range','tv','-c:a','aac',str(temporary)],timeout=max(120,min(14400,info['duration']*20)))
                converted=util.probe(temporary)
                if converted.get('hdr') or abs(converted['duration']-info['duration'])>1/30+.01:raise util.Fail('The style working copy did not preserve SDR timing.')
                temporary.replace(dest)
            finally:temporary.unlink(missing_ok=True)
        doc=util.read_json(p/'words.json');words=doc.get('words',[]) if isinstance(doc,dict) else doc
        words_sig=digest(p/'words.json')
        if not (w/'words.json').exists() or previous.get('word_source_sha256')!=words_sig:
            util.write_json(w/'words.json',[dict(x,text=x.get('text',x.get('w',''))) for x in words])
        util.write_json(w/'source.json',{'sha256':sig,'working_colour':'SDR Rec.709','colour_contract':colour_contract,'word_source_sha256':words_sig})
        segdoc=util.read_json(p/'segments.json',default={});segs=segdoc.get('segments',[]) if isinstance(segdoc,dict) else segdoc
        util.write_json(w/'segments.json',[dict(x,frame=round(x.get('start',0)*30),frames=round((x.get('end',0)-x.get('start',0))*30)) for x in segs])
        for name in ('cutout.webm','subject.webm'):
            if not info.get('hdr') and (p/name).is_file() and not (w/'assets/subject.webm').exists():
                shutil.copy2(p/name,w/'assets/subject.webm')
        c=choices(p);_copy_style_fonts(w,c);look=c.get('look');caption=c.get('caption')
        picks={'mode':'preset' if look else 'custom','style':look['id'].split(':')[1] if look else None,
               'captionStyle':caption['id'].split(':')[1] if isinstance(caption,dict) else ('none' if caption=='none' or not look else entry(look['id'],look['version']).get('captionStyle','none')),
               'effects':[x['id'].split(':')[1] for x in c['effects']]}
        # An unselected feature is UNKNOWN, not "no captions". Agent must resolve reference/default before render.
        sections={part:[] for part in ('hook','middle','end')}
        for selected in c['effects']:
            where=c.get('placements',{}).get(selected['id'],'auto')
            for part in sections:
                if where=='auto' or isinstance(where,dict) or where==part:sections[part].append(selected['id'].split(':')[1])
        if c['effects']:picks['effectSections']=sections
        util.write_json(w/'picks.json',picks)
        context(p)
        return w


def _slot_sources(slot):
    return {str(f.relative_to(slot)):hashlib.sha256(f.read_bytes()).hexdigest() for f in slot.rglob('*.py') if '__pycache__' not in f.parts}


def verify_slot(slot):
    receipt=util.read_json(slot/'creatorcut-receipt.json',default={})
    expected=receipt.get('implementation')
    if expected and expected!=_slot_sources(slot):
        raise util.Fail('The selected effect implementation changed outside its saved parameters. Restore its pinned code before continuing.')
    return receipt


def configure(slot, values):
    """JSON-only values replace existing top-level constants via AST positions, never eval/exec input."""
    if not isinstance(values,dict): raise util.Fail('Effect parameters must be an object.')
    receipt=verify_slot(slot)
    source=(slot/'build.py').read_text();tree=ast.parse(source);lines=source.splitlines(keepends=True);edits=[]
    allowed={}
    for node in tree.body:
        if isinstance(node,ast.Assign) and len(node.targets)==1:
            target=node.targets[0]
            if isinstance(target,ast.Name) and target.id.isupper():allowed[target.id]=(node,None)
            elif isinstance(target,(ast.Tuple,ast.List)) and isinstance(node.value,(ast.Tuple,ast.List)) and len(target.elts)==len(node.value.elts):
                for index,name in enumerate(target.elts):
                    if isinstance(name,ast.Name) and name.id.isupper():allowed[name.id]=(node,index)
    if set(values)-set(allowed): raise util.Fail('Unknown effect parameters: '+', '.join(sorted(set(values)-set(allowed))))
    json.dumps(values,allow_nan=False)
    grouped={}
    for key,value in values.items():
        node,index=allowed[key];grouped.setdefault(node,{}).update({key:value})
    for node,updates in grouped.items():
        if isinstance(node.targets[0],ast.Name):replacement=f'{node.targets[0].id} = {updates[node.targets[0].id]!r}\n'
        else:
            replacement=''.join(name.id+' = '+(repr(updates[name.id]) if name.id in updates else ast.get_source_segment(source,node.value.elts[index]))+'\n' for index,name in enumerate(node.targets[0].elts))
        edits.append((node.lineno-1,node.end_lineno,replacement))
    for start,end,value in sorted(edits,reverse=True): lines[start:end]=[value]
    result=''.join(lines);ast.parse(result)
    (slot/'build.py').write_text(result)
    prior=util.read_json(slot/'creatorcut-parameters.json',default={})
    util.write_json(slot/'creatorcut-parameters.json',dict(prior,**values))
    if receipt:
        receipt['implementation']=_slot_sources(slot);util.write_json(slot/'creatorcut-receipt.json',receipt)


def new_slot(p, identifier, start, end, parameters, evidence):
    limit=launch_limit(identifier)
    if limit and end-start>limit+1e-6:raise util.Fail('Frame Break is available for up to 3 seconds. Choose a shorter moment; your saved choices are kept.')
    from . import style_recipe
    reason=style_recipe.unsuitable_reason(p,identifier,start,end,parameters)
    if reason:raise util.Fail(reason,'Choose another moment or let the chat finish the video without this effect.')
    selected=next((x for x in choices(p)['effects'] if x['id']==identifier),None)
    e=entry(identifier,selected['version'] if selected else None,verify=True)
    from . import style_recipe
    style_recipe.protect_facts(p,e,parameters,evidence)
    verdict=preflight(identifier,evidence,e["version"])
    if not verdict['ok']: raise util.Fail(' '.join(verdict['issues']))
    if not all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) for v in (start,end)) or not 0<=start<end: raise util.Fail('Invalid effect timing.')
    where=choices(p).get('placements',{}).get(identifier)
    if isinstance(where,dict) and (start<where['start']-1/30 or end>where['end']+1/30):
        raise util.Fail('The effect falls outside the seconds you selected.')
    if selected is None:
        from . import videos
        cfg=util.read_json(p/'project.json');manual=cfg.get('library_choices',{}).copy()
        manual['effects_mode']='replace'
        manual['effects']=list(choices(p)['effects'])+[{'id':e['id'],'version':e['version']}]
        videos.set_brief(p.name,{'library_choices':manual})
    w=prepare(p)
    if end>util.probe(w/'assets/aroll.mp4')['duration']+1/30:raise util.Fail('The effect ends after this video.')
    key=e['key'];name=key+'-'+str(round(start*30))
    slot=w/'fx'/name
    # Build privately, then commit only a fully prepared recipe. A crash must not leave a
    # half-cut matte at the final path and make the next attempt look like an existing edit.
    with util.file_guard(w/'.slot-create.guard',timeout=10):
        if slot.exists(): raise util.Fail('That effect slot already exists. Revise it rather than overwrite a running render.')
        pending_name=name+'-preparing'
        pending=w/'fx'/pending_name
        shutil.rmtree(pending,ignore_errors=True)
        try:
            if e['slot'].get('cutout') not in (None,'none') and not (w/'assets/subject.webm').exists():ensure_matting()
            args=[key,'--project',w,'--from',start,'--to',end,'--name',pending_name,'--picks',w/'picks.json']
            if evidence.get('buyer_folder'):
                folder=Path(evidence['buyer_folder']).resolve()
                if not folder.is_dir() or not folder.is_relative_to(p.resolve()):raise util.Fail('Put this effect’s supplied material inside this video project, then retry.')
                args+=['--buyer-files',folder]
            # Reuse only this cut's exact span and the same clean-matting recipe.
            matte_key=hashlib.sha256(json.dumps({'source':digest_file(w/'assets/aroll.mp4'),'start_frame':round(start*30),'end_frame':round(end*30),'cuts':util.read_json(w/'segments.json',default=[]),'model':'rvm-resnet50-fp32-clean-v1','producer':{name:digest_file(Path(e['_root'])/'scripts'/name) for name in ('rvm_cut.py','head_clean.py')}},sort_keys=True).encode()).hexdigest() if e['slot'].get('cutout') not in (None,'none') else 'none'
            cache=w/'cutout-cache'/matte_key;matte=cache/'subject.webm';proof=util.read_json(cache/'receipt.json',default={})
            want=round(end*30)-round(start*30)
            if e['slot'].get('cutout') not in (None,'none') and matte.is_file() and proof.get('sha256')==digest_file(matte) and proof.get('frames')==want:
                (pending/'assets').mkdir(parents=True,exist_ok=True);shutil.copy2(matte,pending/'assets/subject.webm');(pending/'assets/.cutout_done').touch()
            run_script(w,'fx_new.py',args,library_root=e['_root'])
            made=pending/'assets/subject.webm'
            if e['slot'].get('cutout') not in (None,'none') and made.is_file():
                actual=util.probe(made)
                if actual.get('frame_count') is None:
                    actual['frame_count']=int(util.run([util.ffprobe_bin(),'-v','error','-count_frames','-select_streams','v:0','-show_entries','stream=nb_read_frames','-of','csv=p=0',str(made)]).stdout.strip().split(',')[0])
                if actual['frame_count']!=want:raise util.Fail('The effect cut-out is incomplete. Retry this exact moment before attaching it.')
                cache.mkdir(parents=True,exist_ok=True);shutil.copy2(made,matte.with_suffix('.pending.webm'));matte.with_suffix('.pending.webm').replace(matte)
                util.write_json(cache/'receipt.json',{'frames':want,'sha256':digest_file(matte)})
            adapt_post_counter(pending,key)
            from . import presets
            cfg=util.read_json(p/'project.json')
            saved=presets.recipe_context(cfg.get('style',''),cfg.get('preset_version')).get('library_recipe',{}).get('effect_style_parameters',{}).get(identifier,{})
            from . import style_recipe
            configure(pending,style_recipe.timing_defaults(pending,dict(saved,**parameters)))
            run=pending/'RUN.txt'
            if run.exists():run.write_text(run.read_text().replace(str(pending),str(slot)).replace(pending.as_posix(),slot.as_posix()))
            util.write_json(pending/'creatorcut-receipt.json',{'id':identifier,'version':e['version'],'source':util.read_json(w/'source.json'),'start':start,'end':end,'evidence':evidence,'parameters':parameters,'implementation':_slot_sources(pending)})
            pending.rename(slot)
        finally:
            shutil.rmtree(pending,ignore_errors=True)
    return slot


def validation_errors(p, plan):
    """Selections must have a content-bound implementation or an explicit explained override."""
    c=choices(p);selected=([c[k] for k in ('look','caption') if isinstance(c.get(k),dict)]+c['effects'])
    errors=[];application=plan.get('library_application',[])
    if c.get('caption')=='none' and any(x.get('type')=='caption' for x in plan.get('items',[])):errors.append('Captions are disabled in Studio; remove the caption layer before rendering.')
    if str(plan.get('background',{}).get('src','')).startswith('work/style-library/'):
        execution=util.read_json(p/'work/style-library/execution.json',default={})
        if execution.get('choices')!=c:
            errors.append('Re-render the style composite with the current caption switch, styles and effects.')
    if not isinstance(application,list) or any(not isinstance(x,dict) for x in application):return ['library_application must be a list of implementation records.']
    for item in selected:
        matches=[x for x in application if x.get('id')==item['id']]
        if len(matches)!=1:
            errors.append('Record exactly one execution or explicit override for '+item['id']);continue
        row=matches[0]
        if row.get('version')!=item['version']: errors.append('Resolve selected library version: '+item['id']);continue
        if row.get('status') in ('overridden','unsuitable'):
            from . import style_recipe
            if row.get('status')=='unsuitable' and style_recipe.verify_omission(p,item,row):continue
            from . import requests
            saved=requests.active(p)
            quote=row.get('quote','');prompt=str(saved.get('settings',{}).get('brief',{}).get('prompt',''))
            if saved and (row.get('status')=='unsuitable' or not isinstance(quote,str) or len(quote.strip())<12 or quote not in prompt):
                errors.append('The selected '+item['id']+' cannot be silently omitted. Ask the customer to change this selection or record their exact current brief override.')
            if len(str(row.get('reason','')).strip())<20:errors.append('Explain why '+item['id']+' is not used.')
            continue
        if row.get('status')!='applied' or not row.get('artifact') or not row.get('sha256'):
            errors.append('Missing executed implementation for '+item['id']);continue
        f=(p/row['artifact']).resolve()
        if p.resolve() not in f.parents or not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest()!=row['sha256']:
            errors.append('Invalid implementation evidence for '+item['id'])
    if any(x.get('status')=='applied' for x in application if x.get('id') in [i['id'] for i in selected]):
        workspace=p/'work/style-library';execution=util.read_json(workspace/'execution.json',default={})
        if not execution or not execution.get('inputs'):
            errors.append('Finish the selected-library composite and record its actual inputs before review.')
        else:
            for name,want in execution['inputs'].items():
                file=(workspace/name).resolve()
                if workspace.resolve() not in file.parents or not file.is_file() or hashlib.sha256(file.read_bytes()).hexdigest()!=want:
                    errors.append('Re-render the selected style after changing '+name)
            base=p/str(plan.get('background',{}).get('src',''))
            if not base.is_file() or hashlib.sha256(base.read_bytes()).hexdigest()!=execution.get('output_sha256'):
                errors.append('The edit is not using its verified selected-style composite.')
    return errors


def _filter_slots(workspace, choices):
    allowed={x['id'].split(':',1)[1] for x in choices['effects']}
    file=workspace/'plan.json';doc=util.read_json(file,default={})
    slots=[x for x in doc.get('slots',[]) if x.get('key') in allowed and not x.get('off')]
    if file.exists():
        doc['slots']=slots;util.write_json(file,doc)
    return {x['slot'] for x in slots}


def render_look(p):
    """Execute selected caption/overall style, then use its exact render as the composition background.
    Other scene graphics survive; voice remains the original cut's audio in compose.
    """
    from . import resources,workflow
    c=choices(p)
    selected=[c[k] for k in ('look','caption') if isinstance(c.get(k),dict)]
    if not selected and not c['effects'] and c.get('caption')!='none':raise util.Fail('Choose a look, caption or effect first.')
    if not selected and c['effects']:selected=[c['effects'][0]]
    roots={entry(item['id'],item['version'],True)['_root'] for item in selected}
    if len(roots)>1:raise util.Fail('These look and caption versions use different engines. Explicitly reselect them from one library version.')
    runtime=next(iter(roots)) if roots else str(util.KIT/'style-library')
    with resources.heavy(),util.project_lock(p,_nested=True):
        w=prepare(p)
        previous=util.read_json(w/'execution.json',default={})
        settings={key:util.read_json(p/'project.json').get(key) for key in ('captions','sfx','zoom','look','style','preset_version')}
        cached=w/'renders/look.mp4'
        if previous.get('inputs') and previous.get('source')==util.read_json(w/'source.json') and previous.get('choices')==c and previous.get('render_settings')==settings and previous.get('inputs') and cached.is_file() and workflow.digest(cached)==previous.get('output_sha256') and all((w/name).is_file() and workflow.digest(w/name)==want for name,want in previous['inputs'].items()):
            util.say('Reusing this exact verified style render.');return cached
        active_slots=_filter_slots(w,c)
        slots=util.read_json(w/'plan.json',default={}).get('slots',[])
        for effect in c['effects']:
            key=effect['id'].split(':',1)[1]
            from . import style_recipe
            application=util.read_json(p/'edit-plan.json',default={}).get('library_application',[])
            omitted=next((row for row in application if row.get('id')==effect['id'] and row.get('status')=='unsuitable'),{})
            if omitted and style_recipe.verify_omission(p,effect,omitted):continue
            if not any(x.get('key')==key and not x.get('off') for x in slots):
                raise util.Fail('Build and attach the selected effect before rendering: '+effect['id'])
        if (c.get('look',{}).get('id') in ('look:chalk-talk','look:show-and-tell') or (c.get('caption') if isinstance(c.get('caption'),dict) else {}).get('id')=='caption:bold') and not (w/'assets/subject.webm').exists():
            ensure_matting()
            util.step('Creating your subject cutout. This takes longer than ordinary captions; frame progress will be shown.')
            run_script(w,'rvm_cut.py',[w],timeout=max(600,util.probe(w/'assets/aroll.mp4')['duration']*90),library_root=runtime)
            if not (w/'assets/subject.webm').is_file():raise util.Fail('The subject cutout did not finish. Run this saved look step again after checking the cutout message.')
        if not (w/'layout.json').exists():run_script(w,'layout.py',[w],library_root=runtime)
        args=[w,'--picks',w/'picks.json','--no-my-style']
        if not c.get('look'):args+=['--style','none']
        if c.get('caption')=='none':args+=['--caption','none']
        elif isinstance(c.get('caption'),dict):args+=['--caption',c['caption']['id'].split(':')[1]]
        run_script(w,'build_reel.py',args,library_root=runtime)
        from . import colour_choice,caption_adjust
        adjusted=caption_adjust.apply(w,util.read_json(p/'project.json').get('captions',{}))
        colour_choice.lock_library_colour(w)
        out=w/'renders/look.mp4';out.parent.mkdir(exist_ok=True)
        run_script(w,'hf.py',[w,'render','-o',out,'--quality','high'],library_root=runtime)
        info=util.probe(out);src=util.probe(w/'assets/aroll.mp4')
        if abs(info['duration']-src['duration'])>1/30+.003:raise util.Fail('Style render timing does not match the source cut.')
        util.run([util.ffmpeg_bin(),'-v','error','-i',str(out),'-f','null','-'],timeout=180)
        plan=util.read_json(p/'edit-plan.json')
        plan['background']['src']=str(out.relative_to(p))
        # This rendered layer carries its own captions. Do not duplicate main captions on top.
        plan['items']=[i for i in plan['items'] if not str(i.get('id','')).startswith('library-') and (i.get('type')!='caption' or (util.read_json(w/'picks.json').get('captionStyle')=='none' and c.get('caption')!='none'))]
        scenes=util.read_json(p/'scene-plan.json',default={})
        for scene in scenes.get('scenes',[]):
            scene['items']=[iid for iid in scene.get('items',[]) if not iid.startswith('library-')]
        if scenes:util.write_json(p/'scene-plan.json',scenes)
        application=[x for x in plan.get('library_application',[]) if x.get('id') not in [i['id'] for i in selected if i['id'].startswith(('look:','caption:'))]]
        application.extend(dict(item,status='applied',artifact=str(out.relative_to(p)),sha256=workflow.digest(out)) for item in selected if item['id'].startswith(('look:','caption:')))
        allowed_ids={x['id'] for x in ([c[k] for k in ('look','caption') if isinstance(c.get(k),dict)]+c['effects'])}
        plan['library_application']=[x for x in application if x.get('status')!='applied' or x.get('id') in allowed_ids]
        audio=plan.get('audio',{})
        audio['events']=[x for x in audio.get('events',[]) if not x.get('library_slot') or x['library_slot'] in active_slots]
        util.write_json(p/'edit-plan.json',plan)
        util.write_json(w/'execution.json',{'studio_switches':{key:util.read_json(p/'project.json').get(key) for key in ('zoom','sfx')},'caption_adjust':adjusted,'choices':c,'render_settings':settings,'code_versions':selected,'output_sha256':workflow.digest(out),'source':util.read_json(w/'source.json'),'slots_sha256':workflow.digest(w/'plan.json') if (w/'plan.json').exists() else None,'inputs':{name:workflow.digest(w/name) for name in ['words.json','layout.json','picks.json','plan.json','index.html','colour-policy.json','caption-adjust.json','source.json']+[str(file.relative_to(w)) for file in (w/'assets').rglob('*') if file.is_file()] if (w/name).exists()}})
        return out


def attach_slot(p,slot):
    """Use the pack's own exact-frame slot composition, retaining voice and caption suppression."""
    from . import workflow,resources
    slot=slot.resolve();w=(p/'work/style-library').resolve()
    if w not in slot.parents:raise util.Fail('The effect must belong to this video.')
    receipt=verify_slot(slot);e=entry(receipt['id'],receipt['version'],True)
    from . import colour_choice
    prepared=colour_choice.ensure_cut(p)
    if receipt['source']!=util.read_json(w/'source.json') or receipt['source'].get('sha256')!=workflow.digest(prepared):raise util.Fail('This effect belongs to an older cut or colour choice. Rebuild it for the current footage.')
    output=slot/'renders'/(slot.name+('.webm' if e['slot'].get('layer')=='overlay' else '.mp4'))
    if not output.is_file():raise util.Fail('Render and inspect this effect slot before attaching it.')
    with resources.heavy(),util.project_lock(p,_nested=True):
        run_script(w,'fx_add.py',[w,slot,'--picks',w/'picks.json'],library_root=e['_root'])
        plan=util.read_json(p/'edit-plan.json')
        a,b=receipt['start'],receipt['end']
        iid='library-'+slot.name
        # Full-frame selected effect uses the original pack's output, never re-created HTML.
        item={'id':iid,'type':'card','src':str(output.relative_to(p)),'t0':a,'t1':b,'x':.5,'y':.5,'w':1,'h':1,'rot':0,'radius':0,'fit':'cover','anim':{'enter':'cut','exit':'cut'},'media_start':0}
        plan['items']=[x for x in plan['items'] if x.get('id')!=iid]
        if e['slot'].get('reel_captions')=='hide':
            plan['items']=[x for x in plan['items'] if not(x.get('type')=='caption' and x.get('t0',0)<b and x.get('t1',0)>a)]
        plan['items'].append(item)
        pack_plan=util.read_json(w/'plan.json',default={})
        source_slot=next((x for x in pack_plan.get('slots',[]) if x.get('key')==e['key'] and abs(x.get('from',-1)-a)<.04),{})
        scenes=util.read_json(p/'scene-plan.json',default={}).get('scenes',[])
        audio=plan.setdefault('audio',{});audio['events']=[x for x in audio.get('events',[]) if x.get('library_slot')!=slot.name]
        for cue in source_slot.get('sfx',[]):
            scene=next((x for x in scenes if x.get('t0',0)<=cue['at']<x.get('t1',0)),None)
            if not scene:raise util.Fail('Bind the effect sound cues to real scenes before attaching it.')
            audio['events'].append({'src':str((w/cue['src']).relative_to(p)),'t':cue['at'],'volume':cue['vol'],'media_start':cue['media'],'duration':cue['dur'],'scene':scene['id'],'reason':e['name']+' motion cue','library_slot':slot.name})
        plan['library_application']=[x for x in plan.get('library_application',[]) if x.get('id')!=e['id']]+[{'id':e['id'],'version':e['version'],'status':'applied','artifact':str(output.relative_to(p)),'sha256':workflow.digest(output),'receipt':str((slot/'creatorcut-receipt.json').relative_to(p))}]
        util.write_json(p/'edit-plan.json',plan)
        return item


def ensure_matting():
    """One-time local model download with a pinned hash; never silently use another matte model."""
    from . import resources
    import urllib.request,ssl,time
    target=util.STUDIO_OUT/'library-runtime/models/rvm_resnet50_fp32.onnx'
    want='25db300fcb6ee27f941a1b52c97856e8d1f13c7f35817f81a612f89af0e8a85c'
    if target.exists() and hashlib.sha256(target.read_bytes()).hexdigest()==want:return target
    for module in ('onnxruntime','scipy.ndimage'):
        try:__import__(module)
        except ImportError:raise util.Fail('The clean cutout needs the vision dependencies. Complete CreatorCut setup before this effect.')
    with resources.heavy(),util.file_guard(target.with_suffix('.guard'),timeout=5):
        if target.exists() and hashlib.sha256(target.read_bytes()).hexdigest()==want:return target
        target.parent.mkdir(parents=True,exist_ok=True);temp=target.with_suffix('.pending')
        url='https://github.com/PeterL1n/RobustVideoMatting/releases/download/v1.0.0/rvm_resnet50_fp32.onnx'
        try:
            util.step('Downloading the clean subject model (103 MB, once).')
            context=ssl.create_default_context()
            try:
                import certifi
                context=ssl.create_default_context(cafile=certifi.where())
            except ImportError:pass
            deadline=time.monotonic()+600
            with urllib.request.urlopen(url,timeout=30,context=context) as response,temp.open('wb') as dest:
                size=0
                while True:
                    if time.monotonic()>deadline:raise util.Fail('The model download timed out. Retry after checking the connection.')
                    chunk=response.read1(1024*1024)
                    if not chunk:break
                    size+=len(chunk)
                    if size>150_000_000:raise util.Fail('The model download is larger than expected.')
                    dest.write(chunk);util.activity('Downloading clean subject model',min(99,size/107_000_000*100))
            if hashlib.sha256(temp.read_bytes()).hexdigest()!=want:raise util.Fail('The subject model download failed its integrity check.')
            temp.replace(target)
        except (OSError,TimeoutError) as error:
            raise util.Fail('The clean subject model could not download. Your footage is safe.','Check your connection, then run setup again; the model is only downloaded once.') from error
        finally:temp.unlink(missing_ok=True)
    return target
