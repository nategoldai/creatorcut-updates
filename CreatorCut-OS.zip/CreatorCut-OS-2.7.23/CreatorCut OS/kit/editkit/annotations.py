"""Version-bound timeline notes, not a second chat. Saving never claims delivery/editing."""
from __future__ import annotations
import math,time,uuid,re
from pathlib import Path
from . import util,videos,events


def read(pid):
    return util.read_json(videos._dir(pid)/'annotations.json',default={'schema':1,'notes':[]})


def _snapshot(pid,version):
    p=videos._dir(pid);vs=videos.versions(pid)
    v=next((x for x in vs if x['n']==version),None)
    if not v: raise util.Fail('Choose an available saved video version before leaving frame feedback.')
    scenes=util.read_json(p/'versions'/f'v{version}.scenes.json',default={})
    segments=util.read_json(p/'versions'/f'v{version}.segments.json',default={})
    plan=util.read_json(p/'versions'/f'v{version}.plan.json',default={})
    return p,v,scenes,segments,plan


def add(pid,payload):
    if not isinstance(payload,dict):raise util.Fail('Invalid timeline note.')
    version=payload.get('version')
    if not isinstance(version,int) or isinstance(version,bool):raise util.Fail('Choose the video version.')
    p,v,scenes,segments,plan=_snapshot(pid,version)
    text=str(payload.get('text','')).strip()
    if not text or len(text)>4000:raise util.Fail('Write a short change request (up to 4,000 characters).')
    start,end=payload.get('start'),payload.get('end',payload.get('start'))
    dur=v.get('duration') or plan.get('duration',0)
    if not all(isinstance(x,(float,int)) and not isinstance(x,bool) and math.isfinite(x) for x in (start,end)) or not (0<=start<dur and start<=end<=dur):raise util.Fail('Select a moment within this version.')
    scope=payload.get('scope','project')
    if scope not in ('project','creator'):raise util.Fail('Invalid feedback scope.')
    request=payload.get('request_id')
    if not isinstance(request,str) or not 1<=len(request)<=128:raise util.Fail('The note needs a request identifier.')
    frame=min(round(start*30),max(0,round(dur*30)-1));last_frame=round(end*30)
    matching=[s for s in scenes.get('scenes',[]) if s.get('t0',0)<=start<s.get('t1',0)]
    selected=matching[0] if matching else {}
    segs=segments.get('segments',[]) if isinstance(segments,dict) else segments
    segment=next((s for s in segs if s.get('start',0)<=start<s.get('end',0)),{})
    note={'id':uuid.uuid4().hex,'request_id':request,'project':pid,'version':version,'candidate_sha256':v.get('candidate_sha256',''),
          'start':start,'end':end,'frame':frame,'end_frame':last_frame,'fps':30,'text':text,'scope':scope,
          'scene':selected.get('id'),'spoken':selected.get('spoken',''),'source_start':segment.get('src_start',0)+start-segment.get('start',0) if segment else None,
          'status':'saved','time':time.time()}
    with util.file_guard(p/'.annotations.guard',timeout=5):
        data=read(pid)
        old=next((n for n in data['notes'] if n['request_id']==request),None)
        if old:
            if any(old.get(k)!=note.get(k) for k in ('text','version','start','end','scope')):raise util.Fail('This note request already belongs to different feedback.')
            return old
        data['notes'].append(note);util.write_json(p/'annotations.json',data)
    events.emit('timeline.note_saved',{'project':pid,'note':note['id']})
    return note


def batch(pid,version,ids):
    """Immutable exact-note snapshot; a short native handoff works for long feedback too."""
    import hashlib,json
    if not isinstance(version,int) or isinstance(version,bool):raise util.Fail('Choose a saved video version.')
    if not isinstance(ids,list) or not ids or len(ids)>1000 or not all(isinstance(x,str) for x in ids) or len(set(ids))!=len(ids):raise util.Fail('Choose the saved changes to apply.')
    p=videos._dir(pid)
    with util.file_guard(p/'.annotations.guard',timeout=5):
        all_notes={n['id']:n for n in read(pid)['notes']}
        notes=[all_notes.get(n) for n in ids]
        if any(not n or n['version']!=version or n['status']!='saved' for n in notes):raise util.Fail('These changes have already been sent or changed. Refresh your video before sending.')
        snapshot={'schema':1,'project':pid,'version':version,'notes':notes}
        bid=hashlib.sha256(json.dumps(snapshot,sort_keys=True).encode()).hexdigest()[:32]
        file=p/'annotation-batches'/f'{bid}.json'
        if not file.exists():util.write_json(file,snapshot)
    from . import requests
    request=requests.create(pid,batch=snapshot)
    return {'ok':True,'id':bid,'request_id':request['id'],'prompt':request['prompt']}



def batch_received(pid,bid):
    import re
    if not re.fullmatch(r'[a-f0-9]{32}',bid):raise util.Fail('Invalid change batch.')
    p=videos._dir(pid);snapshot=util.read_json(p/'annotation-batches'/f'{bid}.json',default={})
    if snapshot.get('project')!=pid:raise util.Fail('That change batch is unavailable.')
    ids={n['id'] for n in snapshot['notes']}
    with util.file_guard(p/'.editor-job.guard',timeout=5),util.file_guard(p/'.annotations.guard',timeout=5):
        from . import editor,requests
        data=read(pid);job=editor.read(pid);active=requests.active(p)
        if active.get('batch')!=snapshot or job.get('state') in ('failed','cancelled','succeeded'):
            return [n for n in data['notes'] if n['id'] in ids]
        for n in data['notes']:
            if n['id'] in ids and n['status']=='saved':n.update(status='received',received_at=time.time())
        util.write_json(p/'annotations.json',data)
    return [n for n in data['notes'] if n['id'] in ids]


def remove(pid,nid):
    """Withdraw only an unsent note. Preserve its id for idempotent save retries."""
    p=videos._dir(pid)
    with util.file_guard(p/'.annotations.guard',timeout=5):
        data=read(pid);note=next((n for n in data['notes'] if n['id']==nid),None)
        if not note:raise util.Fail('That change is unavailable.')
        if note['status'] not in ('saved','removed'):raise util.Fail('This change has already been sent for editing.')
        note.update(status='removed',updated=time.time());util.write_json(p/'annotations.json',data)
    events.emit('timeline.note_removed',{'project':pid,'note':nid})
    return note


def received(pid,nid):
    """Only records a native transport receipt; never marks a render as started."""
    p=videos._dir(pid)
    with util.file_guard(p/'.annotations.guard',timeout=5):
        data=read(pid);note=next((n for n in data['notes'] if n['id']==nid),None)
        if not note:raise util.Fail('That note is unavailable.')
        if note['status']=='removed':raise util.Fail('This change was removed before delivery.')
        if note['status']=='saved':note.update(status='received',received_at=time.time())
        util.write_json(p/'annotations.json',data)
    return note


def prompt(note):
    scope=' Apply only to this video.' if note['scope']=='project' else ' This is also a lasting style preference: capture the concise preference with creator scope, then apply it.'
    return (f"Revise project {note['project']} from saved version {note['version']}, at {note['start']:.3f}–{note['end']:.3f}s "
            f"(frames {note['frame']}–{note['end_frame']} at 30fps; scene {note['scene'] or 'unmapped'}). "
            f"Timeline note {note['id']}: {note['text']}. Read annotations.json for the exact version/source binding. "
            "Do not reuse this timestamp on a newer cut without mapping its scene/source anchor."+scope)


def mapped(note,new_scenes):
    """Map only stable ids+matching speech; otherwise require review, never silently jump."""
    matches=[s for s in new_scenes.get('scenes',[]) if s.get('id')==note.get('scene') and s.get('spoken')==note.get('spoken')]
    if len(matches)!=1:return {'state':'needs_review','reason':'The referenced scene changed or disappeared.'}
    return {'state':'scene_match','scene':matches[0]['id'],'start':matches[0]['t0'],'end':matches[0]['t1'],'reason':'Check the exact word/frame inside this scene before applying.'}


def strip_cache(p,version):
    try:
        target=p/'versions'/f"v{version['n']}.frames"
        doc=util.read_json(target/'frames.json',default={})
        if not isinstance(doc,dict):return None
        frames=doc.get('frames',[])
        if doc.get('candidate_sha256')!=version.get('candidate_sha256') or not frames or not isinstance(frames,list):return None
        if any(not isinstance(f,str) or Path(f).name!=f or not (target/f).is_file() or (target/f).stat().st_size==0 for f in frames):return None
        return doc
    except (OSError,util.Fail):return None


def make_strip(pid,version):
    """Twelve actual edited frames, cached per immutable saved version; never run during state reads."""
    import shutil
    from . import resources
    p,v,_,_,_=_snapshot(pid,version)
    target=p/'versions'/f'v{version}.frames'
    cached=strip_cache(p,v)
    if cached:return cached
    with resources.heavy(),util.file_guard(p/'.frames.guard',timeout=5):
        cached=strip_cache(p,v)
        if cached:return cached
        tmp=target.with_name(target.name+'.pending');shutil.rmtree(tmp,ignore_errors=True);tmp.mkdir()
        try:
            duration=float(v['duration']);rate=12/max(duration,.034)
            util.run([util.ffmpeg_bin(),'-nostdin','-y','-hide_banner','-loglevel','error','-i',str(util.ROOT/v['file']),'-vf',f'fps={rate:.8f},scale=108:-2','-frames:v','12','-q:v','6',str(tmp/'%02d.jpg')],timeout=120)
            files=sorted(tmp.glob('*.jpg'))
            if not files:raise util.Fail('No timeline frames could be read.')
            doc={'version':version,'candidate_sha256':v.get('candidate_sha256'),'frames':[str(f.name) for f in files]}
            util.write_json(tmp/'frames.json',doc)
            if target.exists():shutil.rmtree(target) # Derived cache only; original video is untouched.
            tmp.replace(target)
            events.emit('timeline.frames_ready',{'project':pid,'version':version})
            return doc
        finally:
            shutil.rmtree(tmp,ignore_errors=True)


def transition(pid,nid,status,*,rule='',topic=''):
    """Called by the native editor at actual work boundaries, never by a progress animation."""
    if status not in ('editing','ready'):raise util.Fail('Invalid note status.')
    p=videos._dir(pid)
    with util.file_guard(p/'.annotations.guard',timeout=5):
        data=read(pid);note=next((n for n in data['notes'] if n['id']==nid),None)
        if not note:raise util.Fail('That note is missing.')
        if note['status']=='removed':raise util.Fail('This change was removed and must not be applied.')
        if status=='ready':
            from . import workflow,requests
            if note['status'] not in ('editing','ready'):raise util.Fail('Apply this change before marking it ready.')
            try:candidate=workflow.require_release(p)
            except (util.Fail,OSError,ValueError) as error:
                raise util.Fail('This edit is not published yet. Review and publish the revised video first, then mark this feedback ready.','Run workflow evidence, workflow review and workflow publish for this video; keep the note editing until the new version appears.') from error
            newer=[v for v in videos.versions(pid) if v['n']>note['version'] and v.get('candidate_sha256')==candidate['sha256']]
            if not newer:raise util.Fail('Publish the reviewed revised version before marking this change ready.')
            request=requests.active(p)
            if request and not any(n['id']==nid for n in (request.get('batch') or {}).get('notes',[])):
                raise util.Fail('This note is not included in the reviewed editing request.')
        if status=='editing':
            from . import learn
            if note['scope']=='creator' and not rule:raise util.Fail('Interpret the lasting preference as a concise rule before remembering it.')
            learn.capture_feedback(pid,note['text'],scope=note['scope'],rule=rule,topic=topic)
        note.update(status=status,updated=time.time());util.write_json(p/'annotations.json',data)
    events.emit('timeline.note_'+status,{'project':pid,'note':nid})
    return note

def recover_unpublished_batch(pid,request_id,previous_version):
    """Return only this failed request's unapplied notes to the editable list."""
    if not isinstance(request_id,str) or not re.fullmatch(r'[a-f0-9]{32}',request_id):return 0
    p=videos._dir(pid)
    if max((v['n'] for v in videos.versions(pid)),default=0)>previous_version:return 0
    request=util.read_json(p/'edit-requests'/f'{request_id}.json',default={})
    ids={n['id'] for n in (request.get('batch') or {}).get('notes',[])}
    if not ids:return 0
    with util.file_guard(p/'.annotations.guard',timeout=5):
        data=read(pid);changed=0
        for n in data['notes']:
            if n['id'] in ids and n['status'] in ('received','editing'):
                n.update(status='saved',recovered_at=time.time());changed+=1
        if changed:util.write_json(p/'annotations.json',data)
    return changed
