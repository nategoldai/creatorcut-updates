"""Updates: buyers get new versions of CreatorCut OS without losing anything.

The publisher can use one ZIP in a configured public GitHub repository (github_updates.py),
or keep the legacy two-file website feed: the new zip and a small `latest.json`
({"version": "2.1.0", "zip": "https://…/CreatorCut-OS-2.1.0.zip", "notes": "…"}). The address of latest.json is in
kit/update.json ({"url": "https://…/latest.json"}), shipped inside every zip. The Studio checks it on start and every few
hours; when a newer version is there it shows "Update available", and one click runs apply():

  download → check it is a CreatorCut OS zip → back up the current app files → copy the new ones (videos, presets,
  profile, music, installed tools are never touched) → remove files the new version no longer has → install new tools
  if the requirements changed → done. Any failure puts the backup back, so a broken download can't break the app.
The Studio then restarts itself on the new code."""
from __future__ import annotations

import json
import hashlib
import re
import threading
import os
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path, PurePosixPath

from . import util

CONFIG = util.KIT / "update.json"
STATE = util.STUDIO_OUT / "update.json"
_studio_update=threading.local()
BACKUP = util.KIT / "update-backup"
MANIFEST = "kit/FILES.txt"                     # every file the zip ships, written by dev/package.sh
KEEP = {".creatorcut-editor-control", "kit/render/creatorcut-compat.json", "kit/render/creatorcut-compat-backup", ".venv", "my-videos", "my-brand", "kit/bin", "kit/projects", "kit/studio-out", "kit/music", "kit/sfx",
        "kit/update.json", "kit/update-backup", "kit/render/node_modules", "kit/claude-runtime", "kit/fonts/google", "skills-lock.json",
        "START HERE.pdf"}
# .claude/skills and .agents/skills: the zip carries only CreatorCut's own skills, so those are replaced; the buyer's
# preset-* skills and the HyperFrames / Remotion skills are never in a zip or in FILES.txt, so they are never touched
DEPS = ("kit/requirements.txt", "kit/requirements-vision.txt", "kit/requirements-claude.txt", "kit/requirements-engine.lock", "kit/requirements-claude.lock", "kit/render/package.json", "kit/render/package-lock.json", "kit/tools/patch_render_runtime.py")


def current() -> str:
    f = util.KIT / "VERSION"
    return f.read_text().strip() if f.exists() else "0"


def _newer(a: str, b: str) -> bool:
    def parts(v):
        match = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?(?:\+[0-9A-Za-z.-]+)?", str(v))
        if not match:
            raise util.Fail('The update version is invalid.')
        pre = match.group(4)
        return (tuple(map(int, match.group(1,2,3))), 1 if pre is None else 0,
                tuple((0,int(x)) if x.isdigit() else (1,x) for x in (pre or '').split('.')))
    return parts(a) > parts(b)


def _safe_rel(rel: str) -> str:
    p = PurePosixPath(rel)
    if not rel or p.is_absolute() or '..' in p.parts or '\\' in rel or ':' in rel or str(p) != rel.rstrip('/'):
        raise util.Fail('The update contains an unsafe file path.')
    return rel


def _validate_package(root: Path) -> None:
    manifest = root / 'kit/SHA256-MANIFEST.json'
    if not manifest.exists():
        return  # Legacy explicitly supplied local packages remain supported.
    hashes = util.read_json(manifest)
    if not isinstance(hashes,dict):
        raise util.Fail('The update manifest is invalid.')
    for rel, expected in hashes.items():
        _safe_rel(rel)
        f = root / rel
        if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest() != expected:
            raise util.Fail('Update file verification failed.', 'Download the trusted release again.')
    unlisted = set(_files(root)) - set(hashes) - {'kit/SHA256-MANIFEST.json'}
    if unlisted:
        raise util.Fail('The update has files missing from its verification manifest.')


def _state(**kv) -> dict:
    s = util.read_json(STATE, default={})
    s.update(kv, current=current())
    util.write_json(STATE, s)
    return s


def public_state(path=None) -> dict:
    """An interrupted journal is not a live updater. Never block Make from a saved flag."""
    value=util.read_json(path or STATE,default={})
    if not isinstance(value,dict):return {'status':'failed','error':'The saved update status needs checking. Your videos are kept.'}
    if (value.get('status') in ('downloading','installing') and not is_running()) or (value.get('status')=='waiting_for_edit' and not is_queued()):
        return dict(value,status='interrupted',step='',pct=0,error='The previous update stopped. Your videos are kept; check for updates again.')
    return value


def _channel_config() -> dict:
    cfg = util.read_json(CONFIG, default={})
    # Older installers preserve kit/update.json. A separately shipped channel
    # lets the new app migrate the known old publisher feed on its first run.
    legacy = cfg.get('url') == 'https://nategold.ai/creatorcut/latest.json'
    if legacy and not cfg.get('github_repository'):
        bundled = util.read_json(util.KIT / 'release-channel.json', default={})
        if bundled.get('github_repository') == 'nategoldai/creatorcut-updates':
            util.write_json(CONFIG, bundled)
            return bundled
    return cfg


_CHECK_CONDITION=threading.Condition()
_CHECK_RUNNING=False
_CHECK_SCOPE=None
_CHECK_RESULT=None
_CHECK_FINISHED=0.

def check(timeout=660,reuse=False) -> dict:
    """Startup, button and apply share one verified discovery, never race its lock."""
    global _CHECK_RUNNING,_CHECK_SCOPE,_CHECK_RESULT,_CHECK_FINISHED
    scope=(str(util.ROOT.resolve()),str(STATE),current(),json.dumps(_channel_config(),sort_keys=True))
    joined=False
    with _CHECK_CONDITION:
        if _CHECK_RUNNING:
            joined=True
            if not _CHECK_CONDITION.wait_for(lambda:not _CHECK_RUNNING,timeout=timeout):
                return {'ok':True,'configured':True,'current':current(),'checking':True,'available':False,'message':'Still checking for your update. Try the button again shortly.'}
        if (joined or reuse) and _CHECK_SCOPE==scope and _CHECK_RESULT is not None and time.monotonic()-_CHECK_FINISHED<5:
            return dict(_CHECK_RESULT)
        _CHECK_RUNNING=True;_CHECK_SCOPE=scope;_CHECK_RESULT=None;_CHECK_FINISHED=0.
    try:
        result=_check_once()
        with _CHECK_CONDITION:_CHECK_RESULT=dict(result);_CHECK_FINISHED=time.monotonic()
        return result
    finally:
        with _CHECK_CONDITION:_CHECK_RUNNING=False;_CHECK_CONDITION.notify_all()


def _check_once() -> dict:
    cfg = _channel_config()
    res = {"ok": True, "current": current(), "configured": bool(cfg.get("url") or cfg.get("github_repository")), "available": False, "checked": time.time()}
    if cfg.get("github_repository"):
        try:
            from .github_updates import inspect
            info = inspect(cfg)
            res.update(info, available=_newer(info['latest'], current()))
        except Exception as e:
            res.update(error="Couldn't check for updates right now.")
            util.log(f"GitHub update check: {e}")
    elif cfg.get("url"):
        try:
            from .linkfetch import _get
            info = json.loads(_get(cfg["url"], timeout=15).decode("utf-8"))
            res.update(latest=str(info.get("version", "")), notes=str(info.get("notes", ""))[:400], zip=info.get("zip", ""), sha256=str(info.get("sha256", "")),
                       available=bool(info.get("zip")) and _newer(str(info.get("version", "0")), current()))
            if res.get('available') and (not str(res.get('zip','')).startswith('https://') or not re.fullmatch(r'[a-fA-F0-9]{64}',res.get('sha256',''))):
                res.update(available=False,error='The publisher needs to verify the new update package.')
        except Exception as e:
            res.update(error="Couldn't check for updates right now.")
            util.log(f"update check: {e}")
    prev = public_state()
    if prev.get("status") in ("downloading", "installing"):
        for key in ('status','step','pct'):
            if key in prev:res[key] = prev[key]
    util.write_json(STATE, res)
    return res


def _kept(rel: str) -> bool:
    """Files an update must never touch: the buyer's data and installed tools."""
    if rel.startswith((".claude/skills/creator-preferences/", ".agents/skills/creator-preferences/")):
        return True
    if rel in {".mcp.json", ".codex/config.toml", ".claude/settings.local.json"}:
        return True
    if "/preset-" in rel and rel.startswith((".claude/skills/", ".agents/skills/")):
        return True
    return any(rel == k or rel.startswith(k + "/") for k in KEEP)


def _files(root: Path) -> list[str]:
    return sorted(p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file() and "__pycache__" not in p.parts)


def ensure_idle():
    """Native edits outside the background-job list must also survive updates."""
    from . import jobs
    if jobs.has_active():
        raise util.Fail('Finish the current background work before installing this update.')
    from . import editor
    unpasted_projects=set()
    for pid in editor.all_projects():
        if not (util.PROJECTS/pid/'project.json').is_file():continue  # deleted project journal
        job=editor.read(pid)
        unpasted=(job.get('execution_mode')=='chat' and job.get('state')=='queued' and not job.get('claimed_owner') and not job.get('claimed_delivery'))
        if unpasted:
            # Even a damaged status label cannot hide a real command holding its kernel fence.
            with util.file_guard(util.PROJECTS/pid/'.chat-command.guard','Finish the current editing command before updating.',timeout=0):pass
            unpasted_projects.add(pid)
        if job.get('state') in editor.ACTIVE and not unpasted:
            raise util.Fail('Finish or stop the current edit before installing this update. Your update stays available.')
    runtime = util.KIT / 'studio-out'
    from . import activity_store
    if any(a.get('running') for a in activity_store.records()):
        raise util.Fail('Finish the current editing steps before installing this update.')
    activity = util.read_json(runtime / 'activity.json', default={})
    if activity.get('running'):
        try:
            pid = int(activity.get('pid') or 0)
            if pid > 0:
                if util.process_alive(pid):raise util.Fail('Finish the current editing step before installing this update.')
        except (ProcessLookupError, ValueError):
            pass
        except PermissionError:
            raise util.Fail('The current editing step needs checking before installing an update.')
    for path in (util.KIT / 'projects').glob('*/workflow.json'):
        if path.parent.name in unpasted_projects:continue
        workflow = util.read_json(path, default={})
        if workflow.get('phase') in ('analysing','planning','building','reviewing') and workflow.get('lease_until',0) > time.time():
            raise util.Fail('Finish or stop the current edit before installing this update.', 'Your new version remains available.')


def is_queued():
    try:
        with util.file_guard(util.KIT/'.update-queue.guard',timeout=0):return False
    except util.LockBusy:return True


def is_running():
    """Stale update status cannot keep standalone editing commands blocked."""
    try:
        with util.file_guard(util.KIT / '.update.guard'):
            return False
    except util.LockBusy:
        return True


def _atomic_copy(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.'+destination.name+'.update-', dir=destination.parent)
    os.close(fd)
    try:
        shutil.copy2(source, temporary)
        os.replace(temporary, destination)
    finally:
        Path(temporary).unlink(missing_ok=True)


def apply(source: str | None = None, progress=None) -> str:
    with util.file_guard(util.KIT / '.update.guard', 'An update is already being installed.'):
        _recover_interrupted()
        ensure_idle()
        return _apply(source, progress)


def _apply(source: str | None = None, progress=None) -> str:
    say = progress or (lambda *_: None)
    old_version = current()
    expected_hash = ""
    if not source:
        info = check(reuse=True)
        if info.get("checking"):
            raise util.Fail("The update is still being checked.", "Wait for the check to finish, then press Download new version. Your current app is kept.")
        if not info.get("configured"):
            raise util.Fail("Updates are not connected to a release feed yet.")
        if info.get("error"):
            raise util.Fail(info["error"])
        if not info.get("available"):
            raise util.Fail("You're already on the latest version.")
        source = info["zip"]
        expected_hash = info.get("sha256", "")
    tmp = Path(tempfile.mkdtemp(prefix="cc-update-"))
    try:
        # 1. download and unpack
        z = tmp / "update.zip"
        say("Downloading the update…", 0.05)
        if source.startswith("http"):
            if not source.startswith('https://'):
                raise util.Fail('Updates must use HTTPS.')
            if not re.fullmatch(r'[a-fA-F0-9]{64}', expected_hash):
                raise util.Fail('The publisher has not provided a verified update package.', 'The update feed needs the ZIP SHA-256 checksum.')
            from .linkfetch import _download
            _download(source, z, progress=lambda f: say("Downloading the update…", 0.05 + 0.45 * f) if isinstance(f, (int, float)) else None)
        else:
            shutil.copy2(source, z)
        if expected_hash and hashlib.sha256(z.read_bytes()).hexdigest().lower() != expected_hash.lower():
            raise util.Fail("The update download failed its checksum.", "Try again after the publisher checks the release.")
        say("Checking the update…", 0.52)
        try:
            with zipfile.ZipFile(z) as zf:
                if zf.testzip() is not None:
                    raise zipfile.BadZipFile
                entries = zf.infolist()
                if len(entries)>10000 or sum(x.file_size for x in entries)>2*1024**3:
                    raise util.Fail('The update archive is unexpectedly large.')
                for item in entries:
                    _safe_rel(item.filename)
                    if (item.external_attr >> 16) & 0o170000 == 0o120000:
                        raise util.Fail('The update archive contains a symbolic link.')
                zf.extractall(tmp / "x")
        except zipfile.BadZipFile:
            raise util.Fail("The download was damaged. Try the update again.")
        roots = [p.parent for p in (tmp / "x").rglob("edit.py") if (p.parent / "kit" / "editkit").is_dir()]
        if not roots:
            raise util.Fail("That file isn't a CreatorCut OS update.")
        if len(roots) != 1:
            raise util.Fail("The update archive contains more than one app.")
        new = roots[0]
        _validate_package(new)
        new_version = (new / "kit" / "VERSION").read_text().strip() if (new / "kit" / "VERSION").exists() else "0"
        if not _newer(new_version, old_version):
            raise util.Fail("That update is not newer than your installed version.")
        old_channel = util.read_json(CONFIG,default={})
        new_channel = util.read_json(new/'kit/update.json',default={})
        old_connected = bool(old_channel.get('url') or old_channel.get('github_repository'))
        # A verified publisher package may migrate the old curated website channel.
        # Never replace a customer's custom channel or an existing GitHub connection.
        legacy_default = old_channel.get('url') == 'https://nategold.ai/creatorcut/latest.json' and not old_channel.get('github_repository')
        adopt_feed = ((not old_connected and bool(new_channel.get('url') or new_channel.get('github_repository')))
                      or (legacy_default and bool(new_channel.get('github_repository'))))
        new_files = [f for f in _files(new) if not _kept(f) or (f == 'kit/update.json' and adopt_feed)]
        ensure_idle()  # Downloading may have taken time; check again before any app file changes.
        old_listed = (util.ROOT / MANIFEST).read_text().split("\n") if (util.ROOT / MANIFEST).exists() else []
        for rel in old_listed:
            if rel: _safe_rel(rel)
        stale = [f for f in old_listed if f and f not in set(new_files) and not _kept(f) and (util.ROOT / f).is_file()]
        deps_before = {d: (util.ROOT / d).read_bytes() if (util.ROOT / d).exists() else b"" for d in DEPS}

        # 2. back up everything this update will change (one backup, the version before)
        say("Backing up the current version…", 0.56)
        shutil.rmtree(BACKUP, ignore_errors=True)
        BACKUP.mkdir(parents=True)
        touched = sorted(set(new_files) | set(stale))
        existed = []
        for rel in touched:
            src = util.ROOT / rel
            if src.is_file():
                (BACKUP / rel).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, BACKUP / rel)
                existed.append(rel)
        transaction={"version": old_version, "target": new_version, "existed": existed, "touched": touched, "phase": "applying"}
        policy=util.read_json(new/'kit/execution-policy.json',default={})
        if policy.get('default_editor_mode')=='chat':
            from . import editor
            cfg=editor.config()
            transaction['editor_mode_migration']={'had_key':'editor_mode' in cfg,'before':cfg.get('editor_mode'),'after':'chat'}
        util.write_json(BACKUP / "backup.json", transaction)

        from . import maintenance
        with maintenance.writing(hold_until_restart=getattr(_studio_update,"active",False)):
            # 3. copy the new files, remove the ones it dropped; any error puts the backup back
            try:
                say("Installing the new version…", 0.62)
                for rel in new_files:
                    dest = util.ROOT / rel
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    _atomic_copy(new / rel, dest)
                for rel in stale:
                    (util.ROOT / rel).unlink(missing_ok=True)
                if transaction.get('editor_mode_migration'):
                    from . import editor
                    cfg=editor.config();cfg['editor_mode']='chat'
                    util.write_durable_json(editor.root()/'config.json',cfg)
                changed = [d for d in DEPS if deps_before[d] != ((util.ROOT / d).read_bytes() if (util.ROOT / d).exists() else b"")]
                from . import chat_execution
                if chat_execution.mode()=='chat':changed=[d for d in changed if d not in ('kit/requirements-claude.txt','kit/requirements-claude.lock')]
                if changed:
                    say("Installing new tools…", 0.75)
                    _backup_runtime_dependencies(changed,transaction)
                    _install_deps(changed)
                util.write_json(BACKUP / "backup.json", dict(transaction, phase="committed"))
            except Exception:
                util.log("update failed, restoring the backup")
                rollback()
                raise
        say(f"Updated to version {new_version}", 1.0)
        util.ok(f"Updated from {old_version} to {current()}")
        return current()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def rollback() -> str:
    """Put the version from before the last update back (files only; data was never touched)."""
    info = util.read_json(BACKUP / "backup.json", default=None)
    if not info:
        raise util.Fail("There's no earlier version to go back to.")
    existed = set(info["existed"])
    # Preflight the complete restore before any mutation. Recovery must never
    # target videos, presets, memory, account config or installed runtimes.
    for rel in info["touched"]:
        _safe_rel(rel)
        if _kept(rel) and rel != 'kit/update.json':
            raise util.Fail('The update backup includes protected customer data.')
    migration=info.get('editor_mode_migration')
    if migration:
        if migration.get('after')!='chat' or migration.get('before') not in (None,'chat','managed'):raise util.Fail('The saved editing mode migration is invalid.')
        from . import editor
        cfg=editor.config()
        if migration.get('had_key'):cfg['editor_mode']=migration['before']
        else:cfg.pop('editor_mode',None)
        util.write_durable_json(editor.root()/'config.json',cfg)
    _restore_runtime_dependencies(info)
    for rel in info["touched"]:
        dest = util.ROOT / rel
        if rel in existed:
            dest.parent.mkdir(parents=True, exist_ok=True)
            _atomic_copy(BACKUP / rel, dest)
        else:
            dest.unlink(missing_ok=True)
    util.write_json(BACKUP / "backup.json", dict(info, phase="restored"))
    util.ok(f"Back on version {current()}")
    return current()


def _recover_interrupted():
    info=util.read_json(BACKUP/'backup.json',default={})
    if info.get('phase') != 'applying':return False
    version=rollback()
    _state(status='failed',available=True,pct=0,step='',error='The previous update was interrupted. Your previous app version and saved work are restored. Try the update again.')
    util.log('Recovered interrupted update to '+version)
    return True

def recover_interrupted():
    """Only restore a durable uncommitted transaction whose installer is gone."""
    try:
        with util.file_guard(util.KIT/'.update.guard',timeout=0):
            return _recover_interrupted()
    except util.LockBusy:return False


RUNTIME_PATHS={'python':'.venv','claude':'kit/claude-runtime','node':'kit/render/node_modules'}

def _runtime_keys(changed):
    result=[]
    if any(x in changed for x in ('kit/requirements.txt','kit/requirements-vision.txt','kit/requirements-engine.lock')):result.append('python')
    if any(x in changed for x in ('kit/requirements-claude.txt','kit/requirements-claude.lock')):
        from . import editor
        if editor.provider_name()=='claude':result.append('claude')
    if any(x in changed for x in ('kit/render/package.json','kit/render/package-lock.json')):result.append('node')
    return result

def _backup_runtime_dependencies(changed,transaction):
    keys=_runtime_keys(changed)
    if not keys:return
    rows={key:{'path':RUNTIME_PATHS[key],'existed':(util.ROOT/RUNTIME_PATHS[key]).exists()} for key in keys}
    # A complete old runtime is retained before any package manager can modify it.
    estimate=0
    for row in rows.values():
        path=util.ROOT/row['path']
        if path.is_symlink():raise util.Fail('The editing tools must be private local folders before updating. Your current tools were kept.')
        if path.is_dir():estimate+=sum(f.stat().st_size for f in path.rglob('*') if f.is_file() and not f.is_symlink())
    if shutil.disk_usage(util.ROOT).free<estimate+2_500_000_000:raise util.Fail('This update needs more free space to keep a working rollback copy. Your current version was kept.')
    transaction['runtimes']=rows;util.write_durable_json(BACKUP/'backup.json',transaction)
    for key,row in rows.items():
        old=util.ROOT/row['path'];saved=BACKUP/'runtimes'/key
        if row['existed']:
            saved.parent.mkdir(parents=True,exist_ok=True);os.replace(old,saved)
            shutil.copytree(saved,old,symlinks=True)

def _restore_runtime_dependencies(info):
    rows=info.get('runtimes',{})
    if not isinstance(rows,dict):raise util.Fail('The runtime recovery record is not valid.')
    for key,row in rows.items():
        if key not in RUNTIME_PATHS or not isinstance(row,dict) or row.get('path')!=RUNTIME_PATHS[key]:raise util.Fail('The runtime recovery path is not valid.')
    for key,row in rows.items():
        live=util.ROOT/row['path'];saved=BACKUP/'runtimes'/key
        if saved.is_dir():
            if live.is_symlink():live.unlink()
            elif live.exists():shutil.rmtree(live)
            live.parent.mkdir(parents=True,exist_ok=True);os.replace(saved,live)
        elif not row.get('existed'):
            if live.is_symlink():live.unlink()
            elif live.exists():shutil.rmtree(live)


def _install_deps(changed: list[str]) -> None:
    bin_ = util.KIT / "bin"
    vpy = util.ROOT / (".venv/Scripts/python.exe" if os.name == "nt" else ".venv/bin/python")
    uv = bin_ / ("uv.exe" if os.name == "nt" else "uv")
    engine_lock=util.KIT/'requirements-engine.lock'
    if engine_lock.is_file() and any(x in changed for x in ('kit/requirements.txt','kit/requirements-vision.txt','kit/requirements-engine.lock')):
        cmd=([str(uv),'pip','install','--python',str(vpy)] if uv.exists() else [str(vpy),'-m','pip','install'])
        subprocess.run(cmd+['--require-hashes','--only-binary',':all:','-r',str(engine_lock)],check=True,capture_output=True,timeout=1800)
    elif not engine_lock.is_file():
        # Compatibility with old fixtures/packages; every new release includes its verified lock.
        for req in ('kit/requirements.txt','kit/requirements-vision.txt'):
            if req in changed and (util.ROOT/req).is_file():
                cmd=([str(uv),'pip','install','--python',str(vpy)] if uv.exists() else [str(vpy),'-m','pip','install'])
                subprocess.run(cmd+['-r',str(util.ROOT/req)],check=True,capture_output=True,timeout=1800)
    if any(x in changed for x in ("kit/requirements-claude.txt","kit/requirements-claude.lock")):
        from . import editor
        if editor.provider_name()=='claude' and __import__('editkit.chat_execution',fromlist=['mode']).mode()!='chat':
            locked=(util.KIT/'requirements-claude.lock').is_file()
            requirement=util.KIT/('requirements-claude.lock' if locked else 'requirements-claude.txt')
            cmd=([str(uv),'pip','install','--python',str(vpy),'--target',str(util.KIT/'claude-runtime'),'-r',str(requirement)] if uv.exists() else
                 [str(vpy),'-m','pip','install','--target',str(util.KIT/'claude-runtime'),'-r',str(requirement)])
            if locked:cmd+=['--upgrade','--require-hashes','--only-binary',':all:']
            env=dict(os.environ,UV_CACHE_DIR=str(bin_/'uv-cache'))
            subprocess.run(cmd,check=True,capture_output=True,timeout=1800,env=env)
            subprocess.run([str(vpy),'-c',"import sys;sys.path.insert(0,'kit');from editkit import claude_runtime;assert claude_runtime.ready()"],cwd=util.ROOT,check=True,capture_output=True,timeout=30,env=env)
    if any(x in changed for x in ("kit/render/package.json", "kit/render/package-lock.json")):
        node = bin_ / "node"
        npm = node / "npm.cmd" if os.name == "nt" else node / "bin" / "npm"
        if not npm.exists():
            raise util.Fail('The update needs the local renderer installer. Run setup, then try the update again.')
        if npm.exists():
            env = dict(os.environ, PATH=str(npm.parent) + os.pathsep + os.environ.get("PATH", ""),
                       npm_config_cache=str(bin_ / "npm-cache"), npm_config_update_notifier="false",
                       npm_config_fund="false", npm_config_audit="false")
            subprocess.run([str(npm), "ci", "--no-audit", "--no-fund"], cwd=util.KIT / "render", env=env, check=True,
                           capture_output=True, timeout=1800, shell=os.name == "nt")
            browser=util.KIT/"render/node_modules/.bin"/("remotion.cmd" if os.name=="nt" else "remotion")
            subprocess.run([str(browser),"browser","ensure"],cwd=util.KIT/"render",env=env,check=True,capture_output=True,timeout=600,shell=os.name=="nt")
            verify=util.KIT/'setup/verify-render.cjs'
            executable=node/('node.exe' if os.name=='nt' else 'bin/node')
            if not verify.exists() or not executable.exists():
                raise util.Fail('Renderer update verification is unavailable. Run setup and retry.')
            subprocess.run([str(executable),str(verify),str(util.KIT/'render')],cwd=util.ROOT,env=env,check=True,capture_output=True,timeout=60)


    # Apply the app-owned compatibility patch after files/dependencies are ready,
    # including updates which change only adapter code. No editing-session grants.
    compatibility=util.KIT/'tools/patch_render_runtime.py'
    installed=util.KIT/'render/node_modules/hyperframes/package.json'
    if compatibility.is_file() and installed.is_file():
        subprocess.run([str(sys.executable),str(compatibility),str(util.KIT/'render')],cwd=util.ROOT,check=True,capture_output=True,timeout=60)


_UPDATE_LOCK = threading.Lock()

def run_in_studio(on_done) -> None:
    """The Update button: runs apply() in the background with progress the Studio shows, then on_done() (restart)."""
    if not _UPDATE_LOCK.acquire(blocking=False):
        return
    def say(text, frac):
        _state(status="installing" if frac > 0.5 else "downloading", step=text, pct=round(frac, 3))
    queue=None
    try:
        queue=util.file_guard(util.KIT/'.update-queue.guard',timeout=0)
        queue.__enter__()
    except util.LockBusy:
        _UPDATE_LOCK.release();return
    except BaseException:
        _UPDATE_LOCK.release();raise
    applied=False
    idle_deadline=time.monotonic()+600
    try:
        _state(status="downloading", step="Starting the update…", pct=0.01, error="")
        while True:
            try:ensure_idle();break
            except util.Fail:
                if time.monotonic()>=idle_deadline:raise util.Fail('Your edit is still active. Finish or stop it, then download the update again. Your current version is kept.')
                _state(status='waiting_for_edit',step='Your update will install after the current edit finishes.',pct=None,error='')
                time.sleep(2)
        _studio_update.active=True
        v = apply(progress=say)
        applied=True
        _state(status="done", step=f"Updated to version {v}", pct=1.0, available=False)
        on_done()
    except Exception as e:
        if applied:
            from . import maintenance
            maintenance.restart_failed()
            msg="Your update is installed. Close and reopen CreatorCut to finish; your videos and presets are saved."
        else:
            msg = e.args[0] if isinstance(e, util.Fail) and e.args else "The update didn't finish. Your previous app files were kept; retry the update."
        util.log(f"update: {e!r}")
        _state(status="failed", step="", pct=0, error=msg)
    finally:
        _studio_update.active=False
        if queue is not None:queue.__exit__(None,None,None)
        _UPDATE_LOCK.release()


def restart_server() -> None:
    """Start the Studio again on the new code (same process id, same port)."""
    time.sleep(1.5)                                    # let the page see "done" first
    os.execv(sys.executable, [sys.executable] + sys.argv)
