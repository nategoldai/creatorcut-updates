"""Project Stop-hook handoff. No global settings, transcript reads or idle continuation."""
import json
from . import chat_execution,native_receiver,util

def stop(stream):
 if chat_execution.paste_only():return None # Old hook commands must not read or wait in customer mode.
 try:data=json.loads(stream.read(65537))
 except (ValueError,OSError):return None
 if not isinstance(data,dict) or data.get('stop_hook_active') or chat_execution.mode()!='chat' or chat_execution.paste_only():return None
 conversation=data.get('session_id')
 if not isinstance(conversation,str) or not conversation:return None
 try:
  if not native_receiver.studio_open():return None
  result=native_receiver.wait(45,conversation,require_open=True)
 except (OSError,ValueError,util.Fail):return None
 action=result.get('native_action')
 if not action:return None
 return {'decision':'block','reason':action['text']}
