"""Video projects as the Studio sees them: a draft with its own media bin (raw footage, B-roll, images, music),
a brief (prompt, reference links, style, length), frame annotations, and numbered versions.

Folder: kit/projects/<id>/
  project.json   engine settings + studio fields (title, brief, media, status)
  media/         copies of everything the creator added (originals are never touched)
  annotations.json  saved-version frame/range feedback; chat.json is legacy display history only
  versions/      v1.mp4, v2.mp4 … + versions.json [{n, file, note, time}]
"""
from __future__ import annotations

import datetime as dt
import contextlib
import os
import re
import shutil
import threading
import queue
import time
import uuid
from pathlib import Path

from . import events, util
from .cut import tonemap_filter

MEDIA_KINDS = {"raw": util.VIDEO_EXT, "broll": util.VIDEO_EXT | util.IMAGE_EXT, "image": util.IMAGE_EXT,
               "music": util.AUDIO_EXT}
_lock = threading.RLock()
_picture_jobs=queue.Queue(maxsize=64)
_picture_worker_lock=threading.Lock()
_picture_worker=None


def _schedule_pictures(pid,mid,path,kind):
    """Bound slow strip/hero decoding; fast fallback posters remain separately bounded."""
    global _picture_worker
    with _picture_worker_lock:
        if _picture_worker is None or not _picture_worker.is_alive():
            job_queue=_picture_jobs
            def work():
                while True:
                    args=job_queue.get()
                    try:_pictures(*args)
                    except Exception:util.log_exception('thumbnail details')
                    finally:job_queue.task_done()
            _picture_worker=threading.Thread(target=work,daemon=True,name='creatorcut-thumbnail-details')
            try:_picture_worker.start()
            except RuntimeError:
                _picture_worker=None;util.log('Thumbnail detail worker unavailable; fallback posters remain available.');return
    try:_picture_jobs.put_nowait((pid,mid,path,kind))
    except queue.Full:util.log('Thumbnail detail capacity reached; bounded fallback posters remain available.')


def _dir(pid: str) -> Path:
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,80}", pid or ""):
        raise util.Fail("That video doesn't exist.")
    d = util.PROJECTS / pid
    if not (d / "project.json").exists():
        raise util.Fail("That video doesn't exist.")
    return d


def load(pid: str) -> dict:
    return util.read_json(_dir(pid) / "project.json")


def save(pid: str, cfg: dict) -> None:
    util.write_json(_dir(pid) / "project.json", cfg)


def update(pid: str, fn) -> dict:
    with _lock, util.file_guard(_dir(pid) / '.metadata.guard', 'This video is saving another change.', timeout=5):
        cfg = load(pid)
        fn(cfg)
        save(pid, cfg)
        return cfg


def create(title: str = "", style: str = "", platform: str = "", request_id: str = "") -> dict:
    """One project per explicit creation request, even if its HTTP reply is lost."""
    if request_id and not re.fullmatch(r"[A-Za-z0-9_-]{1,128}",request_id):
        raise util.Fail("The video creation request is invalid.")
    args = {"title": title, "style": style, "platform": platform}
    with _lock, util.file_guard(util.PROJECTS / '.creation.guard', 'Another video is being created.', timeout=5):
        if request_id:
            for f in util.PROJECTS.glob('*/project.json'):
                c = util.read_json(f)
                if c.get('creation_request') == request_id:
                    if c.get('creation_args') != args:
                        raise util.Fail("This creation request already belongs to another video.")
                    return c
        c = _create(title, style, platform)
        if request_id:
            c.update(creation_request=request_id, creation_args=args)
            save(c['name'], c)
        return c


def _create(title: str = "", style: str = "", platform: str = "") -> dict:
    """A new, empty video draft."""
    prof = util.load_profile()
    title = (title or "").strip()[:80] or "Untitled video"
    base = util.slugify(title if title != "Untitled video" else "video-" + dt.datetime.now().strftime("%m%d-%H%M"))
    pid, n = base, 2
    util.PROJECTS.mkdir(parents=True,exist_ok=True)
    while True:
        d=util.PROJECTS/pid
        try:d.mkdir();break
        except FileExistsError:pid,n=f'{base}-{n}',n+1
    (d / 'media').mkdir()
    cfg = {"name": pid, "title": title, "created": dt.datetime.now().isoformat(timespec="seconds"),
           "style": style or prof.get("style") or "creatorcut-signature", "platform": platform or "vertical",
           "grade": None, "look": "natural", "voice_cleanup": False, "music": prof.get("music", "none"), "keywords": prof.get("keywords", []),
           "cta": prof.get("cta", ""), "captions": {}, "framing": {"fit": "cover", "x": 0.5, "y": 0.45},
           "status": "draft", "version": 0, "media": [], "brief": {"prompt": "", "references": [], "length": "best"},
           "studio": True}
    from . import presets
    recipe = presets.recipe_context(cfg.get('style', ''))
    cfg['preset_version'] = recipe.get('version')
    template=recipe.get('brief_template') or {}
    if template:
        cfg['brief'].update(prompt=template.get('prompt',''),prompt_origin='preset')
        cfg['preset_library_choices']=template.get('settings',{}).get('library_choices',{})
        for key,value in template.get('settings',{}).items():
            if key!='library_choices':cfg[key]=value
    util.write_json(d / "project.json", cfg)
    util.write_json(d / "chat.json", {"messages": []})
    events.emit("video.created", {"project": pid, "title": title})
    return cfg


def _unguarded_add_media(pid: str, path: Path, kind: str, name: str) -> dict:
    """Register a file that was just copied into the project's media folder."""
    item = {"id": uuid.uuid4().hex[:8], "kind": kind, "file": util.rel(path), "name": name,
            "added": time.time(), "size_mb": round(path.stat().st_size / 1e6, 1)}
    info = None
    if path.suffix.lower() in util.VIDEO_EXT:
        # A missing tool is a setup failure, not a damaged uploaded file.
        util.ffprobe_bin()
        try:
            info = util.probe(path)
        except Exception:
            path.unlink(missing_ok=True)
            raise util.Fail(f"'{name}' can't be read as a video (it may be damaged or still downloading).",
                            "Export it again from your phone or camera, then drop it in again.")
    if path.suffix.lower() in util.VIDEO_EXT | util.AUDIO_EXT:
        try:
            item["duration"] = round(info["duration"], 1) if info else _audio_duration(path)
        except Exception:
            pass
    if path.suffix.lower() in util.IMAGE_EXT:
        item["thumb"] = util.rel(_thumb(path))
    update(pid, lambda c: c.setdefault("media", []).append(item))
    events.emit("media.added", {"project": pid, "kind": kind, "name": name, "id": item["id"]})
    if path.suffix.lower() in util.VIDEO_EXT:             # pictures of a long 4K clip take a while: never hold the upload
        _schedule_pictures(pid,item["id"],path,kind)
    return item


def _pictures(pid: str, mid: str, path: Path, kind: str) -> None:
    """Thumbnail, film strip and size of a video in the bin, added to its item when ready."""
    extra: dict = {}
    try:
        frame=_thumb(path)
        if frame.is_file():extra["thumb"] = util.rel(frame)
        if kind == "raw":
            extra["strip"] = [util.rel(f) for f in _strip(path)]
            h = hero(path)
            if h:
                extra["hero"] = util.rel(h)
            info = util.probe(path)
            extra["w"], extra["h"] = info["width"], info["height"]
    except Exception as e:
        util.log(f"media pictures for {path.name}: {e}")
    def fn(c):
        for m in c.get("media", []):
            if m.get("id") == mid:
                m.update(extra)
    try:
        update(pid, fn)
        events.emit("media.ready", {"project": pid, "id": mid})
    except Exception as e:                               # the video was deleted meanwhile
        util.log(f"media pictures: {e}")


def _unguarded_remove_media(pid: str, mid: str) -> None:
    def fn(c):
        keep = []
        for m in c.get("media", []):
            if m["id"] == mid:
                f = util.ROOT / m["file"]
                if f.exists() and _dir(pid) in f.resolve().parents:   # only ever delete our own copies
                    f.unlink()
            else:
                keep.append(m)
        c["media"] = keep
    update(pid, fn)


def _audio_duration(p: Path) -> float | None:
    try:
        out = util.run([util.ffprobe_bin(), "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(p)]).stdout
        return round(float(out.strip()), 1)
    except Exception:
        return None


def _thumb(p: Path) -> Path:
    out = p.parent / ".thumbs" / (p.stem + ".jpg")
    out.parent.mkdir(exist_ok=True)
    try:
        if p.suffix.lower() in util.IMAGE_EXT:
            from PIL import Image, ImageOps
            im = ImageOps.exif_transpose(Image.open(p)).convert("RGB")
            im.thumbnail((360, 640))
            im.save(out, quality=84)
        else:
            info=util.probe(p);dur=info["duration"]
            util.run([util.ffmpeg_bin(), "-y", "-threads", "1", "-filter_threads", "1", "-hide_banner", "-ss", f"{min(1.0, dur / 3):.2f}", "-i", str(p),
                      "-frames:v", "1", "-vf", tonemap_filter(info)+"scale=360:-2", "-q:v", "4", str(out)], timeout=15)
    except Exception:
        pass
    return out


def hero(p: Path) -> Path | None:
    """A sharp frame of a clip (1080 px on the long side) for the Studio's editor view while it edits."""
    out = p.parent / ".thumbs" / (p.stem + "-hero.jpg")
    if out.exists():
        return out
    out.parent.mkdir(exist_ok=True)
    try:
        info=util.probe(p);dur=info["duration"]
        util.run([util.ffmpeg_bin(), "-y", "-threads", "1", "-filter_threads", "1", "-hide_banner", "-v", "error", "-ss", f"{min(1.5, dur / 3):.2f}", "-i", str(p), "-frames:v", "1",
                  "-vf", tonemap_filter(info)+"scale='if(gt(iw,ih),1080,-2)':'if(gt(iw,ih),-2,1080)'", "-q:v", "2", str(out)], timeout=15)
        return out if out.exists() else None
    except Exception:
        return None


def _strip(p: Path, n: int = 14) -> list[Path]:
    """Small frames across a clip, for the Studio's filmstrip while it edits."""
    out_dir = p.parent / ".thumbs"
    out_dir.mkdir(exist_ok=True)
    files = []
    try:
        info=util.probe(p);dur=info["duration"]
        util.run([util.ffmpeg_bin(), "-y", "-threads", "1", "-filter_threads", "1", "-hide_banner", "-i", str(p), "-vf",
                  tonemap_filter(info)+f"fps={n / max(dur, 0.5):.4f},scale=240:-2", "-frames:v", str(n), "-q:v", "3",
                  str(out_dir / f"{p.stem}-strip-%02d.jpg")], timeout=45)
        files = sorted(out_dir.glob(f"{p.stem}-strip-*.jpg"))
    except Exception:
        pass
    return files


def set_brief(pid: str, brief: dict) -> dict:
    if "length" in brief:
        from .request_constraints import length_bounds
        length_bounds(brief["length"])
    allowed = {"prompt", "references", "length", "title", "style", "platform", "step", "look", "library_choices", "captions_on", "music"}
    if 'captions_on' in brief and type(brief['captions_on']) is not bool:
        raise util.Fail('Choose captions on or off.')
    if 'music' in brief and brief['music'] not in ('auto','none'):
        raise util.Fail('Choose music on or off.')
    selected_recipe = None
    if 'library_choices' in brief:
        from . import library
        brief = dict(brief, library_choices=library.pin_choices(brief['library_choices']))
    if "style" in brief:
        from . import presets, styles
        sid = str(brief["style"])
        if not sid or not styles.style_path(sid):
            raise util.Fail("That preset is no longer available. Choose another style.")
        selected_recipe = presets.recipe_context(sid)

    def fn(c):
        if selected_recipe is not None:
            c["preset_version"] = selected_recipe.get("version")
            template = selected_recipe.get("brief_template") or {}
            # Preset code choices are a lower input layer; never promote them to current manual overrides.
            if selected_recipe.get('kind') in ('brief','reviewed','snapshot'):
                c['preset_library_choices'] = template.get('settings',{}).get('library_choices',{})
            # A customer's current brief always wins; seed empty new projects only.
            if not c.get("brief",{}).get("prompt") and "prompt" not in brief:
                c.setdefault("brief",{}).update(prompt=template.get("prompt", ""),prompt_origin="preset")
                for key,value in template.get("settings",{}).items():
                    if key=="music_selection" and c.get("choice_origins",{}).get("music")=="studio":continue
                    if key not in brief and key != "library_choices" and c.get("choice_origins",{}).get(key)!="studio": c[key]=value
        for k, v in brief.items():
            if k not in allowed:
                continue
            if k=="library_choices" and isinstance(v.get("caption"),dict):c.setdefault("captions",{}).pop("mode",None)
            if k in ("look","library_choices","captions_on","music"):
                c.setdefault("choice_origins",{})["captions" if k=="captions_on" else k]="studio"
            if k in ("title", "style", "platform"):
                c[k] = str(v)[:80]
            elif k == 'prompt':
                text=str(v)[:20000];saved=c.setdefault('brief',{})
                if text!=saved.get('prompt') or saved.get('prompt_origin')!='preset':saved['prompt_origin']='current'
                saved['prompt']=text
            elif k == "captions_on":
                c.setdefault("captions", {})["enabled"] = v
                if v and c.get("library_choices", {}).get("caption") == "none":
                    c["library_choices"].pop("caption", None)
            elif k == "music":
                c["music"] = v
                c.pop("music_selection",None)
            elif k == "library_choices":
                c[k] = v
            elif k == "look":
                from . import colour_choice
                selected=colour_choice.choice({'look':str(v)})
                c['look']=selected;c['grade']=None;c['colour_recipe']=None;c['colour_recipe']=colour_choice.pin(c)
            elif k == "step":
                c["studio_step"] = str(v)[:20]
            elif k == "references":
                c.setdefault("brief", {})[k] = [str(u)[:300] for u in (v or [])][:5]
            else:
                c.setdefault("brief", {})[k] = str(v)[:20000 if k == "prompt" else 4000]
    from . import editor,requests
    import copy
    p=_dir(pid)
    with util.file_guard(p/'.request.guard',timeout=5),util.file_guard(p/'.editor-job.guard',timeout=5):
        active_job=editor.read(pid).get('state') in editor.ACTIVE
        if active_job:
            before=load(pid);after=copy.deepcopy(before);fn(after)
            if requests.settings(before)!=requests.settings(after):
                raise util.Fail('This edit is running. Your current settings are protected; add changes on its timeline after this pass.')
        if not active_job and 'music' in brief:
            from . import music_library
            music_library.clear_pending_music(p)
        result = update(pid, fn)
    if "style" in brief and not active_job:
        from . import learn
        learn.project_memory(_dir(pid), result.get("style"))
    return result


# ------------------------------------------------------------------- chat ----
def chat(pid: str) -> list[dict]:
    return util.read_json(_dir(pid) / "chat.json", default={"messages": []}).get("messages", [])



@contextlib.contextmanager
def _chat_file_lock(pid):
    """A short, OS-released lock independent of long rendering locks."""
    f=(_dir(pid)/'.chat.lock').open('a+b')
    acquired=False
    try:
        f.seek(0,2)
        if f.tell()==0:f.write(b'0');f.flush()
        deadline=time.monotonic()+2
        while not acquired:
            try:
                f.seek(0)
                if os.name=='nt':
                    import msvcrt
                    msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
                else:
                    import fcntl
                    fcntl.flock(f.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
                acquired=True
            except (OSError,BlockingIOError):
                if time.monotonic()>deadline:
                    raise util.Fail('The local conversation mirror is busy.', 'The native conversation is unchanged. Retry mirroring this reply.')
                time.sleep(.01)
        yield
    finally:
        if acquired:
            if os.name=='nt':
                import msvcrt
                f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
            else:
                import fcntl
                fcntl.flock(f.fileno(),fcntl.LOCK_UN)
        f.close()

def say(pid: str, role: str, text: str, **extra) -> dict:
    msg = {"id": uuid.uuid4().hex[:8], "role": role, "text": text.strip()[:6000], "time": time.time(), **extra}
    with _lock, _chat_file_lock(pid):
        f = _dir(pid) / "chat.json"
        data = util.read_json(f, default={"messages": []})
        if extra.get("native_reply_id"):
            prior=next((m for m in data["messages"] if m.get("native_reply_id")==extra["native_reply_id"]),None)
            if prior:return prior
        data["messages"].append(msg)
        data["messages"] = data["messages"][-400:]
        util.write_json(f, data)
    return msg


# --------------------------------------------------------------- versions ----
def versions(pid: str) -> list[dict]:
    return util.read_json(_dir(pid) / "versions" / "versions.json", default={"versions": []}).get("versions", [])


def snapshot_version(pid: str, note: str = "") -> dict:
    """Publish complete version files before atomically committing their index."""
    import tempfile
    d=_dir(pid);versions_dir=d/'versions';versions_dir.mkdir(exist_ok=True)
    with util.file_guard(d/'.versions.guard',timeout=30):
        staging=Path(tempfile.mkdtemp(prefix='.version-partial-',dir=versions_dir))
        try:return _snapshot_version_locked(pid,note,staging)
        finally:shutil.rmtree(staging,ignore_errors=True)

def _snapshot_version_locked(pid: str, note: str, staging: Path) -> dict:
    """Keep a copy of the current preview as the next version (v1, v2 …)."""
    d = _dir(pid)
    from . import workflow
    candidate = workflow.require_release(d)
    prev = d / candidate['file']
    old = versions(pid)
    if old and old[-1].get('candidate_sha256') == candidate['sha256']:
        return old[-1]
    final=d/"versions";final.mkdir(exist_ok=True)
    vd=staging
    data = util.read_json(final / "versions.json", default={"versions": []})
    n = len(data["versions"]) + 1
    out = vd / f"v{n}.mp4"
    shutil.copy2(prev, out)
    if (d / "edit-plan.json").exists():                  # the plan of each version: the learning loop compares them
        shutil.copy2(d / "edit-plan.json", vd / f"v{n}.plan.json")
    for source, suffix in [('scene-plan.json','scenes.json'), ('render/release-review.json','review.json'), ('segments.json','segments.json'), ('words.json','words.json')]:
        if (d/source).exists(): shutil.copy2(d/source, vd/f'v{n}.{suffix}')
    from . import library
    saved_settings=load(pid).copy()
    saved_settings['library_choices']=library.choices(d,include_disabled=True)
    saved_settings.pop('preset_library_choices',None)
    settings_file=vd/f'v{n}.settings.json'
    util.write_json(settings_file,saved_settings)
    library_source=d/'work/style-library'
    if library_source.exists():
        library_version=vd/f'v{n}.library';library_version.mkdir(exist_ok=True)
        for filename in ('picks.json','words.json','layout.json','plan.json','execution.json'):
            if (library_source/filename).is_file():shutil.copy2(library_source/filename,library_version/filename)
        for receipt in (library_source/'fx').glob('*/creatorcut-receipt.json'):
            dest=library_version/'effects'/receipt.parent.name;dest.mkdir(parents=True,exist_ok=True)
            for filename in ('creatorcut-receipt.json','creatorcut-parameters.json'):
                if (receipt.parent/filename).exists():shutil.copy2(receipt.parent/filename,dest/filename)
    from . import music_library,requests
    saved_request=requests.active(d)
    music_credit=music_library.attribution(saved_request.get('settings',{}).get('music_selection'))
    if music_credit:
        (vd/f'v{n}.credits.txt').write_text(music_credit['text']+'\n',encoding='utf-8')
    info = candidate.get("probe") or util.probe(prev)
    poster = vd / f"v{n}.jpg"
    try:
        util.run([util.ffmpeg_bin(), "-y", "-hide_banner", "-ss", "0.8", "-i", str(out), "-frames:v", "1",
                  "-vf", tonemap_filter(info)+"scale=360:-2", "-q:v", "4", str(poster)])
    except util.Fail:
        pass
    if workflow.digest(out)!=candidate["sha256"]:raise util.Fail("The saved movie copy did not verify. Your previous video version is kept.")
    v = {"review_file": util.rel(final / f"v{n}.review.json"), "candidate_sha256": candidate["sha256"], "n": n, "file": util.rel(final/out.name), "poster": util.rel(final/poster.name) if poster.exists() else "", "note": note[:200],
         "time": time.time(), "duration": round(util.probe(out)["duration"], 3), "fps":30,"settings_sha256":workflow.digest(settings_file)}
    if music_credit:v['music_credit']=music_credit;v['credits_file']=util.rel(final/f'v{n}.credits.txt')
    # The index is the commit point. Never expose a version before all of its files exist.
    for source in vd.iterdir():
        target=final/source.name
        if target.is_dir():shutil.rmtree(target)  # only an unindexed, interrupted version number
        source.replace(target)
    data["versions"].append(v)
    util.write_durable_json(final / "versions.json", data)
    out=final/out.name
    public=d/'preview.mp4';tmp=public.with_suffix('.partial.mp4')
    shutil.copy2(out,tmp);tmp.replace(public)
    events.emit("version.ready", {"project": pid, "n": n, "note": note[:200]}, source="engine")
    to_shelf(pid, out, f"v{n}")
    return v


def shelf(pid: str) -> Path:
    """my-videos/<video name>/: every version and the final of one video, where the creator finds them in Finder."""
    cfg = load(pid)
    name = cfg.get("shelf")
    if not name:
        title = (cfg.get("title") or "").strip()
        base = re.sub(r"[^\w .()&,'-]", "", title if title and title != "Untitled video" else pid).strip(" .")[:60] or pid
        name, k = base, 2
        while (util.ROOT / "my-videos" / name).exists() and not (util.ROOT / "my-videos" / name / ".video").exists():
            name, k = f"{base} {k}", k + 1
        update(pid, lambda c: c.update(shelf=name))
    d = util.ROOT / "my-videos" / name
    d.mkdir(parents=True, exist_ok=True)
    (d / ".video").write_text(pid)
    return d


def to_shelf(pid: str, src: Path, label: str) -> Path | None:
    """Put a copy of a version / the final in the video's own folder (a hard link when possible: no extra space)."""
    try:
        d = shelf(pid)
        dest = d / f"{d.name} {label}{src.suffix.lower()}"
        temporary = dest.with_name('.'+dest.name+'.'+uuid.uuid4().hex+'.partial')
        try:
            try:
                os.link(src, temporary)
            except OSError:
                shutil.copy2(src, temporary)
            os.replace(temporary, dest)
        finally:
            temporary.unlink(missing_ok=True)
        return dest
    except Exception as e:                               # a copy for convenience: never break the edit
        util.log(f"my-videos copy: {e}")
        return None


def focused() -> str:
    """The video open on the Studio screen (or the newest one)."""
    f = util.read_json(util.STUDIO_OUT / "focus.json", default={})
    pid = f.get("project", "")
    if pid and (util.PROJECTS / pid / "project.json").exists():
        return pid
    vids = sorted(_studio_projects(), key=lambda p: p.stat().st_mtime, reverse=True)
    return vids[0].parent.name if vids else ""


def _studio_projects() -> list:
    """project.json of every Studio video, whatever its folder is called."""
    out = []
    for f in util.PROJECTS.glob("*/project.json"):
        if f.parent.name.startswith("_"):
            continue
        if util.read_json(f, default={}).get("studio"):
            out.append(f)
    return out


def start_preparation(pid: str) -> dict:
    """Start deterministic local footage work, never a second AI chat or generic edit."""
    from . import jobs, workflow
    with _lock:
        cfg = load(pid)
        if not any(m.get('kind') == 'raw' for m in cfg.get('media', [])):
            raise util.Fail('Add your raw footage first.')
        active = jobs.find('footage-preparation', pid, states=('queued','waiting','running'))
        if active:
            return {'ok': True, 'job': active, 'already_started': True}
        if cfg.get('preparation', {}).get('state') == 'ready':
            return {'ok': True, 'already_prepared': True}
        if cfg.get('status') not in ('draft','preparation_error','awaiting_editor'):
            raise util.Fail('This video already has editing work. Continue in the chat beside Studio.')
        if workflow.state(_dir(pid)).get('owner'):
            raise util.Fail('This project is already assigned to an editor. Continue in the chat beside Studio.')
        update(pid, lambda c: c.update(status='preparing', preparation={'state':'running','started':time.time()}))
        def work(jid):
            try:
                jobs.update(jid, message='Preparing your footage. Reference analysis continues separately.')
                jobs.engine(jid, ['prepare', pid])
                update(pid, lambda c: c.update(status='awaiting_editor', preparation={**c.get('preparation',{}),'state':'ready','finished':time.time()}))
                return {'project':pid,'next':'Continue in the native chat; no second AI was started.'}
            except Exception:
                update(pid, lambda c: c.update(status='preparation_error', preparation={**c.get('preparation',{}),'state':'error','updated':time.time()}))
                raise
        # Reference analysis uses the heavy-job lock; independent preparation must not wait on it.
        job = jobs.submit('footage-preparation', work, key=pid, label='Preparing your footage', heavy=False)
        return {'ok':True,'job':job}


def begin(pid: str) -> dict:
    """The creator asked for the edit (in the chat): the Studio shows the progress screen; the reference is applied."""
    cfg = load(pid)
    if not any(m["kind"] == "raw" for m in cfg.get("media", [])):
        raise util.Fail("There's no footage in this video yet.", "Drop your raw video into Footage in the Studio first.")
    from . import refs
    pending = refs.apply_to_video(pid)
    update(pid, lambda c: c.update(status="queued" if c.get("status") == "draft" else c.get("status"), generated_at=time.time()))
    util.activity(f"Starting {cfg.get('title') or pid}")
    return {"title": cfg.get("title") or pid, "reference_pending": pending}


def context_text(project=None) -> str:
    """Everything in the Studio, for the agent (plain text)."""
    from . import refs
    lines = []
    prof = util.load_profile()
    if prof.get("website"):
        w = prof["website"]
        lines.append(f"Website: {w.get('url') if isinstance(w, dict) else w}" + ("" if (isinstance(w, dict) and w.get("read")) else " (not read yet: read it and save what matters in the profile memory)"))
    if project:load(project)
    foc = project or focused()
    vids = [f.parent.name for f in sorted(_studio_projects(), key=lambda f: f.stat().st_mtime, reverse=True)]
    if not vids:
        return "\n".join(lines + ["No videos yet. The creator drops footage in the Studio (New video)."])
    for pid in ([project] if project else [foc] + [v for v in vids if v != foc]):
        if not pid:
            continue
        c = load(pid)
        head = ("ON SCREEN: " if pid == foc else "") + f"{pid} \"{c.get('title') or 'Untitled video'}\" status={c.get('status')} style={c.get('style')}"
        lines.append(head)
        from . import workflow
        wf = workflow.state(util.PROJECTS / pid)
        if wf:
            lines.append(f"  workflow: {wf.get('phase')} — {wf.get('message', '')}; owner={wf.get('owner','')}")
        if pid != foc:
            continue
        for m in c.get("media", []):
            lab = (f" shows: {m['label']}" if m.get("label") else " (not labelled yet)") if m["kind"] in ("broll", "image") else ""
            lines.append(f"  {m['kind']}: {m['name']} id={m['id']}" + (f" {m.get('duration')}s" if m.get("duration") else "") + lab)
        for rr in refs.for_project(pid):
            lines.append(f"  reference: {rr.get('title') or rr.get('name') or rr.get('id')} ({rr.get('id')}) status={rr.get('status')}")
            kj = util.read_json(util.PROJECTS / "_teach" / "_refs" / str(rr.get("id")) / "kit.json", default={})
            for w in kj.get("reference_warnings", []):
                lines.append(f"    ! tell the creator: {w}")
        if not refs.for_project(pid):
            lines.append("  reference: none (uses the preset " + str(c.get("style")) + ")")
        if (c.get("brief") or {}).get("prompt"):
            lines.append(f"  brief: {c['brief']['prompt']}")
        from . import library,annotations
        selection=library.choices(util.PROJECTS/pid)
        if selection.get('look') or selection.get('caption') or selection.get('effects'):
            lines.append('  executable style choices: '+__import__('json').dumps(selection,ensure_ascii=False))
            lines.append('  Read selected-library.json after workflow init; execute pinned code via kit/tools/style-library.py.')
        notes=annotations.read(pid).get('notes',[])
        pending=[n for n in notes if n.get('status')!='ready']
        if pending:
            lines.append('  timeline notes: '+__import__('json').dumps([{k:n.get(k) for k in ('id','version','start','end','text','scope','status')} for n in pending],ensure_ascii=False))
            lines.append('  Read annotations.json and inspect that exact saved version before applying feedback.')
        vs = versions(pid)
        if vs:
            lines.append(f"  versions: " + ", ".join(f"v{v['n']} ({v.get('note', '')[:40]})" for v in vs))
        lines.append(f"  folder: my-videos/{c.get('shelf') or '(made on the first version)'}")
    return "\n".join(lines)


def restore_version(pid: str, n: int) -> None:
    d = _dir(pid)
    v = next((x for x in versions(pid) if x["n"] == int(n)), None)
    if not v:
        raise util.Fail("That version doesn't exist.")
    with util.project_lock(d):
        tmp = d / 'preview.partial.mp4'
        shutil.copy2(util.ROOT / v['file'], tmp)
        tmp.replace(d/'preview.mp4')
        update(pid, lambda c: c.update(selected_version=n, status='previewed'))
        from . import workflow
        workflow.state(d, 'ready', f'Showing saved version {n}; ask the editor to make any changes.', lease_until=0)


# ----------------------------------------------------------- multi-clip ----
def prepare(pid: str) -> dict:
    d=_dir(pid)
    with util.file_guard(d/'.prepare.guard','Your footage is already being prepared.',timeout=120):
        return _prepare_locked(pid)


def _prepare_locked(pid: str) -> dict:
    """Turn the raw clips in the media bin into one source video (in order) and write source.json."""
    d = _dir(pid)
    cfg = load(pid)
    raws = [m for m in cfg.get("media", []) if m["kind"] == "raw"]
    if not raws:
        raise util.Fail("Add your raw footage first.", "Drop a video of you talking into the Footage area.")
    files = [util.ROOT / m["file"] for m in raws]
    from . import artifact_cache as cache, cut as cutmod
    expected=cache.key('prepare-source-v1',files,{},[Path(__file__),Path(cutmod.__file__)])
    manifest=d/'prepare-cache.json'
    if cache.hit(manifest,expected):
        util.step('Reusing your unchanged prepared footage')
        return util.read_json(d/'source.json')
    if len(files) == 1:
        src = files[0]
    else:
        util.step(f"Joining {len(files)} clips into one…")
        first = util.probe(files[0])
        w, h = first["width"] - first["width"] % 2, first["height"] - first["height"] % 2
        inputs, parts = [], []
        any_hdr = False
        duration = 0
        from . import cut as cutmod
        for i, f in enumerate(files):
            inputs += ["-i", str(f)]
            info = util.probe(f)
            duration += info['duration']
            any_hdr = any_hdr or info.get('hdr', False)
            tm = cutmod.tonemap_filter(info)
            parts.append(f"[{i}:v]{tm}scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,"
                         f"setsar=1,fps=30,format=yuv420p,setpts=PTS-STARTPTS[v{i}]")
            if info["has_audio"]:
                parts.append(f"[{i}:a]aresample=48000,aformat=channel_layouts=stereo,asetpts=PTS-STARTPTS[a{i}]")
            else:
                parts.append(f"anullsrc=r=48000:cl=stereo,atrim=duration={info['duration']:.3f}[a{i}]")
        parts.append("".join(f"[v{i}][a{i}]" for i in range(len(files))) + f"concat=n={len(files)}:v=1:a=1[v][a]")
        src = d / "media" / "joined.mp4"
        partial = src.with_name('joined.'+__import__('uuid').uuid4().hex+'.partial.mp4')
        try:
            util.run_progress([util.ffmpeg_bin(), "-nostdin", "-y", "-hide_banner", *inputs, "-filter_complex", ";".join(parts),
                  "-map", "[v]", "-map", "[a]", "-c:v", "libx264", "-preset", "veryfast", "-crf", "16",
                  "-c:a", "aac", "-b:a", "256k", *(['-color_trc','bt709','-color_primaries','bt709','-colorspace','bt709'] if any_hdr else []), str(partial)], duration, label="Clips joined", detail='Joining your clips')
            partial.replace(src)
        finally:
            partial.unlink(missing_ok=True)
    info = util.probe(src)
    info["inputs"] = [str(f.resolve()) for f in files]
    util.write_json(d / "source.json", info)
    focus = face_focus(src, info) if info["width"] > info["height"] * 0.9 else None

    def fn(c):
        c["source"] = src.name
        if c.get('status') in (None,'new','preparing'):c['status']='new'
        if focus:
            framing=c.setdefault('framing',{})
            framing['auto_face']={'x':focus[0],'y':focus[1]}
            # The renderer consumes auto_face only when no manual position is set.
    update(pid, fn)
    if cache.key('prepare-source-v1',files,{},[Path(__file__),Path(cutmod.__file__)])!=expected:raise util.Fail('The original clips changed during preparation. Retry with the saved clips.')
    cache.commit(manifest,expected,[d/'source.json']+([src] if len(files)>1 else []))
    return info


def face_focus(src: Path, info: dict) -> tuple[float, float] | None:
    """Where the speaker's face usually is (0–1 across, 0–1 down), from 8 frames."""
    try:
        import cv2
        import numpy as np
        cap = cv2.VideoCapture(str(src))
        n = cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0
        face = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
        xs, ys = [], []
        for k in range(8):
            cap.set(cv2.CAP_PROP_POS_FRAMES, int(n * (k + 0.5) / 8))
            ok, fr = cap.read()
            if not ok:
                continue
            g = cv2.cvtColor(cv2.resize(fr, (480, int(fr.shape[0] * 480 / fr.shape[1]))), cv2.COLOR_BGR2GRAY)
            fs = face.detectMultiScale(g, 1.15, 5, minSize=(30, 30))
            if len(fs):
                x, y, w, h = max(fs, key=lambda f: f[2] * f[3])
                xs.append((x + w / 2) / g.shape[1])
                ys.append((y + h / 2) / g.shape[0])
        cap.release()
        if len(xs) >= 3:
            return round(float(np.median(xs)), 3), round(min(0.6, max(0.3, float(np.median(ys)))), 3)
    except Exception as e:
        util.log(f"face focus: {e}")
    return None


def updates(limit: int = 30) -> list[dict]:
    """The Home "Updates" feed: what the editor did, in plain words."""
    out = []
    for e in reversed(events.since(0)):
        p, t = e.get("payload") or {}, e["type"]
        text = None
        if t == "agent.message":
            text = p.get("text")
        elif t == "render.done":
            text = "Saved to My videos."
        elif t == "version.ready":
            text = f"Version {p.get('n')} ready" + (f": {p['note']}" if p.get("note") else ".")
        elif t == "teach.ready" and not p.get("hidden"):
            text = f"Preset saved: {p.get('label')}."
        if p.get("project") and not (util.PROJECTS / str(p["project"]) / "project.json").exists():
            text = None                                   # that video was deleted
        if t == "teach.ready" and not (util.USER_STYLES_DIR / f"{p.get('style')}.json").exists():
            text = None                                   # that preset was deleted
        if t == "render.done" and not p.get("project"):
            text = None
        if text and any(o["text"] == str(text)[:240] and o.get("project") == p.get("project") for o in out):
            text = None                                   # the same update once (newest kept)
        if text:
            out.append({"id": e["id"], "time": e["time"], "text": str(text)[:240], "project": p.get("project"), "type": t,
                        "style": p.get("style") if t == "teach.ready" else None})
        if len(out) >= limit:
            break
    return out


TRASH = util.STUDIO_OUT / "trash"


def _unguarded_trash(pid: str) -> None:
    """Delete a video from the app: its project folder and its exports move to kit/studio-out/trash (recoverable).
    Originals the creator dropped in are copies, so nothing of theirs is lost."""
    import shutil as _sh
    import time as _t
    d = _dir(pid)
    dest = TRASH / f"{pid}-{_t.strftime('%Y%m%d-%H%M%S')}"
    dest.mkdir(parents=True, exist_ok=True)
    for f in util.FINISHED.glob(f"{pid}-*") if util.FINISHED.exists() else []:
        _sh.move(str(f), str(dest / f.name))
    _sh.move(str(d), str(dest / "project"))
    # the video's own (unlisted) reference style goes with it; saved presets are never touched
    sid = f"ref-{pid}"[:60]
    sj = util.USER_STYLES_DIR / f"{sid}.json"
    if sj.exists() and util.read_json(sj, default={}).get("hidden"):
        for f in (sj, util.USER_STYLES_DIR / f"{sid}.md", util.USER_STYLES_DIR / f"{sid}.frames",
                  util.ROOT / ".claude" / "skills" / f"preset-{sid}", util.ROOT / ".agents" / "skills" / f"preset-{sid}"):
            if f.exists():
                _sh.move(str(f), str(dest / f"style-{f.name}"))
    events.emit("video.deleted", {"project": pid})

# Bind guards after all functions are defined, avoiding module import cycles.
from .editor import protect_inputs as _protect_inputs
add_media = _protect_inputs(_unguarded_add_media)
remove_media = _protect_inputs(_unguarded_remove_media)
trash = _protect_inputs(_unguarded_trash)
