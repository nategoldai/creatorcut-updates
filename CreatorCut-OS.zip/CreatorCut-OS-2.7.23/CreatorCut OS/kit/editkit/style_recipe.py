"""One bounded, pinned effect recipe; safe timings and measurable clip suitability."""
import ast,json,math,re,time
from pathlib import Path
from . import util,library

def constants(file):
 result={}
 for node in ast.parse(Path(file).read_text()).body:
  if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
   try:result[node.targets[0].id]=ast.literal_eval(node.value)
   except (ValueError,TypeError):pass
 return result

def timing_defaults(slot,overrides=None):
 slot=Path(slot);clip=util.read_json(slot/'clip.json');n=int(clip['frames']);key=clip.get('key',slot.name.rsplit('-',1)[0]);base=constants(slot/'build.py');out={};overrides=overrides or {}
 doc=util.read_json(slot/'words.json',default={'words':[]});words=doc.get('words',[]) if isinstance(doc,dict) else doc
 onsets=[round(float(w.get('start',w.get('t',0)))*30) for w in words]
 if key=='frame-break':
  if n<72:raise util.Fail('Frame Break needs at least 2.4 seconds in one continuous shot. Loosen the cut here or choose another moment.')
  first=next((f for f in onsets if 23<=f<=n-47),min(45,n-47))
  out['F_IN']=first;out['F_OUT']=next((f for f in onsets if first+45<=f<=n-2),n-2)
 elif 'F_IN' in base and base['F_IN'] is None:
  out['F_IN']=next((f for f in onsets if 6<=f<n-20),min(12,max(0,n-21)))
 # Other recipes retain designed timings unless the slot explicitly supports auto.
 # Never rescale every numeric constant: those include gains, physics and data.
 if 'F_OUT' in base and base['F_OUT'] is None and key not in ('ui-world',):out.setdefault('F_OUT',max(1,n-2))
 out.update(transcript_content(key,words,base,overrides))
 out.update(overrides)
 if key=='frame-break' and (type(out.get('F_IN')) is not int or out['F_IN']<23 or type(out.get('F_OUT')) is not int or not out['F_IN']+45<=out['F_OUT']<=n-2):
  raise util.Fail('Frame Break needs F_IN at least 23, F_OUT at least 45 frames later and two frames before the end. Use a longer continuous moment.')
 return out

def transcript_content(key,words,base,overrides):
 """Use verbatim spoken fragments, not invented facts or decorative samples."""
 if not words:return {}
 chunks=[]
 for i in range(0,min(len(words),20),5):
  group=words[i:i+5];text=' '.join(str(w.get('w',w.get('text',''))) for w in group).strip()
  if text:chunks.append((text,round(float(group[0].get('start',0))*30),round(float(group[-1].get('end',group[-1].get('start',0)))*30)))
 out={}
 if key=='checklist' and len(chunks)>=2:
  out={'TITLE':chunks[0][0][:22],'ROWS':[(t,a,max(a+1,b)) for t,a,b in chunks[:4]],'F_DONE':min(round(float(words[-1].get('end',0))*30)-2,max(x[2] for x in chunks[:4])+10)}
 elif key=='freeze-and-label' and len(chunks)>=2:
  out={'LABELS':[(chunks[0][0],str(words[0].get('w',words[0].get('text',''))),'head'),(chunks[1][0],str(words[min(5,len(words)-1)].get('w',words[min(5,len(words)-1)].get('text',''))),'chest')]}
 elif key in ('prompt-box','serif-flow'):
  field='TEXT' if key=='prompt-box' else 'TITLE';out[field]=' '.join(str(w.get('w',w.get('text',''))) for w in words[:12])
 return {k:v for k,v in out.items() if k in base and k not in overrides}

def input_question(e):
 material=str(e.get('material',''))
 if not material or material.lower().startswith(('none','nothing needed')):return None
 return 'For '+e['name']+', please provide '+material+'. If you do not have it, I can finish this video without that effect.'

def protect_facts(p,e,parameters,evidence):
 # Inspect content fields, never geometry/timing numbers. Recipe defaults are not
 # customer evidence. Optional facts stay off unless explicitly supplied.
 required={'odometer':('COUNTERS',),'the-stack':('TITLE','CARDS'),'comment-bubble':('KEYWORD','REPLY_TEXT','CHIP_TEXT'),'knockout-tiles':('TILES',)}
 for key in required.get(e['key'],()):
  if key not in parameters:raise util.Fail('Please provide the real '+key.lower().replace('_',' ')+' for '+e['name']+'.','Use words or figures supplied in this video’s brief or spoken transcript. Example content cannot be published.')
 request=util.read_json(p/'active-edit-request.json',default={});cfg=util.read_json(p/'project.json',default={})
 prompt=str(request.get('settings',cfg).get('brief',{}).get('prompt',''))
 doc=util.read_json(p/'words.json',default={});words=doc.get('words',[]) if isinstance(doc,dict) else doc
 source=prompt+' '+' '.join(str(w.get('w',w.get('text',''))) for w in words)
 def verify(value):
  if value in (None,''):return
  text=str(value).casefold().replace(',','');hay=source.casefold().replace(',','')
  if text not in hay:raise util.Fail('Please supply the real wording or number for '+e['name']+': '+str(value)+'.','Add the exact words to this video’s brief. Never invent names, results or figures.')
 key=e['key']
 if key=='odometer':
  for counter in parameters.get('COUNTERS',[]):
   verify(counter.get('text'));verify(counter.get('say'))
   for row in counter.get('label',[]):verify(row[0])
 elif key=='the-stack':
  verify(parameters.get('TITLE'))
  for card in parameters.get('CARDS',[]):
   verify(card.get('title'));verify(card.get('sub'))
   for label,value in card.get('rows',[]):verify(label);verify(value)
 elif key=='comment-bubble':
  for field in required[key]:verify(parameters.get(field))
  if parameters.get('USER_NAME','you')!='you':verify(parameters['USER_NAME'])
 elif key=='knockout-tiles':
  for tile in parameters.get('TILES',[]):verify(tile.get('text'))
  if parameters.get('RECEIPTS_ON'):
   for field in ('RECEIPT_TITLE','RECEIPT_ITEM','RECEIPT_AMOUNT'):verify(parameters.get(field))
 for field in ('FIGURES','X_LABELS','COUNTS'):
  value=parameters.get(field)
  if value is not None:
   for item in value.values() if isinstance(value,dict) else value:verify(item)


def minimum_seconds(identifier,version=None):
 e=library.entry(identifier,version,True)
 return 2.4 if e['key']=='frame-break' else max(1.0,float(e.get('minimum_seconds',0)))

def continuous_spans(p,identifier,version=None):
 e=library.entry(identifier,version,True);duration=float(util.probe(p/'cut.mp4')['duration']);rows=util.read_json(p/'segments.json',default={}).get('segments',[])
 if not rows:rows=[{'start':0,'end':duration,'src_start':0,'src_end':duration}]
 spans=[]
 for row in rows:
  a=float(row['start']);b=float(row['end']);source=float(row.get('src_start',a));source_end=float(row.get('src_end',source+b-a))
  if spans and abs(source-spans[-1]['source_end'])<=1/30 and abs(a-spans[-1]['end'])<=1/30:
   spans[-1].update(end=b,source_end=source_end)
  else:spans.append({'start':a,'end':b,'source_start':source,'source_end':source_end})
 minimum=minimum_seconds(identifier,version)
 where=library.choices(p).get('placements',{}).get(identifier)
 if isinstance(where,dict):
  spans=[dict(row,start=max(row['start'],where['start']),end=min(row['end'],where['end'])) for row in spans if max(row['start'],where['start'])<min(row['end'],where['end'])]
 if e.get('segments')==2:
  # A cut effect needs the two actual neighbouring shots, not a continuous span.
  return [{'start':max(0,row['start']-.5),'end':min(duration,row['start']+.5),'crosses_cut':True} for row in spans[1:] if row['start']>=.5 and duration-row['start']>=.5]
 return [row for row in spans if row['end']-row['start']>=minimum]

def require_span(p,identifier,start,end,version=None):
 spans=continuous_spans(p,identifier,version)
 if not any(row['start']-1/30<=start<end<=row['end']+1/30 for row in spans):
  raise util.Fail('This effect does not fit that continuous shot. Loosen the cut around this moment or choose one of the listed spans.','Run style-library.py spans '+p.name+' '+identifier)
 return spans

def measure_shot(p,start,end):
 """Conservative measured shot size/background motion, never a guessed success."""
 import tempfile
 try:import cv2,numpy as np
 except ImportError:raise util.Fail('The frame tools are missing. Run setup again before applying this effect.')
 source=p/'cut.mp4';info=util.probe(source)
 if info['width']!=1080 or info['height']!=1920:raise util.Fail('This effect needs 1080 × 1920 footage. Choose a vertical platform and rebuild the cut first.')
 frames=[];face_ratios=[]
 work=p/'work';work.mkdir(parents=True,exist_ok=True)
 with tempfile.TemporaryDirectory(prefix='effect-measure-',dir=work) as td:
  detector=cv2.CascadeClassifier(str(Path(cv2.data.haarcascades)/'haarcascade_frontalface_default.xml'))
  for i,t in enumerate((start+(end-start)*.2,start+(end-start)*.5,start+(end-start)*.8)):
   frame=Path(td)/f'{i}.jpg';util.run([util.ffmpeg_bin(),'-nostdin','-v','error','-y','-ss',str(t),'-i',str(source),'-frames:v','1','-vf','scale=360:640',str(frame)],timeout=30)
   gray=cv2.imread(str(frame),cv2.IMREAD_GRAYSCALE)
   if gray is None:raise util.Fail('That video frame could not be read. Rebuild the cut, then choose this effect again.')
   if not detector.empty():
    faces=detector.detectMultiScale(gray,scaleFactor=1.1,minNeighbors=5,minSize=(25,25))
    if len(faces):face_ratios.append(max(float(h)/640 for x,y,w,h in faces))
   bg=gray.astype('float32');bg[:,90:270]=0;frames.append(bg)
 motion=[]
 for a,b in zip(frames,frames[1:]):
  shift,response=cv2.phaseCorrelate(a,b)
  if response>.15:motion.append(math.hypot(*shift)/360)
 shot=('close' if sorted(face_ratios)[len(face_ratios)//2]>.32 else 'medium' if sorted(face_ratios)[len(face_ratios)//2]>.12 else 'wide') if len(face_ratios)>=2 else 'unknown'
 if len(motion)<2 and all(float(np.std(f))<2 for f in frames):
  motion=[float(np.mean(np.abs(a-b)))/255 for a,b in zip(frames,frames[1:])]
 camera=('still' if max(motion)<.008 else 'drifting' if max(motion)<.05 else 'moving') if len(motion)==2 else 'unknown'
 from .workflow import digest
 return {'source_sha256':digest(source),'start':start,'end':end,'shot':shot,'camera':camera,'face_samples':len(face_ratios),'background_displacement':motion,'method':'3 measured frames; face height and background phase correlation; unknown never counts as a verified mismatch'}

def unsuitable_reason(p,identifier,start,end,parameters=None):
 parameters=parameters or {};key=identifier.split(':')[-1]
 if key=='blackout':
  selected=next((x for x in library.choices(p)['effects'] if x['id']==identifier),{});e=library.entry(identifier,selected.get('version'),True)
  defaults=constants(Path(e['_root'])/'effects/blackout/build.py');snap=parameters.get('F_SNAP',defaults.get('F_SNAP'));punch=parameters.get('F_PUNCH',defaults.get('F_PUNCH',70))
  if snap=='auto':
   cuts=util.read_json(p/'segments.json',default={}).get('segments',[])[1:]
   if not any(start+punch/30<float(row['start'])<end-14/30 for row in cuts):return 'Blackout needs a cut after the punch word, or an explicit return time. This moment has neither, so I am leaving Blackout out before building it.'
 if key=='vertigo':
  duration=float(util.probe(p/'cut.mp4').get('video_duration') or util.probe(p/'cut.mp4')['duration'])
  if start<.6 and duration-end<.6:return 'Vertigo needs some footage before or after this moment to rebuild the background. This span uses the whole clip, so I am leaving Vertigo out before building it.'
 return None

def _run(p,identifier,start,end,parameters,evidence):
 """Prep -> build -> real lint -> snapshot -> render -> check -> attach."""
 selected=next((x for x in library.choices(p)['effects'] if x['id']==identifier),None);version=selected.get('version') if selected else None
 reason=unsuitable_reason(p,identifier,start,end,parameters)
 if reason:return record_omission(p,identifier,'unsuitable_moment',version,parameters=parameters,start=start,end=end)
 limit=library.launch_limit(identifier)
 if limit and end-start>limit+1e-6:raise util.Fail('Frame Break is available for up to 3 seconds. Choose a shorter moment; your saved choices are kept.')
 require_span(p,identifier,start,end,version)
 measured=measure_shot(p,start,end);e=library.entry(identifier,version,True);evidence=dict(evidence,measured=measured)
 for field in ('shot','camera'):
  actual=measured[field]
  if actual!='unknown':
   if e.get(field) and actual not in e[field]:raise util.Fail(e['name']+' needs a different '+field+'. This moment measured '+actual+'. Choose another moment or effect.')
   evidence[field]=actual
 candidate=p/'work/style-library/fx'/(e['key']+'-'+str(round(start*30)))
 if candidate.is_dir():
  receipt=library.verify_slot(candidate)
  if receipt.get('id')!=identifier or receipt.get('version')!=e['version'] or receipt.get('start')!=start or receipt.get('end')!=end or receipt.get('parameters')!=json.loads(json.dumps(parameters)) or receipt.get('source')!=util.read_json(p/'work/style-library/source.json'):raise util.Fail('This effect slot has different saved inputs. Choose a new moment or restore its exact settings before resuming.')
  slot=candidate
 else:slot=library.new_slot(p,identifier,start,end,parameters,evidence)
 recipe=util.read_json(slot/'slot.json',default={});current='prep'
 try:
  common=['CAPTIONS=0'] if isinstance(library.choices(p).get('caption'),dict) or library.choices(p).get('caption')=='none' else []
  times=','.join(f'{x:.3f}' for x in (0,(end-start)*.25,(end-start)*.5,(end-start)*.75,max(0,end-start-1/30)))
  linted=False;snapshot=False;rendered=False
  from .workflow import digest
  def inventory():return {str(f.relative_to(slot)):digest(f) for f in slot.rglob('*') if f.is_file() and f.name!='recipe-checkpoint.json' and '__pycache__' not in f.parts}
  checkpoint=util.read_json(slot/'recipe-checkpoint.json',default={})
  completed=int(checkpoint.get('completed',0)) if checkpoint.get('files')==inventory() else 0
  # Follow each pack's order: several effects build their plan before bake.py.
  # Optional preview bakes are omitted; full bake/check/snapshot always remain.
  for step_index,line in enumerate(recipe.get('steps',[])):
   if step_index<completed:
    linted=linted or line.strip().startswith('hf lint');snapshot=snapshot or line.strip().startswith('hf snapshot');rendered=rendered or line.strip().startswith('hf render');continue
   command=line.split('#',1)[0].strip()
   match=re.match(r'run\s+([a-zA-Z0-9_-]+\.py)(.*)',command)
   if match:
    script,tail=match.groups()
    if script=='onsets.py' or '--frames' in tail or '--sheet' in tail or tail.strip()=='frames':continue
    if not (slot/script).is_file():raise util.Fail('This recipe is missing '+script+'. Restore this pinned effect before retrying.')
    switches=re.findall(r'\b[A-Z][A-Z0-9_]*=[^\s]+',tail)
    switches=[word for word in switches if not word.startswith('SAFE=')]+['SAFE=0']
    current=script;library.run_script(p,'fx_run.py',[slot,script,*switches,*common],timeout=1200)
   elif command.startswith('hf lint'):
    current='lint';library.run_script(p,'fx_run.py',[slot,'hf','lint'],timeout=120);linted=True
   elif command.startswith('hf snapshot'):
    current='snapshot';library.run_script(p,'fx_run.py',[slot,'hf','snapshot','--at',times],timeout=300);snapshot=True
   elif command.startswith('hf render'):
    if not linted:
     current='lint';library.run_script(p,'fx_run.py',[slot,'hf','lint'],timeout=120);linted=True
    if not snapshot:
     current='snapshot';library.run_script(p,'fx_run.py',[slot,'hf','snapshot','--at',times],timeout=300);snapshot=True
    current='render';extra=['--video-frame-format','png'] if '--video-frame-format png' in command else []
    library.run_script(p,'fx_run.py',[slot,'hf','render',*extra],timeout=max(600,(end-start)*90));rendered=True
   util.write_json(slot/'recipe-checkpoint.json',{'completed':step_index+1,'files':inventory()})
  if not rendered:raise util.Fail('This effect recipe has no render step. Use its documented recipe before attaching it.')
  current='attach';return library.attach_slot(p,slot)
 except util.Fail as error:
  if current=='check.py':
   # A failed quality check writes its contact sheet. Keep that evidence without
   # invalidating the already-completed render; never mark the failed check done.
   checkpoint=util.read_json(slot/'recipe-checkpoint.json',default={})
   if checkpoint:util.write_json(slot/'recipe-checkpoint.json',dict(checkpoint,files=inventory()))
   failures=util.read_json(p/'effect-check-failures.json',default={});failures[identifier]={'version':e['version'],'source_sha256':digest(p/'cut.mp4'),'error':error.message,'request_id':util.read_json(p/'active-edit-request.json',default={}).get('id'),'slot':str(slot.relative_to(p))};util.write_json(p/'effect-check-failures.json',failures)
   return record_omission(p,identifier,'failed_effect_check',e['version'])
  raise util.Fail(library.entry(identifier,version)['name']+' paused at '+current+'. '+error.message,'Your video is saved. Fix the named input or choose another suitable moment, then run this recipe again.') from error


def omission_check(p,identifier,reason,version=None):
 e=library.entry(identifier,version,True)
 if e['kind']!='effect':return False
 if reason=='unsuitable_moment':
  receipt=util.read_json(p/'effect-omissions.json',default={}).get(identifier,{})
  span=receipt.get('span',{})
  return bool(span and unsuitable_reason(p,identifier,span.get('start',0),span.get('end',0),receipt.get('parameters',{})))
 if reason=='failed_effect_check':
  from .workflow import digest
  failure=util.read_json(p/'effect-check-failures.json',default={}).get(identifier,{})
  return bool(failure.get('version')==e['version'] and failure.get('source_sha256')==digest(p/'cut.mp4') and failure.get('error') and failure.get('request_id')==util.read_json(p/'active-edit-request.json',default={}).get('id') and (p/failure.get('slot','')/'creatorcut-receipt.json').is_file())
 if reason=='no_continuous_span':return not continuous_spans(p,identifier,version)
 if reason=='unsupported_frame':
  info=util.probe(p/'cut.mp4');return (info['width'],info['height'])!=(1080,1920)
 if reason=='missing_customer_material':
  material=str(e.get('material','')).lower();cfg=util.read_json(p/'project.json',default={})
  has_files=any(m.get('kind') in ('broll','image') for m in cfg.get('media',[]))
  direct=any(f.is_file() and f.suffix.lower() in ('.jpg','.jpeg','.png','.webp','.mov','.mp4','.webm') for base in (p/'work',p/'assets',p/'media') if base.is_dir() for f in base.rglob('*'))
  if any(k in material for k in ('folder','recording','picture','b-roll','video')) and not has_files and not direct:return True
  if e['key'] in ('odometer','the-stack'):
   doc=util.read_json(p/'words.json',default={});words=doc.get('words',[]) if isinstance(doc,dict) else doc
   text=cfg.get('brief',{}).get('prompt','')+' '+' '.join(str(w.get('w',w.get('text',''))) for w in words)
   return not re.search(r'\d|\b(one|two|three|four|five|six|seven|eight|nine|ten|hundred|thousand|million)\b',text,re.I)
 return False

def verify_omission(p,item,row):
 from .workflow import digest
 receipt=util.read_json(p/'effect-omissions.json',default={}).get(item['id'],{})
 return bool(receipt and row.get('notice')==receipt.get('notice') and receipt.get('version')==item['version'] and receipt.get('source_sha256')==digest(p/'cut.mp4') and omission_check(p,item['id'],receipt.get('reason'),item['version']))

def record_omission(p,identifier,reason,version=None,parameters=None,start=None,end=None):
 from .workflow import digest
 e=library.entry(identifier,version,True)
 if reason=='unsuitable_moment':
  if not unsuitable_reason(p,identifier,start,end,parameters):raise util.Fail('This moment has not been verified unsuitable.')
 elif not omission_check(p,identifier,reason,e['version']):raise util.Fail('This effect could still fit this video. Choose a supported moment; it cannot be skipped with that reason.')
 reasons={'unsuitable_moment':'this moment does not contain the footage it needs','failed_effect_check':'its rendered frames failed the effect’s quality check','no_continuous_span':'there is no long enough continuous shot','unsupported_frame':'this video is not vertical 1080 × 1920','missing_customer_material':'its required personal material was not supplied'}
 notice='I left '+e['name']+' out because '+reasons[reason]+'. The rest of your video is being finished.'
 if reason=='unsuitable_moment':notice=unsuitable_reason(p,identifier,start,end,parameters)+' The rest of your edit can continue.'
 if reason=='failed_effect_check':notice+=' '+util.read_json(p/'effect-check-failures.json')[identifier]['error']+' Next: inspect the saved effect contact sheet, correct the named problem, rerun its check and attach it only after it passes.'
 receipts=util.read_json(p/'effect-omissions.json',default={});receipts[identifier]={'version':e['version'],'reason':reason,'source_sha256':digest(p/'cut.mp4'),'notice':notice,'span':{'start':start,'end':end} if start is not None else None,'parameters':parameters or {}};util.write_json(p/'effect-omissions.json',receipts)
 plan=util.read_json(p/'edit-plan.json')
 pack=p/'work/style-library/plan.json';removed=[]
 if pack.is_file():
  pack_plan=util.read_json(pack);removed=[row.get('slot') for row in pack_plan.get('slots',[]) if row.get('key')==e['key']];pack_plan['slots']=[row for row in pack_plan.get('slots',[]) if row.get('key')!=e['key']];util.write_json(pack,pack_plan)
 plan['items']=[row for row in plan.get('items',[]) if row.get('id') not in ['library-'+name for name in removed if name]]
 if plan.get('audio'):plan['audio']['events']=[row for row in plan['audio'].get('events',[]) if row.get('library_slot') not in removed]
 plan['library_application']=[x for x in plan.get('library_application',[]) if x.get('id')!=identifier]+[{'id':identifier,'version':e['version'],'status':'unsuitable','reason':reason,'notice':notice}];util.write_json(p/'edit-plan.json',plan)
 util.say(notice)
 from . import events
 events.emit('library.notice',{'project':p.name,'message':notice},source='engine')
 return {'omitted':True,'id':identifier,'message':notice}

def run(p,identifier,start,end,parameters,evidence):
 try:return _run(p,identifier,start,end,parameters,evidence)
 except util.Fail:
  selected=next((x for x in library.choices(p)['effects'] if x['id']==identifier),{})
  for reason in ('unsupported_frame','no_continuous_span','missing_customer_material'):
   if omission_check(p,identifier,reason,selected.get('version')):return record_omission(p,identifier,reason,selected.get('version'))
  raise
