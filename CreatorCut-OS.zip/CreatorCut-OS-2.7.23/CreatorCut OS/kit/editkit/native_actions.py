"""A rendezvous with an active tool in the current conversation.

No inference, persistent queue, subprocess editor, or simulated replies. An action
is accepted only while a real foreground tool is waiting to receive it. Delivery
and an editor claiming a project are deliberately different acknowledgements.
"""
from __future__ import annotations

import secrets
import json
import os
import tempfile
import threading
import time
from collections import OrderedDict

from . import util,deadlines


class Rendezvous:
    def __init__(self):
        self.condition = threading.Condition()
        self.receiver = None
        self.action = None
        self.receipts = OrderedDict()
        self.bound_receiver=None
        self.last_seen=None

    def status(self):
        with self.condition:
            return {"available": bool(self.receiver and deadlines.remaining(self.receiver[1]) > 0 and self.action is None),
                    "connected":deadlines.remaining(self.last_seen)>0 if self.last_seen else False,
                    "transport": "foreground_native_tool"}

    def receive(self, receiver: str, timeout: float = 25, take=None):
        if not receiver or len(receiver) > 160:
            raise util.Fail("A conversation-bound receiver is required.")
        timeout = min(25, max(0.05, float(timeout)))
        with self.condition:
            now=time.monotonic()
            if self.bound_receiver and self.bound_receiver[0]!=receiver and deadlines.remaining(self.bound_receiver[1])>0:
                raise util.Fail('Another CreatorCut chat is listening for this installation.')
            self.bound_receiver=(receiver,deadlines.after(110))
            self.last_seen=deadlines.after(110)
            if self.action and self.action.get('receiver') and deadlines.remaining(self.action.get('_ack_deadline',deadlines.after(8)))<=0:
                self.action['state']='unconfirmed';self.action=None
            if self.receiver:
                raise util.Fail("A conversation is already receiving Studio actions.")
            if self.action is not None and self.action.get("receiver"):
                # receive() returns before its consumer sends the acknowledgement.
                # A second tool must not steal or receive that action again in
                # this gap, even when it has the same conversation id.
                raise util.Fail("An editing action is already being delivered.")
            deadline = deadlines.after(timeout)
            self.receiver = (receiver, deadline)
            try:
                while self.action is None:
                    if take:
                        action=take(receiver)
                        if action:
                            self.action=action;self.receipts[action['request_id']]=action
                            while len(self.receipts)>128:self.receipts.popitem(last=False)
                            break
                    remaining = deadlines.remaining(deadline)
                    if remaining <= 0:
                        return {"action": None}
                    self.condition.wait(remaining)
                action = self.action
                action["receiver"] = receiver
                action["_received_at"] = time.monotonic()
                action["_ack_deadline"] = deadlines.after(8)
                return {"action": dict(action)}
            finally:
                self.receiver = None
                self.condition.notify_all()

    def dispatch(self, request_id: str, project: str, text: str, timeout: float = 8):
        if not request_id or len(request_id) > 128 or not project or not text.strip() or len(text) > 24000:
            raise util.Fail("An editing request needs its project, instructions and request ID.")
        with self.condition:
            old = self.receipts.get(request_id)
            if old:
                if old["project"] != project or old["text"] != text:
                    raise util.Fail("That request ID was already used for different instructions.")
                return self._receipt(old)
            if not self.status()["available"]:
                raise util.Fail("The live editing connection is not ready. Your instructions are saved.")
            action = {"request_id": request_id, "project": project, "text": text,
                      "state": "delivering", "time": time.time()}
            self.receipts[request_id] = action
            while len(self.receipts) > 128:
                self.receipts.popitem(last=False)
            self.action = action
            self.condition.notify_all()
            deadline = deadlines.after(min(8, max(0.05, float(timeout))))
            while action["state"] == "delivering":
                remaining = deadlines.remaining(deadline)
                if remaining <= 0:
                    action["state"] = "unconfirmed"
                    if self.action is action:
                        self.action = None
                    break
                self.condition.wait(remaining)
            return self._receipt(action)

    def acknowledge(self, receiver: str, request_id: str):
        with self.condition:
            action = self.receipts.get(request_id)
            if not action or action.get("receiver") != receiver:
                raise util.Fail("This action does not belong to this conversation receiver.")
            action["state"] = "delivered"
            if self.action is action:
                self.action = None
            self.condition.notify_all()
            return self._receipt(action)

    @staticmethod
    def _receipt(action):
        return {"accepted": action["state"] == "delivered", "state": action["state"],
                "request_id": action["request_id"], "project": action["project"]}


BROKER = Rendezvous()
AGENT_KEY = secrets.token_urlsafe(32)


def write_agent_key(server_token):
    path = util.STUDIO_OUT / "native-agent.json"
    # This file is never in Studio's public static/media allowlists.
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.native-agent-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w') as stream:
            json.dump({"key": AGENT_KEY, "api_token": server_token}, stream)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def authorized(given):
    return bool(given) and secrets.compare_digest(str(given), AGENT_KEY)


def dispatch_persisted(request_id, project, text):
    """Persist delivery identity before handoff so a server restart cannot silently replay it."""
    import hashlib
    from . import videos
    videos.load(project)
    if not request_id or len(request_id)>128 or not text.strip() or len(text)>24000:
        raise util.Fail('An editing request needs its project, instructions and request ID.')
    p=videos._dir(project);file=p/'.native-deliveries.json';digest=hashlib.sha256(text.encode()).hexdigest()
    with util.file_guard(p/'.native-deliveries.guard','Another editing request is being delivered.'):
        data=util.read_json(file,default={});prior=data.get(request_id)
        if prior:
            if prior.get('digest')!=digest:raise util.Fail('That request identifier belongs to different instructions.')
            return {'request_id':request_id,'project':project,'accepted':prior.get('accepted') is True,'state':'delivered' if prior.get('accepted') else 'unconfirmed'}
        if not BROKER.status()['available']:
            raise util.Fail('The live editing connection is not ready. Your instructions are saved.')
        data[request_id]={'digest':digest,'state':'unconfirmed','accepted':False,'time':time.time()}
        util.write_json(file,data)
        try:
            result=BROKER.dispatch(request_id,project,text)
        except util.Fail:
            # Validation/receiver loss happens before a new action is emitted.
            data.pop(request_id,None);util.write_json(file,data);raise
        # An unexpected interruption keeps the unconfirmed marker. Never retry it blindly.
        data[request_id].update(accepted=result.get('accepted') is True,state=result.get('state','unconfirmed'))
        util.write_json(file,data)
        return result
