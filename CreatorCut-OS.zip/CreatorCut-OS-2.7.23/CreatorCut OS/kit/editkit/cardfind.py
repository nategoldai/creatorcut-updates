"""Find the cards (images, clips, text boxes) a reference puts on top of its footage, precisely.

A card is a flat rectangle laid over the footage: four straight edges that aren't in the clean background (the
footage without anything on top: the per-pixel median of the shots that share a camera) and a body that differs from
it. Every frame is searched for such rectangles; one that stays put for a while is a card. For each card: its box
(centre, size, top edge, as fractions of the frame), when it's on screen, and how it enters and leaves (cut, slide
up / down / in from a side, pop) — plus the reference's typical layout, which placement copies."""
from __future__ import annotations

from pathlib import Path

from . import util

SW = 270                      # analysis width: 1 px ≈ 0.4% of the frame


def _load(frames: list[Path]):
    import numpy as np
    from PIL import Image
    out = []
    for f in frames:
        im = Image.open(f).convert("RGB")
        out.append(np.asarray(im.resize((SW, int(im.height * SW / im.width)))).astype(np.float32))
    return np.stack(out) if out else None


def _grads(a):
    import cv2
    return (abs(cv2.Sobel(a, cv2.CV_32F, 1, 0, ksize=3)).max(-1), abs(cv2.Sobel(a, cv2.CV_32F, 0, 1, ksize=3)).max(-1))


def _runs(row, minlen: int, gap: int = 3):
    import numpy as np
    idx = np.flatnonzero(row)
    if not len(idx):
        return []
    br = np.flatnonzero(np.diff(idx) > gap + 1)
    st, en = np.r_[idx[0], idx[br + 1]], np.r_[idx[br], idx[-1]]
    return [(int(s), int(e)) for s, e in zip(st, en) if e - s + 1 >= minlen]


def _backgrounds(g, cuts_i: list[int]):
    """A clean background per frame: the median of every shot filmed from the same spot (a card is a minority there)."""
    import numpy as np
    bounds = [0] + [c for c in cuts_i if 0 < c < len(g)] + [len(g)]
    shots = [(a, b) for a, b in zip(bounds, bounds[1:]) if b > a]
    meds = [np.median(g[a:b:max(1, (b - a) // 40)], 0) for a, b in shots]
    groups: list[list[int]] = [[0]]
    for k in range(1, len(shots)):
        if float(np.median(abs(meds[k] - meds[groups[-1][-1]]).max(-1))) < 10:
            groups[-1].append(k)
        else:
            groups.append([k])
    bg = [None] * len(g)
    for grp in groups:
        idx = [i for k in grp for i in range(*shots[k])]
        m = np.median(g[idx[::max(1, len(idx) // 120)]], 0)
        for i in idx:
            bg[i] = m
    return bg


def rects(a, bg, bgx=None, bgy=None) -> list[tuple]:
    """Card-like rectangles in one frame: [(x0, y0, w, h, score)] as fractions, best first, no duplicates."""
    import cv2
    import numpy as np
    H, W = a.shape[:2]
    if bgx is None:
        bgx, bgy = _grads(bg)
    gx, gy = _grads(a)
    diff = abs(a - bg).max(-1) > 18
    eh = (gy > 30) & (gy > bgy * 1.5 + 10)
    ev = (gx > 30) & (gx > bgx * 1.5 + 10)
    ehd = cv2.dilate(eh.astype(np.uint8), np.ones((3, 1), np.uint8)).astype(np.float32)
    evd = cv2.dilate(ev.astype(np.uint8), np.ones((1, 3), np.uint8)).astype(np.float32)
    ch = np.c_[np.zeros(H), np.cumsum(ehd, 1)]
    cv = np.r_[np.zeros((1, W)), np.cumsum(evd, 0)]
    cd = np.pad(np.cumsum(np.cumsum(diff.astype(np.float32), 0), 1), ((1, 0), (1, 0)))
    hcov = lambda y, x0, x1: (ch[y, x1 + 1] - ch[y, x0]) / (x1 - x0 + 1)
    vcov = lambda x, y0, y1: (cv[y1 + 1, x] - cv[y0, x]) / (y1 - y0 + 1)
    fill = lambda x0, x1, y0, y1: (cd[y1, x1] - cd[y0, x1] - cd[y1, x0] + cd[y0, x0]) / max(1, (x1 - x0) * (y1 - y0))
    hs = [(y, x0, x1) for y in range(1, H - 1) for x0, x1 in _runs(eh[y], int(0.12 * W))]
    vs = [(x, y0, y1) for x in range(1, W - 1) for y0, y1 in _runs(ev[:, x], int(0.06 * H))]
    tol = 0.04 * W
    cands = set()
    for yt, a0, a1 in hs:                            # a top and a bottom edge that line up on one side at least
        for yb, b0, b1 in hs:
            if yb - yt >= 0.06 * H and (abs(a0 - b0) < tol or abs(a1 - b1) < tol):
                cands.add((min(a0, b0) if abs(a0 - b0) < tol else a0, max(a1, b1) if abs(a1 - b1) < tol else a1, yt, yb))
    for xl, a0, a1 in vs:                            # a left and a right edge side by side
        for xr, b0, b1 in vs:
            if xr - xl >= 0.12 * W and min(a1, b1) - max(a0, b0) > 0.5 * min(a1 - a0, b1 - b0):
                cands.add((xl, xr, min(a0, b0), max(a1, b1)))
    found = []
    for x0, x1, yt, yb in cands:
        for _ in range(2):                           # snap each side onto its strongest edge nearby
            yt = max(range(max(0, yt - 2), min(H, yt + 3)), key=lambda y: hcov(y, x0, x1))
            yb = max(range(max(0, yb - 2), min(H, yb + 3)), key=lambda y: hcov(y, x0, x1))
            x0 = max(range(max(0, x0 - 2), min(W, x0 + 3)), key=lambda x: vcov(x, yt, yb))
            x1 = max(range(max(0, x1 - 2), min(W, x1 + 3)), key=lambda x: vcov(x, yt, yb))
        if x1 - x0 < 0.14 * W or yb - yt < 0.06 * H:
            continue
        c = sorted((hcov(yt, x0, x1), hcov(yb, x0, x1), vcov(x0, yt, yb), vcov(x1, yt, yb)))
        if c[1] < 0.45 or sum(c) < 2.6 or fill(x0, x1, yt, yb) < 0.6:   # a solid body, not an outline of the person
            continue
        cols = (cd[yb, x0 + 2:x1 - 1] - cd[yt, x0 + 2:x1 - 1] - cd[yb, x0 + 1:x1 - 2] + cd[yt, x0 + 1:x1 - 2]) / (yb - yt)
        rows = (cd[yt + 2:yb - 1, x1] - cd[yt + 2:yb - 1, x0] - cd[yt + 1:yb - 2, x1] + cd[yt + 1:yb - 2, x0]) / (x1 - x0)
        if _split(cols, (cv[yb + 1, x0 + 2:x1 - 1] - cv[yt, x0 + 2:x1 - 1]) / (yb - yt + 1)) or \
                _split(rows, (ch[yt + 2:yb - 1, x1 + 1] - ch[yt + 2:yb - 1, x0]) / (x1 - x0 + 1)):
            continue                                  # plain background between two edges inside: two cards, not one
        found.append((x0 / W, yt / H, (x1 - x0) / W, (yb - yt) / H, float(sum(c))))
    found.sort(key=lambda r: (-r[4], -r[2] * r[3]))
    keep: list[tuple] = []
    for r in found:
        if any(_iou(r, k) > 0.5 or _inside(r, k) for k in keep):
            continue
        keep.append(r)
    return [r for r in keep if not any(k is not r and k[2] * k[3] > r[2] * r[3] and _inside(r, k) and k[4] >= r[4] - 0.15
                                       for k in keep)]


def _split(fill_line, edge_line) -> bool:
    """A line of plain background right next to a straight edge running all the way across: the gap between two cards."""
    import numpy as np
    if len(fill_line) < 8:
        return False
    gap = fill_line < 0.25
    edge = np.convolve((edge_line >= 0.8).astype(float), np.ones(7), "same") > 0
    return bool((gap & edge)[3:-3].any())


def _inside(p, q, m=0.02) -> bool:
    return p[0] >= q[0] - m and p[1] >= q[1] - m and p[0] + p[2] <= q[0] + q[2] + m and p[1] + p[3] <= q[1] + q[3] + m


def _iou(a, b) -> float:
    ix = max(0.0, min(a[0] + a[2], b[0] + b[2]) - max(a[0], b[0]))
    iy = max(0.0, min(a[1] + a[3], b[1] + b[3]) - max(a[1], b[1]))
    inter = ix * iy
    return inter / (a[2] * a[3] + b[2] * b[3] - inter + 1e-9)


def _native(src, t0: float, t1: float):
    """The frames between t0 and t1 at the video's own frame rate (motion takes a few frames; 10 per second miss it)."""
    import subprocess
    import numpy as np
    info = util.probe(Path(src))
    w, h = SW, int(round(info["height"] * SW / info["width"] / 2)) * 2
    r = subprocess.run([util.ffmpeg_bin(), "-v", "error", "-ss", f"{max(0.0, t0):.3f}", "-i", str(src), "-t", f"{t1 - max(0.0, t0):.3f}",
                        "-vf", f"scale={w}:{h}", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True, timeout=60)
    n = len(r.stdout) // (w * h * 3)
    return np.frombuffer(r.stdout[:n * w * h * 3], np.uint8).reshape(n, h, w, 3).astype(np.float32) if n else None


def _motion(seq, bg, tpl_frame, box, before: bool, fps: float) -> tuple[str, int]:
    """How a card arrives (before=True) or leaves. `seq` runs from the card being absent to it sitting in place (for
    an exit: backwards in time). In the first frame where part of it shows, its own picture is looked for: found
    shifted, it slides (from that side); smaller at the same spot, it pops; faint in place, it fades; going from
    absent to whole in one frame, it's a cut. Returns (motion, milliseconds the motion takes)."""
    import cv2
    import numpy as np
    if seq is None or len(seq) < 2:
        return "cut", 0
    H, W = seq.shape[1:3]
    x0, y0, w, h = box[:4]
    X0, X1, Y0, Y1 = int(x0 * W), int((x0 + w) * W), int(y0 * H), int((y0 + h) * H)
    bw, bh = X1 - X0, Y1 - Y0
    if bw < 8 or bh < 8 or tpl_frame.shape[:2] != (H, W):
        return "cut", 0
    gray = lambda a: a.mean(-1).astype(np.float32)
    tpl, bgg = gray(tpl_frame)[Y0:Y1, X0:X1], gray(bg)
    full = abs(tpl - bgg[Y0:Y1, X0:X1]).mean()
    moving = []
    for f in seq:
        fr = gray(f)
        here = abs(fr - bgg)[Y0:Y1, X0:X1].mean()
        pad = cv2.copyMakeBorder(fr, bh, bh, bw, bw, cv2.BORDER_CONSTANT, value=float(fr.mean()))
        _, best, _, (mx, my) = cv2.minMaxLoc(cv2.matchTemplate(pad, tpl, cv2.TM_CCOEFF_NORMED))
        dx, dy = (mx - bw - X0) / bw, (my - bh - Y0) / bh
        settled = best > 0.7 and max(abs(dx), abs(dy)) < 0.04 and here > 0.75 * full
        if settled:
            break
        if here > 0.15 * full or best > 0.6:
            moving.append((best, dx, dy, here, fr))
    if not moving:
        return "cut", 0
    ms = int(round((len(moving) + 1) * 1000 / fps))
    best, dx, dy, here, fr = max(moving, key=lambda m: m[0])
    if best > 0.5 and max(abs(dx), abs(dy)) > 0.06:
        if abs(dy) >= abs(dx):
            return ("slide-up" if dy > 0 else "slide-down") if before else ("slide-down" if dy > 0 else "slide-up"), ms
        return ("slide-left" if dx > 0 else "slide-right") if before else ("slide-right" if dx > 0 else "slide-left"), ms
    cx, cy = (X0 + X1) // 2, (Y0 + Y1) // 2
    for _, _, _, _, fr2 in moving:
        for sc in (0.4, 0.55, 0.7, 0.85):            # smaller, same centre: it grows in (shrinks out)
            t2 = cv2.resize(tpl, (max(4, int(bw * sc)), max(4, int(bh * sc))))
            r = fr2[max(0, cy - bh // 2):cy + bh // 2, max(0, cx - bw // 2):cx + bw // 2]
            if r.shape[0] >= t2.shape[0] and r.shape[1] >= t2.shape[1] and \
                    cv2.minMaxLoc(cv2.matchTemplate(r, t2, cv2.TM_CCOEFF_NORMED))[1] > max(0.6, best + 0.05):
                return "pop", ms
    return ("fade", ms) if len(moving) >= 2 else ("cut", 0)


def find(frames: list[Path], cuts: list[float], fps: float = 10.0, ocr: list | None = None, src=None, progress=None) -> dict:
    """{"cards": [{t_in, t_out, x, y, w, h, top, enter, exit, kind}], "layout": {...}}; x, y are the centre."""
    say = progress or (lambda *_: None)
    say('Reading image-placement frames…', 0)
    g = _load(frames)
    if g is None or len(g) < 4:
        return {"cards": [], "layout": {}}
    bgs = _backgrounds(g, sorted({int(round(c * fps)) for c in cuts}))
    grads: dict[int, tuple] = {}
    tracks: list[dict] = []
    open_: list[dict] = []
    for i in range(len(g)):
        k = id(bgs[i])
        if k not in grads:
            grads[k] = _grads(bgs[i])
        boxes = rects(g[i], bgs[i], *grads[k])
        if i % 10 == 0 or i == len(g) - 1:
            say(f'Measured image positions in {i + 1} of {len(g)} frames', 0.1 + 0.55 * (i + 1) / len(g))
        used = set()
        for b in boxes:
            tr = max((t for t in open_ if id(t) not in used), key=lambda t: _iou(t["boxes"][-1], b), default=None)
            if tr is not None and _iou(tr["boxes"][-1], b) > 0.6:
                tr["boxes"].append(b); tr["last"] = i; used.add(id(tr))
            else:
                t = {"first": i, "last": i, "boxes": [b]}
                open_.append(t); used.add(id(t))
        for t in [t for t in open_ if i - t["last"] > 2]:      # gone for 3 frames: closed
            open_.remove(t); tracks.append(t)
    tracks += open_
    import numpy as np
    kept = []
    for track_index, t in enumerate(tracks):
        if track_index % 10 == 0 or track_index == len(tracks) - 1:
            say(f'Checking image track {track_index + 1} of {len(tracks)}', 0.65 + 0.1 * (track_index + 1) / max(1, len(tracks)))
        bs = np.array([b[:4] for b in t["boxes"]])
        if len(bs) < max(4, int(0.5 * fps)) or len(bs) < 0.6 * (t["last"] - t["first"] + 1):
            continue                                  # a card stays on screen at least half a second
        # its box: the one most frames agree on (a frame or two may catch only part of it)
        votes = [(np.abs(bs - b).max(1) < 0.012).sum() for b in bs]
        box = tuple(float(v) for v in np.median(bs[np.array(votes) >= max(votes) * 0.8], 0))
        jitter = float(np.median(np.abs(bs - np.array(box)).max(1)))
        score = float(np.median([b[4] for b in t["boxes"]]))
        if score < 3.6 or jitter > 0.012 or box[2] * box[3] < 0.02:
            continue                                  # a card sits still with four clear edges; the speaker's arm doesn't
        kept.append(dict(t, box=box))
    # the same card seen twice with a short gap (someone's hand passed over it): one card
    kept.sort(key=lambda t: t["first"])
    merged: list[dict] = []
    for t in kept:
        prev = next((m for m in merged if _iou(m["box"], t["box"]) > 0.8 and 0 <= t["first"] - m["last"] <= fps), None)
        if prev:
            prev["last"] = max(prev["last"], t["last"])
        else:
            merged.append(t)
    # a picture inside a bigger card (part of its content) isn't a card of its own
    merged = [t for t in merged if not any(o is not t and o["box"][2] * o["box"][3] > t["box"][2] * t["box"][3]
                                           and _inside(t["box"], o["box"]) and o["first"] <= t["first"] + fps // 2
                                           and o["last"] >= t["last"] - fps // 2 for o in merged)]
    cards = []
    for card_index, t in enumerate(merged):
        say(f'Measuring image {card_index + 1} of {len(merged)} entering', 0.75 + 0.24 * card_index / max(1, len(merged)))
        x0, y0, w, h = t["box"]
        mid = g[min(t["last"], t["first"] + 2)]
        if src:
            vf = float(util.probe(Path(src)).get("fps") or 30)
            t_in, t_out = t["first"] / fps, (t["last"] + 1) / fps
            ein, ems = _motion(_native(src, t_in - 0.6, t_in + 0.15), bgs[t["first"]], mid, t["box"], True, vf)
            say(f'Measuring image {card_index + 1} of {len(merged)} leaving', 0.75 + 0.24 * (card_index + 0.5) / len(merged))
            seq = _native(src, t_out - 0.15, t_out + 0.6)
            eout, _ = _motion(seq[::-1] if seq is not None else None, bgs[t["last"]], mid, t["box"], False, vf)
        else:
            ein, ems = _motion(g[max(0, t["first"] - 4):t["first"] + 1], bgs[t["first"]], mid, t["box"], True, fps)
            eout, _ = _motion(g[t["last"]:t["last"] + 5][::-1], bgs[t["last"]], mid, t["box"], False, fps)
        cards.append({"t_in": round(t["first"] / fps, 2), "t_out": round((t["last"] + 1) / fps, 2),
                      "x": round(x0 + w / 2, 3), "y": round(y0 + h / 2, 3), "w": round(w, 3), "h": round(h, 3),
                      "top": round(y0, 3), "aspect": round(w * g.shape[2] / max(1e-6, h * g.shape[1]), 3),
                      "enter": ein, "enter_ms": ems, "exit": eout,
                      "kind": _kind(t["box"], (t["first"] + t["last"]) // 2, ocr)})
    cards.sort(key=lambda c: c["t_in"])
    say('Image positions and movement measured', 1)
    return {"cards": cards, "layout": layout(cards)}


def _kind(box, i: int, ocr) -> str:
    """"text" for a box that's mostly words (a title card), "image" otherwise."""
    if not ocr or i >= len(ocr):
        return "image"
    x0, y0, w, h = box
    words = [b for b in (ocr[i] or []) if x0 <= b.get("x", -1) + b.get("w", 0) / 2 <= x0 + w
             and y0 <= b.get("y", -1) + b.get("h", 0) / 2 <= y0 + h]
    covered = sum(b.get("w", 0) * b.get("h", 0) for b in words)
    return "text" if words and covered > 0.3 * w * h else "image"


def layout(cards: list[dict]) -> dict:
    """The reference's habit for its image cards: where they sit (medians; the centre line if most are centred), how
    big, how they come and go and for how long."""
    import statistics as st
    big = [c for c in cards if c.get("kind") != "text" and c["w"] * c["h"] >= 0.03 and c["t_out"] - c["t_in"] >= 0.6]
    if not big:
        return {}
    med = lambda k: round(st.median(c[k] for c in big), 3)
    centred = sum(1 for c in big if abs(c["x"] - 0.5) < 0.06) / len(big)
    common = lambda k: max(set(c[k] for c in big), key=[c[k] for c in big].count)
    return {"count": len(big), "x": 0.5 if centred >= 0.5 else med("x"), "y": med("y"), "top": med("top"),
            "w": med("w"), "h": med("h"), "centred_share": round(centred, 2), "enter": common("enter"),
            "exit": common("exit"), "duration": round(st.median(c["t_out"] - c["t_in"] for c in big), 2),
            "bottom": round(st.median(c["top"] + c["h"] for c in big), 3)}
