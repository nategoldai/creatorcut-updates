---
name: creatorcut
description: "Open or resume CreatorCut Studio inside this AI host. Use for /creatorcut, open CreatorCut, or resume editing in CreatorCut."
---

# Open CreatorCut

Use this installed app folder and read AGENTS.md plus kit/skills-src/studio/SKILL.md. Open Studio in the host's embedded preview beside this conversation. Use its native creatorcut_studio tool if configured for this installation; otherwise start the local Studio with private Python and use the host's embedded preview tool with its actual URL. Keep the title CREATORCUT. Never launch an external browser or a second editor/model.

For an invocation outside the app project, read ~/.creatorcut/installations.json to locate the active existing installation. The setup installs this launcher into the user's skill directory so future chats can discover it. Host slash/skill discovery may require reopening the chat. Do not claim an unknown host supports custom slash commands or embedded previews without checking its available tools.


## Continue without Studio
When the user says “continue my CreatorCut video” in this installation, use its private interpreter to run `edit.py workflow unfinished`. This lists only unfinished saved requests; no open Studio or message connection is needed. If more than one is listed, show their titles and ask which one; never guess. If none are listed, say there is no unfinished saved edit here. For the chosen exact project run `edit.py workflow resume PROJECT`. It uses the same safe Stop/recovery as Studio: if `stopping` is true, wait and run that same resume command again, never claim or start a replacement while an old step is alive. Once it returns the fresh native_message, read its request/delivery details and follow the edit skill in this visible chat. Claim without --owner, keep the generated owner ID, run the required fresh renderer probe, and reuse verified completed artifacts. Do not reopen Studio merely to recover and do not launch another model. Normal permissions remain explicit.
