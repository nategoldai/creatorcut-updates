---
name: studio
description: Open CreatorCut Studio in this conversation.
---
Open the actual supported embedded Studio using the private interpreter and edit.py studio open --no-browser. Chat mode is the default. Do not launch a managed editor or another AI. Do not listen or poll. When the customer presses Make or Update, Studio gives them a message to paste here; act on that pasted message.
