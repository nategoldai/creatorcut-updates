# Claude Code setup
Open this installation as the project, verify its private tools and show Studio in the supported preview. Make, Update and Try again give a message to paste into this visible chat. Do not listen or poll, and do not use Stop hooks to deliver edits. Normal host security decisions remain the user’s. Do not change global settings or use another installation.
