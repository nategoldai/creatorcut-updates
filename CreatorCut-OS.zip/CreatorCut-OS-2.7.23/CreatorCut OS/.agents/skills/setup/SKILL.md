---
name: setup
description: "Install, open or repair CreatorCut for a beginner in their current native AI project."
---
# Install CreatorCut

Work only in this installation. Detect the actual host from its tools; do not ask a beginner to choose or require another host's account. Chat is the default editing mode. This visible conversation is the AI editor; do not start a managed editor or another model.

1. Say: I’ll set up CreatorCut and open it when it’s ready. This may take a few minutes. Keep updates short, factual and about 45–60 seconds apart. No technical inventories unless asked.
2. Name a dedicated installation chat CREATORCUT with a supported native title control, preserving any later manual rename. Never edit private host databases or claim a rename without verification. If the host has no supported naming control, leave the title alone and continue quietly.
3. Read the supplied installer before running it. On Mac, use this actual visible host (Codex or Claude Code) and run `bash kit/setup/install.sh --no-shortcut`. Do not require system Python: public bootstrap uses curl, unzip and shasum; setup downloads its private Python. If setup is actually attempted on Windows say “Mac only for now” and stop before downloading. Do not add host-support warnings to onboarding or the first screen. Never change global host settings.
4. Show the installation progress card from kit/tools/install_status.py in the supported embedded preview. It reports actual setup milestones. Continue the installer and health checks rather than ending the turn. Preserve an existing installation and its customer files during repairs.
5. Use the installed private interpreter to run `edit.py doctor --json`. Required engine tools must be installed before Make. Studio can show installation/progress while optional assets download; missing tools must have a clear repair action. A failed browser probe is not a permission grant or completed render.
6. Open `sh kit/setup/launch.sh studio open --no-browser` in the supported host preview and verify the actual Studio screen. Register only this project's CreatorCut MCP integration when supported; respect its ordinary first-use trust and permission prompts. Do not change global settings or silently approve access.
7. Say at most two short ready sentences, including that Make gives a message to paste into this chat. Start work only when the saved message is pasted here.

Make always shows the Editor's Start in your chat paste card. It contains the same saved request, and pasting it into any chat starts or resumes that edit. Never pretend a localhost preview is a message-capable MCP App.

Use only supported embedding: this host's in-app browser/preview tools or a mounted CreatorCut MCP App. Do not automatically open an external browser. If embedding is unavailable, state that limitation and the actual local URL. Claude Code project configuration must point at this installation; never reuse another host's folder, credentials or runtime.

For setup/resume, inspect and repair what is actually missing, preserve videos/presets/memory/settings, and reopen Studio. Do not repeat a full installation unnecessarily. Keep required security decisions explicit. Once ready, explain Make → copy → paste into this chat. Do not listen or launch a hidden AI. See kit/docs/chat-editing.md, kit/docs/setup-notes.txt and the edit skill for exact contracts.

## Real capability check
Open this exact app folder as the chat's project first. If another project is open, say only: “Open the CreatorCut folder as your project, then paste the message again.” Do not add folder permissions automatically.

After installing tools, run `.venv/bin/python edit.py renderer-probe --project ABSOLUTE_SCRATCH_FOLDER` in THIS real visible chat. The actual `prerequisites_passed` result decides readiness, not the host name. If it fails, read the exact failed stage and describe only its required permission in one plain sentence telling the customer how to approve the actual host prompt. Never approve it yourself, invent a grant or move a denied command outside its restrictions. After genuine approval rerun the same probe. Do not call an unrun probe passed or promise no prompts. Both Codex and Claude Code on a Mac can attempt setup; complete host release acceptance is separate.

If the probe requests network permission, say: “Allow network access for this edit in the chat’s permission prompt so its renderer can run; that grant also permits internet access.” If it requests a specific folder, name that exact folder and the actual prompt. Only the customer can approve. Never claim the renderer is ready before the rerun passes.
