# CreatorCut OS

Open the extracted inner **CreatorCut OS** folder as your project in Codex or Claude Code. Its project instructions guide setup and open Studio beside your conversation. Use the included START HERE.pdf for the introduction and kit/docs/setup-notes.txt for current setup details.

## Make your first video
1. Name your video and add raw footage and optional B-roll.
2. Add a reference or choose a saved preset if you have one. Otherwise CreatorCut Signature supplies bold white/yellow Inter Tight type, clean motion and selective behind-person emphasis. Clear instructions/reference choices override the default; unclear details fall back individually.
3. Choose your colour treatment. In Step 5, explain cuts, pacing, captions, animations, music and anything else you want.
4. Click Make my video to open Editor. The managed editor uses the complete saved brief, footage and references in its own persistent project session. It keeps working independently of the host chat.
5. In Editor, review the video, add timeline feedback and click Update video, export, and optionally save/update a named preset for next time.

## Presets and editing memory
Home and Studio show named saved presets. A preset captures the entered brief and references, and can be updated from a reviewed final video. Existing projects keep their pinned recipe. Lasting feedback is saved locally in background preference files; one-off scene corrections stay with that project. Defaults do not become personal preferences just because they were used.

## Local tools
Setup downloads editing tools that can use several GB. Internet is required for installation. The managed editor requires Codex from OpenAI and your own signed-in account. Your Codex plan and usage limits apply, including when Studio is opened from Claude. A Claude subscription alone does not authenticate this engine. Studio has no separate chat. Host permissions and embedded-preview capabilities still apply. The ZIP excludes your personal projects, footage and preference files. The included worked-example reel is intentional.

For editing craft, see kit/docs/craft-guide.md and signature-style.md. Setup details: kit/docs/setup-notes.txt. Technical validation scope: kit/docs/verification-notes.md. Original recordings and reviewed outputs are preserved.

## Faster repeat edits
CreatorCut reuses completed local work only when its input contents and settings still match. Prepared footage, transcripts, cutouts and reference studies can be reused. Sound-only revisions can keep the exact visual frames while rebuilding audio. Changed captions, effects, fonts or footage rebuild the affected visual render; final export settings and required review remain unchanged. Cache data stays with the project and is excluded from this ZIP. Speed gains depend on how much of the edit remains unchanged; no fixed speed multiplier is promised.
