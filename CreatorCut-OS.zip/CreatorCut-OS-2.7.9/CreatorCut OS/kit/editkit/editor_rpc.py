"""Documented Codex App Server transport. No API key extraction or permission bypass."""
from __future__ import annotations
import os,json,subprocess,threading,queue,time
from concurrent.futures import Future
from . import util

class RPC:
    def __init__(self,command,cwd):
        self.process=subprocess.Popen(command,cwd=cwd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1,close_fds=True,env=dict(os.environ,CREATORCUT_MANAGED_EDITOR='1'))
        self.pending={};self.lock=threading.Lock();self.serial=0;self.events=queue.Queue();self.stderr=[]
        self.outgoing=queue.Queue(maxsize=32);self.closed=threading.Event()
        self.writer=threading.Thread(target=self._write_loop,daemon=True);self.writer.start()
        threading.Thread(target=self._read,daemon=True).start();threading.Thread(target=self._errors,daemon=True).start()
    def _errors(self):
        for line in self.process.stderr:
            self.stderr=(self.stderr+[line.rstrip()])[-30:]
    def _read(self):
        try:
            for line in self.process.stdout:
                if len(line)>8_000_000:continue
                try:m=json.loads(line)
                except ValueError:continue
                if not isinstance(m,dict):continue
                if 'id' in m and 'method' not in m:
                    with self.lock:f=self.pending.pop(m['id'],None)
                    if f and not f.done():
                        if 'error' in m:
                            error=m['error'];message=error.get('message','Editor request failed.') if isinstance(error,dict) else str(error)
                            f.set_exception(util.Fail(message))
                        else:f.set_result(m.get('result',{}))
                else:self.events.put(m)
        finally:
            with self.lock:
                for f in self.pending.values():
                    if not f.done():f.set_exception(util.Fail('The editor connection closed. Your project is saved.'))
                self.pending.clear()
            self.events.put({'method':'creatorcut/process_closed'})
    def _write_loop(self):
        # Only this thread touches stdin. A blocked pipe must never hold the
        # response registry lock or prevent a caller's deadline from expiring.
        while not self.closed.is_set():
            try:item=self.outgoing.get(timeout=.1)
            except queue.Empty:continue
            payload,done=item
            try:
                if self.process.poll() is not None:raise OSError('Editor process stopped')
                self.process.stdin.write(payload);self.process.stdin.flush()
                done.set_result(None)
            except (OSError,ValueError) as exc:
                done.set_exception(util.Fail('The editor connection stopped. Your request is saved.'))
                self.closed.set()
            finally:self.outgoing.task_done()
    def write(self,message,timeout=30):
        deadline=time.monotonic()+timeout
        if self.closed.is_set() or self.process.poll() is not None:
            raise util.Fail('The editor process stopped. Your files are saved.')
        done=Future()
        try:
            self.outgoing.put((json.dumps(message,ensure_ascii=False)+'\n',done),timeout=max(0,deadline-time.monotonic()))
            done.result(timeout=max(0,deadline-time.monotonic()))
        except (TimeoutError,queue.Full):
            # Delivery is ambiguous. Stop this owned transport, do not replay
            # an unconfirmed turn into it or allow queued messages to arrive late.
            self.closed.set()
            if self.process.poll() is None:
                try:self.process.terminate()
                except OSError:pass
            raise util.Fail('The editor did not confirm message delivery. Your request remains saved; no duplicate is sent automatically.')
    def request(self,method,params=None,timeout=30):
        with self.lock:
            self.serial+=1;rid='cc-'+str(self.serial);f=Future();self.pending[rid]=f
        try:
            deadline=time.monotonic()+timeout
            self.write({'jsonrpc':'2.0','id':rid,'method':method,'params':params or {}},timeout=timeout)
            return f.result(timeout=max(0,deadline-time.monotonic()))
        except TimeoutError:
            raise util.Fail('The editor did not confirm '+method+'. Your request remains saved; no duplicate is sent automatically.')
        finally:
            with self.lock:self.pending.pop(rid,None)
    def notify(self,method,params=None):self.write({'jsonrpc':'2.0','method':method,'params':params or {}})
    def respond(self,rid,result):self.write({'jsonrpc':'2.0','id':rid,'result':result})
    def reject(self,rid,message):self.write({'jsonrpc':'2.0','id':rid,'error':{'code':-32601,'message':message}})
    def close(self):
        self.closed.set()
        if self.process.poll() is None:
            # Terminate before closing stdin: flush/close can itself block when
            # the child is alive but no longer reading its pipe.
            try:self.process.terminate();self.process.wait(timeout=5)
            except (OSError,ValueError,subprocess.TimeoutExpired):
                self.process.terminate()
                try:self.process.wait(timeout=5)
                except subprocess.TimeoutExpired:self.process.kill();self.process.wait(timeout=5)

        self.writer.join(timeout=2)
        for stream in (self.process.stdin,self.process.stdout,self.process.stderr):
            try:stream.close()
            except (OSError,ValueError):pass
