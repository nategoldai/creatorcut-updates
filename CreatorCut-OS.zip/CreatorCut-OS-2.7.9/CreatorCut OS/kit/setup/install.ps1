# CreatorCut OS: one-step installer for Windows.
#
#   powershell -NoProfile -ExecutionPolicy Bypass -File kit/setup/install.ps1              install
#   powershell -NoProfile -ExecutionPolicy Bypass -File kit/setup/install.ps1 -Open        legacy flag; Studio opens through the host preview
#   powershell -NoProfile -ExecutionPolicy Bypass -File kit/setup/install.ps1 -Wait python wait for the private Python, then exit
#
# Needs no admin rights and changes nothing outside this folder (plus the standard download cache).
# It downloads FFmpeg + ffprobe and uv + a private Python 3.12 into kit\bin, the engine's packages
# into .venv, then fonts, sound effects and the speech model. Progress is written live to
# kit\studio-out\progress.js, which Studio.html shows. Safe to run again: finished steps are skipped.

param([switch]$Open, [string]$Wait = "", [switch]$NoShortcut)
$ErrorActionPreference = "Continue"
$ProgressPreference = "SilentlyContinue"   # makes downloads much faster
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

$Root = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
Set-Location $Root
$Kit = Join-Path $Root "kit"; $Bin = Join-Path $Kit "bin"; $Out = Join-Path $Kit "studio-out"
$Pjs = Join-Path $Out "progress.js"; $Beat = Join-Path $Out "beat.js"; $Log = Join-Path $Out "install.log"
New-Item -ItemType Directory -Force -Path $Bin, $Out | Out-Null
$env:UV_PYTHON_INSTALL_DIR = Join-Path $Bin "python"
if (-not $env:UV_CACHE_DIR) { $env:UV_CACHE_DIR = Join-Path $Bin "cache" }
$Vpy = Join-Path $Root ".venv\Scripts\python.exe"
$Edit = Join-Path $Root "edit.py"
$Arm = ($env:PROCESSOR_ARCHITECTURE -eq "ARM64")
$Steps = @("python", "engine", "packages", "motion", "vision", "extras", "model", "studio")
$PidFile = Join-Path $Out "install.pid"

# -Wait python: for the agent. Returns once the private Python exists (so the Studio can start).
if ($Wait) {
  for ($i = 0; $i -lt 240; $i++) {
    if (Test-Path $Vpy) { Write-Output "PYTHON_READY=1"; exit 0 }
    $running = $false
    if (Test-Path $PidFile) { $p = Get-Content $PidFile -ErrorAction SilentlyContinue; if ($p -and (Get-Process -Id $p -ErrorAction SilentlyContinue)) { $running = $true } }
    if (-not $running -and $i -gt 3) { Write-Output "INSTALLER_NOT_RUNNING=1"; exit 2 }
    Start-Sleep -Seconds 1
  }
  Write-Output "PYTHON_READY=0"; exit 3
}
Set-Content -Path $PidFile -Value $PID
$S = @{}; foreach ($k in $Steps) { $S[$k] = @{ state = "todo"; start = 0; end = 0 } }
$Global:State = "running"; $Global:Current = ""; $Global:Err = $null
function Now { [DateTimeOffset]::UtcNow.ToUnixTimeSeconds() }
$Started = Now

function Write-Progress2 {
  $parts = foreach ($k in $Steps) { '"{0}":{{"state":"{1}","start":{2},"end":{3}}}' -f $k, $S[$k].state, $S[$k].start, $S[$k].end }
  $err = if ($Global:Err) { '"' + $Global:Err + '"' } else { "null" }
  $js = 'window.AIE_PROGRESS = {{"state":"{0}","current":"{1}","started":{2},"updated":{3},"os":"windows","error":{4},"order":["python","engine","packages","motion","vision","extras","model","studio"],"steps":{{{5}}}}};' -f `
        $Global:State, $Global:Current, $Started, (Now), $err, ($parts -join ",")
  [IO.File]::WriteAllText($Pjs, $js + "`n")
}
function Begin-Step($k, $n, $msg) { $Global:Current = $k; $S[$k].state = "running"; $S[$k].start = Now; Write-Progress2; Write-Output ""; Write-Output "[$n/8] $msg" }
function Finish-Step($k, $st = "done") { $S[$k].state = $st; $S[$k].end = Now; Write-Progress2 }
function Skip-Step($k) { $S[$k].state = "done"; $S[$k].start = Now; $S[$k].end = Now }
function Fail-Step($k, $msg) {
  $S[$k].state = "error"; $S[$k].end = Now; $Global:State = "error"; $Global:Err = $msg; Write-Progress2
  Write-Output ""; Write-Output "X $msg"; Write-Output "SETUP_STATUS=error"; Write-Output "SETUP_STEP=$k"; Write-Output "LOG=kit/studio-out/install.log"
  Stop-Beat; Remove-Item $PidFile -ErrorAction SilentlyContinue; exit 1
}
function Get-File($url, $dest) {
  for ($i = 0; $i -lt 3; $i++) {
    try { Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $dest; if ((Get-Item $dest).Length -gt 10000) { return $true } }
    catch { Add-Content $Log "download failed ($url): $_" }
    Start-Sleep -Seconds 2
  }
  return $false
}
function Test-Libass($ff) { $f = & $ff -hide_banner -filters 2>$null | Out-String; return ($f -match "\sass\s") }
function Run-Py($cmdArgs) { & $Vpy $Edit @cmdArgs *>> $Log; return ($LASTEXITCODE -eq 0) }
# a heartbeat the Studio watches, so it knows the installer is alive
$BeatJob = Start-Job -ArgumentList $Beat -ScriptBlock { param($b) while ($true) { [IO.File]::WriteAllText($b, "window.AIE_BEAT = " + [DateTimeOffset]::UtcNow.ToUnixTimeSeconds() + ";`n"); Start-Sleep -Seconds 2 } }
function Stop-Beat { try { Stop-Job $BeatJob -ErrorAction SilentlyContinue; Remove-Job $BeatJob -Force -ErrorAction SilentlyContinue } catch {} }

Set-Content -Path $Log -Value ""
Write-Output "CreatorCut OS setup (windows). Nothing to do for you: the Studio shows the progress."
Write-Progress2
if ($Open) { Write-Host "Studio opens inside your AI host. Ask your editor to open CREATORCUT after setup." }

# 1. private Python (uv)
$UV = Join-Path $Bin "uv.exe"
$pyOk = $false; if (Test-Path $Vpy) { & $Vpy -c "import sys; assert sys.version_info >= (3, 9)" 2>$null; $pyOk = ($LASTEXITCODE -eq 0) }
if ($pyOk) { Skip-Step "python"; Write-Output "[1/8] Private Python: already installed" }
else {
  Begin-Step "python" 1 "Setting up a private Python (about 30 MB)..."
  if (-not (Test-Path $UV)) {
    $t = if ($Arm) { "aarch64-pc-windows-msvc" } else { "x86_64-pc-windows-msvc" }
    $tmp = Join-Path $Bin "tmp-uv"; Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue; New-Item -ItemType Directory $tmp | Out-Null
    if (Get-File "https://github.com/astral-sh/uv/releases/latest/download/uv-$t.zip" (Join-Path $tmp "uv.zip")) {
      try { Expand-Archive -Path (Join-Path $tmp "uv.zip") -DestinationPath (Join-Path $tmp "x") -Force
            $u = Get-ChildItem -Path (Join-Path $tmp "x") -Recurse -Filter "uv.exe" | Select-Object -First 1
            if ($u) { Copy-Item $u.FullName $UV -Force } } catch { Add-Content $Log "uv unzip failed $_" }
    }
    Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue
  }
  if (-not (Test-Path $UV)) { Fail-Step "python" "The Python helper could not be downloaded. Check the internet connection and run setup again." }
  Remove-Item -Recurse -Force (Join-Path $Root ".venv") -ErrorAction SilentlyContinue
  & $UV venv --python 3.12 --python-preference only-managed (Join-Path $Root ".venv") *>> $Log
  if (-not (Test-Path $Vpy)) { Fail-Step "python" "A private Python could not be set up. Check the internet connection and run setup again." }
  Finish-Step "python"; Write-Output "  Private Python ready"
}

# 2. video engine (FFmpeg with captions support)
$FF = Join-Path $Bin "ffmpeg.exe"; $FP = Join-Path $Bin "ffprobe.exe"
if ((Test-Path $FF) -and (Test-Path $FP) -and (Test-Libass $FF)) { Skip-Step "engine"; Write-Output "[2/8] Video engine: already installed" }
else {
  Begin-Step "engine" 2 "Downloading the video engine (FFmpeg, about 150 MB)..."
  $tmp = Join-Path $Bin "tmp-ffmpeg"; Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue; New-Item -ItemType Directory $tmp | Out-Null
  $ok = $false
  $sources = if ($Arm) { @("https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-winarm64-gpl.zip") }
             else { @("https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip",
                      "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip") }
  foreach ($src in $sources) {
    if ($ok) { break }
    if (Get-File $src (Join-Path $tmp "ff.zip")) {
      try {
        Expand-Archive -Path (Join-Path $tmp "ff.zip") -DestinationPath (Join-Path $tmp "x") -Force
        $e = Get-ChildItem -Path (Join-Path $tmp "x") -Recurse -Filter "ffmpeg.exe" | Select-Object -First 1
        $p = Get-ChildItem -Path (Join-Path $tmp "x") -Recurse -Filter "ffprobe.exe" | Select-Object -First 1
        if ($e -and $p) { Copy-Item $e.FullName $FF -Force; Copy-Item $p.FullName $FP -Force; $ok = Test-Libass $FF }
      } catch { Add-Content $Log "ffmpeg unzip failed $_" }
    }
  }
  Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue
  if ($ok) { Finish-Step "engine"; Write-Output "  Video engine ready" }
  else { Fail-Step "engine" "The video engine could not be downloaded. Check the internet connection and run setup again." }
}

# 3. editing engine packages
& $Vpy -c "import faster_whisper, PIL, certifi, yt_dlp" 2>$null
if ($LASTEXITCODE -eq 0) { Skip-Step "packages"; Write-Output "[3/8] Editing tools: already installed" }
else {
  Begin-Step "packages" 3 "Installing the editing tools (speech recognition and images, about 150 MB)..."
  if (Test-Path $UV) { & $UV pip install --python $Vpy -r (Join-Path $Kit "requirements.txt") *>> $Log }
  else { & $Vpy -m pip install -q -r (Join-Path $Kit "requirements.txt") *>> $Log }
  & $Vpy -c "import faster_whisper, PIL, certifi, yt_dlp" 2>$null
  if ($LASTEXITCODE -ne 0) { Fail-Step "packages" "The editing tools could not be installed. Check the internet connection and run setup again." }
  Finish-Step "packages"; Write-Output "  Editing tools ready"
}

# 4. motion graphics: private Node 22 + HyperFrames + Remotion + headless browser + their Claude skills
$NodeDir = Join-Path $Bin "node"; $Node = Join-Path $NodeDir "node.exe"; $Npm = Join-Path $NodeDir "npm.cmd"; $Npx = Join-Path $NodeDir "npx.cmd"
$Render = Join-Path $Kit "render"
function Find-Chrome { Get-ChildItem -Path (Join-Path $Render "node_modules\.remotion\chrome-headless-shell") -Recurse -Filter "chrome-headless-shell.exe" -ErrorAction SilentlyContinue | Select-Object -First 1 }
function Motion-Ready {
  if (-not (Test-Path $Node)) { return $false }
  & $Node (Join-Path $Kit "setup\verify-render.cjs") $Render
  if ($LASTEXITCODE -ne 0) { return $false }
  (Test-Path $Node) -and (Test-Path (Join-Path $Render "node_modules\hyperframes-library\bin\hyperframes.mjs")) -and (Test-Path (Join-Path $Render "node_modules\.bin\hyperframes.cmd")) -and (Test-Path (Join-Path $Render "node_modules\.bin\remotion.cmd")) -and `
  (Find-Chrome) -and (Test-Path (Join-Path $Root ".claude\skills\hyperframes\SKILL.md"))
}
if (Motion-Ready) { Skip-Step "motion"; Write-Output "[4/8] Motion graphics: already installed" }
else {
  Begin-Step "motion" 4 "Installing motion graphics: HyperFrames, Remotion and a private browser (about 350 MB)..."
  if (-not (Test-Path $Node)) {
    $na = if ($Arm) { "win-arm64" } else { "win-x64" }
    $tmp = Join-Path $Bin "tmp-node"; Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue; New-Item -ItemType Directory $tmp | Out-Null
    try {
      $sums = (Invoke-WebRequest -UseBasicParsing "https://nodejs.org/dist/latest-v22.x/SHASUMS256.txt").Content
      $name = ([regex]::Match($sums, "node-v22[0-9.]*-$na\.zip")).Value
      Invoke-WebRequest -UseBasicParsing "https://nodejs.org/dist/latest-v22.x/$name" -OutFile (Join-Path $tmp "node.zip")
      Expand-Archive -Force (Join-Path $tmp "node.zip") $tmp
      Remove-Item -Recurse -Force $NodeDir -ErrorAction SilentlyContinue
      Move-Item (Join-Path $tmp ($name -replace "\.zip$", "")) $NodeDir
    } catch { $_ | Out-File -Append $Log }
    Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue
    if (-not (Test-Path $Node)) { Fail-Step "motion" "The motion graphics engine could not be downloaded. Check the internet connection and run setup again." }
  }
  $env:PATH = "$NodeDir;$Bin;$env:PATH"; $env:npm_config_cache = Join-Path $Bin "npm-cache"; $env:npm_config_update_notifier = "false"
  Push-Location $Render; & $Npm ci --no-audit --no-fund --loglevel=error *>> $Log; & (Join-Path $Render "node_modules\.bin\remotion.cmd") browser ensure *>> $Log; Pop-Location
  foreach ($pack in @("heygen-com/hyperframes", "remotion-dev/skills")) { & $Npx -y skills add $pack --all --agent claude-code -y *>> $Log }
  Remove-Item -Recurse -Force (Join-Path $Root "agent") -ErrorAction SilentlyContinue
  & $Vpy (Join-Path $Root "kit\tools\sync_skills.py") *>> $Log   # skills in the exact format Claude Code and Codex accept
  if (-not (Motion-Ready)) { Fail-Step "motion" "The motion graphics tools didn't finish installing. Run setup again; it continues where it stopped." }
  Finish-Step "motion"; Write-Output "  Motion graphics ready"
}
$chrome = (Find-Chrome).FullName
foreach ($tool in @("hyperframes", "remotion")) {
  $exe = if ($tool -eq "hyperframes") { """$Node"" ""$Render\node_modules\hyperframes\bin\hyperframes.mjs""" } else { """$Render\node_modules\.bin\$tool.cmd""" }
  $w = "@echo off`r`nset ""PATH=$NodeDir;$Bin;%PATH%""`r`nset ""HYPERFRAMES_BROWSER_PATH=$chrome""`r`nset HYPERFRAMES_SKIP_SKILLS=1`r`nset DO_NOT_TRACK=1`r`n$exe %*`r`n"
  [IO.File]::WriteAllText((Join-Path $Bin "$tool.cmd"), $w)
}

# 5. reading references: on-screen text and the person's outline
& $Vpy -c "import rapidocr_onnxruntime, scipy.ndimage, onnxruntime, cv2" 2>$null
if ($LASTEXITCODE -eq 0) { Skip-Step "vision"; Write-Output "[5/8] Reference reading: already installed" }
else {
  Begin-Step "vision" 5 "Installing text recognition and person detection (reads reference videos)..."
  if (Test-Path $UV) { & $UV pip install --python $Vpy -r (Join-Path $Kit "requirements-vision.txt") *>> $Log }
  else { & $Vpy -m pip install -q -r (Join-Path $Kit "requirements-vision.txt") *>> $Log }
  & $Vpy -c "import rapidocr_onnxruntime, scipy.ndimage, onnxruntime, cv2" 2>$null
  if ($LASTEXITCODE -ne 0) { Fail-Step "vision" "Text recognition could not be installed. Check the internet connection and run setup again." }
  Finish-Step "vision"; Write-Output "  Reference reading ready"
}

# 6. fonts and sound effects
Begin-Step "extras" 6 "Adding premium fonts and sound effects..."
Run-Py @("fonts") | Out-Null; Run-Py @("calibrate") | Out-Null; Run-Py @("sfx") | Out-Null
Run-Py @("music-gen") | Out-Null
Finish-Step "extras"; Write-Output "  Fonts and sound effects ready"

# 7. speech model
Begin-Step "model" 7 "Downloading speech recognition (about 500 MB, the longest step)..."
if (Run-Py @("model")) { Finish-Step "model"; Write-Output "  Speech recognition ready" }
else { Fail-Step "model" "Speech recognition could not finish downloading. Check the connection and run setup again." }

# 8. the Studio
Begin-Step "studio" 8 "Building your Studio..."
if (-not (Run-Py @("studio", "--thumbs"))) { Run-Py @("studio") | Out-Null }
# Embedded-host workflow: no standalone browser shortcut is created.
& $Vpy (Join-Path $Kit "tools/install_shortcut.py") *>> $Log
& $Vpy (Join-Path $Kit "tools/verify_setup.py") *>> $Log
if ($LASTEXITCODE -ne 0) { Fail-Step "studio" "Some editing tools are not ready. Check the setup log and run setup again." }
Finish-Step "studio"
Remove-Item -Recurse -Force (Join-Path $Bin "cache"), (Join-Path $Bin "npm-cache") -ErrorAction SilentlyContinue
$Global:State = "done"; $Global:Current = ""; Write-Progress2
Stop-Beat
Write-Output ""
Remove-Item $PidFile -ErrorAction SilentlyContinue
Write-Output "Everything is installed."
Write-Output "SETUP_STATUS=done"
