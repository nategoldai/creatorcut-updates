# Production workflow

CreatorCut runs its local tools through an app-owned persistent Codex session per video. The customer supplies a signed-in Codex account; opening the interface in Claude does not replace that account. Native chat answers questions and can submit explicit project instructions, but it is not the managed session or its execution dependency. Ending a native reply does not stop a saved editing job. Normal host permissions remain required. Dependencies, models and rendering use local disk/CPU.

## Start / resume
Open the app folder in the host, follow setup when needed, then open Studio in its supported embedded preview. Make and Update persist the complete immutable request before dispatching the assigned managed editor. Do not arm a foreground native-action receiver, require copied requests, or launch a competing writer from this companion chat. Read persistent-editor.md for execution and recovery.

Inside the assigned project session, inspect the exact saved project/request and use `workflow claim ID --owner editor-JOB_ID`. Refresh the lease while actually working; keep project-specific files and output paths. The supervisor can serve two independent project sessions; heavy inference and rendering still share one resource lock. One video's permission wait must not block the other session. This is a single-customer local application, not an authenticated multi-user service. A saved request or an animated timeline alone is not proof of editing or completion.

## Required artifacts
1. Best-take plan + cut transcript (`plan.json`, `words.json`, `segments.json`). Agent reviews actual cuts.
2. Reference evidence and scene contract (`scene-plan.json`). Brief wins; reference adaptations explained.
3. Exact composition (`edit-plan.json`) with stable item ids and explicit audio events.
4. Candidate (`render/candidate.mp4`), technical decode check, review frames and manifest.
5. Agent-authored review tied to candidate SHA256 and input hashes.
6. Published numbered version; final export copies the same approved candidate.

`workflow init` only creates a scaffold; it does not invent scenes. `design` remains a legacy heuristic helper. A host agent must perform the creative work. The gate validates coverage/bindings/assets but cannot independently prove design fidelity or truthful human/agent observation.

## Commands
Use private Python, then `edit.py workflow {init,status,claim,block,validate,evidence,review,publish} PROJECT`.
Claim: `--owner SESSION --phase planning` (analysing/planning/building/reviewing supported).
Review: `--report PATH`. Publish: `--note TEXT`.
`compose PROJECT --final` makes an internal full-quality candidate. `compose` uses draft quality for experiments. Both require the scene contract. `workflow evidence` regenerates inspection frames. `render PROJECT` copies the reviewed output to finished; it doesn't render an unchecked alternate.

If a requirement is impossible or assets are missing: explain it, record unresolved entries, and block. An unknown logo or web UI is not a reason to make up a fake approximation without disclosure. Budget-limited failures remain candidates, not finished versions.

## Release support
Automated regression and local render tests are shipped in kit/tests. Independent first-run installations on Windows/Linux and creative evaluations across customer footage must be completed before advertising broad production readiness. See kit/docs/verification-notes.md at package root for measured status.

## Default visual direction
Use `kit/docs/signature-style.md` whenever a visual choice is unspecified. CreatorCut Signature is the default: Inter Tight white/yellow type, speech-timed in-place pops, selective readable words behind the speaker, purposeful animated media and gentle subject-safe finishing. Explicit instructions, clear reference observations, selected preset and relevant user memory override only the features they specify; unknown features fall back individually. Observed absence is an explicit choice (e.g. no captions or no motion), not a reason to add effects. Read style-direction.json and translate actual brief/reference/recipe/memory evidence to style-inputs.json before final planning. Defaults are not user preferences and must not be learned as feedback. Never silently restyle existing approved projects.
