/* Compact, executable style choices and version-bound timeline annotations. No chatbot. */
(function () {
'use strict';
const A=window.AIE,esc=A.esc, rows=(window.CREATORCUT_CATALOGUE||{}).entries||[];
const C=window.CreatorCutCreative={};
const chosen=p=>p?.settings?.library_choices||{};
const key=p=>p.name+':'+C.version(p);
C.version=p=>{const vs=p.versions||[],latest=vs.at(-1);for(const [k,d] of Object.entries(A.ui.timelineDelivery||{})){if(k.startsWith(p.name+':')&&latest?.n>Number(k.slice(p.name.length+1))){A.ui.reviewVersions={...(A.ui.reviewVersions||{}),[p.name]:latest.n};delete A.ui.timelineDelivery[k];A.saveUI();}}const n=(A.ui.reviewVersions||{})[p.name];return vs.find(v=>v.n===n)?.n||latest?.n||0;};
C.video=p=>(p.versions||[]).find(v=>v.n===C.version(p));
const active=(p,e)=>e.kind==='effect'?(chosen(p).effects||[]).some(v=>v.id===e.id&&v.version===e.version):chosen(p)[e.kind]?.id===e.id&&chosen(p)[e.kind]?.version===e.version;
function cards(p,kind){return '<div class="look-grid">'+rows.filter(e=>e.kind===kind).map(e=>'<div class="look-card-wrap" data-key="look-'+esc(e.id)+'"><button class="look-card" data-act="libraryPick" data-id="'+esc(e.id)+'" aria-pressed="'+active(p,e)+'"'+(A.ui.savingChoices?' disabled':'')+'><span class="look-preview">'+(e.poster?'<img loading="lazy" alt="" src="'+esc(e.poster)+'">':'<span class="look-type-sample">'+esc(e.name)+'</span>')+(e.preview?'<video aria-hidden="true" muted loop playsinline preload="none" data-keep-attrs data-library-preview data-src="'+esc(e.preview)+'"></video>':'')+'</span><span class="look-card-title">'+esc(e.name)+'<i aria-hidden="true">'+(active(p,e)?'✓':'+')+'</i></span><small>'+esc(e.look||e.line||e.does||'')+'</small></button><button class="look-expand" data-act="libraryPreview" data-id="'+esc(e.id)+'" aria-label="Preview '+esc(e.name)+'">Preview ↗</button></div>').join('')+'</div>';}
C.picker=p=>{
 const ch=chosen(p), selections=[ch.look,ch.caption,...(ch.effects||[])].filter(Boolean);
 return '<div class="creative-choices" aria-busy="'+!!A.ui.savingChoices+'"><p class="creative-hint" role="status">'+(A.ui.savingChoices?'Saving your choice…':'Your reference guides the edit. A choice here changes only that part.')+'</p>'+selections.map(c=>{const e=rows.find(x=>x.id===c.id);return e?'<span class="choice-chip">'+esc(e.name)+(c.version!==e.version?' · saved version':'')+'<button data-act="libraryRemove" data-id="'+esc(e.id)+'" aria-label="Reset '+esc(e.name)+'"'+(A.ui.savingChoices?' disabled':'')+'>×</button></span>':'';}).join('')+
 [['look','Overall styles'],['caption','Captions & fonts'],['effect','Effects & animation']].map(([kind,label])=>'<details class="look-disclosure" data-creative-details="'+kind+'"'+((A.ui.lookOpen||{})[kind]?' open':'')+'><summary>'+label+'<span>'+rows.filter(e=>e.kind===kind).length+' '+({look:'styles',caption:'captions',effect:'effects'}[kind])+'</span></summary>'+cards(p,kind)+'</details>').join('')+
 ((ch.effects||[]).length?'<details class="effect-placement"><summary>Choose where effects appear</summary>'+(ch.effects||[]).map(c=>'<label>'+esc(rows.find(e=>e.id===c.id)?.name||c.id)+'<select data-change="libraryPlacement" data-id="'+esc(c.id)+'">'+[['auto','Let my editor choose'],['hook','Opening'],['middle','Middle'],['end','Ending'],['range','Choose seconds…']].map(([v,t])=>'<option value="'+v+'"'+((typeof (ch.placements||{})[c.id]==='object'?'range':(ch.placements||{})[c.id])===v?' selected':'')+'>'+t+'</option>').join('')+'</select></label>'+((ch.placements||{})[c.id]?.mode==='range'?'<div class="effect-time" data-effect="'+esc(c.id)+'"><label>From<input type="number" min="0" step=".1" data-time="start" value="'+ch.placements[c.id].start+'"></label><label>To<input type="number" min="0" step=".1" data-time="end" value="'+ch.placements[c.id].end+'"></label><button class="btn btn-line btn-sm" data-act="saveEffectTime">Set time</button></div>':'')).join('')+'</details>':'')+'</div>';
};
function moment(t){const f=Math.max(0,Math.round(Number(t||0)*30));return Math.floor(f/1800)+':'+String(Math.floor(f/30)%60).padStart(2,'0')+'.'+String(Math.round((f%30)/30*100)).padStart(2,'0');}
C.moment=moment;
C.timeline=p=>{
 const v=C.video(p);if(!v)return '';
 const k=key(p),d=(A.ui.timelineDrafts||{})[k]||{},dur=Number(v.duration)||1;
 const notes=(p.annotations||[]).filter(n=>n.version===v.n&&n.status!=='removed').slice().reverse();
 const jobActive=['queued','starting','editing','waiting_approval','recovering'].includes(p.editor_job?.state);
 const todo=notes.filter(n=>n.status==='saved'),busy=!!A.ui.savingTimeline||!!A.ui.sendingTimeline;
 const thumb=v.poster||p.poster||'',t=Number(d.start)||0;
 const palette=['100,156,218','105,174,143','209,175,89','158,143,200'];
 const noteColor=(n,i)=>palette[(notes.length-1-i)%palette.length];
 return '<section class="feedback-timeline moment-editor" data-key="feedback-'+esc(k)+'" aria-label="Video feedback timeline">'+
 '<div class="feedback-film" data-act="timelineSeek" role="slider" tabindex="0" aria-valuemin="0" aria-valuemax="'+dur+'" aria-valuenow="'+t+'" aria-valuetext="'+moment(t)+'" aria-label="Select a video moment">'+(v.strip?.length?v.strip:Array(12).fill('')).map(url=>url?'<img alt="" loading="lazy" src="'+esc(url)+'">':'<span></span>').join('')+'<i id="feedback-playhead" data-keep-attrs style="left:'+Math.min(100,t/dur*100)+'%"></i>'+notes.map(n=>'<i class="feedback-pin" style="left:'+Math.min(99,n.start/dur*100)+'%" title="'+esc(n.text)+'"></i>').join('')+'</div>'+
 '<div class="timeline-ends" aria-hidden="true"><span>0:00</span><span>'+A.fmtTime(dur)+'</span></div><div class="moment-transport"><button class="play moment-play" data-act="playpause" aria-label="Play">'+A.icon('play')+'</button><span class="time" id="tc">'+moment(t)+' <small>/ '+A.fmtTime(dur)+'</small></span>'+'<select aria-label="Feedback video version" data-change="reviewVersion">'+(p.versions||[]).map(x=>'<option value="'+x.n+'"'+(x.n===v.n?' selected':'')+'>Version '+x.n+'</option>').join('')+'</select>'+'</div><div class="edit-feedback-card"><div class="edit-feedback-head"><h2>Edit feedback</h2><span>'+notes.length+' '+(notes.length===1?'edit':'edits')+'</span></div><p class="creative-hint">Pause the video. Tell me what to edit.</p><div class="moment-compose"><div class="moment-at"><span class="moment-dot"></span><b id="feedback-moment">'+moment(t)+'</b><span class="feedback-frame-stamp" id="feedback-frame">Frame '+Math.round(t*30)+'</small></div><textarea data-input="timelineDraft" data-field="text" data-free maxlength="4000" rows="2" placeholder="What should change here?" aria-label="Change this moment"'+(busy?' disabled':'')+'>'+esc(d.text||'')+'</textarea><div class="moment-compose-foot"><button class="btn btn-line btn-sm" data-act="saveTimelineNote"'+(busy?' disabled':'')+'>'+(A.ui.savingTimeline?'Saving…':'Add edit ↓')+'</button></div></div>'+
 (notes.length?'<div class="moment-notes" aria-label="Edits for this version">'+notes.map((n,i)=>'<article style="--note-rgb:'+noteColor(n,i)+';--note-order:'+i+'" data-key="note-'+esc(n.id)+'" data-note="'+esc(n.id)+'"><button class="note-time" data-act="noteJump" data-time="'+n.start+'" aria-label="Go to '+moment(n.start)+'">'+moment(n.start)+'</button><p>'+esc(n.text)+'</p>'+(n.status==='saved'?'<button class="moment-remove" data-act="removeTimelineNote" data-id="'+esc(n.id)+'" aria-label="Remove change '+(i+1)+'"'+(busy?' disabled':'')+'>×</button>':'<small>'+({received:'Sent',editing:'Editing',ready:'Updated'}[n.status]||'Saved')+'</small>')+'</article>').join('')+'</div>':'')+
 '<div class="moment-submit"><button class="btn btn-ink" data-act="updateTimelineVideo"'+(busy||jobActive||(!todo.length&&!d.text?.trim())?' disabled':'')+'>'+(A.ui.sendingTimeline?'Starting your edit…':'Update video with this feedback')+'</button><p role="status">'+esc((jobActive?'Your edit is running. You can save more notes for the next pass.':A.ui.timelineMessages?.[k])||(todo.length?todo.length+' '+(todo.length===1?'edit':'edits')+' ready.':((A.state.editor?.enabled||A.nativeChat?.available)?'Your original video stays safe.':'Your changes are saved.')))+'</p></div></div></section>';
};
function project(){return (A.state?.projects||[]).find(p=>p.name===A.ui.studioProject);}
async function saveChoices(p,ch){
 if(A.ui.savingChoices)return false;A.ui.savingChoices=true;A.render();
 try{await A.api.brief(p.name,{library_choices:ch});p.settings=p.settings||{};p.settings.library_choices=ch;const current=(A.state.projects||[]).find(x=>x.name===p.name);if(current){current.settings=current.settings||{};current.settings.library_choices=ch;}return true;}catch(e){A.toast(e.message,'alert','err');return false;}finally{A.ui.savingChoices=false;A.render();}
}
A.actions.libraryPick=async el=>{
 const p=project(),e=rows.find(e=>e.id===el.dataset.id);if(!p||!e)return;
 if(A.ui.savingChoices)return;
 const ch=JSON.parse(JSON.stringify(chosen(p)));if(e.kind==='effect'){ch.effects_mode='replace';ch.effects=ch.effects||[];ch.effects=active(p,e)?ch.effects.filter(v=>v.id!==e.id):[...ch.effects.filter(v=>v.id!==e.id),{id:e.id,version:e.version}];}else if(active(p,e)) delete ch[e.kind];else ch[e.kind]={id:e.id,version:e.version};
 return saveChoices(p,ch);
};
A.actions.libraryRemove=async el=>{const p=project();if(!p)return;const ch=JSON.parse(JSON.stringify(chosen(p))),id=el.dataset.id;
 if(id.startsWith('effect:'))ch.effects_mode='replace';ch.effects=(ch.effects||[]).filter(x=>x.id!==id);for(const kind of ['look','caption'])if(ch[kind]?.id===id)delete ch[kind];
 return saveChoices(p,ch);
};
A.actions.libraryPlacement=async el=>{const p=project();if(!p)return;const ch=JSON.parse(JSON.stringify(chosen(p)));ch.placements={...(ch.placements||{}),[el.dataset.id]:el.value==='range'?{mode:'range',start:0,end:3}:el.value};return saveChoices(p,ch);};
A.actions.saveEffectTime=async el=>{const p=project(),box=el.closest('.effect-time');if(!p||!box)return;const ch=JSON.parse(JSON.stringify(chosen(p)));ch.placements={...(ch.placements||{}),[box.dataset.effect]:{mode:'range',start:+box.querySelector('[data-time=start]').value,end:+box.querySelector('[data-time=end]').value}};if(await saveChoices(p,ch))A.toast('Effect time saved.','check');};
A.actions.reviewVersion=el=>{const p=project();if(!p)return;A.ui.reviewVersions={...(A.ui.reviewVersions||{}),[p.name]:+el.value};A.render();};
function draft(){const p=project();if(!p)return;const k=key(p);A.ui.timelineDrafts=A.ui.timelineDrafts||{};return A.ui.timelineDrafts[k]=A.ui.timelineDrafts[k]||{};}
A.actions.timelineDraft=el=>{const d=draft();if(!d)return;delete d.request_id;d[el.dataset.field]=el.type==='checkbox'?el.checked:el.type==='number'?+el.value:el.value;A.saveUI();const submit=document.querySelector('[data-act=updateTimelineVideo]');if(submit){const p=project(),todo=(p?.annotations||[]).some(n=>n.version===C.version(p)&&n.status==='saved');submit.disabled=!!A.ui.sendingTimeline||!!A.ui.savingTimeline||['queued','starting','editing','waiting_approval','recovering'].includes(p?.editor_job?.state)||(!todo&&!d.text?.trim());}};
function captureMoment(t,video){
 const p=project(),d=draft();if(!p||!d||!Number.isFinite(t)||(video&&document.getElementById("mon")!==video))return;
 const dur=Number.isFinite(video?.duration)?video.duration:Number(C.video(p)?.duration)||1;
 const frame=Math.max(0,Math.min(Math.round(t*30),Math.ceil(dur*30)-1));t=frame/30;
 if(d.start!==+t.toFixed(6))delete d.request_id;d.start=d.end=+t.toFixed(6);A.saveUI();
 const label=document.getElementById('feedback-moment');if(label)label.textContent=moment(t);const frameLabel=document.getElementById('feedback-frame');if(frameLabel)frameLabel.textContent='Frame '+frame;
 const film=document.querySelector('.feedback-film');if(film){film.setAttribute('aria-valuenow',String(t));film.setAttribute('aria-valuetext',moment(t));}
 const h=document.getElementById('feedback-playhead');if(h)h.style.left=(t/dur*100)+'%';
}
function seek(t){const v=document.getElementById('mon');if(v){t=Math.max(0,Math.min(t,(Number.isFinite(v.duration)?v.duration:1)-1/30));v.pause();v.currentTime=t;}captureMoment(t,v);}
A.actions.timelineSeek=(el,event)=>{const v=document.getElementById('mon');if(v&&Number.isFinite(v.duration)){const r=el.getBoundingClientRect();seek(Math.max(0,Math.min(1,(event.clientX-r.left)/r.width))*v.duration);}};
A.actions.noteJump=el=>seek(+el.dataset.time);
function putNote(pid,note){const p=(A.state.projects||[]).find(x=>x.name===pid);if(p){p.annotations=p.annotations||[];const old=p.annotations.findIndex(x=>x.id===note.id);if(old<0)p.annotations.push(note);else p.annotations[old]=note;}}
async function persistNote(p,version,k,d){
 if(!d.text?.trim())return;
 if(!Number.isFinite(d.start))d.start=0;if(!Number.isFinite(d.end))d.end=d.start;
 d.request_id=d.request_id||crypto.randomUUID();A.saveUI();
 const result=await A.api.timelineNote(p.name,{...d,version,scope:d.remember?'creator':'project'});putNote(p.name,result.note);
 // Retain a newer draft if a response arrives after navigation or another input.
 if(A.ui.timelineDrafts?.[k]===d)A.ui.timelineDrafts[k]={start:d.start,end:d.end};if(project()?.name===p.name&&C.version(project())===version){const input=document.querySelector('.moment-compose textarea');if(input)input.value='';}A.saveUI();return result.note;
}
A.actions.saveTimelineNote=async()=>{
 const p=project(),d=draft();if(!p||!d||A.ui.savingTimeline||A.ui.sendingTimeline)return;
 if(!d.text?.trim()){document.querySelector('.feedback-timeline textarea')?.focus();return;}
 const k=key(p),version=C.version(p),from=document.querySelector('.moment-compose textarea')?.getBoundingClientRect(),before=Object.fromEntries(Array.from(document.querySelectorAll('.moment-notes article')).map(el=>[el.dataset.note,el.getBoundingClientRect().top]));A.ui.savingTimeline=true;A.render();
 try{const note=await persistNote(p,version,k,d);if(note)A.ui.noteMotion={project:p.name,version,id:note.id,top:from?.top,before};A.ui.timelineMessages[k]='Edit saved. Add another or click Edit video.';}catch(e){A.toast(e.message,'alert','err');}finally{A.ui.savingTimeline=false;A.render();}
};
A.actions.removeTimelineNote=async el=>{
 const p=project();if(!p||A.ui.sendingTimeline||A.ui.savingTimeline)return;
 A.ui.savingTimeline=true;A.render();try{const r=await A.api.timelineRemove(p.name,el.dataset.id);putNote(p.name,r.note);}catch(e){A.toast(e.message,'alert','err');}finally{A.ui.savingTimeline=false;A.render();}
};
A.actions.updateTimelineVideo=async()=>{
 const p=project();if(!p||A.ui.sendingTimeline||A.ui.savingTimeline)return;
 if(['queued','starting','editing','waiting_approval','recovering'].includes(p.editor_job?.state)){A.toast('Your edit is running. Your new notes stay saved for the next pass.','info');return;}
 const version=C.version(p),k=key(p),d=draft();document.getElementById('mon')?.pause();A.ui.timelineSendingProject=p.name;A.ui.sendingTimeline=true;A.render();
 A.ui.timelineMessages=A.ui.timelineMessages||{};
 try{
  if(d?.text?.trim())await persistNote(p,version,k,d);
  const current=(A.state.projects||[]).find(x=>x.name===p.name)||p;
  const notes=(current.annotations||[]).filter(n=>n.version===version&&n.status==='saved');if(!notes.length)return;
  const batch=await A.api.timelineBatch(p.name,version,notes.map(n=>n.id));
  const text=batch.prompt;

  const managed=true;
  const r=await A.api.editorDispatch(p.name,batch.request_id||batch.id);if(!r?.accepted)throw new Error('Delivery was not confirmed. Your changes are saved.');
  A.markEditAccepted(p.name,r,batch.request_id||batch.id,Date.now()/1000);
  A.ui.editJustStarted=p.name;
  // Delivery is distinct from actual editing. Real workflow activity switches to the editing animation.
  A.ui.timelineMessages[k]=managed?'Starting your saved changes…':'Request delivered. Waiting for editing activity…';if(managed)await A.api.state().then(A.setState).catch(()=>{});A.ui.timelineDelivery=A.ui.timelineDelivery||{};A.ui.timelineDelivery[k]={at:Date.now(),batch:batch.id};setTimeout(()=>{const current=(A.state.projects||[]).find(x=>x.name===p.name);const w=current?.workflow||{};if(!A.state.editor?.enabled&&Date.now()-(A.ui.timelineDelivery?.[k]?.at||0)>=30000&&(!(Number(w.updated)*1000>=A.ui.timelineDelivery[k].at)||!['analysing','planning','building','reviewing','ready'].includes(w.phase))){A.ui.timelineMessages[k]='Request delivered, but editing has not started. Your changes are saved.';A.saveUI();A.render();}},31000);
  for(const n of notes)putNote(p.name,{...n,status:'received'});try{await A.api.timelineBatchReceived(p.name,batch.id);}catch(e){A.ui.timelineMessages[k]='Changes sent. Saved-note status will refresh shortly.';}
 }catch(e){A.ui.timelineMessages[k]=e.message;A.toast('Editing has not been confirmed. '+e.message,'alert','err');}finally{A.ui.sendingTimeline=false;delete A.ui.timelineSendingProject;A.saveUI();A.render();}
};
// A true, larger playback preview, separate from selecting a recipe. No preferences are learned by browsing.
A.actions.libraryPreview=el=>{
 const e=rows.find(x=>x.id===el.dataset.id),owner=project()?.name;if(!e?.preview||!owner)return;
 document.querySelector('.look-dialog')?.close();observed.forEach(v=>stopPreview(v,true));
 const dialog=document.createElement('dialog');dialog.className='look-dialog';dialog.setAttribute('aria-label',e.name+' preview');
 const head=document.createElement('div');head.className='look-dialog-head';const title=document.createElement('h2');title.textContent=e.name;const close=document.createElement('button');close.textContent='×';close.setAttribute('aria-label','Close preview');close.onclick=()=>dialog.close();head.append(title,close);
 const video=document.createElement('video');video.src=e.preview;video.poster=e.poster||'';video.muted=true;video.loop=true;video.playsInline=true;video.controls=true;video.preload='metadata';
 const error=document.createElement('p');error.className='look-dialog-error';error.hidden=true;error.textContent='The preview couldn’t load. Close it and try again.';video.addEventListener('error',()=>error.hidden=false);
 const foot=document.createElement('div');foot.className='look-dialog-foot';const description=document.createElement('p');description.textContent=e.look||e.line||e.does||'';const select=document.createElement('button');select.className='btn btn-ink';select.textContent=active(project(),e)?'Remove selection':'Use this '+(e.kind==='look'?'style':e.kind);select.dataset.id=e.id;select.onclick=async()=>{if(project()?.name!==owner){dialog.close();return;}select.disabled=true;await A.actions.libraryPick(select);dialog.close();};foot.append(description,select);dialog.append(head,video,error,foot);document.body.append(dialog);
 const opener=el;dialog.addEventListener('close',()=>{video.pause();video.removeAttribute('src');video.load();dialog.remove();if(opener.isConnected)opener.focus();});dialog.addEventListener('click',ev=>{if(ev.target===dialog){const r=dialog.getBoundingClientRect();if(ev.clientX<r.left||ev.clientX>r.right||ev.clientY<r.top||ev.clientY>r.bottom)dialog.close();}});dialog.showModal();if(!A.reduced)video.play().catch(()=>{});
};
const sending=new Set();
A.actions.sendTimelineNote=async el=>{
 const p=project(),n=p?.annotations?.find(n=>n.id===el.dataset.id);if(!n||sending.has(n.id))return;
 const text='Please apply timeline note '+n.id+' in project '+p.name+', saved version '+n.version+', '+n.start.toFixed(3)+'–'+n.end.toFixed(3)+'s: '+n.text+'. Read annotations.json for exact source/scene binding; map before applying to a newer cut.'+(n.scope==='creator'?' Also remember the lasting preference for future videos.':' Apply to this video only.');
 if(!A.nativeChat?.available){A.toast('Your note is saved. Connect Studio to this conversation before sending.','alert');return;}
 sending.add(n.id);
 try{const r=await A.nativeChat.send(p.name,text);if(r.accepted){await A.api.timelineReceived(p.name,n.id);n.status='received';A.render();}}catch(e){A.toast(e.message,'alert','err');}finally{sending.delete(n.id);}
};
let visible=new Set();let observed=new Set();let playing;
function stopPreview(v,release=false){v.pause();v.removeAttribute('data-preview-ready');if(playing===v)playing=null;if(release&&v.hasAttribute('src')){v.removeAttribute('src');v.load();}}
document.addEventListener('visibilitychange',()=>{if(document.hidden)observed.forEach(v=>stopPreview(v,true));});
const reduced=window.matchMedia?.('(prefers-reduced-motion: reduce)');reduced?.addEventListener?.('change',e=>{A.reduced=e.matches;if(e.matches)observed.forEach(v=>stopPreview(v,true));});
const observer='IntersectionObserver' in window?new IntersectionObserver(entries=>entries.forEach(x=>{if(x.isIntersecting)visible.add(x.target);else{visible.delete(x.target);stopPreview(x.target,true);}})):null;
const frameRequests=new Map(),feedbackPlayers=new Set();
C.bind=()=>{
 if(A.ui.editJustStarted===project()?.name&&['queued','starting','editing','recovering','waiting_approval'].includes(project()?.editor_job?.state)&&!A.ui.sendingTimeline){delete A.ui.editJustStarted;document.querySelector('.ed')?.scrollIntoView({behavior:A.reduced?'auto':'smooth',block:'start'});}
 for(const old of feedbackPlayers)if(!old.isConnected){old._feedbackCleanup?.();feedbackPlayers.delete(old);}
 const motion=A.ui.noteMotion;
 if(motion&&project()?.name===motion.project&&C.version(project())===motion.version){
  const row=Array.from(document.querySelectorAll('.moment-notes article')).find(el=>el.dataset.note===motion.id);
  if(row){delete A.ui.noteMotion;if(!A.reduced&&row.animate){const delta=Number.isFinite(motion.top)?motion.top-row.getBoundingClientRect().top:-55;row.animate([{transform:'translateY('+Math.min(-24,delta)+'px)',opacity:.1,filter:'blur(3px)'},{transform:'translateY(0)',opacity:1,filter:'blur(0)'}],{duration:1050,easing:'cubic-bezier(.16,1,.3,1)'});for(const other of document.querySelectorAll('.moment-notes article')){const old=motion.before?.[other.dataset.note];if(other!==row&&Number.isFinite(old)){const dy=old-other.getBoundingClientRect().top;if(Math.abs(dy)>1)other.animate([{transform:'translateY('+dy+'px)'},{transform:'translateY(0)'}],{duration:950,easing:'cubic-bezier(.16,1,.3,1)'});}}}const input=document.querySelector('.moment-compose textarea');if(input&&!input.disabled)input.focus({preventScroll:true});}
 }

 for(const video of observed)if(!video.isConnected){stopPreview(video,true);observer?.unobserve(video);observed.delete(video);visible.delete(video);if(playing===video)playing=null;}
 const p=project(),version=p&&C.video(p);
 if(document.querySelector('.feedback-timeline')&&version&&!version.strip?.length&&A.api.timelineFrames&&Date.now()-(frameRequests.get(key(p))||0)>60000){
  frameRequests.set(key(p),Date.now());A.api.timelineFrames(p.name,version.n).catch(()=>{});
 }

 document.querySelectorAll('[data-creative-details]').forEach(d=>{if(d._cc)return;d._cc=true;d.addEventListener('toggle',()=>{A.ui.lookOpen={...(A.ui.lookOpen||{}),[d.dataset.creativeDetails]:d.open};if(!d.open)d.querySelectorAll('video').forEach(v=>stopPreview(v,true));});});
 document.querySelectorAll('[data-library-preview]').forEach(v=>{if(v._cc)return;v._cc=true;v.addEventListener('loadeddata',()=>{if(playing===v&&!A.reduced)v.setAttribute('data-preview-ready','true');});v.addEventListener('error',()=>{v.pause();v.removeAttribute('data-preview-ready');v.removeAttribute('src');});observer?.observe(v);observed.add(v);const b=v.closest('button');b.addEventListener('pointerenter',()=>{if(A.reduced||!v.closest('details')?.open)return;if(playing&&playing!==v)stopPreview(playing,true);if(!v.src)v.src=v.dataset.src;playing=v;if(v.readyState>=2)v.setAttribute('data-preview-ready','true');v.play().catch(()=>stopPreview(v));});b.addEventListener('pointerleave',()=>stopPreview(v,true));b.addEventListener('focus',()=>b.dispatchEvent(new Event('pointerenter')));b.addEventListener('blur',()=>stopPreview(v,true));});
 const v=document.getElementById('mon');const film=document.querySelector('.feedback-film');if(film&&!film._key){film._key=true;film.addEventListener('keydown',event=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;event.preventDefault();const mon=document.getElementById('mon');if(mon)seek(event.key==='Home'?0:event.key==='End'?mon.duration:mon.currentTime+(event.key==='ArrowRight'?1:-1)/30);});}if(v&&!v._feedback){
  v._feedback=true;let raf=0;
  const paint=()=>{if(!v.isConnected)return;const t=v.currentTime,dur=v.duration;const h=document.getElementById('feedback-playhead');if(h&&dur)h.style.left=(t/dur*100)+'%';const clock=document.getElementById('tc');if(clock&&Number.isFinite(dur))clock.textContent=moment(t)+' / '+A.fmtTime(dur);const film=document.querySelector('.feedback-film');if(film&&dur)film.setAttribute('aria-valuenow',String(t));};
  const stop=()=>{cancelAnimationFrame(raf);raf=0;};
  const tick=()=>{raf=0;if(!v.isConnected||v.paused||v.ended||document.hidden)return;paint();raf=requestAnimationFrame(tick);};
  const start=()=>{stop();paint();if(!v.paused&&!document.hidden)raf=requestAnimationFrame(tick);};
  const restore=()=>{const d=draft();if(d?.start>0&&d.start<v.duration){v.currentTime=d.start;captureMoment(d.start,v);}paint();};if(v.readyState>=1)restore();else v.addEventListener('loadedmetadata',restore,{once:true});
  v.addEventListener('play',start);v.addEventListener('pause',()=>{stop();paint();captureMoment(v.currentTime,v);});v.addEventListener('ended',()=>{stop();paint();captureMoment(v.currentTime,v);});v.addEventListener('seeked',()=>{paint();if(v.paused)captureMoment(v.currentTime,v);});v.addEventListener('timeupdate',()=>{if(v.paused||document.hidden)paint();});
  const visibility=()=>{if(!v.isConnected){stop();document.removeEventListener('visibilitychange',visibility);return;}document.hidden?stop():start();};document.addEventListener('visibilitychange',visibility);v._feedbackCleanup=()=>{stop();document.removeEventListener('visibilitychange',visibility);};feedbackPlayers.add(v);start();
 }
};
})();
