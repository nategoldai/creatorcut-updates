#!/usr/bin/env bash
# CreatorCut OS: one-step installer for Mac and Linux.
#
#   bash kit/setup/install.sh               install (Claude Code shows the Studio in its Browser pane)
#   Studio is opened by the editor inside the host app after setup. Legacy --open no longer launches a browser.
#   bash kit/setup/install.sh --wait python wait until the private Python is ready (so the Studio can start), then exit
#
# Needs no password and no admin rights, and changes nothing outside this folder (plus the
# standard download cache). It downloads:
#   - FFmpeg + ffprobe (portable builds with caption support)  -> kit/bin/
#   - uv + a private Python 3.12                               -> kit/bin/
#   - the editing engine's Python packages                     -> .venv/
#   - a private Node 22 + HyperFrames + Remotion + headless browser (motion graphics) -> kit/bin/node, kit/render/
#   - the HyperFrames and Remotion skills for Claude Code      -> .claude/skills, .agents/skills
#   - text recognition + person detection (reading references) -> .venv/
#   - fonts, sound effects, and the speech model               -> kit/fonts, kit/sfx, model cache
# Progress is written live to kit/studio-out/progress.js, which Studio.html shows.
# Safe to run again: finished steps are skipped, so after a timeout just run it again.

set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT" || exit 1
KIT="$ROOT/kit"; BIN="$KIT/bin"; OUT="$KIT/studio-out"
PJS="$OUT/progress.js"; BEAT="$OUT/beat.js"; PIDF="$OUT/install.pid"; LOG="$OUT/install.log"
mkdir -p "$BIN" "$OUT"
export UV_PYTHON_INSTALL_DIR="$BIN/python"
export UV_CACHE_DIR="${UV_CACHE_DIR:-$BIN/cache}"
export PIP_DISABLE_PIP_VERSION_CHECK=1
OS="$(uname -s)"; ARCH="$(uname -m)"
case "$OS" in Darwin) PLAT=mac ;; *) PLAT=linux ;; esac
VPY="$ROOT/.venv/bin/python"
STEPS="python engine packages motion vision extras model studio"
NSTEPS=8
OPEN=0; WAIT=""; SKIP_MODEL=0; NO_SHORTCUT=1
while [ $# -gt 0 ]; do case "$1" in --open) echo "Studio opens inside your AI host. Ask your editor to open CREATORCUT after setup." ;; --skip-model) SKIP_MODEL=1 ;; --no-shortcut) NO_SHORTCUT=1 ;; --wait) WAIT="${2:-python}"; shift ;; esac; shift; done

# ------------------------------------------- --wait python: for the agent ----
if [ -n "$WAIT" ]; then
  for _ in $(seq 1 240); do
    if [ -x "$VPY" ] && "$VPY" -c 'import sys' 2>/dev/null; then echo "PYTHON_READY=1"; exit 0; fi
    if ! { [ -f "$PIDF" ] && kill -0 "$(cat "$PIDF" 2>/dev/null)" 2>/dev/null; }; then
      sleep 2; [ -x "$VPY" ] && { echo "PYTHON_READY=1"; exit 0; }
      echo "INSTALLER_NOT_RUNNING=1"; exit 2
    fi
    sleep 1
  done
  echo "PYTHON_READY=0"; exit 3
fi

# ---------------------------------------------------------------- helpers ----
say()  { printf '%s\n' "$*"; }
now()  { date +%s; }
STATE=running; CURRENT=""; ERROR_MSG=""; STARTED="$(now)"
for s in $STEPS; do eval "S_$s=todo; T0_$s=0; T1_$s=0"; done

write_progress() {
  local body="" sep="" st t0 t1 err="null"
  for s in $STEPS; do
    eval "st=\$S_$s; t0=\$T0_$s; t1=\$T1_$s"
    body="$body$sep\"$s\":{\"state\":\"$st\",\"start\":$t0,\"end\":$t1}"; sep=","
  done
  [ -n "$ERROR_MSG" ] && err="\"$ERROR_MSG\""
  printf 'window.AIE_PROGRESS = {"state":"%s","current":"%s","started":%s,"updated":%s,"os":"%s","error":%s,"order":["python","engine","packages","motion","vision","extras","model","studio"],"steps":{%s}};\n' \
    "$STATE" "$CURRENT" "$STARTED" "$(now)" "$PLAT" "$err" "$body" > "$PJS.tmp" && mv -f "$PJS.tmp" "$PJS"
}
begin() { CURRENT="$1"; eval "S_$1=running; T0_$1=$(now)"; write_progress; say ""; say "[$2/$NSTEPS] $3"; }
finish() { eval "S_$1=${2:-done}; T1_$1=$(now)"; write_progress; }
skip() { eval "S_$1=done; T0_$1=$(now); T1_$1=$(now)"; }
fail() {
  # $1 = step, $2 = plain-language message for the creator (no quotes)
  eval "S_$1=error; T1_$1=$(now)"; STATE=error; ERROR_MSG="$2"; write_progress
  say ""; say "✗ $2"; say "SETUP_STATUS=error"; say "SETUP_STEP=$1"; say "LOG=kit/studio-out/install.log"
  exit 1
}
dl() {  # dl URL FILE
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL --retry 3 --retry-delay 2 --connect-timeout 20 -o "$2" "$1" >>"$LOG" 2>&1
  else
    wget -q -O "$2" "$1" >>"$LOG" 2>&1
  fi
}
open_studio() {
  if [ "$PLAT" = mac ]; then open "$ROOT/Studio.html" >/dev/null 2>&1 || true
  else (xdg-open "$ROOT/Studio.html" >/dev/null 2>&1 &) || true; fi
}
has_libass() { "$1" -hide_banner -filters 2>/dev/null | grep -qE '^ *[A-Z.|]+ +ass +'; }

# ----------------------------------------------- only one installer at once ----
if [ -f "$PIDF" ] && kill -0 "$(cat "$PIDF" 2>/dev/null)" 2>/dev/null; then
  say "The installer is already running. Waiting for it to finish (progress is in Studio.html)…"
  while kill -0 "$(cat "$PIDF" 2>/dev/null)" 2>/dev/null; do sleep 5; done
  say "The other installer finished. Checking everything…"
fi
echo $$ > "$PIDF"
MAINPID=$$
( while kill -0 "$MAINPID" 2>/dev/null; do printf 'window.AIE_BEAT = %s;\n' "$(date +%s)" > "$BEAT"; sleep 3; done ) &
BEATPID=$!
trap 'kill $BEATPID 2>/dev/null; wait $BEATPID 2>/dev/null; rm -f "$PIDF"' EXIT
: > "$LOG"

say "CreatorCut OS setup ($PLAT, $ARCH). Nothing to do for you: the Studio shows the progress."
write_progress
[ "$OPEN" = 1 ] && open_studio

# -------------------------------------------------- 1. private Python (uv) ----
UV="$BIN/uv"
if [ -x "$VPY" ] && "$VPY" -c 'import sys; assert sys.version_info >= (3, 9)' 2>/dev/null; then
  skip python; say "[1/8] Private Python: already installed ✓"
else
  begin python 1 "Setting up a private Python (about 30 MB)…"
  if [ ! -x "$UV" ]; then
    case "$PLAT-$ARCH" in
      mac-arm64) T=aarch64-apple-darwin ;; mac-*) T=x86_64-apple-darwin ;;
      linux-aarch64|linux-arm64) T=aarch64-unknown-linux-gnu ;; *) T=x86_64-unknown-linux-gnu ;;
    esac
    TMP="$BIN/tmp-uv"; rm -rf "$TMP"; mkdir -p "$TMP"
    if dl "https://github.com/astral-sh/uv/releases/latest/download/uv-$T.tar.gz" "$TMP/uv.tgz" && \
       (cd "$TMP" && tar -xzf uv.tgz) >>"$LOG" 2>&1; then
      u="$(find "$TMP" -type f -name uv | head -1)"; [ -n "$u" ] && mv -f "$u" "$UV" && chmod +x "$UV"
    fi
    rm -rf "$TMP"
    [ -x "$UV" ] || { s="$(command -v uv)"; [ -n "$s" ] && ln -sf "$s" "$UV"; }
  fi
  [ -x "$UV" ] || fail python "The Python helper could not be downloaded. Check the internet connection and run setup again."
  rm -rf "$ROOT/.venv"
  if [ -n "${AIE_PYTHON:-}" ]; then   # test hook: use a given interpreter
    "$UV" venv --python "$AIE_PYTHON" ${AIE_VENV_ARGS:-} "$ROOT/.venv" >>"$LOG" 2>&1
  else
    "$UV" venv --python 3.12 --python-preference only-managed "$ROOT/.venv" >>"$LOG" 2>&1
  fi
  [ -x "$VPY" ] || fail python "A private Python could not be set up. Check the internet connection and run setup again."
  finish python; say "  ✓ Private Python ready"
fi
# Codex / no Browser pane: start the Studio server in the background and open it in the default browser
[ "$OPEN" = 1 ] && "$VPY" "$ROOT/edit.py" studio open >>"$LOG" 2>&1 &

# ------------------------------------------------- 2. video engine (FFmpeg) ----
FF="$BIN/ffmpeg"; FP="$BIN/ffprobe"
if [ -x "$FF" ] && [ -x "$FP" ] && has_libass "$FF"; then
  skip engine; say "[2/8] Video engine: already installed ✓"
else
  begin engine 2 "Downloading the video engine (FFmpeg, about 80 MB)…"
  TMP="$BIN/tmp-ffmpeg"; rm -rf "$TMP"; mkdir -p "$TMP"
  ok=0
  if [ "$PLAT" = mac ]; then
    A=arm64; [ "$ARCH" = x86_64 ] && A=amd64
    base="https://ffmpeg.martin-riedl.de/redirect/latest/macos/$A/release"
    if dl "$base/ffmpeg.zip" "$TMP/ffmpeg.zip" && dl "$base/ffprobe.zip" "$TMP/ffprobe.zip"; then
      (cd "$TMP" && unzip -o -q ffmpeg.zip -d x1 && unzip -o -q ffprobe.zip -d x2) >>"$LOG" 2>&1
      f1="$(find "$TMP/x1" -type f -name ffmpeg | head -1)"; f2="$(find "$TMP/x2" -type f -name ffprobe | head -1)"
      [ -n "$f1" ] && [ -n "$f2" ] && mv -f "$f1" "$f2" "$BIN/" && ok=1
    fi

  else
    A=linux64; case "$ARCH" in aarch64|arm64) A=linuxarm64 ;; esac
    url="https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-$A-gpl.tar.xz"
    if dl "$url" "$TMP/ff.tar.xz" && (cd "$TMP" && tar -xJf ff.tar.xz) >>"$LOG" 2>&1; then
      d="$(find "$TMP" -type f -name ffmpeg -path '*/bin/*' | head -1)"
      [ -n "$d" ] && mv -f "$d" "$(dirname "$d")/ffprobe" "$BIN/" && ok=1
    fi
    if [ $ok = 0 ] && command -v ffmpeg >/dev/null && command -v ffprobe >/dev/null && has_libass "$(command -v ffmpeg)"; then
      ln -sf "$(command -v ffmpeg)" "$BIN/ffmpeg"; ln -sf "$(command -v ffprobe)" "$BIN/ffprobe"; ok=1
    fi
  fi
  rm -rf "$TMP"
  chmod +x "$BIN/ffmpeg" "$BIN/ffprobe" 2>/dev/null
  [ "$PLAT" = mac ] && xattr -d com.apple.quarantine "$BIN/ffmpeg" "$BIN/ffprobe" 2>/dev/null
  if [ $ok = 1 ] && "$BIN/ffmpeg" -hide_banner -version >/dev/null 2>&1 && has_libass "$BIN/ffmpeg"; then
    finish engine; say "  ✓ Video engine ready"
  else
    rm -f "$BIN/ffmpeg" "$BIN/ffprobe"
    fail engine "The video engine could not be downloaded. Check the internet connection and run setup again."
  fi
fi

# ------------------------------------------------ 3. editing engine packages ----
if "$VPY" -c 'import faster_whisper, PIL, certifi, yt_dlp' 2>/dev/null; then
  skip packages; say "[3/8] Editing tools: already installed ✓"
else
  begin packages 3 "Installing the editing tools (speech recognition and images, about 150 MB)…"
  [ -x "$UV" ] || { s="$(command -v uv)"; [ -n "$s" ] && UV="$s"; }
  if [ -x "$UV" ]; then "$UV" pip install --python "$VPY" -r "$KIT/requirements.txt" >>"$LOG" 2>&1
  else "$VPY" -m pip install -q -r "$KIT/requirements.txt" >>"$LOG" 2>&1; fi
  "$VPY" -c 'import faster_whisper, PIL, certifi, yt_dlp' 2>/dev/null || \
    fail packages "The editing tools could not be installed. Check the internet connection and run setup again."
  finish packages; say "  ✓ Editing tools ready"
fi

# --------------------------------------------- 4. fonts and sound effects ----
# ------------------------------------- 4. motion graphics (Node + HyperFrames + Remotion) ----
NODE_DIR="$BIN/node"; NODE="$NODE_DIR/bin/node"; NPM="$NODE_DIR/bin/npm"; RENDER="$KIT/render"
motion_ready() {
  [ -x "$NODE" ] && "$NODE" "$KIT/setup/verify-render.cjs" "$RENDER" && "$NODE" -e 'process.exit(+process.versions.node.split(".")[0] >= 22 ? 0 : 1)' 2>/dev/null && \
  [ -f "$RENDER/node_modules/hyperframes-library/bin/hyperframes.mjs" ] && [ -x "$RENDER/node_modules/.bin/hyperframes" ] && [ -x "$RENDER/node_modules/.bin/remotion" ] && \
  [ -n "$(ls -d "$RENDER"/node_modules/.remotion/chrome-headless-shell/*/chrome-headless-shell-*/chrome-headless-shell 2>/dev/null | head -1)" ] && \
  [ -f "$ROOT/.claude/skills/hyperframes/SKILL.md" ] && [ -f "$ROOT/.claude/skills/remotion-best-practices/SKILL.md" ]
}
if motion_ready; then
  skip motion; say "[4/$NSTEPS] Motion graphics: already installed ✓"
else
  begin motion 4 "Installing motion graphics: HyperFrames, Remotion and a private browser (about 350 MB)…"
  if ! { [ -x "$NODE" ] && "$NODE" -e 'process.exit(+process.versions.node.split(".")[0] >= 22 ? 0 : 1)' 2>/dev/null; }; then
    case "$PLAT-$ARCH" in mac-arm64) NA=darwin-arm64 ;; mac-*) NA=darwin-x64 ;; linux-aarch64|linux-arm64) NA=linux-arm64 ;; *) NA=linux-x64 ;; esac
    TMP="$BIN/tmp-node"; rm -rf "$TMP"; mkdir -p "$TMP"
    NV="$(curl -fsSL https://nodejs.org/dist/latest-v22.x/SHASUMS256.txt 2>>"$LOG" | grep -o "node-v22[0-9.]*-$NA.tar.gz" | head -1)"
    [ -n "$NV" ] && dl "https://nodejs.org/dist/latest-v22.x/$NV" "$TMP/node.tgz" && (cd "$TMP" && tar -xzf node.tgz) >>"$LOG" 2>&1 && \
      rm -rf "$NODE_DIR" && mv -f "$TMP/${NV%.tar.gz}" "$NODE_DIR"
    rm -rf "$TMP"
    [ -x "$NODE" ] || fail motion "The motion graphics engine could not be downloaded. Check the internet connection and run setup again."
  fi
  export PATH="$NODE_DIR/bin:$BIN:$PATH" npm_config_cache="$BIN/npm-cache" npm_config_update_notifier=false npm_config_fund=false npm_config_audit=false
  (cd "$RENDER" && "$NPM" ci --no-audit --no-fund --loglevel=error) >>"$LOG" 2>&1 || \
    fail motion "HyperFrames and Remotion could not be installed. Check the internet connection and run setup again."
  (cd "$RENDER" && ./node_modules/.bin/remotion browser ensure) >>"$LOG" 2>&1 || \
    fail motion "The rendering browser could not be downloaded. Check the internet connection and run setup again."
  # the agent skills that teach Claude HyperFrames and Remotion (project-level, no plugins or keys)
  for pack in heygen-com/hyperframes remotion-dev/skills; do
    (cd "$ROOT" && "$NODE_DIR/bin/npx" -y skills add "$pack" --all --agent claude-code -y </dev/null) >>"$LOG" 2>&1 || true
  done
  rm -rf "$ROOT/agent"                       # a copy the skills tool makes for other agents; Claude Code and Codex don't use it
  "$VPY" "$ROOT/kit/tools/sync_skills.py" >>"$LOG" 2>&1 || true   # skills in the exact format Claude Code and Codex accept
  motion_ready || fail motion "The motion graphics tools didn't finish installing. Run setup again; it continues where it stopped."
  finish motion; say "  ✓ Motion graphics ready"
fi
# wrappers so every engine command finds the private Node, FFmpeg and browser
CHROME="$(ls -d "$RENDER"/node_modules/.remotion/chrome-headless-shell/*/chrome-headless-shell-*/chrome-headless-shell 2>/dev/null | head -1)"
for tool in hyperframes remotion; do
  cat > "$BIN/$tool" <<WRAP
#!/usr/bin/env bash
export PATH="$NODE_DIR/bin:$BIN:\$PATH"
export HYPERFRAMES_BROWSER_PATH="$CHROME" HYPERFRAMES_SKIP_SKILLS=1 HYPERFRAMES_NO_TELEMETRY=1 DO_NOT_TRACK=1
if [ "$tool" = hyperframes ]; then exec "$NODE" "$RENDER/node_modules/hyperframes/bin/hyperframes.mjs" "\$@"; fi
exec "$RENDER/node_modules/.bin/$tool" "\$@"
WRAP
  chmod +x "$BIN/$tool"
done

# ------------------------------------- 5. reading references (text + person) ----
vision_ready() { if [ "$PLAT" = mac ]; then "$VPY" -c 'import ocrmac, Vision, scipy.ndimage, onnxruntime, cv2' 2>/dev/null; else "$VPY" -c 'import rapidocr_onnxruntime, scipy.ndimage, onnxruntime, cv2' 2>/dev/null; fi; }
if vision_ready; then
  skip vision; say "[5/$NSTEPS] Reference reading: already installed ✓"
else
  begin vision 5 "Installing text recognition and person detection (reads reference videos)…"
  if [ -x "$UV" ]; then "$UV" pip install --python "$VPY" -r "$KIT/requirements-vision.txt" >>"$LOG" 2>&1
  else "$VPY" -m pip install -q -r "$KIT/requirements-vision.txt" >>"$LOG" 2>&1; fi
  vision_ready || fail vision "Text recognition could not be installed. Check the internet connection and run setup again."
  finish vision; say "  ✓ Reference reading ready"
fi

begin extras 6 "Adding premium fonts and sound effects…"
"$VPY" "$ROOT/edit.py" fonts >>"$LOG" 2>&1 || say "  ! Some fonts didn't download; styles use built-in fonts instead."
"$VPY" "$ROOT/edit.py" calibrate >>"$LOG" 2>&1
"$VPY" "$ROOT/edit.py" sfx >>"$LOG" 2>&1
"$VPY" "$ROOT/edit.py" music-gen >>"$LOG" 2>&1
finish extras; say "  ✓ Fonts and sound effects ready"

# ------------------------------------------------------ 5. speech model ----
begin model 7 "Downloading speech recognition (about 500 MB, the longest step)…"
if [ "$SKIP_MODEL" = 1 ]; then finish model later; say "  Speech model deferred until first edit."
elif "$VPY" "$ROOT/edit.py" model >>"$LOG" 2>&1; then finish model; say "  ✓ Speech recognition ready"
else finish model later; say "  ! Speech model will download on the first edit instead (that's fine)."; fi

# ---------------------------------------------------------- 6. the Studio ----
begin studio 8 "Building your Studio…"
"$VPY" "$ROOT/edit.py" studio --thumbs >>"$LOG" 2>&1 || "$VPY" "$ROOT/edit.py" studio >>"$LOG" 2>&1
[ "$NO_SHORTCUT" = 1 ] || "$VPY" "$ROOT/edit.py" studio app >>"$LOG" 2>&1 || true      # the CreatorCut Studio app icon (Applications / Spotlight)
"$VPY" "$ROOT/kit/tools/install_shortcut.py" >>"$LOG" 2>&1 || say "  CreatorCut is installed; the chat shortcut can be retried from setup."
finish studio
rm -rf "$BIN/cache" "$BIN/npm-cache"
STATE=done; CURRENT=""; write_progress
say ""
say "✓ Everything is installed."
say "SETUP_STATUS=done"
