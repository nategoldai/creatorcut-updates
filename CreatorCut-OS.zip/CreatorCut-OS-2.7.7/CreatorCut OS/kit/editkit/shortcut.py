"""A per-user /creatorcut skill points to the installed app, never a system browser."""
from pathlib import Path
import json
from . import util
MARKER='CREATORCUT-OWNED-LAUNCHER-v1'

def install(home=None):
    home=Path(home) if home is not None else Path.home()
    registry=home/'.creatorcut/installations.json'
    old=util.read_json(registry,default={})
    app=str(util.ROOT.resolve())
    paths=list(dict.fromkeys([app]+old.get('installations',[])))[:20]
    util.write_json(registry,{'owner':MARKER,'active':app,'installations':paths})
    text='''---
name: creatorcut
description: "Open the installed CreatorCut Studio inside this AI host. Use for /creatorcut, open CreatorCut, or resume my CreatorCut videos."
---

# CreatorCut
<!-- '''+MARKER+''' -->
Read ~/.creatorcut/installations.json and select the existing active app folder, or the first existing installation containing kit/VERSION and AGENTS.md. Read that app's AGENTS.md and kit/skills-src/studio/SKILL.md. Do not install another copy when a working installation exists.

Open its current Studio in the host's supported embedded app/preview beside this conversation. Prefer its creatorcut_studio MCP App when that tool belongs to this installation. Otherwise run the private Python edit.py studio serve (yielding, not blocking), read its actual URL, and use the host's embedded-preview tool. In Codex use open_in_codex with a browser target and placement right. In Claude use its supported preview/launch tools. Never run open/start/xdg-open, webbrowser.open or an external browser. The document title is CREATORCUT.

Studio Make/Update use the app-owned persistent editor described in kit/docs/persistent-editor.md. Verify the managed supervisor and signed-in Codex account. Do not wait for a native foreground receiver or ask users to paste copied messages. This host chat remains a companion, not a mirror of the persistent session. Respect normal permissions and explain unavailable host capabilities factually.
'''
    codex=home/'.codex/skills' if (home/'.codex/skills').exists() else home/'.agents/skills'
    installed=[];conflicts=[]
    for root in (codex,home/'.claude/skills'):
        file=root/'creatorcut/SKILL.md'
        if file.exists() and MARKER not in file.read_text():conflicts.append(str(file));continue
        file.parent.mkdir(parents=True,exist_ok=True);file.write_text(text);installed.append(str(file))
    return {'installed':installed,'preserved_conflicts':conflicts,'registry':str(registry)}
