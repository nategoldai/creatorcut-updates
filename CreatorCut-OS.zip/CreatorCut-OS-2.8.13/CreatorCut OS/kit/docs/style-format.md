# Style format

Toolkit styles live in `kit/styles/*.json`. The creator's own styles live in `my-brand/styles/*.json` and take priority if a name matches. Any key you leave out falls back to the default. Start a new style by copying the closest toolkit style.

```json
{
  "name": "Bold Captions",
  "tagline": "One sentence a beginner understands.",
  "best_for": ["tips", "opinions"],
  "energy": 5,
  "fonts":   {"caption": "anton", "heading": "anton", "body": "inter-extrabold"},
  "colors":  {"text": "#FFFFFF", "accent": "#FFE500", "outline": "#000000",
              "card": "#111111", "card_text": "#FFFFFF", "muted": "#A1A1AA"},
  "captions": {"mode": "highlight", "max_words": 2, "max_chars": 14, "size": 108, "y": 0.64,
               "uppercase": true, "outline": 7, "shadow": 3, "highlight": "both",
               "pop": true, "keyword_accent": true, "box": false, "box_color": "#000000", "box_alpha": 0.6},
  "graphics": {"card_radius": 22, "card_alpha": 0.94, "shadow": true, "entrance": "pop",
               "title_style": "block", "title_case": "upper", "heading_size": 118, "body_size": 54,
               "tilt": 0, "sticker": false, "accent_bar": true},
  "zoom":   {"punch_in": 1.1, "pattern": "alternate", "emphasis": 1.18, "focus_y": 0.38},
  "grade":  "punchy",
  "sfx":    {"enabled": true, "volume": 0.38, "entrance": "whoosh", "emphasis": "thud",
             "list": "pop", "counter": "tick", "cta": "ding"},
  "pacing": {"max_pause": 0.16, "remove_fillers": true},
  "progress_bar": true,
  "use_brand_accent": true
}
```

## Options

**fonts** (keys): bundled: `inter`, `inter-medium`, `inter-semibold`, `inter-bold`, `inter-extrabold`, `inter-black`, `inter-display-semibold`, `inter-display-bold`, `inter-display-black`, `poppins`, `poppins-medium`, `poppins-bold`, `lora`, `lora-italic`. Font pack (downloaded at setup): `anton` (tall condensed, viral captions), `bebas` (condensed caps), `archivo-black` (heavy, wide), `dm-serif` (elegant serif titles), `instrument-serif` and `instrument-serif-italic` (premium editorial serif), `permanent-marker` (handwritten), `space-mono` (techy monospace numbers). A missing pack font falls back to a similar bundled one.

**captions.mode**: `highlight` (spoken word lights up), `reveal` (words appear as spoken), `pop` (each chunk pops in), `plain`.
**captions.highlight**: `color`, `scale`, `both`. **captions.y**: 0.6–0.75 of the frame height (lower is higher on screen). **box**: subtitles on a solid box; text colour is `colors.text`, box colour is `box_color`.

**graphics.entrance**: `slide`, `rise`, `pop`, `stamp`, `drop`, `fade`. **title_style**: `block` (words on accent-colour blocks), `card` (title on a card), `text` (big outlined text). **title_case**: `upper`, `title`, `none`. **tilt** (degrees) + **sticker** (white borders) give the collage look.

**zoom.pattern**: `alternate` (every other cut), `every-3`, `always`, `none`. **punch_in**: 1.0 none … 1.15 strong.

**grade**: `none`, `natural`, `clean`, `warm`, `punchy`, `cinematic`, `moody`, `soft`, `luxe`, `mono`, `film`.

**sfx sounds** (in `kit/sfx/`): `whoosh`, `swoosh`, `pop`, `click`, `tick`, `ding`, `thud`, `riser`, `camera`.

**energy** 1–5 sets how often something changes on screen (retention check) and how dense the graphics are.

After saving a style, run `edit.py studio --thumbs` to refresh its preview in the Studio.

## Presets saved from a reference

Presets saved in the Studio also carry a measured style **kit** (`kit`: styles with fonts identified letter by letter, sizes, colours, case, motion, the reference's colour, behind-person moments, graphic inventory) used by `edit.py design`, plus the edit spec `my-brand/styles/<id>.md` and frames in `my-brand/styles/<id>.frames/`. Extra keys honoured by the classic renderer: `captions.x`, `captions.exact_position`, `captions.lead_ms`, `fonts.accent`, `graphics.allowed`, `grade: "custom"` + `grade_filter`, `broll`, `music.bpm`, `music.mood`, `hidden`.

## Default visual direction
Use `kit/docs/signature-style.md` whenever a visual choice is unspecified. CreatorCut Signature is the default: bold captions with serif accents, animated graphics timed to the spoken story, and sound cues that support the action. Explicit instructions, clear reference observations, selected preset and relevant user memory override only the features they specify; unknown features fall back individually. Observed absence is an explicit choice (e.g. no captions or no motion), not a reason to add effects. Read style-direction.json and translate actual brief/reference/recipe/memory evidence to style-inputs.json before final planning. Defaults are not user preferences and must not be learned as feedback. Never silently restyle existing approved projects.
