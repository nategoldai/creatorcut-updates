# edit-plan.json (motion-graphics edits)

`edit.py design <p>` drafts it; you add the creative layer; `edit.py compose <p>` checks and renders it with HyperFrames.
Positions `x`, `y` are the **centre** of the element as fractions of the frame (0-1). Text sizes are fractions of the frame height.
Times are seconds on the cut (`edit.py words <p>` lists every word with its time).

```json
{
  "duration": 36.1,
  "background": {"src": "graded.mp4", "zooms": [{"t0": 7.0, "t1": 8.7, "scale": 1.12, "x": 0.5, "y": 0.4}]},
  "fonts":  {"caption": {"family": "Inter Tight", "weight": 500, "italic": false, "file": "kit/fonts/google/inter-tight-500.ttf"}, "...": {}},
  "styles": {"caption": {"font": "caption", "size": 0.07, "colour": "#FFFDFF", "case": "lower", "shadow": 0.28}, "...": {}},
  "items": [ ... ]
}
```

## Items

| type | fields | use for |
|---|---|---|
| `caption` | `t0 t1 x y words:[{w,t,style}]`, optional `lines:[[0,1],[2]]`, `reveal:"word"`, `anim:{ease,scale_from,dy_from,ms}` | every caption and the hook |
| `card` | `src t0 t1 x y w h rot radius shadow behind anim:{ease,dx_from,dy_from,rot_from,scale_from,ms,float}` | a B-roll clip / screenshot on a tilted rounded card. `behind: true` puts it behind the person. While visible it drifts and tilts a little more (`float: {rot, dx, dy, scale}`, or `false` to hold still) |
| `note` | `text t0 t1 x y rot style arrow:{to:[x,y],bend}` | a handwritten aside with a drawn arrow (`\n` for a new line) |
| `burst` | `srcs t0 t1 x y count spread size behind` | many thumbnails flying out around the person (kept off the face), then floating. Use many different frames (`edit.py media` makes a strip per clip: `media/.thumbs/<clip>-strip-NN.jpg`) |
| `piece` | `name t0 t1 x y scale` + options: `folder` (srcs, label), `counter` (value, label), `checklist` (items [{text, t}]), `phone` (src, rot), `sticker` (text, colour, rot), `apps` (srcs, label) | ready-made animated motion graphics in the video's fonts and colours (`kit/editkit/pieces.py`) |
| `html` | `t0 t1 html css gsap assets:{NAME: "media/file.jpg"}` | anything else, built in the reference's look (`$ID` = this item's id, `$T0` = its start; use `assets/NAME` in the html) |

Scenes made of several graphics (a full-screen stage + the clip card on it): give each part `"together": true` so they stay on screen together, and `"z"` for the layer order (stage 17, card 18; captions are 20).

Cards copy the reference's motion: `"anim": {"enter": "cut" | "slide-up" | "slide-down" | "slide-left" | "slide-right" | "fade" | "pop"
| (tilted pop, default), "exit": "cut" | "slide-…" | "fade" | (shrink, default),
"float": null}` for cards that sit still; flat cards: `"shadow": false, "radius": 0`. Word-by-word captions with
`"anim": {"ease": "cut"}` appear in place with a hard cut (the whole block is laid out from the start).

Rules: animate with transforms only (x, y, scale, rotation, opacity), never left/top. Use only styles and fonts from the kit
(add a style when the reference has another, e.g. `note` in its handwriting font from Google Fonts: `kit/fonts/google/<name>-400.ttf`
is downloaded by `edit.py font "<Family>" 400`). Every text block is shrunk automatically to fit the frame.

## Default visual direction
Use `kit/docs/signature-style.md` whenever a visual choice is unspecified. CreatorCut Signature is the default: bold captions with serif accents, animated graphics timed to the spoken story, and sound cues that support the action. Explicit instructions, clear reference observations, selected preset and relevant user memory override only the features they specify; unknown features fall back individually. Observed absence is an explicit choice (e.g. no captions or no motion), not a reason to add effects. Read style-direction.json and translate actual brief/reference/recipe/memory evidence to style-inputs.json before final planning. Defaults are not user preferences and must not be learned as feedback. Never silently restyle existing approved projects.
