"""Learn a style from references (videos or screenshots of creators the user loves).

analyze_ref()  measures one reference: pace (scene cuts, shot length, punch-ins, silence), speech (words per
               minute, hook length, first-3-seconds text), captions (position, size, highlight colour, box vs
               outline), colour (brightness, contrast, saturation, temperature, vivid colours), graphics density
               and audio (music under the voice, sound-effect proxy). It also keeps sample frames and caption-band
               crops for the contact sheet.
aggregate()    combines several references into measurements.json + contact-sheet.jpg.
draft_style()  turns measurements into a style JSON, starting from the closest built-in style. The agent then looks
               at the contact sheet and refines it (fonts, case, graphics) — the agent makes the final call.

References are only used to learn the general feel. Downloaded videos are deleted right after analysis."""
from __future__ import annotations

import colorsys
import re
import shutil
import subprocess
from collections import Counter
from pathlib import Path

from . import util

TEACH = util.PROJECTS / "_teach"
REFS = TEACH / "_refs"


# ------------------------------------------------------------- low level ----
def _scene_times(video: Path, threshold: float = 0.32) -> list[float]:
    proc = util.run([util.ffmpeg_bin(), "-hide_banner", "-i", str(video), "-vf",
                     f"scale=320:-2,select='gt(scene,{threshold})',showinfo", "-an", "-f", "null", "-"], check=False)
    return [float(m) for m in re.findall(r"pts_time:([0-9.]+)", proc.stderr or "")]


def _frame(video: Path, t: float, out: Path, width: int = 540) -> Path | None:
    util.run([util.ffmpeg_bin(), "-y", "-hide_banner", "-ss", f"{max(0.0, t):.2f}", "-i", str(video), "-frames:v", "1",
              "-vf", f"scale={width}:-2", "-q:v", "3", str(out)], check=False)
    return out if out.exists() else None


def _palette(img, n: int = 6) -> list[tuple[str, float, float, float]]:
    """Dominant colours as (#hex, share, saturation, lightness)."""
    small = img.convert("RGB").resize((160, 160))
    q = small.quantize(colors=n, method=2)
    pal = q.getpalette()
    counts = sorted(q.getcolors(), reverse=True)
    out = []
    total = sum(c for c, _ in counts)
    for c, idx in counts:
        r, g, b = pal[idx * 3: idx * 3 + 3]
        h, l, s = colorsys.rgb_to_hls(r / 255, g / 255, b / 255)
        out.append((f"#{r:02X}{g:02X}{b:02X}", round(c / total, 3), round(s, 2), round(l, 2)))
    return out


def _merge_vivid(counter: Counter, n: int = 6) -> list[str]:
    vivid: list[str] = []
    for c, _ in counter.most_common(40):
        r, g, b = (int(c[i:i + 2], 16) for i in (1, 3, 5))
        if all(abs(r - int(v[1:3], 16)) + abs(g - int(v[3:5], 16)) + abs(b - int(v[5:7], 16)) > 70 for v in vivid):
            vivid.append(c)
        if len(vivid) == n:
            break
    return vivid


def _audio_pcm(video: Path):
    """16 kHz mono float samples (numpy) or None."""
    try:
        import numpy as np
        proc = subprocess.run([util.ffmpeg_bin(), "-v", "error", "-i", str(video), "-vn", "-ac", "1", "-ar", "16000",
                               "-f", "s16le", "-"], capture_output=True, timeout=300)
        if proc.returncode != 0 or not proc.stdout:
            return None
        return np.frombuffer(proc.stdout, dtype=np.int16).astype(np.float32) / 32768.0
    except Exception:
        return None


# ---------------------------------------------------------- image metrics ----
def _image_metrics(im) -> dict:
    from PIL import ImageStat
    rgb = im.convert("RGB")
    hsv = rgb.convert("HSV")
    st_hsv = ImageStat.Stat(hsv)
    st_rgb = ImageStat.Stat(rgb)
    L = ImageStat.Stat(rgb.convert("L"))
    r, g, b = st_rgb.mean
    return {"brightness": st_hsv.mean[2] / 255, "saturation": st_hsv.mean[1] / 255,
            "contrast": L.stddev[0] / 128, "temperature": (r - b) / 255}


def _caption_band(im) -> dict | None:
    """Find the horizontal band where captions most likely sit: rows dense with bright, high-contrast strokes
    (white text with a dark outline, or text on a box). Returns y (0..1 centre), height (0..1), box guess and
    the vivid colours inside the band (likely the highlight colour)."""
    import numpy as np
    small = im.convert("RGB").resize((180, 320))
    a = np.asarray(small).astype(np.float32) / 255.0
    lum = a.mean(axis=2)
    mx, mn = a.max(axis=2), a.min(axis=2)
    sat = np.where(mx > 0, (mx - mn) / np.maximum(mx, 1e-6), 0)
    # strong horizontal edges = text strokes
    edge = np.abs(np.diff(lum, axis=1))
    edge = np.pad(edge, ((0, 0), (0, 1)))
    strokes = (edge > 0.35).astype(np.float32)
    rows = strokes.mean(axis=1)
    rows[:int(320 * 0.06)] = 0           # ignore the very top (status bars) and bottom (app UI)
    rows[int(320 * 0.92):] = 0
    if rows.max() < 0.04:
        return None
    k = np.ones(9) / 9
    sm = np.convolve(rows, k, mode="same")
    peak = int(sm.argmax())
    thr = sm[peak] * 0.45
    top, bot = peak, peak
    while top > 0 and sm[top - 1] > thr:
        top -= 1
    while bot < 319 and sm[bot + 1] > thr:
        bot += 1
    band = a[top:bot + 1]
    # box: the band's background (non-stroke pixels) is very uniform and differs from the rows just outside
    inner = lum[top:bot + 1]
    outside = np.concatenate([lum[max(0, top - 8):top], lum[bot + 1:min(320, bot + 9)]]) if bot - top < 300 else inner
    box = bool(inner.std() < 0.28 and outside.size and abs(np.median(inner) - np.median(outside)) > 0.25)
    # highlight colour: vivid colours much more common inside the caption band than in the rest of the frame
    def vivid_counts(rows_sel):
        cnt = Counter()
        px, ss, ll = a[rows_sel], sat[rows_sel], lum[rows_sel]
        m = (ss > 0.55) & (ll > 0.42) & (ll < 0.92)   # skip dark anti-aliased edges against outlines
        if m.sum():
            q = np.minimum((px[m] * 255).astype(int) // 40 * 40 + 20, 255)
            for c in map(tuple, q):
                cnt["#%02X%02X%02X" % c] += 1
        return cnt, max(1, int(rows_sel.sum()) * 180)
    rows_in = np.zeros(320, dtype=bool)
    rows_in[top:bot + 1] = True
    inside, n_in = vivid_counts(rows_in)
    outside, n_out = vivid_counts(~rows_in)
    scored = []
    for c, k in inside.items():
        share_in = k / n_in
        share_out = outside.get(c, 0) / n_out
        if k >= 12 and share_in > 4 * share_out + 0.002:
            scored.append((share_in, c))
    vivid = Counter({c: sc for sc, c in scored})
    return {"y": round((top + bot) / 2 / 320, 3), "height": round((bot - top + 1) / 320, 3), "box": box,
            "vivid": [c for c, _ in vivid.most_common(3)], "top": top / 320, "bottom": (bot + 1) / 320}


# ----------------------------------------------------------- one reference ----
from .resources import reference_work

@reference_work
def analyze_ref(src: Path, out_dir: Path, with_speech: bool = True, progress=None, detailed: bool = True) -> dict:
    """Measure one reference file. Writes frames into out_dir/frames and measurements to out_dir/measurements.json."""
    from PIL import Image, ImageOps
    src, out_dir = Path(src), Path(out_dir)
    from . import artifact_cache as cache
    manifest=out_dir/'measurements-cache.json'
    model=util.load_profile().get('whisper_model','small')
    def current_key(mode=detailed):return cache.key('reference-measurements-v1',[src,*cache.model_files(model)] if with_speech else [src],{'with_speech':with_speech,'model':model,'detailed':mode},sorted(Path(__file__).parent.glob('*.py')))
    source_sha=cache.digest(src)
    expected=current_key()
    if cache.hit(manifest,expected):
        if progress:progress('Reusing unchanged reference measurements',1)
        return util.read_json(out_dir/'measurements.json')
    words_file = out_dir / 'words.json'
    saved_words = []
    if detailed and with_speech:
        try:
            receipt = util.read_json(manifest, default={})
            if isinstance(receipt, dict) and isinstance(receipt.get('outputs'), dict) and 'words.json' in receipt['outputs']:
                if cache.hit(manifest, current_key(False)):
                    words = util.read_json(words_file)
                    if isinstance(words, list):
                        saved_words = words
        except (OSError, util.Fail):
            pass
    frames_dir = out_dir / "frames"
    if frames_dir.exists():
        shutil.rmtree(frames_dir)
    frames_dir.mkdir(parents=True)
    say = progress or (lambda *_: None)
    m: dict = {"file": src.name, "kind": "video" if src.suffix.lower() in util.VIDEO_EXT else "image"}
    frames: list[tuple[float, Path]] = []

    if m["kind"] == "image":
        if src.suffix.lower() == ".heic":
            raise util.Fail("HEIC photos can't be read.", "Export it as PNG or JPG and drop it again.")
        im = ImageOps.exif_transpose(Image.open(src)).convert("RGB")
        im.thumbnail((540, 960))
        f = frames_dir / "00.jpg"
        im.save(f, quality=88)
        frames.append((0.0, f))
    else:
        say("Measuring the pace…", 0.1)
        info = util.probe(src)
        dur = max(info["duration"], 0.1)
        cuts = _scene_times(src)
        m.update({"duration": round(dur, 1), "aspect": f"{info['width']}x{info['height']}",
                  "cuts": len(cuts), "cuts_per_minute": round(len(cuts) / dur * 60, 1),
                  "avg_shot_seconds": round(dur / (len(cuts) + 1), 2)})
        # silence ratio
        sp = util.run([util.ffmpeg_bin(), "-hide_banner", "-i", str(src), "-af", "silencedetect=noise=-35dB:d=0.25",
                       "-vn", "-f", "null", "-"], check=False)
        sil = sum(float(x) for x in re.findall(r"silence_duration: ([0-9.]+)", sp.stderr or ""))
        m["silence_ratio"] = round(min(1.0, sil / dur), 3)

        # speech
        words = []
        if with_speech and info["has_audio"]:
            if saved_words:
                say("Reusing the reference speech measurements…", 0.54)
                words = saved_words
            else:
                say("Listening to the speech…", 0.3)
                words = _transcribe(src, lambda f: say(f"Listening to the speech… {round(f * 100)}%", 0.3 + 0.24 * f))
        util.write_json(words_file, words)
        if words:
            spoken = max(0.1, words[-1]["end"] - words[0]["start"])
            first_end = next((w["end"] for w in words if w["w"].rstrip().endswith((".", "!", "?"))), None)
            m["speech"] = {"words": len(words), "wpm": round(len(words) / spoken * 60),
                           "hook_seconds": round(first_end, 1) if first_end else None,
                           "first_3s": " ".join(w["w"].strip() for w in words if w["start"] < 3.0)[:160],
                           "starts_at": round(words[0]["start"], 2)}
        # frames: at word times (captions visible) plus after cuts and evenly spaced
        say("Studying the frames…", 0.55)
        picks = [dur * p for p in (0.08, 0.22, 0.38, 0.52, 0.68, 0.84)]
        picks += [min(dur - 0.1, c + 0.35) for c in cuts[:4]]
        if words:
            step = max(1, len(words) // 6)
            picks += [(w["start"] + w["end"]) / 2 for w in words[::step]][:6]
        picks = sorted({round(t, 1) for t in picks if 0 <= t < dur})[:14]
        for i, t in enumerate(picks):
            f = _frame(src, t, frames_dir / f"{i:02d}.jpg")
            if f:
                frames.append((t, f))
        # punch-ins: a scene "cut" where the colours before and after barely change = same shot, new scale
        punch = 0
        for c in cuts[:24]:
            a_ = _frame(src, max(0, c - 0.12), out_dir / "_a.jpg", 160)
            b_ = _frame(src, c + 0.12, out_dir / "_b.jpg", 160)
            if a_ and b_:
                ha = Image.open(a_).convert("RGB").histogram()
                hb = Image.open(b_).convert("RGB").histogram()
                inter = sum(min(x, y) for x, y in zip(ha, hb)) / max(1, sum(ha))
                if inter > 0.72:
                    punch += 1
        for t in ("_a.jpg", "_b.jpg"):
            (out_dir / t).unlink(missing_ok=True)
        m["punch_ins"] = punch
        m["punch_in_share"] = round(punch / max(1, min(24, len(cuts))), 2) if cuts else 0.0
        # audio: music under the voice, sound-effect transients between words
        say("Listening to the music and sound…", 0.75)
        m["audio"] = _audio_metrics(src, words)
        # Studio follows basic measurements with its complete high-resolution
        # study. Do not run a second coarse visual study/replica first.
        if detailed:
            # frame-by-frame Style DNA (zooms, cutaways, caption motion, font, tempo)
            try:
                from . import dna
                deep_say = lambda msg, f: say(msg, 0.76 + min(1.0, max(0.0, f - 0.6) / 0.4) * 0.21)   # keep progress moving forward
                m["deep"] = dna.analyze(src, words, frames_dir, deep_say)
                m["replica"] = dna.replica(src, words, m["deep"], out_dir, deep_say)
                if m["deep"].get("cuts_per_minute") is not None:      # frame-by-frame cuts include jump cuts
                    n = m["deep"]["cuts_10fps"]
                    m.update(cuts=n, cuts_per_minute=m["deep"]["cuts_per_minute"], avg_shot_seconds=round(dur / (n + 1), 2))
            except Exception as e:
                util.log(f"deep analysis skipped for {src.name}: {e}")
        else:
            from . import dna
            m['deep']={'tempo_bpm':dna._tempo(src),'loudness_lufs':dna._loudness(src)}
            m['full_visual_study_follows']=True

    # per-frame metrics
    say("Reading colours and captions…", 0.98)
    colours, metrics, bands = Counter(), [], []
    prev = None
    overlay_changes = 0
    from PIL import ImageChops, ImageStat
    for t, f in frames:
        im = Image.open(f).convert("RGB")
        metrics.append(_image_metrics(im))
        for hexc, share, s, l in _palette(im):
            if s > 0.45 and 0.25 < l < 0.85:
                colours[hexc] += share
        band = _caption_band(im)
        if band:
            bands.append(band)
            crop = im.crop((0, int(max(0, band["top"] - 0.03) * im.height), im.width,
                            int(min(1, band["bottom"] + 0.03) * im.height)))
            crop.save(f.with_name(f.stem + "_cap.jpg"), quality=88)
        # graphics: change in the top/middle bands between nearby frames of the same shot
        small = im.resize((90, 160))
        if prev is not None:
            top = ImageStat.Stat(ImageChops.difference(prev.crop((0, 8, 90, 70)), small.crop((0, 8, 90, 70)))).mean
            whole = ImageStat.Stat(ImageChops.difference(prev, small)).mean
            if sum(top) / 3 > 28 and sum(whole) / 3 < 45:
                overlay_changes += 1
        prev = small

    def avg(k):
        return round(sum(x[k] for x in metrics) / len(metrics), 3) if metrics else None

    m["colour"] = {"brightness": avg("brightness"), "saturation": avg("saturation"), "contrast": avg("contrast"),
                   "temperature": avg("temperature"), "vivid": _merge_vivid(colours)}
    if bands:
        ys = sorted(b["y"] for b in bands)
        hs = sorted(b["height"] for b in bands)
        hl = Counter(c for b in bands for c in b["vivid"])
        m["captions"] = {"y": ys[len(ys) // 2], "height": hs[len(hs) // 2],
                         "box": sum(b["box"] for b in bands) > len(bands) / 2,
                         "highlight": [c for c, _ in hl.most_common(2)], "seen_in": f"{len(bands)}/{len(frames)} frames"}
    else:
        m["captions"] = None
    if m["kind"] == "video" and m.get("duration"):
        m["graphics_per_minute"] = round(overlay_changes / m["duration"] * 60, 1)
    m["frames"] = [util.rel(f) for _, f in frames]
    util.write_json(out_dir / "measurements.json", m)
    if cache.digest(src)!=source_sha:raise util.Fail('The reference changed during analysis. Retry its scan.')
    cache.commit(manifest,current_key(),[out_dir/'measurements.json',*sorted(frames_dir.glob('*.jpg')),
                                          *([words_file] if m['kind']=='video' else [])])
    return m


def _transcribe(src: Path, report=None) -> list[dict]:
    """Words with timings. `report(fraction)` follows how far into the audio the transcription is."""
    try:
        from faster_whisper import WhisperModel  # type: ignore
        audio = _audio_pcm(src)
        if audio is None or len(audio) < 8000:
            return []
        audio = audio[: 16000 * 185]
        from . import speech_models
        private_model = speech_models.require(util.load_profile().get("whisper_model", "small"))
        model = WhisperModel(str(private_model), device="cpu", compute_type="int8", local_files_only=True)
        segs, _ = model.transcribe(audio, word_timestamps=True, vad_filter=True, beam_size=1)
        out = []
        total = max(1.0, len(audio) / 16000)
        for s in segs:
            for w in s.words or []:
                out.append({"w": w.word.strip(), "start": float(w.start), "end": float(w.end)})
            if report:
                report(min(1.0, float(s.end) / total))
            if s.end > 180:
                break
        return out
    except Exception as e:
        util.warn(f"Couldn't listen to the speech ({str(e)[:120]}); measuring the visuals only.")
        return []


def _audio_metrics(src: Path, words: list[dict]) -> dict | None:
    x = _audio_pcm(src)
    if x is None or len(x) < 16000:
        return None
    import numpy as np
    hop = 320  # 20 ms
    n = len(x) // hop
    env = np.sqrt((x[: n * hop].reshape(n, hop) ** 2).mean(axis=1) + 1e-12)
    speech_mask = np.zeros(n, dtype=bool)
    for w in words:
        speech_mask[int(w["start"] * 50): int(w["end"] * 50) + 1] = True
    speech_rms = float(np.median(env[speech_mask])) if speech_mask.any() else float(np.percentile(env, 75))
    gaps = env[~speech_mask] if speech_mask.any() else env[env < np.percentile(env, 30)]
    bed = float(np.median(gaps)) if gaps.size else 0.0
    music = bool(speech_rms > 0 and bed / speech_rms > 0.12)
    # transients: sudden jumps well above the recent level, not at the start of a word
    onsets = 0
    starts = {int(w["start"] * 50) for w in words}
    last = -100
    for i in range(10, n):
        recent = np.median(env[i - 10:i])
        if env[i] > recent * 3.5 and env[i] > speech_rms * 0.35 and i - last > 8:
            if not any(abs(i - s) <= 4 for s in starts):
                onsets += 1
            last = i
    dur = n / 50
    loud = 20 * np.log10(max(speech_rms, 1e-6))
    return {"music": music, "music_level": round(bed / speech_rms, 3) if speech_rms else 0,
            "sfx_per_minute": round(onsets / dur * 60, 1), "voice_dbfs": round(float(loud), 1)}


# --------------------------------------------------------------- aggregate ----
def aggregate(name: str, ref_dirs: list[Path]) -> dict:
    """Combine measured references into kit/projects/_teach/<name>/measurements.json + contact-sheet.jpg."""
    out_dir = TEACH / name
    out_dir.mkdir(parents=True, exist_ok=True)
    ms = []
    for d in ref_dirs:
        f = Path(d) / "measurements.json"
        if f.exists():
            ms.append((Path(d), util.read_json(f)))
    if not ms:
        raise util.Fail("None of the references could be analysed.", "Drop 2–5 videos or screenshots and try again.")
    vids = [m for _, m in ms if m["kind"] == "video"]

    def mean(vals):
        vals = [v for v in vals if v is not None]
        return round(sum(vals) / len(vals), 3) if vals else None

    cpm = mean([m.get("cuts_per_minute") for m in vids])
    pace = None if cpm is None else "very fast" if cpm > 40 else "fast" if cpm > 24 else "medium" if cpm > 12 else "slow"
    speech = [m["speech"] for m in vids if m.get("speech")]
    caps = [m["captions"] for m in ms_only(ms) if m.get("captions")]
    vivid = Counter()
    for _, m in ms:
        for i, c in enumerate(m["colour"]["vivid"]):
            vivid[c] += 1.0 / (i + 1)
    hl = Counter()
    for c in caps:
        for i, h in enumerate(c.get("highlight") or []):
            hl[h] += 1.0 / (i + 1)
    audio = [m["audio"] for m in vids if m.get("audio")]
    result = {
        "name": name, "references": len(ms), "videos": len(vids),
        "files": [m["file"] for _, m in ms],
        "pace": pace, "cuts_per_minute": cpm,
        "avg_shot_seconds": mean([m.get("avg_shot_seconds") for m in vids]),
        "punch_in_share": mean([m.get("punch_in_share") for m in vids]),
        "silence_ratio": mean([m.get("silence_ratio") for m in vids]),
        "words_per_minute": mean([s["wpm"] for s in speech]),
        "hook_seconds": mean([s.get("hook_seconds") for s in speech]),
        "first_3s": [s.get("first_3s", "") for s in speech],
        "captions": {"y": mean([c["y"] for c in caps]), "height": mean([c["height"] for c in caps]),
                     "box": sum(c["box"] for c in caps) > len(caps) / 2 if caps else None,
                     "highlight": [c for c, _ in hl.most_common(3)], "found_in": len(caps)} if caps else None,
        "colour": {k: mean([m["colour"][k] for _, m in ms]) for k in ("brightness", "saturation", "contrast", "temperature")},
        "vivid_colours": _merge_vivid(vivid),
        "graphics_per_minute": mean([m.get("graphics_per_minute") for m in vids]),
        "music": (sum(a["music"] for a in audio) > len(audio) / 2) if audio else None,
        "sfx_per_minute": mean([a["sfx_per_minute"] for a in audio]),
        "per_reference": [m for _, m in ms],
        "deep": _aggregate_deep([m.get("deep") for m in vids if m.get("deep")]),
        "replica": next((m["replica"] for m in vids if (m.get("replica") or {}).get("captions")), None),
    }
    result["contact_sheet"] = util.rel(_contact_sheet(out_dir, ms))
    result["next"] = ("Look at the contact sheet (frames + caption-band crops): judge font class (condensed sans, "
                      "geometric sans, serif, marker), caption case, words per chunk and graphics treatment. Then "
                      "refine my-brand/styles/<name>.json (see kit/docs/style-format.md).")
    util.write_json(out_dir / "measurements.json", result)
    return result


def _aggregate_deep(ds: list[dict]) -> dict:
    if not ds:
        return {}
    import statistics as stx

    def med(vals):
        vals = [v for v in vals if v is not None]
        return round(stx.median(vals), 3) if vals else None
    ds = [d for d in ds if isinstance(d, dict)]
    def measured(rows, key):
        return [row[key] for row in rows if key in row and row[key] is not None]

    def group(key):
        return [row[key] for row in ds if isinstance(row.get(key), dict) and row[key]]

    def majority(rows, key):
        values = [v for v in measured(rows, key) if isinstance(v, bool)]
        return sum(values) > len(values) / 2 if values else None

    caps, zoom, broll = group("captions"), group("zoom"), group("broll")
    font_votes = Counter()
    for c in caps:
        for i, f in enumerate(c.get("font_match") or []):
            if isinstance(f, dict) and f.get("key") and isinstance(f.get("confidence"), (float, int)):
                font_votes[f["key"]] += f["confidence"] * (1.0 if i == 0 else 0.5)
    anim = Counter(measured(caps, "animation"))
    counts = measured(broll, "count")
    return {
        "schema_version": 2,
        "zoom": {"punch_in": med(measured(zoom, "punch_in")), "punch_ins_per_min": med(measured(zoom, "punch_ins_per_min")),
                 "slow_push": majority(zoom, "slow_push")},
        "broll": {"per_minute": med(measured(broll, "per_minute")), "avg_seconds": med(measured(broll, "avg_seconds")),
                  "talking_head_share": med(measured(broll, "talking_head_share")), "count": sum(counts) if counts else None},
        "captions": {"words_per_caption": med(measured(caps, "words_per_caption")), "animation": anim.most_common(1)[0][0] if anim else None,
                     "uppercase": majority(caps, "uppercase"),
                     "font_match": [{"key": k, "score": round(v, 2)} for k, v in font_votes.most_common(3)],
                     "accent": next((c["accent"] for c in caps if c.get("accent") and c["accent"].get("font_match")), None)} if caps else None,
        "structure": next((d["structure"] for d in ds if d.get("structure")), None),
        "tempo_bpm": med(measured(ds, "tempo_bpm")), "loudness_lufs": med(measured(ds, "loudness_lufs")),
    }


def ms_only(ms):
    return [m for _, m in ms]


def _contact_sheet(out_dir: Path, ms: list[tuple[Path, dict]]) -> Path:
    from PIL import Image, ImageDraw, ImageOps
    tiles = []
    for d, m in ms:
        fr = sorted((d / "frames").glob("[0-9][0-9].jpg"))
        caps = sorted((d / "frames").glob("*_cap.jpg"))
        for f in fr[:6]:
            tiles.append(("frame", m["file"], f))
        for f in caps[:3]:
            tiles.append(("cap", m["file"], f))
    tiles = tiles[:36]
    cols, tw, th = 6, 240, 427
    rows = (len(tiles) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * (tw + 8) + 8, max(1, rows) * (th + 30) + 8), (16, 16, 18))
    dr = ImageDraw.Draw(sheet)
    for i, (kind, label, f) in enumerate(tiles):
        im = ImageOps.exif_transpose(Image.open(f)).convert("RGB")
        im.thumbnail((tw, th))
        x = 8 + (i % cols) * (tw + 8)
        y = 8 + (i // cols) * (th + 30)
        sheet.paste(im, (x + (tw - im.width) // 2, y + (th - im.height) // 2))
        dr.text((x + 4, y + th + 8), (("caption · " if kind == "cap" else "") + label)[:36], fill=(200, 200, 200))
    out = out_dir / "contact-sheet.jpg"
    sheet.save(out, quality=86)
    return out


# ------------------------------------------------------------ draft style ----
GRADE_HINTS = [  # (grade, brightness, saturation, contrast, temperature)
    ("clean", 0.62, 0.30, 0.45, 0.04), ("natural", 0.5, 0.32, 0.45, 0.04), ("warm", 0.52, 0.38, 0.45, 0.12),
    ("punchy", 0.52, 0.48, 0.58, 0.05), ("cinematic", 0.42, 0.30, 0.55, 0.0), ("moody", 0.33, 0.25, 0.5, 0.02),
    ("soft", 0.66, 0.22, 0.35, 0.05), ("luxe", 0.40, 0.26, 0.5, 0.06), ("mono", 0.48, 0.03, 0.55, 0.0),
]


def nearest_grade(c: dict) -> str:
    if not c or c.get("brightness") is None:
        return "natural"
    best, bd = "natural", 9e9
    for g, b, s, k, t in GRADE_HINTS:
        d = (c["brightness"] - b) ** 2 * 3 + (c["saturation"] - s) ** 2 * 4 + (c["contrast"] - k) ** 2 + (
            (c.get("temperature") or 0) - t) ** 2 * 2
        if d < bd:
            best, bd = g, d
    return best


def _energy(r: dict) -> int:
    cpm = r.get("cuts_per_minute") or 0
    wpm = r.get("words_per_minute") or 160
    gpm = r.get("graphics_per_minute") or 0
    score = (cpm / 12) + (max(0, wpm - 140) / 40) + gpm / 6
    return max(1, min(5, round(1 + score)))


def draft_style(r: dict, name: str, label: str = "") -> dict:
    """A complete style JSON from aggregated measurements, starting from the closest built-in style."""
    from . import styles as st
    energy = _energy(r) if r.get("videos") else 3
    caps = r.get("captions") or {}
    box = bool(caps.get("box"))
    serif_hint = (r.get("colour") or {}).get("saturation", 0.3) < 0.2 and energy <= 2
    candidates = []
    for s in st.list_styles():
        if s["origin"] != "toolkit":
            continue
        full = st.load(s["id"], apply_brand=False)
        d = abs(full["energy"] - energy) * 2
        d += 0 if bool(full["captions"].get("box")) == box else 2.5
        if serif_hint and "serif" in full["fonts"]["caption"]:
            d -= 1
        candidates.append((d, s["id"], full))
    candidates.sort(key=lambda x: x[0])
    _, base_id, base = candidates[0]

    accent = (caps.get("highlight") or r.get("vivid_colours") or [base["colors"]["accent"]])[0]
    style = {
        "name": label or "Your style",
        "tagline": _tagline(r, energy),
        "best_for": base.get("best_for", []),
        "energy": energy,
        "learned_from": {"references": r.get("references"), "base": base_id, "measured": util.rel(TEACH / name / "measurements.json")},
        "fonts": dict(base["fonts"]),
        "colors": dict(base["colors"], accent=accent),
        "captions": dict(base["captions"]),
        "graphics": dict(base["graphics"]),
        "zoom": dict(base["zoom"]),
        "grade": nearest_grade(r.get("colour") or {}),
        "sfx": dict(base["sfx"]),
        "pacing": dict(base["pacing"]),
        "progress_bar": base.get("progress_bar", False),
        "use_brand_accent": False,
    }
    if caps.get("y"):
        style["captions"]["y"] = round(min(0.76, max(0.5, caps["y"])), 3)
    if caps.get("height"):
        # caption band height (fraction of frame) → font size on a 1920-high frame
        style["captions"]["size"] = int(min(120, max(60, caps["height"] * 1920 * 0.9)))
    style["captions"]["box"] = box
    if box:
        style["captions"]["mode"] = "highlight"
    cpm = r.get("cuts_per_minute")
    if cpm is not None:
        style["pacing"]["max_pause"] = 0.14 if cpm > 30 else 0.18 if cpm > 18 else 0.24 if cpm > 8 else 0.32
    share = r.get("punch_in_share")
    if share is not None:
        style["zoom"]["punch_in"] = round(1.0 + min(0.13, 0.03 + share * 0.12), 3)
        style["zoom"]["pattern"] = "always" if share > 0.6 else "alternate" if share > 0.15 else "every-3"
    gpm = r.get("graphics_per_minute")
    if gpm is not None:
        style["graphics"]["density"] = "high" if gpm > 6 else "medium" if gpm > 2 else "low"
    sfx = r.get("sfx_per_minute")
    if sfx is not None:
        style["sfx"]["enabled"] = sfx > 1.5
        style["sfx"]["volume"] = round(min(0.42, 0.18 + sfx / 60), 2)
    if r.get("music") is not None:
        bpm = (r.get("deep") or {}).get("tempo_bpm")
        style["music"] = {"volume": 0.16 if r["music"] else 0.1, "duck": True, "enabled": bool(r["music"]),
                          **({"bpm": bpm} if bpm else {})}
    deep = r.get("deep") or {}
    dc = deep.get("captions") or {}
    if dc.get("font_match"):
        from . import styles as st
        key = dc["font_match"][0]["key"]
        if key in st.FONTS:
            style["fonts"]["caption"] = key
            style["fonts"]["heading"] = key
    acc = dc.get("accent") or {}
    if acc.get("font_match"):
        from . import styles as st
        akey = acc["font_match"][0]["key"]
        if acc.get("italic") and not st.FONTS.get(akey, {}).get("italic"):   # measured slant wins over the shape match
            akey = next((f["key"] for f in acc["font_match"] if st.FONTS.get(f["key"], {}).get("italic")), "instrument-serif-italic")
        if akey in st.FONTS and akey != style["fonts"]["caption"]:
            style["fonts"]["accent"] = akey
            style["captions"]["keyword_accent"] = True
    if dc.get("uppercase") is not None:
        style["captions"]["uppercase"] = bool(dc["uppercase"])
    if dc.get("words_per_caption"):
        style["captions"]["max_words"] = int(max(1, min(5, round(dc["words_per_caption"]))))
        style["captions"]["max_chars"] = 10 + 6 * style["captions"]["max_words"]
    if dc.get("animation"):
        style["captions"]["mode"] = {"pop": "pop", "slide": "pop", "cut": "highlight" if (caps.get("highlight")) else "plain"}[dc["animation"]]
    z = deep.get("zoom") or {}
    if z.get("punch_in"):
        style["zoom"]["punch_in"] = round(min(1.2, max(1.02, z["punch_in"])), 3)
        style["zoom"]["pattern"] = "alternate" if (z.get("punch_ins_per_min") or 0) > 3 else "every-3"
    b = deep.get("broll") or {}
    if b.get("count"):
        style["broll"] = {"per_minute": b.get("per_minute"), "seconds": b.get("avg_seconds") or 2.0, "mode": "full"}
    rep = r.get("replica") or {}
    rc = rep.get("captions")
    if rc:
        # exact caption look measured at full resolution
        from . import styles as st
        m = st._load_metrics()
        k = (m.get(st.REF_FONT, {}).get("cap") or 146) / 200.0     # visual cap height per size unit (Inter Black)
        cap_px = rc["cap_height"] * 1920
        style["captions"]["size"] = int(round(cap_px / k))
        style["captions"]["outline"] = round(rc["outline_rel"] * cap_px, 1)
        style["captions"]["shadow"] = 0
        style["captions"]["y"] = rc["y"]
        style["captions"]["x"] = rc["x"]
        style["captions"]["exact_position"] = True
        style["colors"]["text"] = rc["fill"] or style["colors"]["text"]
        if rc.get("outline"):
            style["colors"]["outline"] = rc["outline"]
        if rc.get("highlight"):
            style["colors"]["accent"] = rc["highlight"]
            style["captions"]["highlight"] = "color"
        elif style["captions"].get("mode") == "highlight":
            style["captions"]["mode"] = "plain"
        style["captions"]["box"] = bool(rc.get("box"))
        if rc.get("box_color"):
            style["captions"]["box_color"] = rc["box_color"]
        if rc.get("lines") == 1:
            style["captions"]["max_chars"] = min(style["captions"].get("max_chars", 18), 18)
    if rc:
        # graphics follow the reference's own text, not a stock look: same fonts, case and colours, no cards or bars
        g = style.setdefault("graphics", {})
        g.update(title_style="caption", title_case="upper" if style["captions"].get("uppercase") else "none",
                 accent_bar=False, shadow=False, sticker=False, tilt=0.0,
                 entrance="pop" if (rep.get("pop") or {}).get("animated") and dc.get("animation") == "pop" else "fade",
                 heading_size=int(round(style["captions"]["size"] * max(1.3, (rc.get("cap_height_big") or 0) / max(rc["cap_height"], 1e-4)))))
        style["fonts"]["heading"] = style["fonts"]["caption"]
        style["fonts"]["body"] = style["fonts"]["caption"]
        # only graphic kinds actually seen: big hook text and accent words; cards, lists, counters and progress
        # bars are added by the agent only when the frame sheets show them
        g["allowed"] = ["title", "emphasis", "broll"]
        style["progress_bar"] = False
    pop = rep.get("pop")
    if pop:
        style["captions"]["pop"] = bool(pop["animated"])
        if pop["animated"]:
            style["captions"].update(pop_from=pop["from"], pop_peak=max(1.0, pop["peak"]), pop_in_ms=pop["in_ms"])
    if rep.get("lead_ms") is not None:
        style["captions"]["lead_ms"] = max(0, min(250, rep["lead_ms"]))
    if rep.get("transitions"):
        style["transitions"] = rep["transitions"]
    if r.get("colour") and r["colour"].get("brightness") is not None:
        from . import dna
        g = dna.custom_grade(r["colour"])
        style["grade"] = "custom"
        style["grade_filter"] = g["filter"]
        style["grade_note"] = f"custom, closest preset {nearest_grade(r['colour'])}"
    return style


def _tagline(r: dict, energy: int) -> str:
    bits = []
    if r.get("pace"):
        bits.append(f"{r['pace']} cuts")
    caps = r.get("captions") or {}
    if caps.get("box"):
        bits.append("boxed captions")
    elif caps:
        bits.append("outlined captions")
    if r.get("words_per_minute"):
        bits.append(f"{int(r['words_per_minute'])} words a minute")
    if not bits:
        bits.append("calm" if energy <= 2 else "energetic")
    n = r.get("references") or 0
    return f"Learned from {n} reference{'s' if n != 1 else ''}: " + ", ".join(bits) + "."


def reveal(r: dict, style: dict) -> dict:
    """The compact summary the Studio's "Your style" card shows."""
    from . import styles as st
    font = st.FONTS.get(style["fonts"]["caption"], {})
    font = dict(font, ass=font.get("label") or font.get("ass"))
    caps = r.get("captions") or {}
    return {
        "pace": r.get("pace"), "cuts_per_minute": r.get("cuts_per_minute"),
        "words_per_minute": r.get("words_per_minute"),
        "palette": ([style["colors"]["accent"]] + [c for c in r.get("vivid_colours", []) if c != style["colors"]["accent"]])[:5],
        "captions": ("Boxed" if caps.get("box") else "Outlined") + (", high" if (caps.get("y") or 0.66) < 0.6 else ", low" if (caps.get("y") or 0.66) > 0.7 else ", centre-low") if caps else "Not detected",
        "font": {"key": style["fonts"]["caption"], "file": font.get("file", ""), "label": font.get("ass", style["fonts"]["caption"])},
        "grade": style.get("grade_note", style["grade"]), "energy": style["energy"], "music": r.get("music"),
        "caption_animation": style["captions"].get("mode"), "words_per_caption": style["captions"].get("max_words"),
        "uppercase": style["captions"].get("uppercase"), "punch_in": style["zoom"].get("punch_in"),
        "broll": (r.get("deep") or {}).get("broll"), "tempo_bpm": (r.get("deep") or {}).get("tempo_bpm"),
        "base": style.get("learned_from", {}).get("base"),
    }


# ---------------------------------------------------------- CLI (/teach) ----
def keep_history(name: str) -> None:
    """Before a style is retrained or its rulebook edited, keep the old version (Styles → versions)."""
    import shutil
    import time as _t
    hist = util.USER_STYLES_DIR / ".history"
    stamp = _t.strftime("%Y%m%d-%H%M%S")
    for ext in (".json", ".md"):
        f = util.USER_STYLES_DIR / f"{name}{ext}"
        if f.exists():
            hist.mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, hist / f"{name}-{stamp}{ext}")


def analyze(folder: Path, name: str) -> dict:
    """`edit.py teach <name> [--folder]`: analyse every reference in a folder (default my-brand/references),
    aggregate, and write a draft style the agent then refines."""
    folder = Path(folder)
    files = sorted(p for p in folder.rglob("*") if p.is_file() and p.suffix.lower() in (util.VIDEO_EXT | util.IMAGE_EXT))
    if not files:
        raise util.Fail(f"There are no videos or screenshots in {util.rel(folder)}.",
                        "Drop 2–5 videos or screenshots of the look you love into the Studio (or my-brand/references).")
    dirs = []
    from . import setup
    speech = setup._model_cached(util.load_profile().get("whisper_model", "small"))
    for f in files:
        d = REFS / ("f-" + util.slugify(f.stem))
        util.step(f"Analysing {f.name}…")
        try:
            analyze_ref(f, d, with_speech=speech)
            dirs.append(d)
        except util.Fail as e:
            util.warn(f"Skipped {f.name}: {e.message}")
    res = aggregate(name, dirs)
    style = draft_style(res, name)
    out = util.USER_STYLES_DIR / f"{name}.json"
    if not out.exists():
        util.write_json(out, style)
        util.ok(f"Draft style written: {util.rel(out)} (refine it after looking at the contact sheet)")
    res["draft_style"] = util.rel(out)
    util.write_json(TEACH / name / "measurements.json", res)
    return res
