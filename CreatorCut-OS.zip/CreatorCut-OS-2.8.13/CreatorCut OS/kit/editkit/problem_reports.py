"""Problem reports contain only selected facts, never logs or project content."""
import errno
import hashlib
from datetime import datetime
import re
import secrets
import time
import unicodedata
import uuid
from pathlib import Path

from . import diagnostics, telemetry, util

CHOICES = ("It got stuck", "The video looks wrong", "An error appeared", "Install problem", "Something else")
AREAS = frozenset("studio install update editor render reference footage captions music effects".split())
CLASSES = frozenset("input app host machine network".split())
HOST_REASONS = {
    "usage_limit": "The chat reported a usage limit.",
    "permission_denied": "A permission needed for the edit was denied.",
    "refused": "The chat declined the edit.",
    "context_full": "The chat reached its context limit.",
}
REASONS = {
    **HOST_REASONS,
    "unknown": "The editing step could not finish.",
    "storage": "The Mac ran out of available space.",
    "source": "The editing tools could not read the source footage.",
    "browser": "The rendering browser could not finish this step.",
    "access": "The editing tools could not access a required file or resource.",
    "timeout": "The editing tool stopped making progress.",
    "stuck": "Studio was open and the edit showed no progress for 20 minutes.",
    "waiting_chat_pickup": "Studio observed the first queued edit waiting for the chat to claim it for ten minutes. No edit had started.",
    "crash": "CreatorCut encountered an unexpected error.",
    "startup": "Studio could not start. The cause was not recorded.",
    "startup_timeout": "The local Studio server did not become ready before its startup deadline.",
    "startup_exit": "The local Studio server exited before it became ready.",
    "startup_access": "Studio was denied access to a local resource during startup.",
    "speech_recognition": "Speech recognition could not finish after the footage opened.",
    "silent_input": "A raw footage clip did not contain an audio track.",
    "video_tool_missing": "The local video reader was unavailable.",
    "missing_input": "A required project input was unavailable.",
}
CODE = re.compile(r"CC-[A-Z0-9]{5}\Z")


def directory():
    return util.STUDIO_OUT / "problem-reports"


def scrub(value, private=()):
    text = unicodedata.normalize("NFC", str(value or ""))
    for item in sorted(set(item for item in private if isinstance(item, str) and len(item) >= 3), key=len, reverse=True):
        text = re.sub(re.escape(unicodedata.normalize("NFC",item)), "[removed]", text, flags=re.I)
    text = re.sub(r"\b[\w.-]+\.[A-Za-z]{2,}/[^\s,;]*", "[removed]", text)
    text = re.sub(r"(?<!\w)[\w .()\-]{1,160}\.\w{2,5}\b", "[removed]", text, flags=re.I)
    text = re.sub(r"(?:https?://|file:|www\.)\S+", "[removed]", text, flags=re.I)
    text = re.sub(r"\b[^\s@]+@[^\s@]+\.[^\s@]+", "[removed]", text)
    text = re.sub(r"(?:\b[A-Za-z]:[\\/]|~?/)[^\r\n,;]*", "[removed]", text)
    text = re.sub(r"\b(?:bearer\s+\S+|(?:sk|ghp|github_pat|phc)[_-]\S+|[a-f0-9]{16,}|[A-Za-z0-9_+=/-]{25,})\b",
                  "[removed]", text, flags=re.I)
    text = re.sub(r"(?<!\w)@[\w.]+|(?<!\d)(?:\+?\d[(). -]*){7,}(?!\d)", "[removed]", text)
    return re.sub(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", "[removed]", text).strip()[:500]


def private_terms(project):
    profile = _data(util.PROFILE)
    contact = _data(util.STUDIO_OUT / "dashboard-contact.json")
    terms = [profile.get("name"), contact.get("email"), str(util.ROOT), str(Path.home())]
    if project:
        row = _data(project / "project.json")
        terms.extend((row.get("title"), row.get("name")))
        for item in row.get("media", []):
            terms.extend((item.get("name"), Path(item.get("file") or "").name))
    return terms


def report_path(code):
    if not isinstance(code, str) or not CODE.fullmatch(code):
        raise util.Fail("That report code is unavailable.")
    return directory() / (code + ".json")


def save(row):
    path = report_path(row["code"])
    util.write_durable_json(path, row)


def read(code):
    row = util.read_json(report_path(code), default={})
    if not row:
        raise util.Fail("That report is no longer saved.")
    return row


def _step(value):
    from editor import director
    return value if value in AREAS or value in director.LABELS else "editor"


def _timestamp(value):
    if type(value) in (int, float) and 0 < value < 4102444800:
        return datetime.fromtimestamp(value).astimezone().isoformat(timespec="milliseconds")
    return "not recorded"


def _data(path):
    try:
        row = util.read_json(path, default={})
        return row if isinstance(row, dict) else {}
    except (OSError, util.Fail):
        return {}


def _label(value):
    if isinstance(value, str) and re.fullmatch(r"[a-z0-9_:-]{1,80}", value):
        return value
    return "not recorded"


def contact_name():
    name = _data(util.PROFILE).get("name")
    if not isinstance(name, str):
        return None
    name = unicodedata.normalize("NFC", name).strip()
    if 0 < len(name) <= 80 and all(ch in " -'’." or unicodedata.category(ch)[0] in "LM" for ch in name):
        return name
    return None


def _caption_choice(choices, library):
    captions = choices.get("captions")
    selected = library.get("caption")
    if (choices.get("captions_on") is False or choices.get("captions_enabled") is False
            or captions is False or isinstance(captions, dict) and captions.get("enabled") is False
            or selected == "none"):
        return "Off"
    return "On"


def _music_mode(choices):
    selection = choices.get("music_selection") or {}
    return selection.get("mode") or choices.get("music")


def _library_ids():
    from . import library
    try:
        return {row["id"] for row in library.catalogue().get("entries", [])}
    except (OSError, util.Fail, KeyError):
        return set()


def _style_choice(choices, library, known):
    look = library.get("look")
    look_id = look.get("id") if isinstance(look, dict) else look
    if isinstance(look_id, str) and look_id in known:
        return look_id
    style = choices.get("style")
    if look or choices.get("preset_version") or style not in (None, "", "creatorcut-signature"):
        return "Custom or saved style"
    return "CreatorCut Signature"


def _evidence(project, status, area, reason, payload):
    request_id = status.get("request_id")
    request = _data(project / "creator-request.json") if project else {}
    if not request_id or request.get("id") != request_id:
        request = {}
    choices = request.get("choices") or {}
    library = choices.get("library_choices") or {}
    files = request.get("files") or {}
    refs = files.get("references") or []
    mac = payload["mac"]
    install = _data(util.STUDIO_OUT / "setup-ready.json")
    install_version = install.get("version")
    if not isinstance(install_version, str) or not re.fullmatch(r"[0-9.]{1,30}", install_version):
        install_version = "not recorded"
    lines = [
        f"Contact: {contact_name() or 'not entered'}",
        f"Report time: {_timestamp(time.time())} (local UTC offset shown)",
        f"Setup ready: {_timestamp(install.get('updated'))} · version {install_version}",
        "Machine: " + ", ".join(f"{key}={value}" for key, value in mac.items()) if mac else "Machine: not recorded",
        f"Failure: {_label(reason)} · step {area} · class {payload['failure_class']}",
    ]
    if not project:
        return lines
    if request:
        style = _style_choice(choices, library, _library_ids())
        effects = [item.get("id") for item in library.get("effects", []) if isinstance(item, dict)]
        lines.extend([
            f"Request created: {_timestamp(request.get('created'))} · claimed: {_timestamp(status.get('claimed_at') or status.get('started'))}",
            f"Choices: look {style} · captions {_caption_choice(choices, library).lower()} · music {_label(_music_mode(choices))}",
            "Selected effects: " + (", ".join(_label(item) for item in effects[:12]) or "none recorded"),
            f"Inputs: {len(files.get('raw') or [])} raw · {len(files.get('broll') or [])} B-roll · "
            + ("reference file" if any(isinstance(ref, dict) and ref.get("file") for ref in refs)
               else "reference link" if refs else "no reference"),
        ])
    else:
        lines.append("Saved request settings: not available for this report")
    completed = [_label(step) for step in (status.get("completed") or [])[:40]]
    if completed:
        lines.append("Completed steps: " + ", ".join(completed))
    history = diagnostics.report_timeline(project.name, request_id)
    lines.append("Recorded timeline:" if history else "Recorded timeline: no events available")
    for event in history:
        fields = ", ".join(f"{key}={value}" for key, value in event.items() if key not in ("time", "event"))
        lines.append(f"{_timestamp(event['time'])}  {event['event']}" + (f"  {fields}" if fields else ""))
    return lines


def _incident_context(project, status, events):
    """Project only approved settings and diagnostic fields onto the incident."""
    request_id = status.get("request_id")
    request = _data(project / "creator-request.json")
    if not request_id or request.get("id") != request_id:
        return {}
    from . import music_library

    choices = request.get("choices") or {}
    selection = choices.get("library_choices") or {}
    known = _library_ids()

    def known_id(item):
        value = item.get("id") if isinstance(item, dict) else item
        return value if isinstance(value, str) and value in known else None

    result = {"style": _style_choice(choices, selection, known)}
    result["effects"] = [value for item in selection.get("effects", [])
                         if (value := known_id(item))][:20]
    music = choices.get("music_selection") or {}
    mode = _music_mode(choices)
    if mode in music_library.MODES:
        result["music"] = {"none": "Off", "auto": "Auto", "library": "Library",
                           "upload": "Uploaded music"}[mode]
        track_id = music.get("id")
        if mode == "library" and isinstance(track_id, str) and re.fullmatch(r"[A-Za-z0-9_-]{1,80}", track_id):
            result["music"] = f"Library track {track_id}"

    milestones = ("requested", "claimed")
    markers = [next((event for event in events if event["event"] == name), None) for name in milestones]
    markers = [event for event in markers if event is not None]
    present = {event["event"] for event in markers}
    for event, timestamp in (("requested", request.get("created")), ("claimed", status.get("claimed_at") or status.get("started"))):
        if event not in present and _timestamp(timestamp) != "not recorded":
            markers.append({"event": event, "time": timestamp})
    recent = [event for event in events if event["event"] not in ("requested", "claimed")]
    budget = 19 - len(markers)
    failure = next((event for event in reversed(recent) if event["event"] == "step.failed"), None)
    recent = recent[-budget:]
    if failure and failure not in recent:
        recent = [failure, *recent[1:]]
    timeline = []
    caption = _caption_choice(choices, selection)
    if caption == "On" and (name := known_id(selection.get("caption"))):
        caption += " (" + name + ")"
    timeline.append({"time": _timestamp(request.get("created")), "step": "captions",
                     "status": "completed", "detail": caption})
    for event in sorted(markers + recent, key=lambda item: item["time"]):
        label = event["event"]
        state = {"requested": "started", "claimed": "started", "resumed": "started",
                 "step.started": "started", "resource.wait": "started", "rescue_used": "started",
                 "customer.input": "started", "step.failed": "failed", "stopped": "skipped"}
        entry = {"time": _timestamp(event["time"]), "step": event.get("stage") or label,
                 "status": state.get(label, "completed")}
        clip = event.get("clip")
        if type(clip) is int and 1 <= clip <= 10000:
            entry["clip_number"] = clip
        fields = ("outcome", "tool", "exit_code", "codec", "pixel_format", "width",
                  "height", "fps", "duration", "megabytes", "extension")
        detail = ", ".join(f"{key}={event[key]}" for key in fields if key in event)
        if detail:
            entry["detail"] = detail[:500]
        timeline.append(entry)
    result["edit_timeline"] = [entry for entry in timeline if entry["time"] != "not recorded"]
    return result


def build(project=None, *, trigger="button", area="editor", reason="unknown", failure_class="app",
          choice="", text="", signature=None, listener_detected=None):
    from editor import director
    status = director.status(project) if project else {}
    area = _step(status.get("failed_step") or area)
    chat_facts = status.get("report_chat_facts") or {}
    failure = status.get("rescue_failure") or {}
    if reason == "unknown" and project and failure.get("step") == area == status.get("failed_step"):
        reason = failure.get("reason") or reason
        failure_class = failure.get("class") or failure_class
    if reason == "unknown" and chat_facts.get("request") == status.get("request_id"):
        reason = chat_facts.get("reason") or reason
    reason = reason if reason in REASONS else "unknown"
    if reason in HOST_REASONS:
        headline = HOST_REASONS[reason]
    elif reason == "waiting_chat_pickup":
        headline = "Waiting for chat pickup"
    elif reason == "stuck":
        headline = f"Stuck at {area} for 20 min"
    else:
        headline = f"CreatorCut could not finish {area}"
    summary = REASONS[reason]
    attempts = status.get("rescue_attempts") or {}
    count = min(2, attempts.get(area, 0)) if isinstance(attempts.get(area, 0), int) else 0
    if count:
        summary += f" CreatorCut tried {count} recovery " + ("step." if count == 1 else "steps.")
    if project:
        summary += " Earlier saved versions were kept."
    code = "CC-" + "".join(secrets.choice("ABCDEFGHJKLMNPQRSTUVWXYZ23456789") for _ in range(5))
    payload = dict(telemetry.identity(), type="report", code=code, time=telemetry.utc(),
                   trigger=trigger, step=area, failure_class=failure_class if failure_class in CLASSES else "app",
                   headline=headline, ai_summary=summary, mac=telemetry.mac_details(report=True))
    if telemetry.incident_protocol():
        payload.update(incident_id=str(uuid.uuid4()), event_id=str(uuid.uuid4()))
        if name := contact_name():
            payload["name"] = name
        payload["error_code"] = reason
        payload["observed_error"] = REASONS[reason]
        if project:
            steps = diagnostics.report_timeline(project.name, status.get("request_id"))
            try:
                payload.update(_incident_context(project, status, steps))
            except (OSError, AttributeError, TypeError, ValueError, util.Fail):
                pass  # Old or damaged edit settings cannot suppress the failure.
            failure_event = {} if reason in HOST_REASONS else next(
                (row for row in reversed(steps) if row["event"] == "step.failed" and row.get("stage") == area), {})
            if type(failure_event.get("clip")) is int:
                payload["input_number"] = failure_event["clip"]
            if type(failure_event.get("exit_code")) is int:
                payload["exit_code"] = failure_event["exit_code"]
            if outcome := failure_event.get("outcome"):
                payload["error_code"] = outcome
                detail = {"missing_movie_index": "The movie index could not be found.",
                          "unsupported_decoder": "The local video decoder was unavailable.",
                          "invalid_media": "The video reader reported invalid media data."}.get(outcome)
                if detail:
                    payload["observed_error"] = detail
            if tool := failure_event.get("tool"):
                payload["tool"] = tool
        if type(listener_detected) is bool:
            payload["observed_error"] += " Studio detected a chat listener." if listener_detected else " Studio did not detect a chat listener."
    if choice in CHOICES:
        payload["choice"] = choice
    customer_text = scrub(text, private_terms(project)) if text else ""
    if customer_text:
        payload["customer_text"] = customer_text
    progress = status.get("overall_percent")
    version = status.get("version")
    state = status.get("state")
    lines = [headline, summary, f"CreatorCut {payload['app_version']} · {payload['host']}"]
    if state in ("working", "waiting_chat", "waiting_for", "paused", "needs_you", "done", "stopped"):
        lines.append(f"Edit state: {state}")
    if runtime := telemetry.mac_runtime():
        lines.append("Mac runtime: " + runtime)
    if type(listener_detected) is bool:
        lines.append("Chat listener detected: " + ("yes" if listener_detected else "no"))
    if type(progress) in (int, float) and 0 <= progress <= 100:
        lines.append(f"Progress: {round(progress)}%")
    if type(version) is int and version > 0:
        lines.append(f"Saved version: {version}")
    try:
        lines.extend(_evidence(project, status, area, reason, payload))
    except (OSError, AttributeError, TypeError, ValueError, util.Fail):
        lines.append("Some local evidence could not be read; the failure was still recorded.")
    payload["report_text"] = "\n".join(lines).encode("utf-8")[:48000].decode("utf-8", errors="ignore")
    if payload.get("incident_id"):
        # The deployed schema allows a short factual observation, while the
        # complete local report remains available to the customer by code.
        observed = [payload["observed_error"], f"CreatorCut support code {code}."]
        observed.extend(line for line in lines if line.startswith(
            ("Machine: ", "Mac runtime: ", "Edit state: ", "Completed steps: ", "Inputs: ", "Chat listener detected: ")))
        payload["observed_error"] = " ".join(observed)[:1000]
    return {"code": code, "payload": payload, "project": project.name if project else "",
            "request": status.get("request_id"), "signature": signature, "created": time.time(),
            "status": "saved"}


def submit(project=None, **facts):
    row = build(project, **facts)
    try:
        directory().mkdir(parents=True, exist_ok=True)
        with util.file_guard(directory() / ".reports.guard", timeout=2):
            signature = row.get("signature")
            recent = sorted(directory().glob("CC-*.json"), key=lambda file: file.stat().st_mtime)
            if signature:
                for file in reversed(recent):
                    previous = util.read_json(file, default={})
                    if previous.get("signature") == signature and (
                        row["request"] or time.time() - previous.get("created", 0) < 3600
                    ):
                        return previous
            for file in recent[:-99]:
                old = _data(file)
                if old.get("status") == "sent" and old.get("note_status") not in ("saved", "queued") and not any(
                        event.get("status") == "saved" for event in old.get("updates", {}).values()):
                    file.unlink(missing_ok=True)
            save(row)
    except OSError as error:
        if error.errno != errno.ENOSPC or not telemetry.enabled():
            raise
        # An atomic replacement may have succeeded before fsync ran out of space.
        if saved := _data(report_path(row["code"])):
            return saved
        # The queue was never reached. Try a compact report without writing files.
        if telemetry.post(telemetry.compact_report(row["payload"])) != 200:
            raise util.Fail("Could not save or send the report. Free some disk space and try again.") from error
        row.update(status="sent", status_format="compact", local_saved=False)
        return row
    deliver(row)
    if row["payload"].get("incident_id") and row["payload"].get("customer_text"):
        row = add_note(row["code"], row["payload"].get("choice"), row["payload"]["customer_text"])
    return row


def deliver(row, note=None, *, retry=False):
    if row.get("status") == "sent" and note is None:
        return
    if not telemetry.enabled():
        return
    payload = note or row["payload"]
    with util.file_guard(directory() / ".reports.guard", timeout=2):
        latest = read(row["code"])
        field = "note_status" if note is not None else "status"
        if latest.get(field) == "sent" or latest.get(field) == "queued" and not retry:
            row.update(latest)
            return
        if telemetry.enqueue(payload):
            latest[field] = "queued"
            save(latest)
        row.update(latest)


def recover_queue():
    """Restore unsent reports if Studio stopped between saving and queueing."""
    if not telemetry.enabled():
        return
    queued = {(item.get("type"), item.get("code"))
              for path in telemetry.queue_dir().glob("*.json")
              if (item := telemetry.queue_row(path).get("payload"))}
    for path in directory().glob("CC-*.json"):
        row = _data(path)
        code = row.get("code")
        payload = row.get("payload")
        if (not isinstance(code, str) or not CODE.fullmatch(code) or not isinstance(payload, dict)
                or payload.get("type") != "report" or payload.get("code") != code):
            continue
        try:
            if row.get("status") in ("saved", "queued") and ("report", code) not in queued:
                deliver(row, retry=True)
            note = row.get("note")
            if (row.get("status") in ("sent", "queued") and row.get("note_status") in ("saved", "queued")
                    and isinstance(note, dict) and ("report_note", code) not in queued):
                deliver(row, note, retry=True)
            updates = row.get("updates") or {}
            for entry in updates.values():
                if entry.get("status") == "saved" and isinstance(entry.get("payload"), dict):
                    telemetry.enqueue(entry["payload"])
        except (OSError, TypeError, ValueError, util.Fail):
            continue


def receipt(payload, *, sent, http_status=None, compact=False, full_http=None):
    with util.file_guard(directory() / ".reports.guard", timeout=2):
        if not report_path(payload["code"]).exists():
            return
        row = read(payload["code"])
        if payload["type"] == "report_update":
            entry = (row.get("updates") or {}).get(payload["event_id"])
            if entry:
                entry.update(status="sent" if sent else "rejected", http_status=http_status)
        else:
            field = "note_status" if payload["type"] == "report_note" else "status"
            row[field] = "sent" if sent else "rejected"
            if http_status is not None:
                row[field + "_http"] = http_status
            if field == "status":
                row["status_format"] = "compact" if compact else "full"
                if full_http is not None:
                    row["full_http"] = full_http
        save(row)


def add_note(code, choice, text):
    row = read(code)
    project = util.PROJECTS / row["project"] if row.get("project") else None
    with util.file_guard(directory() / ".reports.guard", timeout=2):
        row = read(code)
        if row.get("note_status") in ("queued", "sent"):
            return row
        note = {"type": "report_note", "code": code, "time": telemetry.utc(),
                "customer_text": scrub(text, private_terms(project)),
                "choice": choice if choice in CHOICES else "Something else"}
        if incident := row["payload"].get("incident_id"):
            note.update(incident_id=incident, event_id=str(uuid.uuid4()),
                        install_id=row["payload"]["install_id"], email=telemetry.contact()["email"],
                        name=contact_name())
        row["note"] = note
        row["note_status"] = "saved"
        save(row)
    deliver(row)
    deliver(row, note)
    return row


def public(row):
    return {"code": row["code"], "status": row["status"], "note_status": row.get("note_status"),
            "status_format": row.get("status_format"), "local_saved": row.get("local_saved", True),
            "copy": row["payload"]["report_text"] + "\nReport code: " + row["code"] +
                    ("\n" + row["note"]["customer_text"] if row.get("note") else
                     "\n" + row["payload"].get("customer_text", ""))}


def record_outcome(request, outcome, *, step=None, attempt=None):
    """Attach the outcome to saved incidents for this exact edit, using stable event IDs."""
    if not request or not telemetry.incident_protocol():
        return
    try:
        for path in directory().glob("CC-*.json"):
            row = _data(path)
            if row.get("request") != request:
                continue
            original = row.get("payload") or {}
            incident = original.get("incident_id")
            if not incident or (step and original.get("step") != step):
                continue
            namespace = uuid.UUID(incident)
            event_id = str(uuid.uuid5(namespace, f"{outcome}:{step or ''}:{attempt}"))
            update = {key: original[key] for key in ("install_id", "incident_id", "code") if key in original}
            update.update(type="report_update", event_id=event_id, time=telemetry.utc(), outcome=outcome)
            if step:
                update["step"] = step
            if type(attempt) is int:
                update["attempt"] = attempt
            with util.file_guard(directory() / ".reports.guard", timeout=2):
                latest = read(row["code"])
                updates = latest.setdefault("updates", {})
                if event_id not in updates:
                    updates[event_id] = {"payload": update, "status": "saved"}
                    save(latest)
                entry = updates[event_id]
            if entry["status"] == "saved":
                telemetry.enqueue(entry["payload"])
    except (OSError, TypeError, ValueError, util.Fail):
        pass


def automatic(project=None, *, area="editor", reason="unknown", failure_class="app",
              trigger="automatic", signature="", listener_detected=None):
    try:
        safe_id = hashlib.sha256(signature.encode()).hexdigest()[:24] if signature else None
        return submit(project, trigger=trigger, area=area, reason=reason, failure_class=failure_class,
                      signature=safe_id, listener_detected=listener_detected)
    except (OSError, ValueError, util.Fail):
        return None
