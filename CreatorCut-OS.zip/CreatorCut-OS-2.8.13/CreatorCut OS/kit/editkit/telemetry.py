"""Opt-in, bounded CreatorCut dashboard delivery."""
import hashlib
import http.client
import os
import shutil
import subprocess
import json
import platform
import re
import random
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timezone

from . import util

EVENTS = frozenset("""install_started install_step_done install_failed install_finished
studio_opened studio_alive make_pressed feedback_sent edit_claimed edit_step edit_heartbeat
edit_paused rescue_used effect_used effect_skipped edit_finished edit_failed download_clicked
update_installed update_failed history_summary install_identified""".split())
DETAILS = {
    "make_pressed": {"effects", "captions", "look", "reference", "music", "clip_seconds"},
    "feedback_sent": {"effects", "captions", "look", "reference", "music", "clip_seconds"},
    "edit_claimed": {"auto"}, "edit_heartbeat": {"waiting_for_chat"},
    "edit_finished": {"version", "effects_used", "effects_skipped", "rescues", "ai_steps"},
    "edit_failed": {"failure_class"}, "update_installed": {"from", "to"},
    "update_failed": {"from", "to"},
    "history_summary": {"videos", "finished", "failed", "last_version"},
}
PICKUP_WAIT_SECONDS = 600
SLUG = re.compile(r"[a-zA-Z0-9_-]{1,80}\Z")
_disabled = False
OWNER_EMAIL = "hello@nategold.ai"


def config():
    return util.read_json(util.KIT / "telemetry.json", default={})


def enabled():
    try:
        return (config().get("enabled") is True
                and not (util.STUDIO_OUT / "dashboard-opt-out").exists()
                and not owner_contact(contact()["email"]))
    except (OSError, ValueError, AttributeError, util.Fail):
        return False


def incident_protocol():
    # Enable only after Lovable confirms the versioned request and receipt contract.
    try:
        return config().get("report_protocol") == 2
    except (OSError, ValueError, AttributeError, util.Fail):
        return False


def utc():
    return datetime.now(timezone.utc).isoformat()


def queue_dir():
    return util.STUDIO_OUT / "dashboard-queue"


def install_id():
    path = util.STUDIO_OUT / "dashboard-install-id"
    try:
        return str(uuid.UUID(path.read_text().strip()))
    except (OSError, ValueError):
        pass
    with util.file_guard(path.with_suffix(".guard"), timeout=2):
        try:
            return str(uuid.UUID(path.read_text().strip()))
        except (OSError, ValueError):
            value = str(uuid.uuid4())
            path.write_text(value + "\n")
            return value


def email(value):
    value = value.strip() if isinstance(value, str) else ""
    return value if re.fullmatch(r"[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+", value) and len(value) <= 254 else None


def owner_contact(value):
    return isinstance(value, str) and value.strip().casefold() == OWNER_EMAIL


def identity():
    from . import editor
    host = editor.provider_name()
    address = contact()["email"]
    return {"install_id": install_id(), "app_version": (util.KIT / "VERSION").read_text().strip()[:30],
            "host": host if host in ("claude", "codex") else "unknown", "email": email(address)}


def _known_installer_host():
    from . import editor
    for host in (os.environ.get("CREATORCUT_HOST"), editor.detect_host(environ=os.environ)
                 if any(os.environ.get(key) for key in ("CLAUDE_PROJECT_DIR", "CLAUDE_SESSION_ID",
                        "CLAUDECODE", "CLAUDE_CODE_SESSION_ID", "CODEX_THREAD_ID")) else None,
                 editor.config().get("provider")):
        if host in ("claude", "codex"):
            return host
    return None


def _hardware(key):
    try:
        return subprocess.run(
            ["/usr/sbin/sysctl", "-n", key], capture_output=True, text=True,
            timeout=1, check=True,
        ).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return ""


def mac_details(*, report=False):
    macos = platform.mac_ver()[0]
    if not re.fullmatch(r"[0-9.]{1,30}", macos):
        return {}
    result = {"macos": macos}
    if report:
        chip = _hardware("machdep.cpu.brand_string") or platform.machine()
        if re.fullmatch(r"[A-Za-z0-9 .@()+-]{1,60}", chip):
            result["chip"] = chip
        memory = _hardware("hw.memsize")
        if memory.isdecimal() and len(memory) < 16:
            ram_gb = round(int(memory) / (1024 ** 3), 2)
            if 0 < ram_gb <= 512:
                result["ram_gb"] = ram_gb
        try:
            result["free_disk_gb"] = round(shutil.disk_usage(util.STUDIO_OUT).free / 1e9, 2)
        except OSError:
            pass
    return result


def mac_runtime():
    """Only hardware identifiers. The computer name is never queried."""
    if platform.system() != "Darwin":
        return ""
    model = _hardware("hw.model")
    arch = platform.machine()
    translated = _hardware("sysctl.proc_translated")
    fields = []
    if re.fullmatch(r"(?:Mac|iMac)[A-Za-z]*[0-9]+,[0-9]+", model):
        fields.append(f"model={model}")
    if arch in ("arm64", "x86_64"):
        fields.append(f"architecture={arch}")
    if translated in ("0", "1") or arch == "arm64":
        fields.append("rosetta=" + ("yes" if translated == "1" else "no"))
    return ", ".join(fields)


def _report_wire(payload):
    """Send the approved incident fields. Keep raw local evidence off the wire."""
    if not payload.get("incident_id"):
        return payload
    kind = payload["type"]
    wire = {key: payload[key] for key in ("incident_id", "event_id", "install_id", "time")}
    wire["type"] = "incident_update"
    if kind == "report":
        wire["kind"] = "failure"
        for key in ("code", "headline", "name", "email", "app_version", "step", "input_number",
                    "tool", "exit_code", "error_code", "observed_error", "mac", "style", "effects",
                    "music", "edit_timeline"):
            if key in payload:
                wire[key] = payload[key]
        if payload.get("host") in ("claude", "codex", "chatgpt"):
            wire["host"] = payload["host"]
    elif kind == "report_note":
        wire["kind"] = "note"
        for key in ("email", "name", "customer_text"):
            if payload.get(key):
                wire[key] = payload[key]
    elif kind == "report_update":
        outcome = payload["outcome"]
        wire["kind"] = {"retry_failed": "retry", "recovered": "recovery"}.get(outcome, "outcome")
        wire["result"] = {
            "retry_failed": "Retry did not finish",
            "needs_customer": "Edit needs the customer's help",
            "recovered": "Retry completed the failed step",
            "published": "Edited video was saved",
            "stopped": "Edit was stopped",
        }[outcome]
        if payload.get("step"):
            wire["step"] = payload["step"]
        if type(payload.get("attempt")) is int:
            wire["attempt"] = payload["attempt"]
            wire["result"] += f" (attempt {payload['attempt']})"
    else:
        raise ValueError("Unknown incident update")
    return wire


def compact_report(payload):
    fields = ("type", "code", "time", "install_id", "email", "app_version", "host",
              "trigger", "step", "failure_class", "headline", "mac")
    return {key: payload[key] for key in fields if key in payload}


def enqueue(payload):
    if not enabled() or owner_contact(payload.get("email")):
        return None
    path = queue_dir()
    path.mkdir(parents=True, exist_ok=True)
    wire = _report_wire(payload)
    raw = json.dumps(wire, ensure_ascii=False).encode()
    compact = False
    if wire["type"] == "incident_update":
        # The failure and selected settings always survive the timeline limit.
        timeline = list(wire.get("edit_timeline", []))
        if timeline:
            wire["edit_timeline"] = timeline
        while len(raw) > 12288 and len(timeline) > 1:
            removable = next((i for i, entry in enumerate(timeline)
                              if entry["status"] != "failed" and entry["step"] not in ("requested", "claimed")), None)
            if removable is None:
                break
            del timeline[removable]
            raw = json.dumps(wire, ensure_ascii=False).encode()
        if len(raw) > 12288:
            if payload["type"] != "report":
                raise ValueError("Incident update is too large")
            wire = compact_report(payload)
            raw = json.dumps(wire, ensure_ascii=False).encode()
            compact = True
    if len(raw) > (8192 if payload["type"] == "event" else 81920):
        raise ValueError("Dashboard payload too large")
    with util.file_guard(path / ".enqueue.guard", timeout=1):
        queued = sorted(path.glob("*.json"))
        if payload["type"] != "event":
            for existing in queued:
                saved = queue_row(existing)
                old = saved.get("payload") or {}
                if (old.get("type") == payload["type"] and old.get("code") == payload.get("code")
                        and old.get("event_id") == payload.get("event_id")):
                    return existing.name
        if len(queued) >= 500:
            events = [file for file in queued if (queue_row(file).get("payload") or {}).get("type") == "event"]
            keep = 499 if payload["type"] == "event" else 500
            for expired in events[:max(0,len(events)-keep)]:
                expired.unlink(missing_ok=True)
        name = f"{time.time_ns():020d}-{uuid.uuid4().hex}.json"
        write = util.write_json if payload["type"] == "event" and payload.get("name") != "install_identified" else util.write_durable_json
        row = {"payload": payload, "created": time.time()}
        if wire is not payload:
            row["wire"] = wire
        if compact:
            row["compact"] = True
        write(path / name, row)
    return name


def safe_detail(key, value):
    if key in ("captions", "look"):
        return value is None or isinstance(value, str) and re.fullmatch(r"[a-z0-9:-]{1,80}", value)
    if key == "effects":
        return isinstance(value, list) and len(value) <= 75 and all(safe_detail("look", item) for item in value)
    if key in ("from", "to", "last_version"):
        return isinstance(value, str) and re.fullmatch(r"[0-9.]{1,30}", value)
    if key in ("reference", "music", "failure_class"):
        return value in ("file", "link", "none", "auto", "library", "upload", "input", "app", "host", "machine", "network")
    return type(value) in (bool, int, float) and 0 <= value <= 86400


def event(name, *, project=None, request=None, step=None, seconds=None, percent=None, details=None, contact_name=None):
    if name not in EVENTS or not enabled():
        return
    try:
        payload = dict(identity(), type="event", name=name, event_id=str(uuid.uuid4()), time=utc(),
                       mac=mac_details(), video=None, details={})
        if name == "install_identified" and incident_protocol() and contact_name:
            payload["contact_name"] = contact_name
        if project:
            payload["video"] = hashlib.sha256((payload["install_id"] + project).encode()).hexdigest()[:20]
        if isinstance(request, str) and SLUG.fullmatch(request):
            payload["request_id"] = request
        if isinstance(step, str) and SLUG.fullmatch(step):
            payload["step"] = step
        for key, value, bound in (("seconds", seconds, 86400), ("percent", percent, 100)):
            if type(value) in (float, int) and 0 <= value <= bound:
                payload[key] = value
        if details:
            payload["details"] = {key: value for key, value in details.items()
                                  if key in DETAILS.get(name, ()) and safe_detail(key, value)}
        return enqueue(payload)
    except (OSError, ValueError, util.Fail):
        pass


def post(payload):
    """One object per request. Disable redirects so credentials stay on the configured endpoint."""
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None

    cfg = config()
    url = cfg.get("url", "")
    if not enabled() or owner_contact(payload.get("email")) or not url.startswith("https://") or not cfg.get("key"):
        return 0
    request = urllib.request.Request(url, data=json.dumps(payload, ensure_ascii=False).encode(),
                                     headers={"Content-Type": "application/json", "X-CreatorCut-Key": cfg["key"]})
    try:
        with urllib.request.build_opener(NoRedirect).open(request, timeout=5) as response:
            if response.status == 200 and payload.get("incident_id"):
                try:
                    ack = json.loads(response.read(8193))
                except (ValueError, UnicodeError):
                    return 502
                if (not isinstance(ack, dict) or ack.get("saved") is not True
                        or ack.get("incident_id") != payload["incident_id"]
                        or ack.get("event_id") != payload.get("event_id")):
                    return 502
            return response.status
    except urllib.error.HTTPError as error:
        if error.code == 409 and payload.get("type") == "incident_update":
            try:
                body = json.loads(error.read(8193))
                if isinstance(body, dict) and (body.get("error") == "incident_not_found" or body.get("code") == "incident_not_found"):
                    return 425  # Local retry category for a missing parent incident.
            except (ValueError, OSError, http.client.HTTPException):
                return 502
        return error.code
    except (OSError, ValueError, http.client.HTTPException):
        return 0


def queue_row(path):
    try:
        row = util.read_json(path, default={})
        payload = row.get("payload") if isinstance(row, dict) else None
        if not isinstance(payload, dict):
            return {}
        kind = payload.get("type")
        if kind == "event" and payload.get("name") in EVENTS:
            return row
        if kind in ("report", "report_note", "report_update") and isinstance(payload.get("code"), str) and re.fullmatch(r"CC-[A-Z0-9]{5,8}", payload["code"]):
            return row
    except (ValueError, OSError, util.Fail, TypeError):
        pass
    return {}


def flush(limit=20, only_code=None):
    global _disabled
    if _disabled or not enabled():
        return
    directory = queue_dir()
    try:
        directory.mkdir(parents=True, exist_ok=True)
        with util.file_guard(directory / ".send.guard", timeout=0):
            attempted = 0
            entries = [(path, queue_row(path)) for path in sorted(directory.glob("*.json"))]
            order = {"report": 0, "report_note": 1, "report_update": 1, "event": 2}
            entries.sort(key=lambda entry: order.get((entry[1].get("payload") or {}).get("type"), 3))
            for path, row in entries:
                if not row:
                    path.unlink(missing_ok=True)
                    continue
                payload = row["payload"]
                if owner_contact(payload.get("email")):
                    path.unlink(missing_ok=True)
                    continue
                if only_code is not None and payload.get("code") != only_code:
                    continue
                if payload.get("host") == "unknown" and not row.get("wire"):
                    host = _known_installer_host()
                    if not host:
                        continue
                    payload["host"] = host
                    util.write_durable_json(path, row)
                next_attempt = row.get("next_attempt", 0)
                if type(next_attempt) in (int, float) and next_attempt > time.time():
                    continue
                if attempted >= limit:
                    break
                attempted += 1
                kind = payload["type"]
                wire = row.get("wire") or _report_wire(payload)
                compact = row.get("compact") is True
                if payload.get("incident_id") and kind != "report":
                    from . import problem_reports
                    incident = problem_reports._data(problem_reports.report_path(payload["code"]))
                    if incident.get("status") != "sent":
                        if incident.get("status") == "rejected":
                            problem_reports.receipt(payload, sent=False, http_status=409)
                            path.unlink(missing_ok=True)
                        continue
                    if incident.get("status_format") == "compact":
                        if kind == "report_note":
                            wire = {key: payload[key] for key in ("type", "code", "time", "install_id", "choice", "customer_text")}
                        else:
                            problem_reports.receipt(payload, sent=False, http_status=409)
                            path.unlink(missing_ok=True)
                            continue
                code = post(compact_report(payload) if compact else wire)
                if code in (400, 413) and kind == "report" and not compact:
                    row.update(compact=True, full_http=code)
                    util.write_durable_json(path,row)
                    compact = True
                    code = post(compact_report(payload))
                if code == 401:
                    _disabled = True
                    break
                if code not in (200, 400, 409, 413) and not (code == 404 and kind == "event"):
                    count = row.get("attempts", 0)
                    count = count + 1 if type(count) is int and 0 <= count < 100 else 1
                    row.update(attempts=count, next_attempt=time.time()+min(600,5*2**min(count,7))+random.uniform(0,5))
                    util.write_json(path,row)
                    if code == 0:
                        break
                    continue
                if kind in ("report", "report_note", "report_update"):
                    from . import problem_reports
                    problem_reports.receipt(payload, sent=code == 200, http_status=code,
                                            compact=compact, full_http=row.get("full_http"))
                if code != 200:
                    util.log(f"Dashboard rejected {kind} ({code})")
                path.unlink(missing_ok=True)
    except (OSError, ValueError, util.Fail):
        pass


def contact():
    try:
        row = util.read_json(util.STUDIO_OUT / "dashboard-contact.json", default={})
    except (OSError, util.Fail):
        row = {}
    if not isinstance(row, dict):
        row = {}
    skips = row.get("skips", 0)
    return {"email": email(row.get("email")), "skips": min(2, max(0, skips)) if type(skips) is int else 0}


def contact_prompt():
    row = contact()
    videos = sum(path.is_file() for path in util.PROJECTS.glob("*/project.json"))
    return {"has_email": bool(row["email"]),
            "ask": not row["email"] and (row["skips"] == 0 or row["skips"] == 1 and videos >= 2)}


def save_contact(address, skip):
    row = contact()
    previous = row["email"]
    if skip:
        row["skips"] = min(2, row["skips"] + 1)
    else:
        row["email"] = email(address)
        if not row["email"]:
            raise util.Fail("Enter a valid email or choose Skip.")
    util.write_durable_json(util.STUDIO_OUT / "dashboard-contact.json", row)
    if owner_contact(row["email"]):
        # Retain the local opt-out even if contact information later changes.
        util.write_text(util.STUDIO_OUT / "dashboard-opt-out", "Disabled for this installation.\n")
    if row["email"] and not skip:
        if incident_protocol():
            publish_contact()
        elif row["email"] != previous:
            event("studio_alive")


def publish_contact():
    from . import problem_reports

    address = contact()["email"]
    if not address:
        return
    name = problem_reports.contact_name()
    fingerprint = hashlib.sha256(json.dumps([address, name]).encode()).hexdigest()
    marker = util.STUDIO_OUT / "dashboard-contact-queued"
    try:
        with util.file_guard(marker.with_suffix(".guard"), timeout=.1):
            if marker.is_file() and marker.read_text().strip() == fingerprint:
                return
            if event("studio_alive"):
                util.write_text(marker, fingerprint)
    except (OSError, ValueError, util.Fail):
        pass


def unclaimed_candidate(active):
    """Select the first ready request only when no edit is occupying the chat."""
    from editor import director

    if active.get("state") in ("working", "waiting_for", "waiting_resources", "needs_you", "paused"):
        return None
    for request in director.requests():
        rid = request["id"]
        delivery = director.read(director.OUT / "request-state" / (rid + ".json"))
        if delivery.get("cancelled") or delivery.get("delivered"):
            continue
        project = director.project(request["video"])
        state = director.status(project)
        if state.get("state") == "waiting_chat" and state.get("request_id") == rid:
            return project, rid
    return None


def observe_pickup(active, observation, now):
    """Count continuously observed waits only; sleep and restarts reset the clock."""
    from editor import director
    from . import problem_reports

    candidate = unclaimed_candidate(active)
    if not candidate:
        return None
    project, rid = candidate
    if not observation or observation[0] != rid:
        return rid, now, now, False
    _, started, last, reported = observation
    if not reported and now - last > 20:
        started = now
    if not reported and now - started >= PICKUP_WAIT_SECONDS:
        state = director.status(project)
        if state.get("state") != "waiting_chat" or state.get("request_id") != rid:
            return None
        reported = bool(problem_reports.automatic(
            project, area="editor", reason="waiting_chat_pickup", failure_class="host",
            signature=f"pickup:{rid}", listener_detected=director.waiter_alive()))
    return rid, started, now, reported


def watch():
    """One Studio-only observer. It sends queued facts and never drives an edit."""
    from editor import director, session
    from . import problem_reports
    last_alive = last_heartbeat = float("-inf")
    changed_at = time.monotonic()
    progress_key = None
    pickup = None
    event("studio_opened")
    try:
        problem_reports.recover_queue()
    except (OSError, ValueError, util.Fail):
        pass
    next_pickup_check = next_identity_check = 0
    while True:
        if enabled():
            try:
                now = time.monotonic()
                if now >= next_identity_check:
                    next_identity_check = now + 60
                    if incident_protocol():
                        publish_contact()
                if now - last_alive >= 600:
                    event("studio_alive")
                    last_alive = now
                update = util.read_json(util.STUDIO_OUT / "update.json", default={})
                from . import updater
                previous = util.read_json(updater.BACKUP / "backup.json", default={})
                old_version = previous.get("version") if isinstance(previous,dict) else None
                new_version = previous.get("target") if isinstance(previous,dict) and previous.get("phase")=="committed" else None
                if old_version and new_version==updater.current():
                    marker=util.STUDIO_OUT / "dashboard-last-update"
                    if not marker.exists() or marker.read_text().strip()!=new_version:
                        if event("update_installed",details={"from":old_version,"to":new_version}):
                            marker.write_text(new_version+"\n")
                history = util.STUDIO_OUT / "dashboard-history-sent"
                if update.get("status") == "done" and not history.exists():
                    projects = list(util.PROJECTS.glob("*/status.json"))
                    states = [director.status(path.parent) for path in projects]
                    queued = event("history_summary", details={"videos": len(states),
                          "finished": sum(s.get("state") == "done" for s in states),
                          "failed": sum(s.get("state") in ("failed", "needs_you") for s in states),
                          "last_version": old_version or identity()["app_version"]})
                    if queued:
                        history.touch()
                project = director.current()
                st = director.status(project) if project else {}
                if now >= next_pickup_check:
                    next_pickup_check = now + 10
                    pickup = observe_pickup(st, pickup, now)
                request = st.get("request_id")
                stage = st.get("active_step")
                active = st.get("state") in ("working", "waiting_for", "waiting_resources")
                key = (request, stage, st.get("step_label"), round(st.get("overall_percent") or 0))
                if key != progress_key or not active:
                    progress_key, changed_at = key, now
                if project and request and active and now - last_heartbeat >= 300:
                    event("edit_heartbeat", project=project.name, request=request, step=stage,
                          percent=st.get("overall_percent"), details={"waiting_for_chat": not director.command_alive(st)})
                    last_heartbeat = now
                if project and request and st.get("state") == "working" and now - changed_at >= 1200 and not director.command_alive(st) and session.alive(st.get("owner_process")) is True:
                    row = problem_reports.automatic(project, area=stage or "editor", reason="stuck", signature=f"stuck:{request}")
                    if row and st.get("problem_report_code") != row["code"]:
                        director.put(project, _request=request, problem_report_code=row["code"])
                    changed_at = now
                flush()
            except (OSError, ValueError, TypeError, director.Needed, util.Fail):
                pass
        time.sleep(5)
