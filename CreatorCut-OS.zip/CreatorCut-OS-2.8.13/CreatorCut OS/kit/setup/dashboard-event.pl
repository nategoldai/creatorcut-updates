#!/usr/bin/perl
# Installer-only sender. Available before CreatorCut's Python is installed.
use strict;
use warnings;
use JSON::PP;
use POSIX 'strftime';
use Time::HiRes ();
use Fcntl qw(:flock);

my ($root, $event, $step, $seconds) = @ARGV;
exit 0 unless defined $event && $event =~ /\A(?:install_started|install_step_done|install_failed|install_finished|studio_failed|install_blocked)\z/;
my $out = "$root/kit/studio-out";
exit 0 if -e "$out/dashboard-opt-out";
my $email;
if (open my $contact_file, '<', "$out/dashboard-contact.json") {
    my $contact = eval { decode_json(do { local $/; <$contact_file> }) };
    if (ref($contact) eq 'HASH' && defined $contact->{email} && !ref($contact->{email})) {
        my $address = $contact->{email};
        $address =~ s/\A\s+|\s+\z//g;
        exit 0 if lc($address) eq 'hello@nategold.ai';
        $email = $address if length($address) <= 254 && $address =~ /\A[^\s\@<>]+\@[^\s\@<>]+\.[^\s\@<>]+\z/;
    }
}
open my $config, '<', "$root/kit/telemetry.json" or exit 0;
my $settings = eval { decode_json(do { local $/; <$config> }) };
exit 0 unless ref($settings) eq "HASH" && JSON::PP::is_bool($settings->{enabled}) && $settings->{enabled};
exit 0 unless $settings->{url} =~ /\Ahttps:\/\/[a-z0-9.]+\/functions\/v1\/creatorcut-ingest\z/ &&
              $settings->{key} =~ /\A[a-zA-Z0-9_.-]+\z/;
mkdir $out unless -d $out;
open my $guard, '>>', "$out/dashboard-install-id.guard" or exit 0;
flock($guard, LOCK_EX) or exit 0;
sub uuid { my $id = lc `/usr/bin/uuidgen`; chomp $id; return $id; }
my $id;
if (open my $source, '<', "$out/dashboard-install-id") { chomp($id = <$source> // ''); }
unless (defined $id && $id =~ /\A[0-9a-f-]{36}\z/) {
    $id = uuid();
    open my $target, '>', "$out/dashboard-install-id" or exit 0;
    print {$target} "$id\n";
}
close $guard;
open my $version_file, '<', "$root/kit/VERSION" or exit 0;
chomp(my $version = <$version_file>);
exit 0 unless $version =~ /\A[0-9.]+\z/;
my $time = strftime('%Y-%m-%dT%H:%M:%SZ', gmtime);
my $event_id = uuid();
my $host = $ENV{CREATORCUT_HOST} // '';
unless ($host =~ /\A(?:claude|codex)\z/) {
    $host = ($ENV{CLAUDE_CODE_SESSION_ID} || $ENV{CLAUDE_SESSION_ID} || $ENV{CLAUDECODE} || $ENV{CLAUDE_PROJECT_DIR})
        ? 'claude' : $ENV{CODEX_THREAD_ID} ? 'codex' : 'unknown';
}
if ($host eq 'unknown' && open(my $provider_file, '<', "$out/editor/config.json")) {
    my $provider = eval { decode_json(do { local $/; <$provider_file> }) };
    if (ref($provider) eq 'HASH' && ($provider->{provider} // '') =~ /\A(?:claude|codex)\z/) {
        $host = $provider->{provider};
    }
}
my $mac = {};
if ($^O eq 'darwin' && -x '/usr/bin/sw_vers') {
    chomp(my $macos = `/usr/bin/sw_vers -productVersion`);
    $mac->{macos} = $macos if $macos =~ /\A[0-9.]{1,30}\z/;
}
my $payload = {type=>'event', install_id=>$id, event_id=>$event_id, time=>$time, name=>$event,
               app_version=>$version, host=>$host, email=>undef, mac=>$mac, video=>undef, details=>{}};
$payload->{step} = $step if defined $step && $step =~ /\A[a-z]+\z/;
$payload->{seconds} = 0+$seconds if defined $seconds && $seconds =~ /\A\d{1,5}\z/ && $seconds <= 86400;
if ($event eq 'studio_failed' || $event eq 'install_blocked') {
    my @alphabet = split //, 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    my $code = 'CC-' . join '', map { $alphabet[hex($_) % @alphabet] } (substr(($event_id =~ s/-//gr),0,10) =~ /(..)/g);
    my %reasons = (
        runtime_missing=>'The local Python runtime was missing.',
        runtime_repair=>'The local Python runtime failed during relocation or setup repair.',
        runtime_launch=>'The private environment could not start Python 3.12.',
        compatibility=>'The Mac did not meet the Apple silicon and macOS 14 minimum requirements.',
    );
    my $summary = $reasons{$step // ''} // 'Studio could not start before its local Python runtime loaded.';
    my $area = $event eq 'install_blocked' ? 'install' : 'studio';
    my $headline = $area eq 'install' ? 'This Mac did not meet setup requirements' : 'Studio could not start';
    my @facts = ($summary);
    if ($^O eq 'darwin') {
        chomp(my $arch = `/usr/bin/uname -m`);
        chomp(my $translated = `/usr/sbin/sysctl -n sysctl.proc_translated 2>/dev/null`);
        chomp(my $chip = `/usr/sbin/sysctl -n machdep.cpu.brand_string 2>/dev/null`);
        $mac->{chip} = $chip if $chip =~ /\A[A-Za-z0-9 .@()+-]{1,60}\z/;
        push @facts, "Process architecture: $arch" if $arch =~ /\A(?:arm64|x86_64)\z/;
        push @facts, "Rosetta translation: " . ($translated eq '1' ? 'active' : $translated eq '0' ? 'inactive' : 'not reported');
    }
    push @facts, "Launch stage: $step" if defined $step && exists $reasons{$step};
    push @facts, "Exit status: $seconds" if defined $seconds && $seconds =~ /\A\d{1,3}\z/ && $seconds <= 255;
    $payload = {type=>'report', install_id=>$id, code=>$code, time=>$time, app_version=>$version, host=>$host, mac=>$mac,
                trigger=>'automatic', step=>$area, failure_class=>'host', headline=>$headline,
                ai_summary=>$summary, report_text=>join("\n", @facts)};
}
$payload->{email} = $email if defined $email;
my $directory = "$out/dashboard-queue";
mkdir $directory unless -d $directory;
my $name = sprintf('%020d-%s.json', Time::HiRes::time() * 1000000000, $event_id);
my $file = "$directory/$name";
open my $queue, '>>', "$directory/.enqueue.guard" or exit 0;
flock($queue, LOCK_EX) or exit 0;
opendir my $spool_dir, $directory or exit 0;
my @saved = map { "$directory/$_" } sort grep { /\.json\z/ } readdir $spool_dir;
closedir $spool_dir;
unlink shift @saved while @saved >= 500;
open my $spool, '>', "$file.partial" or exit 0;
print {$spool} encode_json({payload=>$payload, created=>time});
close $spool;
rename "$file.partial", $file;
close $queue;
# The dashboard rejects unknown hosts. Studio resolves this before its first send.
exit 0 if $host eq 'unknown';
exit 0 if -e "$out/dashboard-opt-out";
# Installer can report even when Studio will never run. Use its stable event id.
open my $lock, '>>', "$directory/.send.guard" or exit 0;
flock($lock, LOCK_EX | LOCK_NB) or exit 0;
open my $data, '>', "$file.body" or exit 0;
print {$data} encode_json($payload);
close $data;
my $response = "$file.status";
my $denied = "$directory/.installer-denied-" . getppid();
if (-e $denied) {
    unlink "$file.body";
    exit 0;
}
pipe(my $headers, my $writer) or exit 0;
my $pid = fork();
if (defined $pid && $pid == 0) {
    close $writer;
    open STDOUT, '>', $response or exit 1;
    open STDIN, '<&', $headers or exit 1;
    exec '/usr/bin/curl', '--silent', '--max-time', '5', '--output', '/dev/null',
         '--write-out', '%{http_code}', '--config', '-', '--data-binary', "\@$file.body", $settings->{url};
    exit 1;
}
close $headers;
if ($pid) {
    print {$writer} "header = \"Content-Type: application/json\"\nheader = \"X-CreatorCut-Key: $settings->{key}\"\n";
    close $writer;
    waitpid($pid, 0);
}
if (open my $status, '<', $response) {
    my $code = <$status> // '';
    if ($code =~ /\A(?:200|400|413)\z/) {
        unlink $file;
        if ($code ne '200' && open my $log, '>>', "$out/dashboard-installer.log") {
            print {$log} "Dashboard rejected installer event ($code)\n";
        }
    } elsif ($code eq '401' && open my $flag, '>', $denied) {
        close $flag;
    }
}
unlink "$file.body", $response;
