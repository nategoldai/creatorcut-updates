#!/usr/bin/env bash
# CreatorCut OS: one-step installer for Mac and Linux.
#
#   bash kit/setup/install.sh               install (Claude Code shows the Studio in its Browser pane)
#   Studio is opened by the editor inside the host app after setup. Legacy --open no longer launches a browser.
#   bash kit/setup/install.sh --wait python wait until the private Python is ready (so the Studio can start), then exit
#
# Needs no password and no admin rights, and changes nothing outside this folder (plus the
# standard download cache). It downloads:
#   - FFmpeg + ffprobe (portable builds with caption support)  -> kit/bin/
#   - uv + a private Python 3.12                               -> kit/bin/
#   - the editing engine's Python packages                     -> .venv/
#   - a private Node 22 + HyperFrames + Remotion + headless browser (motion graphics) -> kit/bin/node, kit/render/
#   - the HyperFrames and Remotion skills for Claude Code      -> .claude/skills, .agents/skills
#   - text recognition + person detection (reading references) -> .venv/
#   - fonts, sound effects, and the speech model               -> kit/fonts, kit/sfx, model cache
# Progress is written live to kit/studio-out/progress.js, which Studio.html shows.
# Safe to run again: finished steps are skipped, so after a timeout just run it again.

set -u
export LC_ALL=C
INSTALL_ARGS=("$@")
INSTALL_CALLER_CWD="$PWD"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT" || exit 1
KIT="$ROOT/kit"; BIN="$KIT/bin"; OUT="$KIT/studio-out"
if [ "$(uname -s)" = Darwin ]; then
  # Keep this floor in sync with the pinned Python 3.12 arm64 ONNX Runtime wheel.
  mac_version="$(sw_vers -productVersion)"
  mac_major="${mac_version%%.*}"
  mac_arch="$(uname -m)"
  if [ "$mac_arch" != arm64 ] && [ "$(sysctl -n hw.optional.arm64 2>/dev/null || true)" = 1 ]; then
    mac_arch=arm64  # The installer itself can be launched under Rosetta.
  fi
  if [ "$mac_arch" != arm64 ] || ! [ "$mac_major" -ge 14 ] 2>/dev/null; then
    if [ -x /usr/bin/perl ]; then
      /usr/bin/perl "$KIT/setup/dashboard-event.pl" "$ROOT" install_blocked compatibility >/dev/null 2>&1 || true
    fi
    printf '%s\n' "This Mac has $mac_arch and macOS $mac_version. CreatorCut needs an Apple silicon Mac (M1 or newer) with macOS 14 or later. Nothing was installed." >&2
    exit 1
  fi
fi
PJS="$OUT/progress.js"; BEAT="$OUT/beat.js"; PIDF="$OUT/install.pid"; LOG="$OUT/install.log"
mkdir -p "$BIN" "$OUT"
export UV_PYTHON_INSTALL_DIR="$BIN/python"
export UV_CACHE_DIR="$BIN/cache"
export PIP_DISABLE_PIP_VERSION_CHECK=1
OS="$(uname -s)"; ARCH="$(uname -m)"
case "$OS" in Darwin) ARCH="$mac_arch"; PLAT=mac ;; *) PLAT=linux ;; esac
VPY="$ROOT/.venv/bin/python"
STEPS="python engine packages motion vision extras model studio"
NSTEPS=8
OPEN=0; WAIT=""; SKIP_MODEL=0; NO_SHORTCUT=1
while [ $# -gt 0 ]; do case "$1" in --open) echo "Studio opens inside your AI host. Ask your editor to open CREATORCUT after setup." ;; --skip-model) SKIP_MODEL=1 ;; --no-shortcut) NO_SHORTCUT=1 ;; --wait) WAIT="${2:-python}"; shift ;; esac; shift; done

private_python_ready() {
  # Never launch an old/system interpreter merely to discover it is too old.
  [ -x "$VPY" ] && [ -r "$ROOT/.venv/pyvenv.cfg" ] || return 1
  grep -Eq '^version([_a-z]*)[[:space:]]*=[[:space:]]*3\.12([.[:space:]]|$)' "$ROOT/.venv/pyvenv.cfg" || return 1
  if [ -x /usr/bin/perl ]; then
    # alarm survives exec: no detached watchdog and no recycled-PID signal.
    /usr/bin/perl -e 'alarm 60; exec @ARGV; exit 127' "$VPY" -c 'import sys; assert sys.version_info[:2] == (3, 12)' 2>/dev/null
  elif command -v timeout >/dev/null 2>&1; then
    timeout 60 "$VPY" -c 'import sys; assert sys.version_info[:2] == (3, 12)' 2>/dev/null
  else
    # Fresh uv metadata is checked here; the later required doctor still has
    # to execute successfully before setup can report that Studio is ready.
    return 0
  fi
}
# ------------------------------------------- --wait python: for the agent ----
if [ -n "$WAIT" ]; then
  wait_deadline=$((SECONDS + 240))
  while [ "$SECONDS" -lt "$wait_deadline" ]; do
    if private_python_ready; then echo "PYTHON_READY=1"; exit 0; fi
    if ! { [ -f "$PIDF" ] && kill -0 "$(cat "$PIDF" 2>/dev/null)" 2>/dev/null; }; then
      sleep 2; private_python_ready && { echo "PYTHON_READY=1"; exit 0; }
      echo "INSTALLER_NOT_RUNNING=1"; exit 2
    fi
    sleep 1
  done
  echo "PYTHON_READY=0"; exit 3
fi

# ---------------------------------------------------------------- helpers ----
say()  { printf '%s\n' "$*"; }
now()  { date +%s; }
STATE=running; CURRENT=""; ERROR_MSG=""; STARTED="$(now)"
for s in $STEPS; do eval "S_$s=todo; T0_$s=0; T1_$s=0"; done

write_progress() {
  local body="" sep="" st t0 t1 err="null"
  for s in $STEPS; do
    eval "st=\$S_$s; t0=\$T0_$s; t1=\$T1_$s"
    body="$body$sep\"$s\":{\"state\":\"$st\",\"start\":$t0,\"end\":$t1}"; sep=","
  done
  [ -n "$ERROR_MSG" ] && err="\"$ERROR_MSG\""
  printf 'window.AIE_PROGRESS = {"state":"%s","current":"%s","started":%s,"updated":%s,"os":"%s","error":%s,"order":["python","engine","packages","motion","vision","extras","model","studio"],"steps":{%s}};\n' \
    "$STATE" "$CURRENT" "$STARTED" "$(now)" "$PLAT" "$err" "$body" > "$PJS.tmp" && mv -f "$PJS.tmp" "$PJS"
}
dashboard_install() {
  if [ -x /usr/bin/perl ]; then
    /usr/bin/perl "$KIT/setup/dashboard-event.pl" "$ROOT" "$@" >/dev/null 2>&1 || true
  fi
}
begin() { CURRENT="$1"; eval "S_$1=running; T0_$1=$(now)"; write_progress; say ""; say "[$2/$NSTEPS] $3"; }
finish() { eval "S_$1=${2:-done}; T1_$1=$(now)"; write_progress; dashboard_install install_step_done "$1"; }
skip() { eval "S_$1=done; T0_$1=$(now); T1_$1=$(now)"; dashboard_install install_step_done "$1"; }
fail() {
  # $1 = step, $2 = plain-language message for the creator (no quotes)
  eval "S_$1=error; T1_$1=$(now)"; STATE=error; ERROR_MSG="$2"; write_progress; dashboard_install install_failed "$1"
  if [ "${NETWORK_PERMISSION_BLOCKED:-0}" = 1 ]; then
    say ""; say "Allow network access for this installation in your AI app, then run setup again. Your files are kept."
    say "SETUP_STATUS=needs_network_permission"
  else say ""; say "✗ $2"; say "SETUP_STATUS=error"; fi; say "SETUP_STEP=$1"; say "LOG=kit/studio-out/install.log"
  exit 1
}
dl() {  # dl URL FILE
  local partial="$2.part"
  printf '%s\n' "$partial" > "$OUT/transfer.path.tmp" && mv -f "$OUT/transfer.path.tmp" "$OUT/transfer.path"
  if command -v curl >/dev/null 2>&1; then
    local status=0
    curl -fL -C - --retry 3 --retry-delay 2 --connect-timeout 20 --max-time 900 --speed-limit 1024 --speed-time 90 -o "$partial" "$1" >>"$LOG" 2>&1 || status=$?
    # Some mirrors do not support ranges. Restart only this partial transfer once.
    if [ "$status" = 33 ]; then
      rm -f "$partial"
      curl -fL --retry 3 --retry-delay 2 --connect-timeout 20 --max-time 900 --speed-limit 1024 --speed-time 90 -o "$partial" "$1" >>"$LOG" 2>&1 || return 1
    elif [ "$status" != 0 ]; then
      if tail -30 "$LOG" | grep -Eiq 'operation not permitted|network access.*denied|sandbox.*network'; then NETWORK_PERMISSION_BLOCKED=1; fi
      return 1
    fi
  else
    wget -c -q --timeout=30 --tries=3 -O "$partial" "$1" >>"$LOG" 2>&1 || return 1
  fi
  mv -f "$partial" "$2"
  rm -f "$OUT/transfer.path"
}

checked_download() {
  dl "$1" "$2" || return 1
  local actual=""
  if command -v shasum >/dev/null 2>&1; then actual="$(shasum -a 256 "$2" | awk '{print $1}')"
  elif command -v sha256sum >/dev/null 2>&1; then actual="$(sha256sum "$2" | awk '{print $1}')"
  else say "A checksum tool is required before downloaded tools can be installed.";return 1;fi
  if [ "$actual" != "$3" ]; then say "The downloaded tool did not match its verified checksum. It was not installed.";rm -f "$2";return 1;fi
}
[ -f "$KIT/setup/binary-pins.sh" ] || fail python "The verified tool list is missing. Download CreatorCut again."
source "$KIT/setup/binary-pins.sh"

open_studio() {
  if [ "$PLAT" = mac ]; then open "$ROOT/Studio.html" >/dev/null 2>&1 || true
  else (xdg-open "$ROOT/Studio.html" >/dev/null 2>&1 &) || true; fi
}
has_libass() { "$1" -hide_banner -filters 2>/dev/null | grep -qE '^ *[A-Z.|]+ +ass +'; }

# ----------------------------------------------- only one installer at once ----
# A kernel lock owns the whole installation, including dependency writes. PID files are display only.
if [ "${CREATORCUT_INSTALL_LOCKED:-}" != "$$" ]; then
  if [ -x /usr/bin/perl ]; then
    cd "$INSTALL_CALLER_CWD" || exit 1
    exec /usr/bin/perl -MFcntl=:flock -e '
      my $path=shift @ARGV; $^F=1024; open(my $lock,">>",$path) or die "Cannot lock installation: $!\n";
      my $end=time()+300;
      until(flock($lock,LOCK_EX|LOCK_NB)){die "SETUP_STATUS=running\nAnother installation is still running.\n" if time()>=$end;sleep 1;}
      $^F=fileno($lock);$ENV{CREATORCUT_INSTALL_LOCKED}=$$;exec @ARGV;die "Cannot restart installer: $!\n";
    ' "$OUT/install.guard" bash "$KIT/setup/install.sh" ${INSTALL_ARGS[@]+"${INSTALL_ARGS[@]}"}
  elif command -v flock >/dev/null 2>&1; then
    exec 9>>"$OUT/install.guard"
    flock -w 300 9 || { say "SETUP_STATUS=running"; exit 2; }
  else
    say "The installation lock tool is unavailable. Ask your AI assistant to check the setup requirements.";exit 1
  fi
fi
echo $$ > "$PIDF"
MAINPID=$$
( while kill -0 "$MAINPID" 2>/dev/null; do
  printf 'window.AIE_BEAT = %s;\n' "$(date +%s)" > "$BEAT"
  stage="$(sed -n 's/.*"current":"\([a-z]*\)".*/\1/p' "$PJS" 2>/dev/null)"
  bytes=unknown
  if [ -f "$OUT/transfer.path" ]; then IFS= read -r transfer < "$OUT/transfer.path"; if [ -f "$transfer" ]; then bytes="$(wc -c < "$transfer" | tr -d ' ')";fi;fi
  printf 'SETUP_PROGRESS step=%s bytes=%s total=unknown state=running\n' "${stage:-starting}" "$bytes"
  sleep 5
 done ) &
BEATPID=$!
trap 'kill $BEATPID 2>/dev/null; wait $BEATPID 2>/dev/null; rm -f "$PIDF"' EXIT
: > "$LOG"
dashboard_install install_started

case "$OS-$ARCH" in Darwin-arm64|Linux-aarch64|Linux-arm64|Linux-x86_64) ;; *) fail python "This computer type is not supported by this installer yet." ;; esac
case "$ROOT" in *$'\n'*|*$'\r'*) fail python "Choose an app folder without line breaks in its name." ;; esac
if [ ! -f "$ROOT/.venv/pyvenv.cfg" ]; then
  FREE_KB="$(df -Pk "$ROOT" | awk 'NR==2{print $4}')"
  if [ -n "$FREE_KB" ] && [ "$FREE_KB" -lt 6291456 ]; then fail python "Free at least 6 GB before installing CreatorCut. Your current files have not been changed.";fi
fi
case "$ROOT" in *Library/Mobile\ Documents*|*Library/CloudStorage*|"$HOME"/Dropbox*|"$HOME"/Google\ Drive*) fail python "Choose a CreatorCut folder directly in your Home folder, outside cloud storage." ;; esac
if [ "$OS" = Darwin ]; then
  LINK_PROBE=$(mktemp -d "$ROOT/.setup-links.XXXXXX") || fail python "Choose a folder on your Mac’s own drive."
  if ! ln -s "$ROOT" "$LINK_PROBE/link"; then
    rmdir "$LINK_PROBE"
    fail python "This drive cannot store the editing tools. Choose a folder on your Mac’s own drive."
  fi
  rm "$LINK_PROBE/link"
  rmdir "$LINK_PROBE"
fi

say "CreatorCut OS setup ($PLAT, $ARCH). Nothing to do for you: the Studio shows the progress."
write_progress
[ "$OPEN" = 1 ] && open_studio

# -------------------------------------------------- 1. private Python (uv) ----
UV="$BIN/uv"

  if [ ! -x "$UV" ]; then
    begin python 1 "Preparing the private Python helper…"
    case "$PLAT-$ARCH" in
      mac-arm64) T=aarch64-apple-darwin ;; mac-*) T=x86_64-apple-darwin ;;
      linux-aarch64|linux-arm64) T=aarch64-unknown-linux-gnu ;; *) T=x86_64-unknown-linux-gnu ;;
    esac
    TMP="$BIN/tmp-uv"; mkdir -p "$TMP"
    cc_pin uv "$PLAT" "$ARCH" || fail python "This computer type is not supported yet."
    if checked_download "$PIN_URL" "$TMP/uv.tgz" "$PIN_SHA" && \
       (cd "$TMP" && tar -xzf uv.tgz) >>"$LOG" 2>&1; then
      u="$(find "$TMP" -type f -name uv | head -1)"; [ -n "$u" ] && mv -f "$u" "$UV" && chmod +x "$UV"
    fi
    [ -x "$UV" ] && rm -rf "$TMP"
  fi

if private_python_ready; then
  skip python; say "[1/8] Private Python: already installed ✓"
else
  begin python 1 "Setting up a private Python (about 30 MB)…"
  [ -x "$UV" ] || fail python "The Python helper could not be downloaded. Check the internet connection and run setup again."
  if [ -d "$ROOT/.venv" ]; then
    mv "$ROOT/.venv" "$ROOT/.venv.recovery.$(date +%s).$$" || fail python "The previous Python tools could not be preserved. Your app folder was kept."
  fi
  if [ "${CREATORCUT_TEST_ONLY:-0}" = 1 ] && [ "${CREATORCUT_DEV_TEST:-0}" = 1 ] && [ -n "${AIE_PYTHON:-}" ]; then   # isolated developer tests only
    "$UV" venv --python "$AIE_PYTHON" ${AIE_VENV_ARGS:-} "$ROOT/.venv" >>"$LOG" 2>&1
  else
    "$UV" venv --python 3.12.15 --python-preference only-managed "$ROOT/.venv" >>"$LOG" 2>&1
  fi
  private_python_ready || fail python "The app's private Python 3.12 could not be prepared. Run setup again; your computer's Python does not need changing."
  finish python; say "  ✓ Private Python ready"
fi
# Codex / no Browser pane: start the Studio server in the background and open it in the default browser
[ "$OPEN" = 1 ] && "$VPY" "$ROOT/edit.py" studio open >>"$LOG" 2>&1 &

# ------------------------------------------------- 2. video engine (FFmpeg) ----
FF="$BIN/ffmpeg"; FP="$BIN/ffprobe"
if [ -x "$FF" ] && [ -x "$FP" ] && has_libass "$FF"; then
  skip engine; say "[2/8] Video engine: already installed ✓"
else
  begin engine 2 "Downloading the video engine (FFmpeg, about 80 MB)…"
  TMP="$BIN/tmp-ffmpeg"; mkdir -p "$TMP"
  ok=0
  for tool in ffmpeg ffprobe; do
    cc_pin "$tool" "$PLAT" "$ARCH" || fail engine "This computer type is not supported yet."
    if checked_download "$PIN_URL" "$TMP/$tool.zip" "$PIN_SHA"; then
      mkdir -p "$TMP/$tool"
      unzip -o -q "$TMP/$tool.zip" -d "$TMP/$tool" >>"$LOG" 2>&1 || fail engine "The verified video tool could not be unpacked. Run setup again."
      executable="$(find "$TMP/$tool" -type f -name "$tool" | head -1)"
      [ -n "$executable" ] || fail engine "The video tool package is incomplete. Run setup again."
      if [ "$tool" = ffmpeg ]; then READY_FF="$executable"; else READY_FP="$executable"; fi
    else fail engine "The video tool download did not verify. Run setup again; your files are kept.";fi
  done
  mv -f "$READY_FF" "$BIN/ffmpeg" && mv -f "$READY_FP" "$BIN/ffprobe" || fail engine "The verified video tools could not be saved. Run setup again."
  ok=1
  rm -rf "$TMP"
  chmod +x "$BIN/ffmpeg" "$BIN/ffprobe" 2>/dev/null
  if [ $ok = 1 ] && "$BIN/ffmpeg" -hide_banner -version >/dev/null 2>&1 && has_libass "$BIN/ffmpeg"; then
    finish engine; say "  ✓ Video engine ready"
  else
    rm -f "$BIN/ffmpeg" "$BIN/ffprobe"
    fail engine "The video engine could not be downloaded. Check the internet connection and run setup again."
  fi
fi

# ------------------------------------------------ 3. editing engine packages ----
ENGINE_LOCK="$KIT/requirements-engine.lock"
[ -f "$ENGINE_LOCK" ] || fail packages "The verified dependency list is missing. Download CreatorCut again."
ENGINE_SHA="$("$VPY" -c 'import hashlib,sys;print(hashlib.sha256(open(sys.argv[1],"rb").read()).hexdigest())' "$ENGINE_LOCK")"
dependency_install_failed() {
  if tail -60 "$LOG" | grep -Eiq 'no matching distribution|no compatible wheel|no wheel.*platform|no wheels.*platform|platform tag|compatible wheel.*current platform'; then
    fail packages "The required editing tools are not supported on this Mac."
  fi
  fail packages "The editing tools could not download. Check the connection and run setup again."
}
packages_ready() {
  "$VPY" -c 'import sys;from pathlib import Path;sys.path.insert(0,"kit");import faster_whisper,PIL,certifi,yt_dlp;from editor.audio_check import check;check(Path.cwd())' >/dev/null 2>&1
}
if [ "$(cat "$BIN/engine-lock.sha256" 2>/dev/null)" = "$ENGINE_SHA" ] && packages_ready; then
  say "[3/8] Checking your editing tools…"
else
  begin packages 3 "Installing the editing tools (speech recognition and images, about 150 MB)…"
  if [ -x "$UV" ]; then
    "$VPY" "$KIT/tools/install_step.py" 1800 "$UV" pip install --python "$VPY" --require-hashes --only-binary :all: -r "$ENGINE_LOCK" >>"$LOG" 2>&1 || dependency_install_failed
  else
    "$VPY" "$KIT/tools/install_step.py" 1800 "$VPY" -m pip install -q --require-hashes --only-binary :all: -r "$ENGINE_LOCK" >>"$LOG" 2>&1 || dependency_install_failed
  fi
  packages_ready || fail packages "The speech tools need repairing. Run setup again to continue."
  printf '%s\n' "$ENGINE_SHA" > "$BIN/engine-lock.sha256"
  say "  ✓ Editing tools ready"
fi

CREATORCUT_HOST="$("$VPY" "$KIT/tools/configure_editor.py" --detect-host)" || fail packages "The editor host could not be selected. Run setup again."
export CREATORCUT_HOST
CREATORCUT_EDITOR_MODE="$("$VPY" -c 'import sys;sys.path.insert(0,"kit");from editkit import chat_execution;print(chat_execution.mode())')" || fail packages "The editing policy could not be read. Download CreatorCut again."
export CREATORCUT_EDITOR_MODE
finish packages
"$VPY" "$KIT/tools/configure_editor.py" --host "${CREATORCUT_HOST:-codex}" >>"$LOG" 2>&1 || fail packages "Your current edit must finish before setup changes its editing engine."

# --------------------------------------------- 4. fonts and sound effects ----
# ------------------------------------- 4. motion graphics (Node + HyperFrames + Remotion) ----
NODE_DIR="$BIN/node"; NODE="$NODE_DIR/bin/node"; NPM="$NODE_DIR/bin/npm"; RENDER="$KIT/render"
MOTION_SHA="$("$VPY" -c 'import hashlib,sys;print(hashlib.sha256(open(sys.argv[1],"rb").read()).hexdigest())' "$RENDER/package-lock.json")"
[ -n "$MOTION_SHA" ] || fail motion "The motion-graphics dependency list could not be read. Download CreatorCut again."
motion_ready() {
  [ "$(cat "$BIN/motion-lock.sha256" 2>/dev/null)" = "$MOTION_SHA" ] && \
  [ -x "$NODE" ] && "$NODE" "$KIT/setup/verify-render.cjs" "$RENDER" && "$NODE" -e 'process.exit(+process.versions.node.split(".")[0] >= 22 ? 0 : 1)' 2>/dev/null && \
  [ -f "$RENDER/node_modules/hyperframes-library/bin/hyperframes.mjs" ] && [ -x "$RENDER/node_modules/.bin/hyperframes" ] && [ -x "$RENDER/node_modules/.bin/remotion" ] && \
  [ -n "$(ls -d "$RENDER"/node_modules/.remotion/chrome-headless-shell/*/chrome-headless-shell-*/chrome-headless-shell 2>/dev/null | head -1)" ] && \
  [ -f "$KIT/skills-src/edit/SKILL.md" ] && [ -f "$KIT/docs/motion.md" ]
}
if motion_ready; then
  skip motion; say "[4/$NSTEPS] Motion graphics: already installed ✓"
else
  begin motion 4 "Installing motion graphics: HyperFrames, Remotion and a private browser (about 350 MB)…"
  if ! { [ -x "$NODE" ] && "$NODE" -e 'process.exit(+process.versions.node.split(".")[0] >= 22 ? 0 : 1)' 2>/dev/null; }; then
    case "$PLAT-$ARCH" in mac-arm64) NA=darwin-arm64 ;; mac-*) NA=darwin-x64 ;; linux-aarch64|linux-arm64) NA=linux-arm64 ;; *) NA=linux-x64 ;; esac
    TMP="$BIN/tmp-node"; mkdir -p "$TMP"
    cc_pin node "$PLAT" "$ARCH" || fail motion "This computer type is not supported yet."
    NV="$PIN_NAME"
    checked_download "$PIN_URL" "$TMP/node.tgz" "$PIN_SHA" && (cd "$TMP" && tar -xzf node.tgz) >>"$LOG" 2>&1 && \
      rm -rf "$NODE_DIR" && mv -f "$TMP/${NV%.tar.gz}" "$NODE_DIR"
    if [ -x "$NODE" ] && "$NODE" -e 'process.exit(+process.versions.node.split(".")[0] >= 22 ? 0 : 1)' 2>/dev/null; then rm -rf "$TMP"; else fail motion "The motion graphics engine could not be downloaded. Check the internet connection and run setup again.";fi
  fi
  export PATH="$NODE_DIR/bin:$BIN:$PATH" npm_config_cache="$BIN/npm-cache" npm_config_update_notifier=false npm_config_fund=false npm_config_audit=false npm_config_fetch_timeout=120000 npm_config_fetch_retries=2
  (cd "$RENDER" && "$VPY" "$KIT/tools/install_step.py" 1800 "$NPM" ci --no-audit --no-fund --loglevel=error) >>"$LOG" 2>&1 || \
    fail motion "HyperFrames and Remotion could not be installed. Check the internet connection and run setup again."
  (cd "$RENDER" && "$VPY" "$KIT/tools/install_step.py" 600 ./node_modules/.bin/remotion browser ensure) >>"$LOG" 2>&1 || \
    fail motion "The rendering browser could not be downloaded. Check the internet connection and run setup again."
  # Editing instructions ship in this verified package; never fetch moving third-party skills.
  "$VPY" "$ROOT/kit/tools/sync_skills.py" >>"$LOG" 2>&1 || fail motion "The editing instructions could not be installed. Run setup again."
  printf '%s\n' "$MOTION_SHA" > "$BIN/motion-lock.sha256"
  motion_ready || fail motion "The motion graphics tools didn't finish installing. Run setup again; it continues where it stopped."
  finish motion; say "  ✓ Motion graphics ready"
fi
# wrappers so every engine command finds the private Node, FFmpeg and browser
# Version-pinned robustness patch; never performed by an editing model.
"$VPY" "$ROOT/kit/tools/patch_render_runtime.py" "$RENDER" >>"$LOG" 2>&1 || \
  fail motion "The browser renderer needs a repair. Run setup again before editing."
for tool in hyperframes remotion; do
  cp "$ROOT/kit/setup/render-launcher.sh" "$BIN/$tool"
  chmod +x "$BIN/$tool"
done

# ------------------------------------- 5. reading references (text + person) ----
vision_ready() { if [ "$PLAT" = mac ]; then "$VPY" -c 'import ocrmac, Vision, scipy.ndimage, onnxruntime, cv2' 2>/dev/null; else "$VPY" -c 'import rapidocr_onnxruntime, scipy.ndimage, onnxruntime, cv2' 2>/dev/null; fi; }
if vision_ready; then
  skip vision; say "[5/$NSTEPS] Reference reading: already installed ✓"
else
  begin vision 5 "Installing text recognition and person detection (reads reference videos)…"
  if [ -x "$UV" ]; then "$VPY" "$KIT/tools/install_step.py" 1800 "$UV" pip install --python "$VPY" --require-hashes --only-binary :all: -r "$ENGINE_LOCK" >>"$LOG" 2>&1
  else "$VPY" "$KIT/tools/install_step.py" 1800 "$VPY" -m pip install -q --require-hashes --only-binary :all: -r "$ENGINE_LOCK" >>"$LOG" 2>&1; fi
  vision_ready || fail vision "Text recognition could not be installed. Check the internet connection and run setup again."
  finish vision; say "  ✓ Reference reading ready"
fi

begin extras 6 "Adding premium fonts and sound effects…"
for extra in fonts calibrate sfx music-gen; do
  "$VPY" "$ROOT/edit.py" "$extra" >>"$LOG" 2>&1 || "$VPY" "$ROOT/edit.py" "$extra" >>"$LOG" 2>&1 || fail extras "Some style assets are not ready. Run setup again; completed downloads are kept."
done
finish extras; say "  ✓ Fonts and sound effects ready"

# ------------------------------------------------------ 5. speech model ----
begin model 7 "Downloading speech recognition (about 500 MB, the longest step)…"
if [ "$SKIP_MODEL" = 1 ]; then finish model later; say "  Speech model deferred. Run setup again before editing spoken videos."
elif "$VPY" "$KIT/tools/install_step.py" 1800 "$VPY" "$ROOT/edit.py" model >>"$LOG" 2>&1; then "$VPY" "$KIT/tools/install_step.py" 900 "$VPY" -c 'import sys;sys.path.insert(0,"kit");from editkit import library;library.ensure_matting()' >>"$LOG" 2>&1 || fail model "The subject cutout model could not download. Run setup again to continue."
  "$VPY" -c 'import sys;from pathlib import Path;sys.path.insert(0,"kit");from editor.audio_check import check;check(Path.cwd())' >>"$LOG" 2>&1 || fail model "The speech tools need repairing. Run setup again."
  finish model; say "  ✓ Speech recognition ready"
else fail model "Speech recognition could not finish downloading. Check the connection and run setup again."; fi

# ---------------------------------------------------------- 6. the Studio ----
begin studio 8 "Building your Studio…"
"$VPY" "$ROOT/edit.py" studio --thumbs >>"$LOG" 2>&1 || "$VPY" "$ROOT/edit.py" studio >>"$LOG" 2>&1
[ "$NO_SHORTCUT" = 1 ] || "$VPY" "$ROOT/edit.py" studio app >>"$LOG" 2>&1 || true      # the CreatorCut Studio app icon (Applications / Spotlight)
[ "$NO_SHORTCUT" = 1 ] || "$VPY" "$ROOT/kit/tools/install_shortcut.py" >>"$LOG" 2>&1 || say "  CreatorCut is installed; the chat shortcut can be retried from setup."
"$VPY" "$ROOT/kit/tools/verify_setup.py" >>"$LOG" 2>&1 || fail studio "Some editing tools are not ready yet. Check the setup log and run setup again."
for native in scipy.ndimage cv2 onnxruntime faster_whisper; do
  "$VPY" -c 'import importlib,sys;importlib.import_module(sys.argv[1])' "$native" >>"$LOG" 2>&1 || \
    fail studio "The editing library $native could not load on this Mac. See the setup log."
done
finish studio
# Private download caches are retained for interrupted setup and repair.
STATE=done; CURRENT=""; write_progress
say ""
say "✓ Everything is installed."
for old_venv in "$ROOT"/.venv.recovery.*; do
  [ -d "$old_venv" ] && [ ! -L "$old_venv" ] && rm -rf "$old_venv"
done
touch "$ROOT/kit/studio-out/.install-complete"
say "SETUP_STATUS=done"
dashboard_install install_finished

if [ "${CREATORCUT_TEST_ONLY:-0}" != 1 ] && [ "$PLAT" = mac ]; then
  HANDOFF=$("$VPY" -c 'import sys; sys.path.insert(0,"kit"); from editor import director; print(director.setup_handoff()) if not director.listener_allowed(sys.argv[1]) else None' "$INSTALL_CALLER_CWD") || HANDOFF=""
  if [ -n "$HANDOFF" ]; then
    open -R "$ROOT" >/dev/null 2>&1 || true
    say "$HANDOFF"
  fi
fi
