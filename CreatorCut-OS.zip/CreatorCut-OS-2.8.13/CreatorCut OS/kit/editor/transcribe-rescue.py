"""Transcribe the assembled audio, in smaller pieces when recovering."""
import os
import subprocess
import sys
import tempfile
import wave
from pathlib import Path

from faster_whisper import WhisperModel
from speech import append_timed_word, samples, wav_samples

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from editkit import util


def main():
    project = Path(sys.argv[1])
    args = sys.argv[2:]
    whole = "--whole" in args
    prompt = next((arg for arg in args if arg != "--whole"), "Claude, Claude Code, skill.")
    work = project / "work"
    work.mkdir(exist_ok=True)
    model = WhisperModel(os.environ.get("CREATORCUT_SPEECH_MODEL", "small"), device="cpu", compute_type="int8")
    words = []

    def transcribe(audio, offset, total):
        segments, _ = model.transcribe(audio, word_timestamps=True, vad_filter=whole, initial_prompt=prompt)
        for segment in segments:
            for word in segment.words or []:
                append_timed_word(words, word.word.strip(), round(offset + word.start, 3), round(offset + word.end, 3))
            print(f'"percent": {min(100, 100 * (offset + segment.end) / total):.2f}', flush=True)

    with tempfile.TemporaryDirectory(dir=work) as scratch:
        audio = Path(scratch) / "audio.wav"
        subprocess.run([str(util.KIT / "bin/ffmpeg"), "-nostdin", "-v", "error", "-i",
                        str(project / "assets/aroll.mp4"), "-vn", "-ac", "1", "-ar", "16000",
                        str(audio)], check=True)
        with wave.open(str(audio)) as source:
            rate = source.getframerate()
            total = max(0.001, source.getnframes() / rate)
            if whole:
                transcribe(wav_samples(audio), 0, total)
            else:
                while source.tell() < source.getnframes():
                    offset = source.tell() / rate
                    transcribe(samples(source.readframes(rate * 60)), offset, total)
                    print(f'"percent": {100 * source.tell() / source.getnframes():.2f}', flush=True)
    util.write_json(work / "words_raw.json", words)
    util.write_json(project / "words.json", words)
    print(" ".join(f"{word['text']}@{word['start']:.2f}" for word in words))


if __name__ == "__main__":
    main()
