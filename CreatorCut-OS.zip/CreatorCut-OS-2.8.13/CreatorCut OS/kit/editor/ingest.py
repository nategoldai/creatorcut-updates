#!/usr/bin/env python3
"""Register raw clips for a CreatorCut project, make contact sheets, transcribe every clip.

Usage (run with PY, the skill's Python from .platform.json; it has faster-whisper):
  PY ingest.py <project_dir> <clip files or one folder> [--newest N]

Writes into <project_dir>:
  sources.json             {"c1": "/abs/original.MP4", ...}  (ordered oldest -> newest by file time)
  work/sheet_cN.jpg        8 frames across each clip; work/sheets.jpg stacks them (look at it: setups, angles)
  words_cN.json            word timestamps per clip (small.en)
  transcript.txt           per-clip segment transcript + speech regions (silencedetect) for picking takes
Originals are never modified. Everything is read straight from them (no proxies).
"""
import json
import os
import subprocess
import sys
import tempfile
from io import BytesIO
from pathlib import Path

sys.dont_write_bytecode = True   # no __pycache__ next to the scripts (a plugin's folder is not ours to write in)
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "style-library/scripts"))
import skillenv  # noqa: E402
from speech import append_timed_word, wav_samples

FF, FP = skillenv.tool('ffmpeg'), skillenv.tool('ffprobe')
VIDEO_EXT = ('.mp4', '.mov', '.m4v')


def probe(f):
    out = subprocess.run([FP, '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height,r_frame_rate',
                          '-show_entries', 'format=duration', '-of', 'json', f], **skillenv.TEXT).stdout
    j = json.loads(out)
    s = j['streams'][0]
    return s['width'], s['height'], s['r_frame_rate'], float(j['format']['duration'])


def speech_regions(f):
    # Match the transcription track and avoid decoding unused video frames.
    out = subprocess.run([FF, '-hide_banner', '-i', f, '-map', '0:a:0', '-vn', '-sn', '-dn',
                          '-af', 'silencedetect=n=-38dB:d=0.35', '-f', 'null', '-'],
                         **skillenv.TEXT).stderr
    marks = [(l.split('silence_')[1].split(':')[0], float(l.split(': ')[1].split(' ')[0]))
             for l in out.splitlines() if 'silence_start' in l or 'silence_end' in l]
    return ' '.join(f"{k[0].upper()}{v:.2f}" for k, v in marks)   # S=silence start, E=silence end


def contact_sheet(source, output, width, height, duration):
    # For long, high-resolution clips, decode only around the eight preview
    # points. This sheet is a visual aid. Assembly still validates the video.
    if duration >= 20 and width * height >= 3840 * 2160:
        from PIL import Image

        try:
            with tempfile.TemporaryDirectory(dir=Path(output).parent) as tmp:
                sheet = None
                for index in range(8):
                    at = (index + 0.5) * duration / 8
                    data = subprocess.check_output(
                        [FF, '-loglevel', 'error', '-ss', f'{at:.3f}', '-i', source,
                         '-map', '0:v:0', '-frames:v', '1', '-vf', 'scale=200:-2',
                         '-f', 'image2pipe', '-c:v', 'png', '-'],
                        stderr=subprocess.PIPE, timeout=8,
                    )
                    with Image.open(BytesIO(data)) as preview:
                        if sheet is None:
                            sheet = Image.new('RGB', (8 * preview.width, preview.height))
                        if preview.size != (sheet.width // 8, sheet.height):
                            raise ValueError('Inconsistent contact-sheet frame size')
                        sheet.paste(preview, (index * preview.width, 0))
                staged = Path(tmp) / 'sheet.jpg'
                sheet.save(staged, quality=90)
                os.replace(staged, output)
                return
        except (OSError, ValueError, subprocess.SubprocessError):
            # Seek support and stream/container durations vary across cameras.
            pass
    subprocess.run([FF, '-loglevel', 'error', '-y', '-i', source, '-vf',
                    f'fps=8/{duration},scale=200:-2,tile=8x1', '-frames:v', '1', output], check=True)


def main():
    skillenv.utf8_stdio()
    proj, args = skillenv.path_arg(sys.argv[1]), sys.argv[2:]
    newest = None
    if '--newest' in args:
        i = args.index('--newest'); newest = int(args[i + 1]); args = args[:i] + args[i + 2:]
    files = []
    for a in map(skillenv.path_arg, args):
        if os.path.isdir(a):
            files += [os.path.join(a, f) for f in os.listdir(a) if f.lower().endswith(VIDEO_EXT)]
        else:
            files.append(a)
    input_index = {os.path.abspath(f): i for i, f in enumerate(files, 1)}
    files = sorted(input_index, key=os.path.getmtime)
    if newest:
        files = files[-newest:]
    work = os.path.join(proj, 'work')
    os.makedirs(work, exist_ok=True)
    sources = {f'c{k + 1}': f for k, f in enumerate(files)}
    with open(os.path.join(proj, 'sources.json'), 'w', encoding='utf-8') as fh:
        json.dump(sources, fh, indent=1)

    print(json.dumps({'percent':2}),flush=True)
    sheets = [];durations={}
    for cid, f in sources.items():
        print(f'CREATORCUT_INGEST media {input_index[f]}', flush=True)
        w, h, fr, d = probe(f);durations[cid]=d
        print(f'{cid}  {w}x{h} {fr} {d:.1f}s  {os.path.basename(f)}')
        sh = os.path.join(work, f'sheet_{cid}.jpg')
        contact_sheet(f, sh, w, h, d)
        sheets.append(sh)
        print(json.dumps({'percent':5+15*len(sheets)/max(1,len(sources))}),flush=True)
    ins = sum((['-i', s] for s in sheets), [])
    stack = ['-filter_complex', f'vstack={len(sheets)}'] if len(sheets) > 1 else []
    subprocess.run([FF, '-loglevel', 'error', '-y', *ins, *stack, os.path.join(work, 'sheets.jpg')], check=True)

    # device='cpu': the default 'auto' picks CUDA on any PC with an NVIDIA card and then dies on the first clip with
    # "Library cublas64_12.dll is not found" unless the CUDA toolkit happens to be installed
    print('CREATORCUT_INGEST speech 0', flush=True)
    from faster_whisper import WhisperModel
    m = WhisperModel(os.environ.get('CREATORCUT_SPEECH_MODEL', 'small'), device='cpu', compute_type='int8')
    lines = []
    for cid, f in sources.items():
        print(f'CREATORCUT_INGEST media {input_index[f]}', flush=True)
        wav = os.path.join(work, f'{cid}.wav')
        subprocess.run([FF, '-loglevel', 'error', '-y', '-i', f, '-map', '0:a:0', '-vn', '-ac', '1', '-ar', '16000', wav], check=True)
        print(f'CREATORCUT_INGEST speech {input_index[f]}', flush=True)
        segs, _ = m.transcribe(wav_samples(wav), word_timestamps=True, vad_filter=True)
        words = []
        lines.append(f'===== {cid}  {os.path.basename(f)}')
        for s in segs:
            print(json.dumps({'percent':20+70*((list(sources).index(cid)+min(1,s.end/max(.01,durations[cid])))/max(1,len(sources)))}),flush=True)
            lines.append(f'[{s.start:6.2f}-{s.end:6.2f}] {s.text.strip()}')
            for w in s.words:
                append_timed_word(words, w.word.strip(), round(w.start, 3), round(w.end, 3))
        word_file = os.path.join(proj, f'words_{cid}.json')
        with open(word_file + '.partial', 'w', encoding='utf-8') as fh:
            json.dump(words, fh, indent=1)
        os.replace(word_file + '.partial', word_file)
        lines.append('words: ' + ' '.join(f"{w['text']}@{w['start']:.2f}" for w in words))
        lines.append('speech map: ' + speech_regions(f))
    with open(os.path.join(proj, 'transcript.txt'), 'w', encoding='utf-8') as fh:   # utf-8: Whisper emits curly quotes, notes
        fh.write('\n'.join(lines) + '\n')
    print('\n'.join(lines))


if __name__ == '__main__':
    main()
