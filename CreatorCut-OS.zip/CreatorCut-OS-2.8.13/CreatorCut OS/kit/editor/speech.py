"""Read the mono 16 kHz PCM audio extracted by CreatorCut’s FFmpeg."""

def samples(raw):
    import numpy as np
    return np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0


def wav_samples(path):
    import wave
    with wave.open(str(path)) as audio:
        if (audio.getnchannels(), audio.getsampwidth(), audio.getframerate()) != (1, 2, 16000):
            raise ValueError("Expected mono 16 kHz PCM audio")
        return samples(audio.readframes(audio.getnframes()))


def speech_cut_edges(project):
    """Give likely clipped words a little room at a verified quiet boundary."""
    import json
    import wave
    from bisect import bisect_left
    import numpy as np

    path = project / 'edl.json'
    sections = json.loads(path.read_text())
    changed = []
    for clip in dict.fromkeys(section['clip'] for section in sections):
        if not (isinstance(clip, str) and clip.startswith('c') and clip[1:].isdigit()):
            continue
        try:
            words = json.loads((project / f'words_{clip}.json').read_text())
            audio = wave.open(str(project / 'work' / f'{clip}.wav'), 'rb')
        except (OSError, ValueError, EOFError, wave.Error):
            continue
        with audio:
            if (audio.getnchannels(), audio.getsampwidth(), audio.getframerate()) != (1, 2, 16000):
                continue
            duration = audio.getnframes() / 16000
            if not isinstance(words, list):
                continue
            words = [w for w in words if isinstance(w, dict)
                     and type(w.get('start')) in (float, int) and type(w.get('end')) in (float, int)
                     and 0 <= w['start'] < w['end'] <= duration + .25]
            starts = sorted(w['start'] for w in words)
            ends = sorted(w['end'] for w in words)
            def quiet(at):
                start = int((at - .025) * 16000)
                if not 0 <= start <= audio.getnframes() - 800:
                    return False
                audio.setpos(start)
                window = samples(audio.readframes(800))
                return window.size == 800 and float(max(np.sqrt(np.mean(window.reshape(5, 160)**2, axis=1)))) <= .0126

            rows = [s for s in sections if s['clip'] == clip]
            for section in rows:
                for edge, boundaries, direction in (('in', starts, -1), ('out', ends, 1)):
                    at = section[edge]
                    index = bisect_left(boundaries, at)
                    closest = min(boundaries[max(0, index-1):index+1], key=lambda t: abs(t-at), default=None)
                    if closest is None or abs(closest-at) > .12 or quiet(at):
                        continue
                    # Stay clear of adjacent kept material and of the next
                    # excluded word. Keep longer pauses and creative timing intact.
                    if direction < 0:
                        limits = [s['out'] for s in rows if s is not section and s['out'] <= at]
                        limits += [w['end'] + .015 for w in words if w['end'] <= at and w['end'] <= closest - .025]
                        bound = max([0, at - .24, *limits])
                    else:
                        limits = [s['in'] for s in rows if s is not section and s['in'] >= at]
                        limits += [w['start'] - .015 for w in words if w['start'] >= at and w['start'] >= closest + .025]
                        bound = min([duration, at + .24, *limits])
                    for offset in (.06, .08, .10, .12, .14, .16):
                        candidate = round(closest + direction * offset, 3)
                        if (candidate-at)*direction < .02 or (bound-candidate)*direction < 0:
                            continue
                        # Quiet for 50 ms across the cut, including room for the fade.
                        if quiet(candidate):
                            section[edge] = candidate
                            changed.append({'clip':clip, 'edge':edge, 'from':at, 'to':candidate})
                            break
    return sections, changed


def append_timed_word(words, text, start, end):
    """Keep adjacent pieces of a name, version number or single-letter compound together."""
    if not text:
        return
    previous = words[-1] if words else None
    numeric_suffix = text[:1] in ('-', '.') and text[1:2].isdigit()
    letter_suffix = (
        previous is not None and len(previous['text']) == 1 and previous['text'].isalpha()
        and text.startswith('-') and text[1:2].isalpha() and start <= previous['end'] + 0.1
    )
    if previous is not None and (numeric_suffix or letter_suffix):
        previous['text'] += text
        previous['end'] = max(previous['end'], end)
    else:
        words.append({'text': text, 'start': start, 'end': end})
