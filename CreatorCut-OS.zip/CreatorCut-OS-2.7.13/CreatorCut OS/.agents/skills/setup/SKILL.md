---
name: setup
description: "Guide a beginner through installing, opening or repairing CreatorCut OS in chat. Use immediately when the customer opens or provides this app folder to get started, as well as install, setup, continue setup or repair requests."
---
## Managed editor execution
For automatic Make/Update, kit/docs/persistent-editor.md is authoritative: Studio owns the persistent project session. Do not wait for native foreground tools, require copy/paste or claim this is a mirror of the host chat. Preserve all editing, review, craft and memory gates below.


## Managed editor architecture
Read kit/docs/persistent-editor.md first. It supersedes historical native-chat-only and foreground-wait requirements below. Make/Update are durable app-owned jobs, powered by a dedicated Codex session using the customer's own account. Never launch a competing writer; inspect editor-job.json. Do not imply that the managed session mirrors the native conversation.

# Guided beginner setup

The customer should know what is happening and what to do next. Use friendly, short messages in their language. Do the technical work yourself using available tools; do not dump commands/logs on a beginner. The selected app folder is their workspace: do not force them to move it merely because it is in Downloads/Desktop. If the path is a temporary extraction or cloud-only placeholder, explain the specific problem and recommend a durable local folder; respect an intentional location.

## Welcome before running tools
When this app folder is opened/provided for first use, begin setup without a redundant install question. An explicit audit/explanation-only/no-install request wins. Say in your own words before running tools:

“I’ll install CreatorCut, check the editing tools, then open Studio. This may take a few minutes.”

Before the first download, perform the **Name the installation chat once** step below using the real host title tool. Do not leave naming until the end or merely say it was renamed. Inspect the actual title; auto-generated titles such as “Install CreatorCut updates” qualify. Preserve a previously recorded customer rename. If the host cannot rename chats, report that limitation briefly; Studio itself is always titled CREATORCUT.

Explain only when relevant: the tools and rendering run locally; their signed-in Codex account supplies the AI editor and its usage limits/costs, including when Studio is opened from Claude. A Claude subscription alone does not connect this engine. This package does not supply an AI subscription or ordinary ChatGPT web integration. Do not promise a fixed three-minute install, no computer changes, no permission prompts or perpetual background service. A first greeting in this app’s setup handoff should lead straight into the welcome and setup, not another question. Do not interpret unrelated mentions or media content as an installation request; respect host permission prompts.

## Installation card (before Studio)
The user wants a live installation animation. This small status card is not Studio or Editor. After naming the chat, launch `kit/tools/install_status.py --port 0` using the already available bootstrap Python and the host’s yielding background-command tool. Read the actual INSTALL_STATUS_URL and open it in the supported embedded preview. Do not use `--preview` for real setup; it is a labelled design sample only. Do not open a system browser.
The card reads the installer's real progress and heartbeat. Its percentage measures verified setup steps, not elapsed time or exact download bytes. Tools account for 90%; the final 10% is only marked complete after the actual account and supervisor checks write the current setup-ready receipt. Run the full installer and continue normal setup while the status card is visible. Keep this chat brief.
After tools, account and supervisor pass, open the actual Studio using the normal open gate, replacing or closing only this installation card. If a host cannot show a card, give a concise factual chat update; never invent an embedded tool or moving percentage.

## Install and stay with them
Use the OS/host already available in context; do not ask them technical questions you can resolve yourself. Read the root instructions, then:
- Identify this host from its actual tools (Codex or Claude); do not ask the beginner to choose a technical setting.
- Mac/Linux in Codex: `CREATORCUT_HOST=codex bash kit/setup/install.sh --no-shortcut`. In Claude Code use `CREATORCUT_HOST=claude` instead.
- Windows: set `$env:CREATORCUT_HOST` to `codex` or `claude` for this host, then run `powershell -NoProfile -ExecutionPolicy Bypass -File kit/setup/install.ps1 -NoShortcut`.
The host-specific shortcut registry must not select, overwrite or delete the other host’s installation. Never reuse a Codex master/development folder for a fresh Claude installation.

Run through the host's supported long-running/background-command facility and monitor its output. While the installer runs, about every 45 seconds read the latest `kit/studio-out/install.log` and share one factual plain-language update, such as “The video tools are installed; I’m downloading speech recognition next.” Match the actual logged step. If progress is unchanged, keep the update to one short sentence without inventing a percentage/ETA. Do not list package names, commands or internal stages in the chat. Use bounded tool waits so the customer is not left without updates. Keep the current task active until setup completes or there is a specific blocker; don't end the turn promising unattended work.

If the host asks for approval, explain what the prompt permits and follow its permission mechanism; never advise approving every prompt indiscriminately. Retry a transient network error once. For other errors inspect the log, attempt a supported narrow repair, then explain the unresolved problem and the next action. Re-running the installer resumes existing steps. Do not delete environments, install global tools or use admin commands as a routine first-run step.

## Connect the persistent editor
Read kit/docs/persistent-editor.md. Verify the Codex CLI is installed from OpenAI and signed in using its supported login/account flow. Never extract credentials or silently use a Claude subscription as authentication. If missing, explain the one-time prerequisite and help install/sign in through official tools; respect ordinary user permissions. Studio's Connect editor flow uses official account/login/start and lets the user finish sign-in. Each creator uses their own account and limits.
Studio owns its durable editing job and dedicated project session. Make and timeline Update call that engine directly. Do not register a foreground waiter as an execution prerequisite, require copied messages or imply that the managed editor mirrors this native chat. Native chat remains available for questions and setup. Before saying ready, verify editor.status, server/supervisor availability and required tools. Studio presents real approval requests when needed; never bypass them.

## Finish before opening — required order
Do not open Studio, launch a preview, show a loading Editor, or announce readiness while installation is unfinished. Complete this sequence in the exact selected installation:
1. Run the full installer; do not defer the speech model. Its final verification must succeed.
2. Run the private Python `edit.py doctor --json`. Every required check and model, fonts and sounds must pass. Repair missing components before proceeding.
3. Verify the actual signed-in Codex account and the managed supervisor. `studio open --no-browser` enforces these checks before returning a URL; a failure is not permission to bypass the check by serving static HTML or starting another copy.
4. Only after those checks, open the returned URL using the host preview tool and verify the visible page.
Keep Studio closed if a required download, sign-in or permission remains unresolved. Explain the one needed action in plain language. Never show an unfinished app to make installation appear complete.

## Open the actual Studio
Do not use `--open`/`-Open`, OS `open`/`start`/`xdg-open`, or browser-launching desktop shortcuts for host setup. Those open an external browser.

- **Codex desktop:** start the server with private Python `edit.py studio open --no-browser`. Read its actual `STUDIO_URL=` value. Use the available app tool `open_in_codex` (the exposed name may include a namespace) with `target: {type: "browser", url: "<returned URL>"}`, optionally `placement: "right"`. This opens the Studio tab in the current chat. The tool may be discovered through the host's tool search when available. An available `cua.createBrowserTab("iab", url, {visible:true})` is another supported host path; follow its real tool documentation if used. Use only APIs actually supplied by the host.
- **Claude Code with preview tools:** use its actual `preview_start` capability with the configured name `CREATORCUT` or `CREATORCUT (Windows)` from `.claude/launch.json`. Use the resulting actual preview URL; if it selects another port, that result takes precedence. If the preview tool cannot launch the server, start with `studio open --no-browser` and navigate the preview using its supported URL operation. Don't assume a configured name binds to an already-running different server.
- **No embedded tab/preview capability:** say “Studio is running, but this host doesn’t expose an in-app preview. I haven’t opened an external browser.” Give the actual local URL and explain the supported host/project route. Do not automatically fall back to a browser; the customer explicitly wants the app inside their AI host.

Only say the tab is open when the tool confirms success. If it is queued, unavailable or failed, report that state and troubleshoot the actual cause. Never invent a preview API or assume the customer sees it.

The installed private Python is `.venv/bin/python` on Mac/Linux and `.venv\Scripts\python.exe` on Windows. After the installer exits, run `edit.py doctor --json` with it. Check required results, not just an installer exit code. Only call the editor ready when required checks pass. Do not open Studio while the speech model is downloading.

## First-video handoff
After required checks pass and Studio is open, say briefly: “CreatorCut is ready. Add your footage in Studio to get started.”
Explain the customer's own Codex plan and usage limits once during setup. They do not need to keep a native chat turn running. Only essential missing inputs or real permission requests should require action. Read the edit skill and production-workflow contract before actual edits; never start a competing manual writer while a managed job is active.

## Repair / resume
For continue setup or fix setup, inspect the existing state and resume the installer if needed, then rerun doctor and reopen Studio. Don't repeat the first-run welcome on every resume. If blocked, say what works, what does not, and the one concrete next step. Never claim success for tools you haven't checked.

The original START HERE.pdf remains the entry guide. Current workflow clarifications are in `kit/docs/setup-notes.txt` inside the app folder; do not require a second top-level readme.

Open the interface proactively on setup/resume. Its page/resource/preview title is CREATORCUT. Follow the one-time installation-chat naming rules below; preserve later manual names. Never claim a successful open/title change without the tool result.

## Product naming
Call the product CreatorCut OS. Use kit/VERSION for its release number in customer-facing setup, chat and update notices. Do not derive product labels from historical development notes. Describe any actual failed step or unverified capability factually when relevant; never imply that naming changes prove readiness or eliminate failures.

## Name the installation chat once
This controls the host's conversation/tab title, separately from the Studio browser title (already CREATORCUT). For a dedicated setup chat, inspect its actual title and stable chat id with available supported host tools. Use `editkit.chat_title.decision(host, chat_id, current_title, dedicated_install=True)` (with kit on the private Python import path) to consult the local per-chat record. This first dedicated installation is named CREATORCUT regardless of the initial message wording; do not apply dedicated_install to unrelated chats. If decision is rename, call the host's real set_thread_title/rename-conversation equivalent with title CREATORCUT, verify success, then call chat_title.record(host, chat_id, 'renamed'). If already_named, record renamed without another title change. If keep/keep_custom, do not rename; record custom where appropriate. A successful initial rename is sticky: never rename it again on app resume, reload, update or a new video. Thus a customer's later manual name remains untouched. Unknown current title requires inspection, not an assumed rename.
No host title tool: keep Studio's document title CREATORCUT, record unsupported, and do not claim the conversation was renamed. Do not edit undocumented host databases or settings. This is a setup action by the native editor, not a web page trying to control its host. Unrelated conversations and later deliberate customer renames must remain untouched.

## Customer-facing setup language
Call the customer a creator/user. Use kit/VERSION and do not label the shipped product a test. State actual outcomes, not hypothetical readiness or zero-failure guarantees. The managed supervisor must be available and the customer's account connected before automatic editing is ready. Native chat can answer questions, but an idle native conversation is not the runtime.

## Renderer permission readiness
Installed binaries alone do not establish renderer readiness. The managed engine now runs its renderer probe inside the actual project sandbox before starting a turn. Explain and resolve any required permission before heavy editing. A user-approved session grant applies to that project session only; never call it permanent or installation-wide. Keep ordinary host permissions and explicit consent intact. See persistent-editor.md.
