"""Durable app-owned editing jobs. One writer, exact briefs, real provider events.

Studio owns the editing session, so ending its host conversation does not end an
edit. This is deliberately not a mirror of the host chat. No inferred progress,
unattended permission acceptance, hidden API token handling or generic fallback.
"""
from __future__ import annotations
import os,re,sys,time,json,shutil,threading,subprocess,queue,secrets,signal
from pathlib import Path
from . import util

TERMINAL={'succeeded','failed','cancelled','needs_attention','needs_setup'}
ACTIVE={'queued','starting','editing','waiting_approval','recovering'}
START_LOCK=threading.Lock()
WAKE_LOCK=threading.Lock()
_wake_running=False

_provider_pool=None

class ProviderPool:
    """Supervisor-owned, bounded live connections; never stored grants or auto-approval."""
    def __init__(self,capacity=2,idle_seconds=1800):
        self.capacity=capacity;self.idle_seconds=idle_seconds;self.entries={};self.lock=threading.Lock()
    @staticmethod
    def live(rpc):return rpc.process.poll() is None and not rpc.closed.is_set()
    def acquire(self,pid,factory):
        close=[]
        with self.lock:
            entry=self.entries.get(pid)
            if entry and entry['busy']:raise util.LockBusy('This video already owns a live editing connection.')
            if entry and self.live(entry['rpc']):
                entry.update(busy=True,touched=time.monotonic());return entry['rpc'],True
            if entry:close.append(self.entries.pop(pid)['rpc'])
            while len(self.entries)>=self.capacity:
                idle=[(key,row) for key,row in self.entries.items() if not row['busy']]
                if not idle:raise util.LockBusy('The available editing connections are busy.')
                key,_=min(idle,key=lambda item:item[1]['touched']);close.append(self.entries.pop(key)['rpc'])
            # Closing old idle sessions first keeps the process limit bounded.
            for rpc in close:rpc.close()
            rpc=factory();self.entries[pid]={'rpc':rpc,'busy':True,'touched':time.monotonic()}
            return rpc,False
    def owns_idle(self,pid,process_id):
        with self.lock:
            row=self.entries.get(pid)
            return bool(row and not row['busy'] and row['rpc'].process.pid==process_id and self.live(row['rpc']))
    def release(self,pid,rpc,keep):
        close=False
        with self.lock:
            row=self.entries.get(pid)
            if not row or row['rpc'] is not rpc:return
            if keep and self.live(rpc):row.update(busy=False,touched=time.monotonic())
            else:self.entries.pop(pid);close=True
        if close:rpc.close()
    def reap(self):
        close=[]
        with self.lock:
            for pid,row in list(self.entries.items()):
                if not row['busy'] and (not self.live(row['rpc']) or time.monotonic()-row['touched']>self.idle_seconds):
                    close.append(self.entries.pop(pid)['rpc'])
        for rpc in close:rpc.close()
    def close(self):
        with self.lock:connections=[r['rpc'] for r in self.entries.values()];self.entries.clear()
        for rpc in connections:rpc.close()

def wake_worker():
    """Start supervision off the HTTP thread; the watchdog also retries it.

    Saving a job must not wait for process inspection, another startup lock or
    provider initialization. Coalesce concurrent clicks into one wake attempt.
    """
    global _wake_running
    with WAKE_LOCK:
        if _wake_running:return
        _wake_running=True
    def wake():
        global _wake_running
        try:ensure_worker()
        except Exception:util.log_exception('editor start will be retried by supervisor watchdog')
        finally:
            with WAKE_LOCK:_wake_running=False
    try:threading.Thread(target=wake,daemon=True,name='editor-wake').start()
    except Exception:
        with WAKE_LOCK:_wake_running=False
        util.log_exception('editor wake thread will be retried by supervisor watchdog')

def root():return util.STUDIO_OUT/'editor'
def control():return util.ROOT/'.creatorcut-editor-control'
def provider_record(pid):
    job_path(pid)
    return safe_json(control()/'providers'/f'{pid}.json')
def job_path(pid):
    from . import videos
    return videos._dir(pid)/'editor-job.json'
def config():return safe_json(root()/'config.json') or {'enabled':True,'provider':'codex'}
def binary():
    paths=[shutil.which('codex'),Path.home()/'.local/bin/codex',Path.home()/'.npm-global/bin/codex']
    if sys.platform=='darwin':paths.append(Path('/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex'))
    return next((str(Path(p).resolve()) for p in paths if p and Path(p).is_file()),None)
def alive(pid):
    return util.process_alive(pid)

def safe_json(path):
    try:
        value=util.read_json(path,default={})
        return value if isinstance(value,dict) else {}
    except (util.Fail,OSError,ValueError):
        return {}

def identity(pid):
    return util.process_identity(pid) if alive(pid) else ''

def same_process(pid,birth):
    return alive(pid) and bool(birth) and identity(pid)==birth

def valid_job(value,pid):
    import math
    return (isinstance(value,dict) and value.get('project')==pid and isinstance(value.get('state'),str)
        and value['state'] in ACTIVE|TERMINAL and type(value.get('created')) in (int,float) and math.isfinite(value['created'])
        and type(value.get('attempts')) is int and value['attempts']>=0
        and type(value.get('state_seq',0)) is int and 0<=value.get('state_seq',0)<9007199254740991
        and isinstance(value.get('id'),str) and isinstance(value.get('request_id'),str)
        and type(value.get('retry_after',0)) in (int,float) and math.isfinite(value.get('retry_after',0)))

def all_projects():
    return sorted({f.parent.name for f in util.PROJECTS.glob('*/editor-job.json')}|
                  {f.stem for f in (control()/'jobs').glob('*.json')})

def read(pid):
    path=job_path(pid);backup=control()/'jobs'/f'{pid}.json'
    if not path.exists() and not backup.exists():return {}
    copies=[value for f in (path,backup) if valid_job(value:=safe_json(f),pid)]
    if copies:return max(copies,key=lambda value:value.get('state_seq',0))
    raise util.Fail('The saved editing job needs recovery. Your original files and video versions are preserved.')

def store_job(pid,data):
    if not valid_job(data,pid):raise util.Fail('The editor cannot save an invalid job state.')
    previous=safe_json(control()/'jobs'/f'{pid}.json')
    previous_seq=previous.get('state_seq',0) if valid_job(previous,pid) else 0
    data['state_seq']=max(data.get('state_seq',0),previous_seq)+1
    util.write_durable_json(job_path(pid),data)
    util.write_durable_json(control()/'jobs'/f'{pid}.json',data)

def patch(pid,**fields):
    job_path(pid) # Validate before creating a lock path.
    with util.file_guard(util.PROJECTS/pid/'.editor-job.guard',timeout=5):
        d=read(pid);d.update(fields,updated=time.time());store_job(pid,d)
    return d

def protect_inputs(fn):
    """Keep captured media and references stable until the current edit finishes."""
    import functools
    @functools.wraps(fn)
    def wrapped(pid,*args,**kwargs):
        import contextlib
        from . import videos
        if not pid:return fn(pid,*args,**kwargs)
        p=videos._dir(pid)
        with util.file_guard(p/'.request.guard',timeout=5), util.file_guard(p/'.editor-job.guard',timeout=5):
            if read(pid).get('state') in ACTIVE:
                raise util.Fail('This video is being edited. Your current files are protected; add these changes after the edit finishes.')
            return fn(pid,*args,**kwargs)
    return wrapped

def public(pid):
    try:d=read(pid)
    except util.Fail:return {'state':'needs_attention','message':'The saved editing job needs recovery. Your original files are safe.'}
    if not d:return {}
    keys=('id','state_seq','state','message','created','updated','activity_at','attempts','version','answer','approval','request_id','approval_outcome')
    result={k:d[k] for k in keys if k in d}
    if d.get('state') in {'failed','needs_attention'}:
        result['message']='Your edit is paused. Your footage and completed steps are saved.'
        result.pop('answer',None) # Provider diagnostics stay in the local job/log, not the beginner UI.
    if d.get('state') in ACTIVE:
        worker=safe_json(control()/'worker.json') or safe_json(root()/'worker.json')
        if not same_process(worker.get('pid'),worker.get('birth')) or supervisor_age(worker)>15:
            result.update(state='recovering',message='Reconnecting your editor. Your files and instructions are saved.')
    return result

def verify_account():
    """Check the actual signed-in account; don't trust a stale connected badge."""
    from .editor_rpc import RPC
    cli=binary()
    if not cli:raise util.Fail('Sign in to Codex to finish setup.')
    rpc=None
    try:
        rpc=RPC([cli,'app-server','--listen','stdio://'],util.ROOT)
        rpc.request('initialize',{'clientInfo':{'name':'creatorcut-setup','version':(util.KIT/'VERSION').read_text().strip()}},timeout=10)
        rpc.notify('initialized')
        account=rpc.request('account/read',{'refreshToken':False},timeout=10)
        if not account.get('account'):raise util.Fail('Sign in to Codex to finish setup.')
        util.write_json(root()/'account.json',{'state':'connected','updated':time.time()})
    except Exception:
        util.write_json(root()/'account.json',{'state':'disconnected','updated':time.time()})
        raise
    finally:
        if rpc:rpc.close()


def status():
    return {'enabled':config().get('enabled',True),'available':bool(binary()),'provider':'codex','mode':'persistent_editor','setup':'Sign in to Codex with your own account. Your plan and usage limits apply.','account':safe_json(root()/'account.json')}

def enqueue(pid,rid):
    from . import videos,requests
    if not config().get('enabled',True):raise util.Fail('Your editor is paused. Enable the editor before starting a video.')
    videos.load(pid);p=util.PROJECTS/pid;request=requests.active(p)
    if not request or request['id']!=rid:raise util.Fail('Save the current video settings before starting this edit.')
    with util.file_guard(p/'.request.guard',timeout=5),util.file_guard(p/'.editor-job.guard',timeout=5):
        request=requests.active(p)
        if not request or request['id']!=rid:raise util.Fail('Save the current video settings before starting this edit.')
        old=read(pid)
        if old.get('request_id')==rid:
            if old.get('state') in TERMINAL-{'succeeded'}:
                old.update(state='queued',message='Resuming your saved edit',updated=time.time(),cancel=False,approval=None,approval_outcome=None,retry_after=0,retry_attempt_base=old.get('attempts',0))
                store_job(pid,old)
            result=old
        elif old.get('state') in ACTIVE:
            raise util.Fail('This video is already being edited. Your new settings are saved; apply them after this pass.')
        else:
            now=time.time();result={'schema':1,'id':secrets.token_hex(16),'project':pid,'request_id':rid,'state':'queued','message':'Starting your editor','created':now,'updated':now,'activity_at':now,'attempts':0,'previous_version':max((v['n'] for v in videos.versions(pid)),default=0)}
            store_job(pid,result)
    wake_worker()
    return {'accepted':True,'state':result['state'],'request_id':rid,'job':result['id'],'project':pid,'transport':'persistent_editor'}

def supervisor_age(record):
    """Independent thread heartbeat cannot hide a stalled scheduling loop.

    Monotonic timestamps are shared by processes on this machine and survive
    wall-clock corrections. Older supervisor records keep their legacy fallback.
    """
    import math
    def age(value,now):
        return max(0,now-value) if type(value) in (int,float) and math.isfinite(value) else float('inf')
    now=time.monotonic()
    elapsed=age(record['heartbeat_monotonic'],now) if 'heartbeat_monotonic' in record else age(record.get('heartbeat'),time.time())
    if 'scheduler_heartbeat' in record:elapsed=max(elapsed,age(record['scheduler_heartbeat'],now))
    return elapsed


def ensure_worker():
    if not config().get('enabled',True):return
    root().mkdir(parents=True,exist_ok=True)
    with START_LOCK,util.file_guard(root()/'.start.guard',timeout=5):
        old=safe_json(control()/'worker.json')
        current_version=(util.KIT/'VERSION').read_text().strip()
        owned=same_process(old.get('pid'),old.get('birth'))
        age=supervisor_age(old)
        if owned and age>45:
            # A stale supervisor must recover even when an update is pending
            # and its saved jobs are still marked active.
            os.kill(old['pid'],signal.SIGTERM)
            return
        if owned and old.get('version') and old['version']!=current_version:
            if not pending_jobs():
                os.kill(old['pid'],signal.SIGTERM)
            return
        if owned and age<15:return
        if owned:
            # Only an identity-verified supervisor created by this app is stopped.
            # This never targets a render or a different installation's process.
            return
        try:
            with util.file_guard(root()/'.worker.guard',timeout=0):pass
        except util.LockBusy:return
        log=(root()/'worker.log').open('ab')
        try:
            p=subprocess.Popen([sys.executable,str(util.KIT/'tools/editor_worker.py')],cwd=util.ROOT,stdout=log,stderr=log,stdin=subprocess.DEVNULL,start_new_session=True,close_fds=True)
            record={'pid':p.pid,'birth':identity(p.pid),'heartbeat':time.time(),'heartbeat_monotonic':time.monotonic(),'starting':True}
            util.write_json(control()/'worker.json',record);util.write_json(root()/'worker.json',record)
        finally:log.close()

def retry(pid):
    job_path(pid)
    from . import requests
    with util.file_guard(util.PROJECTS/pid/'.editor-job.guard',timeout=5):
        d=read(pid)
        if d.get('state') not in TERMINAL-{'succeeded'}:return {'ok':True,'state':d.get('state')}
        if requests.active(util.PROJECTS/pid).get('id')!=d.get('request_id'):raise util.Fail('Your settings changed. Start the edit with your current instructions instead.')
        d.update(state='queued',message='Resuming your saved edit',updated=time.time(),approval=None,approval_outcome=None,cancel=False,retry_after=0,retry_attempt_base=d.get('attempts',0));store_job(pid,d)
    wake_worker();return {'ok':True}

def cancel(pid):
    p=job_path(pid).parent
    with util.file_guard(p/'.editor-job.guard',timeout=5):
        d=read(pid)
        if not d:return {'ok':True}
        if d.get('state') in TERMINAL:return {'ok':True,'state':d['state']}
        d.update(cancel=True,updated=time.time(),message='Stopping safely. Your originals and saved versions are kept.')
        if d.get('state')=='queued':d.update(state='cancelled',message='Edit stopped. Your originals and saved versions are kept.')
        store_job(pid,d)
    return {'ok':True,'state':d['state']}

def session_approval_supported(kind,params):
    # The installed App Server response schema includes acceptForSession.
    # It does not send availableDecisions. Respect a restricted list if a future host provides one.
    offered=params.get('availableDecisions')
    if kind=='permissions':return True # Documented permission grants support explicit scope=session.
    return kind=='command' and params.get('kind','command')=='command' and (offered is None or 'acceptForSession' in offered)

def answer(pid,job_id,approval_id,decision='',text=''):
    job_path(pid)
    with util.file_guard(util.PROJECTS/pid/'.editor-job.guard',timeout=5):
        d=read(pid);a=d.get('approval') or {}
        if d.get('id')!=job_id or d.get('state')!='waiting_approval' or a.get('id')!=approval_id:raise util.Fail('That question has already been handled. The editor will refresh.')
        if decision=='acceptForSession' and not a.get('session_allowed'):raise util.Fail('This permission supports a one-time decision only.')
        if decision not in ('accept','acceptForSession','decline') and a.get('kind')!='question':raise util.Fail('Choose Allow once or Decline.')
        d['approval_answer']={'id':approval_id,'decision':decision,'text':str(text).strip()[:10000]};store_job(pid,d)
    return {'ok':True}

def prompt(job):
    p=util.PROJECTS/job['project'];py=shlex_quote(sys.executable);entry=shlex_quote(str(util.ROOT/'edit.py'))
    return (f'You are CreatorCut OS\'s app-owned video editor. This is a dedicated persistent project session, not the host chat. '
      f'Work only on project {p.name}, request {job["request_id"]}. Read {p}/edit-requests/{job["request_id"]}.json in FULL. '
      f'Read {util.KIT}/docs/persistent-editor.md and the root AGENTS.md, then the edit skill and requested reference/effect instructions. '
      f'Use {py} {entry} for all editing commands. Your stable workflow owner is editor-{job["id"]}. '
      'Claim the actual project immediately, then prepare/transcribe while reference analysis runs. Plan actual source-specific scenes, use the exact selected executable effects and actual full reference evidence, preserve voice and originals, review full-resolution frames and audio signals truthfully, and publish the exact reviewed candidate. '
      'Current instructions beat selected features, reference, preset and private memory. Read saved creator/preset memory and log each requested correction. '
      'Never modify app engine/source, never bypass a release gate, never mark a note ready before a reviewed new version, and never substitute a generic edit or a copied original for a requested composition. '
      'An already-published matching request must not render again. On interrupted work inspect existing outputs and continue safely. '
      'Do not call another model or spawn subagents. Do not wait for a native conversation tool. Do not write replies into native chat. '
      'Do not ask the customer to copy a request or switch chats. If essential input/permission is missing, use the supported user input/approval mechanism. '
      'Only announce success after the exact requested, reviewed movie is published. If blocked, give one specific short explanation of the unmet requirement. '
      f'This job started with version {job.get("previous_version",0)}; a revised published version must be newer. '
      'Your final response should briefly describe the actual edit and any visual/audio review limitations.')

def shlex_quote(s):
    import shlex
    return shlex.quote(s)

def published(job):
    from . import videos,workflow,requests
    p=util.PROJECTS/job['project']
    if requests.active(p).get('id')!=job['request_id']:return None
    try:c=workflow.require_release(p)
    except (util.Fail,OSError,ValueError):return None
    for v in reversed(videos.versions(p.name)):
        if v['n']>job.get('previous_version',0) and v.get('candidate_sha256')==c['sha256']:
            movie=util.ROOT/v['file']
            if movie.is_file() and workflow.digest(movie)==c['sha256']:return v
    return None

class ProgressWatch:
    """Detect silence, not video duration. Only real editor events renew it."""
    def __init__(self,quiet_seconds=1200):
        self.quiet_seconds=quiet_seconds;self.last_progress=time.monotonic()
    def touch(self):self.last_progress=time.monotonic()
    def expired(self):return time.monotonic()-self.last_progress>self.quiet_seconds

class CodexEditor:
    def __init__(self,job):self.job=job;self.rpc=None
    def check_renderer_environment(self,p,allowed):
        record={'prerequisites_passed':False,'full_render_verified':False,'state':'unverified'}
        try:
            result=self.rpc.request('command/exec',{'command':[sys.executable,str(util.KIT/'tools/renderer_probe.py'),'--project',str(p)],'cwd':str(p),'sandboxPolicy':{'type':'workspaceWrite','writableRoots':[str(x.resolve()) for x in allowed],'networkAccess':False},'timeoutMs':30000},timeout=40)
            if result.get('exitCode')==0:
                data=json.loads(result.get('stdout') or '{}')
                if isinstance(data,dict) and isinstance(data.get('checks'),dict):
                    record={k:data[k] for k in ('prerequisites_passed','checks','requirements','full_render_verified','permission_granted_by_probe','requested_permissions') if k in data}
                    record['state']='checked'
        except (util.Fail,ValueError,OSError):
            # An unsupported diagnostic must not discard or duplicate the edit.
            record['requirements']=['The sandbox check was unavailable. Verify renderer permissions before heavy editing.']
        util.write_json(p/'renderer-capabilities.json',dict(record,checked=time.time()))
        return record
    def finish_published(self,pid,tid,turnid,version):
        """A verified publication is completion; model chatter cannot hold it open.

        Confirm interruption before retaining a connection. Otherwise close our
        owned transport so a new revision cannot share an unconfirmed writer.
        """
        stopped=False
        try:
            self.rpc.request('turn/interrupt',{'threadId':tid,'turnId':turnid},timeout=5)
            until=time.monotonic()+5
            while time.monotonic()<until:
                try:event=self.rpc.events.get(timeout=min(1,max(.01,until-time.monotonic())))
                except queue.Empty:continue
                params=event.get('params') or {};turn=params.get('turn') or {}
                if event.get('method')=='turn/completed' and params.get('threadId')==tid and turn.get('id')==turnid:
                    stopped=True;break
        except (util.Fail,OSError):pass
        if not stopped:self.rpc.close()
        patch(pid,state='succeeded',message='Your video is ready',version=version['n'],approval=None,activity_at=time.time())

    def run(self):
        from .editor_rpc import RPC
        pid=self.job['project'];job_path(pid);p=util.PROJECTS/pid;bin_=binary()
        if not bin_:raise util.Fail('Install Codex and sign in before editing. Your footage and instructions are saved.')
        if read(pid).get('cancel'):
            patch(pid,state='cancelled',message='Edit stopped safely.');return
        factory=lambda:RPC([bin_,'--enable','request_permissions_tool','app-server','--listen','stdio://'],util.ROOT)
        self.rpc,reused=_provider_pool.acquire(pid,factory) if _provider_pool else (factory(),False)
        util.write_json(control()/'providers'/f'{pid}.json',{'pid':self.rpc.process.pid,'birth':identity(self.rpc.process.pid),'worker_pid':os.getpid(),'worker_birth':identity(os.getpid())})
        patch(pid,provider_birth=identity(self.rpc.process.pid),provider_pid=self.rpc.process.pid,state='starting',message='Connecting your editor',activity_at=time.time())
        try:
            if not reused:
                self.rpc.request('initialize',{'clientInfo':{'name':'creatorcut','title':'CreatorCut OS','version':(util.KIT/'VERSION').read_text().strip()},'capabilities':{'experimentalApi':True}})
                self.rpc.notify('initialized')
            account=self.rpc.request('account/read',{'refreshToken':False})
            util.write_json(root()/'account.json',{'state':'connected' if account.get('account') else 'disconnected','updated':time.time()})
            if not account.get('account'):raise util.Fail('Sign in to Codex to connect your editor. Your saved request is ready to resume.')
            session_file=p/'editor-session.json';owned_session=control()/'sessions'/f'{pid}.json'
            session=safe_json(owned_session)
            if not session:
                candidate=safe_json(session_file)
                # Copied/imported project metadata cannot adopt a different
                # video's conversation, even when both jobs start together.
                session=candidate if candidate.get('project')==pid and candidate.get('workspace')==str(util.ROOT.resolve()) else {}
            # A copied Studio project must never resume another video's AI thread.
            taken={d.get('thread_id') for f in (control()/'sessions').glob('*.json') if f.stem!=pid for d in [safe_json(f)]}
            if session.get('thread_id') in taken:session={}
            instructions=(util.KIT/'docs/persistent-editor.md').read_text()
            params={'cwd':str(p),'approvalPolicy':'on-request','sandbox':'workspace-write','developerInstructions':instructions}
            if session.get('thread_id'):
                try:result=self.rpc.request('thread/resume',dict(params,threadId=session['thread_id'],excludeTurns=True),timeout=60)
                except util.Fail as e:
                    if 'archived' in str(e).lower():
                        self.rpc.request('thread/unarchive',{'threadId':session['thread_id']},timeout=30)
                        result=self.rpc.request('thread/resume',dict(params,threadId=session['thread_id'],excludeTurns=True),timeout=60)
                    elif any(x in str(e).lower() for x in ('not found','no rollout','does not exist')):
                        # Project-owned transcript is gone; rebuild from the durable
                        # request, approved plans and exact version-bound notes.
                        result=self.rpc.request('thread/start',params,timeout=60)
                    elif 'already has an active writer' in str(e).lower():
                        # An idle thread can remain loaded by another host. Do not
                        # kill that host or start a second writer on its thread.
                        # Branch only after stored history confirms every turn ended;
                        # run_job also holds our project writer guard and resource checks.
                        stored=self.rpc.request('thread/read',{'threadId':session['thread_id'],'includeTurns':True},timeout=30)['thread']
                        turns=stored.get('turns') or []
                        ended={'completed','interrupted','failed'}
                        if stored.get('status',{}).get('type')=='active' or not turns or any(t.get('status') not in ended for t in turns):
                            raise util.Fail('The previous editor is still finishing. Reconnecting safely.')
                        result=self.rpc.request('thread/fork',dict(params,threadId=session['thread_id'],lastTurnId=turns[-1]['id'],excludeTurns=True),timeout=60)
                        patch(pid,recovered_from_thread=session['thread_id'],message='Reconnecting your saved edit',answer='')
                    else:raise
            else:result=self.rpc.request('thread/start',params,timeout=60)
            tid=result['thread']['id'];session={'provider':'codex','thread_id':tid,'project':pid,'workspace':str(util.ROOT.resolve())}
            util.write_durable_json(owned_session,session);util.write_durable_json(session_file,session)
            patch(pid,thread_id=tid)
            allowed=[p,util.BRAND,util.ROOT/'my-videos',util.STUDIO_OUT,util.KIT/'fonts']
            if read(pid).get('cancel'):
                patch(pid,state='cancelled',message='Edit stopped safely.');return
            # command/exec is a standalone sandbox, not the resumed thread.
            # Its baseline restrictions cannot revoke or describe the approved
            # live thread's access. Revisions verify inside that actual thread.
            readiness=({'state':'verify_in_session','prerequisites_passed':False,'requested_permissions':{},'full_render_verified':False} if reused else self.check_renderer_environment(p,allowed))
            setup_note='\nRenderer sandbox check: '+json.dumps(readiness)+'. If state is verify_in_session, your FIRST action is to run the exact renderer_probe.py --project command within THIS resumed session, inspect its real result, and request only permissions it actually lacks. The live session may already hold approved access; do not request a new grant from a standalone sandbox baseline. If prerequisites_passed is false and requested_permissions is nonempty, your FIRST action must be the built-in request_permissions tool requesting ALL and ONLY the reported network and/or file_system scopes in ONE request. Explain that the local browser renderer needs loopback networking and reference matching needs its generated cache folder. If an older diagnostic omitted requested_permissions and local_browser_server is false, request network.enabled=true. This grant is network access, not a loopback-only allowlist; state that scope honestly. CreatorCut will show the user the real permission request, including the session option. Do not merely describe a blocker and end the turn. After a grant, run renderer_probe.py again in this SAME session and continue normal preparation, render, review and publication only when it passes. If request_permissions is unavailable, use the supported exec_command escalation request for the exact renderer command; never change security settings or route around a denial. If browser_launch is false after the requested network/cache grant, request the supported exec_command approval for this exact renderer_probe.py --project command to check native browser startup. Do not mark the renderer ready from the socket test alone, and do not start heavy editing until the browser check passes. Approval of a probe does not authorize unrelated render commands. A declined grant stops the edit safely. Do not treat this diagnostic as a finished render.'
            capacity_retries=0
            capacity_models=None
            current_model=result.get('model')
            def start_turn(text,capacity_error=None):
                nonlocal capacity_retries,capacity_models,current_model
                while True:
                    if read(pid).get('cancel'):
                        raise util.Fail('Edit stopped safely.')
                    if capacity_error:
                        if read(pid).get('approval_outcome') in ('declined','expired') or capacity_retries>=2:
                            raise util.Fail(capacity_error)
                        if capacity_models is None:
                            try:
                                catalog=self.rpc.request('model/list',{'limit':100},timeout=15).get('data',[])
                                if current_model is None:current_model=next((x.get('model') or x.get('id') for x in catalog if isinstance(x,dict) and x.get('isDefault')),None)
                                available={x.get('model') or x.get('id') for x in catalog if isinstance(x,dict) and not x.get('hidden')}
                                capacity_models=[x for x in ('gpt-6.1-sol','gpt-6-astra','gpt-6-sol','gpt-5.6-sol') if x in available and x!=current_model]
                            except (util.Fail,AttributeError,TypeError):capacity_models=[]
                        capacity_retries+=1
                        if capacity_models:current_model=capacity_models.pop(0)
                        patch(pid,state='recovering',message='The AI service is busy. Reconnecting your saved edit.',capacity_retries=capacity_retries,editor_model=current_model)
                        # Keep this same RPC/thread: an approved session grant,
                        # immutable request and completed assets remain attached.
                        time.sleep(min(4,capacity_retries*2))
                    params_={'threadId':tid,'input':[{'type':'text','text':text}],'sandboxPolicy':{'type':'workspaceWrite','writableRoots':[str(x.resolve()) for x in allowed],'networkAccess':False}}
                    if current_model:params_['model']=current_model
                    try:return self.rpc.request('turn/start',params_,timeout=60)
                    except util.Fail as exc:
                        if 'at capacity' not in str(exc).lower():raise
                        capacity_error=str(exc)
            turn=start_turn(prompt(self.job)+setup_note)
            turnid=turn['turn']['id'];patch(pid,state='editing',turn_id=turnid,message='Reading your footage and editing instructions',activity_at=time.time())
            final='';watch=ProgressWatch();activity_updated=None;completion_repairs=0
            version_index=p/'versions/versions.json'
            def version_stamp():
                try:
                    st=version_index.stat();return (st.st_mtime_ns,st.st_size)
                except FileNotFoundError:return None
            known_version_stamp=version_stamp()
            def note_activity():
                nonlocal activity_updated
                now=time.monotonic();watch.touch()
                # Streaming tokens/frame logs can arrive hundreds of times a
                # second. Persist liveness once per second, not once per byte.
                if activity_updated is None or now-activity_updated>=1:
                    patch(pid,activity_at=time.time());activity_updated=now
            while True:
                current=read(pid)
                if current.get('cancel'):
                    self.rpc.request('turn/interrupt',{'threadId':tid,'turnId':turnid},timeout=10)
                    patch(pid,state='cancelled',message='Edit stopped. Your originals and saved versions are kept.',approval=None);return
                stamp=version_stamp()
                if stamp!=known_version_stamp:
                    known_version_stamp=stamp
                    ready=published(current)
                    if ready:
                        self.finish_published(pid,tid,turnid,ready);return
                if watch.expired():
                    raise util.Fail('The editor connection stopped reporting activity. Your saved edit can be resumed safely.')
                try:event=self.rpc.events.get(timeout=1)
                except queue.Empty:continue
                method=event.get('method','');params_=event.get('params') or {}
                if method=='creatorcut/process_closed':raise util.Fail('The editor connection closed before completion. Your files are saved; resume this edit.')
                if params_.get('threadId') not in (None,tid):continue
                if params_.get('turnId') not in (None,turnid):continue
                if 'id' in event:self._approval(event);watch.touch();continue
                if method=='item/agentMessage/delta':
                    final=(final+str(params_.get('delta','')))[-12000:]
                    note_activity()
                elif method=='item/started':
                    watch.touch()
                    item=params_.get('item') or {};typ=item.get('type','')
                    labels={'commandExecution':'Working on your video','fileChange':'Building your edit','mcpToolCall':'Checking video assets','reasoning':'Planning your edit','agentMessage':'Your editor is working'}
                    patch(pid,activity_at=time.time(),message=labels.get(typ,'Working on your edit'))
                elif method=='item/completed':
                    watch.touch()
                    item=params_.get('item') or {}
                    if item.get('type')=='agentMessage':final=str(item.get('text') or final)[-12000:]
                    patch(pid,activity_at=time.time())
                elif method in ('item/commandExecution/outputDelta','item/fileChange/outputDelta','item/mcpToolCall/progress'):
                    # Real tool output can continue for a long render without a
                    # new item boundary. Count it as activity, never as percent.
                    note_activity()
                elif method=='turn/completed':
                    t=params_.get('turn') or {}
                    if t.get('id')!=turnid:continue
                    if t.get('status')!='completed':
                        error_message=str((t.get('error') or {}).get('message') or 'This editing pass stopped. Your progress is saved.')
                        if 'at capacity' in error_message.lower():
                            continuation=start_turn('Continue the same immutable video request from its saved artifacts. The previous model stopped because of service capacity. Preserve the exact brief, references, styles, completed work and review/publication gates. Do not duplicate the project or any already-published output.',capacity_error=error_message)
                            turnid=continuation['turn']['id'];final=''
                            patch(pid,state='editing',turn_id=turnid,activity_at=time.time(),message='Continuing your saved edit')
                            continue
                        raise util.Fail(error_message)
                    v=published(read(pid))
                    if not v:
                        outcome=read(pid).get('approval_outcome')
                        # A normal model turn can end after diagnosis/preparation.
                        # Continue this same saved request, not a duplicate job, at
                        # most twice. Never retry a declined/expired permission.
                        if outcome not in ('expired','declined') and not read(pid).get('cancel') and completion_repairs<2:
                            completion_repairs+=1
                            patch(pid,state='recovering',message='Checking the unfinished step and continuing your saved edit',completion_repairs=completion_repairs)
                            continuation=self.rpc.request('turn/start',{'threadId':tid,'input':[{'type':'text','text':'The previous turn ended without a verified newly published video for this saved request. Continue this exact project and immutable request from its saved artifacts. Diagnose and fix the unfinished step, then complete normal render, review and publish. Do not create another project or duplicate already completed work. Never bypass permissions, repeat declined actions, substitute a generic edit, or claim completion without a verified published result. If a real prerequisite remains unavailable, explain it precisely and stop.'}],'sandboxPolicy':{'type':'workspaceWrite','writableRoots':[str(x.resolve()) for x in allowed],'networkAccess':False}},timeout=60)
                            turnid=continuation['turn']['id'];final=''
                            patch(pid,state='editing',turn_id=turnid,activity_at=time.time(),message='Continuing your saved edit')
                            continue
                        expired=outcome=='expired'
                        patch(pid,state='needs_attention',message='Your earlier permission or question expired. Resume this edit to continue.' if expired else 'Your editor needs one more step before a finished video is ready.',answer=final or 'No reviewed new version was published.',approval=None);return
                    patch(pid,state='succeeded',message='Your video is ready',version=v['n'],answer=final,approval=None,activity_at=time.time());return
        finally:
            if _provider_pool:
                keep=read(pid).get('state')=='succeeded'
                _provider_pool.release(pid,self.rpc,keep)
                if keep:
                    patch(pid,provider_pid=None,provider_birth=None)
                    util.write_json(control()/'providers'/f'{pid}.json',{'pid':self.rpc.process.pid,'birth':identity(self.rpc.process.pid),'worker_pid':os.getpid(),'worker_birth':identity(os.getpid()),'idle':True})
            else:self.rpc.close()
    def _approval(self,event):
        method=event['method'];params=event.get('params') or {};pid=self.job['project'];aid=secrets.token_hex(16)
        kinds={'item/commandExecution/requestApproval':'command','item/fileChange/requestApproval':'files','item/permissions/requestApproval':'permissions','item/tool/requestUserInput':'question'}
        if method not in kinds:
            self.rpc.reject(event['id'],'This input is not supported by CreatorCut. Stop and explain the precise next step.');return
        kind=kinds[method]
        public_={'id':aid,'kind':kind,'reason':str(params.get('reason') or 'Your editor needs your confirmation.'),'command':str(params.get('command') or ''),'cwd':str(params.get('cwd') or ''),'questions':params.get('questions',[]),'permissions':params.get('permissions') or {},'grantRoot':params.get('grantRoot') or '', 'session_allowed':session_approval_supported(kind,params)}
        patch(pid,state='waiting_approval',message='Your editor has a question' if kind=='question' else 'Your approval is needed',approval=public_,approval_answer=None,approval_outcome=None)
        answered=False
        deadline=time.monotonic()+600
        while time.monotonic()<deadline:
            d=read(pid);a=d.get('approval_answer') or {}
            if d.get('cancel'):a={'id':aid,'decision':'decline'}
            if a.get('id')==aid:answered=True;break
            time.sleep(.25)
        else:a={'decision':'decline'}
        accept=a.get('decision') in ('accept','acceptForSession')
        if kind=='permissions':result={'permissions':params.get('permissions',{}) if accept else {},'scope':'session' if accept and a.get('decision')=='acceptForSession' else 'turn'}
        elif kind=='question':result={'answers':{q['id']:{'answers':[a.get('text','No answer supplied. Stop and explain what is needed.')]} for q in params.get('questions',[])}}
        else:result={'decision':'acceptForSession' if a.get('decision')=='acceptForSession' and public_['session_allowed'] else 'accept' if accept else 'decline'}
        outcome='expired' if not answered else 'accepted' if a.get('decision') in ('accept','acceptForSession') else 'answered' if kind=='question' else 'declined'
        self.rpc.respond(event['id'],result);patch(pid,state='editing',message='The request expired; checking your saved edit.' if outcome=='expired' else 'Continuing your edit',approval=None,approval_answer=None,approval_outcome=outcome,activity_at=time.time())

def run_job(job,provider=CodexEditor):
    pid=job['project'];job_path(pid);p=util.PROJECTS/pid
    with util.file_guard(p/'.managed-editor.guard','Another session is editing this video.',timeout=1):
        job=read(pid)
        if job.get('state') not in ACTIVE:return
        if time.time()<job.get('retry_after',0):return
        if job.get('cancel'):patch(pid,state='cancelled',message='Edit stopped safely.');return
        v=published(job)
        if v:patch(pid,state='succeeded',version=v['n'],message='Your video is ready');return
        # Process signals use a supervisor-owned registry outside all editor
        # writable roots. Model-writable project metadata cannot target a PID.
        owned=provider_record(pid)
        pooled=bool(_provider_pool and owned.get('worker_pid')==os.getpid() and _provider_pool.owns_idle(pid,owned.get('pid')))
        if not pooled and same_process(owned.get('pid'),owned.get('birth')):
            if not same_process(owned.get('worker_pid'),owned.get('worker_birth')):
                try:os.kill(owned['pid'],signal.SIGTERM)
                except ProcessLookupError:pass
            patch(pid,state='recovering',message='Waiting for the previous editor to close safely.');return
        if not owned and same_process(job.get('provider_pid'),job.get('provider_birth')):
            patch(pid,state='recovering',message='Waiting for the previous editor to finish safely.');return
        from . import activity_store,workflow
        activity=activity_store.latest(pid)
        if activity.get('running') and alive(activity.get('pid')):
            patch(pid,state='recovering',message='Your video tools are still working. Waiting before resuming.');return
        owner='editor-'+job['id'];wf=util.read_json(p/'workflow.json',default={})
        if wf.get('lease_until',0)>time.time() and wf.get('owner') not in (owner,None,''):
            patch(pid,state='recovering',message='Your video is already being worked on. Continuing when that step finishes.',retry_after=time.time()+5);return
        with util.file_guard(p/'.editor-job.guard',timeout=5):
            current=read(pid)
            if current.get('state') not in ACTIVE or current.get('cancel'):return
            current.update(state='starting',message='Starting your editor',worker_pid=os.getpid(),worker_birth=identity(os.getpid()),provider_pid=None,attempts=current.get('attempts',0)+1,approval=None,updated=time.time())
            store_job(pid,current)
        try:provider(read(pid)).run()
        except Exception as e:
            util.log_exception('persistent editor '+pid)
            try:v=published(read(pid))
            except Exception:v=None
            if v:
                patch(pid,state='succeeded',version=v['n'],message='Your video is ready',approval=None)
                return
            message=str(e)[:600] if isinstance(e,util.Fail) else 'The editor stopped unexpectedly. Your completed steps and original files are saved. Resume this edit to continue.'
            setup='Sign in' in message or 'Install Codex' in message
            transient=any(x in message.lower() for x in ('connection closed','did not confirm','connection stopped','temporarily unavailable','connection reset','rate limit','previous editor is still finishing','already has an active writer'))
            saved=read(pid)
            retry=transient and not setup and saved.get('attempts',0)-saved.get('retry_attempt_base',0)<3
            patch(pid,state='recovering' if retry else 'needs_setup' if setup else 'failed',message='Reconnecting and resuming your saved edit.' if retry else message,approval=None,retry_after=time.time()+min(30,5*read(pid).get('attempts',1)) if retry else 0)
        finally:
            d=read(pid)
            if same_process(d.get('provider_pid'),d.get('provider_birth')):
                patch(pid,state='recovering',message='Closing the previous editor safely before resuming.',retry_after=time.time()+5)
            else:patch(pid,provider_pid=None,provider_birth=None)
            if d.get('state') in TERMINAL:
                # Only our own ended work lease can be cleared.
                wf=util.read_json(p/'workflow.json',default={})
                if wf.get('owner')==owner:
                    workflow.state(p,'ready' if d.get('state')=='succeeded' else 'blocked',d.get('message',''),lease_until=0)

def pending_jobs():
    jobs=[]
    for pid in all_projects():
        try:
            d=read(pid)
            if d.get('state') in ACTIVE:jobs.append(d)
        except (util.Fail,OSError,ValueError):continue
    return sorted(jobs,key=lambda x:x['created'])


def run_isolated(job,provider):
    try:run_job(job,provider)
    except util.LockBusy:
        try:patch(job['project'],state='recovering',retry_after=time.time()+2,message='Your current video step is finishing safely.')
        except Exception:util.log_exception('busy editor state')
    except Exception:
        util.log_exception('isolated editor job '+job['project'])
        try:patch(job['project'],state='needs_attention',message='This project needs recovery. Your original files and saved versions are safe.')
        except Exception:util.log_exception('save isolated editor failure')


def drain_once(provider=CodexEditor):
    """Synchronous single-drain entry point for diagnostics and tests."""
    for job in pending_jobs():run_isolated(job,provider)


class EditorScheduler:
    """Two project sessions can plan/chat independently; heavy tools remain serialized.

    A long permission wait in one project must not block a different project.
    Per-project kernel locks still prevent competing writers, even across hosts.
    """
    def __init__(self,capacity=2):
        self.capacity=capacity
        self.running={}

    def tick(self,provider=CodexEditor):
        self.running={pid:t for pid,t in self.running.items() if t.is_alive()}
        for job in pending_jobs():
            try:self.dispatch(job,provider)
            except Exception:util.log_exception('isolated scheduler dispatch '+str(job.get('project','unknown')))

    def dispatch(self,job,provider):
        pid=job['project']
        if pid in self.running or time.time()<job.get('retry_after',0):return
        if len(self.running)>=self.capacity:
            if job.get('state')=='queued' and job.get('message')!='Your video is saved and starts when an editor is available.':
                patch(pid,message='Your video is saved and starts when an editor is available.')
            return
        thread=threading.Thread(target=run_isolated,args=(job,provider),daemon=True,name='editor-'+pid)
        self.running[pid]=thread
        try:thread.start()
        except Exception:
            self.running.pop(pid,None)
            patch(pid,state='recovering',retry_after=time.time()+5,message='Reconnecting your saved editor')
            util.log_exception('project editor thread start')


def worker():
    global _provider_pool
    _provider_pool=ProviderPool()
    root().mkdir(parents=True,exist_ok=True)
    with util.file_guard(root()/'.worker.guard','An editor supervisor is already running.',timeout=1):
        # This process loaded these modules once. A heartbeat must not report a
        # newer on-disk version until a fresh supervisor actually loads it.
        loaded_version=(util.KIT/'VERSION').read_text().strip()
        stop=threading.Event()
        scheduler_health={'at':time.monotonic()}
        def beat():
            while not stop.is_set():
                try:
                    record={'pid':os.getpid(),'birth':identity(os.getpid()),'version':loaded_version,'heartbeat':time.time(),'heartbeat_monotonic':time.monotonic(),'scheduler_heartbeat':scheduler_health['at']}
                    util.write_json(control()/'worker.json',record);util.write_json(root()/'worker.json',record)
                except Exception:util.log_exception('editor heartbeat will retry')
                stop.wait(2)
        shutdown=threading.Event();previous_handlers={}
        if threading.current_thread() is threading.main_thread():
            for signum in (signal.SIGTERM,signal.SIGINT):
                previous_handlers[signum]=signal.signal(signum,lambda *_:shutdown.set())
        thread=threading.Thread(target=beat,daemon=True);thread.start()
        try:
            scheduler=EditorScheduler()
            while not shutdown.is_set():
                _provider_pool.reap();scheduler.tick()
                scheduler_health['at']=time.monotonic()
                shutdown.wait(.5)
        finally:
            stop.set();thread.join(timeout=3);_provider_pool.close();_provider_pool=None
            for signum,handler in previous_handlers.items():signal.signal(signum,handler)


def watchdog(stop=None):
    stop=stop or threading.Event()
    while not stop.is_set():
        try:ensure_worker()
        except Exception:util.log_exception('editor supervisor restart')
        stop.wait(5)


CONNECT_LOCK=threading.Lock()
def connect():
    if not binary():raise util.Fail('Install Codex first, then connect your editor in Studio.')
    current=safe_json(root()/'account.json')
    if current.get('state')=='connecting' and time.time()-current.get('updated',0)<600:return current
    def login():
        from .editor_rpc import RPC
        from urllib.parse import urlparse
        with CONNECT_LOCK:
            rpc=None
            try:
                util.write_json(root()/'account.json',{'state':'connecting','updated':time.time()})
                rpc=RPC([binary(),'app-server','--listen','stdio://'],util.ROOT)
                rpc.request('initialize',{'clientInfo':{'name':'creatorcut','version':(util.KIT/'VERSION').read_text().strip()}});rpc.notify('initialized')
                if not rpc.request('account/read',{'refreshToken':False}).get('account'):
                    result=rpc.request('account/login/start',{'type':'chatgpt'})
                    url=result.get('authUrl','');u=urlparse(url)
                    if u.scheme!='https' or u.hostname not in ('auth.openai.com','auth0.openai.com','chatgpt.com'):
                        raise util.Fail('Open Codex and sign in there, then reconnect your editor.')
                    util.write_json(root()/'account.json',{'state':'connecting','url':url,'updated':time.time()})
                    deadline=time.monotonic()+600
                    while time.monotonic()<deadline:
                        event=rpc.events.get(timeout=600)
                        if event.get('method')=='creatorcut/process_closed':raise util.Fail('Sign-in closed. Connect again to continue.')
                        if event.get('method')=='account/login/completed':
                            if not event.get('params',{}).get('success'):raise util.Fail('Sign-in was not completed. Connect again when ready.')
                            break
                    else:raise util.Fail('Sign-in timed out. Your video files are safe; connect again when ready.')
                util.write_json(root()/'account.json',{'state':'connected','updated':time.time()})
                for file in util.PROJECTS.glob('*/editor-job.json'):
                    try:
                        if read(file.parent.name).get('state')=='needs_setup':retry(file.parent.name)
                    except (util.Fail,OSError):util.log_exception('resume after sign-in')
            except Exception as e:
                util.write_json(root()/'account.json',{'state':'disconnected','message':str(e)[:300] if isinstance(e,util.Fail) else 'Sign-in did not finish. Open Codex, sign in, then reconnect.','updated':time.time()})
            finally:
                if rpc:rpc.close()
    threading.Thread(target=login,daemon=True).start()
    return {'state':'connecting'}
