#!/usr/bin/env python3
"""CreatorCut OS: engine entry point.

You never need to run this yourself: Claude (or ChatGPT Codex) runs it for you.
Usage:  python3 edit.py <command>      (Windows: python edit.py <command>)
"""
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.environ["HF_HUB_DISABLE_TELEMETRY"]="1"
os.environ["DO_NOT_TRACK"]="1"
os.environ["HF_HOME"] = str(ROOT / "kit/cache/huggingface")
os.environ["HF_HUB_CACHE"] = str(ROOT / "kit/cache/huggingface/hub")
os.environ["XDG_CACHE_HOME"] = str(ROOT / "kit/cache")

VENV_PY = ROOT / ".venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")

# Use the toolkit's private Python environment when it exists (created by `install`).
IN_VENV = Path(sys.prefix).resolve() == (ROOT / ".venv").resolve()
if VENV_PY.is_symlink() and not VENV_PY.exists():
    sys.exit("CreatorCut moved and needs its local tools reconnected. Run: sh kit/setup/launch.sh studio open --no-browser. Your files are safe.")
if VENV_PY.exists() and not IN_VENV and sys.argv[1:2] != ["install"]:
    args = [str(VENV_PY), str(Path(__file__).resolve())] + sys.argv[1:]
    if os.name == "nt":
        import subprocess
        sys.exit(subprocess.call(args))
    try:os.execv(str(VENV_PY), args)
    except OSError:sys.exit("CreatorCut could not start its local Python. Run: sh kit/setup/launch.sh studio open --no-browser. Your files are safe.")

if sys.version_info < (3, 9):
    sys.exit("CreatorCut OS needs its private Python. Ask your AI assistant to install CreatorCut OS (type: install).")

try:  # nicer output on Windows terminals
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

sys.path.insert(0, str(ROOT / "kit"))

if __name__ == "__main__":
    if sys.argv[1:2] and sys.argv[1] in {'_matte','_status-clock','next','wait','ingest','assemble','words','layout','init','reference','lint','snapshot','base','fx-check','fx-new','fx-run','fx-add','build','render','check','frames','probe','silence','music','publish','progress','ask','status','look'}:
        from editor.director import main
        sys.exit(main(sys.argv[1:]))
    if sys.argv[1:2] and sys.argv[1] in {'workflow','library','renderer-probe','timeline-feedback'}:
        sys.exit('Open your CreatorCut chat and type continue.')
    from editkit.cli import main
    main()
