"""The Studio server: a tiny local web app server (Python standard library only).

    edit.py studio serve [--port 4317]

- Binds to 127.0.0.1 only. Port: $PORT if set (Claude's preview passes it), else --port, else the next free one.
  The chosen port is written to kit/studio-out/server.json (and server.js for the static Studio.html).
- Security: a random token per start. Every /api/* call needs it (X-AIE-Token header; the page gets it from the
  HTML it is served). Media needs the token cookie (SameSite=Strict) or ?t=. Requests whose Host isn't
  127.0.0.1:<port> or localhost:<port> are refused (blocks DNS rebinding). No CORS headers at all.
- Media is served with HTTP Range support so <video> can seek, from an allow-list of folders only.
"""
from __future__ import annotations

import hashlib
import json
import mimetypes
import os
import re
import secrets
import shutil
import socket
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urlparse

from . import events, jobs, util, maintenance, state_feed

TOKEN = secrets.token_urlsafe(24)
PORT = {"n": 4317}
SERVER_JSON = util.STUDIO_OUT / "server.json"
SERVER_JS = util.STUDIO_OUT / "server.js"
PAGE = util.ROOT / "Studio.html"

# Public static files (app code, fonts, starter thumbnails, install progress). No private data.
STATIC_PREFIXES = ("kit/studio/app/", "kit/fonts/", "kit/studio/thumbs/", "kit/samples/")
STATIC_FILES = {"kit/studio-out/progress.js", "kit/studio-out/beat.js", "kit/studio-out/server.js",
                "kit/studio/starter-data.js", "kit/studio-out/data.js"}
# Private media (needs the token): the creator's videos, projects, brand files and Studio assets.
MEDIA_PREFIXES = ("my-videos/", "kit/projects/", "kit/studio-out/assets/", "my-brand/", "kit/studio/thumbs/",
                  "kit/fonts/", "kit/samples/")
MEDIA_EXT = util.VIDEO_EXT | util.IMAGE_EXT | util.AUDIO_EXT | {".otf", ".ttf", ".json", ".md", ".txt"}

UPLOAD = {  # kind → (folder, allowed extensions, max bytes)
    "raw": (util.RAW, util.VIDEO_EXT, 20 * 1024 ** 3),
    "reference": (util.REFERENCES, util.VIDEO_EXT | {".png", ".jpg", ".jpeg", ".webp"}, 2 * 1024 ** 3),
    "proof": (util.BRAND / "proof", {".png", ".jpg", ".jpeg", ".webp"}, 60 * 1024 ** 2),
    "music": (util.MUSIC, util.AUDIO_EXT, 400 * 1024 ** 2),
}

PROFILE_KEYS = {"about", "audience", "website", "memory", "name", "handle", "platform", "style", "favourites", "cta", "language", "vocabulary",
                "onboarding", "agent", "music", "accent", "whisper_model"}

# Settings the server applies itself (deterministic), then queues a preview re-render.
DIRECT_SETTINGS = {
    "framing_fit": ("framing.fit", str), "video_length": ("brief.length", str), "cta": ("cta", str), "platform": ("platform", str),
    "style": ("style", str), "grade": ("grade", str), "caption_size": ("captions.size", int),
    "caption_y": ("captions.y", float), "caption_mode": ("captions.mode", str), "captions_on": ("captions.enabled", bool),
    "uppercase": ("captions.uppercase", bool), "music": ("music", str), "music_volume": ("music_volume", float),
    "sfx_on": ("sfx", bool), "sfx_volume": ("overrides.sfx.volume", float), "zoom_on": ("zoom", bool),
    "progress_bar": ("progress_bar", bool), "voice_cleanup": ("voice_cleanup", bool),
}
RANGES = {"caption_size": (40, 140), "caption_y": (0.45, 0.8), "music_volume": (0.0, 0.5), "sfx_volume": (0.0, 0.6)}
CHOICES = {"framing_fit": {"cover","blur"}, "platform": {"tiktok","reels","shorts","youtube"},"caption_mode": {"highlight", "reveal", "pop", "plain"},
           "grade": {"custom", "none", "natural", "clean", "warm", "punchy", "cinematic", "moody", "soft", "luxe", "mono", "film"}}


class Handler(BaseHTTPRequestHandler):
    server_version = "AIEditorStudio/2"
    protocol_version = "HTTP/1.1"

    # ------------------------------------------------------------ plumbing ----
    def setup(self):
        super().setup()
        # Bound idle header/body/socket I/O; a stalled upload must release its thread.
        self.connection.settimeout(30)

    def handle(self):
        try:
            super().handle()
        except (ConnectionResetError, BrokenPipeError, TimeoutError):
            # A closed tab/restarted connection is normal, not a failed edit.
            self.close_connection = True

    def _content_length(self, limit: int, required: bool = False) -> int:
        raw = self.headers.get("Content-Length")
        if self.headers.get("Transfer-Encoding"):
            self.close_connection = True
            raise util.Fail("Streaming request encoding is not supported.", "Retry the request with a file size.")
        if raw is None and not required:
            return 0
        if raw is None or not str(raw).isdigit() or len(str(raw)) > 15:
            self.close_connection = True
            raise util.Fail("That request has an invalid size.", "Retry the request.")
        n = int(raw)
        if n > limit:
            self.close_connection = True
            raise util.Fail("That request is too big.")
        return n

    def log_message(self, fmt, *args):  # quiet console; details in server.log
        if os.environ.get("AIE_SERVER_VERBOSE"):
            util.log("http " + (fmt % args))

    def _host_ok(self) -> bool:
        host = (self.headers.get("Host") or "").lower()
        return host in (f"127.0.0.1:{PORT['n']}", f"localhost:{PORT['n']}",f"[::1]:{PORT['n']}")

    def _cookie_token(self) -> str:
        for part in (self.headers.get("Cookie") or "").split(";"):
            k, _, v = part.strip().partition("=")
            if k == f"aie_t_{PORT['n']}":
                return v
        return ""

    def _token_ok(self, query: dict) -> bool:
        given = self.headers.get("X-AIE-Token") or self._cookie_token() or (query.get("t") or [""])[0]
        return secrets.compare_digest(given.encode(), TOKEN.encode())

    def _send(self, code: int, body: bytes, ctype: str = "application/json; charset=utf-8", extra: dict | None = None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", (extra or {}).get("Cache-Control","no-store"))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        for k, v in (extra or {}).items():
            if k.lower()!="cache-control":self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def _json(self, data, code: int = 200):
        self._send(code, json.dumps(data, ensure_ascii=False).encode("utf-8"))

    def _error(self, code: int, message: str, fix: str = ""):
        self._json({"ok": False, "error": message, "fix": fix}, code)

    def _body_json(self) -> dict:
        n = self._content_length(2_000_000)
        try:
            raw = self.rfile.read(n) if n else b"{}"
        except (TimeoutError, OSError):
            self.close_connection = True
            raise util.Fail("The request stopped sending data.", "Your project is saved. Retry the request.")
        if n and len(raw) != n:
            self.close_connection = True
            raise util.Fail("The request ended before it finished.", "Retry the request.")
        try:
            data = json.loads(raw.decode("utf-8") or "{}")
        except ValueError:
            raise util.Fail("That request wasn't valid JSON.")
        if not isinstance(data, dict):
            raise util.Fail("That request wasn't a JSON object.")
        return data

    # -------------------------------------------------------------- routing ----
    def do_HEAD(self):
        self.do_GET()

    @maintenance.handler
    def do_GET(self):
        if not self._host_ok():
            return self._send(421, b"Wrong host", "text/plain")
        u = urlparse(self.path)
        q = parse_qs(u.query)
        path = unquote(u.path)
        try:
            if path in ("/", "/index.html", "/Studio.html"):
                return self._page()
            if path == "/api/ping":
                return self._json({"ok": True, "app": "the-ai-editor", "port": PORT["n"], "installation": installation_key()})
            if path.startswith("/api/"):
                if not self._token_ok(q):
                    return self._error(403, "Not allowed.")
                if path.startswith('/api/music/'):
                    from . import videos,music_library,music_provider
                    pid=(q.get('project') or [''])[0];videos.load(pid)
                    if path=='/api/music/state':return self._json(music_library.state(pid))
                    if path=='/api/music/seed':return self._json({'ok':True,'tracks':music_library.catalogue()})
                    if path=='/api/music/search':
                        try:page=int((q.get('page') or ['0'])[0])
                        except ValueError:raise util.Fail('Try that search again.')
                        return self._json(music_provider.search((q.get('q') or [''])[0],page))
                    if path=='/api/music/audio':return music_provider.Preview(self).audio((q.get('id') or [''])[0])
                    if path=='/api/music/selected-audio':
                        file=music_library.selected_file(pid)
                        return self._file(util.rel(file),MEDIA_PREFIXES,private=True)
                    return self._error(404,'Unknown music action.')
                if path == "/api/health":
                    from . import health
                    return self._json(health.snapshot())
                if path == "/api/state":
                    return self._json(state_feed.snapshot())
                if path == "/api/events/stream":
                    return self._sse(q)
                m = re.fullmatch(r"/api/jobs/([a-f0-9]{6,32})", path)
                if m:
                    j = jobs.get(m.group(1))
                    return self._json(j) if j else self._error(404, "No such job.")
                if path == "/api/events":
                    after = int((q.get("after") or ["0"])[0] or 0)
                    return self._json({"events": events.since(after)[-200:]})
                return self._error(404, "Unknown address.")
            if path.startswith("/media/"):
                if not self._token_ok(q):
                    return self._send(403, b"Not allowed", "text/plain")
                name=(q.get('filename') or [''])[0] if (q.get('download') or [''])[0]=='1' else ''
                return self._file(path[len("/media/"):], MEDIA_PREFIXES, private=True,download_name=name)
            rel = path.lstrip("/")
            if rel in STATIC_FILES or rel.startswith(STATIC_PREFIXES):
                return self._file(rel, STATIC_PREFIXES + tuple(STATIC_FILES), private=False)
            if path == "/favicon.ico":
                return self._send(204, b"", "image/x-icon")
            return self._send(404, b"Not found", "text/plain")
        except util.Fail as e:
            return self._error(400, e.message, e.fix)
        except (BrokenPipeError, ConnectionResetError):
            return
        except Exception:
            util.log_exception(f"GET {path}")
            return self._error(500, "Something went wrong in the Studio. Say 'check my studio' to your editor.")

    @maintenance.handler
    def do_POST(self):
        if not self._host_ok():
            return self._send(421, b"Wrong host", "text/plain")
        u = urlparse(self.path)
        q = parse_qs(u.query)
        path = unquote(u.path)
        if not self._token_ok(q) or self.headers.get("X-AIE-Token") is None:
            return self._error(403, "Not allowed.")
        try:
            if path == '/api/music/upload':return self._music_upload(q)
            if path=='/api/effect-material':
                from . import videos
                body=self._body_json();pid=str(body.get('project',''));effect=str(body.get('effect',''))
                if effect not in ('orbit','couch-wall','ui-world','phone-mockup','green-screen','inside-out'):raise util.Fail('Choose an effect that uses your files.')
                cfg=videos.load(pid);item=next((m for m in cfg.get('media',[]) if m.get('id')==body.get('id')),None)
                if not item:raise util.Fail('Please add your effect files again.')
                p=videos._dir(pid);folder=p/'work/effect-material'/effect;folder.mkdir(parents=True,exist_ok=True)
                src=(util.ROOT/item['file']).resolve()
                if not src.is_relative_to(p.resolve()) or not src.is_file():raise util.Fail('Please add your effect files again.')
                shutil.copy2(src,folder/src.name)
                videos.update(pid,lambda c:c.setdefault('effect_material',{}).update({effect:str(folder)}))
                return self._json({'ok':True})
            if path in ('/api/requests','/api/requests/cancel'):
                from editor import director
                body=self._body_json()
                try:
                    if path.endswith('/cancel'):result=director.cancel(str(body.get('project','')))
                    else:result=director.save_request(str(body.get('project','')),body.get('notes'),body.get('key'))
                except director.Needed as error:return self._json({'ok':False,'error':str(error)},409)
                return self._json(result)
            if path.startswith('/api/editor/') or path.startswith('/api/native/'):
                return self._json({'ok':False,'error':'Open your CreatorCut chat and type continue.'},410)
            if path == "/api/upload":
                return self._upload(q)
            body = self._body_json()
            if path.startswith('/api/music/'):
                from . import videos,music_library
                pid=str(body.get('project',''));videos.load(pid)
                if path=='/api/music/intent':return self._json(music_library.intent(pid,body.get('client'),body.get('sequence')))
                token=str(body.get('token',''))
                guard=lambda:music_library.intent_guard(pid,token)
                with guard():pass
                if path=='/api/music/select':
                    mode=body.get('mode')
                    if mode in ('none','auto'):result=music_library.save_mode(pid,mode,guard=guard)
                    elif mode=='library':result=music_library.select(pid,str(body.get('id','')),guard=guard)
                    else:raise util.Fail('Choose a music option from the menu.')
                    events.emit('music.saved',{'project':pid},source='studio')
                    return self._json(result)
                return self._error(404,'Unknown music action.')
            if path=='/api/readiness/check':
                from . import readiness
                return self._json(readiness.start())
            if path == "/api/profile":
                return self._json({"ok": True, "profile": api_profile(body)})
            if path == "/api/references/url":
                from . import refs
                ref = refs.add_url(str(body.get("url", "")))
                return self._json({"ok": True, "ref": ref, "job": ref.get("job")})
            if path == "/api/references/retry":
                from . import refs
                return self._json({"ok": True, "ref": refs.retry(str(body.get("id", "")))})
            if path == "/api/references/remove":
                from . import refs
                refs.remove(str(body.get("id", "")))
                return self._json({"ok": True})
            if path == "/api/styles/from-brief":
                from . import presets
                return self._json({"ok": True, "id": presets.from_brief(str(body.get("project", "")), str(body.get("name", "")))})
            if path == "/api/styles/from-video":        # "Save as preset" on a finished video
                from . import presets
                return self._json(presets.queue_save(str(body.get("project", "")), str(body.get("name", "")), str(body.get("update", "")), version=body.get("version")))
            if path == "/api/focus":                     # the video on the Studio screen
                pid = str(body.get("project", ""))[:80]
                util.write_json(util.STUDIO_OUT / "focus.json", {"project": pid, "time": time.time()})
                return self._json({"ok": True})
            if path == "/api/learned/forget":
                from . import learn
                learn.forget(int(body.get("index", -1)), str(body.get("preset") or "") or None)
                return self._json({"ok": True})
            if path == "/api/styles/rename":
                sid = util.slugify(str(body.get("id", "")))
                f = util.USER_STYLES_DIR / f"{sid}.json"
                if not f.exists():
                    raise util.Fail("That preset doesn't exist.")
                data = util.read_json(f)
                name = str(body.get("name", "")).strip()[:40]
                if not name:
                    raise util.Fail("Give the preset a name.")
                _unique_preset_name(name, except_id=sid)
                data["name"] = name
                util.write_json(f, data)
                from . import presets
                new_id = presets.rename_id(sid, data["name"])
                presets.write_skill(new_id)
                return self._json({"ok": True, "id": new_id})
                return self._json({"ok": True})
            if path == "/api/styles/delete":
                import shutil as _sh
                import time as _t
                sid = util.slugify(str(body.get("id", "")))
                if not (util.USER_STYLES_DIR / f"{sid}.json").exists():
                    raise util.Fail("That preset doesn't exist.")
                dest = util.STUDIO_OUT / "trash" / f"preset-{sid}-{_t.strftime('%Y%m%d-%H%M%S')}"
                dest.mkdir(parents=True, exist_ok=True)
                for f in (util.USER_STYLES_DIR / f"{sid}.json", util.USER_STYLES_DIR / f"{sid}.md", util.USER_STYLES_DIR / f"{sid}.frames", util.USER_STYLES_DIR / f"{sid}.recipes"):
                    if f.exists():
                        _sh.move(str(f), str(dest / f.name))
                for root in (util.ROOT / ".claude" / "skills", util.ROOT / ".agents" / "skills"):
                    if (root / f"preset-{sid}").exists():
                        _sh.move(str(root / f"preset-{sid}"), str(dest / f"skill-{root.parent.name}"))
                util.update_profile(lambda p: p.update(learned_styles=[x for x in p.get("learned_styles", []) if x != sid],
                                                       **({"style": "creatorcut-signature"} if p.get("style") == sid else {})))
                from . import videos as _v
                for f in util.PROJECTS.glob("*/project.json"):          # videos that used it return to the Signature fallback
                    if util.read_json(f, default={}).get("style") == sid:
                        _v.update(f.parent.name, lambda c: c.update(style="creatorcut-signature", preset_version=None))
                return self._json({"ok": True})
            if path == "/api/styles/rulebook":
                sid = util.slugify(str(body.get("id", "")))
                if not (util.USER_STYLES_DIR / f"{sid}.json").exists():
                    raise util.Fail("Only your own styles have an editable rulebook.")
                from . import teach
                teach.keep_history(sid)
                (util.USER_STYLES_DIR / f"{sid}.md").write_text(str(body.get("text", ""))[:20000], encoding="utf-8")
                from . import presets
                presets.write_skill(sid)
                events.emit("style.rulebook", {"style": sid})
                return self._json({"ok": True})
            if path == "/api/profile/website":
                return self._json(read_website(str(body.get("url", ""))))
            if path == "/api/storage/clean":
                return self._json(clean_storage())
            if path == "/api/update/check":
                from . import updater
                return self._json(updater.check())
            if path == "/api/update/apply":
                from . import updater
                if updater.is_running() or updater.is_queued():
                    return self._json({"ok": True, "running": True})
                threading.Thread(target=updater.run_in_studio, args=(updater.restart_server,), daemon=True).start()
                return self._json({"ok": True})
            if path == "/api/teach":
                from . import refs
                label = str(body.get("label") or body.get("name") or "").strip()[:40]
                if not label:
                    raise util.Fail("Give the preset a name.")
                _unique_preset_name(label)
                ids = [str(i) for i in (body.get("ids") or body.get("sources") or [])][:5] or None
                project = str(body.get("project") or "") or None
                if project:
                    from . import videos
                    videos.load(project)
                job = refs.learn(label, label, ids, note=str(body.get("note") or "")[:3000], project=project)
                return self._json({"ok": True, "job": job["id"]})
            if path.startswith("/api/videos"):
                return self._json(api_videos(path, body))
            if path == "/api/event":
                return self._json(api_event(str(body.get("type", "")), body.get("payload") or {}))
            if path == "/api/open":
                return self._json(api_open(str(body.get("what", ""))))
            return self._error(404, "Unknown address.")
        except util.Fail as e:
            return self._error(400, e.message, e.fix)
        except (BrokenPipeError, ConnectionResetError):
            return
        except Exception:
            util.log_exception(f"POST {path}")
            return self._error(500, "Something went wrong in the Studio. Say 'check my studio' to your editor.")

    # ----------------------------------------------------------------- page ----
    def _page(self):
        query=parse_qs(urlparse(self.path).query)
        nonce=(query.get('cc_embed') or [''])[0]
        grants=util.read_json(util.STUDIO_OUT/'embed-grants.json',default={})
        embedded=bool(nonce and grants.get(nonce,{}).get('expires',0)>time.time())
        html = PAGE.read_text(encoding="utf-8")
        boot = json.dumps({"token": TOKEN, "port": PORT["n"]})
        html = html.replace("<head>", f"<head>\n<script>window.AIE_SERVER = {boot};</script>", 1)
        app = util.KIT / "studio" / "app"
        from . import static_cache
        ver=static_cache.version(app)
        html = re.sub(r'((?:src|href)="kit/studio/app/[^"?]+)"', rf'\1?v={ver}"', html)
        self._send(200, html.encode("utf-8"), "text/html; charset=utf-8",
                   {"Set-Cookie": f"aie_t_{PORT['n']}={TOKEN}; Path=/; HttpOnly; SameSite=Strict",
                    "Content-Security-Policy": "default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; "
                                               "style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; "
                                               "connect-src 'self'; font-src 'self' data:; " + ("" if embedded else "frame-ancestors 'self'")})

    # ---------------------------------------------------------------- files ----
    def _file(self, rel: str, prefixes: tuple, private: bool, download_name: str = ''):
        rel = rel.replace("\\", "/").lstrip("/")
        if ".." in rel.split("/") or not rel.startswith(prefixes) and rel not in prefixes:
            return self._send(404, b"Not found", "text/plain")
        p = (util.ROOT / rel)
        try:
            p = p.resolve()
            p.relative_to(util.ROOT.resolve())
        except (ValueError, OSError):
            return self._send(404, b"Not found", "text/plain")
        if not p.is_file():
            if not private and rel in STATIC_FILES:      # progress/data files that don't exist yet on a fresh install
                return self._send(200, b"/* not yet */\n", "text/javascript; charset=utf-8")
            return self._send(404, b"Not found", "text/plain")
        if private and p.suffix.lower() not in MEDIA_EXT:
            return self._send(404, b"Not found", "text/plain")
        ctype = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
        if p.suffix.lower() in (".js", ".mjs"):
            ctype = "text/javascript; charset=utf-8"
        elif p.suffix.lower() == ".css":
            ctype = "text/css; charset=utf-8"
        elif p.suffix.lower() == ".otf":
            ctype = "font/otf"
        elif p.suffix.lower() == ".ttf":
            ctype = "font/ttf"
        elif p.suffix.lower() in (".mov", ".m4v"):
            ctype = "video/mp4"   # browsers play most phone .mov files when labelled as MP4
        size = p.stat().st_size
        rng = self.headers.get("Range")
        start, end = 0, size - 1
        code = 200
        if rng:
            m = re.fullmatch(r"bytes=(\d*)-(\d*)", rng.strip())
            if not m or (not m.group(1) and not m.group(2)):
                return self._send(416, b"", "text/plain", {"Content-Range": f"bytes */{size}"})
            if m.group(1):
                start = int(m.group(1))
                end = int(m.group(2)) if m.group(2) else size - 1
            else:  # suffix range: last N bytes
                start = max(0, size - int(m.group(2)))
            end = min(end, size - 1)
            if start > end or start >= size:
                return self._send(416, b"", "text/plain", {"Content-Range": f"bytes */{size}"})
            code = 206
        cache="private, no-cache" if private else ("public, max-age=3600" if rel.startswith('kit/studio/app/') and 'v=' in self.path else 'no-store')
        if not private and code==200 and p.suffix in ('.js','.css','.svg') and 'gzip' in self.headers.get('Accept-Encoding','') and size<4*1024*1024:
            from . import static_cache
            return self._send(200,static_cache.compressed(p),ctype,{'Content-Encoding':'gzip','Vary':'Accept-Encoding','Cache-Control':cache})
        length = end - start + 1
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(length))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", cache)
        if download_name and private:
            name=re.sub(r'[\x00-\x1f\x7f"\\/]', '_', download_name)[:180] or p.name
            ascii_name=name.encode('ascii','ignore').decode() or 'CreatorCut-video.mp4'
            self.send_header('Content-Disposition',f'attachment; filename="{ascii_name}"; filename*=UTF-8\'\'{quote(name,safe="")}')
        if code == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.end_headers()
        if self.command == "HEAD":
            return
        try:
            with p.open("rb") as f:
                f.seek(start)
                left = length
                while left > 0:
                    chunk = f.read(min(256 * 1024, left))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass

    # --------------------------------------------------------------- upload ----
    def _music_upload(self,q):
        from . import videos,music_library
        pid=(q.get('project') or [''])[0];p=videos._dir(pid);token=(q.get('intent') or [''])[0]
        guard=lambda:music_library.intent_guard(pid,token)
        with guard():pass
        name=Path(unquote(self.headers.get('X-Filename','track.mp3')).replace('\\','/')).name
        ext=Path(name).suffix.lower()
        if ext not in ('.mp3','.m4a','.wav','.aac','.ogg','.flac'):raise util.Fail('Choose an MP3, M4A, WAV, AAC, OGG or FLAC track.')
        size=self._content_length(100*1024*1024,required=True)
        if size<=0:raise util.Fail('Choose an audio file that is not empty.')
        if shutil.disk_usage(util.ROOT).free<size+500*1024**2:raise util.Fail('Free some space before uploading this track. Your previous choice is safe.')
        folder=util.STUDIO_OUT/'assets/music-staging';folder.mkdir(parents=True,exist_ok=True)
        import tempfile
        fd,temp=tempfile.mkstemp(suffix=ext,dir=folder);file=Path(temp);started=time.monotonic()
        try:
            with os.fdopen(fd,'wb') as out:
                left=size
                while left:
                    with guard():pass
                    if time.monotonic()-started>90:raise util.Fail('The track upload took too long. Try again.')
                    block=self.rfile.read(min(65536,left))
                    if not block:raise util.Fail('The upload was interrupted. Your previous music is safe.')
                    out.write(block);left-=len(block)
            result=music_library.upload(pid,file,name,guard=guard)
            events.emit('music.saved',{'project':pid},source='studio')
            return self._json(result)
        finally:file.unlink(missing_ok=True)

    def _upload(self, q: dict):
        kind = (q.get("kind") or [""])[0]
        project = (q.get("project") or [""])[0]
        if project and kind == "reference":           # a reference video for one Studio video
            from . import videos
            videos.load(project)
            folder, exts, limit = UPLOAD["reference"]
        elif project:                                    # into a video's media bin (raw, broll, image, music)
            from . import videos
            if kind not in videos.MEDIA_KINDS:
                raise util.Fail("Unknown upload type.")
            folder = videos._dir(project) / "media"
            exts = videos.MEDIA_KINDS[kind]
            limit = UPLOAD["raw"][2]
        elif kind not in UPLOAD:
            raise util.Fail("Unknown upload type.")
        else:
            folder, exts, limit = UPLOAD[kind]
        if project:
            from .editor import protect_inputs
            protect_inputs(lambda pid: None)(project)
        name = unquote(self.headers.get("X-Filename") or "")
        name = Path(name.replace("\\", "/")).name
        name = re.sub(r"[^\w .()+&,'-]", "_", name).strip(" .")[:120] or "clip"
        ext = Path(name).suffix.lower()
        if ext not in exts:
            nice = ", ".join(sorted(e.lstrip(".").upper() for e in exts if e not in (".mts", ".avi", ".mkv")))
            raise util.Fail(f"That file type ({ext or 'unknown'}) can't be used here.", f"Use one of: {nice}.")
        n = self._content_length(limit, required=True)
        if shutil.disk_usage(util.ROOT).free < n + 500 * 1024 ** 2:
            raise util.Fail("Your computer is almost out of space.", "Free up some disk space and drop it again.")
        folder.mkdir(parents=True, exist_ok=True)
        dest = _free_name(folder, name)
        part = dest.with_name(dest.name + ".part")
        got = 0
        deadline = time.monotonic() + 1200
        try:
            with part.open("wb") as f:
                while got < n:
                    if time.monotonic() > deadline:
                        raise util.Fail("The upload took too long.", "Try a smaller file or retry this upload.")
                    try:
                        chunk = self.rfile.read(min(1024 * 1024, n - got))
                    except (TimeoutError, OSError):
                        self.close_connection = True
                        raise util.Fail("The upload stopped sending data.", "Your original file is unchanged. Drop it again.")
                    if not chunk:
                        break
                    f.write(chunk)
                    got += len(chunk)
            if got != n:
                raise util.Fail("The upload stopped before it finished.", "Drop the file again.")
            part.replace(dest)
        finally:
            part.unlink(missing_ok=True)
        result = {"ok": True, "kind": kind, "file": util.rel(dest), "name": dest.name}
        if project and kind == "reference":
            from . import refs
            result["ref"] = refs.add_file(dest, project=project)
            return self._json(result)
        if project:
            from . import videos
            result["item"] = videos.add_media(project, dest, kind, name)
            return self._json(result)
        if kind == "reference":
            from . import refs
            result["ref"] = refs.add_file(dest)
        elif kind == "raw":
            dur = _duration(dest)
            result["duration"] = dur
            events.emit("clip.added", {"file": util.rel(dest), "name": dest.name, "original_name": name,
                                       "duration": dur, "size_mb": round(n / 1e6, 1)})
        else:
            events.emit(f"{kind}.added", {"file": util.rel(dest), "name": dest.name})
        return self._json(result)

    # ------------------------------------------------------------------ SSE ----
    def _sse(self, q: dict):
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "keep-alive")
        self.send_header("X-Accel-Buffering", "no")
        self.end_headers()
        self.close_connection = True
        last_fp, last_ev, last_ping = None, events.last_id(), time.monotonic()
        try:
            while True:
                fp = fingerprint()
                if fp != last_fp:
                    data = json.dumps(state_feed.snapshot(), ensure_ascii=False)
                    self.wfile.write(f"event: state\ndata: {data}\n\n".encode("utf-8"))
                    last_fp = fp
                for ev in events.since(last_ev):
                    self.wfile.write(f"event: studio\ndata: {json.dumps(ev, ensure_ascii=False)}\n\n".encode("utf-8"))
                    last_ev = ev["id"]
                if time.monotonic() - last_ping > 10:
                    self.wfile.write(b'event: heartbeat\ndata: {}\n\n')
                    last_ping = time.monotonic()
                self.wfile.flush()
                time.sleep(0.7)
        except (BrokenPipeError, ConnectionResetError, OSError):
            return


# ------------------------------------------------------------------- APIs ----
def fingerprint() -> str:
    parts = [str(int(time.monotonic() // 15)), str(events.last_id()), str(jobs.VERSION["n"]), str(events.listening()["listening"])]
    for p in (util.STUDIO_OUT / "progress.js", util.PROFILE, util.STUDIO_OUT / "activity.json", util.RAW, util.FINISHED,
              util.USER_STYLES_DIR, util.BRAND / "learned.json", util.BRAND / "learning-progress.json", util.STUDIO_OUT / "assets" / "styles"):
        parts.append(str(events.watch_file_mtime(p)))
    for f in util.USER_STYLES_DIR.glob("*.json"):
        parts.append(f"{f}:{events.watch_file_mtime(f)}")
    for f in (util.STUDIO_OUT / 'activities').glob('*.json'):
        parts.append(f"{f}:{events.watch_file_mtime(f)}")
    for f in util.PROJECTS.glob("*/*.json"):
        parts.append(f"{f}:{events.watch_file_mtime(f)}")
    for f in util.PROJECTS.glob("*/preview.mp4"):
        parts.append(f"{f}:{events.watch_file_mtime(f)}")
    return hashlib.sha1("|".join(parts).encode()).hexdigest()


def _free_name(folder: Path, name: str) -> Path:
    dest = folder / name
    stem, ext, n = dest.stem, dest.suffix, 2
    while dest.exists() or dest.with_name(dest.name + ".part").exists():
        dest = folder / f"{stem} ({n}){ext}"
        n += 1
    return dest


def _duration(p: Path) -> float | None:
    try:
        return round(util.probe(p)["duration"], 1)
    except Exception:
        return None


def api_profile(body: dict) -> dict:
    if "whisper_model" in body:
        from . import speech_models
        speech_models.name(body["whisper_model"])
    accent = body.get("accent")
    if accent and not re.fullmatch(r"#[0-9A-Fa-f]{6}", str(accent)):
        raise util.Fail("That colour isn't valid.")

    def change(prof):
        for k, v in body.items():
            if k not in PROFILE_KEYS:
                continue
            if k == "accent":
                prof.setdefault("brand", {})["accent"] = v
            elif k == "onboarding" and isinstance(v, dict):
                prof.setdefault("onboarding", {}).update(v)
            elif k == "vocabulary" and isinstance(v, str):
                prof[k] = [w.strip() for w in v.split(",") if w.strip()]
            else:
                prof[k] = v

    prof = util.update_profile(change)
    if "memory" in body:                             # a remembered line removed in the Studio: forget the rule too
        from . import learn
        learn.sync_from_profile()
    from . import state
    return state.profile_public(prof)


def api_event(type_: str, payload: dict) -> dict:
    if not re.fullmatch(r"[a-z]+(\.[a-z]+){1,2}", type_):
        raise util.Fail("Unknown event.")
    payload = {k: v for k, v in payload.items() if isinstance(k, str)}
    if len(json.dumps(payload)) > 20000:
        raise util.Fail("That message is too long.")
    if type_ == "edit.set":
        return apply_setting(str(payload.get("project", "")), str(payload.get("key", "")), payload.get("value"))
    if type_ == "edit.approve":
        p = _project(payload.get("project"))
        job = queue_render(p)
        ev = events.emit("edit.approve", {"project": p.name, "job": job["id"], "rendering": True})
        return {"ok": True, "event": ev["id"], "job": job["id"]}
    if type_ == "versions.request":
        p = _project(payload.get("project"))
        prof = util.load_profile()
        main = prof.get("platform", "tiktok")
        targets = [t for t in payload.get("targets") or ["tiktok", "reels", "shorts"] if t != main][:4]
        job = jobs.submit("versions", lambda jid: _versions(jid, p, targets), key=p.name, label="Other platforms",
                          needs="tools")
        return {"ok": True, "job": job["id"], "event": events.emit(type_, {"project": p.name, "targets": targets})["id"]}
    if type_ == "compare.request":
        p = _project(payload.get("project"))
        job = jobs.submit("compare", lambda jid: _simple(jid, ["compare", p.name]), key=p.name, label="Before/after",
                          needs="tools")
        return {"ok": True, "job": job["id"], "event": events.emit(type_, {"project": p.name})["id"]}
    if type_ == "cover.request":
        p = _project(payload.get("project"))
        text = str(payload.get("text") or _hook_text(p) or "").strip()[:60]
        if not text:
            ev = events.emit("post.request", {"project": p.name, "want": "cover"})
            return {"ok": True, "event": ev["id"], "agent": True}
        job = jobs.submit("cover", lambda jid: _simple(jid, ["cover", p.name, "--text", text]), key=p.name,
                          label="Cover", needs="tools")
        return {"ok": True, "job": job["id"]}
    if type_ in ("repair.request", "update.request", "onboarding.done", "edit.request", "post.request", "style.preview", "check.studio",
                 "onboarding.step", "clip.added", "studio.opened"):
        if type_ == "edit.request":
            text = str(payload.get("text", "")).strip()
            if not text:
                raise util.Fail("Tell your editor what to change first.")
            payload["text"] = text[:2000]
        if type_ == "onboarding.done":
            prof = util.update_profile(lambda pr: pr.setdefault("onboarding", {}).update({"done": True}))
            from . import state
            payload = dict(payload, profile=state.profile_public(prof))
        if type_ == "clip.added" and payload.get("file"):   # an existing clip in my-videos/raw picked in the Studio
            f = util.ROOT / str(payload["file"])
            if not jobs.path_ok(f) or not f.exists() or f.parent.resolve() != util.RAW.resolve():
                raise util.Fail("That clip isn't in your raw folder.")
            payload = {"file": util.rel(f), "name": f.name, "duration": _duration(f)}
        ev = events.emit(type_, payload)
        return {"ok": True, "event": ev["id"], "listening": events.listening()["listening"]}
    raise util.Fail("Unknown event.")


def api_videos(path: str, body: dict) -> dict:
    """Studio video projects: create, brief, media, chat, versions."""
    from . import videos
    pid = str(body.get("project", ""))
    if path == "/api/videos/new":
        cfg = videos.create(str(body.get("title", "")), str(body.get("style", "")), str(body.get("platform", "")), request_id=str(body.get("request_id", "")))
        from . import state_feed
        state_feed.invalidate()
        return {"ok": True, "project": cfg["name"]}
    if path == '/api/videos/timeline-frames':
        from . import annotations
        version=int(body.get('version',0));annotations._snapshot(pid,version)
        job=jobs.submit('timeline_frames',lambda _:annotations.make_strip(pid,version),key=pid+':'+str(version))
        return {'ok':True,'job':job['id']}
    if path == '/api/videos/annotation':
        from . import annotations
        note=annotations.add(pid,body.get('note',{}))
        return {'ok':True,'note':note,'prompt':annotations.prompt(note)}
    if path == '/api/videos/annotation-remove':
        from . import annotations
        return {'ok':True,'note':annotations.remove(pid,str(body.get('id','')))}
    if path in ('/api/videos/annotation-batch','/api/videos/annotation-batch-received','/api/videos/annotation-received','/api/videos/edit-request'):
        raise util.Fail('Open Studio and press Make my video or Update video.')
    if path == "/api/videos/start":
        return videos.start_preparation(pid)
    if path == "/api/videos/brief":
        videos.set_brief(pid, body.get("brief") or {})
        return {"ok": True}
    if path == "/api/videos/media/remove":
        videos.remove_media(pid, str(body.get("id", "")))
        return {"ok": True}
    if path == "/api/videos/mirror-user":
        text=str(body.get('text','')).strip()
        if not text or len(text)>6000:raise util.Fail('Invalid mirrored message.')
        videos.load(pid)
        # Display history only: never emit studio.chat/video.create or start inference.
        msg=videos.say(pid,'user',text,native=True,host_acknowledged=True)
        from . import learn
        learn.log_feedback(text, pid, videos.load(pid).get('style', ''))
        return {'ok':True,'message':msg}
    if path in {"/api/videos/chat", "/api/videos/create", "/api/videos/note"}:
        raise util.Fail("Studio is the editing panel, not a separate AI chat.",
                        "Continue in the conversation beside Studio. Your uploaded files are already saved.")
    if path == "/api/videos/restore":
        videos.restore_version(pid, int(body.get("n", 0)))
        events.emit("version.restored", {"project": pid, "n": int(body.get("n", 0))})
        return {"ok": True}
    if path == "/api/videos/caption":
        return fix_caption(pid, int(body.get("index", -1)), str(body.get("text", "")))
    if path == "/api/videos/reference":       # a reference link for this video: fetched and analysed frame by frame
        from . import refs
        ref = refs.add_url(str(body.get("url", "")), project=pid)
        return {"ok": True, "ref": ref}
    if path == "/api/videos/reference/remove":
        from . import refs
        r = refs.load(str(body.get("id", "")))
        if r.get("project") != pid:
            raise util.Fail("That reference isn't on this video.")
        refs.remove(r["id"])
        return {"ok": True}
    if path == "/api/videos/delete":
        videos.trash(pid)
        return {"ok": True}
    if path == "/api/videos/duplicate":
        src = videos.load(pid)
        cfg = videos.create(src.get("title", "") + " copy", src.get("style", ""), src.get("platform", ""))
        videos.set_brief(cfg["name"], src.get("brief", {}))
        from . import state_feed
        state_feed.invalidate()
        return {"ok": True, "project": cfg["name"]}
    raise util.Fail("Unknown address.")


def fix_caption(pid: str, index: int, text: str) -> dict:
    """Fix a misheard word straight from the timeline (the transcript keeps its timing)."""
    p = _project(pid)
    text = text.strip()
    if not text or len(text) > 60:
        raise util.Fail("Type the corrected word.")
    wj = util.read_json(p / "words.json")
    if not 0 <= index < len(wj["words"]):
        raise util.Fail("That word doesn't exist.")
    old = wj["words"][index]["w"]
    wj["words"][index]["w"] = text
    util.write_json(p / "words.json", wj)
    tr = util.read_json(p / "transcript.json", default=None)
    src_i = wj["words"][index].get("i")
    if tr and src_i is not None and src_i < len(tr.get("words", [])):
        tr["words"][src_i]["w"] = text
        util.write_json(p / "transcript.json", tr)
    events.emit("edit.set", {"project": p.name, "key": "caption_word", "value": f"{old} → {text}", "applied": True})
    job = queue_preview(p)
    return {"ok": True, "job": job.get("id")}


def _unique_preset_name(name: str, except_id: str = "") -> None:
    """Every preset has its own name, so two can never look the same in the Studio."""
    for f in util.USER_STYLES_DIR.glob("*.json"):
        if f.stem == except_id:
            continue
        d = util.read_json(f, default={})
        if not d.get("hidden") and str(d.get("name", "")).strip().lower() == name.strip().lower():
            raise util.Fail(f"You already have a preset called “{name}”.", "Pick another name.")


def read_website(url: str) -> dict:
    """Read the creator's website: title, description and preview image, saved to their profile. The agent is
    then asked to read it properly and remember what matters (what they sell, their voice, their offer)."""
    import html as _html
    from urllib.parse import urljoin, urlparse
    url = url.strip()
    if not url:
        util.update_profile(lambda p: p.pop("website", None))
        return {"ok": True}
    if "://" not in url:
        url = "https://" + url
    u = urlparse(url)
    if u.scheme not in ("http", "https") or not u.hostname or u.hostname in ("localhost", "127.0.0.1") or u.hostname.startswith(("10.", "192.168.")):
        raise util.Fail("That doesn't look like a website address.")

    def work(jid):
        from .linkfetch import _get, _download
        page = _get(url, timeout=20).decode("utf-8", "replace")[:600000]
        def meta(*names):
            for n in names:
                for tag in re.findall(r"<meta\b[^>]*>", page, re.I):
                    if re.search(r'(?:property|name)\s*=\s*["\']' + re.escape(n) + r'["\']', tag, re.I):
                        m = re.search(r'content\s*=\s*(["\'])(.*?)\1', tag, re.I | re.S)
                        if m:
                            return _html.unescape(m.group(2)).strip()
            return ""
        title = meta("og:title", "twitter:title") or _html.unescape((re.search(r"<title[^>]*>(.*?)</title>", page, re.S | re.I) or [None, ""])[1]).strip()
        desc = meta("og:description", "description", "twitter:description")
        img = meta("og:image", "twitter:image")
        thumb = ""
        if img:
            try:
                dest = util.BRAND / "website.jpg"
                _download(urljoin(url, img), dest, url)
                thumb = util.rel(dest)
            except Exception:
                pass
        info = {"url": url, "host": u.hostname.replace("www.", ""), "title": title[:120], "description": desc[:300], "thumb": thumb}
        util.update_profile(lambda p: p.update(website=info))
        events.emit("profile.website", info)
        return info

    job = jobs.submit("website", work, key="website", label="Reading your website", heavy=False)
    return {"ok": True, "job": job["id"]}


def clean_storage() -> dict:
    """Free space: delete big working files of exported videos (finished videos and versions are kept)."""
    from . import updater
    updater.ensure_idle()
    freed = 0
    for f in util.PROJECTS.glob("*/project.json"):
        p = f.parent
        if p.name.startswith("_"):
            continue
        with util.project_lock(p):
            cfg = util.read_json(f, default={})
            if cfg.get("status") != "finished":
                continue
            for g in (p / "cut.mp4", p / "audio16k.wav", p / "media" / "joined.mp4"):
                if g.exists():
                    freed += g.stat().st_size
                    g.unlink()
    return {"ok": True, "freed_mb": round(freed / 1e6)}


def _project(name) -> Path:
    name = str(name or "")
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,80}", name):
        raise util.Fail("Pick a video first.")
    return util.project_dir(name)


def _hook_text(p: Path) -> str:
    post = next(util.FINISHED.glob(f"{p.name}-post.json"), None) if util.FINISHED.exists() else None
    if post:
        t = util.read_json(post).get("cover_text")
        if t:
            return t
    for b in util.read_json(p / "beats.json", default={"beats": []}).get("beats", []):
        if b.get("type") == "title" and b.get("text"):
            return b["text"]
    return ""


def apply_setting(project: str, key: str, value) -> dict:
    """Apply a simple, deterministic setting from the inspector, then queue a preview re-render."""
    p = _project(project)
    if key not in DIRECT_SETTINGS:
        raise util.Fail("That setting can't be changed from here.", "Tell your editor in words instead.")
    path, typ = DIRECT_SETTINGS[key]
    if key=='video_length':
        from .request_constraints import length_bounds
        length_bounds(value)
    if key=='cta' and (not isinstance(value,str) or len(value)>300):raise util.Fail('Keep the ending line under 300 characters.')
    if key=='caption_mode':raise util.Fail('Caption animation is part of your chosen caption style. Choose a different caption style in Studio instead.')
    if typ is bool and type(value) is not bool:raise util.Fail("Choose this switch on or off.")
    try:
        val = typ(value) if typ is not bool else bool(value)
    except (TypeError, ValueError):
        raise util.Fail("That value isn't valid.")
    if key in RANGES:
        lo, hi = RANGES[key]
        if not __import__('math').isfinite(val):raise util.Fail("Choose a finite number.")
        val = max(lo, min(hi, val))
    if key in CHOICES and val not in CHOICES[key]:
        raise util.Fail("That option isn't available.")
    if key == "style":
        from . import styles as st
        st.load(val)
    if key == "music" and val not in ("auto", "none") and not str(val).startswith("library:"):
        if not (util.MUSIC / Path(val).name).exists():
            raise util.Fail("I can't find that music file in my-brand/music.")
    from . import videos
    from . import editor
    with util.file_guard(p/'.request.guard',timeout=5),util.file_guard(p/'.editor-job.guard',timeout=5):
        if editor.read(p.name).get('state') in editor.ACTIVE:
            pending=util.read_json(p/'next-settings.json',default={});pending[key]=val
            if key=='music':pending.pop('music_selection',None)
            util.write_durable_json(p/'next-settings.json',pending)
            return {'ok':True,'queued':True,'value':val,'message':'Saved for your next edit'}
        if key=='music':
            from . import music_library
            music_library.clear_pending_music(p)
        videos.update(p.name,lambda cfg:_set_cfg_value(cfg,key,val))
    ev = events.emit("edit.set", {"project": p.name, "key": key, "value": val, "applied": False})
    job = queue_preview(p)
    return {"ok": True, "event": ev["id"], "job": job["id"], "value": val}


def _set_cfg_value(cfg,key,val):
    path,typ=DIRECT_SETTINGS[key]
    cur=cfg;parts=path.split('.')
    for part in parts[:-1]:
        if not isinstance(cur.get(part),dict):cur[part]={}
        cur=cur[part]
    cur[parts[-1]]=val
    cfg.setdefault('choice_origins',{})[parts[0]]='studio'
    if key=='music':cfg.pop('music_selection',None)
    if key=='captions_on' and val and cfg.get('library_choices',{}).get('caption')=='none':cfg['library_choices'].pop('caption',None)
    if key=='grade':
        cfg['choice_origins']['look']='studio'
        cfg['choice_origins']['colour_recipe']='studio'
        from . import colour_choice
        cfg['look']=colour_choice.ALIASES.get(val,val);cfg['colour_recipe']=None;cfg['colour_recipe']=colour_choice.pin(cfg)


def apply_pending_settings(pid):
    from . import videos
    p=videos._dir(pid);file=p/'next-settings.json';pending=util.read_json(file,default={})
    if not pending:return
    def apply(cfg):
        for key,val in pending.items():
            if key=='music_selection':
                if not isinstance(val,dict):raise util.Fail('The saved track choice needs checking.')
                if val.get('mode') in ('library','upload'):
                    from . import music_library
                    music_library.verified_file(p,val)
                cfg[key]=val;continue
            if key not in DIRECT_SETTINGS:raise util.Fail('A saved next-edit setting is not supported.')
            _,typ=DIRECT_SETTINGS[key]
            if typ is bool and type(val) is not bool:raise util.Fail('A saved next-edit switch is not valid.')
            value=typ(val)
            if key in CHOICES and value not in CHOICES[key]:raise util.Fail('A saved next-edit choice is not supported.')
            if key in RANGES:
                lo,hi=RANGES[key]
                if not __import__('math').isfinite(value):raise util.Fail('A saved next-edit number is not finite.')
                value=max(lo,min(hi,value))
            _set_cfg_value(cfg,key,value)
        if 'music_selection' in pending:cfg['music_selection']=pending['music_selection']
    videos.update(pid,apply);file.unlink()


def queue_preview(p: Path) -> dict:
    """Save UI changes for the native editing conversation; do not fake an agent job."""
    from . import videos
    videos.update(p.name, lambda cfg: cfg.update(settings_need_edit=True))
    return {'id':'','state':'saved','needs_native_edit':True}


def queue_render(p: Path) -> dict:
    existing = jobs.find("render", p.name, states=("queued", "waiting", "running"))
    if existing:
        return existing

    def work(jid):
        out = _simple(jid, ["render", p.name])
        m = re.search(r"^OUTPUT=(.+)$", out["log"], re.M)
        res = {"output": m.group(1).strip() if m else ""}
        events.emit("render.done", {"project": p.name, **res}, source="server")
        return res

    return jobs.submit("render", work, key=p.name, label="Final video", needs="tools")


def _simple(jid: str, args: list[str]) -> dict:
    out = jobs.engine(jid, args)
    return {"log": out[-4000:]}


def _versions(jid: str, p: Path, targets: list[str]) -> dict:
    out = jobs.engine(jid, ["export", p.name, "--to", ",".join(targets)])
    return {"targets": targets, "log": out[-2000:]}


def api_open(what: str) -> dict:
    """Open one of the creator's folders in Finder / Explorer."""
    folders = {"raw": util.RAW, "finished": util.FINISHED, "references": util.REFERENCES, "proof": util.BRAND / "proof",
               "music": util.MUSIC}
    if what not in folders:
        raise util.Fail("Unknown folder.")
    f = folders[what]
    f.mkdir(parents=True, exist_ok=True)
    try:
        if util.os_name() == "mac":
            subprocess.Popen(["open", str(f)])
        elif util.os_name() == "windows":
            subprocess.Popen(["explorer", str(f)])
        else:
            subprocess.Popen(["xdg-open", str(f)])
    except OSError:
        raise util.Fail("Couldn't open the folder.", f"It's at {util.rel(f)}.")
    return {"ok": True, "path": util.rel(f)}


# ----------------------------------------------------------------- start ----
def _port_free(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        if os.name != "nt":   # same rule the HTTP server uses, so a just-closed port counts as free
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False


def installation_key() -> str:
    return hashlib.sha256(str(util.ROOT.resolve()).encode()).hexdigest()


def write_server_info(port: int) -> None:
    info = {"port": port, "pid": os.getpid(), "started": time.time(), "url": f"http://localhost:{port}/", "installation": installation_key()}
    util.write_json(SERVER_JSON, info)
    SERVER_JS.write_text(f"window.AIE_SERVER_INFO = {json.dumps(info)};\n", encoding="utf-8")


def running_server() -> dict | None:
    """The Studio server already running for this folder, if any."""
    info = util.read_json(SERVER_JSON, default={})
    if not info.get("port"):
        return None
    try:
        import urllib.request
        with urllib.request.urlopen(f"http://127.0.0.1:{info['port']}/api/ping", timeout=1.5) as r:
            data = json.loads(r.read().decode())
            if data.get("app") == "the-ai-editor" and data.get("installation") == installation_key():
                return info
    except Exception:
        return None
    return None


def _update_checks() -> None:
    """Look for a new version when the Studio starts and every 6 hours (the Studio shows "Update available")."""
    from . import updater
    st = util.read_json(updater.STATE, default={})
    if st.get("status") in ("downloading", "installing") and not (updater.is_running() or updater.is_queued()):
        util.write_json(updater.STATE, dict(st, status="", step=""))
    failures = 0
    while True:
        try:
            result = updater.check()
            failures = failures + 1 if result.get('error') else 0
        except Exception as e:
            failures += 1
            util.log(f"update check: {e}")
        time.sleep(min(900, 60 * 2 ** min(failures - 1, 4)) if failures else 6 * 3600)


def serve(port: int | None = None) -> None:
    # Also cover direct `studio serve` launches and a launcher dying mid-setup.
    # The kernel releases this ownership on exit; never delete its guard inode.
    with util.file_guard(util.ROOT / '.creatorcut-editor-control' / 'server-live.guard',
                         'Studio is already starting or running.'):
        _serve_owned(port)


def _serve_owned(port: int | None = None) -> None:
    # Restore before accepting requests or starting the editor supervisor.
    from . import updater
    if updater.recover_interrupted():
        os.execv(sys.executable, [sys.executable] + sys.argv)
        return
    from . import editor
    # Legacy retirement runs after the shell opens; a blocked worker is a visible
    # recovery issue, never a server-start failure. Make retains its strict guard.
    from . import setup
    # First installation is verified by the installer; reopening must retain access to repair/sign-in.
    env_port = os.environ.get("PORT")
    if env_port and env_port.isdigit():
        chosen = int(env_port)        # the preview system picked it: use exactly this one
    else:
        want = port or 4317
        chosen = next((p for p in range(want, want + 30) if _port_free(p)), 0)
        if not chosen:
            raise util.Fail("No free port for the Studio.", "Close other apps using ports 4317-4346 and try again.")
    PORT["n"] = chosen
    util.STUDIO_OUT.mkdir(parents=True, exist_ok=True)
    httpd = ThreadingHTTPServer(("127.0.0.1", chosen), Handler)
    httpd.daemon_threads = True
    write_server_info(chosen)
    util.log(f"Studio server started on port {chosen} (pid {os.getpid()})")
    events.emit("studio.started", {"port": chosen}, source="server")
    from . import readiness
    def reconcile():
        editor.retire_for_studio_start()
        try:
            from . import refs,activity_store
            refs.reconcile_interrupted();activity_store.prune_finished()
        except Exception:util.log_exception('startup reconciliation')
    threading.Thread(target=reconcile,name='creatorcut-reconciliation',daemon=True).start()
    from . import chat_execution
    readiness.start()
    threading.Thread(target=_update_checks, daemon=True).start()
    print(f"✓ Studio running at http://localhost:{chosen}/  (leave this running)", flush=True)
    print(f"STUDIO_URL=http://localhost:{chosen}/", flush=True)
    try:
        httpd.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
        info = util.read_json(SERVER_JSON, default={})
        if info.get("pid") == os.getpid():
            SERVER_JSON.unlink(missing_ok=True)
            SERVER_JS.unlink(missing_ok=True)


def start_detached(port: int = 4317, *, startup_timeout: float = 90) -> dict:
    """Reuse a healthy server or launch one owned child with bounded cleanup.

    Editing readiness is checked in the child after its shell becomes available. The start guard
    serializes callers; the separate lifetime guard also covers direct serves.
    """
    deadline = time.monotonic() + max(0, float(startup_timeout))
    info = running_server()
    if info:
        return info
    with util.file_guard(util.ROOT / '.creatorcut-editor-control' / 'server-start.guard',
                         'Studio is still starting.', timeout=max(0, deadline-time.monotonic())):
        info = running_server()
        if info:
            return info
        if time.monotonic() >= deadline:
            raise util.Fail('Studio startup took too long.', 'Try opening Studio again.')
        util.STUDIO_OUT.mkdir(parents=True, exist_ok=True)
        kw = {}
        if util.os_name() == "windows":
            kw["creationflags"] = 0x00000008 | 0x00000200
        else:
            kw["start_new_session"] = True
        env = {k: v for k, v in os.environ.items() if k != "PORT"}
        child = None
        confirmed = False
        try:
            with (util.STUDIO_OUT / "server.out").open("ab") as log:
                child = subprocess.Popen(
                    [sys.executable, str(util.ROOT / "edit.py"), "studio", "serve", "--port", str(port)],
                    cwd=str(util.ROOT), stdout=log, stderr=log, stdin=subprocess.DEVNULL, env=env, **kw)
            child._creatorcut_isolated = util.os_name() != 'windows'
            while time.monotonic() < deadline:
                info = running_server()
                if info:
                    # A direct serve may have won the lifetime lock. Reuse it,
                    # but never leave this invocation's losing child behind.
                    confirmed = info.get('pid') == child.pid
                    return info
                if child.poll() is not None:
                    raise util.Fail('Studio has not opened because setup checks did not pass.',
                                    'Read kit/studio-out/server.out, finish setup, then open Studio again.')
                time.sleep(min(.25, max(0, deadline-time.monotonic())))
            raise util.Fail('Studio startup took too long.', 'Try opening Studio again.')
        finally:
            if child is not None and not confirmed:
                util.stop_process(child)
