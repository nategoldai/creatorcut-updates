"""References for style learning: dropped files and pasted links.

Each reference gets a folder kit/projects/_teach/_refs/<id>/ with ref.json (where it came from, its status),
frames/ and measurements.json. Dropped files are copies in my-brand/references (never the originals).
Linked videos are fetched with yt-dlp into kit/projects/_teach/_downloads/ and deleted right after analysis:
they're only used to learn the general feel, never re-used or re-uploaded."""
from __future__ import annotations

import re
import shutil
import time
import uuid
from pathlib import Path
from urllib.parse import urlparse

from . import events, jobs, teach, util

DOWNLOADS = teach.TEACH / "_downloads"
SUPPORTED = ("tiktok.com", "instagram.com", "youtube.com", "youtu.be", "vm.tiktok.com")


def _ref_dir(rid: str) -> Path:
    if not re.fullmatch(r"[a-z0-9-]{4,40}", rid or ""):
        raise util.Fail("That reference doesn't exist.")
    return teach.REFS / rid


def load(rid: str) -> dict:
    return util.read_json(_ref_dir(rid) / "ref.json")


def save(ref: dict) -> None:
    path=_ref_dir(ref['id']) / 'ref.json'
    with util.file_guard(path.parent/'.reference-save.guard',timeout=5):
        previous=util.read_json(path,default={})
        # A long scan must not resurrect a reference replaced while it ran.
        if previous.get('removed'):ref['removed']=True
        ref["updated"] = time.time()
        util.write_json(path, ref)


def all_refs() -> list[dict]:
    out = []
    if teach.REFS.exists():
        for f in teach.REFS.glob("*/ref.json"):
            try:
                r = util.read_json(f)
            except util.Fail:
                continue
            if r.get("removed") or r.get("used_by") or r.get("project"):
                continue
            out.append(r)
    return sorted(out, key=lambda r: r.get("created", 0))


def for_project(pid: str) -> list[dict]:
    """References added to one Studio video (kept with it, also after a preset was saved from them)."""
    out = []
    if teach.REFS.exists():
        for f in teach.REFS.glob("*/ref.json"):
            try:
                r = util.read_json(f)
            except util.Fail:
                continue
            if r.get("project") == pid and not r.get("removed"):
                out.append(r)
    return sorted(out, key=lambda r: r.get("created", 0))


def _new(kind: str, **kw) -> dict:
    rid = ("u-" if kind == "url" else "f-") + uuid.uuid4().hex[:8]
    ref = {"id": rid, "kind": kind, "status": "queued", "message": "", "created": time.time(), **kw}
    _ref_dir(rid).mkdir(parents=True, exist_ok=True)
    save(ref)
    return ref


def _replace_project_refs(project: str | None) -> None:
    """One reference per video: a new one replaces the previous (it stays on disk, just unlinked)."""
    if project:
        for r in for_project(project):
            _remove(r["id"])


def _add_file(path: Path, project: str | None = None) -> dict:
    """A dropped reference (already copied into my-brand/references)."""
    _replace_project_refs(project)
    ref = _new("file", file=util.rel(path), name=path.name, **({"project": project} if project else {}))
    _start_analysis(ref)
    return ref


def _add_url(url: str, project: str | None = None) -> dict:
    url = (url or "").strip()
    u = urlparse(url if "://" in url else "https://" + url)
    host = (u.hostname or "").lower()
    if u.scheme not in ("http", "https") or not host or not any(host == d or host.endswith("." + d) for d in SUPPORTED):
        raise util.Fail("That doesn't look like a TikTok, Instagram or YouTube link.",
                        "Copy the link from the app's Share button and paste it here.")
    for r in (for_project(project) if project else all_refs()):
        if r.get("url") == u.geturl() and r["status"] != "error":
            return r
    if _is_profile(u):
        videos_ = _profile_videos(u.geturl())
        if not videos_:
            raise util.Fail("Couldn't open that profile.", "Paste links to 2–5 of their videos instead.")
        refs_ = [_add_url(v, project) for v in videos_[:1 if project else 3]]
        return refs_[0]
    _replace_project_refs(project)
    ref = _new("url", url=u.geturl(), name=_short_name(u), host=host, **({"project": project} if project else {}))
    _start_analysis(ref)
    return ref


def _is_profile(u) -> bool:
    path = u.path.strip("/")
    host = (u.hostname or "").lower()
    if "tiktok" in host:
        return path.startswith("@") and "/video/" not in u.path
    if "youtube" in host:
        return path.startswith("@") and "/shorts/" not in u.path and "watch" not in path
    if "instagram" in host:
        return bool(path) and "/" not in path and path not in ("reel", "reels", "p", "explore")
    return False


def _profile_videos(url: str) -> list[str]:
    """The latest public videos of a creator profile (no login)."""
    try:
        import yt_dlp  # type: ignore
        if "youtube" in url and not url.rstrip("/").endswith("/shorts"):
            url = url.rstrip("/") + "/shorts"
        with yt_dlp.YoutubeDL({"extract_flat": "in_playlist", "playlistend": 6, "quiet": True, "no_warnings": True,
                               "logger": _Quiet(), "socket_timeout": 15, "retries": 1, "extractor_retries": 1}) as ydl:
            info = ydl.extract_info(url, download=False) or {}
        out = []
        for e in info.get("entries") or []:
            link = e.get("url") or e.get("webpage_url")
            if link and link.startswith("http"):
                out.append(link)
        return out[:5]
    except Exception as e:
        util.log(f"profile expand failed {url}: {e}")
        return []


class _Quiet:
    def debug(self, m): pass
    def info(self, m): pass
    def warning(self, m): pass
    def error(self, m): util.log(f"yt-dlp: {m[:300]}")


def _remove(rid: str) -> None:
    d = _ref_dir(rid)
    if d.exists():
        ref = load(rid)
        ref["removed"] = True
        save(ref)
        if ref.get('project'):
            from . import videos
            videos.update(ref['project'],lambda c:c.pop('reference_style',None))
            inputs=videos._dir(ref['project'])/'style-inputs.json'
            if inputs.exists():
                doc=util.read_json(inputs);doc.pop('reference',None);util.write_json(inputs,doc)


def retry(rid: str) -> dict:
    ref = load(rid)
    if ref["status"] != "error" and not (ref["status"] == "done" and (ref.get('cover_only') or ref.get('study_error'))):
        return ref
    ref.update(status="queued", message="", study_error="", cover_only=False)
    save(ref)
    _start_analysis(ref)
    return ref


def _short_name(u) -> str:
    host = (u.hostname or "").replace("www.", "")
    path = u.path.strip("/")
    return f"{host}/{path}"[:48] if path else host


def _set(ref: dict, **kw) -> None:
    ref.update(kw)
    save(ref)


def analyse(rid: str, report=None) -> dict:
    """Fetch (links) and study one reference frame by frame. `report(message, progress 0-1)`."""
    report = report or (lambda m, p: None)
    r = load(rid)
    src: Path
    if r["kind"] == "url":
        _set(r, status="fetching", message="Fetching the video…")
        report("Fetching the video…", 0.05)
        src, _cover_only = fetch(r, report)
        r = load(rid)   # fetch() recorded the method, title and cover_only
    else:
        src = util.ROOT / r["file"]
    _set(r, status="analysing", message="Analysing…", study_error="", scan_started=time.time(), progress=0.3)

    def measured(msg,fraction):
        fraction=max(float(r.get('progress') or 0),fraction)
        elapsed=max(0,time.time()-float(r.get('scan_started') or time.time()))
        eta=elapsed*(1-fraction)/fraction if elapsed>2 and 0<fraction<1 else None
        _set(r,message=msg,progress=fraction,estimated_remaining_seconds=eta)
        report(msg,fraction)

    def prog(msg, p):
        measured(msg,0.3+0.3*p)

    def prog2(msg, p):
        measured(msg,0.6+0.38*p)

    try:
        from . import motion
        full_study=src.suffix.lower() in util.VIDEO_EXT and motion.vision_ready()
        m = _measure_process(rid,src,prog,with_speech=jobs.model_ready(),basic=full_study)
        if m.get("kind") == "video":
            if full_study:
                err = _study_process(rid, src, prog2)
                if err:                              # the quick measurements still stand; the agent is told
                    util.log(f"study failed for {rid}: {err}")
                    _set(load(rid), study_error=err[:300])
                    # Keep the complete legacy visual measurements if the
                    # higher-resolution study genuinely could not finish.
                    m = _measure_process(rid,src,prog,with_speech=jobs.model_ready(),basic=False)
    finally:
        if r["kind"] == "url":   # the download folder is temporary; the video itself is kept in the reference's folder
            try:
                if src.exists() and src.suffix.lower() in util.VIDEO_EXT:
                    shutil.copy2(src, _ref_dir(rid) / f"video{src.suffix.lower()}")
            except OSError:
                pass
            shutil.rmtree(src.parent, ignore_errors=True)
    thumb = next(iter(sorted((_ref_dir(rid) / "frames").glob("[0-9][0-9].jpg"))), None)
    r=load(rid)  # Keep fetch and deep-study errors written while analysis ran.
    _set(r, status="done", message="Reference scanned ✓", progress=1.0, summary=dict(_summary(m), cover_only=bool(r.get("cover_only")), method=r.get("method", "")),
         thumb=util.rel(thumb) if thumb else "", analysed_with=ANALYSIS_VERSION)
    return r


ANALYSIS_VERSION = 3


def _analysis_pulse(rid,process):
    """Actual child liveness keeps a slow model stage distinct from a dead scan."""
    last=[0.]
    def pulse():
        import time
        now=time.time()
        if now-last[0]>=10 and process.poll() is None:
            last[0]=now
            try:
                row=load(rid)
                if not row.get('removed') and row.get('status') in ('fetching','analysing'):_set(row,heartbeat=now)
            except (util.Fail,OSError):pass
    return pulse

def _measure_process(rid,src,report,with_speech=False,basic=False):
    import subprocess,sys
    command=[sys.executable,str(util.ROOT/'edit.py'),'measure-ref',rid,'--src',str(src)]
    if with_speech:command.append('--with-speech')
    if basic:command.append('--basic')
    proc=util.spawn(command,cwd=util.ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    tail=[]
    for line in util.progress_lines(proc,timeout=3600,idle_timeout=3600,on_tick=_analysis_pulse(rid,proc)):
        if line.startswith('PROGRESS '):
            try:_,fraction,message=line.rstrip().split(' ',2);report(message,float(fraction))
            except ValueError:continue
        else:tail=(tail+[line.rstrip()])[-8:]
    if proc.returncode!=0:raise util.Fail('The reference scan stopped. Retry it or upload the video file directly.',' | '.join(tail)[-600:])
    result=util.read_json(_ref_dir(rid)/'measurements.json',default={})
    if not isinstance(result,dict) or result.get('kind') not in ('image','video'):raise util.Fail('The reference scan did not produce valid measurements. Retry it.')
    return result


def reconcile_interrupted():
    """Repair display state only; never restart or repeat an unapproved operation."""
    repaired=[]
    for file in teach.REFS.glob('*/ref.json'):
        try:
            with util.file_guard(file.parent/'.reference-save.guard',timeout=.1):
                ref=util.read_json(file,default={})
                if ref.get('removed') or ref.get('status') not in ('queued','fetching','analysing'):continue
                active=jobs.find('reference',ref.get('id',''),states=('queued','waiting','running'))
                if active:continue
                ref.update(status='error',interrupted=True,updated=time.time(),message='This scan was interrupted. Retry it or upload the reference video file.')
                util.write_json(file,ref);repaired.append(ref['id'])
        except (OSError,util.Fail,KeyError):continue
    if repaired:util.log('Recovered interrupted reference scans: '+', '.join(repaired))
    return repaired


def _study_process(rid: str, src: Path, report) -> str:
    """Run the full study in its own process: Apple's word-level text recognition only works on a main thread,
    and the Studio runs analyses in background threads. Progress comes back as 'PROGRESS <0-1> <message>' lines."""
    import subprocess
    import sys
    cmd = [sys.executable, str(util.ROOT / "edit.py"), "study-ref", rid, "--src", str(src)]
    budget=max(900,min(7200,float(util.probe(src).get("duration",0))*20+300))
    proc = util.spawn(cmd, cwd=util.ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    tail = []
    for line in util.progress_lines(proc, timeout=budget, idle_timeout=budget,on_tick=_analysis_pulse(rid,proc)):
        if line.startswith("PROGRESS "):
            _, frac, msg = line.rstrip("\n").split(" ", 2)
            report(msg, float(frac))
        else:
            tail = (tail + [line.rstrip()])[-8:]
    proc.wait()
    if proc.returncode != 0 or not (_ref_dir(rid) / "kit.json").exists():
        return " | ".join(t for t in tail if t) or "study failed"
    kit = util.read_json(_ref_dir(rid) / "kit.json")
    if kit.get("study_complete") is False:return "The full reference study was incomplete; using the complete fallback measurements."
    return "" if kit.get("styles") else "no text styles found"


def _start_analysis(ref: dict) -> None:
    def guarded(jid):
        r = load(ref["id"])
        _set(r, job=jid)
        try:
            analyse(ref["id"], lambda msg, p: jobs.update(jid, message=msg, progress=round(p, 3)))
            return {"ref": ref["id"]}
        except util.ProgressTimeout as e:
            util.log(f"Reference scan deadline for {ref['id']}: {e.message}")
            notice = "This reference could not be read. Download it and drop the video file here instead."
            _set(load(ref["id"]), status="error", message=notice, estimated_remaining_seconds=None)
            raise util.Fail(notice) from e
        except util.Fail as e:
            r = load(ref["id"])
            _set(r, status="error", message=e.message)
            raise
        except Exception:
            util.log_exception('reference analysis')
            _set(load(ref['id']), status='error', message='Reference analysis failed. Retry it or add the video file directly.')
            raise

    jobs.submit("reference", guarded, key=ref["id"], label=ref.get("name", ""), heavy=False, needs="tools", resource="network")


def restudy_preset(sid: str, report=None) -> str:
    """Study a preset's references again with the current analysis and rebuild it (same name, same id)."""
    data = util.read_json(util.USER_STYLES_DIR / f"{sid}.json")
    ids = [x["id"] for x in data.get("references", []) if x.get("id")]
    if not ids and teach.REFS.exists():
        seen = set()
        for f in sorted(teach.REFS.glob("*/ref.json"), key=lambda f: f.stat().st_mtime, reverse=True):
            r = util.read_json(f, default={})
            key = r.get("url") or r.get("file")
            if r.get("used_by") == sid and key not in seen:
                seen.add(key)
                ids.append(r["id"])
    if not ids:
        raise util.Fail("This preset has no references left to study.")
    for i in ids:
        for name in ('measurements-cache.json','study-cache.json'):
            (_ref_dir(i)/name).unlink(missing_ok=True)
        analyse(i, report)
    done = [load(i) for i in ids if load(i)["status"] == "done"]
    build_style(sid, data.get("name", sid), done, data.get("description", ""), hidden=bool(data.get("hidden")))
    return sid


def _summary(m: dict) -> dict:
    s = {"kind": m["kind"]}
    if m.get("cuts_per_minute") is not None:
        s["cuts_per_minute"] = m["cuts_per_minute"]
    if m.get("speech"):
        s["wpm"] = m["speech"]["wpm"]
    if m.get("duration"):
        s["duration"] = m["duration"]
    s["vivid"] = m["colour"]["vivid"][:3]
    return s


# ------------------------------------------------------------------ fetch ----
def fetch(ref: dict, report) -> tuple[Path, bool]:
    """Download a linked video through the free fallback chain in linkfetch.py. Returns (file, cover_only)."""
    from . import linkfetch
    out = DOWNLOADS / ref["id"]

    def say(msg, frac):
        report(msg, round(frac, 3))
        r = load(ref["id"])
        _set(r, message=msg, progress=frac)

    res = linkfetch.fetch(ref["url"], out, say)
    r = load(ref["id"])
    _set(r, method=res.method, cover_only=res.partial, **({"title": res.title[:80]} if res.title else {}))
    return res.path, res.partial


# ------------------------------------------------------------------ learn ----
def build_style(name: str, label: str, done: list[dict], note: str = "", hidden: bool = False) -> str:
    """Turn analysed references into a style: settings, edit spec, Claude skill and the reference's own frames.
    `hidden` styles belong to one video (its reference, not saved as a preset) and never show as presets."""
    res = teach.aggregate(name, [_ref_dir(r["id"]) for r in done])
    style = teach.draft_style(res, name, label)
    if note:
        style["description"] = note
    if hidden:
        style["hidden"] = True
    style["references"] = [{"id": r["id"], "url": r.get("url", ""), "title": r.get("title") or r.get("name", "")} for r in done]
    kits = [(r["id"], util.read_json(_ref_dir(r["id"]) / "kit.json", default=None)) for r in done]
    kits = [(i, k) for i, k in kits if k and k.get("styles")]
    if kits:                                            # the measured style kit the planner and composer copy
        style["kit"] = dict(kits[0][1], reference=kits[0][0])
        prev = util.read_json(util.USER_STYLES_DIR / f"{name}.json", default={})
        # a blueprint the agent refined from the dense frames is kept; otherwise the measured one
        style["blueprint"] = prev["blueprint"] if (prev.get("blueprint") and not prev["blueprint"].get("auto")) else (kits[0][1] or {}).get("blueprint", {})
    out = util.USER_STYLES_DIR / f"{name}.json"
    teach.keep_history(name)
    util.write_json(out, style)
    from . import dna, presets
    (util.USER_STYLES_DIR / f"{name}.md").write_text(dna.rulebook(res, style, name), encoding="utf-8")
    presets.write_skill(name)
    # the preset's picture is the reference itself: its real frames, never a drawn placeholder
    fdir = util.USER_STYLES_DIR / f"{name}.frames"
    if fdir.exists():
        shutil.rmtree(fdir)
    fdir.mkdir(parents=True)
    k = 0
    for r in done:
        for f in sorted((_ref_dir(r["id"]) / "frames").glob("[0-9][0-9].jpg")):
            if k < 12:
                shutil.copy2(f, fdir / f"{k:02d}.jpg")
                k += 1
    summary = teach.reveal(res, style)
    util.write_json(teach.TEACH / name / "reveal.json", summary)
    util.write_json(teach.TEACH / name / "readout.json", readout([measurements(r["id"]) for r in done]))
    for reference in done:
        fresh=load(reference['id']);_set(fresh,saved_style_name=label if not hidden else name)
    if not hidden:
        for r in done:                                   # these references now belong to this preset
            r2 = load(r["id"])
            r2["used_by"] = name
            save(r2)
    events.emit("teach.ready", {"style": name, "label": label, "hidden": hidden, "measurements": res["contact_sheet"].replace(
        "contact-sheet.jpg", "measurements.json"), "contact_sheet": res["contact_sheet"],
        "style_file": util.rel(out), "references": len(done)}, source="server")
    return name


def _video_style_from_refs(pid: str, mine: list[dict]) -> None:
    """The video copies its references: a preset saved from them, else its own unlisted style built from them."""
    from . import videos
    cfg = videos.load(pid)
    ids = {r["id"] for r in mine}
    current=cfg.get('reference_style') or cfg.get('style')
    cur = util.read_json(util.USER_STYLES_DIR / f"{current}.json", default={}) if current else {}
    if ids != {x.get("id") for x in cur.get("references", [])}:
        sid = f"ref-{pid}"[:60]
        build_style(sid, cfg.get("title") or "Reference", mine, hidden=True)
        # Reference analysis is a separate layer. It must not erase the named preset or its feedback scope.
        videos.update(pid,lambda c:c.update(reference_style=sid))


def production_inputs(pid: str) -> dict:
    """Content-bind every attached scan; partial or failed scans cannot become a generic edit.

    This is a production barrier, not a timer or a simulated successful scan.
    Preparation can run while scanning; composition must wait for complete data.
    """
    from .workflow import digest
    out = {}
    for ref in for_project(pid):
        rid = ref['id']
        if ref.get('status') != 'done' or ref.get('study_error') or ref.get('cover_only'):
            raise util.Fail('The reference scan is not ready. Retry it or download and upload the reference video file before finishing this edit.')
        for name in ('kit.json', 'measurements.json'):
            file = _ref_dir(rid) / name
            if not file.is_file() or not isinstance(util.read_json(file), dict):
                raise util.Fail('The reference scan is incomplete. Retry the scan before finishing this edit.')
            out[rid + '/' + name] = digest(file)
    return out


def apply_to_video(pid: str) -> bool:
    """Called when the creator presses Create. Returns True when a reference is still being analysed: the edit
    starts anyway and the reference style is applied by a background job the moment the analysis finishes."""
    mine = for_project(pid)
    if not mine:
        return False
    if all(r["status"] == "done" and not r.get('cover_only') and not r.get('study_error') for r in mine):
        _video_style_from_refs(pid, mine)
        return False

    def work(jid):
        deadline = time.time() + 1200
        while time.time() < deadline:
            rs = for_project(pid)
            if any(r.get('status')=='error' or r.get('study_error') or r.get('cover_only') for r in rs):
                raise util.Fail('A reference could not be scanned. Download it and upload the video file, or retry the scan. No substitute style was applied.')
            busy = [r for r in rs if r["status"] != "done"]
            if not busy:
                break
            jobs.update(jid, message="Studying your reference…", progress=min(0.95, sum(r.get("progress", 0) for r in rs) / max(1, len(rs))))
            time.sleep(1.5)
        rs = for_project(pid)
        if not rs or any(r.get('status')!='done' or r.get('study_error') or r.get('cover_only') for r in rs):
            raise util.Fail("The reference did not finish analysing.", "Check its error or retry the reference; no substitute style was applied.")
        _video_style_from_refs(pid, rs)
        from . import videos
        events.emit("reference.ready", {"project": pid, "style": videos.load(pid).get("style")}, source="server")
        return {"project": pid}

    jobs.submit("ref-style", work, key=pid, label="Studying your reference", heavy=False)
    return True


def unique_id(name: str) -> str:
    name = util.slugify(name or "preset")
    base, n = name, 2
    while (util.USER_STYLES_DIR / f"{name}.json").exists():
        name, n = f"{base}-{n}", n + 1
    return name


def learn(name: str = "preset", label: str = "", ref_ids: list[str] | None = None, note: str = "",
          project: str | None = None) -> dict:
    """Save analysed references as a preset (a job: it waits for references still being analysed)."""
    label = (label or "").strip()[:40] or "Preset"
    name = unique_id(name or label)

    def work(jid):
        deadline = time.time() + 900
        while time.time() < deadline:
            rs = [load(i) for i in ref_ids] if ref_ids else [r for r in all_refs() if not r.get("used_by")]
            busy = [r for r in rs if r["status"] in ("queued", "fetching", "analysing")]
            if not busy:
                break
            jobs.update(jid, message=f"Finishing the analysis of {len(busy)} reference{'s' if len(busy) > 1 else ''}…", progress=0.1)
            time.sleep(1.5)
        done = [r for r in rs if r["status"] == "done"]
        if not done:
            raise util.Fail("None of the references could be analysed.", "Add the video again or try another one.")
        jobs.update(jid, message="Saving the preset…", progress=0.6)
        build_style(name, label, done, note)

        def remember(prof):
            prof.setdefault("learned_styles", [])
            if name not in prof["learned_styles"]:
                prof["learned_styles"].append(name)
            if not project:
                prof["style"] = name
        util.update_profile(remember)
        if project:
            from . import videos
            videos.set_brief(project, {"style": name})
        return {"style": name}

    return jobs.submit("learn", work, key=name, label=label, needs="tools")


# --------------------------------------------------------------- readout ----
def readout(ms: list[dict]) -> list[dict]:
    """What the analysis really found, for the Studio's "Reference analyzed" panel. Only measured values:
    a row is left out when it wasn't measured. Each row: label, value (text), bar (0-1, how much of the scale),
    optional swatches / font. Several references → medians."""
    import statistics as stx
    from . import styles as st
    vids = [m for m in ms if m and m.get("kind") == "video"]
    if not vids:
        return []

    def med(get):
        vals = []
        for m in vids:
            try:
                v = get(m)
            except (KeyError, TypeError, IndexError):
                v = None
            if v is not None:
                vals.append(v)
        return stx.median(vals) if vals else None

    def first(get):
        for m in vids:
            try:
                v = get(m)
            except (KeyError, TypeError, IndexError):
                v = None
            if v:
                return v
        return None

    rows: list[dict] = []
    add = lambda group, label, value, bar=None, **kw: rows.append({"group": group, "label": label, "value": value,
                                                                   "bar": None if bar is None else round(max(0.03, min(1.0, bar)), 3), **kw})
    font = first(lambda m: m["deep"]["captions"]["font_match"][0])
    if font:
        f = st.FONTS.get(font["key"], {})
        add("Captions", "Font", font["label"], font=font["key"], font_file=f.get("file", ""))
    acc = first(lambda m: m["deep"]["captions"]["accent"])
    if acc and acc.get("font_match"):
        k = acc["font_match"][0]["key"]
        if acc.get("italic") and not st.FONTS.get(k, {}).get("italic"):
            k = next((x["key"] for x in acc["font_match"] if st.FONTS.get(x["key"], {}).get("italic")), "instrument-serif-italic")
        f = st.FONTS.get(k, {})
        add("Captions", "Accent words", (f.get("label") or f.get("ass") or k) + (" italic" if acc.get("italic") and "talic" not in (f.get("label") or "") else ""),
            font=k, font_file=f.get("file", ""))
    up = first(lambda m: (m["deep"]["captions"] or {}).get("uppercase") is not None and ("UPPERCASE" if m["deep"]["captions"]["uppercase"] else "lowercase"))
    if up:
        add("Captions", "Case", up)
    wpc = med(lambda m: m["deep"]["captions"]["words_per_caption"])
    if wpc:
        add("Captions", "Words on screen", f"{round(wpc)} at a time", wpc / 6)
    ch = med(lambda m: m["replica"]["captions"]["cap_height"])
    if ch:
        big = med(lambda m: m["replica"]["captions"].get("cap_height_big"))
        add("Captions", "Letter size", f"{ch * 100:.1f}% of frame height" + (f" · key lines up to {big * 100:.1f}%" if big and big > ch * 1.5 else ""), ch / 0.08)
    y = med(lambda m: m["replica"]["captions"]["y"])
    if y:
        where = "upper third" if y < 0.36 else "centre" if y < 0.6 else "lower third"
        add("Captions", "Position", f"{round(y * 100)}% down · {where}", y)
    rc = first(lambda m: m["replica"]["captions"]) or {}
    named = [("fill", rc.get("fill")), ("highlight", rc.get("highlight"))]
    if rc.get("outline") and (rc.get("outline_rel") or 0) > 0.02:
        named.append(("outline", rc["outline"]))
    named = [(n, c) for n, c in named if c]
    if named:
        add("Captions", "Colours", " · ".join(f"{n} {c}" for n, c in named), swatches=[c for _, c in named])
    anim = first(lambda m: m["deep"]["captions"]["animation"])
    pop = first(lambda m: m["replica"]["pop"])
    if anim:
        txt = {"pop": "Pop in", "slide": "Slide in", "cut": "Straight cut"}.get(anim, anim)
        if anim != "cut" and pop and pop.get("animated") and pop.get("in_ms"):
            txt += f" · {pop['in_ms']} ms"
        add("Captions", "Entry", txt)
    lead = med(lambda m: m["replica"]["lead_ms"])
    if lead is not None:
        add("Captions", "Timing", f"{abs(int(lead))} ms {'before' if lead > 0 else 'after'} the word")

    cpm = med(lambda m: m["cuts_per_minute"])
    if cpm is not None:
        add("Pacing", "Cuts", f"{round(cpm)} per minute", cpm / 60)
    shot = med(lambda m: m["avg_shot_seconds"])
    if shot:
        add("Pacing", "Average shot", f"{shot:.1f} s", 1 - min(1, shot / 8))
    wpm = med(lambda m: m["speech"]["wpm"])
    if wpm:
        add("Pacing", "Talking speed", f"{round(wpm)} words per minute", wpm / 260)
    sil = med(lambda m: m["silence_ratio"])
    if sil is not None:
        add("Pacing", "Pauses left in", f"{round(sil * 100)}%", sil / 0.3)
    pin = med(lambda m: m["deep"]["zoom"]["punch_ins_per_min"])
    amt = med(lambda m: m["deep"]["zoom"]["punch_in"])
    if pin is not None:
        add("Pacing", "Punch-in zooms", f"{pin:g} per minute" + (f" · +{round((amt - 1) * 100)}%" if amt else ""), pin / 20)
    tr = first(lambda m: m["replica"]["transitions"])
    if tr:
        total = sum(tr.values())
        add("Pacing", "Transitions", " · ".join(f"{round(v / total * 100)}% {k}" for k, v in sorted(tr.items(), key=lambda x: -x[1])))

    bpm_ = med(lambda m: m["deep"]["broll"]["per_minute"])
    if bpm_ is not None:
        sec = med(lambda m: m["deep"]["broll"]["avg_seconds"])
        add("Visuals", "B-roll", f"{bpm_:g} per minute" + (f" · {sec:g} s each" if sec else ""), bpm_ / 12)
    th = med(lambda m: m["deep"]["broll"]["talking_head_share"])
    if th is not None:
        add("Visuals", "On camera", f"{round(th * 100)}% of the time", th)
    gpm = med(lambda m: m["graphics_per_minute"])
    if gpm is not None:
        add("Visuals", "On-screen graphics", f"{gpm:g} per minute", gpm / 20)
    viv = first(lambda m: m["colour"]["vivid"])
    if viv:
        add("Visuals", "Colour", ", ".join(viv[:3]), swatches=viv[:4])

    music = first(lambda m: m["audio"] and {"on": m["audio"]["music"]})
    if music is not None:
        tempo = med(lambda m: m["deep"]["tempo_bpm"])
        add("Sound", "Music", ("Yes" + (f" · {round(tempo)} bpm" if tempo else "")) if music["on"] else "No music")
    sfx = med(lambda m: m["audio"]["sfx_per_minute"])
    if sfx is not None:
        add("Sound", "Sound effects", f"{round(sfx)} per minute", sfx / 40)
    lufs = med(lambda m: m["deep"]["loudness_lufs"])
    if lufs is not None:
        add("Sound", "Loudness", f"{lufs:g} LUFS")
    hook = first(lambda m: m["deep"]["structure"]["hook"])
    if hook:
        hs = med(lambda m: m["deep"]["structure"]["hook_seconds"])
        add("Structure", "Hook", f"“{hook[:90]}”" + (f" · {hs:.1f} s" if hs else ""))
    cta = first(lambda m: m["deep"]["structure"]["cta"])
    if cta:
        add("Structure", "Ending", f"“{cta[:90]}”")
    return rows


def measurements(rid: str) -> dict:
    return util.read_json(_ref_dir(rid) / "measurements.json", default={})

def add_file(path, project=None):
    from .editor import protect_inputs
    return protect_inputs(lambda pid: _add_file(path,pid))(project)

def add_url(url, project=None):
    from .editor import protect_inputs
    return protect_inputs(lambda pid: _add_url(url,pid))(project)

def remove(rid):
    from .editor import protect_inputs
    ref=load(rid)
    return protect_inputs(lambda pid: _remove(rid))(ref.get('project'))
