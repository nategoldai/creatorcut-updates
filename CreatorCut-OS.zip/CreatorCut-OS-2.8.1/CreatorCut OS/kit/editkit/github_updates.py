"""One public GitHub file, no publisher manifest or release workflow required.

The configured owner/repository is the publisher trust boundary. Blob identity is
verified before reading the embedded version and full SHA-256 file manifest.
No credentials are used. Merely detecting a new package never installs it.
"""
from __future__ import annotations
import hashlib
import http.client
import urllib.error
import json
import os
import re
import tempfile
import time
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path
from . import util

MAX_ZIP = 100 * 1024 * 1024
MAX_EXPANDED = 512 * 1024 * 1024
MAX_DOWNLOAD_SECONDS = 600


def _metadata(repo, path):
    from .linkfetch import _get
    url = 'https://api.github.com/repos/' + repo + '/contents/' + urllib.parse.quote(path, safe='/')
    return json.loads(_get(url, timeout=15, headers={'Accept':'application/vnd.github.object+json','Cache-Control':'no-cache'}))


def _download(url, destination, size):
    started = time.monotonic()
    parsed=urllib.parse.urlsplit(url)
    blob_api=parsed.scheme=='https' and parsed.hostname=='api.github.com' and bool(re.fullmatch(r'/repos/[A-Za-z0-9_-]+/[A-Za-z0-9_.-]+/git/blobs/[a-f0-9]{40}',parsed.path))
    if not blob_api and not (parsed.scheme=='https' and parsed.hostname=='raw.githubusercontent.com'):
        raise util.Fail('Unexpected update download destination.')
    req = urllib.request.Request(url, headers={'User-Agent':'CreatorCut-Updates','Accept':'application/vnd.github.raw+json' if blob_api else 'application/octet-stream','Cache-Control':'no-cache'})
    with urllib.request.urlopen(req, timeout=15) as response, destination.open('wb') as out:
        final=urllib.parse.urlsplit(response.geturl())
        if final.scheme!='https' or final.hostname != parsed.hostname or (blob_api and final.path!=parsed.path):
            raise util.Fail('Unexpected update download destination.')
        received = 0
        while True:
            chunk = response.read(256 * 1024)
            if not chunk: break
            received += len(chunk)
            if received > MAX_ZIP or received > size or time.monotonic() - started > MAX_DOWNLOAD_SECONDS:
                raise util.Fail('Update download exceeded its limit.')
            out.write(chunk)
    if received != size:
        raise util.Fail('Update download was incomplete.')


def _digest(path, algorithm='sha256', git_blob=False):
    h = hashlib.new(algorithm)
    if git_blob: h.update(('blob '+str(path.stat().st_size)+'\0').encode())
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(256*1024), b''): h.update(chunk)
    return h.hexdigest()


def _inspect_archive(path):
    from .updater import _safe_rel, _newer
    with zipfile.ZipFile(path) as archive:
        entries = archive.infolist()
        names = [e.filename for e in entries]
        if len(entries)>10000 or len(names)!=len(set(names)) or sum(e.file_size for e in entries)>MAX_EXPANDED:
            raise util.Fail('The update archive is invalid or too large.')
        for item in entries:
            _safe_rel(item.filename)
            if (item.external_attr >> 16) & 0o170000 == 0o120000:
                raise util.Fail('The update contains a symbolic link.')
        roots = [n[:-len('edit.py')] for n in names if n.endswith('/edit.py') and n[:-len('edit.py')]+'kit/editkit/__init__.py' in names]
        if len(roots)!=1: raise util.Fail('Expected one CreatorCut app in the update.')
        prefix = roots[0]
        manifest_name = prefix+'kit/SHA256-MANIFEST.json'
        if manifest_name not in names: raise util.Fail('Update verification manifest is missing.')
        if archive.getinfo(manifest_name).file_size>2*1024*1024:
            raise util.Fail('Invalid update verification manifest.')
        hashes = json.loads(archive.read(manifest_name))
        if not isinstance(hashes,dict): raise util.Fail('Invalid update verification manifest.')
        app_files = {n[len(prefix):] for n in names if n.startswith(prefix) and not n.endswith('/')}
        if app_files != set(hashes) | {'kit/SHA256-MANIFEST.json'}:
            raise util.Fail('The update contains unverified files.')
        for rel, expected in hashes.items():
            _safe_rel(rel)
            if not isinstance(expected,str) or not re.fullmatch('[a-f0-9]{64}',expected):
                raise util.Fail('Invalid update file checksum.')
            h=hashlib.sha256()
            with archive.open(prefix+rel) as stream:
                for chunk in iter(lambda: stream.read(256*1024),b''): h.update(chunk)
            if h.hexdigest()!=expected: raise util.Fail('Update file verification failed.')
        version = archive.read(prefix+'kit/VERSION').decode().strip()
        _newer(version, '0.0.0')  # Validate, never infer a version from a filename.
        return version


def _transient(error):
    if isinstance(error,urllib.error.HTTPError):return error.code in (408,429,500,502,503,504)
    return isinstance(error,(urllib.error.URLError,TimeoutError,ConnectionError,http.client.IncompleteRead))

def _cached_release(cache,repo,path):
    previous=util.read_json(cache/'verified.json',default={})
    blob=previous.get('blob','');sha=previous.get('sha256','')
    if previous.get('repository')!=repo or previous.get('path')!=path or not re.fullmatch('[a-f0-9]{40}',str(blob)) or not re.fullmatch('[a-f0-9]{64}',str(sha)):return None
    package=cache/(blob+'.zip')
    if not package.is_file() or not 0<package.stat().st_size<=MAX_ZIP or _digest(package)!=sha:return None
    from .updater import _newer
    _newer(previous.get('version',''),'0.0.0')
    return {'latest':previous['version'],'zip':str(package),'sha256':sha,'cached_offline':True,'notes':'Your previously verified update is ready. Your videos and presets stay saved.'}

def inspect(config):
    repo = str(config.get('github_repository','')).strip()
    repo = repo.removeprefix('https://github.com/').removesuffix('/').removesuffix('.git')
    if not re.fullmatch(r'[A-Za-z0-9_-]+/[A-Za-z0-9_.-]+',repo):
        raise util.Fail('The publisher repository address is invalid.')
    path = str(config.get('github_path','CreatorCut-OS.zip'))
    from .updater import _safe_rel
    _safe_rel(path)
    if not path.lower().endswith('.zip'): raise util.Fail('Expected an update ZIP.')
    cache = util.STUDIO_OUT / 'github-updates'
    cache.mkdir(parents=True,exist_ok=True)
    with util.file_guard(cache/'.check.guard', 'Waiting for the current update check.',timeout=660):
        try:metadata = _metadata(repo,path)
        except Exception as error:
            cached=_cached_release(cache,repo,path) if _transient(error) else None
            if cached:return cached
            raise
        size, blob = metadata.get('size'), metadata.get('sha','')
        if metadata.get('type')!='file' or metadata.get('path')!=path or not isinstance(size,int) or isinstance(size,bool) or not 0<size<=MAX_ZIP or not re.fullmatch('[a-f0-9]{40}',str(blob)):
            raise util.Fail('Invalid GitHub update file.')
        url = str(metadata.get('download_url',''))
        parsed=urllib.parse.urlsplit(url)
        if parsed.scheme!='https' or parsed.hostname!='raw.githubusercontent.com' or not parsed.path.startswith('/'+repo+'/'):
            raise util.Fail('Unexpected GitHub update download address.')
        package=cache/(blob+'.zip')
        record=cache/'verified.json'
        previous=util.read_json(record,default={})
        sha = _digest(package) if package.is_file() and package.stat().st_size==size else ''
        same = previous.get('blob')==blob and previous.get('repository')==repo and previous.get('path')==path and sha==previous.get('sha256')
        if same:
            return {'latest':previous['version'],'zip':str(package),'sha256':sha,'notes':'A new CreatorCut version is ready. Your videos, presets and editing preferences stay saved.'}
        fd, name = tempfile.mkstemp(prefix='download-',suffix='.zip',dir=cache);os.close(fd)
        temporary=Path(name)
        try:
            # A changing branch's CDN can still return the previous ZIP after
            # metadata advances. Fetch the immutable object identified above.
            for attempt in range(3):
                try:
                    _download('https://api.github.com/repos/'+repo+'/git/blobs/'+blob,temporary,size)
                    break
                except Exception as error:
                    if not _transient(error) or attempt==2:raise
                    time.sleep(.5*(attempt+1))
            if _digest(temporary,'sha1',True)!=blob: raise util.Fail('GitHub update file changed during download. Try again.')
            version=_inspect_archive(temporary)
            sha=_digest(temporary)
            os.replace(temporary,package)
            util.write_json(record,{'repository':repo,'path':path,'blob':blob,'sha256':sha,'version':version})
            # Only verified cache files are pruned; never app/project data.
            for old in cache.glob('*.zip'):
                if old!=package:old.unlink(missing_ok=True)
            return {'latest':version,'zip':str(package),'sha256':sha,'notes':'A new CreatorCut version is ready. Your videos, presets and editing preferences stay saved.'}
        finally:
            temporary.unlink(missing_ok=True)
