"""CreatorCut OS command line. Agents (Claude Code / Codex) call these; people never have to."""
from __future__ import annotations

import argparse
import time
import datetime as dt
import json
import os
import re
import shutil
import sys
from pathlib import Path

from . import util


def _project(name: str | None) -> Path:
    bound=os.environ.get('CREATORCUT_PROJECT')
    if bound:
        if name and name!=bound:raise util.Fail('This editor is assigned to another video. Use its exact project id.')
        name=bound
    elif os.environ.get('CREATORCUT_MANAGED_EDITOR')=='1' and not name:
        raise util.Fail('A managed edit requires its exact project id; no other video was selected.')
    if not name:
        raise util.Fail("Choose the exact video project for this command.", "Use the project ID shown in Studio; another video's most recent project is never selected automatically.")
    p=util.project_dir(name)
    from . import editor
    job=editor.read(name)
    if job.get('execution_mode')=='chat' and job.get('cancel'):
        raise util.Fail('This native edit was stopped. Your saved work is kept; do not run further editing commands.')
    return p


def cmd_new(a):
    from . import platforms
    video = Path(a.video) if a.video else util.newest_raw_video()
    if video is None:
        raise util.Fail("There's no video in my-videos/raw yet.",
                        "Drag your clip into the my-videos/raw folder (any MP4/MOV from your phone is fine), then try again.")
    if not video.is_absolute():
        video = (Path.cwd() / video) if (Path.cwd() / video).exists() else (util.ROOT / video)
    info = util.probe(video)
    prof = util.load_profile()
    name = util.slugify(a.name or video.stem)
    base, n = name, 2
    while (util.PROJECTS / name).exists() and not a.overwrite:
        name, n = f"{base}-{n}", n + 1
    p = util.PROJECTS / name
    if p.exists() and a.overwrite:
        shutil.rmtree(p)
    p.mkdir(parents=True)
    a.project = name
    from . import activity_store
    activity_store.update(project=name)
    util.write_json(p / "source.json", info)
    plat = platforms.get(a.platform or "vertical")       # every video vertical, safe on all three apps
    cfg = {"name": name, "created": dt.datetime.now().isoformat(timespec="seconds"), "source": video.name,
           "style": a.style or prof.get("style") or "creatorcut-signature", "platform": plat["key"], "grade": None,
           "music": prof.get("music", "auto"), "keywords": prof.get("keywords", []), "cta": prof.get("cta", ""),
           "captions": {}, "framing": {"fit": "cover", "x": 0.5, "y": 0.45}, "status": "new", "version": 0}
    util.write_json(p / "project.json", cfg)
    util.ok(f"New project '{name}' · {util.fmt_time(info['duration'])} · {info['width']}x{info['height']} · "
            f"style {cfg['style']} · {plat['label']}")
    if info["hdr"]:
        util.warn("Filmed in HDR (iPhone default). I'll convert the colours; for best results turn off HDR Video in camera settings.")
    print(f"PROJECT={name}")


def cmd_prepare(a):
    """A Studio video draft: join its raw clips into one source, ready for transcribe."""
    from . import videos
    p = _project(a.project)
    info = videos.prepare(p.name)
    if info.get('has_audio') is False:
        from . import transcribe
        transcribe.transcribe(p)  # Records a measured absence; no speech model is loaded.
    util.ok(f"Footage ready · {util.fmt_time(info['duration'])} · {info['width']}x{info['height']}")
    if info["hdr"]:
        util.warn("Filmed in HDR (iPhone default). I'll convert the colours.")
    print(f"PROJECT={p.name}")


def cmd_transcribe(a):
    from . import transcribe
    p = _project(a.project)
    if a.words:
        transcribe.import_words(p, Path(a.words))
    else:
        transcribe.transcribe(p, model_name=a.model, language=a.language)
    _status(p, "transcribed")


def cmd_plan(a):
    from . import plan
    p = _project(a.project)
    ranges=None
    if getattr(a,'ranges',None) is not None:
        import json
        try:ranges=json.loads(a.ranges)
        except (ValueError,TypeError):raise util.Fail('Visual ranges must be JSON objects with start and end times.')
        if not isinstance(ranges,list):raise util.Fail('Visual ranges must be a JSON list.')
    plan.make_plan(p, max_pause=a.max_pause, ranges=ranges)
    util.ok(f"Edit plan written: {util.rel(p / 'plan.md')}")
    print((p / "plan.md").read_text(encoding="utf-8"))
    _status(p, "planned")

def cmd_request_context(a):
    """Read only this project's saved request, required keys and local context."""
    import json
    from editor import director
    p=director.project(a.project) if a.project else director.current()
    print(json.dumps(director.read(p/'creator-request.json') if p else {},ensure_ascii=False))


def cmd_cut(a):
    from . import cut, plan
    p = _project(a.project)
    pl = util.read_json(p / "plan.json")
    if a.max_pause is not None:
        pl["settings"]["max_pause"] = a.max_pause
        util.write_json(p / "plan.json", pl)
    tr = util.read_json(p / "transcript.json")
    plan.write_plan_md(p, pl, tr["words"], tr.get("duration", 0))
    cut.cut(p)
    _status(p, "cut")


def cmd_beats(a):
    from . import director
    p = _project(a.project)
    if (p / "beats.json").exists() and not a.force:
        raise util.Fail("beats.json already exists; I won't overwrite your graphics plan.", 'Use --force to replace it with a new version.')
    d = director.draft_beats(p)
    util.ok(f"Drafted {len(d['beats'])} graphics in {util.rel(p / 'beats.json')}")
    print(json.dumps(d, indent=2, ensure_ascii=False))


def cmd_words(a):
    p = _project(a.project)
    wj = util.read_json(p / "words.json")
    line, out, t0 = [], [], None
    for i, w in enumerate(wj["words"]):
        if t0 is None:
            t0 = w["start"]
        line.append(f"{w['w']}")
        if len(line) >= 12 or w["w"][-1:] in ".!?":
            out.append(f"[{t0:6.2f}s] {' '.join(line)}")
            line, t0 = [], None
    if line:
        out.append(f"[{t0:6.2f}s] {' '.join(line)}")
    print(f"Cut timeline ({wj['duration']:.1f}s):\n" + "\n".join(out))


def cmd_check(a):
    from . import director, render, platforms, styles
    p = _project(a.project)
    cfg = util.read_json(p / "project.json")
    style = styles.for_project(cfg)
    plat = platforms.get(cfg.get("platform"))
    ctx, stats = render.build_overlay_ass(p, cfg, style, plat)
    director.retention(p)                          # writes retention.md
    util.ok(f"{stats['graphics']} graphics and {stats['captions']} caption events are valid")
    for w in ctx.warnings:
        util.warn(w)
    print((p / "retention.md").read_text(encoding="utf-8"))


def cmd_preview(a):
    return cmd_compose(a)


def _kit(p: Path) -> dict:
    """The style kit of this video's preset / reference (measured by `study`)."""
    from . import styles as st
    cfg = util.read_json(p / "project.json")
    path = st.style_path(cfg.get("style", ""))
    data = util.read_json(path) if path else {}
    if not data.get("kit"):
        raise util.Fail("This video's style has no measured kit yet.",
                        "Add a reference video in the Studio (it's studied automatically) or pick a preset saved from one.")
    return data["kit"]


def cmd_grade(a):
    """Prepare the exact Studio colour choice independently of caption/style choices."""
    from . import colour_choice
    p=_project(a.project);colour_choice.ensure_cut(p)
    util.ok('Original colour preserved.' if colour_choice.choice(util.read_json(p/'project.json'))=='natural' else 'The selected colour recipe is ready.')


def cmd_design(a):
    """Draft the whole edit plan (edit-plan.json) from the style kit: captions, sizes, placement, zooms."""
    from . import planner
    from . import blueprint, learn
    p = _project(a.project)
    try:
        kit = _kit(p)
        if not kit.get("styles"):
            raise util.Fail("Reference typography has not been measured yet.")
    except util.Fail:
        from . import platforms
        cv = platforms.get(util.read_json(p/'project.json').get('platform'))
        duration = util.read_json(p/'words.json')['duration']
        from . import signature
        scaffold = signature.seed(p, {'w':cv['width'],'h':cv['height'],'fps':cv['fps']}, duration)
        if (p/'edit-plan.json').exists() and not a.force:
            raise util.Fail('An edit plan already exists. Refine it rather than overwriting it.')
        util.write_json(p/'edit-plan.json',scaffold)
        util.ok('CreatorCut Signature starter ready. Apply the full brief/reference and review every scene before exporting.')
        return
    from . import signature
    signature.write_direction(p)
    kit = signature.complete_kit(kit)
    bp, sid = blueprint.for_project(p)
    learned = learn.adjustments(sid)
    cfg = util.read_json(p/'project.json')
    if cfg.get('brief', {}).get('references') or str(cfg.get('style','')).startswith('ref-'):
        # Current reference evidence wins over old numerical memory tweaks.
        # The editor still receives all rules to apply in genuinely unclear areas.
        learned = {}
    if bp:
        kit = dict(kit, blueprint=bp)
    plan = planner.draft(p, kit, hook=False)
    if (p / "graded.mp4").exists() and util.read_json(p / "project.json").get("look", "natural") != "natural":
        plan["background"]["src"] = "graded.mp4"
    if kit.get("behind_person"):                         # the reference puts text behind the person: the hook does too
        from . import person
        util.activity("Cutting you out for text behind you", 50)
        person.make_cutout(p / plan["background"]["src"], p / "cutout.webm")
        plan["person_cutout"] = {"src": "cutout.webm"}
        hook = next((i for i in plan["items"] if i.get("role") == "hook"), None)
        if hook and plan["_facts"].get("face"):
            hook["behind"] = True
            hook["y"] = planner.behind_y(p / "cut.mp4", plan["_facts"]["face"], plan["styles"]["hook"]["size"], len(hook["lines"]))
    f = p / "edit-plan.json"
    if f.exists() and not a.force:
        raise util.Fail("edit-plan.json already exists; I won't overwrite your edit.", 'Use --force for a new version.')
    # the reference's editing beyond text (blocks, B-roll cards, bursts, pieces) and what the creator taught us
    if bp:
        util.activity("Placing B-roll and graphics like the reference", 70)
        for n in blueprint.apply(p, plan, bp, learned)["notes"]:
            util.step(n)
    if plan.pop("_needs_cutout", False) and not plan.get("person_cutout"):
        from . import person
        util.activity("Cutting you out for graphics behind you", 80)
        person.make_cutout(p / plan["background"]["src"], p / "cutout.webm")
        plan["person_cutout"] = {"src": "cutout.webm"}
    plan.setdefault("_facts", {})["learned_rules"] = learn.rules(sid)
    if plan["_facts"]["learned_rules"]:
        util.step("Saved preferences to check against this request: " + "; ".join(plan["_facts"]["learned_rules"])[:300])
    for n, item in enumerate(plan.get('items', [])):
        item.setdefault('id', f'item-{n+1:03d}')
    plan.setdefault('audio', {'events': []})
    util.write_json(f, plan)
    caps = sum(1 for i in plan["items"] if i["type"] == "caption")
    util.ok(f"Drafted {caps} captions in the reference's styles ({', '.join(plan['styles'])}); edit plan: {util.rel(f)}")
    print("Next: add the creative layer from the reference's inventory (cards, notes, bursts, custom pieces), then `edit.py compose`.")


def cmd_compose(a):
    """Render an internal candidate; never publish an unreviewed version."""
    from . import render, workflow
    p = _project(a.project)
    with util.project_lock(p):
        from . import colour_choice
        colour_choice.prepare_plan(p)
        from . import render_controls
        render_controls.prepare(p)
        workflow.require_plan(p)
        before = workflow.fingerprint(p)
        out = render.render(p, preview=not getattr(a, 'final', False))
        if workflow.fingerprint(p) != before:
            raise util.Fail('Project inputs changed during rendering. Render the updated plan again.')
        for message in util.read_json(p/'render'/'check.json',default={}).get('warnings',[])[:8]:
            util.warn(message)
        workflow.register(p, out)
        workflow.make_evidence(p)
    util.ok('Internal candidate ready. Inspect render/review-sheet.jpg and watch/listen to the file recorded in render/candidate.json.')
    util.say('Record the review with workflow review; workflow publish releases the reviewed version.')


def cmd_measure_ref(a):
    """Run reference measurements outside the HTTP server process."""
    from . import refs,teach
    teach.analyze_ref(Path(a.src),refs._ref_dir(a.ref),with_speech=a.with_speech,detailed=not getattr(a,"basic",False),
                      progress=lambda m,p:print(f"PROGRESS {p:.3f} {m}",flush=True))


def cmd_study_ref(a):
    """Study one reference fully (map, fonts, kit). Used by the Studio in its own process."""
    from . import refs, study
    d = refs._ref_dir(a.ref)
    words = util.read_json(d / "words.json", default=[])
    import faulthandler
    with (d / "study-stack.log").open("w") as stack:
        faulthandler.dump_traceback_later(75, repeat=True, file=stack)
        try:
            kit = study.run(Path(a.src), d, words, lambda m, p: print(f"PROGRESS {p:.3f} {m}", flush=True))
        finally:
            faulthandler.cancel_dump_traceback_later()
    util.ok(f"Studied: {len(kit.get('styles', {}))} text styles, fonts: " +
            ", ".join(f"{s['font']['family']} {s['font']['weight']}{' italic' if s['font']['italic'] else ''}" for s in kit.get("styles", {}).values()))


def cmd_wait_reference(a):
    """Wait until this video's reference is studied and its style is applied (Create was pressed early)."""
    import time
    from . import refs
    p = _project(a.project)
    t0 = time.time()
    while time.time() - t0 < 1500:
        rs = [r for r in refs.for_project(p.name) if r["status"] != "error"]
        cfg = util.read_json(p / "project.json")
        style = util.read_json(util.USER_STYLES_DIR / f"{cfg.get('style')}.json", default={})
        if not rs or (all(r["status"] == "done" for r in rs) and style.get("kit")):
            util.ok(f"Reference ready: style {cfg.get('style')}")
            return
        if rs and all(r["status"] == "done" for r in rs):          # studied: apply its style now (nobody else may)
            refs._video_style_from_refs(p.name, rs)
            continue
        quiet = [r for r in rs if r["status"] != "done" and time.time() - float(r.get("updated") or r.get("created") or 0) > 600]
        if quiet:
            raise util.Fail("The reference study stopped before it finished.",
                            "Press Try again on the reference in the Studio (or add it again), then continue.")
        time.sleep(5)
    raise util.Fail("The reference is taking too long to study.", "Continue with the brief and tell the creator.")


def cmd_cutout(a):
    """Cut the creator out of every frame (for text behind them): cutout.webm, then set "behind": true on text."""
    from . import person
    p = _project(a.project)
    src = p / ("graded.mp4" if (p / "graded.mp4").exists() else "cut.mp4")
    out = person.make_cutout(src, p / "cutout.webm", lambda m, f: util.activity(m, f * 100))
    util.ok(f"Cut-out ready: {util.rel(out)}. In edit-plan.json set \"person_cutout\": {{\"src\": \"cutout.webm\"}} and \"behind\": true on text that goes behind.")


def cmd_font(a):
    """Download a Google font (free) for the edit plan, e.g. edit.py font "Shadows Into Light" 400."""
    from . import fontmatch
    f = fontmatch.font_file(a.family, int(a.weight), a.italic)
    if not f:
        raise util.Fail(f"Couldn't download {a.family} {a.weight}.", "Check the name on fonts.google.com.")
    util.ok(f"Font ready: {util.rel(f)}")
    print(f"FONT={util.rel(f)}")


def cmd_render(a):
    """Export reviewed content using the verified delivery profile."""
    from . import workflow, videos
    p = _project(a.project)
    cfg = util.read_json(p/'project.json')
    selected = cfg.get('selected_version')
    if selected:
        version = next((v for v in videos.versions(p.name) if v['n'] == selected), None)
        if not version or not version.get('candidate_sha256') or not version.get('review_file'):
            raise util.Fail('This older version has no recorded review. Ask the editor to review it before exporting.')
        src = util.ROOT / version['file']
        review = util.read_json(util.ROOT/version['review_file'])
        if workflow.digest(src) != version['candidate_sha256'] or review.get('candidate_sha256') != version['candidate_sha256']:
            raise util.Fail('The historical video or its review changed.')
    else:
        workflow.require_release(p)
        version = workflow.publish(p, 'Reviewed export')
        src = util.ROOT / version['file']
    from . import delivery
    reviewed_source = src
    src = delivery.prepare(p, src)
    util.write_json(p/'render'/'final-export.json', {'reviewed_source_sha256':workflow.digest(reviewed_source),
        'export_sha256':workflow.digest(src),'delivery_profile':delivery.PROFILE})
    dest = util.FINISHED / f'{p.name}-final.mp4'
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix('.partial.mp4')
    shutil.copy2(src, tmp)
    os.replace(tmp, dest)
    videos.to_shelf(p.name, dest, 'final')
    videos.update(p.name, lambda cfg: cfg.update(latest=util.rel(dest),status='finished',rendered_at=dt.datetime.now().isoformat(timespec='seconds')))
    util.ok(f'Exported reviewed video: {util.rel(dest)}')
    print(f'OUTPUT={util.rel(dest)}')


def cmd_preset_from(a):
    """Save the look of a video as a named preset (fonts, colours, captions, cuts, graphics, learned tweaks)."""
    from . import presets
    p = _project(a.project)
    new = presets.from_video(p.name, a.name)
    util.ok(f"Saved preset '{a.name}' ({new}). It's in the Studio under Presets and on every new video.")


def cmd_label(a):
    """Say what a B-roll clip shows, so the planner puts its card where those words are said."""
    p = _project(a.project)
    from . import videos
    changed = {}
    def apply(cfg):
        m = next((x for x in cfg.get('media', []) if x.get('id') == a.media or x.get('name') == a.media), None)
        if not m:raise util.Fail("That clip isn't in this video's media.", 'See edit.py media for the ids.')
        m['label'] = a.text.strip()[:120]
        changed.update(m)
    videos.update(p.name, apply)
    util.ok(f"{changed.get('name', a.media)}: {changed['label']}")


def cmd_remember(a):
    """Learning loop: keep a preference for every next video (the creator's, or one preset's)."""
    from . import learn
    sets = dict(x.split("=", 1) for x in (a.set or []))
    r = learn.remember(a.rule, a.preset, sets, a.project or "")
    util.ok(f"Remembered{' for preset ' + a.preset if a.preset else ''}: {r['rule']}" + (f" ({r['set']})" if r.get("set") else "") +
            (f" · said {r['count']} times" if r.get("count", 1) > 1 else ""))


def cmd_learned(a):
    from . import learn
    d = learn.public()
    print("Creator:")
    for k, r in enumerate(d["creator"]):
        print(f"  {k}. {r['rule']}")
    for sid, lst in d["presets"].items():
        if a.preset and sid != a.preset:
            continue
        print(f"Preset {sid}:")
        for k, r in enumerate(lst):
            print(f"  {k}. {r['rule']}")


def cmd_forget(a):
    from . import learn
    learn.forget(a.index, a.preset)
    util.ok("Forgotten.")


def cmd_ref_frames(a):
    """Dense frames of a reference (10 a second) around the moments you want to copy: how cards enter, move and leave,
    how bursts fly, how text animates. Read these before animating anything."""
    from . import refs
    from PIL import Image, ImageDraw
    r = refs.load(a.ref)
    d = refs._ref_dir(a.ref)
    vid = next(iter(sorted(d.glob("video.*"))), None) or (util.ROOT / r["file"] if r.get("file") else None)
    if not vid or not Path(vid).exists():
        raise util.Fail("The reference video isn't kept for this reference.", "Add it again (link or file) to study its motion.")
    out_dir = d / "dense"
    out_dir.mkdir(exist_ok=True)
    for t in [float(x) for x in a.at.split(",")]:
        tmp = out_dir / "tmp"
        tmp.mkdir(exist_ok=True)
        util.run([util.ffmpeg_bin(), "-v", "error", "-y", "-ss", f"{t:.2f}", "-t", f"{a.len:.2f}", "-i", str(vid),
                  "-vf", "fps=10,scale=240:-2", str(tmp / "%03d.jpg")])
        fr = sorted(tmp.glob("*.jpg"))
        if not fr:
            continue
        w, h = Image.open(fr[0]).size
        cols = 8
        rows = (len(fr) + cols - 1) // cols
        sheet = Image.new("RGB", (cols * w, rows * (h + 18)), (16, 16, 18))
        dr = ImageDraw.Draw(sheet)
        for k, f in enumerate(fr):
            x, y = (k % cols) * w, (k // cols) * (h + 18)
            sheet.paste(Image.open(f), (x, y + 18))
            dr.text((x + 4, y + 3), f"{t + k / 10:.1f}s", fill=(220, 220, 225))
        out = out_dir / f"at-{t:05.1f}.jpg"
        sheet.save(out, quality=86)
        import shutil as _sh
        _sh.rmtree(tmp, ignore_errors=True)
        print(f"SHEET={util.rel(out)}")


def cmd_stills(a):
    from . import render
    p = _project(a.project)
    video = Path(a.video) if a.video else (p / "preview.mp4" if (p / "preview.mp4").exists() else p / "cut.mp4")
    times = [float(x) for x in a.at.split(",")] if a.at else None
    sheet = render.stills(p, video, times)
    util.ok(f"Contact sheet: {util.rel(sheet)}")


def cmd_auto(a):
    """Everything in one go with a first-draft graphics plan (used by /batch and quick mode)."""
    from . import director
    ns = argparse.Namespace(video=a.video, name=a.name, style=a.style, platform=a.platform, overwrite=False)
    cmd_new(ns)
    a.project = ns.project
    p = util.PROJECTS / ns.project
    cmd_transcribe(argparse.Namespace(project=p.name, words=a.words, model=None, language=None))
    cmd_plan(argparse.Namespace(project=p.name, max_pause=None))
    cmd_cut(argparse.Namespace(project=p.name, max_pause=None))
    director.draft_beats(p)
    cmd_preview(argparse.Namespace(project=p.name, note="First edit"))


def cmd_styles(a):
    from . import styles
    for s in styles.list_styles():
        print(f"{s['id']:<14} {s['name']:<18} energy {'●' * int(s['energy'])}{'○' * (5 - int(s['energy']))}  {s['tagline']}")


def cmd_style(a):
    from . import styles
    p = _project(a.project)
    styles.load(a.style)  # validates
    from . import videos
    videos.set_brief(p.name, {'style': a.style})
    util.ok(f"{p.name} now uses the '{a.style}' style. Read its saved recipe and update this project's design before rendering.")


def cmd_set(a):
    """Set any project setting: edit.py set <project> key=value (JSON values allowed)."""
    p = _project(a.project)
    from . import videos
    def apply(cfg):
        for kv in a.pairs:
            k, _, v = kv.partition('=')
            try:val = json.loads(v)
            except json.JSONDecodeError:val = v
            cur = cfg
            parts = k.split('.')
            for part in parts[:-1]:
                if part not in cur:cur[part] = {}
                if not isinstance(cur[part], dict):raise util.Fail(f'{part} is not an object setting.')
                cur = cur[part]
            cur[parts[-1]] = val
    result=videos.update(p.name, apply)
    util.ok('Project settings saved.')


def cmd_profile(a):
    prof = util.load_profile()
    if a.pairs:
        def apply(current):
            for kv in a.pairs:
                k, _, v = kv.partition('=')
                try:val = json.loads(v)
                except json.JSONDecodeError:val = v
                cur = current
                parts = k.split('.')
                for part in parts[:-1]:
                    if part not in cur:cur[part] = {}
                    if not isinstance(cur[part], dict):raise util.Fail(f'{part} is not an object setting.')
                    cur = cur[part]
                cur[parts[-1]] = val
        prof=util.update_profile(apply)
    print(json.dumps(prof, indent=2, ensure_ascii=False))


def cmd_tour(a):
    from . import extras
    p = _project(a.project)
    out = extras.style_tour(p, seconds=a.seconds, style_ids=a.styles.split(",") if a.styles else None)
    util.ok(f"Style tour: {util.rel(out)}")


def cmd_teach(a):
    from . import teach
    folder = Path(a.folder) if a.folder else util.REFERENCES
    res = teach.analyze(folder, util.slugify(a.name))
    print(json.dumps(res, indent=2))


def cmd_cover(a):
    from . import extras
    p = _project(a.project)
    out = extras.cover(p, a.text, a.at)
    util.ok(f"Cover image: {util.rel(out)}")


def cmd_compare(a):
    from . import extras
    out = extras.compare(_project(a.project))
    util.ok(f"Before/after video: {util.rel(out)}")


def cmd_export(a):
    from . import extras
    outs = extras.export_to(_project(a.project), [t.strip() for t in a.to.split(",") if t.strip()])
    for o in outs:
        util.ok(f"Format adaptation queued for the editor: {o.name}")


def cmd_short(a):
    from . import extras
    p = _project(a.project)
    s, _, e = a.range.partition("-")
    child = extras.make_short(p, float(s), float(e), util.slugify(a.name))
    util.ok(f"Short project '{child.name}' created from {s}s to {e}s. Next: cut, beats, preview.")
    print(f"PROJECT={child.name}")


def cmd_status(a):
    projects = sorted([d for d in util.PROJECTS.iterdir() if d.is_dir() and not d.name.startswith("_")
                       and (d / "project.json").exists()], key=lambda d: d.stat().st_mtime, reverse=True)
    if not projects:
        print("No projects yet. Drop a video into my-videos/raw and say /edit.")
        return
    for d in projects:
        c = util.read_json(d / "project.json")
        print(f"{d.name:<32} {c.get('status', ''):<12} style={c.get('style')} platform={c.get('platform')} "
              f"latest={c.get('latest', '-')}")


def cmd_report(a):
    from . import problem_reports, telemetry
    host_reason = getattr(a, "host_reason", None)
    if host_reason:
        from editor import director
        project = director.current()
        status = director.status(project) if project else {}
        owner = director.chat_owner()
        if not owner or status.get("owner") != owner or status.get("state") in ("done", "stopped"):
            project = None
        request = status.get("request_id") if project else None
        row = problem_reports.automatic(project, reason=host_reason, failure_class="host",
                                        signature=f"host:{request or 'standalone'}:{host_reason}")
    elif not a.auto and not a.summary:
        raise util.Fail("Use Report a problem in Studio.")
    elif a.summary:
        from editor import director
        project = director.current()
        status = director.status(project) if project else {}
        if not status or status.get("owner") != director.chat_owner() or not director.chat_owner():
            raise util.Fail("There is no edit in this chat to summarize.")
        director.put(project, _request=status["request_id"], report_chat_facts={
            "request": status["request_id"], "reason": a.summary})
        print("Saved a technical summary for this edit.")
        return
    else:
        row = problem_reports.automatic(area=a.area, reason="startup" if a.area == "studio" else "unknown",
                                        signature=f"startup:{a.area}")
    if not row:
        if host_reason:
            raise util.Fail("Could not save or send the problem report. Your existing edit is still available in Studio.")
        return
    if row["status"] == "sent":
        print("Problem report sent. Code " + row["code"])
    else:
        print("Problem report saved. Code " + row["code"])
        if telemetry.enabled():
            telemetry.flush(limit=2, only_code=row["code"])


def cmd_studio(a):
    """The Studio app: serve it, wait on it, open it, or rebuild the offline dashboard data."""
    from . import studio
    act = a.action or "build"
    if act == "serve":
        from . import server
        server.serve(a.port)
        return
    if act in ("wait", "pending"):
        from editor import director
        return director.main(['wait' if act=='wait' else 'next'])
    if act == "context":
        from . import videos
        print(videos.context_text(a.project or (a.extra[0] if getattr(a,"extra",None) else None)))
        return
    if act == "app":
        from . import launcher
        where = launcher.install()
        util.ok(f"CreatorCut Studio app: {where}")
        return
    if act == "name":
        from . import videos
        pid = a.project or (a.extra[0] if getattr(a, "extra", None) else "") or videos.focused()
        text = (a.text or "").strip() or (a.extra[1] if getattr(a, "extra", None) and len(a.extra) > 1 else "")
        cfg = videos.load(pid)
        if cfg.get("title") and cfg["title"] != "Untitled video":
            util.ok(f"Keeping the name the creator gave it: {cfg['title']}")
            return
        videos.update(pid, lambda c: c.update(title=text[:60]))
        util.ok(f"Named: {text[:60]}")
        return
    if act == "begin":
        from . import videos
        pid = a.project or (a.extra[0] if getattr(a, "extra", None) else "")
        if not pid:
            pid = videos.focused()
        if not pid:
            raise util.Fail("Which video? There's no video open in the Studio.", "Name it, or open it in the Studio.")
        info = videos.begin(pid)
        util.ok(f"Started '{info['title']}': the Studio shows the progress.")
        print(f"PROJECT={pid}")
        return
    if act in ("hook-start", "hook-stop"):
        from editor import hooks
        data=json.loads(sys.stdin.read() or '{}') if act=='hook-stop' else {}
        result=hooks.run('start' if act=='hook-start' else 'stop',data)
        if result:print(json.dumps(result))
        return
    if act == "say":
        from . import events, videos
        text = a.text or ""
        if a.project:
            if getattr(a, "you", None):                    # mirror what the creator asked in the chat
                videos.say(a.project, "user", a.you, native=True)
            videos.say(a.project, "editor", text, native=True)
        print(json.dumps(events.emit("agent.message", {"project": a.project, "text": text}, source="agent")))
        return
    if act == "emit":
        from . import events
        print(json.dumps(events.emit(a.type, json.loads(a.payload or "{}"), source="agent")))
        return
    if act == "open":
        # The owned server checks setup before binding; healthy reuse is immediate.
        from editor import director
        director.require_studio_project()
        from . import server
        try:
            info = server.start_detached(a.port or 4317)
        except server.StudioStarting as error:
            print(error.message)
            return
        except (util.Fail, OSError) as error:
            if isinstance(error, util.LockBusy) and error.message == 'Studio is still starting.':
                print('Studio is still opening. Give it a moment, then open Studio again.')
                return
            from . import problem_reports, telemetry
            reason, category = "startup", "app"
            if isinstance(error, PermissionError):
                reason, category = "startup_access", "host"
            elif str(error) == "Studio startup took too long.":
                reason = "startup_timeout"
            elif str(error) == "Studio has not opened because setup checks did not pass.":
                reason = "startup_exit"
            row = problem_reports.automatic(area="studio", reason=reason, failure_class=category,
                                            signature="startup:studio")
            if row and telemetry.enabled():
                telemetry.flush(limit=1, only_code=row["code"])
            raise
        url = info["url"]
        if not a.no_browser:
            import subprocess
            opener = {"mac": ["open", url], "windows": ["cmd", "/c", "start", "", url]}.get(util.os_name(), ["xdg-open", url])
            try:
                subprocess.Popen(opener)
            except OSError:
                pass
        util.ok(f"Studio is running at {url}")
        print(f"STUDIO_URL={url}")
        from . import chat_execution
        if chat_execution.mode()=='chat':print('Choose your footage in Studio and press Make my video. If it does not start within 30 seconds, type continue in your CreatorCut chat.')
        return
    if act == "status":
        from . import events, server
        info = server.running_server()
        print(json.dumps({"running": bool(info), "url": info["url"] if info else None,
                          "listening": events.listening()["listening"], "pending": len(events.pending())}))
        return
    if act == "thumb":
        from . import styles as st
        names = [a.style] if a.style else [s["id"] for s in st.list_styles()]
        bg = studio._background()
        for n in names:
            studio.style_thumb(n, bg, util.STUDIO_OUT / "assets" / "styles" / f"{n}.jpg")
            util.ok(f"Preview for '{n}' refreshed")
        return
    out = studio.build(thumbs=a.thumbs)
    util.ok(f"Studio data refreshed: {util.rel(out)}")
    print(f"STUDIO={out}")


def cmd_doctor(a):
    from . import setup
    res = setup.doctor()
    if a.json:
        print(json.dumps(res, indent=2))
    else:
        setup.print_doctor(res)


def cmd_install(a):
    from . import setup
    setup.install(model=a.model, skip_model=a.skip_model)


def cmd_install2(a):
    from . import setup
    setup.install_stage2(a.model, a.skip_model)


def cmd_fonts(a):
    from . import setup
    setup.download_fonts()


def cmd_calibrate(a):
    from . import styles as st
    st.calibrate_all()
    util.ok("Fonts calibrated")


def cmd_model(a):
    from . import setup
    sys.exit(0 if setup.download_model(a.model) else 2)


def cmd_sfx(a):
    from . import sfx
    sfx.ensure(force=a.force)


def cmd_reference(a):
    """Study one reference (a pasted link or a file) and make a style for a video from it."""
    import shutil
    from . import dna, linkfetch, teach, videos
    src_arg = a.source
    work = util.PROJECTS / "_teach" / "_downloads" / ("cli-" + util.slugify(src_arg)[:30])
    if re.match(r"https?://", src_arg):
        util.step("Fetching the reference…")
        res = linkfetch.fetch(src_arg, work, lambda m, f: None)
        src, how = res.path, res.method
        util.ok(f"Fetched ({how}{', cover image only' if res.partial else ''})")
    else:
        src = Path(src_arg)
        if not src.is_absolute():
            src = util.ROOT / src
        if not src.exists():
            raise util.Fail("I can't find that reference file.")
    from . import setup
    name = util.slugify(a.name or ((a.project + "-ref") if a.project else "reference"))
    rdir = teach.REFS / ("x-" + name)
    try:
        teach.analyze_ref(src, rdir, with_speech=setup._model_cached(util.load_profile().get("whisper_model", "small")),
                          progress=lambda m, f: util.step(m))
    finally:
        if re.match(r"https?://", src_arg):
            shutil.rmtree(work, ignore_errors=True)
    agg = teach.aggregate(name, [rdir])
    style = teach.draft_style(agg, name, a.label or "Reference style")
    util.write_json(util.USER_STYLES_DIR / f"{name}.json", style)
    (util.USER_STYLES_DIR / f"{name}.md").write_text(dna.rulebook(agg, style, name), encoding="utf-8")
    util.write_json(teach.TEACH / name / "reveal.json", teach.reveal(agg, style))
    from . import presets
    presets.write_skill(name)
    if a.project:
        videos.update(a.project, lambda c: c.update(style=name))
    util.ok(f"Style '{name}' written · rules in my-brand/styles/{name}.md")
    print(json.dumps({"style": name, "contact_sheet": agg["contact_sheet"], "rulebook": f"my-brand/styles/{name}.md",
                      "deep": agg.get("deep")}, indent=1))


def cmd_media(a):
    """List a Studio video's media (with thumbnails) and make a contact sheet of its B-roll for the agent to look at."""
    from PIL import Image, ImageDraw
    p = _project(a.project)
    cfg = util.read_json(p / "project.json")
    items = cfg.get("media", [])
    thumbs = [m for m in items if m.get("thumb") and m["kind"] in ("broll", "image")]
    if thumbs:
        tiles = []
        for m in thumbs[:24]:
            try:
                im = Image.open(util.ROOT / m["thumb"]).convert("RGB")
                im.thumbnail((240, 420))
                tiles.append((m, im))
            except Exception:
                pass
        cols = 4
        sheet = Image.new("RGB", (cols * 250 + 10, ((len(tiles) + cols - 1) // cols) * 460 + 10), (16, 16, 18))
        dr = ImageDraw.Draw(sheet)
        for i, (m, im) in enumerate(tiles):
            x, y = 10 + (i % cols) * 250, 10 + (i // cols) * 460
            sheet.paste(im, (x, y))
            dr.text((x, y + 425), f"{m['id']} {m['name'][:26]}", fill=(220, 220, 220))
        out = p / "render" / "media-sheet.jpg"
        out.parent.mkdir(exist_ok=True)
        sheet.save(out, quality=86)
        print(f"MEDIA_SHEET={util.rel(out)}")
    print(json.dumps({"brief": cfg.get("brief", {}), "style": cfg.get("style"), "media": [
        {k: m.get(k) for k in ("id", "kind", "name", "file", "duration", "label")} for m in items]}, indent=1, ensure_ascii=False))


def cmd_update(a):
    from . import updater
    if a.source == "rollback":
        with util.file_guard(util.KIT / ".update.guard", timeout=5):
            updater.ensure_idle()
            updater.rollback()
    elif a.source == "check":
        r = updater.check()
        if r.get("checking"):
            raise util.Fail("The update check is still running. Try again in a moment.")
        if r.get("error"):
            raise util.Fail(r["error"])
        if not r.get("configured") or not r.get("latest"):
            raise util.Fail(updater.UNCONFIRMED)
        if r.get("cached_offline"):
            if not r.get("available"):
                raise util.Fail(updater.UNCONFIRMED)
            print(f"Version {r['current']}. Previously verified update {r['latest']} is available. {updater.UNCONFIRMED}")
            return
        print(f"Version {r['current']}" + (f", {r['latest']} available: {r.get('notes', '')}" if r.get("available") else ", up to date"))
    else:
        updater.apply(a.source)


def cmd_match(a):
    """Match check: the reference frame next to the same frame with OUR caption in this preset, so the agent can
    compare font, size, position, colours and outline and adjust the preset until they match."""
    from PIL import Image
    from . import ass, captions, platforms, styles as st, teach
    style = st.load(a.style, apply_brand=False)
    frames = sorted(teach.TEACH.glob("_refs/*/frames/[0-9][0-9].jpg"))
    if a.frame:
        frames = [Path(a.frame) if Path(a.frame).is_absolute() else util.ROOT / a.frame]
    if not frames:
        raise util.Fail("No reference frames found.", "Train a preset from reference videos first.")
    ref = frames[0]
    work = util.PROJECTS / "_teach" / "_match"
    work.mkdir(parents=True, exist_ok=True)
    plat = platforms.get("tiktok")
    base = Image.open(ref).convert("RGB").resize((1080, 1920))
    from PIL import ImageFilter
    dim = base.filter(ImageFilter.GaussianBlur(28)).point(lambda v: int(v * 0.8))   # hide the reference's own caption
    dim.save(work / "bg.jpg", quality=92)
    words = [{"w": w, "start": 0.2 + i * 0.3, "end": 0.45 + i * 0.3} for i, w in enumerate((a.text or "YOUR WORDS HERE").split())]
    doc = ass.Doc(1080, 1920)
    captions.build(doc, words, style, plat, 5.0)
    (work / "cap.ass").write_text(doc.render(), encoding="utf-8")
    fonts_rel = os.path.relpath(util.FONTS_DIR, work).replace("\\", "/")
    util.run([util.ffmpeg_bin(), "-y", "-hide_banner", "-loop", "1", "-t", "1", "-i", "bg.jpg", "-vf",
              f"ass=cap.ass:fontsdir={fonts_rel}", "-ss", "0.3", "-frames:v", "1", "ours.png"], cwd=work)
    ours = Image.open(work / "ours.png").convert("RGB")
    side = Image.new("RGB", (2180, 1920), (20, 20, 22))
    side.paste(base, (0, 0))
    side.paste(ours, (1100, 0))
    out = work / f"match-{a.style}.jpg"
    side.resize((1090, 960)).save(out, quality=88)
    util.ok(f"Left: reference · right: this preset (on a blurred copy) → {util.rel(out)}")
    print(f"MATCH={util.rel(out)}")


def cmd_preset_skill(a):
    """Rewrite a preset's skill file after you edited its spec or settings."""
    from . import presets
    out = presets.write_skill(a.style)
    util.ok(f"Preset skill updated: {out}")


def cmd_restudy(a):
    """Study a preset's references again with the current frame-by-frame analysis and rebuild it."""
    from . import refs
    ids = [a.style] if a.style != "all" else [f.stem for f in util.USER_STYLES_DIR.glob("*.json")]
    for sid in ids:
        refs.restudy_preset(sid, lambda m, p: print(f"  {round(p * 100):3d}%  {m}", flush=True))
        util.ok(f"Preset studied again: {sid}")


def cmd_musicgen(a):
    from . import musicgen
    musicgen.ensure(force=a.force)


def cmd_clean(a):
    p = _project(a.project)
    freed = 0
    for f in [p / "cut.mp4", p / "preview.mp4", p / "audio16k.wav"] + list((p / "render").glob("*.png")):
        if f.exists():
            freed += f.stat().st_size
            f.unlink()
    util.ok(f"Freed {freed / 1e6:.0f} MB from {p.name} (finished videos are untouched)")


ACTIVITY_LABELS = {
    "design": ("Planning scene graphics", 0.6), "compose": ("Rendering an internal candidate", 0.8), "grade": ("Applying requested colour treatment", 0.65),
    "new": ("Getting your clip ready", 0.05), "prepare": ("Getting your footage ready", 0.05), "transcribe": ("Listening to every word", 0.15),
    "plan": ("Finding the best takes", 0.35), "cut": ("Cutting out pauses and bad takes", 0.45),
    "beats": ("Designing your graphics", 0.6), "check": ("Checking captions and graphics", 0.7),
    "preview": ("Rendering your preview", 0.8), "render": ("Rendering the final video", 0.9),
    "auto": ("Editing your video", 0.1), "export": ("Making versions for other platforms", 0.5),
    "compare": ("Making your before/after", 0.5), "cover": ("Making your cover", 0.5),
    "study-ref": ("Studying a reference", 0.1), "cutout": ("Separating the speaker", 0.5),
    "teach": ("Learning your style", 0.5), "tour": ("Making a style tour", 0.5),
}


def _activity(a, running: bool, error: str = "") -> None:
    """What the engine is doing right now, for the Studio's progress display."""
    import time
    if getattr(a, "project", None) is None and a.cmd not in ("new", "auto", "teach", "study-ref") :
        try:
            a.project = os.environ.get('CREATORCUT_PROJECT') or None
        except Exception:
            pass
    from . import activity_store
    label, prog = ACTIVITY_LABELS[a.cmd]
    if running:
        activity_store.begin(getattr(a, 'project', None), cmd=a.cmd, request_id=os.environ.get('CREATORCUT_REQUEST_ID'), label=label, progress=prog, percent=None, log=[], error='')
        activity_store.start_heartbeat()
        util.activity(label)
    else:
        activity_store.stop_heartbeat()
        from . import diagnostics
        current=activity_store.latest(getattr(a,'project',None))
        diagnostics.bound('step.complete',stage=a.cmd,duration=max(0,time.time()-current.get('started',time.time())),outcome='failed' if error else 'completed')
        activity_store.update(running=False, waiting_resources=False, error=error, percent=None if error else 100)


def _status(p: Path, s: str) -> None:
    from . import videos
    videos.update(p.name, lambda cfg: cfg.update(status=s))


def cmd_plan_save(a):
    from . import plan_io
    p=_project(a.project)
    if a.recover:
        with util.project_lock(p,heavy_work=False),util.file_guard(p/'.plan-save.guard',timeout=5):result={'recovered':plan_io.recover(p)}
    else:
        if not a.scene or not a.plan:raise util.Fail('Supply both the scene and edit plan JSON files.')
        files=[Path(a.scene),Path(a.plan)]
        if any(not file.is_file() or file.stat().st_size>8*1024*1024 for file in files):raise util.Fail('Each plan must be a local JSON file smaller than 8 MB.')
        result=plan_io.save(p,util.read_json(files[0]),util.read_json(files[1]))
    print(json.dumps(result))


def cmd_local_tool(a):
    """Fixed app tools through the existing scoped edit.py command rule."""
    import runpy
    target={'library':'style-library.py','renderer-probe':'renderer_probe.py','timeline-feedback':'timeline-feedback.py'}[a.cmd]
    old=sys.argv
    try:
        sys.argv=[str(util.KIT/'tools'/target),*a.tool_args]
        runpy.run_path(sys.argv[0],run_name='__main__')
    finally:sys.argv=old


def minimum_free_bytes(args):
    """Metadata-only starts do not need a render's working-space reserve."""
    if args.cmd == 'new':
        return 256 * 1024 ** 2
    if args.cmd == 'prepare':
        try:
            p = _project(getattr(args,'project',None))
            cfg = util.read_json(p / 'project.json')
            if len([m for m in cfg.get('media', []) if m.get('kind') == 'raw']) == 1:
                return 256 * 1024 ** 2
        except (util.Fail, OSError, ValueError):
            pass
    try:
        from . import capacity
        return capacity.required(util.read_json(_project(getattr(args,'project',None))/'edit-plan.json',default={}))
    except (util.Fail,OSError):return 2_500_000_000


def main(argv=None):
    ap = argparse.ArgumentParser(prog="edit.py", description="CreatorCut OS engine")
    sub = ap.add_subparsers(dest="cmd", required=True)

    def add(name, fn, help_, *args):
        sp = sub.add_parser(name, help=help_)
        for arg in args:
            sp.add_argument(*arg[0], **arg[1])
        sp.set_defaults(fn=fn)
        return sp

    for tool in ('library','renderer-probe','timeline-feedback'):
        sp=sub.add_parser(tool,help='Run this installation’s '+tool+' tool');sp.add_argument('tool_args',nargs=argparse.REMAINDER);sp.set_defaults(fn=cmd_local_tool)
    P = (["project"], {"nargs": "?", "help": "exact project name; never inferred from another video"})
    add("report", cmd_report, "save a technical problem report", (["--auto"], {"action": "store_true"}),
        (["--area"], {"choices": ["studio", "install", "editor"], "default": "editor"}),
        (["--summary"], {"choices": ["storage", "source", "browser", "access", "timeout", "missing_input"]}),
        (["--host-reason"], {"choices": ["usage_limit", "permission_denied", "refused", "context_full"]}))
    add("doctor", cmd_doctor, "check everything is installed", (["--json"], {"action": "store_true"}))
    add("install", cmd_install, "install Python packages, fonts, sounds and the speech model",
        (["--model"], {}), (["--skip-model"], {"action": "store_true"}))
    add("install-stage2", cmd_install2, argparse.SUPPRESS, (["--model"], {}), (["--skip-model"], {"action": "store_true"}))
    add("fonts", cmd_fonts, "download the premium font pack")
    add("calibrate", cmd_calibrate, "measure fonts so every style renders at the right size")
    add("model", cmd_model, "download the speech model", (["--model"], {}))
    add("reference", cmd_reference, "study a reference link or file and make a style from it", (["source"], {}),
        (["--project"], {}), (["--name"], {}), (["--label"], {}))
    add("media", cmd_media, "a Studio video's media list + B-roll contact sheet", P)
    add("update", cmd_update, "install a newer version (keeps all videos, styles and settings); 'check', 'rollback', or a zip file/link", (["source"], {"nargs": "?"}))
    add("match", cmd_match, "compare a preset's captions with a reference frame, side by side", (["style"], {}),
        (["--text"], {"help": "the words on the reference frame"}), (["--frame"], {}))
    add("restudy", cmd_restudy, "study a preset's references again with the current analysis (id or 'all')", (["style"], {}))
    add("preset-skill", cmd_preset_skill, "write/refresh a preset's skill file (.claude/skills/preset-<id>)", (["style"], {}))
    add("music-gen", cmd_musicgen, "make the built-in original music library", (["--force"], {"action": "store_true"}))
    add("sfx", cmd_sfx, "make the sound-effects library", (["--force"], {"action": "store_true"}))
    add("new", cmd_new, "start a project from a video (default: newest in my-videos/raw)",
        (["video"], {"nargs": "?"}), (["--name"], {}), (["--style"], {}), (["--platform"], {}),
        (["--overwrite"], {"action": "store_true"}))
    add("prepare", cmd_prepare, "Studio draft: join its raw clips into the source video", P)
    add("request-context", cmd_request_context, "read this video's complete saved request and required input keys", P)
    add("transcribe", cmd_transcribe, "word-level transcript", P, (["--model"], {}), (["--language"], {}),
        (["--words"], {"help": "import words from a JSON file instead"}))
    add("plan", cmd_plan, "find bad takes, fillers and pauses; preserve verified silent footage", P, (["--max-pause"], {"type": float}),
        (["--ranges"], {"help":"silent footage only: JSON list of source sections, e.g. [{\"start\":0,\"end\":5}]"}))
    add("cut", cmd_cut, "cut the video from plan.json", P, (["--max-pause"], {"type": float}))
    add("words", cmd_words, "show the cut transcript with times", P)
    add("beats", cmd_beats, "draft a graphics plan (beats.json)", P, (["--force"], {"action": "store_true"}))
    add("check", cmd_check, "validate graphics + retention report", P)
    add("preview", cmd_preview, "fast preview + contact sheet (saved as the next version)", P,
        (["--note"], {"help": "what changed, shown on the version chip"}))
    add("render", cmd_render, "final full-quality video", P)
    add("measure-ref",cmd_measure_ref,"measure a reference in an isolated worker",(["ref"],{}),(["--src"],{"required":True}),(["--with-speech"],{"action":"store_true"}),(["--basic"],{"action":"store_true"}))
    add("study-ref", cmd_study_ref, "study a reference fully (map, fonts, style kit)", (["ref"], {}), (["--src"], {"required": True}))
    add("wait-reference", cmd_wait_reference, "wait until the video's reference is studied and applied", P)
    add("cutout", cmd_cutout, "cut the person out of every frame (text behind them)", P)
    add("font", cmd_font, "download a Google font for the edit plan", (["family"], {}), (["weight"], {"nargs": "?", "default": "400"}),
        (["--italic"], {"action": "store_true"}))
    add("grade", cmd_grade, "colour-match the cut to the reference (with safety checks)", P)
    add("design", cmd_design, "draft the edit plan (edit-plan.json) from the style kit", P, (["--force"], {"action": "store_true"}))
    add("compose", cmd_compose, "render an internal motion candidate for review", P,
        (["--note"], {"help": "what changed"}), (["--final"], {"action": "store_true", "help": "full quality into my-videos/finished"}))
    add("stills", cmd_stills, "contact sheet of frames", P, (["--video"], {}), (["--at"], {"help": "comma-separated seconds"}))
    add("label", cmd_label, "say what a B-roll clip shows (its card lands on those words)", P, (["media"], {}), (["text"], {}))
    add("remember", cmd_remember, "learning loop: keep a preference for every next video", (["rule"], {}), (["--preset"], {}),
        (["--project"], {}), (["--set"], {"nargs": "*", "help": "key=value, e.g. caption_size=1.15 cards_density=0.5 zoom=false"}))
    add("preset-from", cmd_preset_from, "save a video's look as a named preset", (["project"], {}), (["name"], {}))
    add("learned", cmd_learned, "list what the creator taught (learning loop)", (["--preset"], {}))
    add("forget", cmd_forget, "forget a learned rule", (["index"], {"type": int}), (["--preset"], {}))
    add("ref-frames", cmd_ref_frames, "dense frames (10 a second) of a reference around given moments: study its motion", (["ref"], {}),
        (["--at"], {"required": True, "help": "comma-separated seconds"}), (["--len"], {"type": float, "default": 2.4}))
    add("auto", cmd_auto, "new → transcribe → plan → cut → draft graphics → preview",
        (["video"], {"nargs": "?"}), (["--name"], {}), (["--style"], {}), (["--platform"], {}), (["--words"], {}))
    add("plan-save",cmd_plan_save,"validate and atomically save both edit plans",P,(["--scene"],{}),(["--plan"],{}),(["--recover"],{"action":"store_true"}))
    add("styles", cmd_styles, "list styles")
    add("style", cmd_style, "switch a project's style", (["project"], {}), (["style"], {}))
    add("set", cmd_set, "set project settings key=value", (["project"], {}), (["pairs"], {"nargs": "+"}))
    add("profile", cmd_profile, "show or set profile key=value", (["pairs"], {"nargs": "*"}))
    add("tour", cmd_tour, "your clip in every style", P, (["--seconds"], {"type": float, "default": 4.0}), (["--styles"], {}))
    add("teach", cmd_teach, "analyse references for a new style", (["name"], {}), (["--folder"], {}))
    add("cover", cmd_cover, "make a cover/thumbnail image", P, (["--text"], {"required": True}), (["--at"], {"type": float}))
    add("compare", cmd_compare, "before/after video", P)
    add("export", cmd_export, "re-make for other platforms", P, (["--to"], {"required": True}))
    add("short", cmd_short, "make a short from a time range", P, (["--range"], {"required": True}), (["--name"], {"required": True}))
    add("status", cmd_status, "list projects")
    add("studio", cmd_studio, "the Studio app: serve | wait | pending | open | status | thumb | build",
        (["action"], {"nargs": "?", "choices": ["serve", "wait", "pending", "emit", "say", "open", "status", "thumb", "build", "hook-start", "hook-stop", "context", "begin", "name", "app"]}),
        (["extra"], {"nargs": "*", "help": "the video (and text): studio begin <video>, studio name <video> \"<name>\""}),
        (["--host-project"], {"help": "bridge-config: actual open host project folder"}),
        (["--project"], {}), (["--text"], {}), (["--you"], {"help": "studio say: the creator's message it answers (shown in the Studio)"}),
        (["--thumbs"], {"action": "store_true", "help": "re-render style previews"}),
        (["--port"], {"type": int}), (["--for"], {"dest": "for_", "help": "event types to wait for, comma-separated"}),
        (["--timeout"], {"type": float, "default": 100}), (["--conversation"], {}), (["--ack"], {"action": "store_true"}),
        (["--style"], {}), (["--type"], {}), (["--payload"], {}),
        (["--no-browser"], {"action": "store_true"}))
    add("clean", cmd_clean, "delete large working files of a project", P)
    raw=list(sys.argv[1:] if argv is None else argv)
    if raw and raw[0] in ("library","renderer-probe","timeline-feedback") and raw[1:2]!=["--"]:raw.insert(1,"--")
    a = ap.parse_args(raw)
    if hasattr(a,"tool_args") and a.tool_args[:1]==["--"]:a.tool_args=a.tool_args[1:]
    host_project=os.environ.get('CLAUDE_PROJECT_DIR')
    if host_project and Path(host_project).resolve()!=util.ROOT.resolve() and a.cmd in ('workflow','compose','render','library','renderer-probe','timeline-feedback','prepare','transcribe','cut'):
        print('Open the CreatorCut folder as your project, then type continue. Your files are safe.');sys.exit(1)
    try:
        from . import editor
        if not (a.cmd=='studio' and a.action in ('open','serve','app','status')):editor.retire_managed_workers()
    except util.Fail as error:
        print(error.message);sys.exit(1)
    if a.cmd not in ('studio','doctor','setup','update'):
        update_state = util.read_json(util.STUDIO_OUT / 'update.json', default={})
        if update_state.get('status') in ('downloading','installing'):
            from . import updater
            if updater.is_running():
                print('CreatorCut is updating. Your files are saved; continue this step when the update finishes.')
                sys.exit(1)
    # heavy steps need room on the disk: say so before starting, never fail half-way
    if a.cmd in ("prepare", "cut", "grade", "compose", "render", "cutout", "new", "export", "short"):
        try:
            import shutil as _sh
            from . import capacity
            free = capacity.available(util.ROOT)
            required = minimum_free_bytes(a)
            if free < required:
                print(f"\n✗ There is not enough working space for this step ({free/1e9:.1f} GB free; {required/1e9:.2f} GB needed).")
                print("→ Your originals and saved edits are kept. Free some disk space, then continue this step.")
                sys.exit(1)
        except OSError:
            pass
    tracked = a.cmd in ACTIVITY_LABELS
    if tracked:_activity(a, True)
    try:
        from contextlib import nullcontext
        command_project=getattr(a,'project',None)
        command_lock=nullcontext()
        if command_project and (tracked or a.cmd in ('plan-save','label') or a.cmd=='workflow' and a.action not in ('start','claim','status','next','unfinished','resume','clean-cache')):
            command_path=_project(command_project)
            from . import editor as _editor
            if _editor.read(command_path.name).get('execution_mode')=='chat':
                command_lock=chat_execution.command_guard(command_path)
        with command_lock:
            if a.cmd in {'auto','prepare','transcribe','cut','grade','compose','preview','render','cutout','tour','short','compare','cover','check'}:
                from .resources import heavy
                with heavy(ACTIVITY_LABELS.get(a.cmd, ('Processing video',0))[0]):
                    a.fn(a)
            else:
                a.fn(a)
            if tracked:
                _activity(a, False)
    except util.Fail as e:
        if tracked:
            try:_activity(a, False, error=e.message)
            except (OSError,util.Fail):pass
        print(f"\n✗ {e.message}")
        if e.fix:
            print(f"→ {e.fix}")
        sys.exit(1)
    except KeyboardInterrupt:
        if tracked: _activity(a, False, error="Editing step cancelled")
        sys.exit(130)
    except BrokenPipeError:
        pass
    except OSError as error:
        import errno
        if tracked:
            try:_activity(a,False,error='The step could not save its output.')
            except (OSError,util.Fail):pass
        if error.errno==errno.ENOSPC:print('Your Mac ran out of space. Free some space, then retry this saved step. Previously saved videos are kept.')
        else:print('This step could not read or save a file. Reconnect the source or check this app folder, then retry. Your saved videos are kept.')
        sys.exit(1)
    except Exception as e:                             # never a raw crash: say it plainly, keep the details
        import traceback
        try:
            (util.STUDIO_OUT).mkdir(parents=True, exist_ok=True)
            with (util.STUDIO_OUT / "engine-errors.log").open("a", encoding="utf-8") as f:
                f.write(f"\n--- {time.strftime('%Y-%m-%d %H:%M:%S')} edit.py {' '.join(sys.argv[1:])}\n{traceback.format_exc()}")
        except Exception:
            pass
        if tracked:
            _activity(a, False, error="Something went wrong")
        print(f"\n✗ Something unexpected went wrong in '{a.cmd}' ({type(e).__name__}: {str(e)[:160]}).")
        print("→ The details are in kit/studio-out/engine-errors.log. Try the step again; if it repeats, run `edit.py doctor`.")
        sys.exit(1)
