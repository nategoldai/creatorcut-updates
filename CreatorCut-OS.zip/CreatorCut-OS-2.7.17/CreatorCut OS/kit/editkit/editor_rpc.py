"""Documented Codex App Server transport. No API key extraction or permission bypass."""
from __future__ import annotations
import os,json,subprocess,threading,queue,time
from concurrent.futures import Future
from . import util

class RPC:
    def __init__(self,command,cwd):
        self.process=subprocess.Popen(command,cwd=cwd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1,close_fds=True,env=dict(os.environ,CREATORCUT_MANAGED_EDITOR='1'),**util.process_group_options())
        self.process._creatorcut_isolated = os.name != 'nt'
        self.pending={};self.lock=threading.Lock();self.close_lock=threading.Lock();self.cleanup_complete=False;self.serial=0;self.events=queue.Queue();self.stderr=[]
        self.outgoing=queue.Queue(maxsize=32);self.closed=threading.Event()
        self.writer=threading.Thread(target=self._write_loop,daemon=True)
        self.reader=threading.Thread(target=self._read,daemon=True)
        self.error_reader=threading.Thread(target=self._errors,daemon=True)
        try:
            for thread in (self.writer,self.reader,self.error_reader):thread.start()
        except Exception:
            self.close();raise
    def _errors(self):
        try:
            for line in self.process.stderr:
                self.stderr=(self.stderr+[line.rstrip()])[-30:]
        finally:
            self.process.stderr.close()

    def _read(self):
        try:
            for line in self.process.stdout:
                if len(line)>8_000_000:continue
                try:m=json.loads(line)
                except ValueError:continue
                if not isinstance(m,dict):continue
                if 'id' in m and 'method' not in m:
                    with self.lock:f=self.pending.pop(m['id'],None)
                    if f and not f.done():
                        if 'error' in m:
                            error=m['error'];message=error.get('message','Editor request failed.') if isinstance(error,dict) else str(error)
                            f.set_exception(util.Fail(message))
                        else:f.set_result(m.get('result',{}))
                else:self.events.put(m)
        finally:
            with self.lock:
                for f in self.pending.values():
                    if not f.done():f.set_exception(util.Fail('The editor connection closed. Your project is saved.'))
                self.pending.clear()
            self.closed.set()
            self.events.put({'method':'creatorcut/process_closed'})
            self.process.stdout.close()
    def _write_loop(self):
        try:self._write_messages()
        finally:
            # EOF can arrive with writes still queued. Fail them immediately;
            # a caller must not wait for its full send deadline after disconnect.
            self.closed.set()
            while True:
                try:payload,done=self.outgoing.get_nowait()
                except queue.Empty:break
                if not done.done():done.set_exception(util.Fail('The editor connection stopped. Your request is saved.'))
                self.outgoing.task_done()
            # Buffered close may flush into an already closed child pipe.
            try:self.process.stdin.close()
            except (OSError,ValueError):pass

    def _write_messages(self):
        # Only this thread touches stdin. A blocked pipe must never hold the
        # response registry lock or prevent a caller's deadline from expiring.
        while not self.closed.is_set():
            try:item=self.outgoing.get(timeout=.1)
            except queue.Empty:continue
            payload,done=item
            try:
                if self.process.poll() is not None:raise OSError('Editor process stopped')
                self.process.stdin.write(payload);self.process.stdin.flush()
                done.set_result(None)
            except (OSError,ValueError) as exc:
                done.set_exception(util.Fail('The editor connection stopped. Your request is saved.'))
                self.closed.set()
            finally:self.outgoing.task_done()
    def write(self,message,timeout=30):
        deadline=time.monotonic()+timeout
        if self.closed.is_set() or self.process.poll() is not None:
            raise util.Fail('The editor process stopped. Your files are saved.')
        done=Future()
        try:
            self.outgoing.put((json.dumps(message,ensure_ascii=False)+'\n',done),timeout=max(0,deadline-time.monotonic()))
            done.result(timeout=max(0,deadline-time.monotonic()))
        except (TimeoutError,queue.Full):
            # Delivery is ambiguous. Stop this owned transport, do not replay
            # an unconfirmed turn into it or allow queued messages to arrive late.
            self.closed.set()
            if self.process.poll() is None:
                try:self.process.terminate()
                except OSError:pass
            raise util.Fail('The editor did not confirm message delivery. Your request remains saved; no duplicate is sent automatically.')
    def request(self,method,params=None,timeout=30):
        with self.lock:
            self.serial+=1;rid='cc-'+str(self.serial);f=Future();self.pending[rid]=f
        try:
            deadline=time.monotonic()+timeout
            self.write({'jsonrpc':'2.0','id':rid,'method':method,'params':params or {}},timeout=timeout)
            return f.result(timeout=max(0,deadline-time.monotonic()))
        except TimeoutError:
            raise util.Fail('The editor did not confirm '+method+'. Your request remains saved; no duplicate is sent automatically.')
        finally:
            with self.lock:self.pending.pop(rid,None)
    def notify(self,method,params=None):self.write({'jsonrpc':'2.0','method':method,'params':params or {}})
    def respond(self,rid,result):self.write({'jsonrpc':'2.0','id':rid,'result':result})
    def reject(self,rid,message):self.write({'jsonrpc':'2.0','id':rid,'error':{'code':-32601,'message':message}})
    def close(self):
        # Only signal the process/group created by this connection. A detached
        # descendant can retain inherited pipes after that process exits; its
        # reader owns and eventually closes the stream, never this caller.
        if not self.close_lock.acquire(blocking=False):return
        try:
            if self.cleanup_complete:return
            self.closed.set()
            with self.lock:
                for future in self.pending.values():
                    if not future.done():future.set_exception(util.Fail('The editor connection closed. Your project is saved.'))
                self.pending.clear()
            util.stop_process(self.process)
            if self.writer.ident is not None:self.writer.join(timeout=.25)
            if not self.writer.is_alive():
                try:self.process.stdin.close()
                except (OSError,ValueError):pass
            for thread,stream in ((self.reader,self.process.stdout),(self.error_reader,self.process.stderr)):
                if not thread.is_alive():
                    try:stream.close()
                    except (OSError,ValueError):pass
            self.cleanup_complete=True
        finally:self.close_lock.release()
