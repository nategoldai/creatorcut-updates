import io
import json
import sys
import tempfile
import threading
import unittest
import urllib.error
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from editkit import native_actions,native_receiver,util


class NativeReceiverTests(unittest.TestCase):
    def test_initial_server_metadata_can_arrive_after_wait_starts(self):
        with tempfile.TemporaryDirectory() as directory,patch.object(util,'STUDIO_OUT',Path(directory)):
            original_read=util.read_json
            reads=[]
            def read(path,*args,**kwargs):
                reads.append(path)
                if path==util.STUDIO_OUT/'server.json' and not path.exists():
                    util.write_json(path,{'port':4338})
                    util.write_json(util.STUDIO_OUT/'native-agent.json',{'key':'key','api_token':'token'})
                    raise util.Fail('Studio is still writing its startup metadata')
                return original_read(path,*args,**kwargs)
            def connection(req,**kwargs):
                result={'action':{'request_id':'one','project':'existing','text':'Actual action'}} if req.full_url.endswith('/receive') else {'accepted':True}
                return io.BytesIO(json.dumps(result).encode())
            with patch.object(util,'read_json',side_effect=read),patch.object(native_receiver.urllib.request,'urlopen',side_effect=connection):
                result=native_receiver.wait(2,'current')
            self.assertTrue(result['receipt']['accepted'])
            self.assertGreaterEqual(reads.count(util.STUDIO_OUT/'server.json'),3)

    def test_active_wait_recovers_changed_server_port_and_credentials(self):
        with tempfile.TemporaryDirectory() as directory,patch.object(util,'STUDIO_OUT',Path(directory)):
            util.write_json(util.STUDIO_OUT/'server.json',{'port':4338})
            util.write_json(util.STUDIO_OUT/'native-agent.json',{'key':'old-key','api_token':'old-token'})
            requests=[]
            def connection(req,**kwargs):
                requests.append(req)
                if len(requests)==1:
                    util.write_json(util.STUDIO_OUT/'server.json',{'port':4339})
                    util.write_json(util.STUDIO_OUT/'native-agent.json',{'key':'new-key','api_token':'new-token'})
                    raise urllib.error.URLError('server restarting')
                if req.full_url.endswith('/receive'):
                    return io.BytesIO(json.dumps({'action':{'request_id':'one','project':'existing','text':'Actual action'}}).encode())
                return io.BytesIO(json.dumps({'accepted':True}).encode())
            with patch.object(native_receiver.urllib.request,'urlopen',side_effect=connection):
                result=native_receiver.wait(2,'current')
            self.assertTrue(result['receipt']['accepted'])
            self.assertEqual(len(requests),3)
            self.assertIn(':4339/',requests[1].full_url)
            self.assertEqual(requests[1].get_header('X-aie-token'),'new-token')
            self.assertEqual(requests[1].get_header('X-creatorcut-agent'),'new-key')

    def test_cancel_during_reconnect_finishes_without_acknowledging(self):
        with tempfile.TemporaryDirectory() as directory,patch.object(util,'STUDIO_OUT',Path(directory)):
            util.write_json(util.STUDIO_OUT/'server.json',{'port':4338})
            util.write_json(util.STUDIO_OUT/'native-agent.json',{'key':'key','api_token':'token'})
            cancelled=threading.Event();calls=[]
            def connection(req,**kwargs):
                calls.append(req);cancelled.set()
                raise urllib.error.URLError('server restarting')
            with patch.object(native_receiver.urllib.request,'urlopen',side_effect=connection):
                result=native_receiver.wait(2,'current',cancelled)
            self.assertEqual(result['state'],'cancelled')
            self.assertEqual(len(calls),1)

    def test_cancelled_native_turn_never_acknowledges_a_late_action(self):
        with tempfile.TemporaryDirectory() as directory,patch.object(util,'STUDIO_OUT',Path(directory)):
            util.write_json(util.STUDIO_OUT/'server.json',{'port':4338})
            util.write_json(util.STUDIO_OUT/'native-agent.json',{'key':'fixture','api_token':'fixture'})
            cancelled=threading.Event();calls=[]
            def connection(req,**kwargs):
                calls.append(req);cancelled.set()
                return io.BytesIO(json.dumps({'action':{'request_id':'late','text':'Late request'}}).encode())
            with patch.object(native_receiver.urllib.request,'urlopen',side_effect=connection):
                result=native_receiver.wait(1,'current',cancelled)
            self.assertEqual(result,{'native_action':None,'state':'cancelled'})
            self.assertEqual(len(calls),1)

    def test_received_action_is_not_lost_when_acknowledgement_disconnects(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(util,'STUDIO_OUT',Path(directory)):
            util.write_json(util.STUDIO_OUT/'server.json',{'port':4338})
            util.write_json(util.STUDIO_OUT/'native-agent.json',{'key':'fixture','api_token':'fixture'})
            requests=[]
            def connection(req,**kwargs):
                requests.append(req)
                if req.full_url.endswith('/receive'):
                    return io.BytesIO(json.dumps({'action':{'request_id':'one','project':'existing','text':'Actual action'}}).encode())
                raise urllib.error.URLError('ack connection interrupted')
            with patch.object(native_receiver.urllib.request,'urlopen',side_effect=connection):
                result=native_receiver.wait(1,'same-conversation')
            self.assertEqual(result['native_action']['text'],'Actual action')
            self.assertEqual(result['native_action']['state'],'receipt_unconfirmed')
            self.assertFalse(result['receipt']['accepted'])
            self.assertEqual(len(requests),2)
            self.assertEqual(json.loads(requests[0].data)['receiver'],'same-conversation')

    def test_agent_key_is_private_and_not_a_browser_api_token(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(util,'STUDIO_OUT',Path(directory)):
            native_actions.write_agent_key('browser-token')
            path=util.STUDIO_OUT/'native-agent.json'
            self.assertEqual(path.stat().st_mode & 0o077,0)
            self.assertTrue(native_actions.authorized(json.loads(path.read_text())['key']))
            self.assertFalse(native_actions.authorized('browser-token'))


if __name__=='__main__':unittest.main()
