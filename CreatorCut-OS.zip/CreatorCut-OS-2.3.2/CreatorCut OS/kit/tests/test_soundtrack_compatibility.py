import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from editkit import soundtrack,util


class SoundtrackCompatibility(unittest.TestCase):
    def test_old_and_current_ffmpeg_receive_supported_filter_file_arguments(self):
        for major,option in [(6,'-filter_complex_script'),(7,'-/filter_complex'),(9,'-/filter_complex')]:
            with self.subTest(major=major),tempfile.TemporaryDirectory() as directory:
                project=Path(directory)
                (project/'cut.mp4').write_bytes(b'voice fixture')
                raw=project/'visual.mp4';raw.write_bytes(b'visual fixture')
                dest=project/'render/candidate.mp4';calls=[]
                def render(cmd,**kwargs):
                    calls.append(cmd)
                    Path(cmd[-1]).write_bytes(b'complete result')
                with patch.object(util,'probe',return_value={'has_audio':True}),patch.object(util,'ffmpeg_bin',return_value='ffmpeg'),patch.object(util,'ffmpeg_major',return_value=major),patch.object(util,'run',side_effect=render):
                    soundtrack.mix(project,raw,dest,{'duration':1,'background':{'src':'cut.mp4'},'audio':{}})
                self.assertIn(option,calls[0])
                if major>=7:self.assertNotIn('-filter_complex_script',calls[0])
                self.assertEqual(dest.read_bytes(),b'complete result')
                self.assertFalse((project/'render/candidate.partial.mp4').exists())
                self.assertFalse((project/'render/mixed.wav').exists())


if __name__=='__main__':unittest.main()
