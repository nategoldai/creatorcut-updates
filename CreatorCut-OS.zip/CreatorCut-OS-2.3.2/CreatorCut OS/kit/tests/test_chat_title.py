import sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from editkit import util,chat_title
class ChatTitleTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);x=patch.object(util,'BRAND',Path(self.tmp.name));x.start();self.addCleanup(x.stop)
 def test_initial_install_title(self):self.assertEqual(chat_title.decision('codex','one','Install'),'rename')
 def test_custom_title_is_not_replaced(self):self.assertEqual(chat_title.decision('codex','one','My launch video'),'keep_custom')
 def test_manual_rename_after_setup_is_preserved(self):
  chat_title.record('codex','one','renamed');self.assertEqual(chat_title.decision('codex','one','My videos'),'keep')
 def test_another_chat_keeps_its_own_state(self):
  chat_title.record('codex','one','renamed');self.assertEqual(chat_title.decision('codex','two','Install'),'rename')
 def test_unknown_title_does_not_guess(self):self.assertEqual(chat_title.decision('codex','one',None),'inspect_host_title')

class TaskClockTests(unittest.TestCase):
 def test_lease_refresh_and_reenter_keep_original_start(self):
  from editkit import workflow
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp);a=workflow.claim(p,'session','planning');b=workflow.claim(p,'session','building')
   self.assertEqual(a['started'],b['started']);self.assertEqual(workflow.state(p)['started'],a['started'])
