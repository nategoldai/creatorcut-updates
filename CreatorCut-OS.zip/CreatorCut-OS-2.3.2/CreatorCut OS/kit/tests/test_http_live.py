"""Live local integration probe: python kit/tests/test_http_live.py --url http://localhost:4331
Uses generated fixture only. The temporary project is moved to Studio trash afterwards.
"""
import argparse,json,re,time
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.error import HTTPError

def run(base):
    html=urlopen(base+'/',timeout=10).read().decode()
    token=json.loads(re.search(r'window.AIE_SERVER = (.*?);',html).group(1))['token']
    headers={'X-AIE-Token':token,'Content-Type':'application/json'}
    def call(path,data=None,extra=None):
        body=json.dumps(data).encode() if data is not None else None
        return json.loads(urlopen(Request(base+path,data=body,headers=dict(headers,**(extra or {}))),timeout=30).read())
    try:
        urlopen(base+'/api/state',timeout=10)
        raise AssertionError('Unauthenticated state was exposed')
    except HTTPError as e:assert e.code==403
    pid=call('/api/videos/new',{'title':'HTTP integration test'})['project']
    try:
        # A user cannot start an edit without footage.
        try:
            call('/api/videos/create',{'project':pid});raise AssertionError('Missing footage accepted')
        except HTTPError as e:assert e.code==400
        root=Path(__file__).resolve().parents[2]
        fixture=(root/'kit/samples/approved-reel.mp4').read_bytes()
        req=Request(base+'/api/upload?kind=raw&project='+pid,data=fixture,headers={**headers,'X-Filename':'test.mp4','Content-Type':'application/octet-stream'})
        assert json.loads(urlopen(req,timeout=30).read())['ok']
        for path,payload in [('/api/videos/create',{'project':pid}),('/api/videos/chat',{'project':pid,'text':'Is this working?'})]:
            try:
                call(path,payload);raise AssertionError('Legacy chat request accepted')
            except HTTPError as e:assert e.code==400
        data=call('/api/state');p=next(p for p in data['projects'] if p['name']==pid)
        assert data['conversation_mode']=='native_chat_alongside'
        assert p['status']=='draft'
        assert not p.get('preview') and not p.get('latest')
        assert not any(e['type'] in {'video.create','studio.chat'} and e.get('payload',{}).get('project')==pid for e in call('/api/events')['events'])
        started=call('/api/videos/start',{'project':pid})
        assert started['ok'] and started.get('job')
        duplicate=call('/api/videos/start',{'project':pid});assert duplicate['ok']
        deadline=time.monotonic()+20
        while time.monotonic()<deadline:
            job=call('/api/jobs/'+started['job']['id'])
            if job.get('state') in ('done','error'):break
            time.sleep(.1)
        state=call('/api/state');prepared=next(p for p in state['projects'] if p['name']==pid)
        assert prepared['preparation']['state']=='ready',str(job)
        assert prepared['status']=='awaiting_editor'
        return {'ok':True,'checks':['authenticated API','raw upload','native conversation mode','legacy chat/create rejected without queueing','uploaded draft preserved','Make starts real footage preparation without a second AI','completed preparation requests native-chat continuation'],'personal_media':False}
    finally:call('/api/videos/delete',{'project':pid})

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--url',default='http://localhost:4331');args=a.parse_args()
    print(json.dumps(run(args.url),indent=2))
