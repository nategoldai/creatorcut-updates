"""Malformed or stalled request bodies must fail rather than hold a worker forever."""
import io
import unittest
from unittest.mock import Mock
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from editkit import server,util

class RequestBounds(unittest.TestCase):
    def handler(self,length='2',body=b'{}'):
        h=object.__new__(server.Handler)
        h.headers={'Content-Length':length}
        h.rfile=io.BytesIO(body)
        h.close_connection=False
        return h
    def test_negative_or_invalid_lengths_rejected_without_reading(self):
        for raw in ['-1','abc','1.5','9'*30]:
            h=self.handler(raw);h.rfile=Mock()
            with self.assertRaises(util.Fail):h._body_json()
            h.rfile.read.assert_not_called()
            self.assertTrue(h.close_connection)
    def test_oversized_and_encoded_body_rejected_before_read(self):
        for headers in [{'Content-Length':'2000001'},{'Content-Length':'2','Transfer-Encoding':'chunked'}]:
            h=self.handler();h.headers=headers;h.rfile=Mock()
            with self.assertRaises(util.Fail):h._body_json()
            h.rfile.read.assert_not_called()
            self.assertTrue(h.close_connection)
    def test_stalled_body_becomes_actionable_error(self):
        h=self.handler();h.rfile=Mock();h.rfile.read.side_effect=TimeoutError()
        with self.assertRaisesRegex(util.Fail,'stopped sending'):h._body_json()
        self.assertTrue(h.close_connection)
    def test_truncated_body_rejected_and_normal_object_survives(self):
        h=self.handler('10',b'{}')
        with self.assertRaisesRegex(util.Fail,'ended before'):h._body_json()
        self.assertTrue(h.close_connection)
        self.assertEqual(self.handler()._body_json(),{})

    def test_missing_probe_tool_preserves_uploaded_copy(self):
        import tempfile
        from unittest.mock import patch
        from editkit import videos
        with tempfile.TemporaryDirectory() as tmp:
            project=Path(tmp)/'demo';project.mkdir()
            (project/'project.json').write_text('{"name":"demo"}')
            clip=project/'upload.mp4';clip.write_bytes(b'fixture')
            with patch.object(util,'PROJECTS',Path(tmp)),patch.object(util,'ffprobe_bin',side_effect=util.Fail('ffprobe is missing')):
                with self.assertRaisesRegex(util.Fail,'ffprobe is missing'):videos.add_media('demo',clip,'raw','upload.mp4')
            self.assertEqual(clip.read_bytes(),b'fixture')

if __name__=='__main__':unittest.main()
