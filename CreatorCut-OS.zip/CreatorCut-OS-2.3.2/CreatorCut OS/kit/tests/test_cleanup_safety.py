import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from editkit import jobs,server,util


class CleanupSafety(unittest.TestCase):
    def setUp(self):
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup)
        self.root=Path(temp.name);self.project=self.root/'kit/projects/finished'
        (self.project/'media').mkdir(parents=True)
        for key,value in {'ROOT':self.root,'KIT':self.root/'kit','PROJECTS':self.root/'kit/projects'}.items():
            p=patch.object(util,key,value);p.start();self.addCleanup(p.stop)
        p=patch.object(jobs,'has_active',return_value=False);p.start();self.addCleanup(p.stop)
        util.write_json(self.project/'project.json',{'name':'finished','status':'finished'})
        for name in ['cut.mp4','preview.mp4','media/original.mp4','media/joined.mp4']:
            (self.project/name).write_bytes(name.encode())

    def test_cleanup_cannot_delete_under_a_native_revision(self):
        util.write_json(self.project/'workflow.json',{'phase':'building','owner':'native','lease_until':time.time()+60})
        with self.assertRaises(util.Fail):server.clean_storage()
        self.assertTrue((self.project/'cut.mp4').exists())
        self.assertEqual((self.project/'preview.mp4').read_bytes(),b'preview.mp4')

    def test_idle_cleanup_preserves_source_and_approved_preview(self):
        server.clean_storage()
        self.assertFalse((self.project/'cut.mp4').exists())
        self.assertFalse((self.project/'media/joined.mp4').exists())
        self.assertEqual((self.project/'media/original.mp4').read_bytes(),b'media/original.mp4')
        self.assertEqual((self.project/'preview.mp4').read_bytes(),b'preview.mp4')


if __name__=='__main__':unittest.main()
