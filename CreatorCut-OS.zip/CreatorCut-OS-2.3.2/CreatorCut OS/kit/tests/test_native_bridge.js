// Execute the actual child + MCP wrapper against a deterministic host simulator.
// No model or external service is substituted in the shipped application.
const fs = require('fs'), vm = require('vm'), assert = require('assert');
const path = require('path');
const dir = path.join(__dirname, '../studio/app');
const nonce = 'test-session', origin = 'http://localhost:4317';
const flush = () => new Promise(resolve => setImmediate(resolve));
async function fixture(mode='ok') {
  const wListeners=[], cListeners=[], timers=[], calls=[];
  let child,wrapper,host;
  const schedule = fn => queueMicrotask(fn);
  const timer = (fn,ms) => { const t={fn,ms,active:true};timers.push(t);return t; };
  const clear = t => { if(t)t.active=false; };
  const nativeOrigin = mode==='opaque'?'null':'https://native.example';
  host = { postMessage(m, target) {
    if(mode==='opaque') assert.notEqual(target,'null');
    calls.push(m);
    if(m.method==='ui/initialize') schedule(()=>wListeners.forEach(f=>f({source:host,origin:nativeOrigin,data:{jsonrpc:'2.0',id:m.id,result:{hostCapabilities:mode==='unsupported'?{}:{message:{text:{}}}}}})));
    if(m.method==='ui/message' && mode!=='timeout') schedule(()=>wListeners.forEach(f=>f({source:host,origin:nativeOrigin,data:{jsonrpc:'2.0',id:m.id,result:mode==='reject'?{isError:true}:{}}})));
  }};
  child={ postMessage(m){schedule(()=>cListeners.forEach(f=>f({source:wrapper,origin:'https://native.example',data:m})));} };
  wrapper={postMessage(m){schedule(()=>wListeners.forEach(f=>f({source:child,origin,data:m})));}};
  const frame={contentWindow:child,addEventListener:()=>{}};
  const w={parent:host,CREATORCUT_EMBED:{url:origin+'/?cc_embed='+nonce,nonce},addEventListener:(type,fn)=>wListeners.push(fn)};
  vm.runInNewContext(fs.readFileSync(path.join(dir,'native-host.js'),'utf8'),{window:w,document:{getElementById:()=>frame},URL,setTimeout:timer,clearTimeout:clear,console});
  const A={render:()=>{}};
  const c={parent:wrapper,AIE:A,addEventListener:(type,fn)=>cListeners.push(fn)};
  vm.runInNewContext(fs.readFileSync(path.join(dir,'native-chat.js'),'utf8'),{window:c,location:{search:'?cc_embed='+nonce},URLSearchParams,Map,setTimeout:timer,clearTimeout:clear,setInterval:timer,clearInterval:clear,console});
  await flush();await flush();
  return {A,calls,timers,cListeners,wListeners,child,wrapper,host,setMode:value=>{mode=value;}};
}
(async()=>{
  let f=await fixture();assert.equal(f.A.nativeChat.available,true);
  const r=await f.A.nativeChat.send('project1','What is happening?');assert.equal(r.accepted,true);
  const msg=f.calls.filter(x=>x.method==='ui/message');assert.equal(msg.length,1);assert(msg[0].params.content[0].text.includes('What is happening?'));
  assert.equal(msg[0].params.role,'user');
  f=await fixture('opaque');assert.equal((await f.A.nativeChat.send('project1','Opaque sandbox')).accepted,true);
  f=await fixture('unsupported');assert.equal(f.A.nativeChat.available,false);
  await assert.rejects(f.A.nativeChat.send('project1','Hello'));assert.equal(f.calls.filter(x=>x.method==='ui/message').length,0);
  f=await fixture('reject');await assert.rejects(f.A.nativeChat.send('project1','Keep this draft'));assert.equal(f.A.nativeChat.pending,false);
  f=await fixture('timeout');const pending=f.A.nativeChat.send('project1','During a render');
  await flush();
  await assert.rejects(f.A.nativeChat.send('project1','Second concurrent send'));
  for(const t of f.timers.filter(x=>x.active&&x.ms===15000)){t.fn();t.active=false;}
  await assert.rejects(pending);assert.equal(f.A.nativeChat.uncertain,true);
  await assert.rejects(f.A.nativeChat.send('project1','Retry without checking'));
  assert.equal(f.calls.filter(x=>x.method==='ui/message').length,1);
  f.setMode('ok');
  assert.equal((await f.A.nativeChat.send('project2','A different saved project')).accepted,true);
  assert.equal(f.A.nativeChat.uncertain,true);
  f.A.nativeChat.confirmStarted('project2');
  await assert.rejects(f.A.nativeChat.send('project1','Still unresolved'));
  f.A.nativeChat.confirmStarted('project1');assert.equal(f.A.nativeChat.uncertain,false);
  assert.equal((await f.A.nativeChat.send('project1','Revision after confirmed start')).accepted,true);
  f=await fixture('unsupported');f.cListeners.forEach(fn=>fn({source:{},origin:'https://attacker.example',data:{type:'creatorcut:capability',nonce,available:true}}));assert.equal(f.A.nativeChat.available,false);
  console.log('PASS: actual bridge scripts: same-conversation send, capability gating, rejection, timeout uncertainty, no duplicate retry, project-scoped uncertainty, actual-start confirmation recovery, spoof rejection. Host is simulated; native provider behavior is not claimed.');
})().catch(e=>{console.error(e);process.exitCode=1;});
