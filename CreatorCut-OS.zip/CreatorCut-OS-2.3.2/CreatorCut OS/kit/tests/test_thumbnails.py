import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from editkit import thumbnails, util


class ThumbnailTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        for key, value in {'ROOT':self.root,'STUDIO_OUT':self.root/'runtime'}.items():
            p = patch.object(util,key,value);p.start();self.addCleanup(p.stop)
        self.video=self.root/'input.mp4';self.video.write_bytes(b'video fixture')

    def test_slow_extraction_does_not_block_state_and_cache_persists(self):
        entered=threading.Event();release=threading.Event();done=threading.Event()
        calls=[]
        def slow(cmd,**kw):
            calls.append(cmd);entered.set();release.wait(2)
            Path(cmd[-1]).write_bytes(b'jpeg');done.set()
        with patch.object(util,'run',side_effect=slow),patch.object(util,'ffmpeg_bin',return_value='ffmpeg'):
            try:
                started=time.monotonic()
                self.assertIsNone(thumbnails.cached(self.video))
                self.assertLess(time.monotonic()-started,.15)
                self.assertTrue(entered.wait(1))
                for _ in range(10):self.assertIsNone(thumbnails.cached(self.video))
                self.assertEqual(len(calls),1)
            finally:release.set()
            self.assertTrue(done.wait(1))
            until=time.monotonic()+1;frame=None
            while frame is None and time.monotonic()<until:
                frame=thumbnails.cached(self.video);time.sleep(.002)
            self.assertIsNotNone(frame)
            self.assertEqual(thumbnails.cached(self.video),frame)
        self.assertEqual(self.video.read_bytes(),b'video fixture')

    def test_updated_video_gets_new_frame_and_missing_outside_files_are_ignored(self):
        complete=threading.Event()
        def extract(cmd,**kw):Path(cmd[-1]).write_bytes(b'jpeg');complete.set()
        with patch.object(util,'run',side_effect=extract),patch.object(util,'ffmpeg_bin',return_value='ffmpeg'):
            thumbnails.cached(self.video);self.assertTrue(complete.wait(1))
            time.sleep(.01);first=thumbnails.cached(self.video)
            self.assertIsNotNone(first)
            complete.clear();self.video.write_bytes(b'new video data')
            self.assertIsNone(thumbnails.cached(self.video));self.assertTrue(complete.wait(1))
            time.sleep(.01);second=thumbnails.cached(self.video)
            self.assertNotEqual(first,second)
        self.assertIsNone(thumbnails.cached(self.root/'missing.mp4'))
        self.assertIsNone(thumbnails.cached(Path('/etc/hosts')))


if __name__=='__main__':unittest.main()
