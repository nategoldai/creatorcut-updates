import sys,tempfile,unittest,json,subprocess,os
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from editkit import util,native_app,events,server,videos

class NativeAppTests(unittest.TestCase):
    def setUp(self):
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup);self.root=Path(temp.name)
        self.p=self.root/'projects/demo';self.p.mkdir(parents=True)
        from editkit import learn
        for k,v in {'BRAND':self.root/'my-brand','PROFILE':self.root/'my-brand/profile.json','USER_STYLES_DIR':self.root/'my-brand/styles'}.items():
            x=patch.object(util,k,v);x.start();self.addCleanup(x.stop)
        x=patch.object(learn,'FILE',self.root/'my-brand/learned.json');x.start();self.addCleanup(x.stop)
        for k,v in {'ROOT':self.root,'PROJECTS':self.root/'projects','STUDIO_OUT':self.root/'runtime'}.items():
            p=patch.object(util,k,v);p.start();self.addCleanup(p.stop)
        for k,v in {'EVENTS':util.STUDIO_OUT/'events.jsonl','HANDLED':util.STUDIO_OUT/'events.handled'}.items():
            p=patch.object(events,k,v);p.start();self.addCleanup(p.stop)
        util.write_json(self.p/'project.json',{'name':'demo','style':'clean'})
    def test_reply_is_only_actual_provided_text_without_an_event(self):
        native_app.call_tool('creatorcut_reply',{'project':'demo','text':'I am checking the cut.','reply_id':'answer1'})
        chat=videos.chat('demo');self.assertEqual(chat[0]['text'],'I am checking the cut.');self.assertTrue(chat[0]['native'])
        self.assertEqual(events.pending(),[])
    def test_repeat_tool_delivery_does_not_duplicate_answer(self):
        args={'project':'demo','text':'A reply','reply_id':'answer1'}
        native_app.call_tool('creatorcut_reply',args);native_app.call_tool('creatorcut_reply',args)
        self.assertEqual(len(videos.chat('demo')),1)
    def test_mirror_user_does_not_queue_inference_or_alter_workflow(self):
        util.write_json(self.p/'workflow.json',{'phase':'building','owner':'current','lease_until':99999999999})
        before=(self.p/'workflow.json').read_bytes()
        server.api_videos('/api/videos/mirror-user',{'project':'demo','text':'Question accepted by host'})
        self.assertEqual((self.p/'workflow.json').read_bytes(),before);self.assertEqual(events.pending(),[])
    def test_empty_actual_reply_rejected(self):
        with self.assertRaises(util.Fail):native_app.call_tool('creatorcut_reply',{'project':'demo','text':''})
    def test_grant_is_local_and_expires(self):
        with self.assertRaises(util.Fail):native_app.grant('https://external.example')
        n=native_app.grant('http://localhost:4317');self.assertGreater(len(n),30)
        self.assertIn('expires',util.read_json(util.STUDIO_OUT/'embed-grants.json')[n])
    def test_project_registration_preserves_other_servers(self):
        util.write_json(self.root/'.mcp.json',{'mcpServers':{'other':{'command':'existing'}}})
        (self.root/'.codex').mkdir();(self.root/'.codex/config.toml').write_text('model = "existing-model"\n')
        native_app.configure();native_app.configure()
        self.assertEqual(util.read_json(self.root/'.mcp.json')['mcpServers']['other']['command'],'existing')
        s=(self.root/'.codex/config.toml').read_text();self.assertIn('existing-model',s);self.assertEqual(s.count('[mcp_servers.creatorcut]'),1)
    def test_registration_uses_actual_host_project_not_app_folder(self):
        host=self.root/'host';host.mkdir()
        result=native_app.configure(host)
        self.assertTrue((host/'.codex/config.toml').exists())
        self.assertFalse((self.root/'.codex/config.toml').exists())
        self.assertFalse(result['connected'])
        self.assertEqual(result['project'],str(host.resolve()))
    def test_invalid_existing_codex_config_keeps_both_files_unchanged(self):
        util.write_json(self.root/'.mcp.json',{'mcpServers':{'other':{'command':'existing'}}})
        f=self.root/'.mcp.json';before=f.read_bytes()
        (self.root/'.codex').mkdir();(self.root/'.codex/config.toml').write_text('[invalid')
        with self.assertRaises(Exception):native_app.configure()
        self.assertEqual(f.read_bytes(),before)
    def test_registration_does_not_write_global_home_config(self):
        with self.assertRaises(util.Fail):native_app.configure(Path.home())
    def test_detailed_brief_keeps_more_than_four_thousand_characters(self):
        text='Show the exact interface on each spoken command. '*250
        videos.set_brief('demo',{'prompt':text})
        self.assertEqual(videos.load('demo')['brief']['prompt'],text)
    def test_empty_brief_does_not_inject_example_style(self):
        videos.set_brief('demo',{'prompt':''})
        self.assertEqual(videos.load('demo')['brief']['prompt'],'')
    def test_native_mirror_does_not_wait_for_render_lock(self):
        with util.project_lock(self.p):
            videos.say('demo','editor','Reply while render is locked',native=True)
        self.assertEqual(len(videos.chat('demo')),1)
    def test_concurrent_user_and_editor_processes_do_not_lose_mirror_entries(self):
        script="""import sys
from pathlib import Path
from editkit import util,videos
util.ROOT=Path(sys.argv[1]);util.PROJECTS=util.ROOT/'projects'
for n in range(15):videos.say('demo','editor',sys.argv[2]+str(n),native=True)
"""
        env=dict(os.environ,PYTHONPATH=str(Path(__file__).resolve().parents[1]))
        children=[subprocess.Popen([sys.executable,'-c',script,str(self.root),str(k)+'-'],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE) for k in range(4)]
        for c in children:
            out,err=c.communicate(timeout=10);self.assertEqual(c.returncode,0,err.decode())
        self.assertEqual(len(videos.chat('demo')),60)
    def test_tool_metadata_uses_native_app_resource(self):
        t=next(x for x in native_app.tools() if x['name']=='creatorcut_studio')
        self.assertEqual(t['_meta']['ui']['resourceUri'],native_app.URI)
    def test_tools_do_not_start_another_session(self):
        result=native_app.handle({'method':'initialize','params':{'protocolVersion':'2025-06-18'}})
        self.assertIn('current native conversation',result['instructions'])
        self.assertNotIn('sampling',result['capabilities'])

if __name__=='__main__':unittest.main()
