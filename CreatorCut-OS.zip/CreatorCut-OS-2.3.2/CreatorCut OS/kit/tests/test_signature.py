"""Behavioral checks for default routing and explicit style overrides."""
import json,sys,tempfile,unittest,copy
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from editkit import signature,util,workflow,styles

class SignatureTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.p=Path(self.tmp.name)
  util.write_json(self.p/'project.json',{'style':signature.ID,'brief':{'prompt':'My video'}})
  util.write_json(self.p/'words.json',{'duration':2,'words':[{'w':'Watch','start':0,'end':.3},{'w':'this','start':.35,'end':.6},{'w':'animation.','start':.7,'end':1.0},{'w':'Now','start':1.5,'end':1.8}]})
 def test_partial_reference_keeps_clear_choice_fills_unknown(self):
  d=signature.resolve({'reference':{'styles':{'caption':{'colour':'#123456'}}}})
  self.assertEqual(d['effective']['styles']['caption']['colour'],'#123456');self.assertEqual(d['sources']['styles.caption.colour'],'reference')
  self.assertEqual(d['effective']['fonts']['caption']['family'],'Inter Tight');self.assertEqual(d['sources']['fonts.caption.family'],'default')
 def test_precedence_and_negative_choices(self):
  d=signature.resolve({'memory':{'sound':{'effects':True}},'preset':{'sound':{'effects':False}},'reference':{'sound':{'effects':True}},'brief':{'sound':{'effects':False},'layout':{'behind_person':False}}})
  self.assertIs(d['effective']['sound']['effects'],False);self.assertEqual(d['sources']['sound.effects'],'brief');self.assertIs(d['effective']['layout']['behind_person'],False)
 def test_resolver_does_not_mutate_inputs(self):
  i={'reference':{'styles':{'caption':{'size':.06}}}};before=copy.deepcopy(i);signature.resolve(i);self.assertEqual(i,before)
 def test_direction_is_not_learning(self):
  marker=self.p/'learned.json';marker.write_text('unchanged');d=signature.write_direction(self.p)
  self.assertFalse(d['is_customer_preference']);self.assertEqual(marker.read_text(),'unchanged');self.assertFalse((self.p/'customer-memory.json').exists())
 def test_caption_starter_has_real_times_accent_and_no_fake_assets(self):
  p=signature.seed(self.p,{'w':1080,'h':1920,'fps':30},2)
  self.assertGreater(len(p['items']),0);self.assertTrue(any(w['style']=='accent' for i in p['items'] for w in i['words']))
  self.assertTrue(all(0<=i['t0']<i['t1']<=2 for i in p['items']));self.assertNotIn('person_cutout',p);self.assertEqual(p['audio']['events'],[])
 def test_no_caption_request_removes_starter_captions(self):
  util.write_json(self.p/'style-inputs.json',{'brief':{'captions':{'enabled':False}}})
  self.assertEqual(signature.seed(self.p,{'w':1080,'h':1920,'fps':30},2)['items'],[])
 def test_cut_boundary_never_holds_old_text(self):
  util.write_json(self.p/'segments.json',{'segments':[{'start':0},{'start':.7}]})
  items=signature.seed(self.p,{'w':1080,'h':1920,'fps':30},2)['items']
  self.assertFalse(any(i['t0']<.7<i['t1'] for i in items))
 def test_behind_requires_real_cutout_and_stable_measured_position(self):
  good=[.38,.38,.385]
  self.assertTrue(signature.emphasis_item('Create',0,1,good,True)['behind'])
  self.assertFalse(signature.emphasis_item('Create',0,1,good,False)['behind'])
  self.assertFalse(signature.emphasis_item('Create',0,1,[.38,.48,.4],True)['behind'])
  self.assertFalse(signature.emphasis_item('Create',0,1,[.15,.15,.15],True)['behind'])
 def test_explicit_foreground_wins_even_with_good_mask(self):
  self.assertFalse(signature.emphasis_item('Create',0,1,[.38]*3,True,allow_behind=False)['behind'])
 def test_style_inputs_are_bound_to_review(self):
  self.assertIn('style-inputs.json',workflow.INPUTS);self.assertIn('style-direction.json',workflow.INPUTS)
 def test_selected_clean_preset_does_not_silently_get_signature_font(self):
  util.write_json(self.p/'project.json',{'style':'clean','brief':{}})
  d=signature.write_direction(self.p)
  self.assertEqual(d['sources']['fonts.caption.family'],'preset');self.assertNotEqual(d['effective']['fonts']['caption']['family'],'Inter Tight')
 def test_partial_kit_keeps_measured_colour_and_no_motion(self):
  k=signature.complete_kit({'styles':{'main':{'colour':'#001122','anim':{'ease':'cut','ms':1}}}})
  self.assertEqual(k['styles']['main']['colour'],'#001122');self.assertEqual(k['styles']['main']['anim']['ease'],'cut')
  self.assertEqual(k['styles']['main']['font']['family'],'Inter Tight');self.assertEqual(len(k['styles']),1)
 def test_unresolved_specific_font_does_not_get_wrong_file(self):
  with self.assertRaises(util.Fail):signature.complete_kit({'styles':{'main':{'font':{'family':'Specific'}}}})
 def test_empty_kit_is_not_a_measured_reference(self):
  with self.assertRaises(util.Fail):signature.complete_kit({'styles':{}})
 def test_font_is_shipped(self):
  d=signature.base()['fonts']['caption'];self.assertTrue((util.ROOT/d['file']).is_file())
  self.assertTrue((util.FONTS_DIR/'licenses/InterTight-OFL.txt').is_file())

if __name__=='__main__':unittest.main()
