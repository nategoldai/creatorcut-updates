import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from editkit import cli,util,videos


class StartupSafety(unittest.TestCase):
    def setUp(self):
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup)
        self.root=Path(temp.name);self.project=self.root/'projects/demo'
        (self.project/'media').mkdir(parents=True)
        for key,value in {'ROOT':self.root,'PROJECTS':self.root/'projects','STUDIO_OUT':self.root/'runtime'}.items():
            p=patch.object(util,key,value);p.start();self.addCleanup(p.stop)

    def config(self,count):
        media=[]
        for n in range(count):
            file=self.project/'media'/f'{n}.mp4';file.write_bytes(b'original')
            media.append({'id':str(n),'kind':'raw','file':str(file.relative_to(self.root))})
        util.write_json(self.project/'project.json',{'name':'demo','status':'draft','media':media})

    def test_metadata_start_needs_less_space_but_render_keeps_its_reserve(self):
        self.config(1)
        self.assertLess(cli.minimum_free_bytes(SimpleNamespace(cmd='prepare',project='demo')),500_000_000)
        self.assertLess(cli.minimum_free_bytes(SimpleNamespace(cmd='new')),500_000_000)
        for cmd in ('cut','compose','render','cutout'):
            self.assertGreaterEqual(cli.minimum_free_bytes(SimpleNamespace(cmd=cmd)),2_500_000_000)
        self.config(2)
        self.assertGreaterEqual(cli.minimum_free_bytes(SimpleNamespace(cmd='prepare',project='demo')),2_500_000_000)

    def test_metadata_probe_has_a_short_bounded_deadline(self):
        file=self.root/'input.mp4';file.write_bytes(b'fixture')
        response={'streams':[{'codec_type':'video','width':540,'height':960,'avg_frame_rate':'30/1'}],'format':{'duration':'2'}}
        with patch.object(util,'ffprobe_bin',return_value='ffprobe'),patch.object(util,'run',return_value=SimpleNamespace(stdout=json.dumps(response))) as run:
            self.assertEqual(util.probe(file)['duration'],2)
            self.assertLessEqual(run.call_args.kwargs['timeout'],20)

    def test_failed_join_preserves_the_existing_source_and_removes_only_partial(self):
        self.config(2)
        joined=self.project/'media/joined.mp4';joined.write_bytes(b'previous good source')
        def fail(cmd,*args,**kwargs):
            Path(cmd[-1]).write_bytes(b'incomplete output')
            raise util.Fail('Injected encoder failure')
        info={'duration':1,'width':540,'height':960,'hdr':False,'has_audio':True}
        with patch.object(util,'probe',return_value=info),patch.object(util,'ffmpeg_bin',return_value='ffmpeg'),patch.object(util,'run_progress',side_effect=fail):
            with self.assertRaisesRegex(util.Fail,'Injected encoder failure'):
                videos.prepare('demo')
        self.assertEqual(joined.read_bytes(),b'previous good source')
        self.assertFalse(joined.with_name('joined.partial.mp4').exists())
        self.assertEqual(videos.load('demo')['status'],'draft')
        self.assertEqual((self.project/'media/0.mp4').read_bytes(),b'original')


if __name__=='__main__':unittest.main()
