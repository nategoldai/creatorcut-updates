"""Single-file GitHub delivery: protocol fixtures, real archive/install/preservation."""
import hashlib,json,sys,tempfile,unittest,zipfile,shutil
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from editkit import github_updates as gh,updater,util

class GithubUpdates(unittest.TestCase):
    def setUp(self):
        t=tempfile.TemporaryDirectory();self.addCleanup(t.cleanup);self.tmp=Path(t.name)
        self.root=self.tmp/'installed';(self.root/'kit').mkdir(parents=True)
        (self.root/'kit/VERSION').write_text('2.3.1')
        self.out=self.root/'kit/studio-out'
        for obj,key,value in [(util,'ROOT',self.root),(util,'KIT',self.root/'kit'),(util,'STUDIO_OUT',self.out),(updater,'CONFIG',self.root/'kit/update.json'),(updater,'STATE',self.out/'update.json'),(updater,'BACKUP',self.root/'kit/update-backup')]:
            p=patch.object(obj,key,value);p.start();self.addCleanup(p.stop)
        self.cfg={'github_repository':'publisher/creatorcut'}
        util.write_json(updater.CONFIG,self.cfg)
        self.package=self.tmp/'release.zip';self.make_package()
        self.meta={'type':'file','path':'CreatorCut-OS.zip','size':self.package.stat().st_size,'sha':gh._digest(self.package,'sha1',True),'download_url':'https://raw.githubusercontent.com/publisher/creatorcut/main/CreatorCut-OS.zip'}
        self.metadata=patch.object(gh,'_metadata',return_value=self.meta).start();self.addCleanup(patch.stopall)
        self.download=patch.object(gh,'_download',side_effect=lambda u,p,s:shutil.copyfile(self.package,p)).start()
    def make_package(self,version='2.3.2'):
        files={'edit.py':b'new code','kit/editkit/__init__.py':b'','kit/VERSION':version.encode()}
        files['kit/SHA256-MANIFEST.json']=json.dumps({k:hashlib.sha256(v).hexdigest() for k,v in files.items()}).encode()
        with zipfile.ZipFile(self.package,'w') as out:
            for rel,data in files.items():out.writestr('release/CreatorCut OS/'+rel,data)
    def test_detects_embedded_version_without_manifest_feed(self):
        result=updater.check()
        self.assertTrue(result['available']);self.assertEqual(result['latest'],'2.3.2')
        self.assertEqual(updater.current(),'2.3.1') # Checking is never installing.
    def test_same_blob_downloaded_only_once(self):
        gh.inspect(self.cfg);gh.inspect(self.cfg)
        self.assertEqual(self.download.call_count,1)
    def test_cache_tampering_is_redownloaded_and_verified(self):
        result=gh.inspect(self.cfg);p=Path(result['zip']);data=p.read_bytes();p.write_bytes(b'X'+data[1:])
        gh.inspect(self.cfg);self.assertEqual(self.download.call_count,2)
    def test_changed_blob_downloaded_and_version_read_again(self):
        gh.inspect(self.cfg);self.make_package('2.3.3')
        self.meta.update(size=self.package.stat().st_size,sha=gh._digest(self.package,'sha1',True))
        self.assertEqual(gh.inspect(self.cfg)['latest'],'2.3.3');self.assertEqual(self.download.call_count,2)
    def test_actual_install_preserves_memory_project_and_preset(self):
        sentinels=['my-brand/learned.json','my-brand/styles/mine.json','kit/projects/mine/project.json','.agents/skills/creator-preferences/SKILL.md']
        for rel in sentinels:
            p=self.root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('customer data')
        self.assertEqual(updater.apply(),'2.3.2')
        for rel in sentinels:self.assertEqual((self.root/rel).read_text(),'customer data')
    def test_mismatched_github_blob_rejected(self):
        self.meta['sha']='a'*40
        result=updater.check();self.assertFalse(result['available']);self.assertIn('error',result)
        self.assertEqual(updater.current(),'2.3.1')
    def test_wrong_download_host_rejected(self):
        self.meta['download_url']='https://example.com/CreatorCut-OS.zip'
        with self.assertRaises(util.Fail):gh.inspect(self.cfg)
        self.download.assert_not_called()
    def test_downgrade_not_offered(self):
        self.make_package('2.1.0');self.meta.update(size=self.package.stat().st_size,sha=gh._digest(self.package,'sha1',True))
        self.assertFalse(updater.check()['available'])
    def test_offline_is_not_reported_as_up_to_date(self):
        self.metadata.side_effect=OSError('offline')
        result=updater.check();self.assertFalse(result['available']);self.assertIn('error',result)
    def test_bad_manifest_rejected_even_with_valid_github_hash(self):
        with zipfile.ZipFile(self.package,'a') as z:z.writestr('release/CreatorCut OS/unlisted.txt','untrusted')
        self.meta.update(size=self.package.stat().st_size,sha=gh._digest(self.package,'sha1',True))
        with self.assertRaises(util.Fail):gh.inspect(self.cfg)
    def test_unsafe_archive_rejected(self):
        with zipfile.ZipFile(self.package,'a') as z:z.writestr('../escape','untrusted')
        self.meta.update(size=self.package.stat().st_size,sha=gh._digest(self.package,'sha1',True))
        with self.assertRaises(util.Fail):gh.inspect(self.cfg)
    def test_same_version_not_offered(self):
        self.make_package('2.3.1');self.meta.update(size=self.package.stat().st_size,sha=gh._digest(self.package,'sha1',True))
        self.assertFalse(updater.check()['available'])

if __name__=='__main__':unittest.main()
