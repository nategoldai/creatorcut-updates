import os
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from editkit import jobs,updater,util


class UpdateReadiness(unittest.TestCase):
    def test_active_job_outside_display_window_still_blocks_update(self):
        entries={str(n):{'id':str(n),'created':n,'state':'done'} for n in range(40)}
        entries['old']={'id':'old','created':-1,'state':'running'}
        with patch.object(jobs,'_jobs',entries):
            self.assertFalse(any(j['state']=='running' for j in jobs.all_jobs()))
            self.assertTrue(jobs.has_active())
            with self.assertRaises(util.Fail):updater.ensure_idle()

    def test_stale_update_file_is_not_an_active_transaction(self):
        with tempfile.TemporaryDirectory() as directory,patch.object(util,'KIT',Path(directory)):
            (util.KIT/'.update.guard').touch()
            self.assertFalse(updater.is_running())
            with util.file_guard(util.KIT/'.update.guard'):
                self.assertTrue(updater.is_running())
            self.assertFalse(updater.is_running())

    def test_native_edit_lease_blocks_update_even_without_a_background_job(self):
        with tempfile.TemporaryDirectory() as directory,patch.object(util,'KIT',Path(directory)),patch.object(jobs,'has_active',return_value=False):
            util.write_json(util.KIT/'projects/demo/workflow.json',{'phase':'building','owner':'native-session','lease_until':time.time()+60})
            with self.assertRaisesRegex(util.Fail,'current edit'):updater.ensure_idle()

    def test_missing_tools_without_an_installer_fail_instead_of_waiting_an_hour(self):
        with patch.object(jobs,'tools_ready',return_value=False),patch.object(jobs,'install_busy',return_value=False),patch.object(jobs.time,'sleep') as sleep:
            with self.assertRaisesRegex(util.Fail,'tools are not ready'):
                jobs._wait_ready('fixture','tools')
            sleep.assert_not_called()

    def test_actual_install_can_finish_and_release_waiting_work(self):
        with patch.object(jobs,'tools_ready',side_effect=[False,True]),patch.object(jobs,'install_busy',return_value=True),patch.object(jobs,'update'),patch.object(jobs.time,'sleep') as sleep:
            jobs._wait_ready('fixture','tools')
            sleep.assert_called_once_with(2)

    def test_failed_atomic_copy_preserves_the_existing_app_file(self):
        with tempfile.TemporaryDirectory() as directory:
            old=Path(directory)/'module.py';old.write_bytes(b'previous complete code')
            source=Path(directory)/'new.py';source.write_bytes(b'new complete code')
            def interrupted(source,destination):
                Path(destination).write_bytes(b'partial')
                raise OSError('write interrupted')
            with patch.object(updater.shutil,'copy2',side_effect=interrupted):
                with self.assertRaises(OSError):updater._atomic_copy(source,old)
            self.assertEqual(old.read_bytes(),b'previous complete code')
            self.assertEqual(sorted(p.name for p in Path(directory).iterdir()),['module.py','new.py'])


if __name__=='__main__':unittest.main()
