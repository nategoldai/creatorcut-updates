"""Fault injection: chat isolation, durable events and stalled child processes."""
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from editkit import util,workflow,studiomake,events

class ResilienceTests(unittest.TestCase):
    def setUp(self):
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup)
        self.root=Path(temp.name);self.p=self.root/'projects/test';self.p.mkdir(parents=True)
        from editkit import learn
        for k,v in {'BRAND':self.root/'my-brand','PROFILE':self.root/'my-brand/profile.json','USER_STYLES_DIR':self.root/'my-brand/styles'}.items():
            x=patch.object(util,k,v);x.start();self.addCleanup(x.stop)
        x=patch.object(learn,'FILE',self.root/'my-brand/learned.json');x.start();self.addCleanup(x.stop)
        for k,v in {'ROOT':self.root,'PROJECTS':self.root/'projects','STUDIO_OUT':self.root/'out'}.items():
            p=patch.object(util,k,v);p.start();self.addCleanup(p.stop)
        for k,v in {'EVENTS':util.STUDIO_OUT/'events.jsonl','HANDLED':util.STUDIO_OUT/'events.handled'}.items():
            p=patch.object(events,k,v);p.start();self.addCleanup(p.stop)
        util.write_json(self.p/'project.json',{'name':'test'})
    def test_legacy_ui_chat_does_not_change_current_edit(self):
        from editkit import server
        workflow.claim(self.p,'current-editor','building')
        before=util.read_json(self.p/'workflow.json')
        with self.assertRaises(util.Fail):server.api_videos('/api/videos/chat',{'project':'test','text':'Are you working?'})
        self.assertEqual(util.read_json(self.p/'workflow.json'),before)
        self.assertEqual(events.pending(),[])
    def test_legacy_make_button_cannot_queue_an_undeliverable_request(self):
        from editkit import server
        with self.assertRaises(util.Fail):server.api_videos('/api/videos/create',{'project':'test'})
        self.assertEqual(events.pending(),[])
        self.assertFalse((self.p/'chat.json').exists())
    def test_settings_save_does_not_create_a_fake_ai_job(self):
        from editkit import server
        result=server.queue_preview(self.p)
        self.assertEqual(result['state'],'saved')
        self.assertEqual(events.pending(),[])
        self.assertTrue(util.read_json(self.p/'project.json')['settings_need_edit'])
    def test_silent_child_stops_instead_of_hanging_pipe_forever(self):
        proc=subprocess.Popen([sys.executable,'-u','-c','import time; time.sleep(30)'],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True)
        started=time.monotonic()
        with self.assertRaises(util.Fail):list(util.progress_lines(proc,timeout=2,idle_timeout=.15))
        self.assertIsNotNone(proc.poll());self.assertLess(time.monotonic()-started,4)
        proc.stdout.close()
    def test_failed_child_output_is_not_reported_as_success(self):
        proc=subprocess.Popen([sys.executable,'-u','-c','print("failed");raise SystemExit(2)'],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True)
        self.assertEqual(''.join(util.progress_lines(proc,timeout=2,idle_timeout=1)).strip(),'failed')
        self.assertEqual(proc.returncode,2);proc.stdout.close()
    def test_live_output_resets_idle_deadline(self):
        script='import time\nfor i in range(5):\n print(i,flush=True);time.sleep(.06)'
        proc=subprocess.Popen([sys.executable,'-u','-c',script],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True)
        self.assertEqual(len(list(util.progress_lines(proc,timeout=2,idle_timeout=.2))),5)
        self.assertEqual(proc.returncode,0);proc.stdout.close()
    def test_quiet_process_has_explicit_no_progress_state(self):
        from editkit import state
        h=state.progress_health('test',{'project':'test','running':True,'updated':1},[],now=202)
        self.assertEqual(h['state'],'quiet');self.assertIn('201 seconds',h['message'])
    def test_actual_recent_progress_is_working(self):
        from editkit import state
        h=state.progress_health('test',{'project':'test','running':True,'updated':199},[],now=202)
        self.assertEqual(h['state'],'working')
    def test_failed_step_preserves_its_error(self):
        from editkit import state
        h=state.progress_health('test',{},[{'key':'test','state':'error','message':'Missing source file','updated':199}],now=202)
        self.assertEqual(h['state'],'error');self.assertEqual(h['message'],'Missing source file')

    def test_new_native_claim_supersedes_old_failed_step_status(self):
        from editkit import state
        old={'project':'test','running':False,'error':'Previous attempt failed','updated':100}
        jobs=[{'key':'test','state':'error','message':'Old failure','updated':101}]
        wf={'owner':'same-session','phase':'building','updated':199,'lease_until':400}
        self.assertEqual(state.progress_health('test',old,jobs,now=202,workflow=wf)['state'],'working')

    def test_failure_after_new_claim_still_needs_attention(self):
        from editkit import state
        wf={'owner':'same-session','phase':'building','updated':199,'lease_until':400}
        failure={'project':'test','running':False,'error':'Current render failed','updated':201}
        self.assertEqual(state.progress_health('test',failure,[],now=202,workflow=wf)['message'],'Current render failed')

    def test_missing_worker_pid_never_checks_the_whole_process_group(self):
        from editkit import state
        with patch.object(state,'ACTIVITY',self.root/'activity.json'):
            util.write_json(state.ACTIVITY,{'project':'test','running':True,'pid':0,'updated':time.time()})
            with patch('os.kill') as kill:
                actual=state._activity()
            kill.assert_not_called()
            self.assertFalse(actual['running']);self.assertTrue(actual['interrupted'])

    def test_make_starts_independent_preparation_without_reference_wait(self):
        from editkit import videos,jobs
        util.write_json(self.p/'project.json',{'name':'test','status':'draft','media':[{'kind':'raw','file':'raw.mp4'}]})
        with patch.object(jobs,'find',return_value=None),patch.object(jobs,'submit',return_value={'id':'prep'}) as submit:
            result=videos.start_preparation('test')
        self.assertEqual(result['job']['id'],'prep')
        self.assertFalse(submit.call_args.kwargs['heavy'])
        worker=submit.call_args.args[1]
        with patch.object(jobs,'engine') as engine,patch.object(jobs,'update'):
            worker('prep')
        engine.assert_called_once_with('prep',['prepare','test'])
        self.assertEqual(videos.load('test')['preparation']['state'],'ready')
        self.assertEqual(events.pending(),[])
    def test_repeated_make_does_not_duplicate_running_preparation(self):
        from editkit import videos,jobs
        util.write_json(self.p/'project.json',{'name':'test','status':'preparing','media':[{'kind':'raw'}]})
        with patch.object(jobs,'find',return_value={'id':'existing'}),patch.object(jobs,'submit') as submit:
            result=videos.start_preparation('test')
        self.assertTrue(result['already_started']);submit.assert_not_called()
    def test_preparation_failure_is_visible_without_ai_queue(self):
        from editkit import videos,jobs
        util.write_json(self.p/'project.json',{'name':'test','status':'draft','media':[{'kind':'raw'}]})
        with patch.object(jobs,'find',return_value=None),patch.object(jobs,'submit',return_value={'id':'prep'}) as submit:
            videos.start_preparation('test')
        with patch.object(jobs,'engine',side_effect=util.Fail('Missing tool')),patch.object(jobs,'update'):
            with self.assertRaises(util.Fail):submit.call_args.args[1]('prep')
        self.assertEqual(videos.load('test')['status'],'preparation_error')
        self.assertEqual(events.pending(),[])

if __name__=='__main__':unittest.main()
