import sys,tempfile,unittest,concurrent.futures
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from editkit import util,videos

class ProjectCreationTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
  for k,v in {'PROJECTS':self.root/'projects','PROFILE':self.root/'profile.json'}.items():
   x=patch.object(util,k,v);x.start();self.addCleanup(x.stop)
  for target in ['editkit.events.emit','editkit.presets.recipe_context']:
   x=patch(target,return_value={});x.start();self.addCleanup(x.stop)
 def test_lost_reply_retry_reuses_project(self):
  a=videos.create('Test 1',request_id='same-click');b=videos.create('Test 1',request_id='same-click')
  self.assertEqual(a['name'],b['name']);self.assertEqual(len(list(util.PROJECTS.glob('*/project.json'))),1)
 def test_same_name_intentional_requests_stay_separate(self):
  a=videos.create('Test 1',request_id='first');b=videos.create('Test 1',request_id='second')
  self.assertNotEqual(a['name'],b['name'])
 def test_concurrent_duplicate_requests_create_once(self):
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
   names=list(pool.map(lambda _:videos.create('Test 1',request_id='repeated')['name'],range(4)))
  self.assertEqual(len(set(names)),1);self.assertEqual(len(list(util.PROJECTS.glob('*/project.json'))),1)
 def test_different_arguments_cannot_reuse_key(self):
  videos.create('Test 1',request_id='key')
  with self.assertRaises(util.Fail):videos.create('Different',request_id='key')
 def test_missing_key_remains_intentional_new_project(self):
  self.assertNotEqual(videos.create('Test 1')['name'],videos.create('Test 1')['name'])

if __name__=='__main__':unittest.main()

class ThumbnailRegistrationTests(unittest.TestCase):
 def test_preview_metadata_is_saved_after_images_are_generated(self):
  captured={}
  cfg={'media':[{'id':'raw'}]}
  with patch.object(videos,'_thumb',return_value=Path('thumb.jpg')),patch.object(videos,'_strip',return_value=[]),patch.object(videos,'hero',return_value=Path('hero.jpg')),patch.object(util,'rel',side_effect=lambda p:str(p)),patch.object(util,'probe',return_value={'width':1080,'height':1920}),patch.object(videos,'update',side_effect=lambda pid,fn:fn(cfg)),patch('editkit.events.emit'):
   videos._pictures('fixture','raw',Path('raw.mp4'),'raw')
  self.assertEqual(cfg['media'][0].get('thumb'),'thumb.jpg')
  self.assertEqual(cfg['media'][0].get('hero'),'hero.jpg')
  self.assertEqual(cfg['media'][0].get('w'),1080)
