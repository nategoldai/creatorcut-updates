"""Durable personal memory and final-edit presets, independent of source references."""
import sys,tempfile,unittest,json
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from editkit import util,learn,presets,videos,workflow,native_app

class PresetLoopTests(unittest.TestCase):
    def setUp(self):
        t=tempfile.TemporaryDirectory();self.addCleanup(t.cleanup);self.root=Path(t.name)
        for key,value in {'ROOT':self.root,'BRAND':self.root/'my-brand','PROFILE':self.root/'my-brand/profile.json','USER_STYLES_DIR':self.root/'my-brand/styles','PROJECTS':self.root/'projects','STUDIO_OUT':self.root/'studio-out'}.items():
            p=patch.object(util,key,value);p.start();self.addCleanup(p.stop)
        p=patch.object(learn,'FILE',util.BRAND/'learned.json');p.start();self.addCleanup(p.stop)
        self.p=util.PROJECTS/'demo';self.v=self.p/'versions';self.v.mkdir(parents=True)
        util.write_json(self.p/'project.json',{'name':'demo','style':'clean','brief':{}})
        self.movie=self.v/'v1.mp4';self.movie.write_bytes(b'candidate fixture; not a real video')
        self.sha=workflow.digest(self.movie)
        util.write_json(self.v/'versions.json',{'versions':[{'n':1,'file':util.rel(self.movie),'candidate_sha256':self.sha}]})
        util.write_json(self.v/'v1.review.json',{'candidate_sha256':self.sha,'inputs':{}})
        util.write_json(self.v/'v1.plan.json',{'styles':{'caption':{'size':98,'color':'#ffe100'}},'items':[{'type':'html','text':'OLD WORDS','t0':2,'t1':5,'x':.2,'entry':'pop'}]})
        util.write_json(self.v/'v1.scenes.json',{'decisions':{'colour':'preserve'},'scenes':[{'speech':'old speech','entry':'pop'}]})
        review=util.read_json(self.v/'v1.review.json')
        review['inputs']={'edit-plan.json':workflow.digest(self.v/'v1.plan.json'),'scene-plan.json':workflow.digest(self.v/'v1.scenes.json')}
        util.write_json(self.v/'v1.review.json',review)
    def test_reference_free_custom_edit_can_save_real_host_skills(self):
        sid=presets.from_video('demo','My studio look')
        for host in ('.agents','.claude'):
            self.assertIn('Approved finished-edit recipe',(self.root/host/f'skills/preset-{sid}/SKILL.md').read_text())
        recipe=presets.recipe_context(sid)
        self.assertEqual(recipe['grammar']['styles']['caption']['size'],98)
        self.assertNotIn('OLD WORDS',json.dumps(recipe['grammar']))
        self.assertEqual(videos.load('demo')['style'],'clean')

    def test_renamed_preset_refreshes_pinned_project_memory_and_keeps_brief(self):
        sid=presets.from_video('demo','Original')
        learn.remember('Quiet accents',preset=sid)
        videos.set_brief('demo',{'style':sid,'prompt':'Keep these exact current instructions'})
        renamed=presets.rename_id(sid,'Renamed')
        self.assertEqual(renamed,'renamed')
        cfg=videos.load('demo');memory=util.read_json(self.p/'customer-memory.json')
        self.assertEqual(cfg['style'],renamed)
        self.assertEqual(cfg['brief']['prompt'],'Keep these exact current instructions')
        self.assertEqual(cfg['preset_version'],1)
        self.assertEqual(memory['recipe']['version'],1)
        self.assertEqual(memory['style'],renamed)
        self.assertEqual(memory['preset'][0]['rule'],'Quiet accents')
        self.assertTrue((util.ROOT/memory['recipe']['folder']/'recipe.json').is_file())
    def test_custom_animation_evidence_is_preserved_and_bound_to_review(self):
        code=self.p/'motion.html';code.write_text('<div>Custom motion evidence</div>')
        review=util.read_json(self.v/'v1.review.json');review['inputs'][util.rel(code)]=workflow.digest(code)
        util.write_json(self.v/'v1.review.json',review)
        sid=presets.from_video('demo','Motion')
        folder=util.ROOT/presets.recipe_context(sid)['folder']
        self.assertEqual((folder/'source/motion.html').read_text(),code.read_text())
        code.write_text('<div>Changed after review</div>')
        with self.assertRaises(util.Fail):presets.from_video('demo','Tampered motion')
    def test_scope_evidence_survives_fresh_module_access(self):
        learn.capture_feedback('demo','Always no loud hits',scope='creator',rule='Quiet sound accents')
        # New reader uses disk, not an in-process conversational cache.
        persisted=json.loads((util.BRAND/'learned.json').read_text())
        self.assertEqual(persisted['creator'][0]['projects'],['demo'])
        self.assertIn('Always no loud hits',persisted['creator'][0]['evidence'][0]['text'])
    def test_unreviewed_or_tampered_version_cannot_be_saved(self):
        self.movie.write_bytes(b'changed')
        with self.assertRaises(util.Fail):presets.from_video('demo','No')
        self.assertFalse((util.USER_STYLES_DIR/'no.json').exists())
    def test_snapshot_uses_saved_plans_not_current_revisions(self):
        util.write_json(self.p/'edit-plan.json',{'styles':{'caption':{'size':12}}})
        sid=presets.from_video('demo','Approved')
        self.assertEqual(presets.recipe_context(sid)['grammar']['styles']['caption']['size'],98)
    def test_update_keeps_old_recipe_and_pins_project_version(self):
        sid=presets.from_video('demo','Look')
        videos.set_brief('demo',{'style':sid})
        self.assertEqual(videos.load('demo')['preset_version'],1)
        self.movie.write_bytes(b'next reviewed candidate')
        newsha=workflow.digest(self.movie)
        util.write_json(self.v/'versions.json',{'versions':[{'n':1,'file':util.rel(self.movie),'candidate_sha256':newsha}]})
        review=util.read_json(self.v/'v1.review.json');review['candidate_sha256']=newsha
        util.write_json(self.v/'v1.review.json',review)
        presets.from_video('demo','Look',sid)
        self.assertEqual(presets.recipe_context(sid)['version'],2)
        learn.project_memory(self.p,sid)
        self.assertEqual(util.read_json(self.p/'customer-memory.json')['recipe']['version'],1)
    def test_selected_preset_refreshes_memory_without_clearing_brief(self):
        sid=presets.from_video('demo','Quiet')
        learn.remember('Subtle sound',preset=sid)
        videos.set_brief('demo',{'prompt':'Special current instructions','style':sid})
        memory=util.read_json(self.p/'customer-memory.json')
        self.assertEqual(memory['preset'][0]['rule'],'Subtle sound')
        self.assertEqual(videos.load('demo')['brief']['prompt'],'Special current instructions')
    def test_project_correction_is_saved_but_not_global(self):
        learn.capture_feedback('demo','Move this logo at 14 seconds',rule='Logo right at 14 seconds')
        self.assertEqual(learn.rules(None),[])
        self.assertIn('Logo right',(self.p/'editing-feedback.md').read_text())
    def test_native_feedback_updates_general_skill_and_records_evidence(self):
        native_app.call_tool('creatorcut_feedback',{'project':'demo','text':'Always lower the effects','scope':'creator','rule':'Keep effects quiet'})
        self.assertIn('Keep effects quiet',(self.root/'.agents/skills/creator-preferences/SKILL.md').read_text())
        self.assertEqual(learn._load()['creator'][0]['evidence'][0]['text'],'Always lower the effects')
    def test_superseded_rule_removed_and_opposites_not_fuzzy_merged(self):
        learn.remember('Use music');learn.remember('Use no music')
        self.assertEqual(len(learn.rules(None)),2)
        learn.capture_feedback('demo','Actually always no music',scope='creator',rule='Use no music',replace='Use music')
        self.assertEqual(learn.rules(None),['Use no music'])
    def test_preset_learning_never_leaks_into_unrelated_style(self):
        sid=presets.from_video('demo','Loud')
        learn.capture_feedback('demo','For Loud keep the purple captions',scope='preset',preset=sid,rule='Purple captions')
        learn.remember('Natural skin')
        self.assertEqual(learn.rules('other'),['Natural skin'])
        self.assertIn('(this preset) Purple captions',learn.rules(sid))
    def test_milestone_counts_projects_not_exports_or_failed_edits(self):
        self.assertEqual(learn.progress()['percent'],0)
        learn.complete('demo',self.sha);learn.complete('demo',self.sha)
        self.assertEqual(learn.progress()['percent'],10)
        for i in range(15):
            pid='p'+str(i);d=util.PROJECTS/pid/'versions';d.mkdir(parents=True)
            util.write_json(d.parent/'project.json',{'name':pid})
            util.write_json(d/'versions.json',{'versions':[{'n':1,'file':util.rel(self.movie),'candidate_sha256':self.sha}]})
            util.write_json(d/'v1.review.json',{'candidate_sha256':self.sha})
            learn.complete(pid,self.sha)
        self.assertEqual(learn.progress()['percent'],100)
        self.assertEqual(learn.progress()['completed'],16)
    def test_removed_general_rule_disappears_in_next_project(self):
        learn.capture_feedback('demo','Remember big captions',scope='creator',rule='Big captions')
        learn.forget(0);learn.project_memory(self.p,'clean')
        self.assertEqual(util.read_json(self.p/'customer-memory.json')['creator'],[])
    def test_preset_with_missing_version_fails_instead_of_silent_generic_fallback(self):
        sid=presets.from_video('demo','Look')
        with self.assertRaises(util.Fail):presets.recipe_context(sid,99)

if __name__=='__main__':unittest.main()
