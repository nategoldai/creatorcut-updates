import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from editkit import cli,util,videos


class MetadataTransactions(unittest.TestCase):
    def workers(self,script,root):
        env=dict(os.environ,PYTHONPATH=str(Path(__file__).resolve().parents[1]))
        children=[subprocess.Popen([sys.executable,'-c',script,str(root),str(n)],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True) for n in range(4)]
        outputs=[]
        try:
            for child in children:
                out,err=child.communicate(timeout=10)
                self.assertEqual(child.returncode,0,err)
                outputs.append(out.strip())
        finally:
            for child in children:
                if child.poll() is None:child.kill();child.wait(timeout=3)
                child.stdout.close();child.stderr.close()
        return outputs

    def test_parallel_native_cli_and_studio_changes_do_not_overwrite_each_other(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);project=root/'projects/demo';project.mkdir(parents=True)
            util.write_json(project/'project.json',{'name':'demo','title':'Keep this title'})
            script="""import sys,time
from pathlib import Path
from editkit import util,videos
util.PROJECTS=Path(sys.argv[1])/'projects'
def change(cfg):
 d=cfg.setdefault('changes',{});value=d.get(sys.argv[2],0);time.sleep(.002);d[sys.argv[2]]=value+1
for n in range(15):videos.update('demo',change)
"""
            self.workers(script,root)
            cfg=util.read_json(project/'project.json')
            self.assertEqual(cfg['changes'],{str(n):15 for n in range(4)})
            self.assertEqual(cfg['title'],'Keep this title')

    def test_creation_id_is_idempotent_across_real_processes(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            script="""import sys
from pathlib import Path
from editkit import util,videos,presets,events
root=Path(sys.argv[1]);util.PROJECTS=root/'projects';util.PROFILE=root/'profile.json'
presets.recipe_context=lambda *a:{};events.emit=lambda *a,**kw:{}
print(videos.create('One explicit click',request_id='one-click')['name'])
"""
            names=self.workers(script,root)
            self.assertEqual(len(set(names)),1)
            self.assertEqual(len(list((root/'projects').glob('*/project.json'))),1)

    def test_cli_preset_selection_pins_the_actual_recipe(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);project=root/'demo';project.mkdir()
            util.write_json(project/'project.json',{'name':'demo','brief':{},'preset_version':1})
            recipe={'version':3,'brief_template':{'prompt':'The actual saved editing instructions'}}
            with patch.object(util,'PROJECTS',root),patch('editkit.styles.load'),patch('editkit.styles.style_path',return_value=root/'named.json'),patch('editkit.presets.recipe_context',return_value=recipe),patch('editkit.learn.project_memory'):
                cli.cmd_style(SimpleNamespace(project='demo',style='named'))
            cfg=util.read_json(project/'project.json')
            self.assertEqual(cfg['preset_version'],3)
            self.assertEqual(cfg['brief']['prompt'],'The actual saved editing instructions')

    def test_failed_library_copy_keeps_the_previous_saved_video(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);shelf=root/'My video';shelf.mkdir()
            source=root/'new.mp4';source.write_bytes(b'new video')
            saved=shelf/'My video final.mp4';saved.write_bytes(b'previous approved video')
            def broken(source,dest):Path(dest).write_bytes(b'partial');raise OSError('disk interrupted')
            with patch.object(videos,'shelf',return_value=shelf),patch.object(videos.os,'link',side_effect=OSError('no hard links')),patch.object(videos.shutil,'copy2',side_effect=broken),patch.object(util,'log'):
                self.assertIsNone(videos.to_shelf('demo',source,'final'))
            self.assertEqual(saved.read_bytes(),b'previous approved video')
            self.assertEqual([p.name for p in shelf.iterdir()],['My video final.mp4'])


if __name__=='__main__':unittest.main()
