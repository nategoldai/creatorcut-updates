"""Real stdio lifecycle; the waiting tool body is an explicit protocol fixture."""
import json
import os
import queue
import subprocess
import sys
import threading
import time
import unittest
from pathlib import Path

SCRIPT="""
import json
from editkit import native_app
original=native_app.call_tool
def tool(name,args,cancelled=None):
    if name=='fixture_wait':
        print(json.dumps({'jsonrpc':'2.0','method':'fixture/ready'}),flush=True)
        cancelled.wait(10)
        return {'content':[{'type':'text','text':'cancelled' if cancelled.is_set() else 'timeout'}]}
    return original(name,args,cancelled)
native_app.call_tool=tool
native_app.serve()
"""


class NativeMcpLifecycle(unittest.TestCase):
    def start(self):
        env=dict(os.environ,PYTHONPATH=str(Path(__file__).resolve().parents[1]))
        p=subprocess.Popen([sys.executable,'-u','-c',SCRIPT],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env=env)
        messages=queue.Queue()
        def read():
            for line in p.stdout:
                messages.put(json.loads(line))
        reader=threading.Thread(target=read,daemon=True);reader.start()
        def stop():
            if p.poll() is None:p.kill();p.wait(timeout=3)
            reader.join(timeout=1)
            for stream in (p.stdin,p.stdout,p.stderr):
                if not stream.closed:stream.close()
        self.addCleanup(stop)
        return p,messages

    def send(self,p,message):
        p.stdin.write(json.dumps(message)+'\n');p.stdin.flush()

    def wait_tool(self,p,messages):
        self.send(p,{'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':'fixture_wait','arguments':{}}})
        self.assertEqual(messages.get(timeout=2)['method'],'fixture/ready')

    def test_wait_does_not_block_other_tools_and_native_cancel_releases_it(self):
        p,messages=self.start();self.wait_tool(p,messages)
        self.send(p,{'jsonrpc':'2.0','id':2,'method':'tools/list'})
        response=messages.get(timeout=2)
        self.assertEqual(response['id'],2)
        self.assertTrue(any(t['name']=='creatorcut_wait_for_action' for t in response['result']['tools']))
        self.send(p,{'jsonrpc':'2.0','method':'notifications/cancelled','params':{'requestId':1}})
        response=messages.get(timeout=2)
        self.assertEqual(response['id'],1)
        self.assertEqual(response['result']['content'][0]['text'],'cancelled')

    def test_closed_native_connection_cancels_wait_instead_of_orphaning_it(self):
        p,messages=self.start();self.wait_tool(p,messages)
        start=time.monotonic();p.stdin.close();p.wait(timeout=2)
        self.assertLess(time.monotonic()-start,2)
        self.assertEqual(p.returncode,0)


if __name__=='__main__':unittest.main()
