"""Persistence and use of customer memory in custom-scene projects."""
import importlib
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from editkit import util, learn, workflow

class LearningTests(unittest.TestCase):
    def setUp(self):
        t = tempfile.TemporaryDirectory(); self.addCleanup(t.cleanup)
        self.root = Path(t.name); self.brand = self.root/'my-brand'
        for key, value in {'ROOT':self.root, 'BRAND':self.brand, 'PROFILE':self.brand/'profile.json', 'USER_STYLES_DIR':self.brand/'styles'}.items():
            p = patch.object(util,key,value); p.start(); self.addCleanup(p.stop)
        p = patch.object(learn,'FILE',self.brand/'learned.json'); p.start(); self.addCleanup(p.stop)
        self.project=self.root/'kit/projects/customer'; self.project.mkdir(parents=True)
        util.write_json(self.project/'project.json',{'style':'interview','brief':{'prompt':'Keep this quiet'}})
    def test_creator_rule_survives_disk_reload_and_has_host_skill(self):
        learn.remember('Keep accents subtle',project='first')
        persisted=json.loads(learn.FILE.read_text())
        self.assertEqual(persisted['creator'][0]['projects'],['first'])
        for host in ('.agents','.claude'):
            content=(self.root/host/'skills/creator-preferences/SKILL.md').read_text()
            self.assertIn('Keep accents subtle',content)
        self.assertEqual(learn._load()['creator'][0]['rule'],'Keep accents subtle')
    def test_selected_preset_memory_loaded_without_design(self):
        learn.remember('No music',preset='interview')
        learn.remember('Fast kinetic type',preset='launch')
        workflow.init(self.project)
        d=util.read_json(self.project/'customer-memory.json')
        self.assertEqual([r['rule'] for r in d['preset']],['No music'])
        self.assertEqual(d['creator'],[])
    def test_existing_plan_not_replaced_when_memory_refreshes(self):
        workflow.init(self.project)
        doc=util.read_json(self.project/'scene-plan.json');doc['scenes']=[{'id':'approved-scene'}]
        util.write_json(self.project/'scene-plan.json',doc)
        learn.remember('Keep source colour')
        workflow.init(self.project)
        self.assertEqual(util.read_json(self.project/'scene-plan.json')['scenes'],doc['scenes'])
        self.assertEqual(util.read_json(self.project/'customer-memory.json')['creator'][0]['rule'],'Keep source colour')
    def test_forget_removes_rule_from_all_generated_memory(self):
        learn.remember('Avoid loud whooshes');learn.forget(0)
        for path in [self.brand/'editing-memory.md', self.root/'.agents/skills/creator-preferences/SKILL.md',self.root/'.claude/skills/creator-preferences/SKILL.md']:
            self.assertNotIn('Avoid loud whooshes',path.read_text())
        self.assertEqual(learn.rules(None),[])
    def test_studio_profile_removal_updates_skill(self):
        learn.remember('Large readable text')
        util.update_profile(lambda p:p.update(memory=[]))
        learn.sync_from_profile()
        self.assertNotIn('Large readable text',(self.brand/'editing-memory.md').read_text())
    def test_long_feedback_retained_without_promoting_a_rule(self):
        text='This is a correction for this clip only. '*70
        learn.log_feedback(text,'customer','interview')
        self.assertEqual(learn._load()['feedback'][0]['text'],text)
        self.assertEqual(learn.rules('interview'),[])

if __name__=='__main__':unittest.main()
