"""Fault injection for audit fixes, not just success-path assertions."""
import sys,subprocess,time,os,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from editkit import util,learn,presets,videos,workflow,motion,refs,server
import test_preset_loop as fixture

class AuditTests(unittest.TestCase):
    setUp = fixture.PresetLoopTests.setUp
    def test_native_command_failure_is_immediately_visible(self):
        from editkit import state
        h=state.progress_health('demo',{'project':'demo','running':False,'error':'Decoder failed'},[])
        self.assertEqual(h['state'],'error');self.assertEqual(h['message'],'Decoder failed')
    def test_interrupted_worker_is_not_shown_as_working(self):
        from editkit import state
        h=state.progress_health('demo',{'project':'demo','running':False,'interrupted':True},[])
        self.assertEqual(h['state'],'error')
    def test_corrupt_memory_does_not_blank_the_dashboard_or_reset_file(self):
        from editkit import state
        learn.FILE.parent.mkdir(parents=True,exist_ok=True);learn.FILE.write_text('{broken')
        names={'install_status':{'state':'none'},'checks':{},'styles_list':[],'references':{},'projects':[],
               'library':[],'raw_waiting':[],'stats':{},'music_library':[],'storage':{},'_activity':{}}
        from contextlib import ExitStack
        with ExitStack() as stack:
            for name,value in names.items():stack.enter_context(patch.object(state,name,return_value=value))
            result=state.snapshot()
        self.assertTrue(any('Editing memory' in msg for msg in result['data_issues']))
        self.assertTrue(result['learning_progress']['unavailable'])
        self.assertEqual(learn.FILE.read_text(),'{broken')
    def test_unpublished_or_old_unverified_counters_do_not_add_progress(self):
        learn.complete('missing','fake')
        self.assertEqual(learn.progress()['percent'],0)
        util.write_json(util.BRAND/'learning-progress.json',{'completed':{'fake':{'sha256':'x'}}})
        self.assertEqual(learn.progress()['percent'],0)
    def test_draft_preset_saves_actual_full_brief_and_reuses_it(self):
        from editkit import refs
        text='Exact typography, readable prompts and muted sound accents. '*100
        videos.set_brief('demo',{'prompt':text,'look':'warm'})
        with patch.object(refs,'for_project',return_value=[]):sid=presets.from_brief('demo','My precise style')
        recipe=presets.recipe_context(sid)
        self.assertEqual(recipe['kind'],'brief');self.assertEqual(recipe['brief_template']['prompt'],text)
        cfg=videos.create('Another script')
        videos.set_brief(cfg['name'],{'style':sid})
        self.assertEqual(videos.load(cfg['name'])['brief']['prompt'],text)
        self.assertEqual(videos.load(cfg['name'])['look'],'warm')
        self.assertTrue((self.root/'.agents/skills'/('preset-'+sid)/'SKILL.md').exists())
    def test_current_brief_wins_when_selecting_saved_preset(self):
        from editkit import refs
        videos.set_brief('demo',{'prompt':'Original saved style'})
        with patch.object(refs,'for_project',return_value=[]):sid=presets.from_brief('demo','Style')
        cfg=videos.create('New')
        videos.set_brief(cfg['name'],{'prompt':'My new specific instruction','style':sid})
        self.assertEqual(videos.load(cfg['name'])['brief']['prompt'],'My new specific instruction')
    def test_final_update_replaces_starting_recipe_with_reviewed_evidence(self):
        from editkit import refs
        videos.set_brief('demo',{'prompt':'Use my reference precisely'})
        with patch.object(refs,'for_project',return_value=[]):sid=presets.from_brief('demo','Final style')
        self.assertEqual(presets.recipe_context(sid)['kind'],'brief')
        presets.from_video('demo','Final style',sid)
        self.assertEqual(presets.recipe_context(sid)['kind'],'reviewed')
        self.assertEqual(presets.recipe_context(sid)['version'],2)
        self.assertEqual(presets.recipe_context(sid,1)['kind'],'brief')
    def test_empty_starting_preset_is_rejected(self):
        from editkit import refs
        with patch.object(refs,'for_project',return_value=[]):
            with self.assertRaises(util.Fail):presets.from_brief('demo','Empty')
    def test_topic_correction_supersedes_opposing_general_rule(self):
        learn.capture_feedback('demo','Always use music',scope='creator',rule='Use music',topic='sound.music')
        learn.capture_feedback('demo','Actually always no music',scope='creator',rule='No music',topic='sound.music')
        self.assertEqual(learn.rules(None),['No music'])
        self.assertEqual(learn._load()['superseded'][-1]['rule'],'Use music')
    def test_inferred_preference_needs_different_projects(self):
        for i in range(3):
            out=learn.capture_feedback('demo','Quieter please',scope='creator',rule='Keep accents quiet',topic='sound.effects',basis='inferred')
        self.assertTrue(out['pending_consistent_evidence']);self.assertEqual(learn.rules(None),[])
        cfg=videos.create('Different script')
        learn.capture_feedback(cfg['name'],'Lower those accents',scope='creator',rule='Keep accents quiet',topic='sound.effects',basis='inferred')
        self.assertEqual(learn.rules(None),['Keep accents quiet'])
        self.assertEqual(len(learn._load()['creator'][0]['evidence']),2)
    def test_explicit_preference_does_not_need_repeated_explanation(self):
        out=learn.capture_feedback('demo','Always preserve my colour',scope='creator',rule='Preserve source colour',topic='colour.treatment')
        self.assertTrue(out['active_general_rule']);self.assertEqual(learn.rules(None),['Preserve source colour'])
    def test_actual_mcp_stdio_entrypoint_initializes_without_another_model(self):
        import json
        entry=Path(__file__).resolve().parents[1]/'tools/native_mcp.py'
        messages=[{'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2025-06-18'}},
                  {'jsonrpc':'2.0','id':2,'method':'tools/list'}, {'jsonrpc':'2.0','id':3,'method':'ping'}]
        proc=subprocess.run([sys.executable,str(entry)],input='\n'.join(json.dumps(x) for x in messages)+'\n',text=True,capture_output=True,timeout=5)
        self.assertEqual(proc.returncode,0,proc.stderr)
        replies=[json.loads(line) for line in proc.stdout.splitlines()]
        self.assertEqual([x['id'] for x in replies],[1,2,3])
        self.assertNotIn('sampling',replies[0]['result']['capabilities'])
        self.assertIn('creatorcut_reply',[x['name'] for x in replies[1]['result']['tools']])
    def test_bad_preset_does_not_mutate_project(self):
        before=videos.load('demo')
        with self.assertRaises(util.Fail):videos.set_brief('demo',{'style':'deleted-style','prompt':'Do not save this either'})
        self.assertEqual(videos.load('demo'),before)
    def test_archived_design_tampering_blocks_preset(self):
        util.write_json(self.v/'v1.plan.json',{'styles':{'caption':{'size':3}}})
        with self.assertRaises(util.Fail):presets.from_video('demo','Tampered')
    def test_duplicate_update_does_not_create_another_version(self):
        sid=presets.from_video('demo','Once')
        presets.from_video('demo','Once',sid);presets.from_video('demo','Once',sid)
        self.assertEqual(presets.recipe_context(sid)['version'],1)
    def test_invalid_learned_settings_are_not_saved(self):
        for x in ('nan','inf','-0.3','2'):
            with self.assertRaises(util.Fail):learn.remember('Bad input',sets={'music_volume':x})
        self.assertEqual(learn.rules(None),[])
    def test_renderer_progress_path_has_a_real_deadline(self):
        exe=Path(sys.executable)
        with patch.object(motion,'_tool',return_value=exe):
            started=time.monotonic()
            with self.assertRaises(util.Fail):motion.run('hyperframes',['-u','-c','import time;time.sleep(30)'],self.p,timeout=.15,progress=lambda line:None)
            self.assertLess(time.monotonic()-started,4)
    def test_renderer_nonprogress_path_also_has_a_real_deadline(self):
        with patch.object(motion,'_tool',return_value=Path(sys.executable)):
            with self.assertRaises(util.Fail):motion.run('hyperframes',['-u','-c','import time;time.sleep(30)'],self.p,timeout=.15)
    def test_closed_output_pipe_cannot_hide_a_stuck_child(self):
        proc=util.spawn([sys.executable,'-u','-c','import os,time;os.close(1);time.sleep(30)'],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True)
        start=time.monotonic()
        with self.assertRaises(util.Fail):list(util.progress_lines(proc,timeout=10,idle_timeout=.15))
        self.assertIsNotNone(proc.poll());self.assertLess(time.monotonic()-start,3);proc.stdout.close()
    def test_callback_failure_stops_owned_worker(self):
        proc=util.spawn([sys.executable,'-u','-c','import time;print("start");time.sleep(30)'],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True)
        iterator=util.progress_lines(proc,timeout=4,idle_timeout=1)
        try:
            self.assertEqual(next(iterator).strip(),'start')
        finally:iterator.close()
        self.assertIsNotNone(proc.poll());proc.stdout.close()
    def test_reference_stream_deadline_reaches_actual_worker(self):
        entry=self.root/'edit.py';entry.write_text('import time;time.sleep(30)')
        original=util.progress_lines
        def bounded(proc,**kwargs):return original(proc,timeout=.2,idle_timeout=.15)
        with patch.object(util,'progress_lines',side_effect=bounded):
            with self.assertRaises(util.Fail):refs._study_process('test',self.movie,lambda *a:None)
    def test_unexpected_reference_failure_sets_visible_error(self):
        ref={'id':'r','status':'analysing'}
        def submit(kind,fn,**kwargs):return fn('j')
        with patch.object(refs,'load',return_value=ref),patch.object(refs,'save'),patch.object(refs,'analyse',side_effect=RuntimeError('bad decoder')),patch.object(refs.jobs,'submit',side_effect=submit):
            with self.assertRaises(RuntimeError):refs._start_analysis(ref)
        self.assertEqual(ref['status'],'error')
    def test_health_refreshes_even_when_no_files_change(self):
        with patch.object(server.time,'monotonic',return_value=1):a=server.fingerprint()
        with patch.object(server.time,'monotonic',return_value=16):b=server.fingerprint()
        self.assertNotEqual(a,b)
    def test_concurrent_memory_writers_do_not_lose_preferences(self):
        script='''import sys
from pathlib import Path
from editkit import util,learn
util.ROOT=Path(sys.argv[1]);util.BRAND=util.ROOT/'my-brand';util.PROFILE=util.BRAND/'profile.json';learn.FILE=util.BRAND/'learned.json'
for i in range(8):learn.remember(sys.argv[2]+' preference '+str(i),project=sys.argv[2])
'''
        env=dict(os.environ,PYTHONPATH=str(Path(__file__).resolve().parents[1]))
        children=[subprocess.Popen([sys.executable,'-c',script,str(self.root),str(i)],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE) for i in range(3)]
        for c in children:
            out,err=c.communicate(timeout=10);self.assertEqual(c.returncode,0,err.decode())
        self.assertEqual(len(learn.rules(None)),24)
        self.assertEqual((self.root/'.agents/skills/creator-preferences/SKILL.md').read_text(),(self.root/'.claude/skills/creator-preferences/SKILL.md').read_text())

if __name__=='__main__':unittest.main()
