import concurrent.futures
import sys
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from editkit.native_actions import Rendezvous
from editkit.util import Fail


class NativeActionsTests(unittest.TestCase):
    def ready(self, broker):
        until = time.monotonic() + 1
        while not broker.status()['available'] and time.monotonic() < until:
            time.sleep(.002)
        self.assertTrue(broker.status()['available'])

    def test_offline_click_is_never_saved_as_queued_work(self):
        broker = Rendezvous()
        with self.assertRaises(Fail):
            broker.dispatch('id', 'project', 'Edit it')
        self.assertFalse(broker.receipts)
        self.assertIsNone(broker.action)

    def test_foreground_tool_receives_and_acknowledges_exactly_one_click(self):
        broker = Rendezvous()
        with concurrent.futures.ThreadPoolExecutor() as pool:
            receive = pool.submit(broker.receive, 'this-native-conversation', 2)
            self.ready(broker)
            dispatch = pool.submit(broker.dispatch, 'id', 'project', 'Saved editing instructions')
            action = receive.result(timeout=1)['action']
            self.assertEqual(action['text'], 'Saved editing instructions')
            self.assertFalse(dispatch.done())  # delivered != merely offered
            broker.acknowledge('this-native-conversation', 'id')
            self.assertTrue(dispatch.result(timeout=1)['accepted'])
        self.assertTrue(broker.dispatch('id', 'project', 'Saved editing instructions')['accepted'])
        self.assertFalse(broker.status()['available'])
        self.assertIsNone(broker.action)
        with self.assertRaises(Fail):
            broker.dispatch('id', 'project', 'Different instructions')

    def test_expired_receive_is_not_a_live_connection(self):
        broker = Rendezvous()
        self.assertIsNone(broker.receive('native', .05)['action'])
        self.assertFalse(broker.status()['available'])
        with self.assertRaises(Fail):
            broker.dispatch('id', 'p', 'Edit')

    def test_disconnected_consumer_cannot_leave_a_hidden_queue(self):
        broker = Rendezvous()
        with concurrent.futures.ThreadPoolExecutor() as pool:
            receive = pool.submit(broker.receive, 'native', 2)
            self.ready(broker)
            dispatch = pool.submit(broker.dispatch, 'id', 'p', 'Edit', .05)
            self.assertEqual(receive.result(timeout=1)['action']['request_id'], 'id')
            result = dispatch.result(timeout=1)
            self.assertEqual(result['state'], 'unconfirmed')
            self.assertFalse(result['accepted'])
        self.assertIsNone(broker.action)
        self.assertEqual(broker.dispatch('id', 'p', 'Edit')['state'], 'unconfirmed')
        with self.assertRaises(Fail):
            broker.acknowledge('different-conversation', 'id')

    def test_a_second_chat_cannot_take_over_a_live_receive(self):
        broker = Rendezvous()
        with concurrent.futures.ThreadPoolExecutor() as pool:
            receive = pool.submit(broker.receive, 'first', .15)
            self.ready(broker)
            with self.assertRaises(Fail):
                broker.receive('second', .05)
            self.assertIsNone(receive.result(timeout=1)['action'])

    def test_action_cannot_be_stolen_between_receive_and_ack(self):
        broker = Rendezvous()
        with concurrent.futures.ThreadPoolExecutor() as pool:
            receive = pool.submit(broker.receive, 'first', 2)
            self.ready(broker)
            dispatch = pool.submit(broker.dispatch, 'one', 'p', 'Edit')
            self.assertEqual(receive.result(timeout=1)['action']['receiver'], 'first')
            for consumer in ('second', 'first'):
                with self.assertRaises(Fail):
                    broker.receive(consumer, .05)
            self.assertEqual(broker.receipts['one']['receiver'], 'first')
            broker.acknowledge('first', 'one')
            self.assertTrue(dispatch.result(timeout=1)['accepted'])


if __name__ == '__main__':
    unittest.main()
