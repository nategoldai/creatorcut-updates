"""Run: private-python -m unittest discover -s kit/tests -v"""
from __future__ import annotations
import copy
import json
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from editkit import util, workflow, pieces, scorecard, learn, events, videos

class ContractTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);self.p=self.root/'kit/projects/test';self.p.mkdir(parents=True)
        for key,val in {'ROOT':self.root,'PROJECTS':self.root/'kit/projects','BRAND':self.root/'my-brand','PROFILE':self.root/'my-brand/profile.json','STUDIO_OUT':self.root/'kit/studio-out'}.items():
            x=patch.object(util,key,val);x.start();self.addCleanup(x.stop)
        for key,val in {'EVENTS':util.STUDIO_OUT/'events.jsonl','HANDLED':util.STUDIO_OUT/'events.handled'}.items():
            x=patch.object(events,key,val);x.start();self.addCleanup(x.stop)
        self.write('project.json',{'name':'test','brief':{'prompt':'Show the upload without music'},'studio':True})
        (self.p/'cut.mp4').write_bytes(b'fixture video')
        (self.p/'font.ttf').write_bytes(b'fixture font')
        self.write('words.json',{'duration':2,'words':[{'w':'drop','start':0,'end':.4},{'w':'footage','start':.5,'end':1}]})
        self.scene={'schema':1,'brief':'Show the upload without music','reference':{'source':'','evidence':[]},'style_direction':'Quiet product demo',
          'decisions':{'colour':'preserve','voice':'preserve','music':'none'},'requirements':[{'id':'r1','text':'Show upload','scenes':['upload']}],
          'unresolved':[], 'scenes':[{'id':'upload','t0':0,'t1':2,'speech':'drop footage','purpose':'show upload','layout':'native composer',
          'entry':'file enters','hold':'complete name visible','exit':'cut to next','sound':'none','items':['upload-ui']}]}
        self.plan={'duration':2,'canvas':{'w':320,'h':568,'fps':30},'background':{'src':'cut.mp4'},'fonts':{'caption':{'file':'font.ttf','family':'Test'}},'styles':{},
          'items':[{'id':'upload-ui','type':'html','t0':0,'t1':2,'html':'<div>Upload</div>','gsap':''}], 'audio':{'events':[]}}
        self.save()
    def write(self,n,d):util.write_json(self.p/n,d)
    def save(self):self.write('scene-plan.json',self.scene);self.write('edit-plan.json',self.plan)
    def bad(self):self.assertFalse(workflow.validate(self.p)['ok'])
    def test_memory_rule_cannot_be_silently_ignored(self):
        self.write('customer-memory.json',{'creator':[{'rule':'Keep effects quiet'}]})
        self.bad()
    def test_memory_rule_binds_to_actual_scene(self):
        self.write('customer-memory.json',{'creator':[{'rule':'Keep effects quiet'}]})
        self.scene['memory_application']=[{'rule':'Keep effects quiet','status':'applied','scenes':['upload'],'reason':'No effects over narration in this upload scene.'}]
        self.save();self.assertTrue(workflow.validate(self.p)['ok'])
    def test_current_request_can_override_saved_rule_with_reason(self):
        self.write('customer-memory.json',{'creator':[{'rule':'Always add music'}]})
        self.scene['memory_application']=[{'rule':'Always add music','status':'overridden','reason':'Current brief explicitly asks for no music.'}]
        self.save();self.assertTrue(workflow.validate(self.p)['ok'])
    def test_valid_reference_free_contract(self):self.assertTrue(workflow.validate(self.p)['ok'])
    def test_missing_required_scene(self):self.scene['scenes']=[];self.save();self.bad()
    def test_unresolved_assets_block(self):self.scene['unresolved']=['missing logo'];self.save();self.bad()
    def test_gap_blocks(self):self.scene['scenes'][0]['t0']=.3;self.save();self.bad()
    def test_unbound_render_item_blocks(self):self.plan['items'].append(dict(self.plan['items'][0],id='extra'));self.save();self.bad()
    def test_false_speech_anchor_blocks(self):self.scene['scenes'][0]['speech']='not spoken';self.save();self.bad()
    def test_missing_font_blocks(self):self.plan['fonts']['caption']['file']='missing.ttf';self.save();self.bad()
    def test_no_music_request_blocks_music(self):self.plan['audio']['music']={'src':'cut.mp4','rights':'owned'};self.save();self.bad()
    def test_sound_needs_visible_reason(self):self.plan['audio']['events']=[{'scene':'upload','src':'cut.mp4','t':1}];self.save();self.bad()
    def test_sound_time_outside_video(self):self.plan['audio']['events']=[{'scene':'upload','src':'cut.mp4','t':3,'reason':'file drop'}];self.save();self.bad()
    def test_mask_required(self):self.plan['items'][0]['behind']=True;self.save();self.bad()
    def test_reference_requires_evidence(self):self.scene['reference']={'source':'cut.mp4'};self.save();self.bad()
    def test_input_fingerprint_changes_when_media_changes(self):
        old=workflow.fingerprint(self.p);(self.p/'cut.mp4').write_bytes(b'changed');self.assertNotEqual(old,workflow.fingerprint(self.p))
    def test_status_updates_dont_invalidate_review(self):
        old=workflow.fingerprint(self.p);c=util.read_json(self.p/'project.json');c['status']='finished';self.write('project.json',c);self.assertEqual(old,workflow.fingerprint(self.p))
    def test_customer_brief_change_invalidates_review(self):
        old=workflow.fingerprint(self.p);c=util.read_json(self.p/'project.json');c['brief']['prompt']='different';self.write('project.json',c);self.assertNotEqual(old,workflow.fingerprint(self.p))
    def test_stale_agent_lease_displays_waiting(self):
        workflow.state(self.p,'building','working',owner='one',lease_until=time.time()-1)
        self.assertEqual(workflow.state(self.p)['phase'],'waiting_editor')
    def test_other_agent_cannot_take_live_lease(self):
        workflow.claim(self.p,'one')
        with self.assertRaises(util.Fail):workflow.claim(self.p,'two')
    def test_unreviewed_candidate_cannot_publish(self):
        with self.assertRaises(util.Fail):workflow.require_release(self.p)
    def prepare_review(self):
        c={'file':'cut.mp4','sha256':workflow.digest(self.p/'cut.mp4'),'inputs':workflow.fingerprint(self.p)}
        self.write('render/candidate.json',c)
        self.write('render/evidence.json',{'candidate_sha256':c['sha256'],'frames':[{'time':t,'file':'font.ttf'} for t in workflow.evidence_times(self.p)]})
        report={'candidate_sha256':c['sha256'],'reviewer':'test agent','watched_video':True,'listened_audio':True,
                'checks':{k:{'pass':True,'observations':'Test fixture observation recorded'} for k in workflow.CHECKS},
                'scenes':{'upload':{'pass':True,'observations':'Entry motion hold and exit inspected'}},'issues':[]}
        return report
    def test_full_review_accepts_current_inputs(self):
        workflow.approve(self.p,self.prepare_review());self.assertTrue(workflow.require_release(self.p))
    def test_changed_candidate_blocks_review(self):
        report=self.prepare_review();(self.p/'cut.mp4').write_bytes(b'changed')
        with self.assertRaises(util.Fail):workflow.approve(self.p,report)
    def test_false_watch_flag_blocks(self):
        report=self.prepare_review();report['watched_video']=False
        with self.assertRaises(util.Fail):workflow.approve(self.p,report)
    def test_missing_scene_review_blocks(self):
        report=self.prepare_review();report['scenes']={}
        with self.assertRaises(util.Fail):workflow.approve(self.p,report)
    def test_changed_inputs_block_previously_approved_release(self):
        workflow.approve(self.p,self.prepare_review());self.plan['items'][0]['html']='changed';self.save()
        with self.assertRaises(util.Fail):workflow.require_release(self.p)
    def test_durable_pending_events(self):
        e=events.emit('media.added',{'project':'test'});self.assertEqual(events.pending()[0]['id'],e['id'])
        events.mark_handled([e['id']]);self.assertEqual(events.pending(),[])
    def test_grid_contains_real_video_elements(self):
        out=pieces.expand({'id':'grid','name':'grid','t0':0,'t1':2,'type':'piece','srcs':['clip.mp4','still.jpg']},{'styles':{}},320,568)
        self.assertIn('<video',out['html']);self.assertIn('<img',out['html']);self.assertEqual(out['id'],'grid')
    def test_strip_contains_real_video_elements(self):
        out=pieces.expand({'name':'strip','t0':0,'t1':2,'type':'piece','srcs':['clip.mp4']},{'styles':{}},320,568)
        self.assertIn('data-start="0.000"',out['html']);self.assertIn('muted',out['html'])
    def test_missing_captions_fail_diagnostics(self):
        result=scorecard.check(self.p,{'styles':{'c':{'role':'caption','count':1}}})
        self.assertTrue(any(not r['ok'] for r in result['rows']))
    def test_invalid_project_path(self):
        with self.assertRaises(util.Fail):util.project_dir('../outside')

    def test_render_lock_blocks_second_writer(self):
        with util.project_lock(self.p):
            with self.assertRaises(util.Fail):
                with util.project_lock(self.p): pass
        self.assertFalse((self.p/'.render.lock').exists())
    def test_release_copies_exact_candidate_and_is_idempotent(self):
        workflow.approve(self.p,self.prepare_review())
        with patch.object(util,'probe',return_value={'duration':2}), patch.object(util,'run'):
            first=workflow.publish(self.p,'Reviewed fixture')
            second=workflow.publish(self.p,'Same fixture')
        self.assertEqual(first['n'],second['n'])
        self.assertEqual(workflow.digest(self.p/'preview.mp4'),workflow.digest(self.p/'cut.mp4'))
        self.assertEqual(len(videos.versions('test')),1)
    def test_ordinary_changes_dont_become_permanent_preferences(self):
        self.assertEqual(learn.auto_learn('test','clean'),[])
    def test_distinct_preferences_same_parameter_do_not_merge(self):
        with patch.object(learn,'FILE',util.BRAND/'learned.json'):
            learn.remember('Use larger text in tutorials',sets={'caption_size':1.1})
            learn.remember('Tiny labels for calm interviews',sets={'caption_size':.8})
            self.assertEqual(len(learn._load()['creator']),2)
    def test_invalid_reference_range_blocks(self):
        (self.p/'ref.jpg').write_bytes(b'image fixture')
        self.scene['reference']={'source':'ref.jpg','summary':'A measured reference','evidence':['ref.jpg']}
        self.scene['scenes'][0]['reference']={'t0':3,'t1':2};self.save();self.bad()
    def test_incomplete_review_evidence_blocks(self):
        r=self.prepare_review();self.write('render/evidence.json',{'candidate_sha256':r['candidate_sha256'],'frames':[]})
        with self.assertRaises(util.Fail):workflow.approve(self.p,r)
    def test_retired_fallback_cannot_start_a_hidden_edit(self):
        from editkit import studiomake
        before=events.pending()
        with self.assertRaises(util.Fail):studiomake.make('test')
        self.assertEqual(events.pending(),before)

    def test_continuous_title_can_span_adjacent_scenes(self):
        first=self.scene['scenes'][0];first['t1']=1
        second=dict(first,id='next',t0=1,t1=2)
        self.scene['scenes'].append(second);self.save()
        self.assertTrue(workflow.validate(self.p)['ok'])
    def test_continuous_item_needs_all_scene_bindings(self):
        first=self.scene['scenes'][0];first['t1']=1
        second=dict(first,id='next',t0=1,t1=2,items=[],treatment='footage')
        self.scene['scenes'].append(second);self.save();self.bad()

    def test_attached_reference_cannot_be_silently_ignored(self):
        cfg=util.read_json(self.p/'project.json');cfg['brief']['references']=['reference.mp4'];self.write('project.json',cfg);self.bad()

    def test_known_visual_finding_requires_specific_review(self):
        r=self.prepare_review();self.write('render/check.json',{'ok':True,'review_findings':[{'id':'layout:text_occluded:#title'}]})
        with self.assertRaises(util.Fail):workflow.approve(self.p,r)
        r['exceptions']=[{'finding':'layout:text_occluded:#title','reason':'This fixture intentionally overlaps the title with a foreground layer.','evidence':['font.ttf']}]
        workflow.approve(self.p,r)

    def test_measured_review_is_explicit_and_discloses_limits(self):
        r=self.prepare_review();r.update(watched_video=False,listened_audio=False,visual_method='frame_sequence',audio_method='signal_analysis',limitations=['Synthetic frame and signal inspection only; no perceptual listening.'])
        self.write('render/audio-check.json',{'candidate_sha256':r['candidate_sha256'],'max_db':-12})
        workflow.approve(self.p,r)
    def test_measured_review_without_limits_is_rejected(self):
        r=self.prepare_review();r.update(watched_video=False,listened_audio=False,visual_method='frame_sequence',audio_method='signal_analysis')
        self.write('render/audio-check.json',{'candidate_sha256':r['candidate_sha256'],'max_db':-12})
        with self.assertRaises(util.Fail):workflow.approve(self.p,r)
    def test_malformed_scene_list_returns_diagnostic(self):
        self.scene['scenes']='wrong type';self.save();self.bad()

    def test_deleted_project_request_is_not_delivered(self):
        events.emit('media.added',{'project':'deleted-project'})
        self.assertEqual(events.pending(),[])
    def test_retired_chat_cannot_invent_a_reply(self):
        from editkit import studiomake
        with patch.object(videos,'say') as say:
            with self.assertRaises(util.Fail):studiomake.chat('test','Hello')
            say.assert_not_called()

if __name__=='__main__':unittest.main()
