"""Generate a synthetic fixture and verify the real render. No customer media or API key.
Run with the app private Python: kit/tests/smoke_render.py
Creates kit/projects/smoke; does not publish or assert creative quality.
"""
from pathlib import Path
import sys,json,subprocess
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'kit'))
from editkit import util
p=root/'kit/projects/smoke'
if p.exists(): raise SystemExit('The smoke project already exists; use a clean test copy or rename the existing smoke project first.')
p.mkdir(parents=True)
f=util.ffmpeg_bin()
util.run([f,'-v','error','-y','-f','lavfi','-i','color=c=0x172037:s=320x568:r=30:d=3','-f','lavfi','-i','sine=frequency=320:sample_rate=48000:duration=3','-vf',"drawbox=x=40+30*t:y=200:w=80:h=80:color=0x529dff:t=fill",'-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-af','volume=0.08','-shortest',str(p/'cut.mp4')])
util.run([f,'-v','error','-y','-f','lavfi','-i','testsrc2=s=160x280:r=30:d=3','-c:v','libx264','-pix_fmt','yuv420p',str(p/'clip.mp4')])
util.run([f,'-v','error','-y','-f','lavfi','-i','sine=frequency=1200:sample_rate=48000:duration=0.08','-af','afade=t=out:d=0.08',str(p/'click.wav')])
util.run([f,'-v','error','-y','-f','lavfi','-i','sine=frequency=110:sample_rate=48000:duration=3','-af','volume=0.05',str(p/'music.wav')])
util.write_json(p/'project.json',{'name':'smoke','title':'Engine verification','studio':True,'style':'clean','platform':'vertical','status':'draft','brief':{'prompt':'Test animated text, playing clip, music and drop sound.'},'media':[]})
util.write_json(p/'words.json',{'duration':3,'words':[{'w':'drop','start':0,'end':.3},{'w':'footage','start':.4,'end':.8}]})
scene={'id':'upload','t0':0,'t1':3,'speech':'drop footage','purpose':'Test actual media rendering','layout':'Title above playing clip','entry':'Title pops in','hold':'Clip plays','exit':'Hard cut','sound':'quiet file drop at .4s','items':['title','strip']}
util.write_json(p/'scene-plan.json',{'schema':1,'brief':'Test animated text and playing clip with explicit audio','style_direction':'Technical test, not customer creative evaluation','reference':{'source':'','evidence':[]},'decisions':{'colour':'preserve','voice':'preserve','music':'provided'},'requirements':[{'id':'r1','text':'Playing clip and sound','scenes':['upload']}],'scenes':[scene],'unresolved':[]})
util.write_json(p/'edit-plan.json',{'canvas':{'w':320,'h':568,'fps':30},'duration':3,'background':{'src':'cut.mp4','zooms':[]},'fonts':{'caption':{'family':'Inter','file':'kit/fonts/Inter-Medium.otf','weight':500}},'styles':{'caption':{'font':'caption','size':.045,'colour':'#ffffff'}},'items':[{'id':'title','type':'caption','t0':0,'t1':3,'x':.5,'y':.18,'words':[{'w':'Engine','style':'caption','t':0},{'w':'test','style':'caption','t':0}], 'anim':{'ease':'pop','ms':180}}, {'id':'strip','type':'piece','name':'strip','t0':0,'t1':3,'y':.5,'h':.34,'srcs':['clip.mp4']}], 'audio':{'music':{'src':'music.wav','volume':.1,'rights':'Test sine generated for this package'},'events':[{'scene':'upload','t':.4,'src':'click.wav','volume':.1,'reason':'Test file drop'}]}})
print(p)

subprocess.run([sys.executable,str(root/'edit.py'),'compose','smoke','--final'],check=True,cwd=root)
from PIL import Image, ImageChops
import numpy as np
frames=[Image.open(p/'render/review-frames'/f'{n:04d}.jpg').convert('RGB') for n in (1,2)]
for im in frames:
    crop=np.array(im.crop((145,188,263,379))).astype(int)
    assert ((crop.max(2)-crop.min(2))>80).sum()>1000, 'Playing clip missing from the actual export'
assert np.abs(np.array(frames[0]).astype(int)-np.array(frames[1]).astype(int)).sum()>100000, 'Clip appears frozen'
r=subprocess.run([f,'-v','error','-i',str(p/'render/candidate.mp4'),'-vn','-ar','48000','-ac','1','-f','f32le','-'],capture_output=True,check=True)
a=np.frombuffer(r.stdout,dtype='<f4');assert len(a)>=143000 and np.max(np.abs(a))<.96
wave=a[int(.4*48000):int(.47*48000)];spectrum=np.abs(np.fft.rfft(wave));freq=np.fft.rfftfreq(len(wave),1/48000)
assert spectrum[(freq>1100)&(freq<1300)].max()>1, 'Timed click missing from the soundtrack'
report={'ok':True,'video':'3s H.264/AAC at 320x568','checks':['contract validation','HyperFrames check','full render and decode','playing video visible','video frames change','timed audio event present','bounded music mix','peak below .96','per-scene evidence generated'], 'creative_quality':'not assessed by this synthetic test','published':False}
util.write_json(p/'render/smoke-result.json',report)
print(json.dumps(report,indent=2))
