"""Crash a real owner, then prove a new process can acquire without manual cleanup."""
import json
import os
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from editkit import util,workflow


class LockRecovery(unittest.TestCase):
    def test_kernel_releases_lock_when_owner_is_terminated(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'.guard'
            script="from pathlib import Path;from editkit import util;import sys,time\nwith util.file_guard(Path(sys.argv[1])):\n print('LOCKED',flush=True)\n time.sleep(20)\n"
            env=dict(os.environ,PYTHONPATH=str(Path(__file__).resolve().parents[1]))
            owner=subprocess.Popen([sys.executable,'-c',script,str(path)],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            try:
                self.assertEqual(owner.stdout.readline().strip(),'LOCKED')
                with self.assertRaises(util.Fail):
                    with util.file_guard(path):pass
                owner.kill();owner.wait(timeout=3)
                # Guard file still exists; kernel ownership, not file existence,
                # determines whether the next request can start.
                self.assertTrue(path.exists())
                with util.file_guard(path):pass
            finally:
                if owner.poll() is None:owner.kill();owner.wait(timeout=3)
                owner.stdout.close();owner.stderr.close()

    def test_abandoned_editor_directory_does_not_block_new_claim(self):
        with tempfile.TemporaryDirectory() as directory:
            project=Path(directory);(project/'.editor-lock').mkdir()
            result=workflow.claim(project,'actual-new-session','planning')
            self.assertEqual(result['owner'],'actual-new-session')

    def test_old_malformed_render_lock_recovers_without_touching_media(self):
        with tempfile.TemporaryDirectory() as directory:
            project=Path(directory);legacy=project/'.render.lock';legacy.write_text('{incomplete')
            os.utime(legacy,(time.time()-30,time.time()-30))
            video=project/'preview.mp4';video.write_bytes(b'approved preview')
            with util.project_lock(project):pass
            self.assertFalse(legacy.exists())
            self.assertEqual(video.read_bytes(),b'approved preview')

    def test_real_active_legacy_owner_remains_protected(self):
        with tempfile.TemporaryDirectory() as directory:
            project=Path(directory);(project/'.render.lock').write_text(json.dumps({'pid':os.getpid()}))
            with self.assertRaises(util.Fail):
                with util.project_lock(project):pass


if __name__=='__main__':unittest.main()
