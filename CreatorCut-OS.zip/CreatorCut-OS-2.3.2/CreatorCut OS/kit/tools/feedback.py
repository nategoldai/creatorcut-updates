"""Save scoped feedback from the current native conversation. No model/session."""
import sys,json,argparse
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from editkit import learn
p=argparse.ArgumentParser()
p.add_argument('project');p.add_argument('text');p.add_argument('--scope',choices=['project','preset','creator'],default='project')
p.add_argument('--rule',default='');p.add_argument('--preset',default='');p.add_argument('--replace',default='')
p.add_argument('--topic',default='');p.add_argument('--basis',choices=['explicit','inferred'],default='explicit')
a=p.parse_args()
print(json.dumps(learn.capture_feedback(**vars(a)),ensure_ascii=False))
