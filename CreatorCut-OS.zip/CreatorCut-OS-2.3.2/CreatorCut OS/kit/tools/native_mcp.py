#!/usr/bin/env python3
"""CreatorCut MCP entrypoint, executed by the native host's existing session."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from editkit.native_app import serve
serve()
