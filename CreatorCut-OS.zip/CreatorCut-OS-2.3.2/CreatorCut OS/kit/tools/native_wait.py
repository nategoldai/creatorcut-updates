#!/usr/bin/env python3
"""Wait in the current conversation's foreground tool, then return one UI action.

Run through the native agent's command tool, never as a detached daemon. This
program cannot edit a video or answer a message: its result returns directly to
the agent that called it. Stop it when leaving Studio. Re-arm after handling an
action. A receive is a bounded blocking rendezvous, not a chat polling loop.
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from editkit import util


from editkit.native_receiver import wait


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--seconds', type=int, default=120)
    parser.add_argument('--conversation')
    args = parser.parse_args()
    try:
        print(json.dumps(wait(args.seconds, args.conversation), ensure_ascii=False), flush=True)
    except (util.Fail, OSError, ValueError, KeyError) as error:
        print(json.dumps({'native_action': None, 'error': str(error)}), flush=True)
        sys.exit(1)
