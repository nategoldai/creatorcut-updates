"""Copy skills from kit/skills-src into .claude/skills (Claude Code) and .agents/skills (ChatGPT Codex),
quoting the description so the YAML frontmatter is always valid. Run after editing any skill."""
import json
import re
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "kit" / "skills-src"
TARGETS = [ROOT / ".claude" / "skills", ROOT / ".agents" / "skills"]

names = {d.name for d in SRC.iterdir() if d.is_dir()}
for t in TARGETS:
    t.mkdir(parents=True, exist_ok=True)
    for d in t.iterdir():             # replace the kit's own skills; keep the creator's preset-* skills
        if d.is_dir() and d.name in names:
            shutil.rmtree(d)
for d in sorted(SRC.iterdir()):
    if not (d / "SKILL.md").exists():
        continue
    text = (d / "SKILL.md").read_text(encoding="utf-8")
    m = re.match(r"---\n(.*?)\n---\n(.*)", text, re.S)
    meta, body = m.group(1), m.group(2)
    name = re.search(r"^name:\s*(.+)$", meta, re.M).group(1).strip().strip('"')
    desc = re.search(r"^description:\s*(.+)$", meta, re.M).group(1).strip()
    if desc.startswith('"') and desc.endswith('"'):
        desc = json.loads(desc)
    out = f"---\nname: {name}\ndescription: {json.dumps(desc, ensure_ascii=False)}\n---\n\n{body.lstrip()}"
    for t in TARGETS:
        (t / name).mkdir(exist_ok=True)
        for child in d.iterdir():
            if child.name != "SKILL.md":
                if child.is_dir(): shutil.copytree(child, t / name / child.name, dirs_exist_ok=True)
                else: shutil.copy2(child, t / name / child.name)
        (t / name / "SKILL.md").write_text(out, encoding="utf-8")
# Codex accepts only these frontmatter keys: drop others (e.g. "version" in downloaded Remotion skills)
ALLOWED = {"name", "description", "license", "allowed-tools", "metadata"}
for t in TARGETS:
    for f in t.glob("*/SKILL.md"):
        try:
            text = f.read_text(encoding="utf-8")
            m = re.match(r"---\n(.*?)\n---\n", text, re.S)
            if not m:
                continue
            keep = [ln for ln in m.group(1).split("\n")
                    if not (re.match(r"^([A-Za-z_-]+):", ln) and re.match(r"^([A-Za-z_-]+):", ln).group(1) not in ALLOWED)]
            if len(keep) != len(m.group(1).split("\n")):
                f.write_text("---\n" + "\n".join(keep) + "\n---\n" + text[m.end():], encoding="utf-8")
        except OSError:
            pass
print(f"Synced {len([d for d in SRC.iterdir() if (d / 'SKILL.md').exists()])} skills to .claude/skills and .agents/skills")
