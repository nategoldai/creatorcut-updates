#!/usr/bin/env bash
# Claude Code status line for CreatorCut OS: always shows how to open the Studio (clickable when it's running).
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cat >/dev/null 2>&1   # Claude Code sends session info on stdin; not needed
J="$ROOT/kit/studio-out/server.json"
URL=""
if [ -f "$J" ]; then
  PORT="$(sed -n 's/.*"port": *\([0-9]*\).*/\1/p' "$J" | head -1)"
  PID="$(sed -n 's/.*"pid": *\([0-9]*\).*/\1/p' "$J" | head -1)"
  if [ -n "$PORT" ] && [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then URL="http://localhost:$PORT/"; fi
fi
if [ ! -d "$ROOT/.venv" ]; then
  printf '🎬 CreatorCut OS · type \033[1minstall\033[0m to set it up'
elif [ -n "$URL" ]; then
  printf '🎬 CREATORCUT · Studio running · type /studio to show it beside this chat'
else
  printf '🎬 CreatorCut Studio  ·  type \033[1m/studio\033[0m to open it'
fi
