window.AIE_BEAT = 0;
