"""Reference map: an exact, measured timeline of everything a reference video shows.

Scripts measure, Claude interprets. This module measures:
  text      every on-screen word (OCR) with its exact box, colour and size, tracked across frames into
            elements with in/out times; grouped into text styles (e.g. "small white sans", "big yellow serif")
  motion    how each element enters, measured at the video's native frame rate (scale, rise, fade)
  person    the person's outline (Vision on Mac): text that sits *behind* the person
  shots     cuts (incl. jump cuts), from frame differences
  speech    which on-screen words are the spoken words (captions) vs fixed notes and labels

Output: <out>/refmap.json + annotated sheets (<out>/annotated/page-NN.jpg) that Claude reads to write the rules."""
from __future__ import annotations

import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

from . import util

FPS = 10
MAX_SECONDS = 75


# ------------------------------------------------------------------ OCR ----
def _ocr_mac(path: str) -> list[tuple[str, float, tuple]]:
    from ocrmac import ocrmac
    return ocrmac.OCR(path, recognition_level="accurate", framework="livetext").recognize()


_RAPID = None


def _ocr_other(path: str) -> list[tuple[str, float, tuple]]:
    """RapidOCR (Windows/Linux): line boxes, split into words by character width."""
    global _RAPID
    from PIL import Image
    if _RAPID is None:
        from rapidocr_onnxruntime import RapidOCR
        _RAPID = RapidOCR()
    W, H = Image.open(path).size
    res, _ = _RAPID(path)
    out = []
    for box, text, conf in res or []:
        xs = [p[0] for p in box]; ys = [p[1] for p in box]
        x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
        words = text.split()
        n = max(1, len(text))
        pos = 0
        for w in words:
            i = text.find(w, pos); pos = i + len(w)
            wx0 = x0 + (x1 - x0) * i / n; wx1 = x0 + (x1 - x0) * (i + len(w)) / n
            out.append((w, float(conf), (wx0 / W, 1 - y1 / H, (wx1 - wx0) / W, (y1 - y0) / H)))
    return out


def ocr(path: str) -> list[dict]:
    """Words with boxes in top-left coordinates (fractions of the frame)."""
    raw = _ocr_mac(path) if sys.platform == "darwin" else _ocr_other(path)
    out = []
    for text, conf, (x, y, w, h) in raw:
        t = text.strip()
        if not t or conf < 0.3:
            continue
        out.append({"t": t, "c": round(float(conf), 2), "x": x, "y": 1 - y - h, "w": w, "h": h})
    return out


# --------------------------------------------------------------- person ----
def person_mask(path: str, quality: int = 1):
    """Person outline as a uint8 array (255 = person), or None. Mac: Apple Vision; elsewhere: MediaPipe if present."""
    import numpy as np
    from PIL import Image
    if sys.platform == "darwin":
        try:
            import Quartz
            import Vision
            from Foundation import NSURL
            url = NSURL.fileURLWithPath_(path)
            req = Vision.VNGeneratePersonSegmentationRequest.alloc().initWithCompletionHandler_(None)
            req.setQualityLevel_(quality)                 # balanced for study, accurate for final masks
            req.setOutputPixelFormat_(1278226488)         # kCVPixelFormatType_OneComponent8 ('L008')
            handler = Vision.VNImageRequestHandler.alloc().initWithURL_options_(url, None)
            handler.performRequests_error_([req], None)
            obs = req.results()
            if not obs:
                return None
            buf = obs[0].pixelBuffer()
            Quartz.CVPixelBufferLockBaseAddress(buf, 0)
            w, h = Quartz.CVPixelBufferGetWidth(buf), Quartz.CVPixelBufferGetHeight(buf)
            bpr = Quartz.CVPixelBufferGetBytesPerRow(buf)
            base = Quartz.CVPixelBufferGetBaseAddress(buf)
            data = base.as_buffer(bpr * h)
            arr = np.frombuffer(data, dtype=np.uint8).reshape(h, bpr)[:, :w].copy()
            Quartz.CVPixelBufferUnlockBaseAddress(buf, 0)
            W, H = Image.open(path).size
            return np.array(Image.fromarray(arr).resize((W, H)))
        except Exception as e:
            util.log(f"person mask failed: {e}")
            return None
    try:
        import mediapipe as mp
        img = np.array(Image.open(path).convert("RGB"))
        with mp.solutions.selfie_segmentation.SelfieSegmentation(model_selection=1) as seg:
            m = seg.process(img).segmentation_mask
        return (m > 0.5).astype(np.uint8) * 255
    except Exception:
        return None


# --------------------------------------------------------------- colour ----
def text_colour(img, box) -> tuple[str, float] | None:
    """The letters' colour inside a word box: of the two tones in the box, the one that touches the box edge
    least is the text (the background surrounds it). Returns (hex, share of the box)."""
    import numpy as np
    H, W = img.shape[:2]
    x0, y0 = int(box["x"] * W), int(box["y"] * H)
    x1, y1 = int((box["x"] + box["w"]) * W), int((box["y"] + box["h"]) * H)
    crop = img[max(0, y0):min(H, y1), max(0, x0):min(W, x1)].reshape(-1, 3).astype(np.float32)
    if len(crop) < 30:
        return None
    hh, ww = max(1, min(H, y1) - max(0, y0)), max(1, min(W, x1) - max(0, x0))
    lum = crop @ np.array([0.299, 0.587, 0.114], np.float32)
    thr = _otsu(lum)
    a = lum > thr
    grid = a.reshape(hh, ww)
    edge = np.concatenate([grid[0], grid[-1], grid[:, 0], grid[:, -1]])
    bright_edge = edge.mean()
    text = a if bright_edge < 0.5 else ~a
    if text.mean() < 0.04 or text.mean() > 0.85:
        return None
    px = crop[text]
    # the core of the letters, not their anti-aliased edges
    core = px[np.argsort(np.abs(px @ np.array([0.299, 0.587, 0.114]) - np.median(px @ np.array([0.299, 0.587, 0.114]))))[: max(10, len(px) // 2)]]
    r, g, b = (int(v) for v in np.median(core, axis=0))
    return "#%02X%02X%02X" % (r, g, b), float(text.mean())


def _otsu(v):
    import numpy as np
    hist, edges = np.histogram(v, bins=64)
    w = hist.cumsum(); m = (hist * edges[:-1]).cumsum()
    tot, mt = w[-1], m[-1]
    best, thr = -1, float(np.median(v))
    for i in range(1, 63):
        w0, w1 = w[i], tot - w[i]
        if w0 == 0 or w1 == 0:
            continue
        mu0, mu1 = m[i] / w0, (mt - m[i]) / w1
        b = w0 * w1 * (mu0 - mu1) ** 2
        if b > best:
            best, thr = b, edges[i]
    return thr


def _iou(a, b) -> float:
    ix = max(0, min(a["x"] + a["w"], b["x"] + b["w"]) - max(a["x"], b["x"]))
    iy = max(0, min(a["y"] + a["h"], b["y"] + b["h"]) - max(a["y"], b["y"]))
    inter = ix * iy
    u = a["w"] * a["h"] + b["w"] * b["h"] - inter
    return inter / u if u > 0 else 0.0


def _norm(t: str) -> str:
    return re.sub(r"[^\w']", "", t.lower())


# ---------------------------------------------------------------- build ----
def build(src: Path, out: Path, words: list[dict] | None = None, progress=None) -> dict:
    import numpy as np
    from PIL import Image
    say = progress or (lambda *_: None)
    src, out = Path(src), Path(out)
    fdir = out / "f10"
    fdir.mkdir(parents=True, exist_ok=True)
    info = util.probe(src)
    W, H, dur = info["width"], info["height"], min(info["duration"], MAX_SECONDS)
    vfps = info.get("fps") or 30
    if not any(fdir.glob("*.jpg")):
        say("Reading every frame…", 0.02)
        util.run([util.ffmpeg_bin(), "-v", "error", "-i", str(src), "-t", f"{dur:.2f}", "-vf", f"fps={FPS}", "-q:v", "2",
                  str(fdir / "%04d.jpg")])
    frames = sorted(fdir.glob("*.jpg"))
    times = [i / FPS for i in range(len(frames))]

    # 1. words on screen in every frame
    cache = out / "ocr.json"
    per_frame: list[list[dict]] = util.read_json(cache, default=[]) if cache.exists() else []
    if per_frame and not any(per_frame):            # an empty reading is a failure, never a result to reuse
        per_frame = []
    for i, f in enumerate(frames):
        if i < len(per_frame):
            continue
        if i % 20 == 0:
            say(f"Reading the text on screen… {round(i / len(frames) * 100)}%", 0.05 + 0.45 * i / len(frames))
        try:
            ws = ocr(str(f))
        except Exception as e:
            util.log(f"ocr failed {f.name}: {e}")
            ws = []
        per_frame.append(ws)
    util.write_json(cache, per_frame)

    # 2. cuts from frame differences (jump cuts included)
    say("Finding the cuts…", 0.52)
    smalls = [np.asarray(Image.open(f).convert("L").resize((48, 85)), dtype=np.float32) for f in frames]
    diffs = [0.0] + [float(np.abs(smalls[i] - smalls[i - 1]).mean()) for i in range(1, len(smalls))]
    cuts = []
    for i in range(1, len(diffs)):
        local = diffs[max(1, i - 10): i] + diffs[i + 1: i + 11]
        base = float(np.median(local)) if local else 0
        if diffs[i] > max(7.0, base * 3) and diffs[i] >= max(diffs[max(1, i - 2): i + 3]):
            if not cuts or times[i] - cuts[-1] > 0.25:
                cuts.append(round(times[i], 2))

    # 3. track words across frames
    say("Following every word across frames…", 0.55)
    tracks: list[dict] = []
    open_: list[dict] = []
    for i, ws in enumerate(per_frame):
        t = times[i]
        nxt = []
        used = set()
        for w in ws:
            key = _norm(w["t"])
            if not key:
                continue
            best = None
            for tr in open_:
                if id(tr) in used or tr["key"] != key:
                    continue
                if _iou(tr["boxes"][-1][1], w) > 0.25 or (abs(tr["boxes"][-1][1]["x"] - w["x"]) < 0.04 and abs(tr["boxes"][-1][1]["y"] - w["y"]) < 0.04):
                    best = tr
                    break
            if best is None:
                best = {"key": key, "text": w["t"], "boxes": [], "frames": []}
                tracks.append(best)
            best["boxes"].append((t, w)); best["frames"].append(i)
            used.add(id(best)); nxt.append(best)
        # tracks that weren't seen this frame stay open for one missed frame (OCR blinks)
        open_ = nxt + [tr for tr in open_ if id(tr) not in used and tr["frames"][-1] >= i - 1]
    tracks = [tr for tr in tracks if len(tr["boxes"]) >= 2 or tr["boxes"][0][1]["c"] > 0.6]

    # 4. describe each track: time, settled box, colour, spoken or not, behind the person
    say("Measuring colour, size and position of every word…", 0.6)
    spoken = [(_norm(w["w"]), w["start"], w["end"]) for w in (words or []) if _norm(w["w"])]
    imgs: dict[int, np.ndarray] = {}

    def img(i):
        if i not in imgs:
            if len(imgs) > 60:
                imgs.clear()
            imgs[i] = np.asarray(Image.open(frames[i]).convert("RGB"))
        return imgs[i]
    masks: dict[int, np.ndarray | None] = {}
    elements = []
    for k, tr in enumerate(tracks):
        t_in, t_out = tr["boxes"][0][0], tr["boxes"][-1][0] + 1 / FPS
        mid = tr["boxes"][len(tr["boxes"]) // 2]
        settled = mid[1]
        hs = [b["h"] for _, b in tr["boxes"]]
        col = text_colour(img(tr["frames"][len(tr["frames"]) // 2]), settled)
        sp = next((s for s in spoken if s[0] == tr["key"] and s[1] - 1.2 <= t_in <= s[2] + 0.6), None)
        el = {"id": k, "text": tr["text"], "t_in": round(t_in, 2), "t_out": round(t_out, 2),
              "x": round(settled["x"], 4), "y": round(settled["y"], 4), "w": round(settled["w"], 4), "h": round(float(np.median(hs)), 4),
              "cx": round(settled["x"] + settled["w"] / 2, 4), "cy": round(settled["y"] + settled["h"] / 2, 4),
              "colour": col[0] if col else None, "ink": round(col[1], 3) if col else None,
              "spoken": bool(sp), "word_start": round(sp[1], 2) if sp else None,
              "lead_ms": int((t_in - sp[1]) * 1000) if sp else None, "upper": tr["text"].isupper() and len(tr["text"]) > 1,
              "frames": len(tr["boxes"])}
        elements.append(el)

    # caption-scale text vs small content text (UI inside screenshots, labels): only the first defines the style
    spoken_h = sorted(e["h"] for e in elements if e["spoken"] and e["h"] >= 0.015)
    cap_h = spoken_h[len(spoken_h) // 2] if spoken_h else 0.03
    for e in elements:
        e["kind"] = "caption" if e["spoken"] and e["h"] >= cap_h * 0.55 else \
                    "text" if e["h"] >= cap_h * 0.55 and e["frames"] >= 3 else "content"

    # 5. text behind the person: inside the person's outline the letters disappear
    say("Checking for text behind the person…", 0.7)
    for el in elements:
        if not el["spoken"] and el["t_out"] - el["t_in"] > 4:
            continue
        i = min(len(frames) - 1, int(round((el["t_in"] + el["t_out"]) / 2 * FPS)))
        if i not in masks:
            masks[i] = person_mask(str(frames[i]))
        m = masks[i]
        if m is None:
            continue
        hh, ww = m.shape
        # widen the box a little: the hidden part of a word isn't in the OCR box when OCR only sees the visible part
        x0, x1 = int(max(0, el["x"] - el["w"] * 0.6) * ww), int(min(1, el["x"] + el["w"] * 1.6) * ww)
        y0, y1 = int(el["y"] * hh), int((el["y"] + el["h"]) * hh)
        reg = m[y0:y1, x0:x1]
        el["person_overlap"] = round(float((reg > 127).mean()), 3) if reg.size else 0.0

    # 6. text styles: cluster by size and colour (and later font)
    say("Grouping text styles…", 0.75)
    styles = _styles([e for e in elements if e["kind"] != "content"], H, cap_h)

    # 7. caption blocks: words that appear together
    blocks = _blocks(elements)

    # 8. entry motion at native frame rate for a sample of elements of each style
    say("Measuring how text animates in…", 0.8)
    motion = _motion(src, elements, styles, vfps, out)

    # 9. text behind the person: a line of words with a gap in it exactly where the person is (the hidden word)
    say("Looking for text that goes behind the person…", 0.88)
    behind_t = []
    lines = defaultdict(list)
    for e in elements:
        if e.get("kind") in ("caption", "text"):
            lines[(round(e["t_in"] * 2) / 2, round(e["cy"] / 0.03))].append(e)
    for (_, _), ws in lines.items():
        ws.sort(key=lambda e: e["x"])
        for a, b in zip(ws, ws[1:]):
            gap = b["x"] - (a["x"] + a["w"])
            ch = a["h"] * 0.55                       # roughly one character width
            if gap < ch * 2.5:
                continue
            t = max(a["t_in"], b["t_in"]) + 0.2
            i = min(len(frames) - 1, int(round(t * FPS)))
            if i not in masks:
                masks[i] = person_mask(str(frames[i]))
            m = masks[i]
            if m is None:
                continue
            hh, ww = m.shape
            reg = m[int(a["y"] * hh):int((a["y"] + a["h"]) * hh), int((a["x"] + a["w"]) * ww):int(b["x"] * ww)]
            if reg.size and (reg > 127).mean() > 0.6:
                behind_t.append(round(t, 2))
                a["behind"] = b["behind"] = True
    res_behind = sorted(set(behind_t))

    res = {"source": src.name, "frame": [W, H], "fps": vfps, "duration": round(dur, 2), "cuts": cuts,
           "cuts_per_minute": round(len(cuts) / max(dur, 1) * 60, 1), "elements": elements, "styles": styles,
           "blocks": blocks, "motion": motion,
           "behind_person": res_behind}
    say("Drawing the annotated sheets…", 0.92)
    res["sheets"] = annotate(frames, times, res, out / "annotated")
    util.write_json(out / "refmap.json", res)
    return res


def colour_family(c: str | None) -> str:
    """Coarse colour name: white, black, grey, or a hue (yellow, orange, red, pink, purple, blue, cyan, green)."""
    import colorsys
    if not c:
        return "unknown"
    r, g, b = (int(c[i:i + 2], 16) / 255 for i in (1, 3, 5))
    h, l, s = colorsys.rgb_to_hls(r, g, b)
    if s < 0.28 or l > 0.93 or l < 0.08:
        return "white" if l > 0.7 else "black" if l < 0.3 else "grey"
    names = [(15, "red"), (40, "orange"), (68, "yellow"), (160, "green"), (195, "cyan"), (255, "blue"), (290, "purple"), (335, "pink"), (360, "red")]
    deg = h * 360
    return next(n for lim, n in names if deg <= lim)


def _styles(elements: list[dict], H: int, cap_h: float = 0.03) -> list[dict]:
    """Group caption-scale words into text styles: colour family x size class (x caption/static)."""
    import numpy as np
    groups = defaultdict(list)
    for e in elements:
        size = "big" if e["h"] > cap_h * 1.45 else "body"
        key = (colour_family(e["colour"]), size, "caption" if e["spoken"] else "static")
        groups[key].append(e)
    # one-offs join the closest real style (by size, then colour)
    real = {k: v for k, v in groups.items() if len(v) >= 3}
    for k, v in list(groups.items()):
        if k not in real and real:
            tgt = min(real, key=lambda r: (r[1] != k[1], r[2] != k[2], r[0] != k[0]))
            real[tgt].extend(v)
    groups = real or groups
    out = []
    for n, (key, es) in enumerate(sorted(groups.items(), key=lambda kv: -len(kv[1]))):
        cols = Counter(e["colour"] for e in es if e["colour"])
        for e in es:
            e["style"] = n
        out.append({"id": n, "family": key[0], "size": key[1], "role": key[2], "count": len(es),
                    "height": round(float(np.median([e["h"] for e in es])), 4),
                    "colour": cols.most_common(1)[0][0] if cols else None,
                    "y": round(float(np.median([e["cy"] for e in es])), 3),
                    "x": round(float(np.median([e["cx"] for e in es])), 3),
                    "upper_share": round(sum(e["upper"] for e in es) / len(es), 2),
                    "examples": [{"text": e["text"], "t": e["t_in"]} for e in es[:12]]})
    return out


def _blocks(elements: list[dict]) -> list[dict]:
    """Caption blocks: spoken words that appear within 50 ms of each other and sit close together."""
    caps = sorted((e for e in elements if e.get("kind") == "caption"), key=lambda e: (e["t_in"], e["y"], e["x"]))
    blocks: list[list[dict]] = []
    for e in caps:
        if blocks and abs(blocks[-1][0]["t_in"] - e["t_in"]) <= 0.25 and min(abs(b["cy"] - e["cy"]) for b in blocks[-1]) < 0.09:
            blocks[-1].append(e)
        else:
            blocks.append([e])
    out = []
    for b in blocks:
        lines = len({round(e["cy"], 2) for e in b if True})
        ys = sorted({round(e["cy"] / 0.02) for e in b})
        out.append({"t": b[0]["t_in"], "words": [e["text"] for e in sorted(b, key=lambda e: (round(e["cy"] / 0.02), e["x"]))],
                    "styles": sorted({e.get("style") for e in b}), "lines": len(ys), "cy": round(sum(e["cy"] for e in b) / len(b), 3)})
    return out


def _motion(src: Path, elements: list[dict], styles: list[dict], vfps: float, out: Path) -> dict:
    """How each text style enters: OCR box height and position over the first frames at native fps."""
    import numpy as np
    tmp = out / "motion"
    tmp.mkdir(exist_ok=True)
    res = {}
    for st in styles:
        es = [e for e in elements if e.get("style") == st["id"] and e["frames"] >= 4 and e.get("kind") != "content"][:8]
        curves = []
        for e in es:
            t0 = max(0, e["t_in"] - 0.12)
            pat = tmp / f"e{e['id']}-%02d.jpg"
            util.run([util.ffmpeg_bin(), "-v", "error", "-ss", f"{t0:.3f}", "-i", str(src), "-t", "0.5", "-q:v", "3", str(pat)], check=False)
            seq = []
            for f in sorted(tmp.glob(f"e{e['id']}-*.jpg")):
                ws = [w for w in ocr(str(f)) if _norm(w["t"]) == _norm(e["text"])]
                if ws:
                    w = min(ws, key=lambda w: abs(w["x"] - e["x"]) + abs(w["y"] - e["y"]))
                    seq.append((w["h"] / max(e["h"], 1e-4), (w["y"] + w["h"] / 2 - e["cy"]), w["c"]))
                else:
                    seq.append(None)
                f.unlink()
            first = next((k for k, s in enumerate(seq) if s), None)
            if first is None:
                continue
            vis = [s for s in seq[first:] if s]
            if len(vis) >= 2:
                curves.append({"scale_from": round(vis[0][0], 2), "dy_from": round(vis[0][1], 3),
                               "settle_frames": next((k for k, s in enumerate(vis) if abs(s[0] - 1) < 0.04 and abs(s[1]) < 0.004), len(vis))})
        if curves:
            res[str(st["id"])] = {"scale_from": round(float(np.median([c["scale_from"] for c in curves])), 2),
                                  "dy_from": round(float(np.median([c["dy_from"] for c in curves])), 3),
                                  "settle_ms": int(float(np.median([c["settle_frames"] for c in curves])) / vfps * 1000),
                                  "samples": len(curves)}
    return res


def annotate(frames: list[Path], times: list[float], res: dict, out: Path, every: int = 3, per_page: int = 24) -> list[str]:
    """Contact sheets with every OCR word boxed (coloured per text style), the style id and cut marks: what Claude
    reads to describe the reference."""
    from PIL import Image, ImageDraw
    out.mkdir(parents=True, exist_ok=True)
    pal = ["#00E5FF", "#FF3D7F", "#FFD400", "#7CFF4F", "#B388FF", "#FF8A3D", "#FFFFFF", "#00FF9C"]
    els = res["elements"]
    cutset = set(res["cuts"])
    tiles = []
    for i in range(0, len(frames), every):
        t = times[i]
        im = Image.open(frames[i]).convert("RGB")
        im.thumbnail((240, 427))
        d = ImageDraw.Draw(im)
        for e in els:
            if e["t_in"] <= t < e["t_out"]:
                c = pal[e.get("style", 0) % len(pal)]
                x0, y0 = e["x"] * im.width, e["y"] * im.height
                d.rectangle([x0, y0, x0 + e["w"] * im.width, y0 + e["h"] * im.height], outline=c, width=2)
                d.text((x0, max(0, y0 - 10)), f"S{e.get('style')}", fill=c)
        lab = f"{t:5.1f}s" + ("  CUT" if any(abs(t - c) < every / FPS for c in cutset) else "")
        d.rectangle([0, 0, 92, 14], fill="#000")
        d.text((3, 1), lab, fill="#fff")
        tiles.append(im)
    pages = []
    for p in range(0, len(tiles), per_page):
        chunk = tiles[p:p + per_page]
        cols = 6
        rows = (len(chunk) + cols - 1) // cols
        tw, th = chunk[0].width, chunk[0].height
        sheet = Image.new("RGB", (cols * (tw + 4), rows * (th + 4)), "#111")
        for k, im in enumerate(chunk):
            sheet.paste(im, ((k % cols) * (tw + 4), (k // cols) * (th + 4)))
        f = out / f"page-{p // per_page + 1:02d}.jpg"
        sheet.save(f, quality=85)
        pages.append(util.rel(f))
    return pages
