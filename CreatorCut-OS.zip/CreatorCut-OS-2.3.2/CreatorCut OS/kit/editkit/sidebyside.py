"""Reference (top row) next to our edit (bottom row) at evenly spaced moments: the picture every check ends with."""
from __future__ import annotations

from pathlib import Path



def sheet(ref: Path, ours: Path, out: Path, n: int = 6, ref_times: list[float] | None = None, our_times: list[float] | None = None) -> Path:
    from PIL import Image, ImageDraw
    import cv2

    def grab(v: Path, times: list[float] | None):
        cap = cv2.VideoCapture(str(v))
        dur = (cap.get(cv2.CAP_PROP_FRAME_COUNT) or 1) / (cap.get(cv2.CAP_PROP_FPS) or 30)
        ts = times or [dur * (k + 0.5) / n for k in range(n)]
        ims = []
        for t in ts:
            cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
            ok, fr = cap.read()
            im = Image.fromarray(cv2.cvtColor(fr, cv2.COLOR_BGR2RGB)) if ok else Image.new("RGB", (270, 480))
            im = im.resize((270, int(270 * im.height / im.width)))
            ImageDraw.Draw(im).text((6, 6), f"{t:.1f}s", fill="#fff")
            ims.append(im)
        return ims
    a, b = grab(ref, ref_times), grab(ours, our_times)
    h = max(i.height for i in a + b)
    s = Image.new("RGB", (n * 276, h * 2 + 30), "#111")
    d = ImageDraw.Draw(s)
    d.text((6, 2), "REFERENCE", fill="#aaa"); d.text((6, h + 16), "OUR EDIT", fill="#aaa")
    for k in range(n):
        s.paste(a[k], (k * 276, 14)); s.paste(b[k], (k * 276, h + 28))
    out.parent.mkdir(parents=True, exist_ok=True)
    s.save(out, quality=88)
    return out
