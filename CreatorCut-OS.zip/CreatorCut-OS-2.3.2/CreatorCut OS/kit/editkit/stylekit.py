"""Style kit: the reference's text styles as exact, renderable settings.

From the reference map (measured boxes, colours, motion) and the identified fonts, each text style gets:
  font file, CSS font size (calibrated: the same OCR that measured the reference measures our rendering of the
  same font, so measured box height -> font size is exact for that font), colour, case, entry motion, position.
Plus the caption system (words per caption, how often the accent/big styles appear) and the shot and graphic
facts. The agent adds the rules ("why") in style.md; this file holds the numbers."""
from __future__ import annotations

import re
import statistics as stx
import tempfile
from pathlib import Path

from . import refmap, util

STOP = set("a an and are as at be but by for from had has have i i'm in is it it's its me my of on or our so that the "
           "their them then there they this to too us was we were what when which who will with you your".split())


def calibrate(font_file: Path, sample: str = "for claude reel") -> float:
    """OCR box height per unit of font size for this font (box_h / font_px)."""
    from PIL import Image, ImageDraw, ImageFont
    size = 120
    f = ImageFont.truetype(str(font_file), size)
    im = Image.new("RGB", (size * len(sample), size * 3), (40, 40, 40))
    ImageDraw.Draw(im).text((40, size), sample, font=f, fill=(255, 255, 255))
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as t:
        im.save(t.name)
        ws = refmap.ocr(t.name)
    Path(t.name).unlink(missing_ok=True)
    hs = [w["h"] * im.height for w in ws if len(w["t"]) >= 3]
    return (stx.median(hs) / size) if hs else 0.9


def build(rmap: dict, fonts: dict[str, dict], frame_h: int | None = None) -> dict:
    """fonts: {style_id: best candidate from fontmatch.match()}. Returns the kit."""
    H = frame_h or rmap["frame"][1]
    els = rmap["elements"]
    styles = {}
    for st in rmap["styles"]:
        f = fonts.get(st["id"]) or fonts.get(str(st["id"]))
        if not f:
            continue
        k = calibrate(util.ROOT / f["file"])
        size = st["height"] / k                      # font size as a fraction of the frame height
        mo = rmap.get("motion", {}).get(str(st["id"]), {})
        sc = mo.get("scale_from", 1.0)
        styles[str(st["id"])] = {
            "role": st["role"], "colour_family": st["family"], "size_class": st["size"], "count": st["count"],
            "font": {"family": f["family"], "weight": f["weight"], "italic": f["italic"], "file": f["file"], "score": f["score"]},
            "size": round(size, 4), "colour": st["colour"], "case": "upper" if st["upper_share"] > 0.6 else "lower" if st["upper_share"] < 0.1 else "as-is",
            "y": st["y"], "x": st["x"],
            "anim": {"ease": "cut" if abs(sc - 1) < 0.03 and abs(mo.get("dy_from", 0)) < 0.004 else "pop",
                     "scale_from": round(sc if abs(sc - 1) >= 0.03 else 1.0, 2), "dy_from": mo.get("dy_from", 0),
                     "ms": max(60, mo.get("settle_ms", 100))},
            "examples": st["examples"][:10],
        }
    caps = [b for b in rmap["blocks"] if b["words"]]
    per = [len(b["words"]) for b in caps] or [2]
    total_words = sum(per) or 1
    share = {sid: round(sum(1 for e in els if str(e.get("style")) == sid and e.get("kind") == "caption") / total_words, 3) for sid in styles}
    kit = {
        "frame": rmap["frame"], "styles": styles,
        "captions": {"words_per_block": {"median": stx.median(per), "p25": sorted(per)[len(per) // 4], "p75": sorted(per)[3 * len(per) // 4],
                                         "single_word_share": round(sum(1 for n in per if n == 1) / len(per), 2)},
                     "style_share": share, "lines_max": max((b["lines"] for b in caps), default=1),
                     "y_median": round(stx.median([b["cy"] for b in caps]), 3) if caps else 0.5},
        "cuts_per_minute": rmap["cuts_per_minute"],
        # text behind the person only when the reference really does it (not one word that brushed a shoulder)
        "behind_person": (lambda n: n if n >= max(3, 0.05 * total_words) else 0)(len(rmap.get("behind_person", []))),
    }
    return kit


FILLER = STOP | set("all gonna just really also can could will would now then still very much more most some any every "
                    "get got do does did make made going want like know think how why where".split())


def keyword(words: list[str]) -> int | None:
    """The word a sentence hinges on (accent style): the last strong word of the sentence, as in short-form
    editing where the punchline word lands last ("...edit it all for us" -> "edit"; "...time back" -> "back")."""
    for i in range(len(words) - 1, -1, -1):
        t = re.sub(r"[^\w']", "", words[i].lower())
        if t and t not in FILLER and len(t) >= 3:
            return i
    return None
