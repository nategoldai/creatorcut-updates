"""The learning loop: what the creator teaches through feedback, kept for every next video.

my-brand/learned.json
  {"creator": [rule…], "presets": {"<style id>": [rule…]}, "feedback": [{"text", "project", "style", "time"}…]}
  rule = {"rule": "Bigger captions", "set": {"caption_size": 1.15}, "count": 2, "first": t, "last": t, "projects": [...]}

- The native editor records up to 300 feedback messages, up to 20,000 characters each.
- The agent turns lasting preferences into rules with `edit.py remember` (for the creator, or for one preset).
- `design` applies the rules' settings automatically and hands their text to the agent (edit-plan `_facts.learned_rules`);
  preset skills list their rules; memory stays in background files and can be changed or forgotten in native chat.
Settings a rule can carry (all optional):
  caption_size (×, e.g. 1.15)  caption_y (+/- fraction of the frame)  cards_density (×, 0 = no cards)  burst / pieces / zoom /
  block / music / sfx (true|false)  max_pause (seconds kept inside sentences)  music_volume (0-1)"""
from __future__ import annotations

import contextlib
import functools
import threading
import os
import json
import time

from . import util

FILE = util.BRAND / "learned.json"
KEYS = {"caption_size": float, "caption_y": float, "cards_density": float, "burst": bool, "pieces": bool, "zoom": bool,
        "block": bool, "music": bool, "sfx": bool, "max_pause": float, "music_volume": float}


_THREAD_LOCK = threading.RLock()
_DEPTH = threading.local()

@contextlib.contextmanager
def memory_lock():
    # Serialize HTTP, CLI and MCP writes; the OS releases this lock on process death.
    with _THREAD_LOCK:
        if getattr(_DEPTH, 'value', 0):
            yield
            return
        util.BRAND.mkdir(parents=True, exist_ok=True)
        with (util.BRAND / '.memory.lock').open('a+b') as f:
            f.seek(0); f.write(b'0'); f.flush(); deadline=time.monotonic()+3
            while True:
                try:
                    if os.name=='nt':
                        import msvcrt
                        f.seek(0); msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
                    else:
                        import fcntl
                        fcntl.flock(f.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
                    break
                except (OSError, BlockingIOError):
                    if time.monotonic()>deadline:
                        raise util.Fail('Editing memory is being updated. Retry this save shortly.')
                    time.sleep(.03)
            _DEPTH.value=1
            try:
                yield
            finally:
                _DEPTH.value=0
                if os.name=='nt':
                    f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
                else:
                    fcntl.flock(f.fileno(),fcntl.LOCK_UN)

def _serialized(fn):
    @functools.wraps(fn)
    def wrapped(*args, **kwargs):
        with memory_lock():
            return fn(*args, **kwargs)
    return wrapped


def _load() -> dict:
    d = util.read_json(FILE, default={})
    d.setdefault("creator", [])
    d.setdefault("presets", {})
    d.setdefault("feedback", [])
    d.setdefault("suggestions", {})
    d.setdefault("superseded", [])
    return d


def _val(k: str, v):
    t = KEYS.get(k)
    if t is None:
        raise util.Fail(f"'{k}' isn't a setting I can learn.", "Settings: " + ", ".join(KEYS))
    if t is bool:
        return str(v).lower() in ("1", "true", "yes", "on")
    import math
    number = float(v)
    bounds = {"caption_size": (.2, 3), "caption_y": (-1, 1), "cards_density": (0, 5),
              "max_pause": (0, 5), "music_volume": (0, 1)}
    lo, hi = bounds[k]
    if not math.isfinite(number) or not lo <= number <= hi:
        raise util.Fail(f"{k} must be between {lo} and {hi}.")
    return number


@_serialized
def log_feedback(text: str, project: str = "", style: str = "") -> None:
    d = _load()
    d["feedback"] = (d["feedback"] + [{"text": text[:20000], "project": project, "style": style, "time": time.time()}])[-300:]
    util.write_json(FILE, d)


@_serialized
def remember(rule: str, preset: str | None = None, sets: dict | None = None, project: str = "") -> dict:
    rule = rule.strip()[:160]
    if not rule:
        raise util.Fail("Say what to remember.")
    sets = {k: _val(k, v) for k, v in (sets or {}).items()}
    d = _load()
    lst = d["presets"].setdefault(preset, []) if preset else d["creator"]
    now = time.time()
    same = next((r for r in lst if r["rule"].casefold() == rule.casefold()), None)
    if same:
        same.update(rule=rule, count=same.get("count", 1) + 1, last=now)
        same.setdefault("set", {}).update(sets)
        if project and project not in same.setdefault("projects", []):
            same["projects"].append(project)
        r = same
    else:
        r = {"rule": rule, "set": sets, "count": 1, "first": now, "last": now, "projects": [project] if project else []}
        lst.append(r)
    util.write_json(FILE, d)
    if not preset:                                   # the Studio's "What the agent remembers" shows the creator's rules
        util.update_profile(lambda p: p.update(memory=[x["rule"] for x in d["creator"]][-30:]))
    else:
        try:
            from . import presets
            presets.write_skill(preset)
        except Exception as e:
            util.log(f"preset skill refresh: {e}")
    write_memory_skill()
    return r


@_serialized
def forget(index: int, preset: str | None = None) -> None:
    d = _load()
    lst = d["presets"].get(preset, []) if preset else d["creator"]
    if not 0 <= index < len(lst):
        raise util.Fail("There's no such rule.")
    lst.pop(index)
    util.write_json(FILE, d)
    if not preset:
        util.update_profile(lambda p: p.update(memory=[x["rule"] for x in d["creator"]]))
    else:
        try:
            from . import presets
            presets.write_skill(preset)
        except Exception as e:
            util.log(f"preset skill refresh: {e}")

    write_memory_skill()


@_serialized
def sync_from_profile() -> None:
    """The creator removed a remembered line in the Studio: drop the matching rule too."""
    d = _load()
    mem = set(util.load_profile().get("memory", []))
    keep = [r for r in d["creator"] if r["rule"] in mem]
    if len(keep) != len(d["creator"]):
        d["creator"] = keep
        util.write_json(FILE, d)
        write_memory_skill()


def adjustments(style: str | None) -> dict:
    """Merged settings: the creator's rules, then the preset's (the preset wins)."""
    d = _load()
    out: dict = {}
    for r in d["creator"] + (d["presets"].get(style or "", []) if style else []):
        out.update(r.get("set") or {})
    return out


def rules(style: str | None) -> list[str]:
    d = _load()
    lst = [r["rule"] for r in d["creator"]]
    if style:
        lst += [f"(this preset) {r['rule']}" for r in d["presets"].get(style, [])]
    return lst


def public() -> dict:
    d = _load()
    return {"creator": [{"rule": r["rule"], "count": r.get("count", 1)} for r in d["creator"]],
            "presets": {k: [{"rule": r["rule"], "count": r.get("count", 1)} for r in v] for k, v in d["presets"].items()}}


# ---------------------------------------------------------------- automatic: learn from what the creator changed ----
def _plan_facts(plan: dict) -> dict:
    items = plan.get("items", [])
    caps = [i for i in items if i.get("type") == "caption" and i.get("role") != "hook"]
    dur = float(plan.get("duration") or 1)
    return {
        "caption_size": float(((plan.get("styles") or {}).get("caption") or {}).get("size") or 0),
        "caption_y": sorted(i["y"] for i in caps)[len(caps) // 2] if caps else None,
        "cards": sum(1 for i in items if i.get("type") == "card") / dur * 60,
        "zoom": bool((plan.get("background") or {}).get("zooms")),
        "burst": any(i.get("type") == "burst" for i in items),
        "pieces": any(i.get("type") in ("piece", "html") for i in items),
    }


def changes(first: dict, final: dict) -> list[tuple[str, object, str]]:
    """What the creator changed between the first draft and the final video: (setting, value, words)."""
    a, b = _plan_facts(first), _plan_facts(final)
    out = []
    if a["caption_size"] and b["caption_size"]:
        r = b["caption_size"] / a["caption_size"]
        if r > 1.08:
            out.append(("caption_size", round(r, 2), "bigger captions"))
        elif r < 0.92:
            out.append(("caption_size", round(r, 2), "smaller captions"))
    if a["caption_y"] is not None and b["caption_y"] is not None and abs(b["caption_y"] - a["caption_y"]) > 0.04:
        d = round(b["caption_y"] - a["caption_y"], 2)
        out.append(("caption_y", d, "captions higher" if d < 0 else "captions lower"))
    if a["cards"] > 0.5 and b["cards"] < a["cards"] * 0.7:
        r = round(b["cards"] / a["cards"], 2)
        out.append(("cards_density", r, "no B-roll cards" if r == 0 else "fewer B-roll cards"))
    elif b["cards"] > max(1.0, a["cards"] * 1.4):
        out.append(("cards_density", round(min(2.0, b["cards"] / max(a["cards"], 0.5)), 2), "more B-roll cards"))
    for k, words in (("zoom", "zooms"), ("burst", "bursts of images"), ("pieces", "animated pieces")):
        if a[k] != b[k]:
            out.append((k, b[k], ("add " if b[k] else "no ") + words))
    return out


def auto_learn(project: str, style: str) -> list[str]:
    """Compatibility hook: project differences are not permanent preference consent."""
    return []


@_serialized
def write_memory_skill() -> None:
    """Regenerate local host skills from durable customer memory, never shipped data."""
    d = _load()
    lines = ["# This customer's editing preferences", "",
             "Saved local preferences, not a universal house style. The current brief/reference wins.",
             "Only use preset rules when that preset is selected. Read kit/docs/learning-loop.md.",
             "Source of truth: my-brand/learned.json. Use remember/forget to update.", "", "## Creator", ""]
    def append_rule(r):
        # Quote as JSON text so embedded newlines/markup do not become document structure.
        lines.append("- " + json.dumps(r["rule"], ensure_ascii=False))
        if r.get('topic'):lines.append('  Topic: '+r['topic'])
        if r.get("set"):
            lines.append("  Settings: " + json.dumps(r["set"], sort_keys=True))
    for r in d["creator"]:
        append_rule(r)
    for sid, ruleset in sorted(d["presets"].items()):
        if ruleset:
            lines.extend(["", "## Preset " + json.dumps(sid), ""])
            for r in ruleset:
                append_rule(r)
    body = "\n".join(lines) + "\n"
    header = ('---\nname: creator-preferences\ndescription: Apply this local customer’s saved editing preferences when editing or revising their videos; current requests take precedence.\n---\n\n')
    util.BRAND.mkdir(parents=True, exist_ok=True)
    (util.BRAND / "editing-memory.md").write_text(body, encoding="utf-8")
    for host in (".agents", ".claude"):
        folder = util.ROOT / host / "skills/creator-preferences"
        folder.mkdir(parents=True, exist_ok=True)
        (folder / "SKILL.md").write_text(header + body, encoding="utf-8")


def project_memory(p, style: str | None = None) -> dict:
    """Provide memory to the bespoke scene workflow, independent of design()."""
    d = _load()
    selected = style or ""
    result = {"style": selected, "creator": d["creator"],
              "preset": d["presets"].get(selected, []),
              "project_feedback": util.read_json(p / "editing-feedback.json", default={}).get("feedback", []),
              "recipe": __import__("editkit.presets", fromlist=["recipe_context"]).recipe_context(selected, util.read_json(p / "project.json", default={}).get("preset_version")),
              "precedence": "current brief/reference > matching preset > creator > craft advice"}
    util.write_json(p / "customer-memory.json", result)
    project_lines = ["# Project editing feedback", "", "These corrections apply to this project only.", ""]
    project_lines += ["- " + json.dumps(x.get("rule") or x["text"], ensure_ascii=False) for x in result["project_feedback"]]
    (p / "editing-feedback.md").write_text("\n".join(project_lines)+"\n", encoding="utf-8")
    if FILE.exists():
        write_memory_skill()
    return result


@_serialized
def capture_feedback(project: str, text: str, scope: str = "project", rule: str = "", preset: str = "", replace: str = "", topic: str = "", basis: str = "explicit") -> dict:
    """Persist feedback immediately; only explicit semantic scope promotes a lasting rule.

    The native editor interprets scope. This function never guesses intent from keywords.
    """
    from . import videos
    cfg = videos.load(project)
    if scope not in {"project", "preset", "creator"}:
        raise util.Fail("Choose project, preset or creator feedback scope.")
    text = text.strip()[:20000]
    if not text:
        raise util.Fail("Include the customer's actual feedback.")
    sid = preset or cfg.get("style", "")
    if scope == "preset" and not (util.USER_STYLES_DIR / f"{util.slugify(sid)}.json").exists():
        raise util.Fail("Select a saved preset before saving preset feedback.")
    if scope != "project" and not rule.strip():
        raise util.Fail("Describe the lasting preference to remember.")
    import re, hashlib
    if topic and not re.fullmatch(r"[a-z][a-z0-9_.-]{0,63}", topic):
        raise util.Fail('Use a concise topic such as sound.effects or captions.entry.')
    if basis not in {'explicit','inferred'}:
        raise util.Fail('Preference basis must be explicit or inferred.')
    log_feedback(text, project, sid)
    promote = True
    if scope != 'project' and basis == 'inferred':
        if not topic:
            raise util.Fail('An inferred preference needs a topic so consistent evidence can be compared.')
        d=_load()
        key=hashlib.sha256((scope+'|'+(sid if scope=='preset' else '')+'|'+topic+'|'+rule.casefold()).encode()).hexdigest()
        candidate=d['suggestions'].setdefault(key,{'rule':rule[:160],'topic':topic,'scope':scope,'projects':[],'evidence':[]})
        if project not in candidate['projects']:
            candidate['projects'].append(project);candidate['evidence'].append({'project':project,'text':text})
        promote=len(candidate['projects'])>=2
        util.write_json(FILE,d)
    local = util.PROJECTS / project / "editing-feedback.json"
    history = util.read_json(local, default={"feedback": []})
    row = {"text": text, "scope": scope if promote else "project", "topic": topic, "basis": basis, "rule": rule.strip()[:160], "time": time.time()}
    if row["rule"] and replace:
        history["feedback"] = [x for x in history["feedback"] if x.get("rule") != replace]
    if not any(x.get("text") == text and x.get("scope") == scope and x.get("rule") == row["rule"] for x in history["feedback"]):
        history["feedback"].append(row)
    util.write_json(local, history)
    if scope != "project" and promote:
        target = sid if scope == "preset" else None
        d=_load()
        old = d["presets"].get(sid, []) if target else d["creator"]
        removed=[(i,x) for i,x in enumerate(old) if (replace and x['rule']==replace) or (topic and x.get('topic')==topic and x['rule']!=rule.strip()[:160])]
        if removed:
            d['superseded']=(d['superseded']+[dict(x,scope=scope,preset=target,replaced_by=rule[:160],replaced_at=time.time()) for _,x in removed])[-100:]
            util.write_json(FILE,d)
            for i,_ in reversed(removed):forget(i,target)
        existing = _load()["presets"].get(sid, []) if target else _load()["creator"]
        if not any(x["rule"] == rule.strip()[:160] and project in x.get("projects", []) for x in existing):
            remember(rule, preset=target, project=project)
        d = _load()
        rows = d["presets"].get(sid, []) if target else d["creator"]
        for saved in rows:
            if saved["rule"] == rule.strip()[:160]:
                if topic: saved['topic']=topic
                saved['basis']=basis
                evidence = saved.setdefault("evidence", [])
                if basis == 'inferred':
                    supporting=d['suggestions'].get(key,{})
                    saved['projects']=list(dict.fromkeys(saved.get('projects',[])+supporting.get('projects',[])))
                    for item in supporting.get('evidence',[]):
                        if not any(e.get('project')==item['project'] and e.get('text')==item['text'] for e in evidence):evidence.append(item)
                if not any(e.get("project") == project and e.get("text") == text for e in evidence):
                    evidence.append({"project":project,"text":text,"time":time.time()})
                saved["evidence"] = evidence[-20:]
        util.write_json(FILE, d)
        write_memory_skill()
    project_memory(util.PROJECTS / project, cfg.get("style"))
    return {"saved": True, "scope": row['scope'], "rule": row["rule"], "active_general_rule": scope != 'project' and promote,
            "basis":basis, "topic":topic, "pending_consistent_evidence":not promote}


@_serialized
def complete(project: str, candidate_sha256: str) -> None:
    """A project counts once, after successful reviewed publication, never per render."""
    from . import videos
    try:
        version = next((v for v in videos.versions(project) if v.get("candidate_sha256") == candidate_sha256), None)
        if not version:
            return
        review = util.read_json(util.PROJECTS / project / 'versions' / f"v{version['n']}.review.json", default={})
        if review.get('candidate_sha256') != candidate_sha256 or not (util.ROOT / version['file']).is_file():
            return
    except (util.Fail, KeyError):
        return
    f = util.BRAND / "learning-progress.json"
    d = util.read_json(f, default={"completed": {}})
    row = d.setdefault("completed", {}).setdefault(project, {"sha256": candidate_sha256, "time": time.time()})
    row["reviewed_publication"] = True
    util.write_json(f, d)


def progress() -> dict:
    d = util.read_json(util.BRAND / "learning-progress.json", default={})
    n = sum(1 for row in d.get("completed", {}).values() if row.get("reviewed_publication") is True)
    return {"completed": n, "target": 10, "percent": min(n, 10) * 10,
            "preferences": len(_load()["creator"]),
            "meaning": "First 10 completed edits; not a measure of AI accuracy. Learning continues afterwards."}
