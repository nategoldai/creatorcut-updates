"""Output formats and safe zones for each platform (where the app's buttons cover the video)."""

PLATFORMS = {
    "vertical": {
        "label": "Vertical (TikTok, Reels, Shorts)", "width": 1080, "height": 1920, "fps": 30,
        # the strictest of the three apps: one video is safe everywhere
        "safe": {"top": 0.10, "bottom": 0.22, "left": 0.06, "right": 0.14},
        "ideal_length": [20, 60], "max_length": 180,
        "notes": "Clear of the buttons on TikTok, Instagram Reels and YouTube Shorts.",
    },
    "tiktok": {
        "label": "TikTok", "width": 1080, "height": 1920, "fps": 30,
        # fractions of the frame the app UI covers
        "safe": {"top": 0.09, "bottom": 0.22, "left": 0.06, "right": 0.14},
        "ideal_length": [21, 60], "max_length": 600,
        "notes": "Captions above the bottom fifth; nothing important on the right edge (like, comment, share buttons).",
    },
    "reels": {
        "label": "Instagram Reels", "width": 1080, "height": 1920, "fps": 30,
        "safe": {"top": 0.10, "bottom": 0.21, "left": 0.06, "right": 0.12},
        "ideal_length": [15, 60], "max_length": 180,
        "notes": "The grid shows the middle 3:4 crop as the cover; keep the hook text in the centre.",
    },
    "shorts": {
        "label": "YouTube Shorts", "width": 1080, "height": 1920, "fps": 30,
        "safe": {"top": 0.08, "bottom": 0.18, "left": 0.06, "right": 0.13},
        "ideal_length": [20, 58], "max_length": 180,
        "notes": "Title and channel name sit at the bottom; keep captions in the middle band.",
    },
    "youtube": {
        "label": "YouTube (landscape)", "width": 1920, "height": 1080, "fps": 30,
        "safe": {"top": 0.05, "bottom": 0.12, "left": 0.05, "right": 0.05},
        "ideal_length": [240, 900], "max_length": 43200,
        "notes": "Bottom 12% is covered by the player bar when paused.",
    },
    "square": {
        "label": "Square post", "width": 1080, "height": 1080, "fps": 30,
        "safe": {"top": 0.06, "bottom": 0.10, "left": 0.06, "right": 0.06},
        "ideal_length": [15, 60], "max_length": 600, "notes": "",
    },
    "portrait": {
        "label": "Feed post 4:5 (Instagram, LinkedIn)", "width": 1080, "height": 1350, "fps": 30,
        "safe": {"top": 0.06, "bottom": 0.12, "left": 0.06, "right": 0.06},
        "ideal_length": [15, 90], "max_length": 600, "notes": "",
    },
}

ALIASES = {"instagram": "reels", "ig": "reels", "reel": "reels", "yt": "youtube", "ytshorts": "shorts",
           "youtube-shorts": "shorts", "tik tok": "tiktok", "linkedin": "portrait", "4:5": "portrait",
           "1:1": "square", "16:9": "youtube", "9:16": "tiktok"}


def get(name: str) -> dict:
    key = (name or "vertical").strip().lower()
    key = ALIASES.get(key, key)
    if key not in PLATFORMS:
        key = "vertical"
    p = dict(PLATFORMS[key])
    p["key"] = key
    return p


def names() -> list[str]:
    return list(PLATFORMS)


def is_vertical(p: dict) -> bool:
    return p["height"] > p["width"]
