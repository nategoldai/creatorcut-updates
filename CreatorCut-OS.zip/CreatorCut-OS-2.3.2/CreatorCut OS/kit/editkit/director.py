"""Creative helpers: a first-draft graphics plan, a retention check, and the hook report.
These give the agent a strong starting point; the agent then applies judgement (see the skills)."""
from __future__ import annotations

import re
from pathlib import Path

from . import platforms, styles as st, util

ORDINALS = [("first", "second", "third", "fourth", "fifth"), ("one", "two", "three", "four", "five"),
            ("number one", "number two", "number three", "number four", "number five"),
            ("step one", "step two", "step three", "step four", "step five")]
NUM_UNIT = re.compile(r"^(\$|€|£)?(\d[\d,]*\.?\d*)(%|x|k|m)?$", re.I)
UNITS = {"percent": "%", "%": "%", "hours": " hours", "hour": " hour", "minutes": " min", "days": " days",
         "dollars": "", "euros": "", "followers": "", "views": "", "times": "x", "x": "x", "k": "K",
         "thousand": "K", "million": "M", "years": " years", "weeks": " weeks", "seconds": " sec"}
POWER = {"never", "always", "secret", "mistake", "biggest", "free", "insane", "stop", "everyone", "nobody",
         "instantly", "forever", "guaranteed", "wrong", "fastest", "easiest", "best", "worst"}


def _n(w: str) -> str:
    return re.sub(r"[^\w$€£%.']+", "", w.lower()).strip(".")


def draft_beats(project: Path) -> dict:
    wj = util.read_json(project / "words.json")
    words, dur = wj["words"], wj["duration"]
    cfg = util.read_json(project / "project.json")
    prof = util.load_profile()
    norm = [_n(w["w"]) for w in words]
    beats, notes = [], []

    # 1. hook title from the first sentence
    first = []
    for w in words:
        first.append(w["w"])
        if re.search(r"[.!?]$", w["w"]) or len(first) >= 9:
            break
    hook = re.sub(r"[.!?,]+$", "", " ".join(first))
    if hook:
        hw = hook.split()[:7]
        title = " ".join(hw)
        if len(hw) > 4:
            cut_ = (len(hw) + 1) // 2
            title = " ".join(hw[:cut_]) + "\n" + " ".join(hw[cut_:])
        end = words[min(len(first), len(words)) - 1]["end"]
        beats.append({"type": "title", "text": title, "at": 0.0, "duration": round(min(3.2, max(2.0, end + 0.3)), 2), "_t": 0.0})
        notes.append("Hook: sharpen the title so it promises the payoff in 3-7 words.")

    # 2. lists: ordinal words said in order ("first … second … third")
    for group in ORDINALS:
        hits = []
        for o in group:
            ws = o.split()
            after = hits[-1][0] + 1 if hits else 0
            found = next((i for i in range(after, len(norm) - len(ws) + 1) if norm[i:i + len(ws)] == ws), None)
            if found is None:
                break
            hits.append((found, len(ws)))
        if len(hits) >= 2:
            items = []
            for k, (i, n) in enumerate(hits):
                stop = hits[k + 1][0] if k + 1 < len(hits) else len(words)
                txt = " ".join(w["w"].strip(".,!?") for w in words[i + n:min(stop, i + n + 4)])
                items.append({"text": txt or f"Step {k + 1}", "at": {"say": " ".join(w["w"] for w in words[i:i + n])}})
            beats.append({"type": "list", "items": items, "_t": words[hits[0][0]]["start"]})
            notes.append("List: rewrite each item as 2-4 words.")
            break

    # 3. numbers that matter -> counters
    counters = 0
    for i, t in enumerate(norm):
        m = NUM_UNIT.match(t)
        if not m or counters >= 2:
            continue
        num = m.group(2).replace(",", "")
        if len(num.replace(".", "")) < 2 and not (m.group(1) or m.group(3)):
            continue
        unit = (m.group(3) or "").upper() if (m.group(3) or "").lower() in ("k", "m") else (m.group(3) or "")
        if i + 1 < len(norm) and norm[i + 1] in UNITS:
            unit = UNITS[norm[i + 1]]
        if any(abs(words[i]["start"] - b.get("_t", -10)) < 4 for b in beats):
            continue
        beats.append({"type": "counter", "value": f"{m.group(1) or ''}{m.group(2)}{unit}", "at": {"say": words[i]["w"]},
                      "_t": words[i]["start"]})
        counters += 1

    # 4. power words -> emphasis (a few, spread out)
    emph = 0
    energy = int(st.for_project(cfg).get("energy", 3))
    for i, t in enumerate(norm):
        if emph >= max(1, energy - 1):
            break
        if t in POWER:
            if any(abs(words[i]["start"] - (b.get("_t", -10))) < 4 for b in beats):
                continue
            beats.append({"type": "emphasis", "text": words[i]["w"].strip(".,!?").upper(), "at": {"say": words[i]["w"], "occurrence": norm[:i + 1].count(t)}, "_t": words[i]["start"]})
            emph += 1

    # 5. call to action at the end
    cta = cfg.get("cta") or prof.get("cta")
    if cta:
        beats.append({"type": "cta", "text": cta, "duration": 2.8})

    # a style copied from a reference only uses the kinds of graphics that reference shows
    style = st.for_project(cfg)
    allowed = (style.get("graphics") or {}).get("allowed")
    if allowed is not None:
        dropped = sorted({b["type"] for b in beats if b["type"] not in allowed})
        beats = [b for b in beats if b["type"] in allowed]
        if dropped:
            notes.append(f"Left out {', '.join(dropped)} graphics: the reference doesn't use them. Copy only what its frame sheets show.")
    if (style.get("graphics") or {}).get("title_case") != "upper":
        for b in beats:
            if b["type"] == "emphasis":
                b["text"] = b["text"].lower()
    for b in beats:
        b.pop("_t", None)
    data = {"beats": beats, "_notes": notes + [
        "This is a first draft. Read the transcript and keep only graphics that explain or prove what's said.",
        "Every 2-4 seconds something should change on screen (cut, zoom or graphic).",
    ]}
    util.write_json(project / "beats.json", data)
    return data


def retention(project: Path) -> dict:
    """Find dead spots (nothing changes on screen for too long), slow starts and length problems."""
    from . import graphics
    cfg = util.read_json(project / "project.json")
    style = st.for_project(cfg)
    plat = platforms.get(cfg.get("platform", "tiktok"))
    wj = util.read_json(project / "words.json")
    words, dur = wj["words"], wj["duration"]
    segs = util.read_json(project / "segments.json", default={"segments": []})["segments"]
    beats = util.read_json(project / "beats.json", default={"beats": []}).get("beats", [])
    clock = graphics.Clock(words, dur)
    changes = sorted({0.0} | {round(s["start"], 2) for s in segs})
    for b in beats:
        try:
            changes.append(clock.at(b.get("at"), default=0.0, where="beat"))
        except util.Fail:
            pass
    changes = sorted(set(changes)) + [dur]
    gap_max = {1: 6.0, 2: 5.0, 3: 4.0, 4: 3.2, 5: 2.6}.get(int(style.get("energy", 3)), 4.0)
    dead = [{"from": round(a, 2), "to": round(b, 2), "seconds": round(b - a, 1)} for a, b in zip(changes, changes[1:]) if b - a > gap_max]
    lo, hi = plat.get("ideal_length", [15, 60])
    first_word = words[0]["start"] if words else 0
    issues = []
    if first_word > 0.6:
        issues.append(f"The first word starts at {first_word:.1f}s: start on the first word (people swipe in under a second).")
    if dur > hi * 1.2:
        issues.append(f"{util.fmt_time(dur)} is long for {plat['label']} (sweet spot {lo}-{hi}s): cut tangents or repeats.")
    if dur < lo * 0.8:
        issues.append(f"{util.fmt_time(dur)} is short for {plat['label']}: fine for a hook, add one more point for reach.")
    if not any(b.get("type") == "title" for b in beats):
        issues.append("No hook title at the start: add one (3-7 words, the promise of the video).")
    for d_ in dead:
        issues.append(f"Nothing changes on screen from {util.fmt_time(d_['from'])} to {util.fmt_time(d_['to'])} ({d_['seconds']}s): "
                      "add a zoom, a graphic or tighten the cut there.")
    score = max(0, 100 - 12 * len(dead) - 10 * (len(issues) - len(dead)))
    report = {"score": score, "dead_spots": dead, "issues": issues, "duration": round(dur, 2),
              "changes_per_10s": round((len(changes) - 1) / max(1.0, dur) * 10, 1)}
    util.write_json(project / "retention.json", report)
    md = [f"# Retention check: {score}/100", "",
          f"Length {util.fmt_time(dur)} · {report['changes_per_10s']} changes on screen per 10 s · sweet spot for {plat['label']}: {lo}-{hi} s", ""]
    md += [f"- {i}" for i in issues] if issues else ["- No problems found: something changes on screen often enough, the start is quick and the length fits."]
    (project / "retention.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    return report
