"""Ready-made animated motion graphics ("pieces"), drawn in the video's own fonts and colours.

In edit-plan.json:  {"type": "piece", "name": "folder", "t0": 13.2, "t1": 15.0, "x": 0.5, "y": 0.17, ...options}
Each piece becomes an `html` item (HTML + GSAP, transforms and opacity only, so HyperFrames renders it frame-exactly).

  folder     clips fly into a folder on a white card            options: srcs (2-4 images), label
  counter    a number counts up, with a label under it         options: value ("10 hours", "$5K", "93%"), label
  checklist  a white card; each line gets its tick when said   options: items [{text, t}]
  phone      a phone with one of their clips, sliding in       options: src (video or image), rot
  sticker    a word (or emoji + word) on a pill that pops      options: text, colour, rot
  apps       a row of app icons popping in one by one          options: srcs (icons/screenshots), label
  strip      a row of clip cards sliding sideways (a carousel)  options: srcs (4-8), h (height, fraction), behind
  grid       a wall of many clips filling the frame, scrolling  options: srcs (12+), cols (3), behind (the person in front)
  phone      also with `text` instead of `src`: a dark card where the words build up, the last in the accent font
Sizes: `scale` (default 1). Positions: x, y are the centre (fractions of the frame)."""
from __future__ import annotations

import html as _h
import re
import math

NAMES = ("folder", "counter", "checklist", "phone", "sticker", "apps", "strip", "grid")


def _num(v: str):
    m = re.match(r"^\s*([^\d\-]*)(-?[\d,]*\.?\d+)(.*)$", str(v))
    if not m:
        return None
    n = m.group(2).replace(",", "")
    return m.group(1), float(n), m.group(3), len(n.split(".")[1]) if "." in n else 0


def _media(key, source, k, t0, duration, style):
    if re.search(r'\.(mp4|mov|m4v|webm|mkv)$', source, re.I):
        return (f'<video id="$ID-media{k}" class="clip" src="assets/{key}" muted playsinline '
                f'data-start="{t0:.3f}" data-duration="{duration:.3f}" data-track-index="{60+k}" style="{style}"></video>')
    return f'<img src="assets/{key}" style="{style}">'


def expand(it: dict, plan: dict, W: int = 1080, H: int = 1920) -> dict:
    name = it.get("name")
    t0, t1 = float(it["t0"]), float(it["t1"])
    d = max(0.4, t1 - t0)
    sc = float(it.get("scale", 1.0))
    cx, cy = it.get("x", 0.5) * W, it.get("y", 0.2) * H
    aspect = float(it.get('aspect',9/16))
    if not math.isfinite(aspect) or aspect <= 0: raise ValueError('Media aspect must be a positive width/height ratio.')
    fit = it.get('fit','contain')
    if fit not in ('contain','cover'): raise ValueError('Media fit must be contain or cover.')
    styles = plan.get("styles", {})
    acc = styles.get("accent", {}).get("colour", "#F8EA7F")
    cap_style = "caption" if "caption" in styles else next(iter(styles), "caption")
    acc_style = "accent" if "accent" in styles else cap_style
    out = dict(it, **{"type": "html", "t0": t0, "t1": t1, "assets": {}, "asset_sizes": {}, "piece": name})
    card = "background:#fff;border-radius:{r}px;box-shadow:0 24px 60px rgba(0,0,0,.28)"
    exit_ = f'tl.to("#$ID-c",{{opacity:0,y:-24,scale:0.96,duration:0.2,ease:"power1.in"}},$T0+{d - 0.2:.2f});'

    if name == "folder":
        w, h = 500 * sc, 230 * sc
        srcs = (it.get("srcs") or [])[:3]
        imgs = ""
        for k, s in enumerate(srcs):
            out["assets"][f"F{k:03d}"] = s
            imgs += (f'<img id="$ID-t{k}" src="assets/F{k:03d}" style="position:absolute;left:{(46 + k * 70) * sc:.0f}px;top:{(38 + (k % 2) * 14) * sc:.0f}px;'
                     f'width:{96 * sc:.0f}px;height:{150 * sc:.0f}px;object-fit:cover;border-radius:{12 * sc:.0f}px;box-shadow:0 8px 20px rgba(0,0,0,.25);'
                     f'transform:rotate({(-8, 4, -3)[k]}deg)">')
        label = f'<div class="s-{cap_style}" style="position:absolute;left:0;right:0;bottom:{-64 * sc:.0f}px;text-align:center;font-size:{44 * sc:.0f}px;color:#fff">{_h.escape(it["label"])}</div>' if it.get("label") else ""
        out["html"] = (f'<div id="$ID-c" style="position:absolute;left:{cx - w / 2:.0f}px;top:{cy - h / 2:.0f}px;width:{w:.0f}px;height:{h:.0f}px;{card.format(r=34 * sc)}">'
                       f'<div id="$ID-f" style="position:absolute;right:{46 * sc:.0f}px;top:{52 * sc:.0f}px;width:{150 * sc:.0f}px;height:{118 * sc:.0f}px">'
                       f'<div style="position:absolute;left:0;top:0;width:{62 * sc:.0f}px;height:{24 * sc:.0f}px;border-radius:10px 10px 0 0;background:#3D7BF7"></div>'
                       f'<div style="position:absolute;left:0;top:{16 * sc:.0f}px;right:0;bottom:0;border-radius:12px;background:linear-gradient(#64A0FF,#3D7BF7)"></div></div>'
                       f'{imgs}{label}</div>')
        g = 'tl.fromTo("#$ID-c",{opacity:0,y:-40,scale:0.85,rotation:-3},{opacity:1,y:0,scale:1,rotation:0,duration:0.38,ease:"back.out(1.6)"},$T0);'
        for k in range(len(srcs)):
            g += (f'tl.to("#$ID-t{k}",{{x:{(234 - k * 70) * sc:.0f},y:{20 * sc:.0f},scale:0.3,rotation:0,opacity:0,duration:0.4,ease:"power2.in"}},'
                  f'$T0+{min(d - 0.7, 0.6 + k * 0.3):.2f});')
        g += f'tl.fromTo("#$ID-f",{{scale:1}},{{scale:1.12,duration:0.12,yoyo:true,repeat:{max(1, 2 * len(srcs) - 1)},ease:"sine.inOut"}},$T0+0.85);'
        out["gsap"] = g + exit_
    elif name == "counter":
        p = _num(it.get("value", "0")) or ("", 0.0, str(it.get("value", "")), 0)
        pre, val, suf, dec = p
        out["html"] = (f'<div id="$ID-c" style="position:absolute;left:{cx:.0f}px;top:{cy:.0f}px;text-align:center">'
                       f'<div id="$ID-n" class="s-{acc_style}" style="font-size:{170 * sc:.0f}px;line-height:1;color:{acc};white-space:nowrap">{_h.escape(pre)}0{_h.escape(suf)}</div>'
                       + (f'<div class="s-{cap_style}" style="font-size:{50 * sc:.0f}px;margin-top:{10 * sc:.0f}px;color:#fff;white-space:nowrap">{_h.escape(it["label"])}</div>' if it.get("label") else "")
                       + "</div>")
        out["gsap"] = ('tl.set("#$ID-c",{xPercent:-50,yPercent:-50},0);tl.fromTo("#$ID-c",{opacity:0,scale:0.7},{opacity:1,scale:1,duration:0.3,ease:"back.out(2)"},$T0);'
                       f'(function(){{var o={{v:0}},el=document.getElementById("$ID-n");'
                       f'tl.to(o,{{v:{val},duration:{min(1.2, d * 0.6):.2f},ease:"power2.out",onUpdate:function(){{'
                       f'el.textContent="{pre}"+o.v.toLocaleString("en-US",{{minimumFractionDigits:{dec},maximumFractionDigits:{dec}}})+"{suf}";}}}},$T0+0.1);}})();'
                       + exit_)
    elif name == "checklist":
        items = it.get("items") or []
        w = 640 * sc
        rows = ""
        g = 'tl.set("#$ID-c",{yPercent:-50},0);tl.fromTo("#$ID-c",{opacity:0,y:30,scale:0.9},{opacity:1,y:0,scale:1,duration:0.35,ease:"back.out(1.5)"},$T0);'
        for k, row in enumerate(items[:5]):
            rows += (f'<div style="display:flex;align-items:center;gap:{20 * sc:.0f}px;padding:{12 * sc:.0f}px 0">'
                     f'<div style="width:{54 * sc:.0f}px;height:{54 * sc:.0f}px;border-radius:50%;border:{4 * sc:.0f}px solid #111;position:relative;flex:none">'
                     f'<div id="$ID-k{k}" style="position:absolute;inset:{-4 * sc:.0f}px;border-radius:50%;background:#16A34A;display:grid;place-items:center;'
                     f'color:#fff;font:700 {32 * sc:.0f}px sans-serif;opacity:0">✓</div></div>'
                     f'<div class="s-{cap_style}" style="font-size:{46 * sc:.0f}px;color:#111;text-shadow:none">{_h.escape(str(row.get("text", row)))}</div></div>')
            tk = float(row.get("t", t0 + 0.5 + k * 0.6)) if isinstance(row, dict) else t0 + 0.5 + k * 0.6
            g += f'tl.fromTo("#$ID-k{k}",{{opacity:0,scale:0.2}},{{opacity:1,scale:1,duration:0.25,ease:"back.out(3)"}},{tk:.3f});'
        out["html"] = (f'<div id="$ID-c" style="position:absolute;left:{cx - w / 2:.0f}px;top:{cy:.0f}px;width:{w:.0f}px;'
                       f'padding:{26 * sc:.0f}px {36 * sc:.0f}px;{card.format(r=34 * sc)}">{rows}</div>')
        out["gsap"] = g + exit_
    elif name == "phone":
        w, h = 330 * sc, 660 * sc
        src = it.get("src")
        extra_g = ""
        if src:
            out["assets"]["P"] = src
            media = (f'<img src="assets/P" style="width:100%;height:100%;object-fit:cover">' if not re.search(r"\.(mp4|mov|m4v|webm)$", src, re.I)
                     else f'<video id="$ID-v" class="clip" src="assets/P" muted playsinline data-start="{t0:.3f}" data-duration="{d:.3f}" data-track-index="{40 + int(t0) % 9}" style="width:100%;height:100%;object-fit:cover"></video>')
        else:
            # kinetic text inside the card: the words build up one by one, the last in the accent font with a drawn underline
            ws = str(it.get("text", "")).split()
            spans = ""
            for k, wd in enumerate(ws):
                last = k == len(ws) - 1 and len(ws) > 1
                spans += (f'<span id="$ID-w{k}" class="s-{acc_style if last else cap_style}" style="display:inline-block;margin:0 {8 * sc:.0f}px;'
                          f'font-size:{(70 if last else 40) * sc:.0f}px;color:{acc if last else "#fff"};text-shadow:none">{_h.escape(wd)}</span>')
                extra_g += f'tl.fromTo("#$ID-w{k}",{{opacity:0,y:{18 * sc:.0f},scale:0.8}},{{opacity:1,y:0,scale:1,duration:0.22,ease:"back.out(2)"}},$T0+{0.3 + k * min(0.22, (d - 0.9) / max(1, len(ws))):.2f});'
            media = (f'<div style="position:absolute;inset:0;background:radial-gradient(120% 80% at 50% 40%,#2a2a2e,#0b0b0c);display:flex;flex-wrap:wrap;'
                     f'align-content:center;justify-content:center;text-align:center;padding:{40 * sc:.0f}px">{spans}'
                     f'<div id="$ID-u" style="flex-basis:100%;height:{6 * sc:.0f}px;margin-top:{10 * sc:.0f}px;background:{acc};border-radius:4px;transform-origin:0 50%"></div></div>')
            extra_g = 'tl.set("#$ID-u",{scaleX:0},0);' + extra_g
            extra_g += f'tl.to("#$ID-u",{{scaleX:1,duration:0.35,ease:"power2.out"}},$T0+{0.3 + len(ws) * min(0.22, (d - 0.9) / max(1, len(ws))) + 0.1:.2f});'

        rot = it.get("rot", 6)
        out["html"] = (f'<div id="$ID-c" style="position:absolute;left:{cx - w / 2:.0f}px;top:{cy - h / 2:.0f}px;width:{w:.0f}px;height:{h:.0f}px;border-radius:{50 * sc:.0f}px;'
                       f'background:#0b0b0c;padding:{12 * sc:.0f}px;box-shadow:0 30px 70px rgba(0,0,0,.4)">'
                       f'<div style="width:100%;height:100%;border-radius:{40 * sc:.0f}px;overflow:hidden;position:relative">{media}'
                       f'<div style="position:absolute;top:{12 * sc:.0f}px;left:50%;width:{90 * sc:.0f}px;height:{24 * sc:.0f}px;margin-left:{-45 * sc:.0f}px;border-radius:20px;background:#0b0b0c"></div></div></div>')
        out["gsap"] = (f'tl.fromTo("#$ID-c",{{opacity:0,x:{220 * sc:.0f},rotation:{rot + 12}}},{{opacity:1,x:0,rotation:{rot},duration:0.45,ease:"back.out(1.3)"}},$T0);'
                       f'tl.to("#$ID-c",{{y:{-18 * sc:.0f},rotation:{rot - 2.5},duration:{max(0.05, d - 0.75):.2f},ease:"sine.inOut"}},$T0+0.45);' + extra_g +
                       f'tl.to("#$ID-c",{{x:{260 * sc:.0f},rotation:{rot + 10},opacity:0,duration:0.25,ease:"power2.in"}},$T0+{d - 0.25:.2f});')
    elif name == "sticker":
        txt = _h.escape(it.get("text", "✓"))
        bg = it.get("colour", acc)
        rot = it.get("rot", -6)
        out["html"] = (f'<div id="$ID-c" class="s-{cap_style}" style="position:absolute;left:{cx:.0f}px;top:{cy:.0f}px;'
                       f'padding:{14 * sc:.0f}px {30 * sc:.0f}px;border-radius:{60 * sc:.0f}px;background:{bg};color:#111;font-size:{58 * sc:.0f}px;white-space:nowrap;'
                       f'text-shadow:none;box-shadow:0 14px 34px rgba(0,0,0,.3)">{txt}</div>')
        out["gsap"] = (f'tl.set("#$ID-c",{{xPercent:-50,yPercent:-50,rotation:{rot}}},0);tl.fromTo("#$ID-c",{{opacity:0,scale:0.2,rotation:{rot - 25}}},{{opacity:1,scale:1,rotation:{rot},duration:0.4,ease:"back.out(2.2)"}},$T0);'
                       f'tl.to("#$ID-c",{{scale:1.06,rotation:{rot + 3},duration:{max(0.3, d - 0.6):.2f},ease:"sine.inOut"}},$T0+0.4);' + exit_)
    elif name == "apps":
        srcs = (it.get("srcs") or [])[:5]
        n = max(1, len(srcs))
        size = 150 * sc
        gap = 26 * sc
        w = n * size + (n - 1) * gap
        icons = ""
        g = ""
        for k, s in enumerate(srcs):
            out["assets"][f"A{k:03d}"] = s
            icons += (f'<img id="$ID-a{k}" src="assets/A{k:03d}" style="position:absolute;left:{k * (size + gap):.0f}px;top:0;width:{size:.0f}px;height:{size:.0f}px;'
                      f'object-fit:cover;border-radius:{size * 0.23:.0f}px;box-shadow:0 12px 30px rgba(0,0,0,.3)">')
            g += f'tl.fromTo("#$ID-a{k}",{{opacity:0,scale:0.3,y:40}},{{opacity:1,scale:1,y:0,duration:0.32,ease:"back.out(2)"}},$T0+{k * 0.14:.2f});'
        label = f'<div class="s-{cap_style}" style="position:absolute;left:0;right:0;top:{size + 24 * sc:.0f}px;text-align:center;font-size:{46 * sc:.0f}px;color:#fff">{_h.escape(it["label"])}</div>' if it.get("label") else ""
        out["html"] = f'<div id="$ID-c" style="position:absolute;left:{cx - w / 2:.0f}px;top:{cy - size / 2:.0f}px;width:{w:.0f}px;height:{size:.0f}px">{icons}{label}</div>'
        out["gsap"] = g + exit_
    elif name == "strip":
        srcs = (it.get("srcs") or [])[:8]
        hh = float(it.get("h", 0.17)) * H
        ww = hh * aspect
        gap = 16 * sc
        n = len(srcs)
        row = ""
        for k, s_ in enumerate(srcs):
            out["assets"][f"S{k:03d}"] = s_
            out["asset_sizes"][f"S{k:03d}"] = [min(W,ww*2),min(H,hh*2)]
            row += _media(f'S{k:03d}', s_, k, t0, d,
                          f'position:absolute;left:{k*(ww+gap):.0f}px;top:0;width:{ww:.0f}px;height:{hh:.0f}px;object-fit:{fit};border-radius:{ww*.08:.0f}px')
        total = n * (ww + gap)
        out["html"] = f'<div id="$ID-c" style="position:absolute;left:{W:.0f}px;top:{cy - hh / 2:.0f}px;width:{total:.0f}px;height:{hh:.0f}px">{row}</div>'
        out["gsap"] = (f'tl.fromTo("#$ID-c",{{x:0,opacity:1}},{{x:{-(W * 0.55):.0f},duration:0.45,ease:"power3.out"}},$T0);'
                       f'tl.to("#$ID-c",{{x:{-(W * 0.55) - max(0, total - W * 0.9):.0f},duration:{max(0.05, d - 0.75):.2f},ease:"none"}},$T0+0.45);'
                       f'tl.to("#$ID-c",{{x:{-(W + total):.0f},duration:0.3,ease:"power2.in"}},$T0+{d - 0.3:.2f});')
    elif name == "grid":
        srcs = it.get("srcs") or []
        cols = max(1, min(6, int(it.get("cols", 3))))
        if not srcs: raise ValueError("A reel grid needs media assets.")
        tw = W / cols
        th = tw / aspect
        rows = int(H / th) + 4
        cells = ""
        for k in range(cols * rows):
            s_ = srcs[k % max(1, len(srcs))] if srcs else ""
            key = f"G{k % max(1, len(srcs)):03d}"
            out["assets"][key] = s_
            out["asset_sizes"][key] = [min(W,tw*2),min(H,th*2)]
            cells += _media(key, s_, k, t0, d,
                            f'position:absolute;left:{(k%cols)*tw+4:.0f}px;top:{(k//cols)*th+4:.0f}px;width:{tw-8:.0f}px;height:{th-8:.0f}px;object-fit:{fit};border-radius:6px')
        out["html"] = f'<div id="$ID-c" style="position:absolute;left:0;top:0;width:{W}px;height:{rows * th:.0f}px;background:{it.get("background", "transparent")}">{cells}</div>'
        out["gsap"] = (f'tl.fromTo("#$ID-c",{{opacity:0,y:0}},{{opacity:1,duration:0.12}},$T0);'
                       f'tl.to("#$ID-c",{{y:{-(rows * th - H) * 0.8:.0f},duration:{d:.2f},ease:"none"}},$T0);'
                       f'tl.to("#$ID-c",{{opacity:0,duration:0.12}},$T0+{d - 0.12:.2f});')
    else:
        raise ValueError(f"unknown piece '{name}' (pieces: {', '.join(NAMES)})")
    if it.get("behind") or name == "grid":
        out["behind"] = True
    return out
