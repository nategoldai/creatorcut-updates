"""Motion-graphics templates. Claude writes beats.json (what appears, when, with what words);
this module turns each beat into ASS drawings/text (and PNG overlays for images), timed to the spoken words.

Every template reads fonts, colours, card shape and entrance motion from the active style,
so the same beats.json looks completely different in "bold" vs "luxury" vs "paper".
"""
from __future__ import annotations

import re
from pathlib import Path

from . import ass, textfit, util
from . import styles as st

TEMPLATES = ["broll", "title", "emphasis", "list", "counter", "compare", "chart", "proof", "image", "quote", "note",
             "nametag", "cta", "steps", "stat"]

DEFAULT_DUR = {"broll": 2.6, "title": 2.4, "emphasis": 1.3, "list": 0.0, "counter": 2.6, "compare": 3.6, "chart": 4.0,
               "proof": 3.2, "image": 2.6, "quote": 3.8, "note": 2.6, "nametag": 3.2, "cta": 0.0}


def _norm(w: str) -> str:
    return re.sub(r"[^a-z0-9%$€£]", "", w.lower())


class Clock:
    """Turns an "at" spec into seconds on the cut timeline: a number, {"t": 3.2}, {"say": "word"} (the first time that
    word is said after the previous graphic), {"say": "two words"}, or {"say": "word", "nth": 2}."""

    def __init__(self, words: list[dict], duration: float):
        self.words = words
        self.duration = duration
        self.toks = [_norm(w["w"]) for w in words]

    def find(self, phrase: str, after: float = 0.0, nth: int = 1) -> float | None:
        want = [_norm(x) for x in str(phrase).split() if _norm(x)]
        if not want:
            return None
        hits = 0
        for i in range(len(self.toks) - len(want) + 1):
            if self.words[i]["start"] < after - 0.05:
                continue
            if self.toks[i:i + len(want)] == want:
                hits += 1
                if hits == nth:
                    return self.words[i]["start"]
        return None

    def at(self, spec, default: float = 0.0, after: float = 0.0, where: str = "") -> float:
        if spec is None:
            return max(0.0, default)
        if isinstance(spec, (int, float)):
            return max(0.0, min(float(spec), self.duration))
        if isinstance(spec, str):
            spec = {"say": spec}
        if isinstance(spec, dict):
            if "t" in spec:
                return max(0.0, float(spec["t"]) + float(spec.get("offset", 0)))
            if "say" in spec:
                t = self.find(spec["say"], after, int(spec.get("nth", 1)))
                if t is None:
                    t = self.find(spec["say"], 0.0, int(spec.get("nth", 1)))
                if t is None:
                    raise util.Fail(f"{where}: the words \"{spec['say']}\" aren't in the cut video.",
                                    "Check the spelling against `edit.py words <project>` (cut words, not the original).")
                return max(0.0, t + float(spec.get("offset", 0)))
        raise util.Fail(f"{where}: I don't understand the time {spec!r}.", "Use a number of seconds or {\"say\": \"word\"}.")


class Ctx:
    def __init__(self, doc: ass.Doc, style: dict, plat: dict, project: Path):
        self.doc, self.style, self.plat, self.project = doc, style, plat, project
        self.W, self.H = plat["width"], plat["height"]
        self.vertical = self.H > self.W
        self.k = (self.W / 1080.0) if self.vertical else (self.H / 1080.0)
        g = style["graphics"]
        self.g = g
        self.col = style["colors"]
        self.radius = float(g.get("card_radius", 26)) * self.k
        self.fh = st.resolve_font(style["fonts"]["heading"])
        self.fb = st.resolve_font(style["fonts"]["body"])
        self.fa = st.resolve_font(style["fonts"]["accent"]) if style["fonts"].get("accent") else self.fh
        safe = plat["safe"]
        self.top = self.H * safe["top"] + 30 * self.k
        self.cap_y = self.H * min(float(style["captions"].get("y", 0.66)), 1 - safe["bottom"] - 0.03)
        self.cx = self.W * (0.5 - (safe["right"] - safe["left"]) / 2 * 0.6)
        self.max_w = self.W * (1 - safe["left"] - safe["right"] - 0.06)
        self.overlays: list[dict] = []        # PNG overlays (proof screenshots, images), composited by render.py
        self.sfx: list[dict] = []
        self.zooms: list[dict] = []
        self.hide: list[tuple[float, float]] = []
        self.brolls: list[dict] = []          # B-roll clips / animated photos, composited by render.py
        self.brolls: list[dict] = []          # B-roll clips / animated photos, composited by render.py
        self.warnings: list[str] = []
        doc.add_style("G", self.fb, 40, primary=self.col["card_text"], outline="#000000", outline_w=0, shadow=0, align=5)

    def region_y(self, beat: dict, height: float) -> float:
        if isinstance(beat.get("y"), (int, float)):          # an exact spot, as a fraction of the frame height
            return self.H * float(beat["y"])
        pos = beat.get("position", self.g.get("position", "top"))
        if pos == "middle" or pos == "center":
            return self.H * 0.40
        if pos == "bottom":
            return self.cap_y - 110 * self.k - height / 2
        return self.top + height / 2

    def sound(self, kind: str, t: float) -> None:
        sfx = self.style.get("sfx", {})
        if not sfx.get("enabled", True):
            return
        name = sfx.get(kind)
        if name:
            self.sfx.append({"name": name, "t": max(0.0, t), "volume": sfx.get("volume", 0.3)})

    # animation tags for an element centred at (x, y)
    def anim(self, x: float, y: float, kind: str | None = None, fade_out: int = 160, rot: float = 0.0,
             scale_from: float | None = None) -> str:
        kind = kind or self.g.get("entrance", "slide")
        r = f"\\frz{rot:.1f}\\org({x:.0f},{y:.0f})" if abs(rot) > 0.05 else ""
        d = 60 * self.k
        if kind == "slide":
            return f"\\an5\\move({x - d:.0f},{y:.0f},{x:.0f},{y:.0f},0,230)\\fad(170,{fade_out}){r}"
        if kind == "rise":
            return f"\\an5\\move({x:.0f},{y + d * 0.8:.0f},{x:.0f},{y:.0f},0,260)\\fad(200,{fade_out}){r}"
        if kind in ("pop", "stamp"):
            s0 = scale_from or (128 if kind == "stamp" else 88)
            return (f"\\an5\\pos({x:.0f},{y:.0f}){r}\\fscx{s0}\\fscy{s0}"
                    f"\\t(0,150,\\fscx104\\fscy104)\\t(150,240,\\fscx100\\fscy100)\\fad(110,{fade_out})")
        if kind == "drop":
            return f"\\an5\\move({x:.0f},{y - d:.0f},{x:.0f},{y:.0f},0,220)\\fad(140,{fade_out}){r}"
        return f"\\an5\\pos({x:.0f},{y:.0f})\\fad(260,{fade_out}){r}"

    # drawing primitives
    def card(self, t0, t1, x, y, w, h, color=None, alpha=None, anim=None, layer=11, radius=None, rot=0.0,
             border: str | None = None, shadow: bool | None = None):
        color = color or self.col["card"]
        alpha = self.g.get("card_alpha", 0.94) if alpha is None else alpha
        radius = self.radius if radius is None else radius
        path = ass.rrect(w, h, radius)
        shadow = self.g.get("shadow", True) if shadow is None else shadow
        if shadow and alpha > 0.3:
            sh = f"{{{self.anim(x + 6 * self.k, y + 14 * self.k, anim, rot=rot)}\\bord0\\shad0\\blur{14 * self.k:.0f}{ass.c('#000000')}{ass.a(0.32)}\\p1}}"
            self.doc.dialogue(t0, t1, sh + _centre(path, w, h) + "{\\p0}", "G", layer=layer - 1)
        bord = f"\\bord{4 * self.k:.1f}{ass.c(border, 3)}" if border else "\\bord0"
        tags = f"{{{self.anim(x, y, anim, rot=rot)}{bord}\\shad0{ass.c(color)}{ass.a(alpha)}\\p1}}"
        self.doc.dialogue(t0, t1, tags + _centre(path, w, h) + "{\\p0}", "G", layer=layer)

    def text(self, t0, t1, x, y, s, font, size, color=None, anim=None, layer=13, outline=0.0, outline_color="#000000",
             shadow=0.0, rot=0.0, align_left_width: float | None = None, extra=""):
        color = color or self.col["card_text"]
        bold = "\\b1" if font.get("bold") else "\\b0"
        ital = "\\i1" if font.get("italic") else "\\i0"
        fsz = st.fs(font, size)
        if align_left_width is not None:
            x = x - align_left_width / 2
            a_ = self.anim(x, y, anim, rot=rot).replace("\\an5", "\\an4")
        else:
            a_ = self.anim(x, y, anim, rot=rot)
        tags = (f"{{{a_}\\fn{font['ass']}{bold}{ital}\\fs{fsz:.0f}{ass.c(color)}\\bord{outline:.1f}{ass.c(outline_color, 3)}"
                f"\\shad{shadow:.1f}{ass.c('#000000', 4)}{extra}}}")
        self.doc.dialogue(t0, t1, tags + ass.esc(s), "G", layer=layer)

    def case(self, s: str) -> str:
        c = self.g.get("title_case", "none")
        if c == "upper":
            return s.upper()
        if c == "title":
            return " ".join(w[:1].upper() + w[1:] for w in s.split())
        return s


def _centre(path: str, w: float, h: float) -> str:
    """Shift a drawing whose top-left is 0,0 so it's centred on the \\pos point (\\an5 centres by bounding box)."""
    return path


# ------------------------------------------------------------- templates ----
def _lines(text: str, font: dict, size: float, max_w: float) -> list[str]:
    parts = [p.strip() for p in str(text).split("\n") if p.strip()]
    out = []
    for p in parts:
        out += textfit.wrap(p, font, size, max_w)
    return out or [str(text)]


def t_title(ctx: Ctx, b: dict, t0: float, t1: float):
    k = ctx.k
    if b.get("hide_captions"):                             # the hook replaces the captions while it's on screen
        ctx.hide.append((t0, t1))
    style = ctx.g.get("title_style", "text")
    size = float(b.get("size", ctx.g.get("heading_size", 104))) * k
    lines = _lines(ctx.case(b["text"]), ctx.fh, size, ctx.max_w * 0.92)
    while len(lines) > 3 and size > float(ctx.g.get("heading_size", 104)) * k * 0.5:
        size *= 0.88                                    # a hook is never a tower of single words: fit it in 3 lines
        lines = _lines(ctx.case(b["text"]), ctx.fh, size, ctx.max_w * 0.92)
    lh = size * 1.12
    total = lh * len(lines)
    y0 = ctx.region_y(b, total) - total / 2 + lh / 2
    rot = float(ctx.g.get("tilt", 0) or 0)
    for i, ln in enumerate(lines):
        y = y0 + i * lh
        d = i * 0.08
        lw = textfit.width(ln, ctx.fh, size)
        if style == "caption":
            # copied from a reference: hook text set exactly like its captions (same fonts, case, colours, no cards)
            accent_line = (i == len(lines) - 1 and len(lines) > 1) or b.get("accent")
            ol = ctx.style["captions"].get("outline", 0) or 0
            ctx.text(t0 + d, t1, ctx.cx, y, ln, ctx.fa if accent_line else ctx.fh, size,
                     color=ctx.col["accent"] if accent_line else ctx.col["text"], anim=ctx.g.get("entrance", "fade"),
                     outline=ol, outline_color=ctx.col["outline"], shadow=(ctx.style["captions"].get("shadow", 0) or 0) * size / max(1, ctx.style["captions"].get("size", 80)) * 1.6, rot=rot)
        elif style == "block":
            ctx.card(t0 + d, t1, ctx.cx, y, lw + size * 0.5, lh * 0.98, color=ctx.col["accent"], alpha=1.0,
                     anim=ctx.g.get("entrance"), radius=size * 0.16, rot=rot)
            ctx.text(t0 + d, t1, ctx.cx, y, ln, ctx.fh, size, color=_on(ctx.col["accent"]), rot=rot)
        elif style == "card":
            if i == 0:
                ctx.card(t0, t1, ctx.cx, y0 + total / 2 - lh / 2, max(textfit.width(x, ctx.fh, size) for x in lines) + size * 0.9,
                         total + size * 0.6, rot=rot)
            ctx.text(t0 + d, t1, ctx.cx, y, ln, ctx.fh, size, color=ctx.col["card_text"], rot=rot)
        else:
            ctx.text(t0 + d, t1, ctx.cx, y, ln, ctx.fh, size, color=ctx.col["text"],
                     outline=max(3.0, size * 0.06), outline_color=ctx.col["outline"], shadow=2, rot=rot)
    ctx.sound("entrance", t0)


def _on(bg: str) -> str:
    return "#111111" if st.luminance(bg) > 0.55 else "#FFFFFF"


def t_emphasis(ctx: Ctx, b: dict, t0: float, t1: float):
    k = ctx.k
    text = ctx.case(b["text"])
    size = float(b.get("size", ctx.g.get("heading_size", 104) * 1.25)) * k
    size = textfit.fit_size(text, ctx.fh, size, ctx.max_w)
    y = ctx.H * 0.42
    if ctx.g.get("title_style") == "caption":
        ol = ctx.style["captions"].get("outline", 0) or 0
        ctx.text(t0, t1, ctx.cx, y, text, ctx.fa, size, color=ctx.col["accent"], anim=ctx.g.get("entrance", "fade"),
                 outline=ol, outline_color=ctx.col["outline"], shadow=0)
    elif ctx.g.get("title_style") == "block":
        w = textfit.ass_width(text, ctx.fh, size)
        ctx.card(t0, t1, ctx.cx, y, w + size * 0.5, size * 1.2, color=ctx.col["accent"], alpha=1.0, anim="stamp", radius=size * 0.14)
        ctx.text(t0, t1, ctx.cx, y, text, ctx.fh, size, color=_on(ctx.col["accent"]), anim="stamp")
    else:
        ctx.text(t0, t1, ctx.cx, y, text, ctx.fh, size, color=ctx.col["accent"], anim="stamp",
                 outline=max(4.0, size * 0.07), outline_color=ctx.col["outline"], shadow=3)
    ctx.zooms.append({"start": t0, "end": t1, "scale": float(ctx.style.get("zoom", {}).get("emphasis", 1.14))})
    ctx.sound("emphasis", t0)


def t_list(ctx: Ctx, b: dict, t0: float, t1: float, times: list[float]):
    k = ctx.k
    items = [it["text"] if isinstance(it, dict) else str(it) for it in b["items"]]
    size = float(b.get("size", ctx.g.get("body_size", 56))) * k
    lh = size * 1.55
    head = b.get("title")
    hsize = size * 1.15
    total = lh * len(items) + (hsize * 1.6 if head else 0)
    w = min(ctx.max_w, max(textfit.width(f"{n + 1}. {x}", ctx.fb, size) for n, x in enumerate(items)) + size * 2.2)
    yc = ctx.region_y(b, total + size)
    y = yc - total / 2
    ctx.card(t0, t1, ctx.cx, yc, w, total + size, anim=ctx.g.get("entrance"))
    if head:
        ctx.text(t0, t1, ctx.cx, y + hsize * 0.6, ctx.case(head), ctx.fh, hsize, color=ctx.col["accent"])
        y += hsize * 1.6
    for n, (x, tn) in enumerate(zip(items, times)):
        yy = y + lh * n + lh / 2
        ctx.text(tn, t1, ctx.cx, yy, f"{n + 1}. {x}", ctx.fb, size, anim="rise", align_left_width=w - size * 1.6)
        ctx.sound("list", tn)


def _parse_number(v) -> tuple[float, str, str, int]:
    s = str(v)
    m = re.match(r"^\s*([^\d\-]*)(-?[\d,]*\.?\d+)(.*)$", s)
    if not m:
        return 0.0, "", s, 0
    num = m.group(2).replace(",", "")
    dec = len(num.split(".")[1]) if "." in num else 0
    return float(num), m.group(1), m.group(3), dec


def t_counter(ctx: Ctx, b: dict, t0: float, t1: float):
    k = ctx.k
    target, pre, suf, dec = _parse_number(b.get("value", b.get("text", "0")))
    size = float(b.get("size", ctx.g.get("heading_size", 104) * 1.35)) * k
    y = ctx.region_y(b, size * 2)
    label = b.get("label", "")
    steps = 14
    dur = min(1.1, max(0.4, (t1 - t0) * 0.45))
    for i in range(steps + 1):
        a = t0 + dur * i / steps
        z = t0 + dur * (i + 1) / steps if i < steps else t1
        v = target * (1 - (1 - i / steps) ** 3)
        s = f"{pre}{v:,.{dec}f}{suf}"
        ctx.text(a, z, ctx.cx, y, s, ctx.fh, size, color=ctx.col["accent"], anim="none" if i else "pop",
                 outline=max(4.0, size * 0.06), outline_color=ctx.col["outline"])
        if i % 3 == 0 and i < steps:
            ctx.sound("counter", a)
    if label:
        ctx.text(t0 + 0.15, t1, ctx.cx, y + size * 0.95, ctx.case(label), ctx.fb, size * 0.38, color=ctx.col["text"],
                 outline=3, outline_color=ctx.col["outline"])


def t_compare(ctx: Ctx, b: dict, t0: float, t1: float, rt: float):
    k = ctx.k
    left, right = b.get("left", {}), b.get("right", {})
    lt = left.get("text", left) if isinstance(left, dict) else str(left)
    rtx = right.get("text", right) if isinstance(right, dict) else str(right)
    size = float(b.get("size", ctx.g.get("body_size", 56))) * k
    w = ctx.max_w / 2 - 14 * k
    h = size * 3.4
    y = ctx.region_y(b, h)
    xl, xr = ctx.cx - w / 2 - 10 * k, ctx.cx + w / 2 + 10 * k
    ctx.card(t0, t1, xl, y, w, h, color=ctx.col["card"], anim="slide")
    ctx.card(rt, t1, xr, y, w, h, color=ctx.col["accent"], alpha=1.0, anim="pop")
    for txt, x, a, col in ((lt, xl, t0, ctx.col["card_text"]), (rtx, xr, rt, _on(ctx.col["accent"]))):
        lines = textfit.wrap(str(txt), ctx.fb, size, w - size)
        for i, ln in enumerate(lines[:3]):
            ctx.text(a, t1, x, y + (i - (len(lines[:3]) - 1) / 2) * size * 1.2, ln, ctx.fb, size, color=col)
    lab = b.get("labels")
    if lab:
        ctx.text(t0, t1, xl, y - h / 2 - size * 0.6, lab[0], ctx.fh, size * 0.6, color=ctx.col["text"], outline=3)
        ctx.text(rt, t1, xr, y - h / 2 - size * 0.6, lab[1], ctx.fh, size * 0.6, color=ctx.col["text"], outline=3)
    ctx.sound("entrance", t0)
    ctx.sound("emphasis", rt)


def t_chart(ctx: Ctx, b: dict, t0: float, t1: float):
    k = ctx.k
    bars = b.get("bars") or [{"label": l, "value": v} for l, v in zip(b.get("labels", []), b.get("values", []))]
    if not bars:
        raise util.Fail("A chart needs bars: [{\"label\": \"Jan\", \"value\": 10}, …].")
    vmax = max(float(x["value"]) for x in bars) or 1
    w, h = ctx.max_w, ctx.H * 0.26
    y = ctx.region_y(b, h + 120 * k)
    ctx.card(t0, t1, ctx.cx, y, w, h + 140 * k)
    n = len(bars)
    bw = (w - 80 * k) / n * 0.62
    size = 34 * k
    if b.get("title"):
        ctx.text(t0, t1, ctx.cx, y - h / 2 - 30 * k, ctx.case(b["title"]), ctx.fh, size * 1.3, color=ctx.col["accent"])
    for i, bar in enumerate(bars):
        x = ctx.cx - w / 2 + 40 * k + (w - 80 * k) * (i + 0.5) / n
        bh = max(6 * k, h * 0.8 * float(bar["value"]) / vmax)
        a = t0 + 0.25 + i * 0.12
        base = y + h / 2 - 10 * k
        col = ctx.col["accent"] if bar.get("highlight") or i == n - 1 else ctx.col["muted"]
        path = ass.rrect(bw, bh, 8 * k)
        tags = (f"{{\\an2\\pos({x:.0f},{base:.0f})\\bord0\\shad0{ass.c(col)}\\fscy0\\t(0,420,\\fscy100)\\p1}}")
        ctx.doc.dialogue(a, t1, tags + path + "{\\p0}", "G", layer=13)
        ctx.text(a, t1, x, base + 26 * k, str(bar["label"]), ctx.fb, size * 0.8, color=ctx.col["card_text"], anim="fade")
        ctx.text(a + 0.3, t1, x, base - bh - 24 * k, str(bar.get("text", bar["value"])), ctx.fh, size, color=ctx.col["card_text"], anim="fade")
    ctx.sound("entrance", t0)


def t_quote(ctx: Ctx, b: dict, t0: float, t1: float):
    k = ctx.k
    size = float(b.get("size", ctx.g.get("body_size", 56) * 1.05)) * k
    lines = textfit.wrap(f"“{b['text']}”", ctx.fh, size, ctx.max_w - size * 1.6)
    lh = size * 1.25
    h = lh * len(lines) + size * (2.2 if b.get("by") else 1.2)
    y = ctx.region_y(b, h)
    ctx.card(t0, t1, ctx.cx, y, ctx.max_w, h, anim=ctx.g.get("entrance"))
    y0 = y - h / 2 + size * 0.6 + lh / 2
    for i, ln in enumerate(lines):
        ctx.text(t0 + 0.1 + i * 0.06, t1, ctx.cx, y0 + i * lh, ln, ctx.fh, size, color=ctx.col["card_text"])
    if b.get("by"):
        ctx.text(t0 + 0.3, t1, ctx.cx, y0 + len(lines) * lh + size * 0.2, f"— {b['by']}", ctx.fb, size * 0.6, color=ctx.col["accent"])
    ctx.sound("entrance", t0)


def t_note(ctx: Ctx, b: dict, t0: float, t1: float):
    k = ctx.k
    size = float(b.get("size", ctx.g.get("body_size", 56) * 0.9)) * k
    lines = textfit.wrap(str(b["text"]), ctx.fb, size, ctx.max_w * 0.7)
    lh = size * 1.25
    w = max(textfit.width(x, ctx.fb, size) for x in lines) + size * 1.4
    h = lh * len(lines) + size * 0.9
    y = ctx.region_y(b, h)
    rot = float(b.get("tilt", ctx.g.get("tilt", -2) or -2))
    ctx.card(t0, t1, ctx.cx, y, w, h, color=ctx.col["accent"], alpha=1.0, anim="pop", rot=rot, radius=10 * k)
    for i, ln in enumerate(lines):
        ctx.text(t0, t1, ctx.cx, y - h / 2 + size * 0.45 + lh * (i + 0.5), ln, ctx.fb, size, color=_on(ctx.col["accent"]), anim="pop", rot=rot)
    ctx.sound("emphasis", t0)


def t_nametag(ctx: Ctx, b: dict, t0: float, t1: float):
    k = ctx.k
    name = b.get("text") or util.load_profile().get("name", "")
    sub = b.get("sub") or util.load_profile().get("handle", "")
    size = 50 * k
    w = max(textfit.width(name, ctx.fh, size), textfit.width(sub, ctx.fb, size * 0.6)) + 70 * k
    x = ctx.W * ctx.plat["safe"]["left"] + w / 2 + 10 * k
    y = ctx.cap_y - 170 * k
    ctx.card(t0, t1, x, y, w, size * 2.3, anim="slide")
    ctx.text(t0 + 0.1, t1, x, y - size * 0.32, name, ctx.fh, size, color=ctx.col["card_text"], anim="slide")
    if sub:
        ctx.text(t0 + 0.18, t1, x, y + size * 0.55, sub, ctx.fb, size * 0.6, color=ctx.col["accent"], anim="slide")
    ctx.sound("entrance", t0)


def t_cta(ctx: Ctx, b: dict, t0: float, t1: float):
    k = ctx.k
    text = ctx.case(b.get("text") or util.load_profile().get("cta") or "Follow for more")
    size = float(b.get("size", 64)) * k
    size = textfit.fit_size(text, ctx.fh, size, ctx.max_w - 80 * k)
    w = textfit.width(text, ctx.fh, size) + size * 1.4
    y = ctx.H * 0.30
    ctx.card(t0, t1, ctx.cx, y, w, size * 2.0, color=ctx.col["accent"], alpha=1.0, anim="pop", radius=size)
    ctx.text(t0, t1, ctx.cx, y, text, ctx.fh, size, color=_on(ctx.col["accent"]), anim="pop")
    ctx.sound("cta", t0)


def _find_image(ctx: Ctx, name: str) -> Path:
    for cand in (Path(name), ctx.project / name, ctx.project / "media" / name, util.BRAND / "proof" / name, util.ROOT / name,
                 util.BRAND / name):
        if cand.exists():
            return cand
    raise util.Fail(f"Can't find the image '{name}'.", "Put it in my-brand/proof/ and use just its file name in beats.json.")


_resolve_image = _find_image


def _picture(ctx: Ctx, b: dict, n: int, tw: int, th: int, sticker: bool) -> Path:
    from PIL import Image, ImageDraw, ImageFilter
    src = _find_image(ctx, b["file"])
    out = ctx.project / "render" / f"img-{n}.png"
    out.parent.mkdir(parents=True, exist_ok=True)
    if src.suffix.lower() in util.VIDEO_EXT:
        frame_png = ctx.project / "render" / f"img-{n}-frame.png"
        util.run([util.ffmpeg_bin(), "-y", "-hide_banner", "-ss", "1", "-i", str(src), "-frames:v", "1", str(frame_png)])
        src = frame_png
    im = Image.open(src).convert("RGBA")
    s = min(tw / im.width, th / im.height)
    im = im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), Image.LANCZOS)
    r = int(ctx.radius)
    mask = Image.new("L", im.size, 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, im.width - 1, im.height - 1), radius=r, fill=255)
    pad = int(14 * ctx.k) if sticker else 0
    canvas = Image.new("RGBA", (im.width + 2 * pad + 40, im.height + 2 * pad + 40), (0, 0, 0, 0))
    if ctx.g.get("shadow", True):
        sh = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
        ImageDraw.Draw(sh).rounded_rectangle((20, 28, 20 + im.width + 2 * pad, 28 + im.height + 2 * pad), radius=r + pad, fill=(0, 0, 0, 110))
        canvas = Image.alpha_composite(canvas, sh.filter(ImageFilter.GaussianBlur(14)))
    if sticker:
        ImageDraw.Draw(canvas).rounded_rectangle((20, 20, 20 + im.width + 2 * pad, 20 + im.height + 2 * pad), radius=r + pad, fill=(255, 255, 255, 255))
    canvas.paste(im, (20 + pad, 20 + pad), mask)
    tilt = float(b.get("tilt", ctx.g.get("tilt", 0) or 0))
    if abs(tilt) > 0.05:
        canvas = canvas.rotate(tilt, resample=Image.BICUBIC, expand=True)
    canvas.save(out)
    return out


def t_proof(ctx: Ctx, b: dict, t0: float, t1: float, n: int):
    tw, th = int(ctx.max_w * 0.86), int(ctx.H * 0.36)
    out = _picture(ctx, b, n, tw, th, sticker=bool(ctx.g.get("sticker")))
    from PIL import Image
    w, h = Image.open(out).size
    y = ctx.region_y(b, h)
    ctx.overlays.append({"png": str(out), "x": ctx.cx - w / 2, "y": y - h / 2, "start": t0, "end": t1,
                         "anim": "rise", "w": w, "h": h})
    if b.get("caption"):
        ctx.text(t0 + 0.2, t1, ctx.cx, y + h / 2 + 30 * ctx.k, ctx.case(b["caption"]), ctx.fh, 44 * ctx.k,
                 color=ctx.col["text"], outline=4, outline_color=ctx.col["outline"])
    ctx.sound("proof" if ctx.style.get("sfx", {}).get("proof") else "entrance", t0)


def t_image(ctx: Ctx, b: dict, t0: float, t1: float, n: int):
    from PIL import Image
    mode = b.get("mode", "card")
    src = _find_image(ctx, b["file"])
    out = ctx.project / "render" / f"img-{n}.png"
    out.parent.mkdir(parents=True, exist_ok=True)
    if mode == "card":
        out = _picture(ctx, b, n, int(ctx.max_w * 0.8), int(ctx.H * 0.34), sticker=bool(ctx.g.get("sticker")))
        w, h = Image.open(out).size
        y = ctx.region_y(b, h)
        ctx.overlays.append({"png": str(out), "x": ctx.cx - w / 2, "y": y - h / 2, "start": t0, "end": t1,
                             "anim": "rise", "w": w, "h": h})
        ctx.sound("entrance", t0)
        return
    if src.suffix.lower() in util.VIDEO_EXT:
        frame_png = ctx.project / "render" / f"img-{n}-frame.png"
        util.run([util.ffmpeg_bin(), "-y", "-hide_banner", "-ss", "1", "-i", str(src), "-frames:v", "1", str(frame_png)])
        src = frame_png
    im = Image.open(src).convert("RGB")
    if mode == "full":
        tw, th = ctx.W, ctx.H
    else:
        tw, th = ctx.W, int(ctx.H * 0.5)
    s = max(tw / im.width, th / im.height)
    im = im.resize((int(im.width * s) + 1, int(im.height * s) + 1), Image.LANCZOS)
    left, top = (im.width - tw) // 2, (im.height - th) // 2
    im.crop((left, top, left + tw, top + th)).save(out)
    ctx.overlays.append({"png": str(out), "x": 0, "y": 0, "start": t0, "end": t1, "anim": "fade", "w": tw, "h": th})
    if mode == "full" and b.get("hide_captions", False):
        ctx.hide.append((t0, t1))
    ctx.sound("entrance", t0)


# ------------------------------------------------------------- b-roll -------
def t_broll(ctx: Ctx, b: dict, t0: float, t1: float) -> None:
    """A B-roll clip or photo over the talking head: full screen (cutaway) or picture-in-picture.
    Photos move (slow push-in / pan) so they never feel static. Captions stay on top."""
    f = _resolve_image(ctx, b["file"]) if b.get("file") else None
    if f is None:
        raise util.Fail("A B-roll beat needs a 'file' (from the project's media folder).")
    mode = b.get("mode", ctx.style.get("broll", {}).get("mode", "full"))
    motion = b.get("motion", "push" if f.suffix.lower() in util.IMAGE_EXT else "none")
    ctx.brolls.append({"file": str(f), "start": t0, "end": t1, "mode": mode, "motion": motion,
                       "offset": float(b.get("from", 0.0)), "image": f.suffix.lower() in util.IMAGE_EXT})
    ctx.sound("entrance", t0)


# ------------------------------------------------------------- build --------
def build(doc: ass.Doc, beats: list[dict], words: list[dict], duration: float, style: dict, plat: dict,
          project: Path) -> Ctx:
    ctx = Ctx(doc, style, plat, project)
    clock = Clock(words, duration)
    cursor = 0.0
    placed = []
    for n, b in enumerate(beats):
        typ = b.get("type")
        where = f"beat {n + 1} ({typ})"
        if typ == "steps":
            typ = "list"
        if typ == "stat":
            typ = "counter"
        if typ not in TEMPLATES:
            raise util.Fail(f"{where}: unknown graphic type '{typ}'.", f"Use one of: {', '.join(TEMPLATES)}")
        t0 = clock.at(b.get("at"), default=cursor, after=cursor, where=where)
        if typ == "list" and b.get("at") is None:
            first = b["items"][0].get("at") if isinstance(b["items"][0], dict) else None
            if first is not None:
                t0 = max(0.0, clock.at(first, default=cursor, after=cursor, where=where) - 0.45)
        if typ == "cta" and b.get("at") is None:
            t0 = max(0.0, duration - float(b.get("duration", 3.0)))
        item_times = []
        if typ == "list":
            last = max(0.0, t0)
            for j, it in enumerate(b["items"]):
                spec = it.get("at") if isinstance(it, dict) else None
                tj = clock.at(spec, default=last + (0.5 if j else 0.35), after=last, where=f"{where} item {j + 1}")
                item_times.append(tj)
                last = tj
        if "until" in b:
            t1 = clock.at(b["until"], default=t0 + 2, after=t0, where=where)
        elif "duration" in b:
            t1 = t0 + float(b["duration"])
        elif typ == "list":
            t1 = item_times[-1] + 2.2 if item_times else t0 + 3
        elif typ == "cta":
            t1 = duration
        else:
            t1 = t0 + DEFAULT_DUR.get(typ, 2.5)
        t1 = min(max(t1, t0 + 0.5), duration)
        if t0 >= duration - 0.2:
            ctx.warnings.append(f"{where} starts after the video ends, skipped.")
            continue
        region = b.get("position", style["graphics"].get("position", "top")) if typ not in ("image", "nametag", "cta", "emphasis", "broll") else typ
        def clash(r):
            return [wn for (rr, a, z, wn) in placed if rr == r and t0 < z - 0.05 and t1 > a + 0.05]
        if clash(region):
            if "position" not in b and region in ("top", "bottom", "middle"):
                for alt in ("top", "bottom", "middle"):
                    if not clash(alt):
                        b = dict(b, position=alt)
                        region = alt
                        break
            if clash(region):
                ctx.warnings.append(f"{where} overlaps {clash(region)[0]} in the same spot ({util.fmt_time(t0)}). "
                                    "Change one 'at' or 'position' so they don't cover each other.")
        placed.append((region, t0, t1, where))
        if typ == "title":
            t_title(ctx, b, t0, t1)
        elif typ == "emphasis":
            t_emphasis(ctx, b, t0, t1)
        elif typ == "list":
            t_list(ctx, b, t0, t1, item_times)
        elif typ == "counter":
            t_counter(ctx, b, t0, t1)
        elif typ == "compare":
            rt = clock.at((b.get("right") or {}).get("at") if isinstance(b.get("right"), dict) else None,
                          default=t0 + 0.7, after=t0, where=where)
            t_compare(ctx, b, t0, t1, rt)
        elif typ == "chart":
            t_chart(ctx, b, t0, t1)
        elif typ == "quote":
            t_quote(ctx, b, t0, t1)
        elif typ == "note":
            t_note(ctx, b, t0, t1)
        elif typ == "nametag":
            t_nametag(ctx, b, t0, t1)
        elif typ == "cta":
            t_cta(ctx, b, t0, t1)
        elif typ == "proof":
            t_proof(ctx, b, t0, t1, n)
        elif typ == "image":
            t_image(ctx, b, t0, t1, n)
        elif typ == "broll":
            t_broll(ctx, b, t0, t1)
        cursor = t0
    return ctx


def progress_bar(doc: ass.Doc, style: dict, plat: dict, duration: float) -> None:
    """A thin bar along the top that fills as the video plays (keeps people watching to the end)."""
    W, H = plat["width"], plat["height"]
    y = H * plat["safe"]["top"] * 0.55
    h = max(6, H * 0.004)
    col = style["colors"]["accent"]
    steps = max(20, int(duration * 4))
    doc.drawing(0, duration, f"m 0 0 l {W} 0 {W} {h:.1f} 0 {h:.1f}", 0, y, "#FFFFFF", opacity=0.18, layer=30, style="Default")
    for i in range(steps):
        a, z = duration * i / steps, duration * (i + 1) / steps
        w = W * (i + 1) / steps
        doc.drawing(a, z, f"m 0 0 l {w:.0f} 0 {w:.0f} {h:.1f} 0 {h:.1f}", 0, y, col, opacity=1.0, layer=31, style="Default")
