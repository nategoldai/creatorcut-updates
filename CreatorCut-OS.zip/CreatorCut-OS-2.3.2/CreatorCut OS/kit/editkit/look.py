"""Colour grades, punch-in zooms, voice clean-up, music under the voice and sound effects."""
from __future__ import annotations

from pathlib import Path

from . import util

GRADES = {
    "none":      {"label": "Untouched", "filter": ""},
    "natural":   {"label": "Natural, slightly richer", "filter": "eq=contrast=1.04:saturation=1.06:gamma=0.99"},
    "clean":     {"label": "Bright and clean", "filter": "eq=brightness=0.025:contrast=1.03:saturation=1.03,curves=m='0/0 0.5/0.53 1/1'"},
    "warm":      {"label": "Warm and friendly", "filter": "colorbalance=rs=0.03:bs=-0.03:rm=0.04:bm=-0.04:rh=0.02:bh=-0.03,eq=saturation=1.08:contrast=1.03"},
    "punchy":    {"label": "Punchy, high energy", "filter": "eq=contrast=1.12:saturation=1.22:gamma=0.98,unsharp=5:5:0.45:5:5:0"},
    "cinematic": {"label": "Cinematic teal & orange", "filter": "colorbalance=rs=-0.04:gs=0.0:bs=0.05:rh=0.05:gh=0.01:bh=-0.05,"
                  "curves=m='0/0.02 0.25/0.22 0.75/0.78 1/0.97',eq=saturation=0.96:contrast=1.05,vignette=PI/5"},
    "moody":     {"label": "Moody, darker", "filter": "eq=contrast=1.1:brightness=-0.03:saturation=0.82,curves=m='0/0.03 0.5/0.46 1/0.94',vignette=PI/4.5"},
    "soft":      {"label": "Soft, airy, pastel", "filter": "eq=brightness=0.035:contrast=0.94:saturation=0.9,curves=m='0/0.06 0.5/0.55 1/0.98'"},
    "luxe":      {"label": "Luxury, rich and deep", "filter": "eq=contrast=1.07:saturation=0.92:gamma=0.97,colorbalance=rh=0.03:bh=-0.02:rs=-0.01:bs=0.02,vignette=PI/6"},
    "mono":      {"label": "Black & white", "filter": "hue=s=0,eq=contrast=1.12"},
    "film":      {"label": "Film look with grain", "filter": "curves=m='0/0.05 0.5/0.5 1/0.95',eq=saturation=0.9,noise=alls=7:allf=t,vignette=PI/5"},
}


def grade_filter(name: str) -> str:
    return GRADES.get(name or "natural", GRADES["natural"])["filter"]


def zoom_filter(segments: list[dict], emph: list[dict], style: dict, W: int, H: int, fps: float) -> str:
    """Punch-in zooms that change at every cut (classic creator jump-cut look) plus pushes on emphasis beats."""
    z = style.get("zoom", {})
    if not segments and not emph:
        return ""
    punch = float(z.get("punch_in", 1.06))
    pattern = z.get("pattern", "alternate")
    emph_scale = float(z.get("emphasis", 1.14))
    fy = float(z.get("focus_y", 0.38))
    terms = []
    for k, s in enumerate(segments):
        on = (pattern == "always" or (pattern == "alternate" and k % 2 == 1) or (pattern == "every-3" and k % 3 == 2))
        if on and pattern != "none" and punch > 1.0:
            terms.append(f"between(t,{s['start']:.3f},{s['end']:.3f})*{punch - 1:.3f}")
    for e in emph or []:
        a, b = float(e["start"]), float(e["end"])
        sc = float(e.get("scale", emph_scale))
        # quick push in over 0.18s, hold, ease back over 0.25s
        terms.append(f"between(t,{a:.3f},{b:.3f})*{sc - 1:.3f}*min(1,(t-{a:.3f})/0.18)*min(1,({b:.3f}-t)/0.25)")
    if not terms:
        return ""
    zexpr = "1+" + "+".join(terms)
    return (f"scale=w='trunc(iw*({zexpr})/2)*2':h='trunc(ih*({zexpr})/2)*2':eval=frame:flags=bicubic,"
            f"crop=w={W}:h={H}:x='(iw-{W})/2':y='(ih-{H})*{fy:.3f}'")


VOICE = ("highpass=f=75,lowpass=f=15000,afftdn=nf=-30,"
         "equalizer=f=180:t=q:w=1.2:g=-2,equalizer=f=3200:t=q:w=1.4:g=2.5,"
         "acompressor=threshold=0.09:ratio=3:attack=8:release=120:makeup=1.6")


def cube(name: str) -> Path | None:
    """A .cube LUT file for a grade, if one ships with the kit (kit/luts/<name>.cube)."""
    p = util.KIT / "luts" / f"{name}.cube"
    return p if p.exists() else None


def pick_music(cfg: dict, style: dict | None = None) -> Path | None:
    """'auto': the creator's own music if they added any (to the project or my-brand/music), otherwise an original
    track from the built-in library that matches the style's mood and tempo. 'library:<mood>' picks one directly."""
    m = cfg.get("music")
    if m in (None, "", "none", False):
        return None
    style = style or {}
    if m == "auto":
        if style.get("music", {}).get("enabled") is False:
            return None
        proj = [util.ROOT / x["file"] for x in cfg.get("media", []) if x.get("kind") == "music"]
        if proj and proj[0].exists():
            return proj[0]
        tracks = sorted(p for p in util.MUSIC.glob("*") if p.suffix.lower() in util.AUDIO_EXT)
        if tracks:
            return tracks[0]
        from . import musicgen
        return musicgen.pick(style.get("music", {}).get("mood"), style.get("music", {}).get("bpm"), int(style.get("energy", 3)))
    if isinstance(m, str) and m.startswith("library:"):
        from . import musicgen
        return musicgen.pick(m.split(":", 1)[1])
    p = Path(m)
    for cand in (p, util.MUSIC / m, util.ROOT / m):
        if cand.exists():
            return cand
    util.warn(f"Couldn't find the music file '{m}', so the video has no music. Put tracks in the my-brand/music folder.")
    return None


def sfx_path(name: str) -> Path | None:
    if not name:
        return None
    p = util.SFX_DIR / f"{name}.wav"
    if not p.exists():
        from . import sfx
        sfx.ensure()
    return p if p.exists() else None
