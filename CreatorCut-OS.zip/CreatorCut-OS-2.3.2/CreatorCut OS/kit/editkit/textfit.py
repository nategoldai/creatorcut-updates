"""Measure text the way libass will draw it, to fit captions and titles inside the safe area."""
from __future__ import annotations

from functools import lru_cache

from . import styles as st


@lru_cache(maxsize=64)
def _font(path: str, size: int):
    from PIL import ImageFont
    return ImageFont.truetype(path, size)


def width(text: str, font: dict, size: float) -> float:
    """Approximate rendered width in pixels of `text` at ASS size `size` (after the engine's size normalisation)."""
    try:
        f = _font(font["file"], 200)
        asc, desc = f.getmetrics()
        w200 = f.getlength(text) * 200 / float(asc + desc)
        return w200 * st.fs(font, size) / 200 * st.width_fix(font)
    except Exception:
        return len(text) * size * 0.55


def fit_size(text: str, font: dict, size: float, max_w: float, min_scale: float = 0.55) -> float:
    w = width(text, font, size)
    if w <= max_w or w <= 0:
        return size
    return max(size * min_scale, size * max_w / w)


def balanced_wrap(text: str, font: dict, size: float, max_w: float) -> list[str]:
    """Split into two lines of similar width (never one long line and one orphan word)."""
    words = text.split()
    if len(words) < 2:
        return [text]
    best, best_cost = [text], float("inf")
    for k in range(1, len(words)):
        a, b = " ".join(words[:k]), " ".join(words[k:])
        wa, wb = width(a, font, size), width(b, font, size)
        cost = max(wa, wb) + abs(wa - wb) * 0.35
        if cost < best_cost:
            best, best_cost = [a, b], cost
    return best


def wrap(text: str, font: dict, size: float, max_w: float, max_lines: int = 4) -> list[str]:
    """Greedy wrap into lines that fit max_w."""
    lines, cur = [], ""
    for w in text.split():
        cand = (cur + " " + w).strip()
        if cur and width(cand, font, size) > max_w:
            lines.append(cur)
            cur = w
        else:
            cur = cand
    if cur:
        lines.append(cur)
    return lines[:max_lines]


def ass_width(text: str, font: dict, size: float) -> float:
    return width(text, font, size)
