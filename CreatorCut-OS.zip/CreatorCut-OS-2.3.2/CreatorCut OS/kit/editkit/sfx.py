"""The sound-effects library is synthesised with FFmpeg, so every sound is original and free to use."""
from __future__ import annotations

from . import util

SOUNDS = {
    "whoosh": ("anoisesrc=d=0.5:c=pink:a=0.6,highpass=f=350,lowpass=f=5500,"
               "afade=t=in:d=0.18:curve=exp,afade=t=out:st=0.2:d=0.3:curve=exp,volume=1.6", "graphic slides in"),
    "swoosh": ("anoisesrc=d=0.28:c=white:a=0.5,highpass=f=1500,lowpass=f=9000,"
               "afade=t=in:d=0.08,afade=t=out:st=0.08:d=0.2,volume=1.2", "quick light swipe"),
    "pop": ("aevalsrc='0.9*sin(2*PI*t*(1100-5200*t))*exp(-t*38)':d=0.14:s=48000", "a word or badge pops"),
    "click": ("aevalsrc='0.7*sin(2*PI*2600*t)*exp(-t*240)+0.2*(random(0)-0.5)*exp(-t*400)':d=0.05:s=48000", "list item appears"),
    "tick": ("aevalsrc='0.55*sin(2*PI*1900*t)*exp(-t*140)':d=0.06:s=48000", "number counter"),
    "ding": ("aevalsrc='0.5*(sin(2*PI*1320*t)+0.45*sin(2*PI*2640*t)+0.2*sin(2*PI*3960*t))*exp(-t*3.6)':d=1.3:s=48000",
             "call to action / success"),
    "thud": ("aevalsrc='0.95*sin(2*PI*t*(140-90*t))*exp(-t*9)':d=0.45:s=48000", "big emphasis hit"),
    "riser": ("aevalsrc='0.35*sin(2*PI*t*(180+900*t*t))*min(1,t/0.9)':d=1.0:s=48000,afade=t=out:st=0.85:d=0.15",
              "build-up before a reveal"),
    "camera": ("aevalsrc='0.6*(random(0)-0.5)*exp(-t*90)+0.4*(random(1)-0.5)*exp(-(t-0.07)*90)*gt(t,0.07)':d=0.16:s=48000",
               "screenshot / proof appears"),
}


def ensure(force: bool = False) -> int:
    util.SFX_DIR.mkdir(parents=True, exist_ok=True)
    made = 0
    for name, (graph, _) in SOUNDS.items():
        out = util.SFX_DIR / f"{name}.wav"
        if out.exists() and not force:
            continue
        util.run([util.ffmpeg_bin(), "-y", "-hide_banner", "-f", "lavfi", "-i", graph, "-af",
                  "aformat=sample_rates=48000:channel_layouts=stereo,alimiter=limit=0.9", str(out)])
        made += 1
    if made:
        util.ok(f"Made {made} sound effects")
    return made


def volume(style: dict, name: str) -> float:
    s = style.get("sfx", {})
    base = float(s.get("volume", 0.32))
    return round(base * (1.25 if name in ("thud", "ding") else 0.8 if name in ("tick", "click") else 1.0), 3)
