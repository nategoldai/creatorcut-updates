"""Bounded, asynchronous real-video thumbnails; state requests never run FFmpeg."""
from __future__ import annotations

import hashlib
import threading
import time
from pathlib import Path

from . import util

_lock = threading.Lock()
_active = set()
_failed = {}


def cached(video: Path) -> Path | None:
    video = Path(video).resolve()
    try:
        if not video.is_relative_to(util.ROOT.resolve()) or not video.is_file():
            return None
        stat = video.stat()
    except OSError:
        return None
    fingerprint = hashlib.sha256(f'{video}:{stat.st_size}:{stat.st_mtime_ns}'.encode()).hexdigest()[:24]
    target = util.STUDIO_OUT / 'assets' / 'posters' / f'frame-{fingerprint}.jpg'
    if target.exists() and target.stat().st_size > 0:
        return target
    with _lock:
        if fingerprint in _active or len(_active) >= 2 or time.monotonic() - _failed.get(fingerprint, -1000) < 60:
            return None
        _active.add(fingerprint)
    threading.Thread(target=_extract, args=(video, target, fingerprint), daemon=True).start()
    return None


def _extract(video, target, fingerprint):
    temporary = target.with_suffix('.pending.jpg')
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        util.run([util.ffmpeg_bin(), '-nostdin', '-y', '-hide_banner', '-loglevel', 'error',
                  '-i', str(video), '-frames:v', '1', '-vf', 'scale=540:-2', '-q:v', '3', str(temporary)], timeout=15)
        if temporary.exists() and temporary.stat().st_size:
            temporary.replace(target)
        else:
            raise util.Fail('No thumbnail frame was decoded.')
    except Exception:
        with _lock:
            _failed[fingerprint] = time.monotonic()
            # Bound metadata even after many deleted/corrupt uploads.
            for old in list(_failed)[:-256]:
                _failed.pop(old, None)
        util.log_exception('video thumbnail')
    finally:
        temporary.unlink(missing_ok=True)
        with _lock:
            _active.discard(fingerprint)
