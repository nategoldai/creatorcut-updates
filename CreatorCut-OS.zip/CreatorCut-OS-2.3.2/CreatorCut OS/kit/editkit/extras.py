"""Library extras: cover images with hook text, before/after videos, other-platform versions, shorts, the style tour."""
from __future__ import annotations

import shutil
from pathlib import Path

from . import ass, platforms, render, textfit, util
from . import styles as st


def cover(project: Path, text: str, at: float | None = None) -> Path:
    """A cover image: a strong frame with the hook text inside Instagram's grid-safe middle (3:4)."""
    from PIL import Image, ImageDraw, ImageFont
    cfg = util.read_json(project / "project.json")
    style = st.for_project(cfg)
    src = util.ROOT / cfg["latest"] if cfg.get("latest") else project / "cut.mp4"
    info = util.probe(src)
    t = at if at is not None else min(info["duration"] * 0.3, 2.5)
    frame = project / "render" / "cover-frame.png"
    frame.parent.mkdir(parents=True, exist_ok=True)
    util.run([util.ffmpeg_bin(), "-y", "-hide_banner", "-ss", f"{t:.2f}", "-i", str(src), "-frames:v", "1", str(frame)])
    im = Image.open(frame).convert("RGB")
    W, H = im.size
    d = ImageDraw.Draw(im)
    font = st.resolve_font(style["fonts"]["heading"])
    safe_w = W * 0.82
    size = int(W * 0.11)
    text = text.upper() if style["graphics"].get("title_case") == "upper" else text

    def wrap(font):
        lines, cur = [], ""
        for w in text.split():
            cand = (cur + " " + w).strip()
            if cur and d.textlength(cand, font=font) > safe_w:
                lines.append(cur)
                cur = w
            else:
                cur = cand
        if cur:
            lines.append(cur)
        return lines

    while True:
        f = ImageFont.truetype(font["file"], size)
        lines = wrap(f)
        if len(lines) <= 3 or size < W * 0.06:
            break
        size = int(size * 0.9)
    lh = size * 1.12
    y = H * 0.5 - lh * len(lines) / 2
    accent = style["colors"]["accent"]
    for i, ln in enumerate(lines):
        w = d.textlength(ln, font=f)
        x = (W - w) / 2
        d.text((x, y + i * lh), ln, font=f, fill=accent if i == len(lines) - 1 and len(lines) > 1 else style["colors"]["text"],
               stroke_width=max(3, size // 14), stroke_fill=style["colors"]["outline"])
    util.FINISHED.mkdir(parents=True, exist_ok=True)
    out = util.FINISHED / f"{project.name}-cover.jpg"
    im.save(out, quality=92)
    util.ok(f"Cover saved: {util.rel(out)}")
    return out


def compare(project: Path) -> Path:
    """A before/after video: the raw clip on the left, the edit on the right (great content for the creator)."""
    cfg = util.read_json(project / "project.json")
    if not cfg.get("latest"):
        raise util.Fail("Render the final video first.", f"Run: edit.py render {project.name}")
    final = util.ROOT / cfg["latest"]
    from . import workflow
    current=workflow.require_release(project)
    if cfg.get('selected_version') and workflow.digest(final)!=current['sha256']:
        raise util.Fail('This historical version needs its matching cut reconstructed for a synchronized comparison.')
    cut_source=project/'cut.mp4'
    if not cut_source.exists(): raise util.Fail('Rebuild the approved cut before making a synchronized comparison.')
    src={'path':str(cut_source)}
    fin = util.probe(final)
    dur = min(fin["duration"], 30.0)
    plat = platforms.get(cfg.get("platform", "tiktok"))
    W, H = plat["width"], plat["height"]
    half = W // 2 // 2 * 2
    font = st.resolve_font("inter-black")
    label = (f"drawtext=fontfile='{font['file']}':text='%s':fontcolor=white:fontsize={int(W * 0.045)}:"
             f"x=(w-text_w)/2:y=h*0.08:box=1:boxcolor=black@0.55:boxborderw=14")
    graph = (f"[0:v]scale={half}:{H}:force_original_aspect_ratio=increase,crop={half}:{H},setsar=1,{label % 'BEFORE'}[l];"
             f"[1:v]scale={half}:{H}:force_original_aspect_ratio=increase,crop={half}:{H},setsar=1,{label % 'AFTER'}[r];"
             f"[l][r]hstack=inputs=2,format=yuv420p[v]")
    util.FINISHED.mkdir(parents=True, exist_ok=True)
    out = util.FINISHED / f"{project.name}-before-after.mp4"
    util.run([util.ffmpeg_bin(), "-y", "-hide_banner", "-t", f"{dur:.2f}", "-i", src["path"], "-t", f"{dur:.2f}",
              "-i", render._relpath(final, project), "-filter_complex", graph, "-map", "[v]", "-map", "1:a",
              "-c:v", "libx264", "-crf", "20", "-preset", "fast", "-c:a", "aac", "-shortest",
              render._relpath(out, project)], cwd=project, label="Before/after video made")
    return out


# ------------------------------------------------------ child projects -------
def _child(project: Path, name: str, updates: dict) -> Path:
    child = util.PROJECTS / name
    child.mkdir(parents=True, exist_ok=True)
    for f in ("source.json", "transcript.json", "transcript.txt", "plan.json", "beats.json"):
        if (project / f).exists():
            shutil.copy2(project / f, child / f)
    cfg = util.read_json(project / "project.json")
    cfg.update(updates)
    cfg.pop("latest", None)
    cfg["version"] = 0
    cfg["parent"] = project.name
    util.write_json(child / "project.json", cfg)
    return child


def export_to(project: Path, targets: list[str]) -> list[Path]:
    """Prepare derivative projects for the agent. A different aspect ratio needs a design review."""
    from . import workflow
    workflow.require_release(project)
    outs=[]
    for target in targets:
        plat=platforms.get(target)
        name=f"{project.name}-{plat['key']}"
        n=2; base=name
        while (util.PROJECTS/name).exists():
            name=f'{base}-{n}'; n+=1
        child=_child(project,name,{'platform':plat['key'],'name':name,'title':f"{project.name} · {plat['label']}", 'studio':True, 'status':'new'})
        cfg=util.read_json(child/'project.json');cfg.pop('shelf',None);cfg.pop('selected_version',None)
        util.write_json(child/'project.json',cfg)
        # Keep originals and the parent's approved plan as design evidence, not a
        # ready-made final composition at the wrong aspect ratio.
        for source in ('edit-plan.json','scene-plan.json','words.json','segments.json'):
            if (project/source).exists():shutil.copy2(project/source,child/f'parent-{source}')
        cfg=util.read_json(child/'project.json')
        cfg['brief']={'prompt':f"Adapt parent project {project.name} to {plat['label']}. Use the same approved takes, reflow the design, then render/review. Parent evidence is in parent-*.json."}
        util.write_json(child/'project.json',cfg)
        outs.append(child)
    return outs


def make_short(project: Path, start: float, end: float, name: str) -> Path:
    pl = util.read_json(project / "plan.json")
    for ph in pl["phrases"]:
        if ph["end"] <= start or ph["start"] >= end:
            ph["keep"] = False
            ph["reason"] = "outside this short"
    child = _child(project, name, {"status": "planned"})
    util.write_json(child / "plan.json", pl)
    if (child / "beats.json").exists():
        (child / "beats.json").unlink()   # beats from the long video don't fit the short
    return child


# ----------------------------------------------------------- style tour ----
def style_tour(project: Path, seconds: float = 4.0, style_ids: list[str] | None = None) -> Path:
    cfg = util.read_json(project / "project.json")
    ids = style_ids or [s["id"] for s in st.list_styles()]
    tour = util.PROJECTS / "_tour" / project.name
    if tour.exists():
        shutil.rmtree(tour)
    clips = []
    for sid in ids:
        d = tour / sid
        d.mkdir(parents=True)
        for f in ("cut.mp4", "words.json", "segments.json", "beats.json", "source.json"):
            if (project / f).exists():
                shutil.copy2(project / f, d / f)
        c = dict(cfg, style=sid, grade=None)
        util.write_json(d / "project.json", c)
        out = d / "clip.mp4"
        try:
            render.render(d, preview=True, out_path=out, limit=seconds + 0.3)
        except util.Fail as e:
            util.warn(f"Skipped {sid}: {e.message}")
            continue
        # label + trim
        sty = st.load(sid)
        doc = ass.Doc(540, 960)
        doc.add_style("L", st.resolve_font("inter-black"), 34, primary="#FFFFFF", align=7)
        doc.dialogue(0, seconds, f"{{\\an7\\pos(24,24)\\bord0\\shad0}}{{\\p1{ass.c('#000000')}{ass.a(0.55)}}}"
                                 f"{ass.rrect(textfit.ass_width(sty['name'], st.resolve_font('inter-black'), 34) + 40, 56, 28)}"
                                 f"{{\\p0}}", "L")
        out = d / "clip.mp4"
        try:
            render.render(d, preview=True, out_path=out, limit=seconds + 0.3)
        except util.Fail as e:
            util.warn(f"Skipped {sid}: {e.message}")
            continue
        # label + trim
        sty = st.load(sid)
        doc = ass.Doc(540, 960)
        doc.add_style("L", st.resolve_font("inter-black"), 34, primary="#FFFFFF", align=7)
        doc.dialogue(0, seconds, f"{{\\an7\\pos(24,24)\\bord0\\shad0}}{{\\p1{ass.c('#000000')}{ass.a(0.55)}}}"
                                 f"{ass.rrect(textfit.ass_width(sty['name'], st.resolve_font('inter-black'), 34) + 40, 56, 28)}"
                                 f"{{\\p0}}", "L")
        doc.dialogue(0, seconds, f"{{\\an7\\pos(44,34)\\bord0\\shad0}}{ass.esc(sty['name'])}", "L", layer=1)
        (d / "label.ass").write_text(doc.render(), encoding="utf-8")
        labelled = d / "labelled.mp4"
        fonts_rel = render._relpath(util.FONTS_DIR, d)
        util.run([util.ffmpeg_bin(), "-y", "-hide_banner", "-i", "clip.mp4", "-t", f"{seconds:.2f}",
                  "-vf", f"scale=540:960,ass=label.ass:fontsdir={fonts_rel},format=yuv420p", "-r", "30",
                  "-c:v", "libx264", "-preset", "veryfast", "-crf", "22", "-c:a", "aac", "-ar", "48000", "-ac", "2",
                  "labelled.mp4"], cwd=d)
        clips.append(labelled)
    if not clips:
        raise util.Fail("No style could be rendered for the tour.")
    lst = tour / "list.txt"
    lst.write_text("".join(f"file '{c.as_posix()}'\n" for c in clips), encoding="utf-8")
    util.FINISHED.mkdir(parents=True, exist_ok=True)
    out = util.FINISHED / f"{project.name}-style-tour.mp4"
    util.run([util.ffmpeg_bin(), "-y", "-hide_banner", "-f", "concat", "-safe", "0", "-i", str(lst), "-c", "copy", str(out)],
             label="Style tour ready")
    return out
