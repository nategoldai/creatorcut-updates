"""The creator, cut out: a transparent video of just the person, frame-aligned with the background.

Stacked above text marked "behind", it makes the text pass behind the person's head and body (as many reference
editors do). Masks come from Apple's person segmentation on Mac (MediaPipe elsewhere), one per frame, softened a
little at the edge, then merged as the alpha channel of a VP9 WebM the composer layers in."""
from __future__ import annotations

import shutil
import tempfile
from pathlib import Path

from . import refmap, util


def make_cutout(video: Path, out: Path, progress=None) -> Path:
    say = progress or (lambda *_: None)
    info = util.probe(video)
    W, H = info["width"], info["height"]
    tmp = Path(tempfile.mkdtemp(prefix="cc-cutout-"))
    try:
        frames, masks = tmp / "f", tmp / "m"
        frames.mkdir(); masks.mkdir()
        say("Finding you in every frame…", 0.02)
        util.run([util.ffmpeg_bin(), "-v", "error", "-i", str(video), "-vf", "scale=540:-2", "-fps_mode", "passthrough", "-q:v", "3", str(frames / "%05d.jpg")])
        files = sorted(frames.glob("*.jpg"))
        from PIL import Image, ImageFilter
        last = None
        failures = 0
        consecutive = 0
        coverage = []
        for k, f in enumerate(files):
            if k % 30 == 0:
                say(f"Cutting you out… {round(k / len(files) * 100)}%", 0.05 + 0.75 * k / len(files))
            m = refmap.person_mask(str(f), quality=2)
            if m is None:
                failures += 1; consecutive += 1
                if last is None or consecutive > 2 or failures > max(2,len(files)*.03):
                    raise util.Fail('Person masking could not reliably process this footage.', 'Repair vision dependencies or choose a layout without a cutout; never substitute an invisible person.')
                im = last.copy()
            else:
                consecutive = 0
                im = Image.fromarray(m)
            coverage.append(sum(im.resize((32,32)).getdata())/(255*1024))
            im = im.filter(ImageFilter.GaussianBlur(.6))
            im.save(masks / f"{k + 1:05d}.png")
            last = im
        util.write_json(out.with_suffix('.mask-report.json'), {'frames':len(files), 'held_after_failed_inference':failures,
                        'coverage_min':min(coverage) if coverage else 0,'coverage_max':max(coverage) if coverage else 0,
                        'note':'Coverage is diagnostic; inspect hair, hands and body edges in motion.'})
        say("Building the cut-out layer…", 0.85)
        out.parent.mkdir(parents=True,exist_ok=True)
        fps = info.get("fps") or 30
        util.run([util.ffmpeg_bin(), "-v", "error", "-y", "-i", str(video), "-framerate", f"{fps:g}", "-i", str(masks / "%05d.png"),
                  "-filter_complex", f"[1:v]scale={W}:{H}:flags=bicubic,format=gray[m];[0:v]format=yuv420p[v];[v][m]alphamerge,format=yuva420p[o]",
                  "-map", "[o]", "-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p", "-b:v", "0", "-crf", "28", "-row-mt", "1", "-deadline", "realtime",
                  "-cpu-used", "8", "-g", "30", "-an", str(out)])
        return out
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
