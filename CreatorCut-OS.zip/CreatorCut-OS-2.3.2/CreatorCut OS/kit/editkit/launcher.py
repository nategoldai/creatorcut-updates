"""The CreatorCut Studio app icon: one click opens the Studio, without looking for it in the chat.

Mac: ~/Applications/CreatorCut Studio.app (Spotlight, Launchpad, drag it to the Dock). Windows: a desktop shortcut.
It starts this folder's Studio and opens it in the browser. If the CreatorCut OS folder is gone or moved, it says so
in plain words instead of failing silently."""
from __future__ import annotations

import os
import plistlib
import shutil
import subprocess
import tempfile
from pathlib import Path

from . import util

NAME = "CreatorCut Studio"


def _icon_png(size: int = 1024) -> Path:
    """The CreatorCut mark (black rounded square, two white bars, red dot) as a PNG."""
    from PIL import Image, ImageDraw
    s = size / 64
    im = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    pad = int(size * 0.09)                      # macOS icons sit inside a margin
    k = (size - 2 * pad) / size
    t = lambda v: pad + v * s * k
    d.rounded_rectangle([t(0), t(0), t(64), t(64)], radius=16 * s * k, fill=(10, 10, 11, 255))
    d.rounded_rectangle([t(17), t(13), t(29), t(39)], radius=3.5 * s * k, fill=(255, 255, 255, 255))
    d.rounded_rectangle([t(35), t(25), t(47), t(51)], radius=3.5 * s * k, fill=(255, 255, 255, 255))
    r = 6 * s * k
    d.ellipse([t(53) - r, t(11) - r, t(53) + r, t(11) + r], fill=(255, 59, 48, 255))
    out = Path(tempfile.mkdtemp()) / "icon.png"
    im.save(out)
    return out


def _mac(root: Path) -> Path:
    app = Path.home() / "Applications" / f"{NAME}.app"
    if app.exists():
        shutil.rmtree(app)
    (app / "Contents" / "MacOS").mkdir(parents=True)
    (app / "Contents" / "Resources").mkdir(parents=True)
    with (app / "Contents" / "Info.plist").open("wb") as f:
        plistlib.dump({"CFBundleName": NAME, "CFBundleDisplayName": NAME, "CFBundleIdentifier": "os.creatorcut.studio",
                       "CFBundleExecutable": "studio", "CFBundleIconFile": "icon", "CFBundlePackageType": "APPL",
                       "CFBundleShortVersionString": (util.KIT / "VERSION").read_text().strip() if (util.KIT / "VERSION").exists() else "1",
                       "LSUIElement": True}, f)
    q = lambda p: "'" + str(p).replace("'", "'\\''") + "'"
    script = f"""#!/bin/bash
# Opens the CreatorCut Studio of {root}
ROOT={q(root)}
if [ ! -x "$ROOT/.venv/bin/python" ]; then
  /usr/bin/osascript -e 'display dialog "Your CreatorCut OS folder is not where it was ({root.parent.name}). Put it back (it should stay in Documents), or open the new folder in Claude Code or Codex and type: install. It repairs itself." buttons {{"OK"}} default button 1 with title "CreatorCut Studio"' >/dev/null
  exit 0
fi
cd "$ROOT" && exec "$ROOT/.venv/bin/python" edit.py studio open >/dev/null 2>&1
"""
    exe = app / "Contents" / "MacOS" / "studio"
    exe.write_text(script)
    exe.chmod(0o755)
    try:                                         # the icon: PNG -> .iconset -> .icns with the Mac's own tools
        png = _icon_png()
        iconset = png.parent / "icon.iconset"
        iconset.mkdir()
        for px in (16, 32, 64, 128, 256, 512):
            for scale, suffix in ((1, ""), (2, "@2x")):
                subprocess.run(["sips", "-z", str(px * scale), str(px * scale), str(png), "--out",
                                str(iconset / f"icon_{px}x{px}{suffix}.png")], capture_output=True, check=False)
        subprocess.run(["iconutil", "-c", "icns", str(iconset), "-o", str(app / "Contents" / "Resources" / "icon.icns")],
                       capture_output=True, check=False)
        shutil.rmtree(png.parent, ignore_errors=True)
    except Exception as e:
        util.log(f"studio app icon: {e}")
    subprocess.run(["touch", str(app)], check=False)    # Finder picks up the new icon
    return app


def _windows(root: Path) -> Path:
    desk = Path(os.environ.get("USERPROFILE", str(Path.home()))) / "Desktop"
    lnk = desk / f"{NAME}.lnk"
    py = root / ".venv" / "Scripts" / "pythonw.exe"
    if not py.exists():
        py = root / ".venv" / "Scripts" / "python.exe"
    ps = (f"$s=(New-Object -ComObject WScript.Shell).CreateShortcut('{lnk}');$s.TargetPath='{py}';"
          f"$s.Arguments='edit.py studio open';$s.WorkingDirectory='{root}';$s.Description='Open your CreatorCut Studio';$s.Save()")
    subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, check=False)
    return lnk


def install() -> Path:
    root = util.ROOT
    return _windows(root) if util.os_name() == "windows" else _mac(root)
