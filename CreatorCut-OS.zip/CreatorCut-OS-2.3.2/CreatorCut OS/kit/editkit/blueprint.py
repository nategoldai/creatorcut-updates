"""The blueprint: how a reference is edited beyond its text, as rules the planner applies to any creator's video.

A preset carries `blueprint` (made automatically by the study, then refined by the agent from dense reference frames):
  pacing    {"max_pause": s}                              how much silence stays inside sentences (measured)
  opening   {"mode": "words" | "block"}                   one word at a time, or the first line set as a block of text
  block     {"sentence": n, "behind": bool} | null        a sentence early on set as a stacked text block (top part behind the head)
  cards     {"per_minute", "w", "h", "y", "rot", "behind", "stack", "duration": [min, max],
             "enter": {...}, "float": {...}} | null      B-roll on cards: size, place, tilt, how many at once, motion
  burst     {"count", "spread", "size", "duration"} | null   a cloud of many small frames on "a week of them" moments
  fullscreen {"duration"} | null                          full-picture cutaways
  pieces    true | false                                  animated pieces (folder, counter, checklist…) fit this look
  notes     {"font": "Caveat"} | null                     handwritten asides (the agent writes their words)
  strip     {"y", "h", "behind"} | null                   a row of clip cards sliding sideways ("batch your B-roll", "all my clips")
  grid      {"cols", "duration"} | null                   a wall of clips filling the background behind the person ("every reel")
  kinetic   {"x", "y"} | null                             a dark card where the key words build up ("custom animations")
  accent_share  0.0-0.5                                   share of caption words set in the accent style (the reference's habit)
apply() places captions' companions (block, cards, bursts, pieces) from these rules, using the creator's B-roll (and its
labels: what each clip shows) and what they say. The agent then adds the creative layer and judges the result."""
from __future__ import annotations

import re
from pathlib import Path

from . import util

STOP = set("the a an and or but so to of in on at for with is are was were be been it its it's this that these those you your "
           "i me my we our they them he she his her not no do does did can will just also then than there here what when how "
           "who why all any some more most very really get got going gonna make made".split())
STRIP_WORDS = {"batch", "broll", "b-roll", "clips", "videos", "reels", "content", "footage", "posts"}
GRID_PHRASES = re.compile(r"\b(every (single )?(video|reel|post|clip)|all (of )?(my|your|the) (videos|reels|posts|content)|hundreds|thousands)\b", re.I)
KINETIC_WORDS = {"custom", "animation", "animations", "automatically", "magic", "instantly"}
QUANTITY = re.compile(r"^(all|every|everything|week|weeks|month|hundreds?|thousands?|dozens?|lots|tons?|many|batch|them|clips)$")
NUMBER = re.compile(r"^\$?\d[\d,]*(\.\d+)?[kKmMx%]?$")
PIECE_WORDS = {"folder": "folder", "files": "folder", "folders": "folder", "clips": "folder", "upload": "folder",
               "app": "apps", "apps": "apps", "tools": "apps"}


def _n(w: str) -> str:
    return re.sub(r"[^a-z0-9']", "", w.lower())


def measure_pacing(ref_words: list[dict]) -> dict:
    """Pauses the reference keeps inside sentences (its editor's rhythm)."""
    gaps = []
    for a, b in zip(ref_words, ref_words[1:]):
        if a["w"].rstrip().endswith((".", "!", "?")):
            continue
        g = b["start"] - a["end"]
        if 0 <= g < 1.5:
            gaps.append(g)
    if len(gaps) < 5:
        return {}
    gaps.sort()
    p75 = gaps[int(len(gaps) * 0.75)]
    return {"max_pause": round(min(0.35, max(0.1, p75 + 0.04)), 3), "pause_p50": round(gaps[len(gaps) // 2], 3)}


def real_cuts(cuts: list[float], track: dict | None, frames: list | None = None, face=None, fps: float = 10.0) -> list[float]:
    """Cuts that no card or burst explains (a graphic appearing or leaving changes the frame as much as a cut)."""
    ev = []
    for c in (track or {}).get("cards", []):
        if c.get("kind") == "fullscreen":
            continue
        t0 = float(c.get("t_in", 0))
        ev += [t0, float(c.get("t_out") or t0 + float(c.get("duration") or 0))]
    for b in (track or {}).get("bursts", []):
        ev += [float(b.get("t_in", 0)), float(b.get("t_in", 0)) + float(b.get("duration") or 0)]
    left = [c for c in cuts if not any(abs(c - e) <= 0.3 for e in ev)]
    return [c for c in left if _head_jumps(c, frames, face, fps)] if frames and face else left


def _head_jumps(t: float, frames: list, face, fps: float) -> bool:
    """Does the head region change at t much more than it does around it (talking, gestures)?"""
    import numpy as np
    from PIL import Image
    x, y, w, h = face
    x0, y0, x1, y1 = max(0, x - w * 0.3), max(0, y - h * 0.3), min(1, x + w * 1.3), min(1, y + h * 1.3)

    def crop(k):
        im = Image.open(frames[k]).convert("L")
        W, H = im.size
        return np.asarray(im.crop((int(x0 * W), int(y0 * H), int(x1 * W), int(y1 * H))).resize((48, 48)), dtype=np.float32)
    i = int(round(t * fps))
    if i <= 0 or i >= len(frames):
        return True
    try:
        d = lambda k: float(np.abs(crop(k) - crop(k - 1)).mean())
        here = d(i)
        around = [d(k) for k in range(max(1, i - 5), min(len(frames), i + 6)) if abs(k - i) > 1]
    except Exception:
        return True
    base = sorted(around)[len(around) // 2] if around else 0.0
    return here > max(9.0, base * 3.0)


def measure_zoom(frames: list, cuts: list[float], fps: float = 10.0) -> dict:
    """Punch-ins: the face height right after each real cut vs right before. {"share": cuts that zoom, "scale": typical}."""
    import cv2
    det = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

    def face_h(k):
        if not 0 <= k < len(frames):
            return None
        g = cv2.imread(str(frames[k]), cv2.IMREAD_GRAYSCALE)
        if g is None:
            return None
        fs = det.detectMultiScale(g, 1.1, 5, minSize=(g.shape[1] // 14, g.shape[1] // 14))
        return max(f[3] for f in fs) / g.shape[0] if len(fs) else None
    ratios = []
    for c in cuts:
        i = int(round(c * fps))
        a, b = face_h(i - 2), face_h(i + 2)
        if a and b:
            ratios.append(b / a)
    if len(ratios) < 3:
        return {}
    zooms = [r for r in ratios if r > 1.08 or r < 1 / 1.08]
    big = sorted(max(r, 1 / r) for r in zooms)
    return {"share": round(len(zooms) / len(ratios), 2), "scale": round(big[len(big) // 2], 2) if big else 1.0, "cuts": len(ratios)}


def caption_screens(rm: dict) -> dict:
    """How captions really read: words on screen together (a 'screen'), and whether a screen builds word by word.
    OCR samples catch screens half built, so blocks of 1-2 words are measured where the reference shows 5."""
    from collections import Counter
    caps = [e for e in rm.get("elements", []) if e.get("kind") == "caption" and e.get("spoken", True)]
    if not caps:
        return {}
    main = Counter(e.get("style") for e in caps).most_common(1)[0][0]
    caps = sorted((e for e in caps if e.get("style") == main), key=lambda e: e["t_in"])
    screens: list[list[dict]] = []
    for e in caps:
        g = screens[-1] if screens else None
        if g and e["t_in"] < max(x["t_out"] for x in g) - 0.05 and abs(e["cy"] - g[0]["cy"]) < 0.12:
            g.append(e)
        else:
            screens.append([e])
    sizes = sorted(len(g) for g in screens)
    multi = [g for g in screens if len(g) > 1]
    build = sum(1 for g in multi if max(x["t_in"] for x in g) - min(x["t_in"] for x in g) > 0.25)
    lines = sorted(len({round(x["cy"] / 0.03) for x in g}) for g in screens)
    return {"block_words": sizes[len(sizes) // 2], "block_words_p75": sizes[3 * len(sizes) // 4],
            "block_words_p90": sizes[min(len(sizes) - 1, int(len(sizes) * 0.9))],
            "build": bool(multi) and build / len(multi) >= 0.5, "lines_typical": lines[len(lines) // 2]}


def auto(kit: dict, track: dict | None, refmap: dict | None, ref_words: list[dict] | None) -> dict:
    """A first blueprint from the measurements (the agent refines it from the dense frames)."""
    bp: dict = {"auto": True}
    # pacing follows how often the reference really cuts. A calm reference (a speaker talking, no cuts) keeps natural
    # pauses: only long silences and bad takes go. Word timings can't measure pauses (speech models stretch words over them).
    cpm = float(kit.get("cuts_per_minute") or 0)
    if cpm < 5:
        bp["pacing"] = {"style": "continuous", "max_pause": 0.45, "min_cut": 0.7}
    elif cpm < 12:
        bp["pacing"] = {"style": "tight", "max_pause": 0.3, "min_cut": 0.25}
    else:
        bp["pacing"] = {"style": "jump", "max_pause": 0.2, "min_cut": 0.0}
    zm = kit.get("zoom_measured") or {}
    if zm:                                          # measured: the reference punches in on cuts (and by how much), or not
        bp["zoom"] = zm.get("share", 0) >= 0.3
        bp["zoom_scale"] = round(min(1.35, max(1.06, zm.get("scale", 1.12))), 2)
    else:
        bp["zoom"] = cpm >= 12                      # no face to measure: jump-cut references usually punch in
    cs = kit.get("captions", {})
    if cs.get("block_words"):
        # a block that builds word by word is seen half-built most of the time: its real length is near the longest seen
        full = cs.get("block_words_p90") if cs.get("build") else cs["block_words"]
        bp["captions"] = {"words": int(max(1, min(8, full or cs["block_words"]))), "build": bool(cs.get("build")),
                          "lines": int(max(1, min(3, cs.get("lines_typical") or kit.get("captions", {}).get("lines_max") or 1)))}
    # opening: the first text on screen is a single word, or a block of several words / lines
    blocks = (refmap or {}).get("blocks", [])
    first = next((b for b in blocks if b.get("words")), None)
    bp["opening"] = {"mode": "block" if first and first["t"] < 1.5 and (len(first["words"]) >= 4 or first.get("lines", 1) >= 2) else "words"}
    big = next((b for b in blocks if b["t"] < 10 and len(b.get("words", [])) >= 5 and b.get("lines", 1) >= 2), None)
    if big:
        sents = _sentences(ref_words or [])
        idx = next((k for k, s in enumerate(sents) if s[0]["start"] - 0.6 <= big["t"] <= s[-1]["end"] + 0.3), 1)
        bp["block"] = {"sentence": max(0, idx), "behind": bool(kit.get("behind_person"))} if kit.get("behind_person") or cpm >= 12 else None
    st = (track or {}).get("stats", {})
    cards = [c for c in (track or {}).get("cards", []) if c["kind"] != "fullscreen"]
    if cards:
        # where, how big, how tilted and how still the reference's cards are: measured, not a house look
        rot = float(st.get("rot") or 0)
        dr = st.get("drift") or {}
        moving = abs(dr.get("dx", 0)) > 0.004 or abs(dr.get("dy", 0)) > 0.004 or abs(rot) > 1.5
        bp["cards"] = {"per_minute": max(4.0, min(40.0, st.get("cards_per_minute", 12))),
                       "w": round(min(0.6, max(0.2, st.get("size", {}).get("w", 0.36))), 3),
                       "h": round(min(0.5, max(0.12, st.get("size", {}).get("h", 0.3))), 3),
                       "y": round(min(0.85, max(0.1, st.get("y", 0.3))), 3),
                       "rot": round(min(10.0, max(0.0, abs(rot))), 1),
                       "behind": st.get("behind_share", 0) >= 0.5 and bool(kit.get("behind_person")),
                       "stack": min(2, max(1, st.get("max_at_once", 1))),
                       "duration": [1.2, 2.6] if cpm >= 5 else [1.6, 3.4],
                       "enter": {"ease": "back", "scale_from": 0.78, "rot_from": 1.8, "ms": 340} if moving
                       else {"enter": "slide-up" if st.get("y", 0.3) > 0.55 else "cut", "exit": "cut", "ms": 420},
                       "flat": not moving,
                       "x": 0.5 if (st.get("sides") or {}).get("middle", 0) >= max(1, sum((st.get("sides") or {}).values())) * 0.4 else None,
                       "float": {"rot": 4, "dx": 0.015, "dy": -0.012, "scale": 1.04} if moving else None}
    pl = (track or {}).get("placed") or {}
    imgs = [c for c in pl.get("cards", []) if c.get("kind") != "text" and c["w"] * c["h"] >= 0.03]
    ref_dur = float((refmap or {}).get("duration") or 0)
    if len(imgs) >= 2 and ref_dur > 0:
        # measured card by card: where each image sits, how big, how it comes and goes (placement copies the slots)
        lay = pl.get("layout") or {}
        lens = sorted(c["t_out"] - c["t_in"] for c in imgs)
        at_once = max(sum(1 for o in imgs if o["t_in"] < c["t_out"] and o["t_out"] > c["t_in"]) for c in imgs)
        bp["cards"] = {**(bp.get("cards") or {}), "per_minute": round(max(4.0, min(40.0, len(imgs) / ref_dur * 60)), 1),
                       "x": lay.get("x", 0.5), "y": lay.get("y", 0.7), "w": lay.get("w", 0.5), "h": lay.get("h", 0.3), "rot": 0.0,
                       "flat": True, "float": None, "behind": False, "stack": min(3, at_once), "measured": True,
                       "duration": [round(max(1.0, lens[len(lens) // 4]), 2), round(max(1.6, lens[-1]), 2)],
                       "enter": {"enter": lay.get("enter", "cut"), "exit": lay.get("exit", "cut"), "ms": 320},
                       "slots": [{"at": round(c["t_in"] / ref_dur, 3), "len": round(c["t_out"] - c["t_in"], 2),
                                  **{k: c[k] for k in ("x", "y", "w", "h", "top", "enter", "exit")}, "ms": c.get("enter_ms") or 320}
                                 for c in imgs]}
    if any(b.get("count", 0) >= 10 for b in (track or {}).get("bursts", [])):
        b = track["bursts"][0]
        bp["burst"] = {"count": 24, "spread": round(min(0.48, max(0.3, b.get("spread", 0.4))), 2), "size": 0.068, "duration": [0.9, 1.6]}
    if any(c["kind"] == "fullscreen" for c in (track or {}).get("cards", [])):
        bp["fullscreen"] = {"duration": 0.9}
    ui = sum(1 for c in cards if c["kind"] == "ui") / max(1, len(cards))
    # animated pieces and kinetic text cards only for references made of that kind of graphic (calm, image-led edits get none)
    bp["pieces"] = ui >= 0.2 or cpm >= 12 or "burst" in bp
    if ui >= 0.3:
        bp["kinetic"] = {"x": 0.78, "y": 0.28, "scale": 0.9}     # screens / UI on cards: key words build up on a dark card
    return bp


def _sentences(words: list[dict]) -> list[list[dict]]:
    out, cur = [], []
    for w in words:
        cur.append(w)
        if w["w"].rstrip().endswith((".", "!", "?")):
            out.append(cur); cur = []
    if cur:
        out.append(cur)
    return out


def _burst_frames(project: Path, media: list[dict], per_clip: int = 7) -> list[str]:
    """Several frames of every B-roll clip (a burst of the same 4 pictures looks cheap)."""
    out_dir = project / "media" / ".burst"
    out_dir.mkdir(parents=True, exist_ok=True)
    srcs = []
    for m in media:
        if m.get("kind") not in ("broll", "image"):
            continue
        f = util.ROOT / m["file"]
        stem = re.sub(r"[^A-Za-z0-9_-]", "", f.stem)[:40]
        if m["kind"] == "image":
            srcs.append(m["file"]); continue
        have = sorted(out_dir.glob(f"{stem}-*.jpg"))
        if not have:
            dur = float(m.get("duration") or 10)
            step = max(1.0, dur / (per_clip + 1))
            util.run([util.ffmpeg_bin(), "-v", "error", "-y", "-i", str(f), "-vf", f"fps=1/{step:.2f},scale=220:-2", "-frames:v", str(per_clip),
                      str(out_dir / f"{stem}-%02d.jpg")], check=False)
            have = sorted(out_dir.glob(f"{stem}-*.jpg"))
        srcs += [str(p.relative_to(project)) for p in have]
    return srcs


def _aspect(m: dict) -> float | None:
    """Width / height of a B-roll clip or image as it's shown (rotation included)."""
    try:
        if m.get("w") and m.get("h"):
            return float(m["w"]) / float(m["h"])
        f = Path(m["file"])
        if f.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp", ".gif", ".heic"):
            from PIL import Image
            with Image.open(f) as im:
                return im.width / im.height
        info = util.probe(f)
        w, h = info.get("width"), info.get("height")         # display size, rotation applied
        return float(w) / float(h) if w and h else None
    except Exception:
        return None


def apply(project: Path, plan: dict, bp: dict, learned: dict | None = None) -> dict:
    """Add the reference's companions to the drafted captions. Returns notes for the agent."""
    learned = learned or {}
    words = util.read_json(project / "words.json")["words"]
    cfg = util.read_json(project / "project.json")
    media = cfg.get("media", [])
    face = plan.get("_facts", {}).get("face")
    dur = float(plan["duration"])
    sents = _sentences(words)
    notes = []
    caps = [i for i in plan["items"] if i["type"] == "caption"]
    busy: list[tuple[float, float]] = []            # times already holding a big graphic
    clips = [m for m in media if m.get("kind") in ("broll", "image")]

    def free(a, b):
        return all(b <= x or a >= y for x, y in busy)

    def sent_end(t):
        return next((s[-1]["end"] for s in sents if s[0]["start"] - 0.05 <= t <= s[-1]["end"] + 0.05), t + 2.0)

    # 1. a sentence as a stacked block (top lines behind the head, the rest below the chin), like the reference
    blk = bp.get("block")
    clauses = []
    for s_ in sents:
        cur = []
        for w in s_:
            cur.append(w)
            if w["w"].rstrip().endswith(",") and len(cur) >= 4:
                clauses.append(cur); cur = []
        if cur:
            clauses.append(cur)
    if blk and learned.get("block", True) is not False and len(clauses) > 1:
        k = min(len(clauses) - 1, max(0, int(blk.get("sentence", 1))))
        sents_b = clauses
        s = clauses[k]
        if 5 <= len(s) <= 16 and "big" in plan["styles"]:
            from . import stylekit
            if "hook" not in plan["styles"]:            # the block's text styles (the draft only makes them for a stacked opening)
                big = plan["styles"]["big"]
                plan["styles"]["hook"] = dict(big, size=round(min(0.09, max(0.06, big["size"] * 0.66)), 4), line=0.98, shadow=max(big.get("shadow", 0.3), 0.35))
                plan["fonts"]["hook"] = plan["fonts"]["big"]
                if "accent" in plan["styles"]:
                    plan["styles"]["hook_accent"] = dict(plan["styles"]["accent"], size=round(min(0.105, max(0.07, plan["styles"]["accent"]["size"] * 0.7)), 4),
                                                         line=0.98, shadow=plan["styles"]["hook"]["shadow"])
                    plan["fonts"]["hook_accent"] = plan["fonts"]["accent"]
            acc = stylekit.keyword([w["w"] for w in s])
            acc_set = {acc, acc + 1} if acc is not None else set()
            t0, t1 = s[0]["start"], (sents_b[k + 1][0]["start"] - 0.03) if k + 1 < len(sents_b) else s[-1]["end"] + 0.4
            head_top = (face[1] - face[3] * 0.2) if face else 0.25
            per_line = 3
            top_n = max(2, min(len(s) - 2, (int(max(1, (head_top - 0.05) / 0.075)) * per_line)))
            top_n = min(top_n, len(s) // 2 + 1)
            top, bot = s[:top_n], s[top_n:]
            def mk(ws, y, behind, first_index):
                lines, cur = [], []
                for j in range(len(ws)):
                    cur.append(j)
                    if len(cur) == per_line or j == len(ws) - 1:
                        lines.append(cur); cur = []
                return {"type": "caption", "role": "block", "t0": round(ws[0]["start"], 3), "t1": round(t1, 3), "x": 0.5, "y": round(y, 3),
                        "lines": lines, "reveal": "word",
                        "words": [{"w": w["w"].lower() if plan["styles"].get("hook", {}).get("case") == "lower" else w["w"], "t": w["start"],
                                   "style": "hook_accent" if (first_index + j) in acc_set and "hook_accent" in plan["styles"] else "hook"} for j, w in enumerate(ws)],
                        "anim": {"ease": "pop", "scale_from": 0.92, "dy_from": 0.006, "ms": 120, "opacity_from": 0}, **({"behind": True} if behind else {})}
            n_top_lines = (len(top) + per_line - 1) // per_line
            ytop = max(0.06 + n_top_lines * 0.04, head_top - n_top_lines * 0.035)
            items = [mk(top, ytop, blk.get("behind", True) and face is not None, 0)]
            if bot:
                items.append(mk(bot, plan["_facts"].get("caption_y", 0.62) + 0.02, False, top_n))
            plan["items"] = [i for i in plan["items"] if not (i["type"] == "caption" and i.get("role") != "block" and i["t0"] < t1 - 0.01 and i["t1"] > t0 + 0.01)]
            plan["items"] += items
            busy.append((t0, t1))
            notes.append(f"Block of text on clause {k + 1} ({t0:.1f}-{t1:.1f}s), top part behind the head.")

    # 3. a burst of many frames on a "lots of them" moment
    bu = bp.get("burst")
    if bu and clips and learned.get("burst", True) is not False:
        cands = [w for w in words if QUANTITY.match(_n(w["w"])) and w["start"] > 2.0 and free(w["start"] - 0.1, w["start"] + bu["duration"][0])]
        strong = [w for w in cands if _n(w["w"]) in ("week", "weeks", "month", "hundreds", "thousands", "dozens", "batch", "them")]
        hit = (strong or cands or [None])[0]
        if hit:
            srcs = _burst_frames(project, media)
            if len(srcs) >= 6:
                t0 = round(hit["start"] - 0.1, 3)
                t1 = round(min(dur, t0 + bu["duration"][1], sent_end(hit["start"]) + 0.15), 3)
                t1 = max(t1, t0 + bu["duration"][0])
                plan["items"].append({"type": "burst", "srcs": srcs, "t0": t0, "t1": t1, "x": 0.5, "y": 0.6, "count": bu["count"],
                                      "spread": bu["spread"], "size": bu["size"]})
                busy.append((t0, t1))
                notes.append(f"Burst of {bu['count']} frames on \"{hit['w']}\" at {t0:.1f}s.")

    # 5. the reference's signature moves on matching words: a sliding row of clips, a wall of clips, kinetic text
    frames_all = None
    def frames_():
        nonlocal frames_all
        if frames_all is None:
            frames_all = _burst_frames(project, media)
        return frames_all
    if bp.get("strip") and clips and learned.get("pieces", True) is not False:
        hit = next((w for w in words if _n(w["w"]).replace("-", "") in {x.replace("-", "") for x in STRIP_WORDS} and free(w["start"] - 0.2, w["start"] + 1.4)), None)
        if hit and len(frames_()) >= 4:
            st_ = bp["strip"]
            t0 = round(hit["start"] - 0.2, 3)
            t1 = round(min(dur, max(t0 + 1.4, sent_end(hit["start"]) + 0.2)), 3)
            plan["items"].append({"type": "piece", "name": "strip", "t0": t0, "t1": t1, "y": st_.get("y", 0.28), "h": st_.get("h", 0.17),
                                  "srcs": frames_()[::max(1, len(frames_()) // 6)][:6], "behind": st_.get("behind", True) and face is not None})
            busy.append((t0, t1)); plan["_needs_cutout"] = plan.get("_needs_cutout") or bool(st_.get("behind", True))
            notes.append(f"Sliding row of clips on \"{hit['w']}\" at {t0:.1f}s.")
    if bp.get("grid") and clips and learned.get("pieces", True) is not False:
        text = " ".join(w["w"] for w in words)
        m = GRID_PHRASES.search(text)
        if m:
            pos = len(text[:m.start()].split())
            w0 = words[min(pos, len(words) - 1)]
            t0 = round(w0["start"] - 0.05, 3)
            t1 = round(min(dur, t0 + bp["grid"].get("duration", 2.2), sent_end(w0["start"]) + 0.3), 3)
            if free(t0, t1) and len(frames_()) >= 6:
                plan["items"].append({"type": "piece", "name": "grid", "t0": t0, "t1": max(t1, t0 + 1.2), "cols": bp["grid"].get("cols", 3), "srcs": frames_()})
                busy.append((t0, t1)); plan["_needs_cutout"] = True
                notes.append(f"Wall of clips behind you on \"{m.group(0)}\" at {t0:.1f}s.")
    if bp.get("kinetic") and learned.get("pieces", True) is not False:
        hit = next((w for w in words if _n(w["w"]) in KINETIC_WORDS and free(w["start"] - 0.6, w["start"] + 1.2)), None)
        if hit:
            s_ = next((s for s in sents if hit in s), [hit])
            k0 = max(s_.index(hit) - 3, 0)
            phrase = " ".join(w["w"].strip(".,!?").lower() for w in s_[k0:s_.index(hit) + 2])
            t0 = round(s_[k0]["start"] - 0.05, 3)
            t1 = round(min(dur, max(t0 + 1.8, sent_end(hit["start"]) + 0.3)), 3)
            kn = bp["kinetic"]
            plan["items"].append({"type": "piece", "name": "phone", "text": phrase, "t0": t0, "t1": t1, "x": kn.get("x", 0.8), "y": kn.get("y", 0.28),
                                  "scale": kn.get("scale", 0.9), "rot": 4})
            busy.append((t0, t1))
            notes.append(f"Kinetic text card \"{phrase}\" at {t0:.1f}s.")

    # 4. animated pieces where the words ask for one (a folder for files/clips, app icons for apps…)
    if bp.get("pieces") and learned.get("pieces", True) is not False:
        n_p = 0
        for w in words:
            name = PIECE_WORDS.get(_n(w["w"]))
            if not name or n_p >= max(1, int(dur / 15)):
                continue
            t0 = round(w["start"] - 0.05, 3)
            t1 = round(min(dur, max(t0 + 1.4, sent_end(w["start"]) + 0.1)), 3)
            if not free(t0, t1):
                continue
            frames = _burst_frames(project, media)
            if name == "folder" and len(frames) >= 3:
                plan["items"].append({"type": "piece", "name": "folder", "t0": t0, "t1": t1, "x": 0.5, "y": 0.17, "srcs": frames[::max(1, len(frames) // 3)][:3]})
            elif name == "apps" and len(frames) >= 3:
                continue                                 # app icons need real icons: the agent adds this piece when it has them
            else:
                continue
            busy.append((t0, t1))
            n_p += 1
            notes.append(f"Animated piece '{name}' on \"{w['w']}\" at {t0:.1f}s.")

    # 4b. graphics that need no B-roll, so a talking-head video still moves like the reference:
    #     a counter when a number is said, and (no B-roll at all) the key phrase on a text card in the reference's card slot
    if (bp.get("pieces") or bp.get("kinetic")) and learned.get("pieces", True) is not False:
        top = round(max(0.11, (face[1] if face else 0.25) - 0.07), 3)
        n_c = 0
        for k, w in enumerate(words):
            raw = w["w"].strip(",.!?:;\"'")
            if n_c >= max(1, int(dur / 20)) or not NUMBER.match(raw):
                continue
            val = float(re.sub(r"[^\d.]", "", raw) or 0)
            if val < 2 or (1900 <= val <= 2100 and not raw.startswith("$")):
                continue                                 # "1" and years don't count up
            t0 = round(w["start"] - 0.1, 3)
            t1 = round(min(dur, max(t0 + 1.6, sent_end(w["start"]) + 0.1)), 3)
            if not free(t0, t1):
                continue
            after = []
            for x in words[k + 1:k + 3]:
                after.append(x["w"].strip(",.!?").lower())
                if x["w"].rstrip().endswith((",", ".", "!", "?")):
                    break
            plan["items"].append({"type": "piece", "name": "counter", "value": raw, "label": " ".join(after), "t0": t0, "t1": t1,
                                  "x": 0.5, "y": top, "scale": 0.8})
            busy.append((t0, t1))
            n_c += 1
            notes.append(f"Counter {raw} on \"{w['w']}\" at {t0:.1f}s.")
    if not clips and bp.get("cards") and bp.get("pieces") and learned.get("pieces", True) is not False:
        kn = bp.get("kinetic") or {"x": 0.78, "y": 0.28, "scale": 0.9}
        placed = [i["t0"] for i in plan["items"] if i.get("name") == "phone"]
        side = -1 if placed else 1
        for s_ in sents:
            if len(placed) >= max(1, int(dur / 12)):
                break
            if s_[0]["start"] < 2.5 or len(s_) < 4 or any(abs(s_[0]["start"] - t) < 5 for t in placed):
                continue
            keys = [w for w in s_ if len(_n(w["w"])) >= 6 and _n(w["w"]) not in STOP]
            if not keys:
                continue
            hit = max(keys, key=lambda w: len(_n(w["w"])))
            k0 = max(s_.index(hit) - 3, 0)
            phrase = " ".join(w["w"].strip(".,!?").lower() for w in s_[k0:s_.index(hit) + 2])
            t0 = round(s_[k0]["start"] - 0.05, 3)
            t1 = round(min(dur, max(t0 + 1.8, sent_end(hit["start"]) + 0.3)), 3)
            if not free(t0, t1):
                continue
            x = kn.get("x", 0.78) if side > 0 else round(1 - kn.get("x", 0.78), 3)
            plan["items"].append({"type": "piece", "name": "phone", "text": phrase, "t0": t0, "t1": t1, "x": x, "y": kn.get("y", 0.28),
                                  "scale": kn.get("scale", 0.9), "rot": 4 * side})
            busy.append((t0, t1))
            placed.append(t0)
            side = -side
            notes.append(f"Text card \"{phrase}\" at {t0:.1f}s (no B-roll here: the key words take the card's place).")

    # 6b. B-roll on cards (after the signature moves, in the time left): where the creator talks about what the clip shows, the reference's size, place, tilt and motion
    cd = bp.get("cards")
    mult = float(learned.get("cards_density", 1.0))
    if cd and clips and mult > 0:
        start_after = 0.4                              # references put B-roll right from the start
        want = max(len(clips), int(round(cd["per_minute"] * dur / 60 * mult)))
        want = min(want, max(1, int(dur / 2.4)))
        label_words = {m["id"]: {_n(x) for x in re.split(r"\W+", (m.get("label") or "")) if len(_n(x)) > 3} for m in clips}
        slots = []
        # labelled clips go where their words are said
        for m in clips:
            lw = label_words[m["id"]]
            if not lw:
                continue
            hit = next((w for w in words if _n(w["w"]) in lw and w["start"] >= start_after), None)
            if hit:
                slots.append((hit["start"], m))
        # the rest: strong words spread evenly over the video
        cand = [w for s in sents for w in s if len(_n(w["w"])) >= 4 and _n(w["w"]) not in STOP and w["start"] >= start_after]
        spacing = max(2.4, dur / max(1, want))
        rest = [m for m in clips if not any(m is x for _, x in slots)]
        k = 0
        last_t = -99.0
        for w in cand:
            if len(slots) >= want:
                break
            if w["start"] - last_t < spacing or any(abs(w["start"] - t) < 2.0 for t, _ in slots):
                continue
            slots.append((w["start"], (rest or clips)[k % len(rest or clips)]))
            k += 1
            last_t = w["start"]
        slots.sort(key=lambda x: x[0])
        side = 1
        placed = 0
        for n_, (t, m) in enumerate(slots):
            t0 = round(max(0.0, t - 0.08), 3)
            t1 = round(min(dur, max(t0 + cd["duration"][0], min(t0 + cd["duration"][1], sent_end(t) + 0.2))), 3)
            nxt = min([x for x, _ in busy if x > t0] + [dur])
            t1 = round(min(t1, nxt - 0.05), 3)       # end as the next big graphic arrives, rather than skipping the card
            if t1 - t0 < 0.9 or not free(t0, t1):
                continue
            x = cd.get("x") or (0.79 if side > 0 else 0.21)
            rot = cd["rot"] if side > 0 else -cd["rot"]
            fl = cd.get("float")
            item = {"type": "card", "src": m["file"], "t0": t0, "t1": t1, "x": x, "y": cd["y"], "w": cd["w"], "h": cd["h"], "rot": rot,
                    "radius": 0.0 if cd.get("flat") else 0.025, "shadow": not cd.get("flat"), "behind": bool(cd.get("behind")) and face is not None,
                    "anim": {**{k2: v for k2, v in cd.get("enter", {}).items() if k2 != "rot_from"}, "dx_from": 0.06 * side, "dy_from": -0.02,
                             "rot_from": rot * cd.get("enter", {}).get("rot_from", 1.8),
                             "float": {"rot": fl["rot"] * side, "dx": -fl["dx"] * side, "dy": fl["dy"], "scale": fl["scale"]} if fl else None}}
            sl = min(cd["slots"], key=lambda s_: abs(s_["at"] - t0 / max(dur, 1.0))) if cd.get("slots") else None
            if sl:
                cvs = plan.get("canvas") or {"w": 1080, "h": 1920}
                bw, bh = sl["w"], sl["h"]
                asp = _aspect(m)
                if asp:                                   # the clip keeps its shape, within the reference's box
                    bh = min(sl["h"] * 1.3, max(sl["h"] * 0.8, bw * cvs["w"] / asp / cvs["h"]))
                    if bh < sl["h"] * 0.999 and bw * cvs["w"] / asp / cvs["h"] < sl["h"] * 0.8:
                        bw = min(sl["w"] * 1.25, 0.94)    # very wide clips: a little wider rather than cropped hard
                top = sl["top"] if sl["top"] + bh <= 0.98 else 0.98 - bh   # its top edge where the reference's is
                item.update(x=sl["x"], y=round(top + bh / 2, 3), w=round(bw, 3), h=round(bh, 3), rot=0, radius=0.0, shadow=False,
                            behind=False, fit="cover", slot=round(sl["at"], 3),
                            anim={"enter": sl["enter"], "exit": sl["exit"], "ms": int(max(200, min(520, sl.get("ms") or 320))), "float": None})
            plan["items"].append(item)
            placed += 1
            # the reference shows two at once: a second clip arrives on the other side
            if cd.get("stack", 1) >= 2 and not cd.get("x") and fl and len(clips) > 1 and t1 - t0 > 1.5 and placed < want:
                m2 = clips[(clips.index(m) + 1) % len(clips)]
                t0b = round(t0 + 0.6, 3)
                plan["items"].append(dict(item, src=m2["file"], t0=t0b, x=1 - x, rot=-rot,
                                          anim=dict(item["anim"], dx_from=-item["anim"]["dx_from"], rot_from=-item["anim"]["rot_from"],
                                                    float=dict(item["anim"]["float"], rot=-item["anim"]["float"]["rot"], dx=-item["anim"]["float"]["dx"]))))
                placed += 1
            busy.append((t0, t1))
            side = -side
        notes.append(f"{placed} B-roll cards placed like the reference ({cd['w']:.2f}×{cd['h']:.2f} of the frame, "
                     f"{'behind the head' if cd.get('behind') else 'in front'}, {cd.get('stack', 1)} at once). Label clips (what they show) so cards land on the right words.")
        if any(c.get("behind") for c in plan["items"] if c["type"] == "card"):
            plan["_needs_cutout"] = True

    # 6. accent words as often as the reference uses them (its punch words, not one per sentence)
    share = float(bp.get("accent_share", 0) or 0)
    if share > 0 and "accent" in plan["styles"]:
        from . import stylekit
        cap_words = [(c, w) for c in plan["items"] if c["type"] == "caption" and c.get("role") not in ("block", "hook") for w in c["words"]]
        step = max(2, int(round(1 / share)))
        for g in range(0, len(cap_words), step):
            win = cap_words[g:g + step]
            if any(w["style"] == "accent" for _, w in win):
                continue
            k = stylekit.keyword([w["w"] for _, w in win])
            if k is not None and _n(win[k][1]["w"]) not in STOP and len(_n(win[k][1]["w"])) >= 3:
                win[k][1]["style"] = "accent"

    # 6c. the words and the images share the frame like the reference: a caption never sits under a card; it moves just
    #     above it (where the reference keeps its words), or below it when above would cover the face
    cards_ = [i for i in plan["items"] if i["type"] == "card"]
    face_bottom = (face[1] + face[3]) if face else 0.0
    moved = 0
    for c in caps:
        if c.get("role") in ("block", "hook"):
            continue
        half = 0.035 * max(1, len(c.get("lines") or []) or 1)
        for k_ in cards_:
            if k_["t0"] >= c["t1"] or k_["t1"] <= c["t0"]:
                continue
            top_, bot_ = k_["y"] - k_["h"] / 2, k_["y"] + k_["h"] / 2
            if c["y"] + half > top_ - 0.01 and c["y"] - half < bot_:
                above = round(top_ - half - 0.015, 3)
                below = round(bot_ + half + 0.015, 3)
                c["y"] = above if above - half >= face_bottom - 0.01 or below > 0.9 else below
                moved += 1
    if moved:
        notes.append(f"{moved} captions moved just above the images (never under them, never on the face).")

    # 7. what the creator taught us (learning loop): sizes and positions
    if learned.get("caption_size"):
        for st in ("caption", "big", "accent"):
            if st in plan["styles"]:
                plan["styles"][st]["size"] = round(plan["styles"][st]["size"] * float(learned["caption_size"]), 4)
    if learned.get("caption_y") is not None:
        for c in caps:
            if c.get("role") not in ("block", "hook"):
                c["y"] = round(min(0.85, max(0.1, c["y"] + float(learned["caption_y"]))), 3)
    if learned.get("zoom") is False:
        plan["background"]["zooms"] = []
    plan.setdefault("_facts", {})["blueprint_notes"] = notes
    return {"notes": notes}


def for_project(project: Path) -> tuple[dict, str]:
    from . import styles as st
    cfg = util.read_json(project / "project.json")
    sid = cfg.get("style", "")
    path = st.style_path(sid)
    data = util.read_json(path) if path else {}
    bp = data.get("blueprint") or (data.get("kit") or {}).get("blueprint") or {}
    return bp, sid
