"""Retired standalone conversation entrypoints. Studio is a native-chat companion."""
from . import util

def _retired():
    raise util.Fail("Studio does not run a separate AI conversation.",
                    "Continue in the conversation beside Studio; your uploaded files are saved.")

def make(pid):
    return _retired()

def chat(pid, text, msg_id=""):
    return _retired()

def kick(pid, ev_id):
    return _retired()
