"""Diagnostic settings comparison (not a release gate or visual fidelity score): after every render, the edit is measured against the reference with numbers, not opinions.

Each line compares one thing (caption colour, height, words per caption, cuts, zooms, cards, graphics inventory,
brightness) and says what to fix when it's off. The agent must fix every flag before the creator sees the video.
Writes <project>/render/match.json. A generic edit can't pass it."""
from __future__ import annotations

from pathlib import Path

from . import util


def _rgb(c: str) -> tuple:
    c = (c or "#ffffff").lstrip("#")
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4)) if len(c) == 6 else (255, 255, 255)


def _main_caption(kit: dict) -> dict:
    caps = [s for s in kit.get("styles", {}).values() if s.get("role") == "caption"]
    return max(caps, key=lambda s: s.get("count", 0)) if caps else {}


def check(project: Path, kit: dict, preview: Path | None = None) -> dict:
    plan = util.read_json(project / "edit-plan.json", default={})
    bp = kit.get("blueprint") or {}
    items = plan.get("items", [])
    dur = float(plan.get("duration") or 1)
    rows = []

    def row(name, ok, ref, got, fix):
        rows.append({"what": name, "ok": bool(ok), "reference": ref, "edit": got, "fix": "" if ok else fix})

    # captions: colour, height, words on screen, how they appear
    main = _main_caption(kit)
    caps = [i for i in items if i["type"] == "caption" and i.get("role") != "hook"]
    if main and not caps:
        row('Required captions present', False, 'captions', 'none', 'add the planned captions or document the customer override')
    if main and caps:
        expected = (main.get('font') or {}).get('family')
        actual_font = (plan.get('fonts') or {}).get((plan.get('styles') or {}).get('caption', {}).get('font', 'caption'), {})
        if expected:
            row('Caption font configured', expected.casefold() == str(actual_font.get('family', '')).casefold(), expected,
                actual_font.get('family'), 'use the measured family or document an approved substitution')
        st = (plan.get("styles") or {}).get("caption", {})
        d = sum(abs(a - b) for a, b in zip(_rgb(main.get("colour")), _rgb(st.get("colour"))))
        row("Caption colour", d <= 60, main.get("colour"), st.get("colour"), "set the caption colour to the reference's exact colour")
        ry = (kit.get("captions") or {}).get("y_median") or main.get("y")
        gy = sorted(i["y"] for i in caps)[len(caps) // 2]
        rf, fb = kit.get("face"), (plan.get("_facts") or {}).get("face")
        if ry is not None and rf and fb:                 # same place relative to the face (a closer camera puts it lower)
            rchin, chin = rf[1] + rf[3], fb[1] + fb[3]
            ry = chin + (ry - rchin) / max(rf[3], 1e-3) * fb[3] if ry >= rchin else fb[1] - (rf[1] - ry) / max(rf[3], 1e-3) * fb[3]
            ry = min(0.8, max(0.1, ry))
        if ry is not None:
            row("Caption height", abs(gy - ry) <= 0.12, round(ry, 2), round(gy, 2), "move the captions to the reference's height (unless the face is there)")
        want = (bp.get("captions") or {}).get("words")
        got = round(sum(len(i["words"]) for i in caps) / len(caps), 1)
        if want:
            row("Words per caption", abs(got - want) <= max(1.0, want * 0.4), want, got, "group the captions like the reference")
        if (bp.get("captions") or {}).get("build") is not None:
            built = sum(1 for i in caps if i.get("reveal") == "word") / len(caps)
            want_b = bool(bp["captions"]["build"])
            row("Words appear one by one", (built >= 0.5) == want_b, want_b, built >= 0.5, "match how the reference reveals its words")
    # the cut: rhythm and zooms
    cuts = (plan.get("_facts") or {}).get("cuts") or []
    rcpm = float(kit.get("cuts_per_minute") or 0)
    gcpm = round(len(cuts) / dur * 60, 1)
    row("Cuts per minute", gcpm <= max(6.0, rcpm * 1.8 + 4), rcpm, gcpm,
        "too many jump cuts for this reference: keep natural pauses (re-plan with the reference's pacing)")
    zooms = len((plan.get("background") or {}).get("zooms", []))
    if bp.get("zoom") is not None:
        row("Zooms", (zooms > 0) == bool(bp.get("zoom")) or zooms == 0 and not cuts, bool(bp.get("zoom")), zooms > 0,
            "zoom only if the reference zooms")
    # graphics: where cards sit, and nothing the reference never uses
    cd = bp.get("cards") or {}
    cards = [i for i in items if i["type"] == "card"]
    if cd and cards:
        gy = sorted(i["y"] for i in cards)[len(cards) // 2]
        row("Card height", abs(gy - cd.get("y", gy)) <= 0.15, cd.get("y"), round(gy, 2), "place B-roll cards at the reference's height")
        gw = sorted(i.get("w", 0.3) for i in cards)[len(cards) // 2]
        row("Card size", abs(gw - cd.get("w", gw)) <= 0.12, cd.get("w"), round(gw, 2), "size the cards like the reference's")
        slots = cd.get("slots") or []
        if slots:
            off = []
            for i in cards:
                s_ = min(slots, key=lambda s: abs(s["at"] - i["t0"] / max(1.0, dur)))
                off.append(max(abs((i["y"] - i["h"] / 2) - s_["top"]), abs(i["x"] - s_["x"]), abs(i.get("w", 0) - s_["w"])))
            worst = max(off)
            row("Images placed like the reference", worst <= 0.06, "each image in the reference's spot", f"off by {worst * 100:.0f}% at most",
                "put every image in the box the reference uses at that moment (blueprint card slots)")
        tilt = sorted(abs(i.get("rot", 0)) for i in cards)[len(cards) // 2]
        row("Card tilt", abs(tilt - cd.get("rot", tilt)) <= 3, cd.get("rot"), tilt, "tilt the cards like the reference (or keep them straight)")
    extra = []
    if not bp.get("burst") and any(i["type"] == "burst" and not i.get("creative") for i in items):
        extra.append("bursts")
    if not bp.get("pieces") and any(i["type"] in ("piece", "html") and not i.get("creative") for i in items):
        extra.append("animated pieces")
    if not kit.get("behind_person") and any(i.get("behind") and not i.get("creative") for i in items):
        extra.append("text behind the person")
    row("Only the reference's kinds of graphics", not extra, "its own", ", ".join(extra) or "its own",
        "remove " + ", ".join(extra) + ' (or mark one "creative": true with a reason, if it truly fits the reference)')
    # colour: brightness of the picture
    if preview and preview.exists() and kit.get("colour"):
        try:
            from . import grade
            st = grade.stats(preview, n=6)
            row("Nothing blown out", st.get("clip", 0) <= 0.01, "0%", f"{st.get('clip', 0) * 100:.1f}%",
                "the picture is burnt out: grade again (edit.py grade) before showing it")
            rl, gl = kit["colour"].get("lum"), st.get("lum")
            if rl is not None and gl is not None:
                row("Brightness", abs(gl - rl) <= 0.15, round(rl, 2), round(gl, 2), "grade the picture closer to the reference's brightness")
        except Exception as e:
            util.log(f"scorecard brightness: {e}")
    res = {"rows": rows, "passed": sum(r["ok"] for r in rows), "total": len(rows)}
    util.write_json(project / "render" / "match.json", res)
    return res


def show(res: dict) -> None:
    util.ok(f"Settings diagnostics only (not visual approval): {res['passed']}/{res['total']}")
    for r in res["rows"]:
        if not r["ok"]:
            util.warn(f"{r['what']}: reference {r['reference']}, edit {r['edit']} → {r['fix']}")
