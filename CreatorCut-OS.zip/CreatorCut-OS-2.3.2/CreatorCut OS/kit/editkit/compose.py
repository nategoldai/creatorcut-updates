"""Turn an edit plan (plan.json) into a HyperFrames composition and render it.

The plan is the whole edit as data, written by the agent from the style kit and the transcript:

  {"canvas": {"w": 1080, "h": 1920, "fps": 30},
   "background": {"src": "cut.mp4", "zooms": [{"t0", "t1", "scale", "x", "y"}]},
   "fonts": {"caption": {"family", "file", "weight", "italic"}, "accent": {...}, "note": {...}},
   "styles": {"caption": {"font", "size", "colour", "shadow", "case", "tracking", "line"}, "big": {...}, "accent": {...}, "note": {...}},
   "items": [
     {"type": "caption", "t0", "t1", "x", "y", "align", "words": [{"w", "t", "style"}], "reveal": "block|word", "anim": {...}},
     {"type": "card",  "src", "t0", "t1", "x", "y", "w", "h", "rot", "radius", "shadow", "anim": {...}, "fit": "cover"},
     {"type": "note",  "text", "t0", "t1", "x", "y", "rot", "style": "note", "arrow": {"to": [x, y], "bend": 0.3}},
     {"type": "burst", "srcs": [...], "t0", "t1", "x", "y", "count", "spread"},
     {"type": "html",  "t0", "t1", "html", "css", "gsap"}            <- anything else, written by the agent
   ]}

Positions are fractions of the canvas (0-1, centre of the element). Sizes of text are fractions of the canvas
height (the same unit the reference map measures), so a measured style copies 1:1."""
from __future__ import annotations

import html as _h
import shutil
from pathlib import Path

from . import motion, util

EASES = {"signature-pop": "power3.out", "pop": "back.out(1.8)", "rise": "power3.out", "fade": "power1.out", "snap": "power4.out", "cut": "none"}


def _px(v: float, total: int) -> str:
    return f"{v * total:.1f}px"


def _font_face(name: str, f: dict, dest: Path) -> str:
    src = util.ROOT / f["file"]
    if not src.exists():
        raise util.Fail(f"The font file for {f.get('family')} is missing.", "Study the reference again to download it.")
    shutil.copy2(src, dest / src.name)
    style = "italic" if f.get("italic") else "normal"
    return f'@font-face {{ font-family: "cc-{name}"; src: url("{src.name}"); font-weight: {f.get("weight", 400)}; font-style: {style}; }}'


def _style_css(name: str, s: dict, fonts: dict, H: int) -> str:
    f = fonts.get(s.get("font", name), {})
    shadow = s.get("shadow")
    sh = f"text-shadow: 0 {H * 0.0012:.1f}px {H * 0.006:.1f}px rgba(0,0,0,{shadow});" if shadow else ""
    stroke = f"-webkit-text-stroke: {s['outline'] * H:.1f}px {s.get('outline_colour', '#000')}; paint-order: stroke fill;" if s.get("outline") else ""
    case = {"upper": "uppercase", "lower": "lowercase"}.get(s.get("case", ""), "none")
    return (f'.s-{name} {{ font-family: "cc-{s.get("font", name)}", sans-serif; font-weight: {f.get("weight", 400)}; '
            f'font-style: {"italic" if f.get("italic") else "normal"}; font-size: {s["size"] * H:.1f}px; '
            f'line-height: {s.get("line", 1.0)}; color: {s.get("colour", "#fff")}; letter-spacing: {s.get("tracking", -0.01)}em; '
            f'text-transform: {case}; {sh} {stroke} white-space: nowrap; }}')


_FONT_CACHE: dict = {}


def _fit_zoom(it: dict, plan: dict, W: int, H: int, room: float = 0.86) -> float:
    """How much a caption must shrink so its widest line fits `room` of the frame width, measured with the real font file."""
    try:
        from PIL import ImageFont
    except ImportError:
        return 1.0
    styles, fonts = plan.get("styles", {}), plan.get("fonts", {})
    words = it.get("words", [])
    lines = it.get("lines") or [list(range(len(words)))]
    widest = 0.0
    for ln in lines:
        w_px = 0.0
        for j in ln:
            if j >= len(words):
                continue
            st = styles.get(words[j].get("style", "caption"), {})
            f = fonts.get(st.get("font", words[j].get("style", "caption")), {})
            path = util.ROOT / f.get("file", "") if f.get("file") else None
            size = int(st.get("size", 0.07) * H)
            text = words[j]["w"]
            text = text.upper() if st.get("case") == "upper" else text.lower() if st.get("case") == "lower" else text
            try:
                key = (str(path), size)
                if key not in _FONT_CACHE:
                    _FONT_CACHE[key] = ImageFont.truetype(str(path), size) if path and path.exists() else None
                ft = _FONT_CACHE[key]
                ww = ft.getlength(text) if ft else len(text) * size * 0.55
            except Exception:
                ww = len(text) * size * 0.55
            if f.get("italic"):
                ww *= 1.08                                   # italic letters lean past their box
            w_px += ww + size * 0.28                         # the space between words
        widest = max(widest, w_px)
    return min(1.0, room * W / widest) if widest > 0 else 1.0


def _card_html(cid: str, src: str, t0: float, d: float, track: int, cx: float, cy: float, w: float, h: float, rot: float,
               radius: float, extra_css: str, fit: str) -> str:
    """A card: a wrapper that GSAP animates (always in the DOM, shown/hidden by opacity) holding the media.
    Videos are their own timed clips with an id (HyperFrames needs that to seek them frame-accurately)."""
    if src.endswith((".mp4", ".mov", ".m4v", ".webm")):
        media = (f'<video id="{cid}v" class="clip" src="{src}" muted playsinline data-start="{t0:.3f}" data-duration="{d:.3f}" '
                 f'data-track-index="{track + 20}" style="width:100%;height:100%;object-fit:{fit}"></video>')
    else:
        media = f'<img src="{src}" style="width:100%;height:100%;object-fit:{fit}">'
    return (f'<div id="{cid}" class="card" style="left:{cx - w / 2:.0f}px;top:{cy - h / 2:.0f}px;width:{w:.0f}px;height:{h:.0f}px;'
            f'border-radius:{radius:.0f}px;{extra_css}transform:rotate({rot:.1f}deg)">{media}</div>')


def build(project: Path, plan: dict) -> Path:
    """Write <project>/hf/index.html (+ assets) from the plan. Returns the composition folder."""
    import copy
    plan = copy.deepcopy(plan)
    cv = plan.get("canvas", {"w": 1080, "h": 1920, "fps": 30})
    W, H = int(cv["w"]), int(cv["h"])
    dur = float(plan["duration"])
    hf = project / "hf"
    if hf.exists():
        shutil.rmtree(hf)
    (hf / "assets").mkdir(parents=True)
    gsap = motion.RENDER / "node_modules" / "gsap" / "dist" / "gsap.min.js"
    shutil.copy2(gsap, hf / "gsap.min.js")

    def asset(src: str, size=None) -> str:
        p = (project / src) if not Path(src).is_absolute() else Path(src)
        if not p.exists():
            p = util.ROOT / src
        if not p.exists():
            raise util.Fail(f"A file in the edit plan is missing: {src}")
        import hashlib
        mw,mh = (int(size[0]),int(size[1])) if size else (W,H)
        mw,mh = max(16,mw//2*2),max(16,mh//2*2)
        key = hashlib.sha1(f"{p.resolve()}:{p.stat().st_mtime_ns}:{p.stat().st_size}:{mw}x{mh}".encode()).hexdigest()[:10]
        if p.suffix.lower() in (".mp4", ".mov", ".m4v", ".mkv"):    # .webm stays as is: it may carry transparency (the cut-out)
            # frame-accurate seeking needs a keyframe every second; also normalises phone HDR/HEVC to plain H.264
            cache = project / "work" / "seekable"
            cache.mkdir(parents=True, exist_ok=True)
            out = cache / f"{key}.mp4"
            if not out.exists():
                from . import cut
                info = util.probe(p)
                filters = cut.tonemap_filter(info) + f"scale=w='min(iw,{mw})':h='min(ih,{mh})':force_original_aspect_ratio=decrease:force_divisible_by=2,setsar=1"
                hdr = ['-vf', filters]
                util.run([util.ffmpeg_bin(), "-v", "error", "-y", "-i", str(p), *hdr, "-c:v", "libx264", "-preset", "veryfast", "-crf", "17",
                          "-pix_fmt", "yuv420p", "-g", "30", "-keyint_min", "30", "-movflags", "+faststart", "-c:a", "aac", "-b:a", "192k", str(out)])
            p = out
        name = f"a{key}{p.suffix.lower()}"
        dst = hf / "assets" / name
        if not dst.exists():
            try:
                dst.hardlink_to(p)
            except OSError:
                shutil.copy2(p, dst)
        return f"assets/{name}"

    # items can be anchored to words instead of seconds: {"say": "folder", "occurrence": 1, "dur": 2.4}
    # (or "until_say": "clips"), so a new cut never puts a graphic at the wrong moment
    wj = util.read_json(project / "words.json", default={"words": []})["words"]
    norm = lambda t: "".join(ch for ch in t.lower() if ch.isalnum() or ch == "'")
    def when(key: str, occ: int = 1) -> float | None:
        n = 0
        for w in wj:
            if norm(w["w"]) == norm(key):
                n += 1
                if n == occ:
                    return float(w["start"])
        return None
    for it in plan.get("items", []):
        if it.get("say"):
            t = when(it["say"], it.get("occurrence", 1))
            if t is None:
                raise util.Fail(f'A graphic is anchored to "{it["say"]}", but that word isn\'t in the cut anymore.', "Anchor it to another word.")
            it["t0"] = round(max(0.0, t + it.get("offset", 0.0)), 3)
            end = when(it["until_say"], it.get("until_occurrence", 1)) if it.get("until_say") else None
            it["t1"] = round(end if end and end > it["t0"] else it["t0"] + it.get("dur", 2.4), 3)
    from . import pieces as _pieces
    try:
        plan["items"] = [_pieces.expand(i, plan, W, H) if i.get("type") == "piece" else i for i in plan.get("items", [])]
    except ValueError as e:
        raise util.Fail(str(e))
    # never two graphics on top of each other: when one would overlap the next on screen, it leaves as the next arrives
    gfx = sorted((i for i in plan.get("items", []) if i["type"] in ("card", "note", "burst", "html")), key=lambda i: i["t0"])
    def area(i):
        if i["type"] in ("html", "burst"):
            return (0.0, 0.0, 1.0, 0.45) if i["type"] == "html" else (0.0, 0.0, 1.0, 1.0)
        w, h = (i.get("w", 0.4), i.get("h", 0.15)) if i["type"] == "card" else (0.5, 0.14)
        return (i["x"] - w / 2, i["y"] - h / 2, i["x"] + w / 2, i["y"] + h / 2)
    for a_, b_ in ([] if (project / "scene-plan.json").exists() else zip(gfx, gfx[1:])):
        A, B = area(a_), area(b_)
        if a_.get("together") and b_.get("together"):
            continue                                    # parts of one scene (a stage and the clip on it) stay together
        if a_["t1"] > b_["t0"] and A[0] < B[2] and B[0] < A[2] and A[1] < B[3] and B[1] < A[3]:
            a_["t1"] = round(max(a_["t0"] + 0.4, b_["t0"]), 3)
    fonts = plan.get("fonts", {})
    css = [_font_face(k, v, hf) for k, v in fonts.items()]
    css += [_style_css(k, v, fonts, H) for k, v in plan.get("styles", {}).items()]
    body, js = [], []
    bg = plan["background"]
    body.append(f'<video id="bg" class="clip" src="{asset(bg["src"])}" playsinline data-has-audio="true" data-start="0" data-duration="{dur:.3f}" '
                f'data-track-index="0" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;transform-origin:50% 40%"></video>')
    for z in bg.get("zooms", []):
        ox, oy = z.get("x", 0.5) * 100, z.get("y", 0.4) * 100
        tgt = '["#bg", "#cutout"]' if plan.get("person_cutout") else '"#bg"'   # the cut-out zooms exactly with the footage
        js.append(f'tl.set({tgt}, {{scale: {z["scale"]}, transformOrigin: "{ox:.0f}% {oy:.0f}%"}}, {z["t0"]:.3f});')
        js.append(f'tl.set({tgt}, {{scale: 1}}, {z["t1"]:.3f});')
    for k, it in enumerate(plan.get("items", [])):
        iid = f"i{k}"
        t0, t1 = float(it["t0"]), float(it["t1"])
        d = max(0.05, t1 - t0)
        track = 2 + k % 6
        an = it.get("anim", {})
        if it["type"] == "caption":
            spans = []
            for j, w in enumerate(it["words"]):
                spans.append(f'<span id="{iid}w{j}" class="s-{w.get("style", "caption")}">{_h.escape(w["w"])}</span>')
            lines = it.get("lines")
            inner = " ".join(spans)
            if lines:                                   # explicit line breaks: [[0, 1], [2]]
                inner = "<br>".join(" ".join(spans[j] for j in ln) for ln in lines)
            align = it.get("align", "center")
            zoom = _fit_zoom(it, plan, W, H)
            fit_style = ' style="zoom:%.3f"' % zoom if zoom < 0.999 else ""
            body.append(f'<div id="{iid}" class="clip cap{" behind" if it.get("behind") else ""}" data-start="{t0:.3f}" data-duration="{d:.3f}" data-track-index="{track}" '
                        f'style="left:{_px(it["x"], W)};top:{_px(it["y"], H)};text-align:{align}"><span class="fit"{fit_style}>{inner}</span></div>')
            ease = EASES.get(an.get("ease", "pop"), an.get("ease", "power2.out"))
            ms = an.get("ms", 120) / 1000
            fr = {"opacity": an.get("opacity_from", 0), "scale": an.get("scale_from", 0.92), "y": an.get("dy_from", 0) * H}
            if it.get("reveal") == "word" and an.get("ease") == "cut":
                for j, w in enumerate(it["words"]):          # in place, hard cut: no fade, no scale, no jump
                    js.append(f'tl.set("#{iid}w{j}", {{opacity: 0}}, {t0:.3f});')
                    js.append(f'tl.set("#{iid}w{j}", {{opacity: 1}}, {max(t0, float(w.get("t", t0))):.3f});')
            elif an.get("ease") == "signature-pop":
                targets = [(f"#{iid}w{j}", max(t0, float(w.get("t", t0)))) for j, w in enumerate(it["words"])] if it.get("reveal") == "word" else [(f"#{iid} .fit", t0)]
                for target, at in targets:
                    end = min(t1, at + ms)
                    js.append(f'gsap.set("{target}", {{opacity:0, scale:1}});')
                    js.append(f'tl.fromTo("{target}", {{opacity:0, scale:{fr["scale"]}}}, {{opacity:1, scale:1, duration:{max(.001,end-at):.3f}, ease:"power3.out", immediateRender:false}}, {at:.3f});')
            elif it.get("reveal") == "word":
                for j, w in enumerate(it["words"]):
                    js.append(f'tl.from("#{iid}w{j}", {{opacity: {fr["opacity"]}, scale: {fr["scale"]}, y: {fr["y"]:.1f}, '
                              f'duration: {ms:.3f}, ease: "{ease}"}}, {max(t0, float(w.get("t", t0))):.3f});')
            elif an.get("ease") != "cut":
                js.append(f'tl.from("#{iid}", {{opacity: {fr["opacity"]}, scale: {fr["scale"]}, y: {fr["y"]:.1f}, '
                          f'duration: {ms:.3f}, ease: "{ease}"}}, {t0:.3f});')
        elif it["type"] == "card":
            w, h = it["w"] * W, it["h"] * H
            src = asset(it["src"], (min(W,w*2),min(H,h*2)))
            sh = "box-shadow:0 18px 50px rgba(0,0,0,.38);" if it.get("shadow", True) else "box-shadow:none;"
            border = f'border:{it["border"] * H:.1f}px solid {it.get("border_colour", "#fff")};' if it.get("border") else ""
            body.append(_card_html(iid, src, t0, d, track, it["x"] * W, it["y"] * H, w, h, it.get("rot", 0), it.get("radius", 0.06) * W,
                                   sh + border + (f"z-index:{int(it['z'])};" if it.get("z") is not None else "z-index:12;" if it.get("behind") else ""),
                                   it.get("fit", "cover")))
            ease = EASES.get(an.get("ease", "rise"), an.get("ease", "power3.out"))
            js.append(f'tl.set("#{iid}", {{opacity: 0}}, 0);')
            if an.get("enter") == "cut":                      # appears, like a cut in the reference
                js.append(f'tl.set("#{iid}", {{opacity: 1}}, {t0:.3f});')
            elif an.get("enter") in ("slide-up", "slide-down", "slide-left", "slide-right"):   # in from an edge, then still
                off = {"slide-up": ("y", (1.0 - it["y"]) * H + h / 2), "slide-down": ("y", -(it["y"] * H + h / 2)),
                       "slide-left": ("x", (1.0 - it["x"]) * W + w / 2), "slide-right": ("x", -(it["x"] * W + w / 2))}[an["enter"]]
                js.append(f'tl.fromTo("#{iid}", {{opacity: 1, {off[0]}: {off[1]:.0f}}}, {{opacity: 1, {off[0]}: 0, '
                          f'duration: {an.get("ms", 420) / 1000:.3f}, ease: "power3.out"}}, {t0:.3f});')
            elif an.get("enter") == "fade":
                js.append(f'tl.fromTo("#{iid}", {{opacity: 0}}, {{opacity: 1, duration: {an.get("ms", 300) / 1000:.3f}, ease: "none"}}, {t0:.3f});')
            elif an.get("enter") == "pop":                    # grows in from the middle, no tilt
                js.append(f'tl.fromTo("#{iid}", {{opacity: 0, scale: 0.55}}, {{opacity: 1, scale: 1, '
                          f'duration: {an.get("ms", 300) / 1000:.3f}, ease: "back.out(1.4)"}}, {t0:.3f});')
            else:
                js.append(f'tl.fromTo("#{iid}", {{opacity: 0, x: {an.get("dx_from", 0.12) * W:.0f}, y: {an.get("dy_from", 0.0) * H:.0f}, '
                          f'rotation: {it.get("rot", 0) + an.get("rot_from", 6)}, scale: {an.get("scale_from", 0.9)}}}, '
                          f'{{opacity: 1, x: 0, y: 0, rotation: {it.get("rot", 0)}, scale: 1, duration: {an.get("ms", 320) / 1000:.3f}, ease: "{ease}"}}, {t0:.3f});')
            # while on screen the card keeps moving: a slow drift and a little more tilt (references never hold a card dead still)
            fl = an.get("float", {})
            if fl is not False and fl is not None and d > 0.8 and an.get("enter") not in (
                    "cut", "slide-up", "slide-down", "slide-left", "slide-right", "fade", "pop"):
                sgn = 1 if it.get("rot", 0) >= 0 else -1
                ms = an.get("ms", 320) / 1000
                js.append(f'tl.to("#{iid}", {{rotation: {it.get("rot", 0) + fl.get("rot", 3.5 * sgn):.1f}, x: {fl.get("dx", -0.012 * sgn) * W:.0f}, '
                          f'y: {fl.get("dy", -0.012) * H:.0f}, scale: {fl.get("scale", 1.03)}, duration: {max(0.3, d - ms - 0.2):.3f}, ease: "sine.inOut"}}, {t0 + ms:.3f});')
            if an.get("exit") == "cut":
                js.append(f'tl.set("#{iid}", {{opacity: 0}}, {t1:.3f});')
            elif an.get("exit") in ("slide-up", "slide-down", "slide-left", "slide-right"):
                off = {"slide-down": ("y", (1.0 - it["y"]) * H + h / 2), "slide-up": ("y", -(it["y"] * H + h / 2)),
                       "slide-right": ("x", (1.0 - it["x"]) * W + w / 2), "slide-left": ("x", -(it["x"] * W + w / 2))}[an["exit"]]
                js.append(f'tl.to("#{iid}", {{{off[0]}: {off[1]:.0f}, duration: 0.28, ease: "power2.in"}}, {max(t0, t1 - 0.28):.3f});')
            elif an.get("exit") == "fade":
                js.append(f'tl.to("#{iid}", {{opacity: 0, duration: 0.2, ease: "none"}}, {max(t0, t1 - 0.2):.3f});')
            else:
                js.append(f'tl.to("#{iid}", {{opacity: 0, scale: 0.9, duration: 0.18, ease: "power1.in"}}, {max(t0, t1 - 0.18):.3f});')
        elif it["type"] == "note":
            st = it.get("style", "note")
            arrow = ""
            if it.get("arrow"):
                ax, ay = it["arrow"]["to"]
                sx, sy = it["x"] * W, it["y"] * H + 0.03 * H
                ex, ey = ax * W, ay * H
                bend = it["arrow"].get("bend", 0.35)
                cx, cy = (sx + ex) / 2 + (ey - sy) * bend, (sy + ey) / 2 - (ex - sx) * bend
                col = plan["styles"].get(st, {}).get("colour", "#fff")
                arrow = (f'<svg id="{iid}a" width="{W}" height="{H}" '
                         f'style="position:absolute;left:0;top:0;overflow:visible"><path id="{iid}p" d="M{sx:.0f},{sy:.0f} Q{cx:.0f},{cy:.0f} {ex:.0f},{ey:.0f}" '
                         f'fill="none" stroke="{col}" stroke-width="{H * 0.0032:.1f}" stroke-linecap="round"/>'
                         f'<path d="M{ex:.0f},{ey:.0f} l{-H * 0.012:.0f},{-H * 0.006:.0f} M{ex:.0f},{ey:.0f} l{-H * 0.004:.0f},{-H * 0.013:.0f}" stroke="{col}" '
                         f'stroke-width="{H * 0.0032:.1f}" stroke-linecap="round" fill="none"/></svg>')
                js.append(f'(function(){{var p=document.getElementById("{iid}p");var L=p.getTotalLength();p.style.strokeDasharray=L;'
                          f'tl.fromTo(p,{{strokeDashoffset:L}},{{strokeDashoffset:0,duration:0.45,ease:"power2.out"}},{t0 + 0.25:.3f});}})();')
            text = "<br>".join(_h.escape(x) for x in it["text"].split("\n"))
            body.append(f'<div id="{iid}" class="note s-{st}" '
                        f'style="left:{_px(it["x"], W)};top:{_px(it["y"], H)};transform:translate(-50%,-50%) rotate({it.get("rot", -4)}deg)">{text}</div>{arrow}')
            js.append(f'tl.set(["#{iid}", "#{iid}a"], {{opacity: 0}}, 0);')
            js.append(f'tl.fromTo("#{iid}", {{opacity: 0, y: {0.01 * H:.0f}}}, {{opacity: 1, y: 0, duration: 0.3, ease: "power2.out"}}, {t0:.3f});')
            js.append(f'tl.set("#{iid}a", {{opacity: 1}}, {t0 + 0.2:.3f});')
            js.append(f'tl.to(["#{iid}", "#{iid}a"], {{opacity: 0, duration: 0.2}}, {max(t0, t1 - 0.2):.3f});')
        elif it["type"] == "burst":
            import math
            import random
            srcs = [asset(x) for x in it["srcs"]]
            n = it.get("count", len(srcs))
            rnd = random.Random(k)
            cw = it.get("size", 0.13) * W
            for j in range(n):
                face = plan.get("_facts", {}).get("face")
                for _try in range(40):            # around the person, never over the face
                    ang = j / n * 6.283 + rnd.uniform(-0.5, 0.5)
                    r = it.get("spread", 0.3) * (0.55 + 0.45 * rnd.random())
                    tx, ty = it["x"] + r * 0.62 * math.cos(ang), it["y"] + r * math.sin(ang)
                    hw, hh = it.get("size", 0.13) / 2 + 0.01, it.get("size", 0.13) * 1.6 * W / H / 2 + 0.01
                    if not face or not (tx + hw > face[0] and tx - hw < face[0] + face[2] and ty + hh > face[1] and ty - hh < face[1] + face[3]):
                        break
                bid = f"{iid}b{j}"
                body.append(_card_html(bid, srcs[j % len(srcs)], t0, d, 8 + j % 6, tx * W, ty * H, cw, cw * 1.6,
                                       rnd.uniform(-14, 14), cw * 0.08, "box-shadow:0 10px 26px rgba(0,0,0,.35);" + ("z-index:12;" if it.get("behind") else ""), "cover"))
                js.append(f'tl.set("#{bid}", {{opacity: 0}}, 0);')
                js.append(f'tl.fromTo("#{bid}", {{x: {(it["x"] - tx) * W:.0f}, y: {(it["y"] - ty) * H:.0f}, scale: 0.2, opacity: 0}}, '
                          f'{{x: 0, y: 0, scale: 1, opacity: 1, duration: 0.42, ease: "back.out(1.4)"}}, {t0 + j * 0.035:.3f});')
                # then keep floating outwards and up, like a cloud of clips
                dxf, dyf = (tx - it["x"]) * W * 0.18, -H * rnd.uniform(0.01, 0.035)
                js.append(f'tl.to("#{bid}", {{x: {dxf:.0f}, y: {dyf:.0f}, rotation: "+={rnd.uniform(-6, 6):.1f}", duration: {max(0.3, d - 0.45 - j * 0.035):.3f}, ease: "sine.out"}}, {t0 + 0.42 + j * 0.035:.3f});')
                js.append(f'tl.to("#{bid}", {{opacity: 0, scale: 0.8, duration: 0.16}}, {max(t0 + j * 0.035 + 0.45, t1 - 0.16 - (n - j) * 0.008):.3f});')
        elif it["type"] == "html":
            for key, src in sorted(it.get("assets", {}).items(), key=lambda kv: -len(kv[0])):   # images/videos the piece uses
                it["html"] = it["html"].replace(f"assets/{key}", asset(src, it.get("asset_sizes",{}).get(key)))
            it["html"] = it["html"].replace("$ID", iid).replace("$T0", f"{t0:.3f}")
            # Timed child videos must not sit inside another timed element: the
            # extractor uses global timestamps, so a second offset corrupts seeking.
            nested_video = '<video' in it['html'].lower()
            timing = '' if nested_video else f'class="clip" data-start="{t0:.3f}" data-duration="{d:.3f}" data-track-index="{track}"'
            body.append(f'<div id="{iid}" {timing} '
                        f'style="position:absolute;inset:0;z-index:{int(it["z"]) if it.get("z") is not None else 12 if it.get("behind") else 19}">{it["html"]}</div>')
            if nested_video:
                js += [f'tl.fromTo("#{iid}", {{opacity:0}}, {{opacity:1,duration:0.001,immediateRender:true}}, {t0:.3f});',
                       f'tl.to("#{iid}", {{opacity:0,duration:0.001}}, {max(t0,t1-.001):.3f});']
            css.append(it.get("css", "").replace("$ID", iid))
            if it.get("gsap"):
                js.append(it["gsap"].replace("$T0", f"{t0:.3f}").replace("$ID", iid))
    if plan.get("person_cutout") and any(i.get("behind") for i in plan.get("items", [])):
        # text behind the person: the person, cut out (transparent video), above the text marked "behind"
        pc = plan["person_cutout"]
        body.append(f'<video id="cutout" class="clip" src="{asset(pc["src"])}" muted playsinline data-start="0" data-duration="{dur:.3f}" '
                    f'data-track-index="30" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:15;transform-origin:50% 40%"></video>')
    page = f'''<!doctype html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width={W}, height={H}">
<script src="gsap.min.js"></script>
<style>
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
html, body {{ width: {W}px; height: {H}px; overflow: hidden; background: #000; }}
.cap {{ position: absolute; transform: translate(-50%, -50%); z-index: 20; white-space: nowrap; }}
.note {{ z-index: 21; }}
.cap.behind {{ z-index: 12; }}
.cap span {{ display: inline-block; }}
.cap span + span {{ margin-left: 0.24em; }}
.card {{ position: absolute; overflow: hidden; background: #111; z-index: 18; }}
.note {{ position: absolute; white-space: nowrap; }}
{chr(10).join(css)}
</style></head>
<body>
<div id="root" data-composition-id="main" data-start="0" data-duration="{dur:.3f}" data-width="{W}" data-height="{H}" data-fps="{cv.get('fps',30)}">
{chr(10).join(body)}
</div>
<script>
// safety: every text block fits inside the safe area (6 % margins) - shrink, never overflow
function fitAll() {{
  document.querySelectorAll(".cap, .note").forEach(function (el) {{
    var z = el.querySelector(":scope > .fit") || el;   // captions shrink inside, so their position never moves
    if (z.dataset.k === undefined) z.dataset.k = z.style.zoom || "1";
    z.style.zoom = "";
    var r = el.getBoundingClientRect(), italic = el.querySelector("[class*=accent]") ? 0.06 : 0;
    var k = Math.min(1, ({W} * (0.86 - italic)) / Math.max(1, r.width));
    var room = Math.min(el.offsetTop - {H} * 0.05, {H} * 0.95 - el.offsetTop) * 2;
    if (el.classList.contains("cap")) k = Math.min(k, Math.max(0.3, room / Math.max(1, r.height)));
    k = Math.min(k, parseFloat(z.dataset.k) || 1);       // never bigger than the size measured with the real font
    if (k < 1) z.style.zoom = k.toFixed(3);
  }});
}}
fitAll();
if (document.fonts && document.fonts.ready) document.fonts.ready.then(fitAll);   // measure again in the real fonts
const tl = gsap.timeline({{ paused: true }});
{chr(10).join(js)}
window.__timelines = window.__timelines || {{}}; window.__timelines["main"] = tl;
</script>
</body></html>'''
    (hf / "index.html").write_text(page, encoding="utf-8")
    util.write_json(hf / "plan.json", plan)
    return hf


def render(project: Path, out: Path, quality: str = "looks", progress=None) -> Path:
    """Render the composition with HyperFrames to an MP4 (with the cut's audio)."""
    hf = project / "hf"
    if not (hf / "index.html").exists():
        raise util.Fail("There's no edit plan to render yet.")
    tmp = hf / "out.mp4"
    render_plan = util.read_json(hf/'plan.json')
    from fractions import Fraction
    fps = str(Fraction(str(render_plan.get('canvas',{}).get('fps',30))).limit_denominator(1001))
    cfg = util.read_json(project/'project.json',default={})
    workers = max(1,min(4,int(cfg.get('render_workers',1))))
    r = motion.run("hyperframes", ["render", "-o", "out.mp4", "--quality", quality, "--fps", fps, "--workers", str(workers), "--quiet"], cwd=hf, progress=progress)
    if not tmp.exists():
        util.log(r.stdout[-3000:])
        raise util.Fail("The motion graphics render failed.", (r.stdout or "")[-300:])
    out.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(tmp), str(out))
    # HyperFrames keeps extracted frames in the system temp folder (can be gigabytes). Remove the ones nobody has
    # touched for 30 minutes (a render running right now keeps its own fresh).
    import tempfile
    import time as _t
    for base in {Path(tempfile.gettempdir()), Path("/tmp")}:
        for c in base.glob("hyperframes-extract-cache-*"):
            try:
                if _t.time() - c.stat().st_mtime > 1800:
                    shutil.rmtree(c, ignore_errors=True)
            except OSError:
                pass
    return out


def check(project: Path) -> dict:
    """HyperFrames' own gate: lint, runtime errors, layout, contrast. Returns findings."""
    hf = project / "hf"
    import time
    t_start = time.time() - 1
    r = motion.run("hyperframes", ["check"], cwd=hf, timeout=600)
    rep = sorted((f for f in (hf / ".hyperframes" / "artifacts" / "checks").glob("*.json") if f.stat().st_mtime >= t_start),
                 key=lambda f: f.stat().st_mtime)
    data = util.read_json(rep[-1], default={}) if rep else {}
    out = {"ok": True, "errors": [], "warnings": [], "review_findings": []}
    if not rep:                                         # the checker didn't report: say so (the render itself still validates)
        out["errors"].append("check: HyperFrames didn't write a report" + (f" ({(r.stderr or r.stdout or '').strip()[-200:]})" if r.returncode else ""))
    for sec in ("lint", "runtime", "layout", "motion", "contrast"):
        for f in (data.get(sec) or {}).get("findings", []):
            message = f"{sec}: {f.get('message')}"
            if f.get('severity') == 'error' and sec in ('lint','runtime'):
                out['errors'].append(message)
            else:
                out['warnings'].append(message)
                if f.get('severity') == 'error':
                    out['review_findings'].append({'id':f"{sec}:{f.get('code')}:{f.get('selector','')}",
                                                  'section':sec,'message':f.get('message'), 'time':f.get('time'),
                                                  'selector':f.get('selector'), 'text':f.get('text','')})
    if r.returncode and not out['errors'] and not out['review_findings']:
        out['errors'].append('HyperFrames check failed: ' + (r.stderr or r.stdout or '')[-400:])
    out["ok"] = not out["errors"]
    return out
