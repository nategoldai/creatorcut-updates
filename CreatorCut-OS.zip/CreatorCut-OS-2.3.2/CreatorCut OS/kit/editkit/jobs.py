"""Background jobs the Studio server runs by itself: fetching reference links, analysing references, learning a
style, re-rendering a preview after a settings change, final renders and library extras.

Engine work runs as a separate `edit.py …` process (same private Python), so a crash never takes the Studio down.
Jobs that need the editing tools wait politely until the installer has finished them."""
from __future__ import annotations

import itertools
import json
import os
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path

from . import events, util

JOBS_FILE = util.STUDIO_OUT / "jobs.json"
_jobs: dict[str, dict] = {}
_lock = threading.Lock()
_heavy = threading.Lock()          # one FFmpeg-heavy job at a time keeps the laptop responsive
_version = itertools.count(1)
VERSION = {"n": 0}


def _bump() -> None:
    VERSION["n"] = next(_version)
    try:
        keep = sorted(_jobs.values(), key=lambda j: j["created"])[-60:]
        util.write_json(JOBS_FILE, {"jobs": keep})
    except OSError:
        pass


def _load() -> None:
    try:
        for j in util.read_json(JOBS_FILE, default={"jobs": []})["jobs"]:
            if j["state"] in ("queued", "running", "waiting"):
                j["state"], j["message"] = "error", "The Studio restarted while this was running. Try again."
            _jobs[j["id"]] = j
    except util.Fail:
        pass


_load()


def get(job_id: str) -> dict | None:
    with _lock:
        j = _jobs.get(job_id)
        return dict(j) if j else None


def all_jobs() -> list[dict]:
    with _lock:
        return sorted((dict(j) for j in _jobs.values()), key=lambda j: j["created"], reverse=True)[:30]


def has_active() -> bool:
    """Safety checks must include work older than the 30-row display window."""
    with _lock:
        return any(j.get('state') in ('queued', 'running', 'waiting') for j in _jobs.values())


def update(job_id: str, **kw) -> None:
    with _lock:
        if job_id in _jobs:
            _jobs[job_id].update(kw)
            _jobs[job_id]["updated"] = time.time()
            _bump()


def find(kind: str, key: str, states=("queued", "waiting")) -> dict | None:
    with _lock:
        for j in _jobs.values():
            if j["kind"] == kind and j.get("key") == key and j["state"] in states:
                return dict(j)
    return None


def submit(kind: str, fn, key: str = "", label: str = "", heavy: bool = True, needs: str = "") -> dict:
    """Start fn(job_id) in a thread. `needs`: "tools" waits for FFmpeg + packages, "model" also for speech."""
    jid = uuid.uuid4().hex[:10]
    job = {"id": jid, "kind": kind, "key": key, "label": label, "state": "queued", "progress": 0.0,
           "message": "Waiting to start…", "result": None, "created": time.time(), "updated": time.time()}
    with _lock:
        _jobs[jid] = job
        _bump()

    def runner():
        try:
            if needs:
                _wait_ready(jid, needs)
            if heavy:
                if _heavy.locked():
                    update(jid, message="Waiting for the current job to finish…")
                if not _heavy.acquire(timeout=7200):
                    raise util.Fail("The previous editing task has not released its tools. Check that task before retrying.")
                try:
                    update(jid, state="running", message="Starting…")
                    res = fn(jid)
                finally:
                    _heavy.release()
            else:
                update(jid, state="running", message="Starting…")
                res = fn(jid)
            update(jid, state="done", progress=1.0, result=res, message="Done")
            events.emit("job.done", {"job": jid, "kind": kind, "key": key, "result": res}, source="server")
        except util.Fail as e:
            update(jid, state="error", message=e.message)
            events.emit("job.error", {"job": jid, "kind": kind, "key": key, "message": e.message}, source="server")
        except Exception as e:  # never leak a traceback to the creator
            util.log_exception(f"job {kind} {key}")
            update(jid, state="error", message="Something went wrong. Your editor can look at it: say 'check my studio'.")
            events.emit("job.error", {"job": jid, "kind": kind, "key": key, "message": str(e)[:200]}, source="server")

    threading.Thread(target=runner, daemon=True, name=f"job-{kind}").start()
    return dict(job)


# ------------------------------------------------------------- readiness ----
_ready_cache: dict[str, bool] = {}


def tools_ready() -> bool:
    if _ready_cache.get("tools"):
        return True
    ff = util.BIN / ("ffmpeg.exe" if util.os_name() == "windows" else "ffmpeg")
    if not ff.exists() and not util.which("ffmpeg"):
        return False
    try:
        r = subprocess.run([sys.executable, "-c", "import PIL, faster_whisper"], capture_output=True, timeout=60)
    except Exception:
        return False
    _ready_cache["tools"] = r.returncode == 0
    return _ready_cache["tools"]


def model_ready() -> bool:
    if _ready_cache.get("model"):
        return True
    from . import setup
    _ready_cache["model"] = setup._model_cached(util.load_profile().get("whisper_model", "small"))
    return _ready_cache["model"]


def install_busy() -> bool:
    from . import state
    return state.install_status().get("state") == "running"


def _wait_ready(jid: str, needs: str) -> None:
    said = False
    deadline = time.time() + 3600
    while time.time() < deadline:
        ok = tools_ready() and (needs != "model" or model_ready() or not install_busy())
        if ok:
            return
        if not install_busy():
            raise util.Fail("The editing tools are not ready.", "I need to finish or repair setup before this step can run.")
        if not said:
            update(jid, state="waiting", message="Waiting for the install to finish…")
            said = True
        time.sleep(2)
    raise util.Fail("The editing tools aren't installed yet.", "Ask your editor to run setup again.")


# ------------------------------------------------------- engine commands ----
STAGE_HINTS = [("Transcrib", 0.15), ("speech", 0.15), ("plan", 0.3), ("Cutting", 0.4), ("Cut done", 0.5),
               ("captions and graphics", 0.6), ("Rendering", 0.7), ("rendered", 0.95), ("Preview ready", 0.95)]


def engine(jid: str, args: list[str], base: float = 0.05, span: float = 0.9) -> str:
    """Run `edit.py <args>` and stream its friendly lines into the job. Returns stdout."""
    cmd = [sys.executable, str(util.ROOT / "edit.py"), *args]
    env = dict(os.environ, PYTHONUNBUFFERED="1", AIE_FROM_STUDIO="1")
    proc = util.spawn(cmd, cwd=str(util.ROOT), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                            encoding="utf-8", errors="replace", env=env)
    out, prog = [], base
    for line in util.progress_lines(proc, timeout=7200, idle_timeout=600):
        line = line.rstrip()
        out.append(line)
        clean = line.lstrip("•✓!→ ").strip()
        for hint, p in STAGE_HINTS:
            if hint.lower() in clean.lower():
                prog = max(prog, base + span * p)
        if clean and not clean.startswith(("{", "}", "[", "]", '"')) and len(clean) < 140:
            update(jid, message=clean, progress=round(min(prog, base + span), 3), progress_at=time.time())
    proc.wait()
    text = "\n".join(out)
    if proc.returncode != 0:
        msg = next((l[2:] for l in reversed(out) if l.startswith("✗ ")), "")
        util.log(f"engine {' '.join(args)} failed:\n{text[-3000:]}")
        raise util.Fail(msg or "The engine stopped unexpectedly.")
    return text


def is_listening() -> bool:
    return events.listening()["listening"]


def json_tail(text: str) -> dict:
    """The last JSON object printed by a command."""
    i = text.rfind("\n{")
    i = 0 if i < 0 and text.startswith("{") else i
    try:
        return json.loads(text[i:].strip()) if i >= 0 else {}
    except ValueError:
        return {}


def path_ok(p: Path) -> bool:
    try:
        p.resolve().relative_to(util.ROOT.resolve())
        return True
    except ValueError:
        return False
