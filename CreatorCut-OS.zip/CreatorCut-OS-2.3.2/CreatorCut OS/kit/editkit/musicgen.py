"""Original background music, synthesised on the creator's computer: no licences, no downloads.

Each mood is a 64-second loop at 48 kHz stereo: chord pads, a bass line, a simple melody and drums, with a
soft stereo reverb. They're built to sit quietly under a voice (the engine ducks them while you talk).

    edit.py music-gen            makes kit/music/*.m4a (skips ones that exist)
"""
from __future__ import annotations

from pathlib import Path

from . import util

LIBRARY = util.KIT / "music"
SR = 48000

# mood: (bpm, root midi, progression (scale degrees), scale, drums, pad brightness, swing, energy)
MOODS = {
    "lofi-chill":    (82, 57, [0, 5, 3, 4], "minor", "lofi", 0.35, 0.12, 2),
    "upbeat-pop":    (118, 60, [0, 4, 5, 3], "major", "pop", 0.7, 0.0, 4),
    "tech-pulse":    (124, 57, [0, 0, 5, 3], "minor", "four", 0.55, 0.0, 4),
    "cinematic":     (90, 50, [0, 5, 2, 6], "minor", "soft", 0.3, 0.0, 3),
    "warm-acoustic": (100, 62, [0, 3, 4, 0], "major", "soft", 0.45, 0.08, 2),
    "hype-trap":     (140, 54, [0, 0, 6, 5], "minor", "trap", 0.5, 0.0, 5),
}
SCALES = {"major": [0, 2, 4, 5, 7, 9, 11], "minor": [0, 2, 3, 5, 7, 8, 10]}


def _hz(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def _env(n, a, r):
    import numpy as np
    e = np.ones(n)
    ai, ri = max(1, int(a * SR)), max(1, int(r * SR))
    e[:ai] = np.linspace(0, 1, ai)
    if ri < n:
        e[-ri:] *= np.linspace(1, 0, ri)
    return e


def _tone(freq, dur, kind="pad", bright=0.5):
    import numpy as np
    n = int(dur * SR)
    t = np.arange(n) / SR
    if kind == "pad":
        det = [0.996, 1.0, 1.004]
        w = sum(np.sin(2 * np.pi * freq * d * t) + bright * 0.5 * np.sin(4 * np.pi * freq * d * t) + bright * 0.25 * np.sin(6 * np.pi * freq * d * t) for d in det) / 3
        return w * _env(n, 0.35, 0.5)
    if kind == "bass":
        w = np.sin(2 * np.pi * freq * t) + 0.3 * np.sin(4 * np.pi * freq * t)
        return w * _env(n, 0.01, 0.08) * np.exp(-t * 1.5)
    if kind == "pluck":
        w = np.sin(2 * np.pi * freq * t) + 0.5 * np.sin(4 * np.pi * freq * t) * np.exp(-t * 6)
        return w * np.exp(-t * 4.5) * _env(n, 0.005, 0.05)
    return np.zeros(n)


def _drum(kind, n_rng):
    import numpy as np
    if kind == "kick":
        t = np.arange(int(0.35 * SR)) / SR
        return np.sin(2 * np.pi * (48 + 110 * np.exp(-t * 28)) * t) * np.exp(-t * 9)
    if kind == "snare":
        t = np.arange(int(0.25 * SR)) / SR
        return (0.35 * n_rng.standard_normal(len(t)) * np.exp(-t * 26) + 0.5 * np.sin(2 * np.pi * 190 * t) * np.exp(-t * 20)) * 0.6
    if kind == "hat":
        t = np.arange(int(0.06 * SR)) / SR
        x = n_rng.standard_normal(len(t))
        x = np.diff(np.concatenate([[0], x]))       # crude high-pass
        return x * np.exp(-t * 90) * 0.1
    return np.zeros(1)


def _place(buf, sig, at):
    i = int(at * SR)
    if i >= len(buf):
        return
    j = min(len(buf), i + len(sig))
    buf[i:j] += sig[: j - i]


def _reverb(x, mix=0.25):
    import numpy as np
    out = x.copy()
    for d, g in ((0.0297, 0.6), (0.0371, 0.55), (0.0411, 0.5), (0.0437, 0.45), (0.083, 0.35)):
        k = int(d * SR)
        y = np.zeros_like(x)
        y[k:] = x[:-k] * g
        for _ in range(3):
            y[k:] += y[:-k] * g * 0.5
        out += y * mix / 3
    return out


def make(mood: str, seconds: float = 64.0, seed: int = 7):
    import numpy as np
    bpm, root, prog, scale, drums, bright, swing, energy = MOODS[mood]
    rng = np.random.default_rng(seed)
    beat = 60.0 / bpm
    bar = beat * 4
    n = int(seconds * SR)
    pads, bass, lead, kit = (np.zeros(n) for _ in range(4))
    sc = SCALES[scale]

    def note(deg, octave=0):
        return root + sc[deg % 7] + 12 * (deg // 7 + octave)
    bars = int(seconds / bar) + 1
    for b in range(bars):
        deg = prog[b % len(prog)]
        t0 = b * bar
        for k in (0, 2, 4):
            _place(pads, _tone(_hz(note(deg + k)), bar * 1.05, "pad", bright) * 0.16, t0)
        pattern = [0, 2.5] if energy <= 2 else [0, 1.5, 2, 3.5] if energy >= 4 else [0, 2, 3]
        for p in pattern:
            _place(bass, _tone(_hz(note(deg, -1)), beat * 0.9, "bass") * 0.32, t0 + p * beat)
        if b % 2 == 1 or energy >= 4:
            for s in range(8):
                if rng.random() < (0.35 + energy * 0.06):
                    st = s * beat / 2 + (swing * beat / 2 if s % 2 else 0)
                    _place(lead, _tone(_hz(note(deg + int(rng.choice([0, 2, 4, 7, 9])), 1)), beat * 0.8, "pluck") * 0.09, t0 + st)
        for s in range(16 if drums in ("four", "pop", "trap") else 8):
            step = bar / (16 if drums in ("four", "pop", "trap") else 8)
            at = t0 + s * step + (swing * step if s % 2 else 0)
            if drums == "four":
                if s % 4 == 0: _place(kit, _drum("kick", rng) * 0.8, at)
                if s % 8 == 4: _place(kit, _drum("snare", rng) * 0.5, at)
                if s % 2 == 1: _place(kit, _drum("hat", rng), at)
            elif drums == "pop":
                if s in (0, 7, 8, 10): _place(kit, _drum("kick", rng) * 0.75, at)
                if s in (4, 12): _place(kit, _drum("snare", rng) * 0.55, at)
                if s % 2 == 0: _place(kit, _drum("hat", rng) * 0.9, at)
            elif drums == "trap":
                if s in (0, 6, 10): _place(kit, _drum("kick", rng) * 0.85, at)
                if s in (8,): _place(kit, _drum("snare", rng) * 0.6, at)
                _place(kit, _drum("hat", rng) * (0.6 if s % 2 else 0.9), at)
                if s in (13, 14, 15) and b % 2: _place(kit, _drum("hat", rng) * 0.5, at + step / 2)
            elif drums == "lofi":
                if s in (0, 5): _place(kit, _drum("kick", rng) * 0.6, at)
                if s in (2, 6): _place(kit, _drum("snare", rng) * 0.35, at)
                _place(kit, _drum("hat", rng) * 0.6, at)
            else:  # soft
                if s in (0,): _place(kit, _drum("kick", rng) * 0.4, at)
                if s % 2 == 1: _place(kit, _drum("hat", rng) * 0.35, at)
    mix_l = _reverb(pads * 1.25 + lead * 0.8, 0.35) + bass + kit
    mix_r = _reverb(pads * 1.2 + lead * 1.1, 0.4) + bass + kit * 0.95
    st = np.stack([mix_l, mix_r], axis=1)
    fade = int(1.5 * SR)
    st[:fade] *= np.linspace(0, 1, fade)[:, None]
    st[-fade:] *= np.linspace(1, 0, fade)[:, None]
    st /= max(1e-6, np.abs(st).max()) / 0.8
    return st.astype(np.float32)


def ensure(force: bool = False) -> int:
    import numpy as np
    import wave
    LIBRARY.mkdir(parents=True, exist_ok=True)
    made = 0
    for mood in MOODS:
        out = LIBRARY / f"{mood}.m4a"
        if out.exists() and not force:
            continue
        x = make(mood)
        tmp = LIBRARY / f"{mood}.wav"
        with wave.open(str(tmp), "wb") as w:
            w.setnchannels(2)
            w.setsampwidth(2)
            w.setframerate(SR)
            w.writeframes((x * 32767).astype(np.int16).tobytes())
        util.run([util.ffmpeg_bin(), "-y", "-hide_banner", "-i", str(tmp), "-af", "highpass=f=35,lowpass=f=8500,acompressor=threshold=0.25:ratio=2.5:attack=15:release=200,loudnorm=I=-18:TP=-2",
                  "-c:a", "aac", "-b:a", "160k", str(out)])
        tmp.unlink(missing_ok=True)
        made += 1
    if made:
        util.ok(f"Made {made} original music tracks")
    return made


def pick(mood_hint: str | None = None, bpm: float | None = None, energy: int | None = None) -> Path | None:
    """Choose a library track by mood name, tempo or energy."""
    ensure()
    tracks = {p.stem: p for p in LIBRARY.glob("*.m4a")}
    if not tracks:
        return None
    if mood_hint and mood_hint in tracks:
        return tracks[mood_hint]
    best, bd = None, 9e9
    for mood, (mbpm, *_rest) in MOODS.items():
        e = _rest[-1]
        d = (abs((bpm or mbpm) - mbpm) / 20) + (abs((energy or e) - e))
        if d < bd and mood in tracks:
            best, bd = mood, d
    return tracks.get(best)
