"""Word-synced captions: chunks of 1-3 words, the spoken word lit up, keywords in the accent colour."""
from __future__ import annotations

import re

from . import ass, textfit
from . import styles as st


def _clean(word: str) -> str:
    return re.sub(r"^[\"'“”‘’(\[]+|[\"'“”‘’)\],.;:!?]+$", "", word.strip()) or word.strip()


def chunk_words(words: list[dict], max_words: int, max_chars: int) -> list[list[dict]]:
    """Group words into caption chunks: never across a sentence end or a long pause, never too long to read."""
    chunks, cur = [], []
    for i, w in enumerate(words):
        if cur:
            prev = cur[-1]
            text = " ".join(_clean(x["w"]) for x in cur + [w])
            if (len(cur) >= max_words or len(text) > max_chars or w["start"] - prev["end"] > 0.45
                    or re.search(r"[.!?,]$", prev["w"].strip())):
                chunks.append(cur)
                cur = []
        cur.append(w)
    if cur:
        chunks.append(cur)
    return chunks


def is_keyword(word: str, keywords: set[str]) -> bool:
    core = _clean(word).lower()
    return bool(core) and (core in keywords or any(k in core for k in keywords if len(k) > 3)) or bool(re.search(r"\d", core))


def build(doc: ass.Doc, words: list[dict], style: dict, plat: dict, duration: float,
          keywords: list[str] | None = None, hide: list[tuple[float, float]] | None = None,
          overrides: dict | None = None) -> int:
    cap = dict(style["captions"])
    cap.update(overrides or {})
    if not cap.get("enabled", True) or not words:
        return 0
    W, H = plat["width"], plat["height"]
    font = st.resolve_font(style["fonts"]["caption"])
    colors = style["colors"]
    size = float(cap["size"]) * (W / 1080.0 if W < H else H / 1080.0 * 0.9)
    kw = {k.lower() for k in (keywords or [])}
    hide = hide or []

    # keep captions clear of the app UI at the bottom
    y = float(cap["y"]) if cap.get("exact_position") else min(float(cap["y"]), 1 - plat["safe"]["bottom"] - 0.03)
    cx = W * (0.5 - (plat["safe"]["right"] - plat["safe"]["left"]) / 2 * 0.6)
    max_w = W * (1 - plat["safe"]["left"] - plat["safe"]["right"] - 0.04)

    box = bool(cap.get("box"))
    doc.add_style("Cap", font, st.fs(font, size), primary=colors["text"], outline=cap.get("box_color", "#000000") if box else colors["outline"],
                  outline_w=(size * 0.22 if box else cap.get("outline", 5)), shadow=0 if box else cap.get("shadow", 2),
                  align=5, border_style=3 if box else 1, back="#000000", back_alpha=0.45, spacing=cap.get("spacing", 0))
    box_tag = ass.a(cap.get("box_alpha", 0.55), 3) if box else ""

    chunks = chunk_words(words, int(cap["max_words"]), int(cap["max_chars"]))
    upper = cap.get("uppercase", False)
    accent = colors["accent"]
    # accent words in their own font (e.g. white sans captions with a yellow italic serif keyword), as measured
    af = style["fonts"].get("accent")
    if af and af != style["fonts"]["caption"]:
        a_ = st.resolve_font(af)
        accent = accent + f"\\fn{a_['ass']}\\i{1 if a_.get('italic') else 0}"
        reset_font = f"\\fn{font['ass']}\\i0"
    else:
        reset_font = ""
    mode = cap.get("mode", "highlight")
    hl = cap.get("highlight", "both")
    count = 0

    def visible(t0, t1):
        for a, b in hide:
            if t0 < b and t1 > a:
                return False
        return True

    starts = []
    for ci, ch in enumerate(chunks):
        s0 = max(0.0, ch[0]["start"] - float(cap.get("lead_ms", 40)) / 1000)
        if ci > 0:
            s0 = max(s0, chunks[ci - 1][-1]["end"])
        starts.append(round(s0, 2))   # ASS works in 1/100 s; round once so events never overlap
    for ci, ch in enumerate(chunks):
        start = starts[ci]
        nxt = starts[ci + 1] if ci + 1 < len(chunks) else duration
        end = nxt if nxt - ch[-1]["end"] < 0.6 else min(nxt, ch[-1]["end"] + 0.25)
        end = min(end, duration)
        if not visible(start, end):
            continue
        tokens = [_clean(w["w"]) for w in ch]
        disp = [t.upper() if upper else t for t in tokens]
        line = " ".join(disp)
        fs = textfit.fit_size(line, font, size, max_w)
        scale = fs / size * 100
        lines_break = None
        if scale < 78 and len(disp) > 1:  # too long for one line: break into two instead of shrinking a lot
            scale = 100.0
            parts = textfit.balanced_wrap(line, font, size, max_w)
            if len(parts) == 2:
                lines_break = len(parts[0].split())
        px = W * float(cap["x"]) if cap.get("x") is not None else cx
        pos = f"\\an5\\pos({px:.0f},{H * y:.0f})"
        base = f"{{{pos}\\fscx{scale:.0f}\\fscy{scale:.0f}{box_tag}}}"
        pop_in = ""
        if cap.get("pop", True):
            pf, pk = float(cap.get("pop_from", 0.86)), float(cap.get("pop_peak", 1.03))
            t_in, t_settle = int(cap.get("pop_in_ms", 90)), int(cap.get("pop_settle_ms", 60))
            fade = f"\\alpha&HFF&\\t(0,{int(cap['fade_ms'])},\\alpha&H00&)" if cap.get("fade_ms") else ""
            pop_in = (f"{{{fade}\\fscx{scale * pf:.0f}\\fscy{scale * pf:.0f}\\t(0,{t_in},\\fscx{scale * pk:.0f}\\fscy{scale * pk:.0f})"
                      f"\\t({t_in},{t_in + t_settle},\\fscx{scale:.0f}\\fscy{scale:.0f})}}")

        def join(parts):
            out = ""
            for k, p in enumerate(parts):
                if k:
                    out += "\\N" if lines_break and k == lines_break else " "
                out += p
            return out

        if mode in ("pop", "plain"):
            parts = []
            for t, w in zip(disp, ch):
                if cap.get("keyword_accent", True) and is_keyword(w["w"], kw):
                    parts.append(f"{{{ass.c(colors['accent'])}{accent[len(colors['accent']):]}}}{ass.esc(t)}{{{ass.c(colors['text'])}{reset_font}}}")
                else:
                    parts.append(ass.esc(t))
            doc.dialogue(start, end, base + (pop_in if mode == "pop" else "") + join(parts), "Cap", layer=20)
            count += 1
            continue

        # highlight / reveal: one event per spoken word
        for k, w in enumerate(ch):
            t0 = start if k == 0 else max(start, round(w["start"], 2))
            t1 = max(t0, round(ch[k + 1]["start"], 2)) if k + 1 < len(ch) else end
            parts = []
            for j, (t, ww) in enumerate(zip(disp, ch)):
                e = ass.esc(t)
                if j == k:
                    tag = ""
                    if hl in ("color", "both"):
                        tag += ass.c(colors["accent"]) + accent[len(colors["accent"]):]
                    if hl in ("scale", "both"):
                        tag += f"\\fscx{scale * 1.08:.0f}\\fscy{scale * 1.08:.0f}"
                    parts.append(f"{{{tag}}}{e}{{{ass.c(colors['text'])}{reset_font}\\fscx{scale:.0f}\\fscy{scale:.0f}}}")
                elif mode == "reveal" and j > k:
                    parts.append(f"{{\\alpha&HFF&}}{e}{{\\alpha&H00&{box_tag}}}")
                elif cap.get("keyword_accent", True) and is_keyword(ww["w"], kw) and j < k:
                    parts.append(f"{{{ass.c(colors['accent'])}{accent[len(colors['accent']):]}}}{e}{{{ass.c(colors['text'])}{reset_font}}}")
                else:
                    parts.append(e)
            text = base + (pop_in if k == 0 else "") + join(parts)
            doc.dialogue(t0, t1, text, "Cap", layer=20)
            count += 1
    return count
