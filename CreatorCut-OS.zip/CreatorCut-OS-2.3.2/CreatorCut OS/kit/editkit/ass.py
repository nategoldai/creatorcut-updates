"""A tiny writer for ASS subtitle files (what FFmpeg's libass draws): styles, timed events, override tags."""
from __future__ import annotations


def _bgr(h: str) -> str:
    h = (h or "#000000").lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    r, g, b = h[0:2], h[2:4], h[4:6]
    return f"{b}{g}{r}".upper()


def _alpha_hex(opacity: float) -> str:
    return f"{int(round((1 - max(0.0, min(1.0, float(opacity)))) * 255)):02X}"


def ts(t: float) -> str:
    t = max(0.0, float(t))
    cs = int(round(t * 100))
    h, cs = divmod(cs, 360000)
    m, cs = divmod(cs, 6000)
    s, cs = divmod(cs, 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def esc(text: str) -> str:
    """Text safe for an ASS event (braces start override blocks; a backslash would start a tag)."""
    return str(text).replace("\\", "\u29f5").replace("{", "(").replace("}", ")").replace("\n", "\\N")


class Doc:
    def __init__(self, width: int, height: int):
        self.width, self.height = int(width), int(height)
        self.styles: list[str] = []
        self.events: list[tuple[float, int, str]] = []
        self._names: set[str] = set()

    def add_style(self, name: str, font: dict, size: float, primary: str = "#FFFFFF", outline: str = "#000000",
                  outline_w: float = 0, shadow: float = 0, align: int = 7, border_style: int = 1,
                  back: str = "#000000", back_alpha: float = 0.0, spacing: float = 0) -> None:
        bold = -1 if font.get("bold") else 0
        italic = -1 if font.get("italic") else 0
        if name in self._names:
            self.styles = [s for s in self.styles if not s.startswith(f"Style: {name},")]
        self._names.add(name)
        self.styles.append(
            "Style: {n},{f},{s:.0f},&H00{p},&H00{p},&H00{o},{b},{bo},{it},0,0,100,100,{sp},0,{bs},{ow},{sh},{al},0,0,0,1".format(
                n=name, f=font["ass"], s=size, p=_bgr(primary), o=_bgr(outline), b=f"&H{_alpha_hex(back_alpha)}{_bgr(back)}",
                bo=bold, it=italic, sp=spacing, bs=border_style, ow=round(float(outline_w), 2), sh=round(float(shadow), 2), al=align))

    def dialogue(self, start: float, end: float, text: str, style: str = "Default", layer: int = 0) -> None:
        if end - start < 0.01:
            return
        self.events.append((start, layer, f"Dialogue: {layer},{ts(start)},{ts(end)},{style},,0,0,0,,{text}"))

    def drawing(self, start: float, end: float, path: str, x: float, y: float, color: str, opacity: float = 1.0,
                layer: int = 0, style: str = "Default", extra: str = "") -> None:
        """A vector shape (ASS drawing commands like 'm 0 0 l 100 0 100 50 0 50') at x, y."""
        tags = f"{{\\an7\\pos({x:.1f},{y:.1f})\\bord0\\shad0{c(color)}{a(opacity)}{extra}\\p1}}"
        self.dialogue(start, end, tags + path + "{\\p0}", style, layer)

    def render(self) -> str:
        if "Default" not in self._names:
            self.styles.insert(0, "Style: Default,Inter,48,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1")
        head = ["[Script Info]", "ScriptType: v4.00+", f"PlayResX: {self.width}", f"PlayResY: {self.height}",
                "WrapStyle: 2", "ScaledBorderAndShadow: yes", "YCbCr Matrix: TV.709", "",
                "[V4+ Styles]",
                "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, "
                "Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, "
                "MarginV, Encoding"]
        ev = ["", "[Events]", "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text"]
        ev += [e[2] for e in sorted(self.events, key=lambda e: (e[0], e[1]))]
        return "\n".join(head + self.styles + ev) + "\n"


def c(h: str, n: int = 1) -> str:
    """Override tag for colour n (1 fill, 3 border, 4 shadow)."""
    return f"\\{n}c&H{_bgr(h)}&"


def a(opacity: float, n: int | None = None) -> str:
    """Override tag for opacity (all parts, or part n)."""
    return f"\\{n}a&H{_alpha_hex(opacity)}&" if n else f"\\alpha&H{_alpha_hex(opacity)}&"


def rrect(w: float, h: float, r: float) -> str:
    """ASS drawing path of a rounded rectangle with its top-left at 0,0."""
    r = max(0.0, min(r, w / 2, h / 2))
    k = r * 0.4477
    return (f"m {r:.1f} 0 l {w - r:.1f} 0 b {w - k:.1f} 0 {w:.1f} {k:.1f} {w:.1f} {r:.1f} l {w:.1f} {h - r:.1f} "
            f"b {w:.1f} {h - k:.1f} {w - k:.1f} {h:.1f} {w - r:.1f} {h:.1f} l {r:.1f} {h:.1f} b {k:.1f} {h:.1f} 0 {h - k:.1f} 0 {h - r:.1f} "
            f"l 0 {r:.1f} b 0 {k:.1f} {k:.1f} 0 {r:.1f} 0")


rounded_rect = rrect
