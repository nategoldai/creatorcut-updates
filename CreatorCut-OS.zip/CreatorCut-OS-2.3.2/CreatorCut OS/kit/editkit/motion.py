"""The motion graphics engine: HyperFrames (HTML + GSAP) and Remotion (React), installed privately by the installer
into kit/bin/node and kit/render. Every call goes through the wrappers in kit/bin, which point at the private Node,
FFmpeg and headless browser, so nothing depends on what's installed on the computer."""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from . import util

RENDER = util.KIT / "render"
NODE_DIR = util.BIN / "node"
WIN = sys.platform.startswith("win")


def _tool(name: str) -> Path:
    return util.BIN / (f"{name}.cmd" if WIN else name)


def chrome() -> Path | None:
    hits = sorted(RENDER.glob("node_modules/.remotion/chrome-headless-shell/*/chrome-headless-shell-*/chrome-headless-shell*"))
    return next((h for h in hits if h.is_file()), None)


def status() -> dict:
    node = NODE_DIR / ("node.exe" if WIN else "bin/node")
    parts = {"node": node.exists(), "hyperframes": (RENDER / "node_modules" / "hyperframes").exists(),
             "remotion": (RENDER / "node_modules" / "remotion").exists(), "browser": chrome() is not None,
             "skills": (util.ROOT / ".claude" / "skills" / "hyperframes" / "SKILL.md").exists()}
    missing = [k for k, v in parts.items() if not v]
    return {"ready": not missing, "detail": "ready" if not missing else "missing: " + ", ".join(missing), "parts": parts}


def vision_ready() -> bool:
    try:
        if sys.platform == "darwin":
            import ocrmac  # noqa: F401
            import Vision  # noqa: F401
        else:
            import rapidocr_onnxruntime  # noqa: F401
        return True
    except Exception:
        return False


def run(tool: str, args: list[str], cwd: Path, timeout: int = 3600, progress=None) -> subprocess.CompletedProcess:
    """Run hyperframes / remotion through the private wrapper. Fails in plain words if it isn't installed."""
    exe = _tool(tool)
    if not exe.exists():
        raise util.Fail("The motion graphics engine isn't installed yet.", "Run setup again (it only adds what's missing).")
    env = dict(os.environ, HYPERFRAMES_SKIP_SKILLS="1", DO_NOT_TRACK="1")
    proc = util.spawn([str(exe), *args], cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                      text=True, encoding="utf-8", errors="replace", env=env)
    out = []
    for line in util.progress_lines(proc, timeout=timeout, idle_timeout=min(timeout, 600)):
        out.append(line)
        if progress is not None:
            progress(line.rstrip())
    return subprocess.CompletedProcess(proc.args, proc.returncode, "".join(out), "")
