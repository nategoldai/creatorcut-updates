"""Shared helpers: paths, running commands, probing media, JSON io, friendly output."""
from __future__ import annotations

import json
import os
import platform
import re
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]          # the toolkit folder
KIT = ROOT / "kit"
STYLES_DIR = KIT / "styles"
BRAND = ROOT / "my-brand"
USER_STYLES_DIR = BRAND / "styles"                    # styles the user teaches / customises
FONTS_DIR = KIT / "fonts"
SFX_DIR = KIT / "sfx"
DOCS_DIR = KIT / "docs"
PROJECTS = KIT / "projects"
RAW = ROOT / "my-videos" / "raw"
FINISHED = ROOT / "my-videos" / "finished"
MUSIC = BRAND / "music"
REFERENCES = BRAND / "references"
STUDIO_OUT = KIT / "studio-out"
STUDIO_PAGE = ROOT / "Studio.html"
PROFILE = BRAND / "profile.json"
BIN = KIT / "bin"                                       # portable FFmpeg + uv, installed by kit/setup/install.*

VIDEO_EXT = {".mp4", ".mov", ".m4v", ".mkv", ".webm", ".avi", ".mts"}
IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp", ".heic"}
AUDIO_EXT = {".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg"}


# ---------------------------------------------------------------- output ----
class Fail(Exception):
    """An error with a plain-language explanation and a suggested fix."""

    def __init__(self, message: str, fix: str = ""):
        super().__init__(message)
        self.message = message
        self.fix = fix


def say(msg: str = "") -> None:
    print(msg, flush=True)


def step(msg: str) -> None:
    print(f"• {msg}", flush=True)


def ok(msg: str) -> None:
    print(f"✓ {msg}", flush=True)


def warn(msg: str) -> None:
    print(f"! {msg}", flush=True)


def log(msg: str) -> None:
    """Technical details go to kit/studio-out/server.log, never to the creator."""
    try:
        STUDIO_OUT.mkdir(parents=True, exist_ok=True)
        with (STUDIO_OUT / "server.log").open("a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + msg.rstrip() + "\n")
    except OSError:
        pass


def log_exception(where: str) -> None:
    import traceback
    log(f"{where}:\n{traceback.format_exc()}")


# ------------------------------------------------------------------ json ----
def read_json(path: Path, default=None):
    path = Path(path)
    if not path.exists():
        if default is not None:
            return default
        raise Fail(f"Missing file: {rel(path)}")
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise Fail(f"{rel(path)} is not valid JSON (line {e.lineno}): {e.msg}",
                   "Fix the JSON syntax (a missing comma or quote is the usual cause) and run the command again.")


def write_json(path: Path, data) -> None:
    """Atomic write: readers (the Studio server, other threads) never see a half-written file."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.{threading.get_ident()}.tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    for attempt in range(5):
        try:
            os.replace(tmp, path)
            return
        except PermissionError:   # Windows: the target is briefly open in another process
            time.sleep(0.05 * (attempt + 1))
    os.replace(tmp, path)


def rel(path) -> str:
    try:
        return str(Path(path).resolve().relative_to(ROOT))
    except Exception:
        return str(path)


def slugify(text: str) -> str:
    s = re.sub(r"[^a-zA-Z0-9]+", "-", text).strip("-").lower()
    return s[:48] or "video"


# --------------------------------------------------------------- system ----
def os_name() -> str:
    s = platform.system()
    return {"Darwin": "mac", "Windows": "windows"}.get(s, "linux")


def which(name: str) -> str | None:
    own = BIN / (name + (".exe" if os_name() == "windows" else ""))
    if own.exists():
        return str(own)
    found = shutil.which(name)
    if found:
        return found
    # common install spots that may not be on PATH inside an app-launched shell
    candidates = []
    if os_name() == "mac":
        candidates = [f"/opt/homebrew/bin/{name}", f"/usr/local/bin/{name}",
                      f"/opt/homebrew/opt/ffmpeg-full/bin/{name}", f"/usr/local/opt/ffmpeg-full/bin/{name}"]
    elif os_name() == "windows":
        local = os.environ.get("LOCALAPPDATA", "")
        candidates = [os.path.join(local, "Microsoft", "WinGet", "Links", name + ".exe")]
    for c in candidates:
        if c and os.path.exists(c):
            return c
    return None


def ffmpeg_bin() -> str:
    own = BIN / ("ffmpeg.exe" if os_name() == "windows" else "ffmpeg")
    if own.exists():
        return str(own)
    # ffmpeg-full on mac is keg-only, so prefer it when present
    for c in ["/opt/homebrew/opt/ffmpeg-full/bin/ffmpeg", "/usr/local/opt/ffmpeg-full/bin/ffmpeg"]:
        if os.path.exists(c):
            return c
    p = which("ffmpeg")
    if not p:
        raise Fail("FFmpeg isn't installed yet.", "Run the setup skill: it installs everything automatically.")
    return p


def ffprobe_bin() -> str:
    own = BIN / ("ffprobe.exe" if os_name() == "windows" else "ffprobe")
    if own.exists():
        return str(own)
    for c in ["/opt/homebrew/opt/ffmpeg-full/bin/ffprobe", "/usr/local/opt/ffmpeg-full/bin/ffprobe"]:
        if os.path.exists(c):
            return c
    p = which("ffprobe")
    if not p:
        raise Fail("ffprobe isn't installed yet (it comes with FFmpeg).", "Run /setup and Claude will install it for you.")
    return p


def run(cmd: list[str], quiet: bool = True, check: bool = True, label: str = "", cwd=None, timeout: float = 3600) -> subprocess.CompletedProcess:
    """Run a command; on failure raise a Fail with the useful tail of the error output. The direct child command has a timeout;
    timeout failures are reported for recovery. Progress-runner process groups have separate cleanup."""
    t0 = time.time()
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace",
                              cwd=str(cwd) if cwd else None, timeout=timeout)
    except subprocess.TimeoutExpired:
        raise Fail(f"{label or Path(cmd[0]).name} took more than {int(timeout // 60)} minutes and was stopped.",
                   "Try the step again. If it happens again, the file may be damaged: export it again from the phone.")
    if check and proc.returncode != 0:
        tail = "\n".join((proc.stderr or proc.stdout or "").strip().splitlines()[-12:])
        raise Fail(f"{label or Path(cmd[0]).name} failed:\n{tail}",
                   "Read the last lines above. If it mentions a missing file or font, run `edit.py doctor`.")
    if not quiet:
        say(proc.stdout)
    if label:
        ok(f"{label} ({time.time() - t0:.1f}s)")
    return proc


def activity(detail: str = "", percent: float | None = None) -> None:
    """Update what the engine is doing right now (shown live in the Studio): a short line about the real work
    and, when known, the percentage of the current step."""
    f = STUDIO_OUT / "activity.json"
    try:
        a = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    except Exception:
        a = {}
    if detail:
        a["detail"] = detail[:120]
        log_ = a.setdefault("log", [])
        if not log_ or log_[-1] != a["detail"]:
            log_.append(a["detail"])
            a["log"] = log_[-12:]
    if percent is not None:
        a["percent"] = round(max(0.0, min(100.0, percent)), 1)
    a["updated"] = time.time()
    try:
        tmp = f.with_name(".activity.tmp")
        tmp.write_text(json.dumps(a), encoding="utf-8")
        os.replace(tmp, f)
    except OSError:
        pass



def process_group_options() -> dict:
    return {"start_new_session": True} if os.name != "nt" else {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP}


def spawn(cmd, **kwargs):
    kwargs.setdefault("stdin", subprocess.DEVNULL)
    kwargs.update(process_group_options())
    proc = subprocess.Popen(cmd, **kwargs)
    proc._creatorcut_isolated = os.name != "nt"
    return proc


def stop_process(proc) -> None:
    """Stop an owned worker and, on POSIX, its isolated renderer/browser descendants."""
    import signal
    isolated = bool(getattr(proc, "_creatorcut_isolated", False))
    if os.name != "nt":
        try: isolated = isolated or os.getpgid(proc.pid) == proc.pid
        except ProcessLookupError: pass
    def stop(sig):
        if isolated:
            try: os.killpg(proc.pid, sig)
            except ProcessLookupError: pass
        elif proc.poll() is None:
            proc.terminate() if sig == signal.SIGTERM else proc.kill()
    if proc.poll() is None or isolated:
        stop(signal.SIGTERM)
        try: proc.wait(timeout=3)
        except subprocess.TimeoutExpired: stop(getattr(signal, "SIGKILL", 9)); proc.wait(timeout=3)
        # The parent can exit while browser grandchildren are still alive.
        if isolated: stop(getattr(signal, "SIGKILL", 9))


def progress_lines(proc, timeout=3600, idle_timeout=300):
    """Read a child without an unbounded pipe wait. No-output deadline is diagnostic."""
    import queue
    q = queue.Queue()
    def read():
        try:
            for line in proc.stdout:
                q.put(line)
        finally:
            q.put(None)
    reader = threading.Thread(target=read, daemon=True)
    reader.start()
    started = last = time.monotonic()
    finished = False
    try:
        while True:
            now = time.monotonic()
            if now-started > timeout or now-last > idle_timeout:
                raise Fail("This step stopped reporting progress and was stopped safely.",
                           "Inspect its log, fix the cause, then retry the interrupted step. Existing files are kept.")
            try:
                line = q.get(timeout=min(.5, max(.01, idle_timeout/4)))
            except queue.Empty:
                continue
            if line is None:
                break
            last = time.monotonic()
            yield line
        remaining = max(.01, min(timeout-(time.monotonic()-started), idle_timeout-(time.monotonic()-last)))
        try:
            proc.wait(timeout=remaining)
            finished = True
        except subprocess.TimeoutExpired:
            raise Fail("This step exceeded its time limit.", "Inspect its log and retry the step.")
    finally:
        if not finished:
            stop_process(proc)
        reader.join(timeout=1)
        if proc.stdout and not reader.is_alive():
            proc.stdout.close()

def run_progress(cmd: list[str], total: float, label: str = "", cwd=None, detail: str = "", timeout=3600, idle_timeout=300) -> None:
    """Run FFmpeg and report real progress (from -progress) to the Studio."""
    full = cmd[:1] + ["-progress", "pipe:1", "-nostats"] + cmd[1:]
    proc = spawn(full, cwd=str(cwd) if cwd else None, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            text=True, encoding="utf-8", errors="replace")
    err: list[str] = []
    import threading as _th
    def _drain():
        for line in proc.stderr:  # type: ignore[union-attr]
            err.append(line)
            del err[:-40]
    t = _th.Thread(target=_drain, daemon=True)
    t.start()
    t0, last = time.time(), -1.0
    frame = 0
    for line in progress_lines(proc, timeout, idle_timeout):
        k, _, v = line.strip().partition("=")
        if k == "frame":
            frame = int(v or 0)
        if k in ("out_time_us", "out_time_ms") and v.isdigit() and total > 0:
            pct = int(v) / 1e6 / total * 100
            if pct - last >= 1:
                last = pct
                activity(f"{detail} · frame {frame}" if detail else "", pct)
    proc.wait()
    t.join(timeout=2)
    if proc.returncode != 0:
        tail = "\n".join("".join(err).strip().splitlines()[-12:])
        raise Fail(f"{label or Path(cmd[0]).name} failed:\n{tail}",
                   "Read the last lines above. If it mentions a missing file or font, run `edit.py doctor`.")
    activity("", 100)
    if label:
        ok(f"{label} ({time.time() - t0:.1f}s)")


def ffmpeg_major() -> int:
    out = run([ffmpeg_bin(), "-hide_banner", "-version"]).stdout
    m = re.search(r"ffmpeg version n?(\d+)", out)
    if m:
        return int(m.group(1))
    return 7 if re.search(r"ffmpeg version N-", out) else 6   # git builds are recent


def filter_script_args(script_path: Path) -> list[str]:
    """Pass a long filter graph from a file (avoids command-length limits on Windows)."""
    if ffmpeg_major() >= 7:
        return ["-/filter_complex", str(script_path)]
    return ["-filter_complex_script", str(script_path)]


def ffmpeg_has_filter(name: str) -> bool:
    out = run([ffmpeg_bin(), "-hide_banner", "-filters"], check=False).stdout
    return re.search(rf"^\s*\S+\s+{re.escape(name)}\s", out, re.M) is not None


# ---------------------------------------------------------------- media ----
def probe(path: Path, timeout: float = 20) -> dict:
    """Duration, display size (rotation applied), fps, HDR flag and audio presence."""
    path = Path(path)
    if not path.exists():
        raise Fail(f"Can't find the video: {rel(path)}")
    out = run([ffprobe_bin(), "-v", "error", "-print_format", "json", "-show_format", "-show_streams", str(path)],
              label="", timeout=timeout).stdout
    data = json.loads(out)
    v = next((s for s in data["streams"] if s.get("codec_type") == "video"), None)
    a = next((s for s in data["streams"] if s.get("codec_type") == "audio"), None)
    if v is None:
        raise Fail(f"{path.name} has no video track.")
    w, h = int(v.get("width", 0)), int(v.get("height", 0))
    rot = 0
    for sd in v.get("side_data_list", []) or []:
        if "rotation" in sd:
            rot = int(float(sd["rotation"]))
    if "rotate" in (v.get("tags") or {}):
        rot = int(v["tags"]["rotate"])
    if abs(rot) % 180 == 90:
        w, h = h, w
    fr = v.get("avg_frame_rate") or v.get("r_frame_rate") or "30/1"
    try:
        num, den = fr.split("/")
        fps = float(num) / float(den) if float(den) else 30.0
    except Exception:
        fps = 30.0
    dur = float(data["format"].get("duration") or v.get("duration") or 0)
    transfer = (v.get("color_transfer") or "").lower()
    hdr = transfer in ("arib-std-b67", "smpte2084")
    return {"path": str(path), "duration": dur, "width": w, "height": h, "fps": round(fps, 3),
            "has_audio": a is not None, "hdr": hdr, "transfer": transfer,
            "codec": v.get("codec_name"), "pix_fmt": v.get("pix_fmt")}


def fmt_time(t: float) -> str:
    t = max(0.0, t)
    m, s = divmod(t, 60)
    return f"{int(m)}:{s:04.1f}"


def newest_raw_video() -> Path | None:
    vids = [p for p in RAW.glob("*") if p.suffix.lower() in VIDEO_EXT]
    return max(vids, key=lambda p: p.stat().st_mtime) if vids else None


def load_profile() -> dict:
    return read_json(PROFILE, default={})


PROFILE_LOCK = threading.RLock()


def save_profile(p: dict) -> None:
    write_json(PROFILE, p)


def update_profile(fn) -> dict:
    """Read-modify-write the profile under a lock (the Studio server saves from several threads)."""
    with PROFILE_LOCK, file_guard(PROFILE.parent / '.profile.guard', 'Your settings are saving another change.', timeout=5):
        prof = load_profile()
        fn(prof)
        save_profile(prof)
        return prof


def project_dir(name: str) -> Path:
    if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_-]{0,80}', name or ''):
        raise Fail('Invalid project name.')
    PROJECTS.mkdir(parents=True, exist_ok=True)
    d = PROJECTS / name
    if not d.exists():
        existing = ", ".join(sorted(p.name for p in PROJECTS.iterdir() if p.is_dir() and not p.name.startswith("_"))) or "none yet"
        raise Fail(f"There's no project called '{name}'.", f"Projects: {existing}. Start one with `edit.py new`.")
    return d


def latest_project() -> str | None:
    PROJECTS.mkdir(parents=True, exist_ok=True)
    dirs = [p for p in PROJECTS.iterdir() if p.is_dir() and not p.name.startswith("_") and (p / "project.json").exists()]
    if not dirs:
        return None
    return max(dirs, key=lambda p: (p / "project.json").stat().st_mtime).name


from contextlib import contextmanager

@contextmanager
def file_guard(path: Path, message='This operation is already running.', timeout=0):
    """Kernel lock: a process crash releases ownership without stale PID files.

    Keep the inode after unlocking, so other processes cannot lock a different
    file under the same path. An existing guard file is not an active lock.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    stream = path.open('a+b')
    acquired = False
    try:
        deadline = time.monotonic() + max(0, float(timeout))
        while not acquired:
            try:
                if os.name == 'nt':
                    import msvcrt
                    if stream.seek(0, os.SEEK_END) == 0:
                        stream.write(b'\0');stream.flush()
                    stream.seek(0)
                    msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                acquired = True
            except OSError as error:
                if time.monotonic() >= deadline:
                    raise Fail(message, 'Wait for that operation to finish, then try again.') from error
                time.sleep(min(.02, max(0, deadline-time.monotonic())))
        yield
    finally:
        try:
            if acquired:
                if os.name == 'nt':
                    import msvcrt
                    stream.seek(0);msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
        finally:
            stream.close()


@contextmanager
def project_lock(project: Path):
    """One candidate writer across processes, with automatic crash recovery."""
    with file_guard(project / '.render.guard', 'This project is already rendering.'):
        legacy = project / '.render.lock'
        if legacy.exists():
            try:
                old = json.loads(legacy.read_text())
                pid = int(old.get('pid') or 0)
            except (OSError, ValueError, TypeError, AttributeError):
                pid = 0
            alive = False
            if pid > 0:
                try:
                    os.kill(pid, 0);alive = True
                except ProcessLookupError:
                    pass
                except OSError:
                    alive = True
            if alive or (pid == 0 and 0 <= time.time() - legacy.stat().st_mtime < 5):
                raise Fail('This project is already rendering.', 'Wait for that render before starting another.')
            legacy.unlink(missing_ok=True)
        yield
