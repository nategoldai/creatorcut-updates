"""Studio helpers: style preview thumbnails, posters, and kit/studio-out/data.js (the offline snapshot that
Studio.html shows when the Studio server isn't running). The live app is served by server.py."""
from __future__ import annotations

import datetime as dt
import json
import os
import shutil
from pathlib import Path

from . import ass, captions, graphics, platforms, setup, styles as st, util

COMMANDS = [
    ("setup", "Set up or repair", "Installs everything automatically and builds this Studio. Run it again any time something is missing."),
    ("edit", "Edit a video", "Raw clip in, finished video out: cuts, captions, graphics, colour, sound. Shows you a preview first."),
    ("hook", "Fix my hook", "Rates your first 3 seconds and writes stronger opening lines and on-screen hook text."),
    ("style", "Change the look", "Switch to any style, or see your clip in all of them side by side."),
    ("teach", "Teach a new style", "Learns the look of creators you love from screenshots or clips and saves it as your own style."),
    ("captions", "Captions", "Change caption size, colour, position, words per line, or fix a misheard word."),
    ("graphics", "Graphics", "Add or change lists, counters, charts, screenshots, quotes, stickers and call-to-actions."),
    ("look", "Colour & music", "Colour grade, music under your voice, sound effects, zoom energy."),
    ("cut", "Tighten the cut", "Remove a sentence, keep a take, make it shorter or faster."),
    ("retention", "Retention check", "Finds moments where viewers might scroll away and fixes them."),
    ("fix", "Fix something", "Describe what looks wrong in plain words; it finds the cause and fixes only that."),
    ("post", "Post kit", "Caption, hashtags, title ideas and a cover image, ready to copy."),
    ("versions", "Every platform", "Make TikTok, Reels, Shorts and YouTube versions in one go."),
    ("shorts", "Long video to Shorts", "Finds the best 3-5 moments in a long video and edits each one."),
    ("compare", "Before & after", "A side-by-side video of your raw clip and the edit, ready to post."),
    ("batch", "Edit everything", "Edits every new clip in my-videos/raw while you do something else."),
    ("studio", "Refresh Studio", "Rebuilds this page with your latest videos."),
    ("stuck", "I am stuck", "Answers questions and solves install problems step by step."),
]

PHRASES = {
    "Cuts & pacing": [
        "Make it faster, cut every pause", "Keep my second take of the intro instead", "Cut the sentence about pricing",
        "Get it under 45 seconds", "Start straight on my first word", "Leave a beat before the big reveal",
    ],
    "Captions": [
        "Make the captions bigger", "Move captions higher, they cover my chin", "One word at a time",
        "Captions in my brand yellow", "Fix the spelling of my name in the captions", "Turn captions off for the first second",
        "Use boxed captions like a tutorial", "Highlight every number",
    ],
    "Graphics": [
        "Add a counter when I say 10 hours", "Show my 3 tips as a list that builds", "Put my analytics screenshot on screen when I mention views",
        "Add a big hook title for the first 2 seconds", "Fewer graphics, keep it clean", "Add a comment-for-the-guide button at the end",
        "Make a before/after comparison card", "Show a quote card with what my client said",
    ],
    "Look & sound": [
        "Warmer, more cinematic colours", "More energy, punch in on every cut", "No zooms", "Add music, quiet under my voice",
        "Turn the sound effects down", "Black and white for the story part", "Make it feel more premium",
    ],
    "Finish & post": [
        "Render the final version", "Make a TikTok and a YouTube Shorts version", "Write my caption and hashtags",
        "Make a cover with the text 'AI edits my videos'", "Make a before/after video", "Edit everything in my raw folder",
    ],
}


def _rel_from_studio(p: Path) -> str:
    """Paths in the dashboard are relative to the toolkit folder, where Studio.html lives."""
    return os.path.relpath(Path(p).resolve(), util.ROOT.resolve()).replace("\\", "/")


def style_thumb(style_id: str, background: Path, out: Path) -> None:
    style = st.load(style_id, apply_brand=False)
    plat = platforms.get("tiktok")
    work = util.PROJECTS / "_thumbs" / style_id
    work.mkdir(parents=True, exist_ok=True)
    doc = ass.Doc(plat["width"], plat["height"])
    words = [{"w": w, "start": 0.4 + i * 0.35, "end": 0.4 + i * 0.35 + 0.3} for i, w in enumerate("Your edits just got better".split())]
    title = {"type": "title", "text": "3 edits that save hours", "at": 0.0, "duration": 4}
    graphics.build(doc, [title], words, 4.0, style, plat, work)
    captions.build(doc, words, style, plat, 4.0)
    (work / "thumb.ass").write_text(doc.render(), encoding="utf-8")
    fonts_rel = os.path.relpath(util.FONTS_DIR, work).replace("\\", "/")
    bg_rel = os.path.relpath(background.resolve(), work.resolve()).replace("\\", "/")
    from . import look
    grade = style["grade_filter"] if style.get("grade") == "custom" and style.get("grade_filter") else look.grade_filter(style.get("grade", "natural"))
    vf = f"scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,{grade + ',' if grade else ''}ass=thumb.ass:fontsdir={fonts_rel},scale=540:960"
    util.run([util.ffmpeg_bin(), "-y", "-hide_banner", "-loop", "1", "-framerate", "30", "-t", "1.2", "-i", bg_rel,
              "-vf", vf, "-ss", "0.95", "-frames:v", "1", "-q:v", "3", "thumb.jpg"], cwd=work)
    out.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(work / "thumb.jpg", out)


def make_poster(video: Path, poster: Path) -> None:
    """A still from the video for the Library grid."""
    poster.parent.mkdir(parents=True, exist_ok=True)
    try:
        d = util.probe(video)["duration"]
        util.run([util.ffmpeg_bin(), "-y", "-hide_banner", "-ss", f"{min(1.5, d / 3):.2f}", "-i", str(video),
                  "-frames:v", "1", "-vf", "scale=540:-2", "-q:v", "3", str(poster)])
    except util.Fail:
        pass


def _background() -> Path:
    """Use a frame of the creator's own latest video so every style preview shows *them*."""
    latest = util.latest_project()
    if latest and (util.PROJECTS / latest / "cut.mp4").exists():
        fr = util.STUDIO_OUT / "assets" / "your-frame.jpg"
        fr.parent.mkdir(parents=True, exist_ok=True)
        try:
            dur = util.probe(util.PROJECTS / latest / "cut.mp4")["duration"]
            util.run([util.ffmpeg_bin(), "-y", "-hide_banner", "-ss", f"{min(2.0, dur / 3):.2f}", "-i",
                      str(util.PROJECTS / latest / "cut.mp4"), "-frames:v", "1", "-q:v", "2", str(fr)])
            return fr
        except util.Fail:
            pass
    return util.KIT / "samples" / "sample-frame.jpg"


def _font_files(key: str) -> list[str]:
    """The style's caption font and its built-in fallback, for the live CSS previews in the Studio."""
    files, seen, k = [], set(), key
    while k and k not in seen and k in st.FONTS:
        seen.add(k)
        files.append("kit/fonts/" + st.FONTS[k]["file"])
        k = st.FONTS[k].get("fallback")
    return files


def style_row(s: dict) -> dict:
    full = st.load(s["id"], apply_brand=False)
    cap = full.get("captions", {})
    return {"id": s["id"], "name": s["name"], "tagline": s["tagline"], "best_for": s["best_for"],
            "energy": s["energy"], "origin": s["origin"], "accent": full["colors"]["accent"],
            "preview": {"fonts": _font_files(full["fonts"]["caption"]), "heading_fonts": _font_files(full["fonts"]["heading"]),
                        "font": full["fonts"]["caption"], "heading": full["fonts"]["heading"],
                        "upper": bool(cap.get("uppercase")), "size": cap.get("size", 84), "mode": cap.get("mode", "highlight"),
                        "max_words": cap.get("max_words", 3), "outline_w": cap.get("outline", 5),
                        "text": full["colors"].get("text", "#FFFFFF"), "accent": full["colors"]["accent"],
                        "outline": full["colors"].get("outline", "#000000"), "box": cap.get("mode") == "box" or bool(cap.get("box")),
                        "box_color": cap.get("box_color", "#000000"),
                        "card": full["colors"].get("card", "#111111"), "card_text": full["colors"].get("card_text", "#FFFFFF"),
                        "y": cap.get("y", 0.62), "title_style": full.get("graphics", {}).get("title_style", "card"),
                        "title_case": full.get("graphics", {}).get("title_case", "none"), "grade": full.get("grade", "natural"),
                        "tilt": full.get("graphics", {}).get("tilt", 0)},
            "thumb": ""}


def starter() -> Path:
    """kit/studio/starter-data.js: what Studio.html shows before anything is installed."""
    data = {"generated": "", "starter": True,
            "profile": {"name": "", "handle": "", "platform": "", "platform_label": "", "style": "", "accent": "",
                        "agent": "claude", "cta": ""},
            "styles": [style_row(s) for s in st.list_styles() if s["origin"] == "toolkit"],
            "videos": [], "projects": [], "raw_waiting": [],
            "commands": [{"id": c, "title": t, "desc": d} for c, t, d in COMMANDS], "phrases": PHRASES,
            "checks": {"ready": False, "checks": []}}
    out = util.KIT / "studio" / "starter-data.js"
    out.write_text("window.STUDIO = " + json.dumps(data, ensure_ascii=False, indent=1) + ";\n", encoding="utf-8")
    return out


def build(thumbs: bool = False, quiet: bool = False) -> Path:
    out_dir = util.STUDIO_OUT
    out_dir.mkdir(parents=True, exist_ok=True)
    prof = util.load_profile()
    # styles + previews
    bg = None
    style_rows = []
    for s in st.list_styles():
        thumb = out_dir / "assets" / "styles" / f"{s['id']}.jpg"
        if thumbs or not thumb.exists():
            bg = bg or _background()
            try:
                style_thumb(s["id"], bg, thumb)
            except util.Fail as e:
                util.warn(f"No preview for {s['id']}: {e.message}")
        row = style_row(s)
        row["thumb"] = _rel_from_studio(thumb) if thumb.exists() else ""
        style_rows.append(row)
    # videos
    videos = []
    for f in sorted(util.FINISHED.glob("*.mp4"), key=lambda p: p.stat().st_mtime, reverse=True):
        stem_post = next((p for p in util.FINISHED.glob("*-post.json") if f.stem.startswith(p.stem[:-5])), None)
        cover = next((p for p in util.FINISHED.glob("*-cover.jpg") if f.stem.startswith(p.stem[:-6])), None)
        pdata = util.read_json(stem_post) if stem_post else None
        poster = util.STUDIO_OUT / "assets" / "posters" / f"{f.stem}.jpg"
        if not poster.exists() or poster.stat().st_mtime < f.stat().st_mtime:
            make_poster(f, poster)
        videos.append({"file": _rel_from_studio(f), "name": f.stem, "kind": "tour" if "style-tour" in f.stem else
                       "compare" if "before-after" in f.stem else "edit",
                       "date": dt.datetime.fromtimestamp(f.stat().st_mtime).strftime("%d %b, %H:%M"),
                       "size_mb": round(f.stat().st_size / 1e6, 1), "post": pdata,
                       "cover": _rel_from_studio(cover) if cover else (_rel_from_studio(poster) if poster.exists() else "")})
    # projects
    projects = []
    for d in sorted(util.PROJECTS.glob("*/project.json"), key=lambda p: p.stat().st_mtime, reverse=True):
        if d.parent.name.startswith("_"):
            continue
        c = util.read_json(d)
        projects.append({"name": d.parent.name, "status": c.get("status"), "style": c.get("style"), "platform": c.get("platform")})
    raw = [p.name for p in util.RAW.glob("*") if p.suffix.lower() in util.VIDEO_EXT]
    edited_sources = {util.read_json(d).get("source") for d in util.PROJECTS.glob("*/project.json")}
    checks = setup.doctor()
    data = {
        "generated": dt.datetime.now().strftime("%d %b %Y, %H:%M"),
        "profile": {"name": prof.get("name", ""), "handle": prof.get("handle", ""), "platform": prof.get("platform", ""),
                    "platform_label": platforms.get(prof.get("platform", "tiktok"))["label"] if prof.get("platform") else "",
                    "style": prof.get("style", ""), "accent": prof.get("brand", {}).get("accent", ""),
                    "agent": prof.get("agent", "claude"), "cta": prof.get("cta", "")},
        "styles": style_rows, "videos": videos, "projects": projects,
        "raw_waiting": [r for r in raw if r not in edited_sources],
        "commands": [{"id": c, "title": t, "desc": d} for c, t, d in COMMANDS],
        "phrases": PHRASES,
        "checks": checks,
    }
    (out_dir / "data.js").write_text("window.STUDIO = " + json.dumps(data, ensure_ascii=False, indent=1) + ";\n", encoding="utf-8")
    if not quiet:
        util.ok(f"Studio built with {len(style_rows)} styles and {len(videos)} videos")
    return util.STUDIO_PAGE
