"""A rendezvous with an active tool in the current conversation.

No inference, persistent queue, subprocess editor, or simulated replies. An action
is accepted only while a real foreground tool is waiting to receive it. Delivery
and an editor claiming a project are deliberately different acknowledgements.
"""
from __future__ import annotations

import secrets
import json
import os
import tempfile
import threading
import time
from collections import OrderedDict

from . import util


class Rendezvous:
    def __init__(self):
        self.condition = threading.Condition()
        self.receiver = None
        self.action = None
        self.receipts = OrderedDict()

    def status(self):
        with self.condition:
            return {"available": bool(self.receiver and self.receiver[1] > time.monotonic() and self.action is None),
                    "transport": "foreground_native_tool"}

    def receive(self, receiver: str, timeout: float = 25):
        if not receiver or len(receiver) > 160:
            raise util.Fail("A conversation-bound receiver is required.")
        timeout = min(25, max(0.05, float(timeout)))
        with self.condition:
            if self.receiver:
                raise util.Fail("A conversation is already receiving Studio actions.")
            if self.action is not None and self.action.get("receiver"):
                # receive() returns before its consumer sends the acknowledgement.
                # A second tool must not steal or receive that action again in
                # this gap, even when it has the same conversation id.
                raise util.Fail("An editing action is already being delivered.")
            deadline = time.monotonic() + timeout
            self.receiver = (receiver, deadline)
            try:
                while self.action is None:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        return {"action": None}
                    self.condition.wait(remaining)
                action = self.action
                action["receiver"] = receiver
                return {"action": dict(action)}
            finally:
                self.receiver = None
                self.condition.notify_all()

    def dispatch(self, request_id: str, project: str, text: str, timeout: float = 8):
        if not request_id or len(request_id) > 128 or not project or not text.strip() or len(text) > 24000:
            raise util.Fail("An editing request needs its project, instructions and request ID.")
        with self.condition:
            old = self.receipts.get(request_id)
            if old:
                if old["project"] != project or old["text"] != text:
                    raise util.Fail("That request ID was already used for different instructions.")
                return self._receipt(old)
            if not self.status()["available"]:
                raise util.Fail("The live editing connection is not ready. Your instructions are saved.")
            action = {"request_id": request_id, "project": project, "text": text,
                      "state": "delivering", "time": time.time()}
            self.receipts[request_id] = action
            while len(self.receipts) > 128:
                self.receipts.popitem(last=False)
            self.action = action
            self.condition.notify_all()
            deadline = time.monotonic() + min(8, max(0.05, float(timeout)))
            while action["state"] == "delivering":
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    action["state"] = "unconfirmed"
                    if self.action is action:
                        self.action = None
                    break
                self.condition.wait(remaining)
            return self._receipt(action)

    def acknowledge(self, receiver: str, request_id: str):
        with self.condition:
            action = self.receipts.get(request_id)
            if not action or action.get("receiver") != receiver:
                raise util.Fail("This action does not belong to this conversation receiver.")
            action["state"] = "delivered"
            if self.action is action:
                self.action = None
            self.condition.notify_all()
            return self._receipt(action)

    @staticmethod
    def _receipt(action):
        return {"accepted": action["state"] == "delivered", "state": action["state"],
                "request_id": action["request_id"], "project": action["project"]}


BROKER = Rendezvous()
AGENT_KEY = secrets.token_urlsafe(32)


def write_agent_key(server_token):
    path = util.STUDIO_OUT / "native-agent.json"
    # This file is never in Studio's public static/media allowlists.
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.native-agent-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w') as stream:
            json.dump({"key": AGENT_KEY, "api_token": server_token}, stream)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def authorized(given):
    return bool(given) and secrets.compare_digest(str(given), AGENT_KEY)
