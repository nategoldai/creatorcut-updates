# Licences

CreatorCut code, generated sounds, fonts, and installed third-party tools have separate terms. Review the applicable upstream licences for your use and organisation; this document does not grant rights to third-party media.

- **Code** (edit.py, kit/editkit, kit/studio, kit/setup, skills): © CreatorCut OS. Licensed to the buyer for personal and business use; don't resell the kit.
- **Fonts** (kit/fonts): Inter and Inter Display (SIL Open Font License 1.1, rsms/inter); Poppins, Lora, Anton, Instrument Serif and the Google Fonts the app downloads when matching a reference (SIL Open Font License 1.1 or Apache 2.0).
- **Sound effects** (kit/sfx): synthesised on your computer by kit/editkit/sfx.py. Original, royalty-free, yours to use.
- **FFmpeg** (kit/bin, downloaded by the installer): LGPL/GPL builds from the official FFmpeg build sites, used unmodified as a separate program.
- **Python packages** (.venv): faster-whisper (MIT), Pillow (MIT-CMU), certifi (MPL 2.0), yt-dlp (Unlicense), OpenCV (Apache 2.0); on Mac ocrmac (MIT) and PyObjC (MIT); elsewhere RapidOCR (Apache 2.0) and MediaPipe (Apache 2.0).
- **Speech model**: Whisper (MIT) in the faster-whisper format, downloaded once.
- **Motion graphics** (kit/render, installed per computer): HyperFrames (Apache 2.0) and Remotion (Remotion licence: free for individuals and companies up to 3 people; larger companies need a Remotion company licence) with GSAP (free standard licence). The headless browser is Chrome for Testing (BSD-style).

## CreatorCut OS v2 additions

- **Creator font library** (kit/fonts): Montserrat, TikTok Sans, Oswald, League Spartan, Barlow Condensed, Fredoka, Rubik,
  Outfit, Playfair Display, Caveat, DM Sans, Lexend, Nunito, Kanit, Raleway, Sora, Syne, Poppins, Lilita One, Bangers
  (SIL Open Font License 1.1); Luckiest Guy, Roboto, Open Sans (Apache License 2.0). Static Latin instances from
  Fontsource; family names normalised (suffix "CC") so every weight is a separate family. Free to use in videos.
- **Music library** (kit/music): generated on your computer by kit/editkit/musicgen.py. Original, royalty-free, yours to use.
- **Reference analysis** uses OpenCV (Apache 2.0) and yt-dlp (Unlicense). Reference videos are used only to measure style
  and may be retained in the local project for comparison evidence; remove them only when no longer needed and authorized.
- **Colour grades**: every LUT is generated on your computer for that video (no third-party LUTs).

## Signature fallback
Inter Tight variable font is redistributed unmodified from Google Fonts under SIL OFL 1.1; see kit/fonts/licenses/InterTight-OFL.txt for full copyright and terms. Signature code is independently authored; no tenfoldmarc template code or downloaded SFX is bundled.
