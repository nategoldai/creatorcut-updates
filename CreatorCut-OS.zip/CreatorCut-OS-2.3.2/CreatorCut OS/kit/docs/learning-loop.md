# Customer learning loop

This is durable editing memory and reusable skills, not model-weight training. It works inside this customer's local app folder; it does not automatically follow them to a separate install/account or ordinary web chat.

## Every project
Read `my-brand/learned.json` (when present), `my-brand/editing-memory.md`, the active preset skill, saved project feedback and this native conversation before planning. `workflow init PROJECT` refreshes `customer-memory.json` in the project with current creator and selected-preset rules. Record which relevant rules you used in scene-plan.json under `memory_application`, including overridden rules and why. This record is an agent explanation, not automatic proof that a visual preference was fulfilled. Use the memory even when writing custom HTML and never calling legacy `design`.

Precedence: the current explicit request first, its reference next, matching preset preferences then general creator preferences, then optional craft advice. If a request changes a lasting preference, update memory; if it is only for this video, leave permanent memory alone.

## Learn from conversation
Feedback explicitly recorded by the native editor is logged in `learned.json` (latest 300 entries, up to 20,000 characters per entry). The native editor saves feedback with creatorcut_feedback (or kit/tools/feedback.py when MCP is unavailable) on each correction. This is agent-mediated persistence, not passive access to the host transcript. Convert clearly lasting statements such as “always use smaller captions” or “remember that I dislike loud whooshes” into concise rules with `edit.py remember`. No extra confirmation is needed when lasting scope is explicit. A specific correction such as “put this logo on the right at 14 seconds” stays project-local. Repeated taste feedback is evidence of a possible preference: infer its narrow scope only when clear; otherwise apply now and ask once whether it should be remembered. Do not turn every revision into a global rule.

Commands (use the installed private Python):
- `edit.py remember "Keep sound accents subtle" --project PROJECT`
- `edit.py remember "Pop captions in; no side slides" --preset STYLE --project PROJECT`
- `edit.py remember "Leave natural thinking pauses in interviews" --preset INTERVIEW --project PROJECT`
- `edit.py learned` lists rules. `edit.py forget INDEX [--preset STYLE]` removes the listed rule.

Optional `--set key=value` stores existing renderer-compatible settings; do not invent one for a preference that needs creative interpretation. Free-text rules still guide bespoke scenes. Remove a superseded or contradictory rule before saving its replacement; do not leave both active. Tell the customer briefly what was saved and its scope. No automatic permanent preference is inferred solely from export differences.

## Saved skill and control
Remember/forget regenerates `my-brand/editing-memory.md` and identical `.claude/skills/creator-preferences/SKILL.md` and `.agents/skills/creator-preferences/SKILL.md`. The JSON remains the source of truth. Read it directly if the host has not refreshed skill discovery. Preset rules also refresh the existing preset skill where available. Native-chat removal regenerates the memory too. Personal feedback and generated preference skills are excluded from distributed app ZIPs.

Approved designs can also be saved as a named style using the existing preset workflow. A preference rule cannot preserve an entire complex animation: retain the project/reference assets and measured style specification for that. Later edits should reuse appropriate approved design decisions, not splice private old footage into unrelated projects.

## What can be promised
“CreatorCut remembers your saved editing preferences and uses them on future videos, helping reduce repeated corrections.” Do not promise each video is automatically better, instant edits, universal reference fidelity or a privately fine-tuned model. An active host agent still interprets preferences, makes edits and reviews the result. Validate the loop on unfamiliar users, not just by checking that a JSON file exists.


## Finished-edit presets and recipe versions
Studio Save as preset uses the published version currently displayed, checks its candidate hash and saved review, and snapshots its immutable plan/scenes/review. A reference is not required. It saves a content-stripped design grammar plus full evidence and available candidate-bound custom HTML/CSS/JS. Example video media is not duplicated or silently reused; missing dependencies must be resolved for the next project's adaptation. Named presets appear on Home and under Use saved preset in Studio, including alongside new references. Update preset creates v2/v3 without rewriting v1. Projects pin the selected version. Reselect explicitly to use the latest. General memory stays live; a pinned design recipe does not freeze the customer's general preferences.

## Real feedback cycle
1. The native editor records actual feedback immediately with project/creator/preset scope, plus the original text as evidence. Project corrections go in editing-feedback.json and editing-feedback.md; creator/preset rules refresh editing-memory.md and both creator-preferences skills.
2. Future projects receive relevant rules and the pinned recipe in customer-memory.json before the scene plan is made. They should not need to restate established preferences.
3. The editor records applied and overridden rules in memory_application and inspects the resulting scenes during candidate review. If the user corrects the result, revise the implementation and replace a superseded preference when appropriate.
4. Customers can ask their native editor to change or forget a preference; no memory/profile page is exposed. Removal regenerates the skills. Remembering is local to this installation; no third-party model weights are trained.

## The progress circle
learning-progress.json records one entry per successfully reviewed and published project. Revisions, retries, previews and failed renders add no points. The first ten projects add ten percentage points each; at ten the milestone stays at 100%, while preference memory continues to evolve. It is an engagement/onboarding milestone, not a prediction of edit quality or measured intelligence. Existing projects can count when next successfully published; old unverified drafts are not silently counted.


Memory application is a render gate: for each rule in customer-memory.json, add an entry to scene-plan.json memory_application with its exact rule, status (applied / overridden / not_applicable), reason and scene ids for applied rules. Current explicit requests may override an old preference, but explain the reason rather than silently ignoring it. Candidate fingerprints include this memory snapshot, so changing it requires fresh review. During review inspect those scenes; this structural gate does not itself prove artistic quality.
Presets can be saved before production from Step 5 with their full entered instructions, look/settings and actual reference analysis pointers. This is a starting recipe, clearly not an approved finished edit. After approval, Update preset with this final video replaces the active recipe using the reviewed plans and custom source evidence. Retained old recipe versions serve existing projects. Empty new briefs inherit the saved template; existing user instructions are never silently replaced. The general memory stays private in background files, with no Profile/Settings/memory page. Users can request changes/forgetting in this native conversation.

## Topic replacement and evidence thresholds
Use a stable topic for lasting feedback, such as sound.effects or captions.entry. A contradictory new rule on that same topic replaces the old active rule; the old evidence is retained in superseded history. Clear lasting requests (basis explicit) apply immediately. An inferred preference requires the same rule on the same topic in two distinct projects before becoming a general rule; repeated corrections within one clip do not count as independent support. Until then it remains project-local. This is an evidence policy, not proof that an inference is correct, and current explicit instructions always win.

The memory remains in background files; there is no Profile, Settings or View memory page. Before production, Save this as a preset captures full entered instructions, saved look/settings and the actual reference analysis links in a named starting recipe. Update from the final video makes a reviewed recipe the active version. Home shows the name, and Studio can select it for another script. Existing non-empty instructions are never silently replaced.

Keep topics narrow: audio.sfx.level and audio.sfx.variety are different preferences. Split independent corrections into separate rules; do not replace a volume preference merely because the customer asks for more varied sounds. When revising a compound rule, preserve its still-valid constraints.

## Default is not evidence of taste
CreatorCut Signature fills unspecified visual choices. Its white/yellow palette or text motion is not a customer preference just because it appeared in an export. Do not call feedback/remember with defaults as if the user said them. A named preset can intentionally retain the chosen recipe; universal rules require actual customer feedback and the normal scope/evidence policy. Reference-specific numeric changes do not automatically override a new reference; inspect relevant rules and apply them only to unclear features. Read signature-style.md.
