# Native conversation and embedded Studio

The real host conversation is the only chat. Studio shows files, settings, previews, presets and editing progress inside the host's preview panel beside that chat. It has no duplicate composer, fake assistant messages or mirrored reply history.

Under the video, a clear guide tells customers to type changes in the chat beside Studio. Copy-example buttons only copy text; the customer pastes, customizes and sends it in the real conversation. They do not start AI work or claim to focus a host chat control.

## Native launch and automatic Make
The automatic start path is: Studio click → either advertised host ui/message OR an active foreground native-action tool → request in the same native conversation → actual project claim → editing tools. Each transition has separate evidence. A delivered action is not proof that editing started.

Register the existing MCP server in the actual open host project with `studio bridge-config --host-project PATH`, then follow the host's trust/reload requirements. Invoke creatorcut_studio to mount the native app when the host supports it. A plain localhost preview has no parent message bridge and cannot wake a native conversation by itself. It must not pretend to edit by starting only footage preparation. CreatorCut does not open a second AI session, scrape host transcripts or write replies into another chat.

Keep opening inside the host. Before declaring automatic start fixed, test a genuine click in each supported host and confirm the request and workflow claim. Registration and simulated host tests are insufficient evidence.

## Foreground action rendezvous
When native App rendering is unavailable, keep the existing conversation active in `creatorcut_wait_for_action` (up to 25 seconds per tool call), or run private Python `kit/tools/native_wait.py --seconds 120 --conversation ACTUAL_SESSION_ID` using the host's yielding command tool. Await its result in this same turn. The server accepts a click only while that actual foreground tool is waiting. The tool acknowledges receipt, returns the saved project ID and action text, and this same editor reads the full saved brief and runs `edit.py workflow claim PROJECT --owner ACTUAL_SESSION_ID --phase planning` before editing. No second AI, assistant reply generator, transcript scraping, detached editor, or persistent action queue exists.

After handling an action, re-arm while serving Studio. Handle native user messages normally; cancel the waiter when leaving Studio or switching to unrelated work. A tool left running after ending a turn is not a live agent: do not detach it and promise automatic replies. With neither advertised ui/message nor an actively awaited receiver, automatic Make is unavailable. This approach does not remove host interruptions, approval requirements, or the need for a live native turn.

Receipts distinguish delivered from unconfirmed; request IDs reject duplicate or altered replay. Receivers require a private local agent key which is excluded from public static/media routes and release archives. Browser API authorization alone cannot impersonate a waiting conversation. A failed/disconnected receive expires instead of silently accumulating work. The UI shows actual receiver availability and actual workflow activity.

## Failure behavior
The host owns conversation delivery, tool approvals and responsiveness. Do not promise instant replies or zero freezes. A failed render is reported here with its exact cause and a targeted recovery; it does not create another chatbot. Show measured step progress, stage names when unknown, and explicit quiet/error states. Preserve source and approved output.

## Verification limits
Bridge unit tests simulate a host and do not prove live provider compatibility. On October 19, the foreground path was tested with the actual Studio Make button in Codex: its action returned to the existing native conversation, that conversation claimed the isolated project, and produced a real three-second preview. This is not proof of an idle-chat wake mechanism or of Claude host integration. Test fresh installations and each host's foreground tool lifecycle before broad release.
