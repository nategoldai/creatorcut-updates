# Candidate review checklist
Read production-workflow.md and scene-contract.md. Inspect the actual candidate and reference; do not publish from a contact sheet alone.

- Speech: correct takes, complete words, no unintended repeats, natural requested pacing and lipsync.
- Reference: important scenes and adaptations accounted for, entry / moving / held / exit compared.
- Typography: actual font, glyphs, size, colour and placement; complete prompts readable at completion.
- Motion: phrase/gesture sync, correct assets, playing-video inserts when requested, no stray frames or mask spill.
- Audio: listen throughout; narration remains natural, music/effects intentional and balanced, cuts don't click.
- Colour: requested appearance preserved or deliberately graded; HDR delivery checked separately.
- Requirements: all brief requirements bound to scenes, unresolved items discussed, no generic substitutions hidden.

Technical checks and setting comparisons are diagnostics. Creative review is an identified agent's attestation, not a 100% fidelity score. Record evidence and observations with workflow review, then workflow publish. Never tick a check you couldn't inspect.
