# Troubleshooting

Always start with `edit.py doctor`. Technical details are in `kit/studio-out/server.log` and `kit/studio-out/install.log`. Re-running the installer is always safe: finished steps are skipped.

| Symptom | Cause and fix |
|---|---|
| Installer stops on a step | Usually the network. Run `bash kit/setup/install.sh` (Windows: `powershell -ExecutionPolicy Bypass -File kit/setup/install.ps1`) again. |
| "FFmpeg isn't installed" | The installer puts a private FFmpeg in `kit/bin`; run it again. |
| Transcription won't install | A very new Python. The installer uses its own private Python 3.12 (`uv`); run it again. |
| First transcription is slow | The speech model downloads once (~500 MB). |
| Studio blank or "can't connect" | The server stopped: `edit.py studio serve` in the background, then reload. Studio skill. |
| Reference link won't fetch | Private or region-locked video. Ask for the file instead (Add reference video file). |
| Colours washed out (iPhone) | HDR video; the cut tone-maps it. Tip: Settings → Camera → Formats → HDR Video off. |
| Text cut off / under buttons | Move the item inside the safe area; compose's fit step shrinks oversize text. |
| Render says "large temp files" | Less than 1 GB free disk. Free space (Storage → Free up space in the app). |
| HyperFrames / browser missing | Motion step of the installer; run it again. |
| An update failed | Nothing changed: the backup was put back. Try again later; `edit.py update rollback` returns to the version before the last update. |
