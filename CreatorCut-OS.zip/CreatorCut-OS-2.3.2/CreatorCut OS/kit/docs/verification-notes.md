# Verification notes

CreatorCut OS 2.3.1. These notes describe test scope, not a guarantee of failure-free operation.

The current build has 201 passing Python regression checks covering editing contracts, presets, feedback memory, reference/default precedence, request bounds, OS lock recovery after an actual process kill, native tool cancellation, bounded metadata reads, low-disk startup, source preservation and update safety. Browser/HTTP checks cover saved briefs, uploads, named presets, real zero progress, no duplicate chat, layout and preparation. Protocol fixtures are labelled separately from live tests.

In Codex, two actual Studio Make clicks returned to foreground command tools in the existing conversation; that conversation claimed the isolated projects and produced real three-second and two-second previews. The actual editor thumbnail decoded at 540x960, and the preview recovered after a Studio server restart. A real MCP worker against the actual isolated Studio also passed cancellation, parallel tool-list response, clean close and hard-kill receiver-expiry checks. These tests establish an active-turn path, not an ability to wake an idle/ended native turn. The Claude host lifecycle has not been verified end to end.

A fresh three-second graphics export passed the real HyperFrames check/render, video-frame motion checks, full H.264/AAC decode, timed sound detection and bounded audio peak checks. This test exposed and then verified the repair of a soundtrack option incompatible with the installed FFmpeg 9 runtime. The fixture verifies engine functionality, not artistic quality.

An actual two-second synthetic Signature composition was exported through HyperFrames and fully decoded. Its font, entry animation and transparent-subject layering were inspected in an exported frame. Intentional behind-subject text caused an occlusion warning that required visual review. This does not prove real-person mask quality or every customer's creative result.

The update-button installation test used a disposable extracted package, real checksum/backup/file installation and UI reload, with test manifest/download delivery substituted. Projects, presets and editing memory were preserved. Additional tests cover active native edits, jobs outside the display window, stale transaction state and interrupted atomic writes. Public publication of this new ZIP and manifest is not complete; the configured feed still advertised an older version during this audit. Independent first installations on other operating systems and the Claude host lifecycle remain outstanding. These limitations must not be described as verified capabilities.

The deeper lifecycle audit additionally verifies a real Studio restart onto another port while the same foreground receiver stays active, reloads the new private credentials and receives one actual action. Concurrent consumers cannot steal an action between delivery and acknowledgement. Renaming a preset preserves the selected recipe version, current brief and refreshed project memory. These are bounded recovery checks, not a guarantee against all host or operating-system failures.

A review of the last 100 customer messages identified that live GitHub release publication and independent Claude installation remain unverified, and automatic Make still requires an active native receiver or supported host message bridge. Delivery uncertainty is now scoped to its project and cleared by an actual newer project claim, never by a cosmetic timer.

Additional fault checks distinguish an old failed step from a genuine newer native editing claim. A new failure remains visible. Invalid non-positive worker PIDs never mark an entire process group as a live editing worker. The known installed application still had active editing leases during this review and was not overwritten; the updated ZIP is distinct from that installed copy.

Startup metadata can arrive after the active wait begins; the tool retries within its bounded lifetime instead of ending on that file-write race. A blocked or expired workflow is never accepted as a newly started edit. Current error/stall messages take priority over an older “building” message.
