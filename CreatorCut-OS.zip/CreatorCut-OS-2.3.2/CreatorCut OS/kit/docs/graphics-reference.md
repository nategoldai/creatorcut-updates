# Graphics reference (beats.json, classic videos)

Studio videos use `edit-plan.json` instead (see `edit-plan.md`). Classic videos describe graphics in `kit/projects/<p>/beats.json`:

```json
{"beats": [
  { "type": "title", "text": "Claude edits my videos now", "at": 0.0, "duration": 2.4 },
  {"type": "list", "title": "3 things it does", "items": [
      {"text": "Cuts bad takes", "at": {"say": "cuts the bad takes"}},
      {"text": "Word-perfect captions", "at": {"say": "adds captions"}},
      {"text": "Builds the graphics", "at": {"say": "builds the graphics"}}],
   "until": {"say": "This saves me"}},
  { "type": "counter", "value": "10 hours", "label": "saved every week", "at": {"say": "ten hours"} },
  { "type": "cta", "text": "Comment EDIT" }
]}
```

## Timing (`at`, `until`)

| Value | Means |
|---|---|
| `0.0` | seconds on the cut video |
| `{"say": "ten hours"}` | the moment those words are spoken (first time after the previous beat) |
| `{"say": "ten hours", "edge": "end"}` | the moment they finish being said |
| `{"say": "the", "occurrence": 3}` | the 3rd time "the" is said |
| `{"say": "...", "offset": -0.3}` | 0.3s before the words |
| `{"say": "...", "anywhere": true}` | search from the start, not after the previous beat |

`duration` (seconds) or `until` ends a beat; otherwise each type has a sensible default.

## Types

| Type | Fields | Use |
|---|---|---|
| `title` | `text` (use `\n` for 2 lines), `sub`, `position`, `y`, `hide_captions` | the hook, at 0.0 |
| `emphasis` | `text` | one power word, stamped big, with a push-in zoom |
| `list` / `steps` | `title`, `items` [{text, at}] | when they enumerate; items appear as said |
| `counter` / `stat` | `value` ("10 hours", "$5K", "93%"), `label` | numbers that matter; counts up |
| `compare` | `left`, `right` ({text, at}), `labels` | before/after, old/new |
| `chart` | `bars` [{label, value, highlight}], `title` | growth, results |
| `proof` | `file` (in `my-brand/proof/`), `caption` | a screenshot that proves a claim |
| `image` | `file`, `mode` card/half/full, `hide_captions` | a photo |
| `broll` | `file` (project media), `mode` full/pip, `motion` push/pan/none, `from` | B-roll clip or moving photo |
| `quote` | `text`, `by` | a quote |
| `note` | `text`, `tilt` | a sticky-note aside |
| `nametag` | `text`, `sub` | who's talking |
| `cta` | `text` (default: profile `cta`) | the call to action at the end |

`position`: `top` (default), `middle`, `bottom`; or `y` as a fraction of the height. Fonts, colours, card shape and entrance come from the style. `edit.py check <p>` validates everything and reports overlaps.
