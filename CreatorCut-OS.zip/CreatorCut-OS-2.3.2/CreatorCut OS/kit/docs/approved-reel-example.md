# Worked example: “I didn’t edit this video”

## Watch and interpret
Watch `kit/samples/approved-reel.mp4`: a complete, reduced-resolution viewing copy of Nate's approved v8 reel (58.333s, 24fps). It demonstrates one customer’s choices; it is not the default style for new customers. The original master was 1080×1920 with 1400 frames. The view copy retains the finished audio and graphics; original raw files, third-party reference videos, fonts and production assets are not provided as an editable project.

This is a documented historical example, not a newly rendered demonstration of the 2.3 engine. The original was a custom Python compositor. The table below reconstructs editorial decisions from surviving scripts, the final release manifest and the conversation; time ranges are navigation cues, not a machine-accurate re-edit list. Use spoken phrases to locate exact events. Do not pretend these notes are original scene-plan.json or that one approved film establishes repeatable customer performance.

## Customer brief and selected speech
The customer wanted to demonstrate AI editing his talking-head reel: respond visually to his spoken commands, show real videos/UI, build from a tight speech cut, and end with a video-guide CTA. He explicitly requested bold white/yellow display type, a white-background Claude scene, gesture-linked colour transformations and an energetic soundtrack. His ordinary footage-preservation preference did not prohibit the creative grading he explicitly requested in this project.

The approved clean v3 cut kept complete thoughts and removed bad takes. Later the “change the music / that’s much better” passage was removed by instruction. The last correction removed interpolated cinematic hold frames and a camera push: the person stays at normal speed. Reuse that editorial principle, not its exact sentence durations.

## Complete scene walkthrough
| Approx. final time | Spoken cue / task | Design and action | Why / what to inspect |
|---|---|---|---|
| 0–2.8s | “I didn’t edit…” | One-line heading and straight modern editing rail using reel thumbnails above the subject. | Show the finished-film premise visually; moving thumbnails must come from the film, not a generic cinema strip. |
| 2.8–4.1s | “Claude did it all for me” | White background, foreground body cutout, genuine Claude mark, black bold text; quick sideways white-wall exit. | Separate this claim from the room; inspect hair, shoulders and first/last compositing frames. |
| 4.1–5.6s | “No CapCut, no Edits app” | Real app marks and labels; staggered pop/settle, opposite red strike strokes, accelerating falling exits. | Match each spoken app name; make one action resolve before the next. |
| 5.6–9.3s | Upload and ask Claude to edit | Compact white composer, talking-head attachment, complete typed instruction, send action, edited state. | A coherent action/result demonstrates the claim. Hold the complete prompt inside the window. |
| 9.3–11.5s | “Watch this / motion graphics” | Short yellow cue followed by a bespoke editing demonstration. | A command produces an immediate visible change, rather than another generic talking-head card. |
| 11.5–14s | “Different font styles” | Six oversized STYLE treatments, white/yellow, behind the subject; pop entrances and individual accents. | Silhouette changes (condensed/serif/outline/heavy/etc.) make the variation obvious. Preserve the foreground mask. |
| 14–16.8s | “Show me…videos / make them go away” | Six genuine playing vertical clips, varied size and tilt, staggered near the right-hand gesture; alternating curved exits. | Actual playback, recognizable clips, purposeful staging; do not attach every card rigidly to the hand. |
| 16.8–about 20s | “Warmer / more cinematic” | Diagonal warmer wipe, reverse cinematic wipe at finger snap; deeper contrast and corners while protecting skin/UI. | Locate the snap on output frames. The final v8 keeps natural moving footage, with no slow-motion hold. |
| about 20–23.4s | “Pretty insane…don’t know…editing” | Animated yellow INSANE as a selective emphasis, room/body framing retained. | Only the chosen emphasis needs display type; do not cover the entire speech with extra titles. |
| about 23.4–26.4s | “Drag and drop this raw file” | Raw talking-head file enters Claude, typing → editing timeline → gaps closing → progress. | Demonstrate the actual verb. Use a readable minimal UI, not a still progress label. |
| about 26.4–30.9s | “Bad takes…silence…animations” | Approved editing/timeline sequence and white-wall transition into the next section. | Check transition-adjacent frames; avoid accidental talking-head flashes or exposure fades. |
| about 30.9–34.8s | “A lot of people…same results” | Real reel wall, fully visible clips; subject already in the first frame above the montage. | Communicate abundance without losing the speaker; do not add a white opacity wash. |
| about 34.8–37.6s | “My way…different / trained…viral clips” | Word-timed DIFFERENT WAY, then Explore-style reel analysis with scan and extraction states. | Stage a simple action; limit labels so the viewer can see what was found. |
| about 37.6–42.9s | “Specific instructions…” | Skill cards converge into a moving Mac-style folder labelled skill.md. | Gather → store is the visual argument; the folder movement follows that action, not random bouncing. |
| about 43–46.6s | “Generic result…looks like this” | Deliberately muted footage, ordinary dark-purple result on white rectangle/black offset box with blue stars; clears on snap, then bold THIS with echoes. | This unattractive treatment is intentional contrast, not the app's default output. Align restoration with the gesture. |
| about 46.6–50.8s | “Instructions and setup” | Miniature real clips converge into a timeline and then a folder. | Shows a reusable editing system. Keep clips identifiable during convergence, then simplify. |
| about 50.8–55s | “Recorded an entire video…step by step” | Silent real guide-preview video on white upper background; transitions toward comment composition. | Show what the audience receives. The guide's audio must not compete with narration. |
| about 55–58.33s | “Comment VIDEO…follow” | Full white background, clean foreground body, large orange VIDEO, comment/submission/reply and Follow→Following. | Exact CTA word and readable interaction; no white flare on the body. |

The original script used source-cut time; removing 64 frames shifted later output positions. Approximate ranges above account for that removal. For frame-exact recreation, inspect the packaged film and establish new anchors; do not lift these ranges as executable timing.

## Assets and production choices
Use this film as visual evidence. Historical asset classes: genuine app marks; owned talking-head/reel footage; supplied Explore screenshots; course preview; subject alpha masks; multiple display fonts; energetic 118 BPM instrumental and action-linked effects. This ZIP supplies the flattened film only, not permission or standalone source files to reuse another creator’s footage, music, marks or fonts in new customer edits. Use suitable customer-owned/usable assets for their work.

The final manifest records no course audio, no music-switch passage, a 0.9 narration gain, mix peak about 0.903 and normal-speed source mapping. It does not prove the soundtrack is the right taste for every creator. Reuse the separation of camera grade from white UI, full-message readability and deliberate variation; do not copy the customer's exact colours or CTA word automatically.

## How to transfer this to a new edit
1. Identify the new customer's spoken demonstrations and preferred reference choreography.
2. Build their clean speech cut; locate gestures on that output.
3. Choose the relevant scene mechanisms above, or a different mechanism required by their reference. Record why each visual helps.
4. Use assets belonging to their story, correct font choices and measured layout; keep original appearance unless the brief calls for grading.
5. Write real scene/edit plans using scene-contract.md. Do not label these historical notes a ready-to-render template.
6. Review actual entry/hold/exit frames and playback/audio where available; retain approved scenes across revisions.
7. Save lasting customer feedback via learning-loop.md, with scope and conflicts resolved. This film remains a demonstration, never their memory profile.

## Rejected → accepted decisions
- Slow-motion cinematic hold → normal-speed footage with stronger requested contrast/vignette.
- Font labels in boxes → one huge STYLE word with distinct treatments behind the body.
- Tiny/rigid cards → varied-size real video cards staged around the hand, with differentiated exits.
- Cropped typing → complete sentence fitted and held in a credible composer.
- Dense instructional UI → a staged scan/extract/store action with fewer labels.
- White fading across the person → clean subject matte and moving opaque white surface.

These corrections are the useful craft knowledge: diagnose the visible failure, change the scene mechanics and inspect the result. “Make it premium” alone does not specify a fix.
