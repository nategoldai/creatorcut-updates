# validation tester checklist

Use a copy of the app folder. Keep existing my-brand and kit/projects data backed up before replacing an older installation. No customer data is included in this ZIP. The unchanged START HERE.pdf is accompanied by current kit/docs/setup-notes.txt.

1. Open the app folder in your native editing conversation. Complete host trust/setup and open CREATORCUT. Confirm the interface is actually visible.
2. Keep the actual native chat beside Studio. Confirm there is no extra chat box in Studio. Under the video, copy an example, paste it into the real chat, customize and send it. Confirm the editor responds here and changes the right project. Repeat during an edit using the host’s normal message handling. A copy button must not claim that it sent a request. Optional Make transport requires separate live host capability testing.
3. Create a short video. Fill Step 5 with distinctive detailed instructions and verify they survive reload, are read before editing and appear in the output. Do not mistake placeholder examples for saved user instructions.
4. During a long step, check real progress. Quiet/failed workers should show Needs attention and a recovery action rather than a live stale number. Recovery should inspect and resume the interrupted step without duplicating an active render or overwriting an approved file.
5. Before Make, name and save the entered brief as a preset. Verify its full template loads for a different script. Then update it from the reviewed result. Find it on Home, choose it for a different script, and check typography/motion/pacing, not just that the preset name appears. Update the preset from a different reviewed result; old projects retain their pinned recipe.
6. Say a clearly general preference, then make another video with a different preset. Verify the native editor saved the preference and uses it in the new output. Memory files remain behind the scenes; there is no Profile/Settings/memory screen. A one-off scene correction must stay local. Remove a saved preference and verify it is absent in a fresh project.
7. Complete one project: circle +10%. Export/revise it again: no extra points. Ten distinct reviewed published projects reach the onboarding milestone, while memory remains editable.

Report host/app version, the failing action, visible state and relevant local log excerpt. These checks require real native sessions and human output review; passing packaged unit tests cannot substitute for them.
