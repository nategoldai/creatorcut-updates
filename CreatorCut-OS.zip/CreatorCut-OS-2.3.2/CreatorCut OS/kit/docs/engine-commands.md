# Engine commands

Run with `.venv/bin/python edit.py <command>` (Mac/Linux) or `.venv\Scripts\python.exe edit.py <command>` (Windows). `edit.py --help` lists everything; `<p>` is a project name in `kit/projects/`.

## Setup and health
| Command | What it does |
|---|---|
| `doctor [--json]` | Checks Python, FFmpeg, editing tools, motion graphics, reference reading, fonts, sounds, speech model, disk. READY / NOT READY. |
| `install` | Runs the one-step installer (`kit/setup/install.sh` / `install.ps1`). Safe to run again. |
| `fonts`, `calibrate`, `sfx`, `music-gen`, `model` | Font pack, font size calibration, sound effects, the original music library, the speech model. |
| `update [check|rollback|<zip or link>]` | Install a newer version (videos, presets and settings are kept). |

## The Studio app
| Command | What it does |
|---|---|
| `studio serve` | Starts the app server (port 4317 or the next free one). |
| `studio context` | What's in the Studio now: the video on screen (footage, B-roll, reference, preset, versions) and every other video. |
| `studio begin <p>` | The creator asked for the video: the Studio switches to the progress screen. |
| `studio say --project <p> --text "…"` | A short note on the Studio screen under the video (your real answer goes in the chat). |
| `studio open`, `studio status`, `studio thumb --style <id>`, `studio build` | Open / check the app, refresh a preset thumbnail, rebuild offline data. |

## A video (Studio flow)
| Command | What it does |
|---|---|
| `prepare <p>` | Joins the video's raw clips into one source. |
| `media <p>` | Media list + B-roll contact sheet (`render/media-sheet.jpg`). |
| `transcribe <p>` | Every word with its time (faster-whisper, on this computer). |
| `plan <p> [--max-pause s]` | The paper edit: bad takes, restarts, stretched words, mumbles, fillers, pauses → `plan.json`, `plan.md`. |
| `cut <p>` | Cuts the video from `plan.json` → `cut.mp4`, `words.json`, `segments.json`. |
| `wait-reference <p>` | Waits until the video's reference is studied and its style applied. |
| `grade <p>` | Per-video colour grade (generated LUT) with safety checks → `graded.mp4`. |
| `design <p> [--force]` | Drafts `edit-plan.json` from the reference's style kit. |
| `cutout <p>` | The person cut out of every frame (for text behind them). |
| `font "<Family>" [weight]` | Downloads any Google font for the plan. |
| `compose <p> --note "…"` | Checks and renders the plan with motion graphics (HyperFrames) → a new version. `--final` for full quality. |
| `stills <p> [--video f] [--at 1.2,3.4]` | Contact sheet of frames. |

## References and presets
| Command | What it does |
|---|---|
| `reference <link or file>` | Fetch and study a reference. |
| `study-ref <id> --src <video>` | Full study: map of every word, fonts letter by letter, style kit, colour. |
| `restudy <style|all>` | Study a preset's references again with the current analysis. |
| `match <style> --text "…" --frame <img>` | Side-by-side of a preset's captions vs a reference frame. |
| `preset-skill <style>` | Writes the preset's skill (`.claude/skills/preset-<id>`). |
| `teach <name> [--folder f]` | Analyse references for a new style (chat flow). |

## Classic chat flow
`new [file] [--style s] [--platform p]`, `words <p>`, `beats <p>`, `check <p>`, `preview <p>`, `render <p>`, `auto <file>`, `styles`, `style <p> <style>`, `set <p> key=value…`, `profile key=value…`, `tour <p>`, `cover <p> --text "…"`, `compare <p>`, `export <p> --to youtube,square`, `short <p> --range 12-48 --name <slug>`, `status`, `clean <p>`.
