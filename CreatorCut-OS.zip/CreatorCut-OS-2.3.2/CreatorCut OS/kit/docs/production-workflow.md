# Production workflow, v2.3

The Studio and render tools are local. Claude Code or local Codex supplies the creative agent and permissions. This ZIP is not an autonomous cloud editing service and does not install a ChatGPT web connector. Keep the agent session open while edits run. Inference billing belongs to the customer's host account. Install downloads dependencies and models; local rendering consumes disk/CPU.

## Start / resume
Open the app folder in the host, read root instructions, run setup if needed, then `studio open`, `studio context`, `studio pending`. Select the requested project and `workflow claim ID --owner UNIQUE-SESSION`. Refresh claim every 20 minutes; leases expire after 30 minutes. The claim is advisory process ownership, not an authenticated multi-user security boundary. This is a single-customer local app. `workflow status` is recoverable after restart even when an event was already acknowledged. No unattended job runs merely because the web page is open. All editing conversation stays in the native chat beside Studio. Optional Make/recovery uses a negotiated ui/message connection; plain preview offers a saved request to copy. See native-conversation.md. No reply mirroring or separate editor queue.

## Required artifacts
1. Best-take plan + cut transcript (`plan.json`, `words.json`, `segments.json`). Agent reviews actual cuts.
2. Reference evidence and scene contract (`scene-plan.json`). Brief wins; reference adaptations explained.
3. Exact composition (`edit-plan.json`) with stable item ids and explicit audio events.
4. Candidate (`render/candidate.mp4`), technical decode check, review frames and manifest.
5. Agent-authored review tied to candidate SHA256 and input hashes.
6. Published numbered version; final export copies the same approved candidate.

`workflow init` only creates a scaffold; it does not invent scenes. `design` remains a legacy heuristic helper. A host agent must perform the creative work. The gate validates coverage/bindings/assets but cannot independently prove design fidelity or truthful human/agent observation.

## Commands
Use private Python, then `edit.py workflow {init,status,claim,block,validate,evidence,review,publish} PROJECT`.
Claim: `--owner SESSION --phase planning` (analysing/planning/building/reviewing supported).
Review: `--report PATH`. Publish: `--note TEXT`.
`compose PROJECT --final` makes an internal full-quality candidate. `compose` uses draft quality for experiments. Both require the scene contract. `workflow evidence` regenerates inspection frames. `render PROJECT` copies the reviewed output to finished; it doesn't render an unchecked alternate.

If a requirement is impossible or assets are missing: explain it, record unresolved entries, and block. An unknown logo or web UI is not a reason to make up a fake approximation without disclosure. Budget-limited failures remain candidates, not finished versions.

## Release support
Automated regression and local render tests are shipped in kit/tests. Independent first-run installations on Windows/Linux and creative evaluations across customer footage must be completed before advertising broad production readiness. See kit/docs/verification-notes.md at package root for measured status.

## Default visual direction
Use `kit/docs/signature-style.md` whenever a visual choice is unspecified. CreatorCut Signature is the default: Inter Tight white/yellow type, speech-timed in-place pops, selective readable words behind the speaker, purposeful animated media and gentle subject-safe finishing. Explicit instructions, clear reference observations, selected preset and relevant user memory override only the features they specify; unknown features fall back individually. Observed absence is an explicit choice (e.g. no captions or no motion), not a reason to add effects. Read style-direction.json and translate actual brief/reference/recipe/memory evidence to style-inputs.json before final planning. Defaults are not user preferences and must not be learned as feedback. Never silently restyle existing approved projects.
