# The blueprint (in a preset: `my-brand/styles/<style>.json` → `blueprint`)

How a reference is edited beyond its text. `study` measures a first version (`"auto": true`); the agent makes it exact from the
dense sheets (`kit/projects/_teach/_refs/<id>/dense/`, 10 frames a second at every graphic moment) and sets `"auto": false`.
`edit.py design` applies it to every video with this preset.

```json
{
  "auto": false,
  "pacing":  {"max_pause": 0.14},
  "opening": {"mode": "words"},
  "block":   {"sentence": 1, "behind": true},
  "cards":   {"per_minute": 18, "w": 0.36, "h": 0.36, "y": 0.2, "rot": 6, "behind": true, "stack": 2, "duration": [1.2, 2.6],
              "enter": {"ease": "back", "scale_from": 0.78, "rot_from": 1.8, "ms": 340},
              "float": {"rot": 4, "dx": 0.015, "dy": -0.012, "scale": 1.04}},
  "burst":   {"count": 24, "spread": 0.44, "size": 0.068, "duration": [0.9, 1.6]},
  "fullscreen": {"duration": 0.9},
  "pieces":  true,
  "notes":   {"font": "Caveat"}
}
```

| key | meaning |
|---|---|
| `pacing.max_pause` | seconds of silence kept inside a sentence (smaller = faster). Measured from the reference's speech. |
| `opening.mode` | `words`: the video opens one word at a time like the captions; `block`: the first line is a stacked block of text. |
| `block` | which sentence (0 = first) is set as a stacked text block early on; `behind`: its top lines pass behind the head. `null` = none. |
| `cards` | B-roll on cards: size (fractions of the frame), height of their centre `y`, tilt in degrees, `behind` the person, `stack` (how many at once), how long they stay, how they enter (`enter`) and drift while visible (`float`). `per_minute`: how often. |
| `burst` | a cloud of many frames from the creator's clips on "a week of them / all / every" moments. |
| `fullscreen` | full-picture cutaways (B-roll over the whole frame). |
| `pieces` | animated pieces (folder, counter, checklist, phone, sticker, apps) fit this look. |
| `notes` | handwritten asides; the agent writes their words, new for every video. |

Leave a key out (or `null`) when the reference never does it: the planner then never adds it.
