# Lessons from real editing sessions

These lessons came from successful and rejected iterations, including Nate's reels. They describe execution failures; they do not define a universal aesthetic.

- Treat a reference as choreography: layout, type, entrances, motion, holds, exits and sound. A list of colours and font names loses the design.
- Match meaning and gesture. A logo must meet the actual pointing finger. Anchor scene timing after the final speech cut. Don't reset a continuous animation at every camera cut.
- Tight cuts preserve syllables, consonants, breaths and intent. Do not blindly shorten all segment ends. Check rejected starts and repeated phrases by listening.
- Moving a screenshot isn't playing a video. Confirm actual in-card playback when the customer wants a reel wall.
- Show the real relevant website/UI at a spoken instruction. Reconstructed interfaces need genuine proportions and coherent content, not blank cards or duplicate filler text.
- Keep the whole prompt visible at typing completion. Constrain camera crops, wrap text and hold for reading. Inspect glyphs, alignment and resolution at full size.
- Person masks need temporal stability and clean hair/body edges. Inspect white-background composites for bright spill, especially hands and shoulders.
- Colour conversion and creative grading are separate. Preserve requested original appearance, and don't brighten footage to compensate for graphics colour errors.
- Preserve original voice unless processing is requested. Loud repeated whooshes or unrelated effects make motion feel worse. Place audio against visible/spoken events; quiet typing for typing, clicks for actual actions, suitable accents for reveals.
- Don't invent hook captions, titles, music or CTA styling against the brief. Intentional stillness is valid; constant motion is not inherently premium.
- Inspect sequences in motion, not just tiny contact sheets. Technical playback and hashes cannot establish visual quality.
- Preserve approved scenes across revisions. Compare to the current request, not abandoned feedback. Never show an unfinished render as the latest ready version.

## Optional customer example (not applied automatically)
Nate often approved large mixed typography, clean white UI scenes, genuine playing-video montages, specific gesture timing and restrained effects. Some projects called for original colour, others for a deliberate cinematic transformation. Even one customer's preferences vary by project. Do not copy these choices into new customers' profiles.
