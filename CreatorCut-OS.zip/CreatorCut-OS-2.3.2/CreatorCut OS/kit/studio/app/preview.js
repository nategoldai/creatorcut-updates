/* CreatorCut OS — real pictures only.
   Presets and references are shown with their own frames (a flipbook of the reference video), and measured
   fonts are loaded from the font library so the readout shows the real typeface. */
(function () {
  "use strict";
  const A = window.AIE;
  const loaded = new Set();

  A.ensureFont = (key, urls) => {
    if (!key || loaded.has(key) || !urls || !urls.length) return;
    loaded.add(key);
    let tag = document.getElementById("aie-fonts");
    if (!tag) { tag = document.createElement("style"); tag.id = "aie-fonts"; document.head.appendChild(tag); }
    tag.appendChild(document.createTextNode('@font-face{font-family:"aie-' + key + '";src:' + urls.map((u) => 'url("' + u + '")').join(",") + ";font-display:block}\n"));
  };

  /* One ticker for every flipbook: each shows the next real frame of its reference. */
  function step() {
    document.querySelectorAll("[data-flip]").forEach((el, k) => {
      const imgs = el.children, n = imgs.length;
      if (n < 2) return;
      el._t = (el._t || 0) + 1;
      if ((el._t + k) % 2) return;                     // neighbours change on alternate ticks
      const cur = Array.prototype.findIndex.call(imgs, (i) => i.classList.contains("on"));
      const next = (cur + 1) % n;
      if (cur >= 0) imgs[cur].classList.remove("on");
      imgs[next].classList.add("on");
    });
  }
  if (!A.reduced) setInterval(step, 450);
})();
