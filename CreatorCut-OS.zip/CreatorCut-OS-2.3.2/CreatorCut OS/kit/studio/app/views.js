/* CreatorCut OS — screens: onboarding, Home, Studio, My videos, Presets. */
(function () {
  "use strict";
  const A = window.AIE;
  const { esc, icon } = A;
  const S = () => A.state || {};
  const P = () => S().profile || {};
  const agent = () => A.agentName();
  const listening = () => !!(S().listening && S().listening.listening);
  // the editor (Claude Code / Codex) behind the app: listening, working on a step, or not open
  // 2.2: the creator talks to the editor in the Claude Code / Codex chat; this screen only shows the work
  const ed = () => ({ connected: !S().offline, busy: false });
  const edLabel = () => "Studio";
  const NAME = "CreatorCut";

  /* ============================================================ pieces == */
  const mark = (size) => '<span class="mark' + (size ? " " + size : "") + '" aria-hidden="true">' + icon("cut") + '<i class="rec"></i></span>';
  const brand = () => '<span class="brand">' + mark() + '<span class="wordmark">' + NAME + "<span>OS</span></span></span>";
  const presets = () => (S().styles || []).filter((s) => s.yours);
  const styleById = (id) => (S().styles || []).find((x) => x.id === id);
  const projectById = (id) => (S().projects || []).find((x) => x.name === id);
  function installInfo() { return A.installView(S().install); }
  function miniRing(pct) {
    const c = 2 * Math.PI * 6;
    return '<svg class="mini-ring" viewBox="0 0 16 16"><circle class="t" cx="8" cy="8" r="6"/><circle class="v" cx="8" cy="8" r="6" stroke-dasharray="' + c.toFixed(2) + '" stroke-dashoffset="' + (c * (1 - pct / 100)).toFixed(2) + '"/></svg>';
  }
  function conn() {
    const iv = installInfo();
    if (iv.state === "running" || iv.state === "paused") return '<button class="conn" data-act="sheet" data-sheet="install">' + miniRing(iv.pct) + "Installing " + iv.pct + "%</button>";
    return '<span class="conn"><i class="dot ok"></i>' + edLabel() + "</span>";
  }
  function ago(t) { const s = Date.now() / 1000 - t; return s < 60 ? "now" : s < 3600 ? Math.floor(s / 60) + "m" : s < 86400 ? Math.floor(s / 3600) + "h" : Math.floor(s / 86400) + "d"; }
  const firstName = () => ((P().name || "").trim().split(/\s+/)[0] || "");

  /* ========================================================= onboarding == */
  const OB = ["welcome", "teach"];
  const PLATFORMS = [["tiktok", "TikTok"], ["reels", "Reels"], ["shorts", "Shorts"], ["youtube", "YouTube"]];
  const forced = (location.search.match(/[?&]ob=(\w+)/) || [])[1];
  if (forced && OB.includes(forced)) { A.ui.forceOnboarding = true; A.ui.obStep = forced; }
  function obStep() { const s = A.ui.obStep || (P().onboarding && P().onboarding.step) || "welcome"; return OB.includes(s) ? s : "welcome"; }
  function goStep(st) {
    const el = document.querySelector(".ob-step");
    const go = () => { A.ui.obStep = st; if (!S().offline) A.api.profile({ onboarding: { step: st } }).catch(() => {}); A.render(); window.scrollTo(0, 0); };
    if (el && !A.reduced) { el.classList.add("leave"); setTimeout(go, 240); } else go();
  }
  function obWelcome() {
    const iv = installInfo();
    return '<div class="ob-step">' + mark("xl") +
      '<div class="col" style="gap:12px"><h1 class="t-hero" tabindex="-1">CreatorCut OS</h1><p class="t-body">Your AI video editor. It copies the editing of the videos you show it.</p></div>' +
      '<div class="field"><label class="t-label" for="ob-name">Your name</label><input class="input" id="ob-name" style="height:46px;font-size:16px" value="' + esc(A.ui.obName != null ? A.ui.obName : P().name || "") + '" data-input="obName" data-enter="obNameGo" data-free autocomplete="given-name"></div>' +
      (iv.state === "error" ? '<div class="well t-small" style="padding:12px 14px">' + esc(S().install.error || "Setup stopped.") + " Type <b>continue setup</b> in " + agent() + ".</div>" : "") +
      '<div class="ob-actions"><button class="btn btn-ink btn-lg" data-act="obNameGo">Continue' + icon("arrow") + "</button>" +
      (["running", "paused"].includes(iv.state) ? '<button class="btn btn-text" data-act="sheet" data-sheet="install">' + miniRing(iv.pct) + "Installing " + iv.pct + "%</button>" : "") + "</div></div>";
  }
  function glyph(k) {
    const phone = (inner) => '<svg class="glyph" viewBox="0 0 52 72" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="10" y="3" width="32" height="66" rx="7"/>' + inner + "</svg>";
    if (k === "tiktok") return phone('<path d="M18 54h12M18 59h8" opacity=".5"/><circle cx="35" cy="32" r="1.8" fill="currentColor" stroke="none"/><circle cx="35" cy="39" r="1.8" fill="currentColor" stroke="none"/><circle cx="35" cy="46" r="1.8" fill="currentColor" stroke="none"/>');
    if (k === "reels") return phone('<rect x="17" y="24" width="18" height="18" rx="5"/><path d="M24 29.5v7l5.5-3.5z" fill="currentColor" stroke="none"/>');
    if (k === "shorts") return phone('<path d="M22 28v13l10-6.5z" fill="currentColor" stroke="none"/><path d="M17 54h18" opacity=".5"/>');
    return '<svg class="glyph" viewBox="0 0 52 72" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="21" width="48" height="30" rx="5"/><path d="M22 30v12l9-6z" fill="currentColor" stroke="none"/><path d="M18 58h16" opacity=".5"/></svg>';
  }

  /* ------------------------------------------- onboarding: first preset -- */
  function obTeach() {
    const refs = (S().references && S().references.items) || [];
    const ups = Object.values(A.ui.uploads).filter((u) => u.kind === "reference" && !u.project);
    const saved = presets().length > 0;
    return '<div class="ob-step wide"><div class="col" style="gap:10px"><span class="t-label">Last step</span><h1 class="t-1" tabindex="-1">Show it what to copy</h1>' +
      '<p class="t-body">Add a video edited the way you want yours. It is studied frame by frame, then you save it as a preset.</p></div>' +
      '<div class="sx-ref"><div class="urlbar big">' + icon("link") + '<input type="url" inputmode="url" placeholder="Add reference link from TikTok, Instagram or YouTube" aria-label="Reference link" value="' + esc(A.ui.urlDraft || "") + '" data-input="urlDraft" data-enter="addUrl" data-free autocomplete="off" spellcheck="false"><button class="btn btn-ink btn-sm" data-act="addUrl">Add</button></div>' +
      '<label class="sx-file" data-drop="reference">' + icon("upload") + 'Add reference video file<input type="file" accept="video/*,.mov,.mp4" data-change="files" data-kind="reference"></label>' +
      ups.map((u) => '<div class="rx up"><div class="rx-head"><span class="rx-src">' + icon("film") + "<b>" + esc(u.name || "Uploading") + '</b></span><span class="t-mono">' + (u.stalled ? "STUCK" : u.progress >= 1 ? "PROCESSING" : Math.round(u.progress * 100) + "%") + '</span><button class="icon-btn" data-act="cancelUpload" data-id="' + u.id + '" aria-label="Remove upload">' + icon("x") + '</button></div><div class="rx-total"><i style="width:' + Math.round(u.progress * 100) + '%"></i></div></div>').join("") +
      refs.map((r) => refCard(r, null)).join("") + "</div>" +
      '<div class="ob-actions"><button class="btn btn-text" data-act="obGo" data-to="welcome">' + icon("back") + 'Back</button><span class="spacer"></span>' +
      (saved ? '<button class="btn btn-ink btn-lg" data-act="finishOb">Continue' + icon("arrow") + "</button>" : '<button class="btn btn-text" data-act="finishOb">Skip</button>') + "</div></div>";
  }
  function onboarding() {
    const st = obStep(), idx = OB.indexOf(st);
    const body = { welcome: obWelcome, teach: obTeach }[st]();
    const intro = !A.ui.introSeen ? '<div class="intro" aria-hidden="true" data-static="intro"><div class="stage-i"><span class="dot-i"></span>' + mark("xl") + '<span class="wordmark">' + NAME + "<span>OS</span></span></div></div>" : "";
    return intro + '<div class="ob"><div class="ob-progress" style="width:' + ((idx + 1) / OB.length) * 100 + '%"></div><div class="ob-top">' + brand() + '<span class="spacer"></span>' + conn() + "</div>" +
      '<main class="ob-body" data-key="ob-' + st + '">' + body + "</main><div></div></div>";
  }

  /* ============================================================== shell == */
  const NAV = [["home", "Home", "home"], ["studio", "Studio", "edit"], ["videos", "My videos", "library"]];
  function shell(content, route) {
    const idx = Math.max(0, NAV.findIndex((n) => n[0] === route));
    const on = NAV.some((n) => n[0] === route);
    const side = '<nav class="side" aria-label="CreatorCut OS">' + brand() +
      '<div class="rail"><i class="ind" style="transform:translateY(' + idx * 40 + "px);opacity:" + (on ? 1 : 0) + '"></i>' +
      NAV.map(([k, l, ic], i) => '<a class="nav" href="#/' + k + '"' + (route === k ? ' aria-current="page"' : "") + ">" + icon(ic) + l + '<span class="kbd k">' + (i + 1) + "</span></a>").join("") + "</div>" +
      '<div class="foot">' + conn() + '<button class="nav" data-act="palette">' + icon("search") + 'Search<span class="spacer"></span><span class="kbd">⌘K</span></button></div></nav>';
    const tabs = '<nav class="tabs" aria-label="CreatorCut OS">' + NAV.map(([k, l, ic]) => '<a class="tab" href="#/' + k + '"' + (route === k ? ' aria-current="page"' : "") + ">" + icon(ic) + l + "</a>").join("") + "</nav>";
    return '<div class="app">' + side + '<div><header class="top">' + brand() + '<span class="spacer"></span></header>' +
      '<main class="main">' + content + "</main></div></div>" + tabs;
  }

  /* =============================================================== home == */
  // a Mac folder: the back with its tab, the video peeking out, the front panel (Big Sur blue)
  const FOLDER_BACK = '<svg class="fb" viewBox="0 0 200 160" aria-hidden="true"><path d="M14 20c0-9 7-16 16-16h46c6 0 10 2 13 6l9 12h72c9 0 16 7 16 16v10H14z" fill="#3f93e4"/><rect x="8" y="34" width="184" height="122" rx="18" fill="#4fa0ea"/></svg>';
  const FOLDER_FRONT = '<svg class="ff" viewBox="0 0 200 104" preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="ffg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a7d7fb"/><stop offset="1" stop-color="#78baf2"/></linearGradient></defs>' +
    '<rect x="8" y="4" width="184" height="98" rx="18" fill="url(#ffg)"/><rect x="8" y="4" width="184" height="2" fill="#fff" opacity=".55"/><rect x="22" y="86" width="156" height="2" rx="1" fill="#3f93e4" opacity=".22"/><rect x="22" y="92" width="156" height="2" rx="1" fill="#3f93e4" opacity=".15"/></svg>';
  function videoTile(p) {
    const act = S().activity || {};
    const busy = (p.busy || (act.running && act.project === p.name) || ["queued", "new", "transcribed", "planned", "cut"].includes(p.status)) && p.status !== "draft";
    const poster = (p.versions && p.versions.length && p.versions[p.versions.length - 1].poster) || (p.media || []).filter((m) => m.kind === "raw").map((m) => m.thumb)[0] || p.poster || "";
    const vid = p.preview || p.latest;
    const label = p.status === "finished" ? "Saved" : busy ? "Creating" : p.preview ? "Ready" : "";
    return '<a class="vtile spot mac" href="#/studio/' + encodeURIComponent(p.name) + '" data-key="' + esc(p.name) + '">' + FOLDER_BACK + '<div class="frame">' + (poster ? '<img alt="" loading="lazy" src="' + esc(poster) + '">' : vid ? '<video class="still" muted playsinline preload="metadata" src="' + esc(vid) + '#t=0.5"></video>' : "") +
      (vid ? '<video muted loop playsinline preload="none" data-hover src="' + esc(vid) + '"></video>' : "") + "</div>" + FOLDER_FRONT + (label ? '<span class="badge">' + (busy ? '<i class="dot live"></i>' : "") + label + "</span>" : "") +
      '<div class="meta"><b>' + esc(p.title || p.name) + '</b><span class="t-tiny">' + esc(p.timeline && p.timeline.duration ? A.fmtTime(p.timeline.duration) : "") + "</span></div></a>";
  }
  function learningLoop() {
    const l = S().learning_progress || {}, n = Math.max(0, Number(l.completed || 0)), pct = Math.min(n, 10) * 10;
    if(l.unavailable) return '<p class="metadata-issue" role="status">Learning progress is temporarily unavailable. Your editing preferences have not been reset.</p>';
    return '<section class="learning-loop" data-static="learning-' + n + '" aria-label="Your AI editor learning loop: ' + pct + '% of your first ten completed edits">' +
      '<div class="learning-orbit" style="--progress:' + pct + '"><svg viewBox="0 0 120 120" role="img" aria-label="' + pct + '%"><circle class="loop-track" cx="60" cy="60" r="50"/><circle class="loop-arc" cx="60" cy="60" r="50" pathLength="100"/></svg><span class="loop-number">' + pct + '<small>%</small></span><span class="loop-satellites" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></span></div>' +
      '<div class="loop-copy"><span class="t-mono">LEARNING LOOP</span><h2>Your AI editor</h2><p>' + (n >= 10 ? 'Your style keeps evolving. Keep creating.' : 'Keep editing videos to help your AI editor learn your style.') + '</p><span class="loop-detail">' + Math.min(n,10) + ' / 10 completed videos</span><span class="loop-note">Your editing feedback is saved behind the scenes.<br>Based on completed videos. Learning continues after the first ten.</span></div></section>';
  }
  function home() {
    const name = firstName();
    const words = ("Welcome" + (name ? ", " + name : "") + ".").split(" ");
    const vids = (S().projects || []).filter((p) => !p.parent && p.status !== "draft");
    const ups = (S().updates || []).slice(0, 5);
    const ps = presets();
    const conn = edLabel().toUpperCase();
    let n = 0;
    const idx = () => '<span class="t-mono">' + String(++n).padStart(2, "0") + "</span>";
    return '<div class="page home page-in">' +
      '<div class="welcome2" data-static="welcome-' + esc(name) + "-" + vids.length + "-" + ps.length + '">' +
      '<span class="kicker t-mono"><i class="dot' + (ed().connected ? " ok" : "") + '"></i>' + conn + " · " + vids.length + " VIDEO" + (vids.length === 1 ? "" : "S") + " · " + ps.length + " PRESET" + (ps.length === 1 ? "" : "S") + "</span>" +
      '<h1 class="hello">Welcome' + (name ? ', <span class="nm">' + esc(name) + ".</span>" : ".") + "</h1>" +
      '<p class="sub">Edit your next <span class="rot" data-words="video,reel,short,story"><span>video</span></span> with CreatorCut AI agent.</p></div>' +
      '<button class="launch tilt spot" data-act="startVideo"><div><h2>New video</h2><p>Footage, a reference, a few words. The agent does the edit.</p><span class="go">Open Studio' + icon("arrow") + '</span></div>' +
      '<div class="sim" aria-hidden="true" data-static="sim">' +
        '<div class="sim-phone"><i class="isl"></i><div class="sim-shot"></div><i class="rx-line"></i></div>' +
        '<div class="sim-side"><div class="sim-status"><div class="roll"><span>Removing bad takes</span><span>Cutting silences</span><span>Syncing captions</span><span>Adding motion graphics</span><span>Mixing music</span><span>Rendering</span></div><b class="sim-pct"></b></div>' +
        '<div class="sim-wave">' + Array.from({ length: 36 }, (_, i) => '<i style="animation-delay:' + ((i * 41) % 100) / 100 + 's"></i>').join("") + "</div>" +
        '<div class="sim-lanes"><div class="l"><i style="left:2%;width:26%"></i><i style="left:31%;width:18%"></i><i style="left:53%;width:22%"></i><i style="left:79%;width:19%"></i></div>' +
        '<div class="l b"><i style="left:4%;width:9%"></i><i style="left:16%;width:11%"></i><i style="left:31%;width:8%"></i><i style="left:43%;width:12%"></i><i style="left:60%;width:9%"></i><i style="left:74%;width:13%"></i></div>' +
        '<div class="l c"><i style="left:10%;width:6%"></i><i style="left:47%;width:8%"></i><i style="left:83%;width:7%"></i></div><i class="ph"></i></div></div></div></button>' +
      '<section class="section xpl" aria-label="How it works"><div class="section-head"><h2 class="t-3 idx">' + idx() + 'How it works</h2><span class="t-tiny">30 seconds</span></div>' +
      '<div class="xpl-v" data-static="explainer"><video src="kit/studio/app/explainer.mp4" poster="kit/studio/app/explainer.jpg" autoplay muted loop playsinline preload="auto"></video></div></section>' + learningLoop() +
      (vids.length ? '<section class="section"><div class="section-head"><h2 class="t-3 idx">' + idx() + 'Recent</h2><a class="link t-small" href="#/videos">All videos</a></div><div class="row-scroll">' + vids.slice(0, 10).map(videoTile).join("") + "</div></section>" : "") +
      '<section class="section"><div class="section-head"><h2 class="t-3 idx">' + idx() + 'Presets</h2></div>' +
      '<div class="plist">' + ps.map((s) => presetTile(s)).join("") + newPresetTile() + "</div></section>" +
      (ups.length ? '<section class="section"><h2 class="t-3 idx">' + idx() + 'Activity</h2><div class="feed2">' + ups.map((u) => { const pj = u.project && projectById(u.project); const ps_ = u.style && styleById(u.style); const th = pj ? ((pj.versions || []).slice(-1)[0] || {}).poster || pj.poster || "" : ps_ && ps_.frames && ps_.frames[0] || ""; return '<a class="upd" data-key="u' + u.id + '" ' + (pj ? 'href="#/studio/' + encodeURIComponent(u.project) + '"' : "") + ">" + (th ? '<img class="uth" alt="" src="' + esc(th) + '">' : '<i class="pip"></i>') + '<span class="txt">' + (pj ? "<b>" + esc(pj.title) + "</b> " : "") + esc(u.text) + '</span><span class="t-mono when">' + ago(u.time) + "</span></a>"; }).join("") + "</div></section>" : "") + "</div>";
  }

  function updateBar() {
    const u = S().update || {};
    if (A.updating || u.status === "downloading" || u.status === "installing" || (A.updating && u.status === "done"))
      return '<div class="upbar busy" role="status"><div class="upbar-t"><b>Updating CreatorCut OS</b><span>' + esc(u.step || "Starting…") + '</span></div>' +
        '<div class="upbar-p"><i style="width:' + Math.max(3, Math.round((u.pct || 0) * 100)) + '%"></i></div><span class="t-tiny">Your videos, presets and settings stay exactly as they are.</span></div>';
    if (u.status === "failed")
      return '<div class="upbar"><div class="upbar-t"><b>The update didn’t finish</b><span>' + esc(u.error || "") + '</span></div><button class="btn btn-soft btn-sm" data-act="installUpdate">Try again</button></div>';
    if (!u.available) {
      if (A.route().name !== 'home') return '';
      const checked = !!(u.configured && u.checked && !u.error);
      const title = checked ? 'Latest update installed' : u.error ? 'Couldn’t check for updates' : u.configured === false ? 'Updates are not connected yet' : 'Checking for updates…';
      const sub = checked ? 'Version ' + (S().version || u.current || '') + ' · You’re up to date.' : u.error ? 'I’ll check again automatically. You can keep editing.' : u.configured === false ? 'The release connection needs to be set up.' : 'Your Studio checks for new versions automatically.';
      return '<section class="upbar current" aria-label="App updates"><span class="update-symbol">' + icon(checked ? 'check' : 'redo') + '</span><div class="upbar-t"><b>CreatorCut updates</b><span>' + esc(sub) + '</span></div><button class="btn btn-soft btn-sm update-current" disabled>' + esc(title) + '</button></section>';
    }
    return '<div class="upbar available" role="status"><span class="update-symbol">' + icon('download') + '</span><div class="upbar-t"><b>A new CreatorCut version is ready · v' + esc(u.latest) + '</b><span>' + esc(u.notes || "New features and fixes.") + '</span><small>Your videos, presets and editing memory are kept.</small></div><button class="btn btn-ink btn-sm" data-act="installUpdate">Install update</button></div>';
  }

  function flip(frames, cls) {
    return frames && frames.length ? '<div class="flip' + (cls ? " " + cls : "") + '" data-flip>' + frames.map((f, i) => '<img alt="" loading="lazy" src="' + esc(f) + '"' + (i ? "" : ' class="on"') + ">").join("") + "</div>" : "";
  }
  function presetMeta(s) {
    if(s.recipe_kind === 'brief') return 'Saved instructions & references';
    if(s.recipe_kind === 'reviewed') return 'From your finished edit';
    const rd = s.readout || [];
    const get = (l) => (rd.find((r) => r.label === l) || {}).value;
    return [get("Font"), get("Cuts")].filter(Boolean).join(" · ");
  }
  function presetTile(s, opts) {
    opts = opts || {};
    return '<button class="pmini" data-key="p-' + esc(s.id) + '" data-act="' + (opts.act || "openStyle") + '" data-id="' + esc(s.id) + '"' + (opts.pressed != null ? ' aria-pressed="' + !!opts.pressed + '"' : "") + ">" +
      '<span class="pm-f">' + flip(s.frames) + '</span><span class="pm-t"><b>' + esc(s.name) + '</b><span class="t-mono">' + esc(presetMeta(s).toUpperCase()) + "</span></span>" + icon("arrow") + "</button>";
  }
  // which saved preset a video copies (shown on the video), or its own reference
  function presetBadge(p) {
    const s = styleById(p.settings && p.settings.style);
    const ref = (p.refs || [])[0];
    if (s && s.yours !== false) return '<button class="ox-preset" data-act="openStyle" data-id="' + esc(s.id) + '">' + (s.frames && s.frames[0] ? '<img alt="" src="' + esc(s.frames[0]) + '">' : "") + '<span><span class="t-mono">PRESET</span><b>' + esc(s.name) + "</b></span>" + icon("arrow") + "</button>";
    if (ref) return '<div class="ox-preset static">' + (ref.thumb ? '<img alt="" src="' + esc(ref.thumb) + '">' : "") + '<span><span class="t-mono">COPIES YOUR REFERENCE</span><b>' + esc(ref.title || ref.name || "Reference video") + "</b></span></div>";
    return "";
  }
  // the learning loop, visible: what this preset learned from the creator's feedback
  function newPresetTile() {
    return '<button class="pmini new" data-act="startVideo"><span class="pm-f">' + icon("plus") + '</span><span class="pm-t"><b>New preset</b><span class="t-mono">FROM A REFERENCE VIDEO</span></span></button>';
  }

  /* ============================================================ studio == */
  /* One page per video: make it (footage, reference, brief) → it's being made → watch, chat, save. */
  const STAGES = [["prepare", "Reading your footage", "Footage read"], ["transcribe", "Listening to every word", "Every word transcribed"],
    ["plan", "Finding bad takes", "Bad takes found"], ["cut", "Deleting bad takes and cutting silences", "Bad takes deleted · silences cut out"],
    ["beats", "Adding captions and animations", "Captions and animations added"], ["broll", "Placing B-roll and music", "B-roll and music placed"],
    ["preview", "Rendering your video", "Rendered"]];
  function stageIndex(p) {
    const act = S().activity || {};
    const order = STAGES.map((s) => s[0]);
    let cur = act.running && act.project === p.name ? order.indexOf(act.cmd === "new" ? "prepare" : act.cmd === "check" ? "broll" : act.cmd === "media" || act.cmd === "reference" ? "prepare" : act.cmd) : -1;
    const byStatus = { queued: 0, new: 1, transcribed: 2, planned: 3, cut: 4, previewed: 7 }[p.status];
    if (cur < 0 && byStatus != null) cur = byStatus;
    return Math.max(0, cur);
  }
  const rawFrames = (p) => { const raw = (p.media || []).filter((m) => m.kind === "raw"); const strip = raw.flatMap((m) => m.strip || []); return strip.length ? strip : raw.map((m) => m.thumb).filter(Boolean); };

  /* ---- 01 footage */
  function mediaZones(p) {
    const zones = [["raw", "footage", "Raw footage", "video/*,.mov,.mp4"], ["broll", "broll", "B-roll and photos", "video/*,image/*"], ["music", "music", "Music", "audio/*"]];
    const ups = Object.values(A.ui.uploads).filter((u) => u.project === p.name);
    return '<div class="sx-zones">' + zones.map(([kind, want, title, accept]) => {
      const items = (p.media || []).filter((m) => m.kind === kind || (kind === "broll" && m.kind === "image"));
      const up = ups.filter((u) => u.kind === kind);
      const empty = !items.length && !up.length;
      return '<section class="sx-zone' + (kind === "raw" ? " main" : "") + (empty ? " empty" : "") + '" data-drop="' + want + '" data-project="' + esc(p.name) + '">' +
        '<label class="sx-zone-add">' + icon(kind === "music" ? "music" : kind === "raw" ? "upload" : "film") + "<b>" + title + "</b>" +
        '<input type="file" multiple accept="' + accept + '" data-change="binFiles" data-kind="' + want + '" data-project="' + esc(p.name) + '"></label>' +
        (empty ? "" : '<div class="sx-items">' + items.map((m) => '<div class="zitem" data-key="' + m.id + '">' + (m.thumb ? '<img alt="" src="' + esc(m.thumb) + '">' : '<span class="aud">' + icon("music") + '<i class="t-tiny">' + esc(m.name) + "</i></span>") +
          (m.duration ? '<span class="d">' + A.fmtTime(m.duration) + "</span>" : "") + '<button class="x" data-act="removeMedia" data-id="' + m.id + '" aria-label="Remove">' + icon("x") + "</button></div>").join("") +
          up.map((u) => '<div class="zitem up' + (u.stalled || u.state === "error" ? " stuck" : "") + '" title="' + esc(u.stalled ? "Stuck. Remove it and drop it again." : u.progress >= 1 ? "Processing…" : u.name || "") + '">' +
            '<span class="spinner"></span><i class="pbar" style="width:' + Math.round(u.progress * 100) + '%"></i>' +
            '<button class="x" data-act="cancelUpload" data-id="' + u.id + '" aria-label="Remove upload">' + icon("x") + "</button></div>").join("") + "</div>") + "</section>";
    }).join("") + "</div>";
  }

  /* ---- 02 reference: live scan, then what was really measured */
  const TRACKS = [["Fetching the video", 0, 0.3, "url"], ["Speech, pace and cuts", 0.3, 0.48], ["Colour and sound", 0.48, 0.6],
    ["Every word on screen", 0.6, 0.78], ["Text styles and motion", 0.78, 0.89], ["Exact fonts", 0.89, 0.96], ["Style kit", 0.96, 1]];
  function refMedia(r, busy) {
    const frames = r.frames || [];
    const inner = r.video ? '<video autoplay muted loop playsinline preload="auto" src="' + esc(r.video) + '"></video>'
      : frames.length ? '<div class="flip" data-flip>' + frames.map((f, i) => '<img alt="" src="' + esc(f) + '"' + (i ? "" : ' class="on"') + ">").join("") + "</div>"
      : r.thumb ? '<img alt="" src="' + esc(r.thumb) + '">' : '<span class="rx-wait"></span>';
    return '<div class="rx-media' + (busy ? " scanning" : "") + '">' + inner + (busy ? '<i class="rx-line"></i><i class="rx-grid"></i><span class="rx-c tl"></span><span class="rx-c tr"></span><span class="rx-c bl"></span><span class="rx-c br"></span>' : "") + "</div>";
  }
  function refScan(r) {
    const done = r.status === "done";
    const p = done ? 1 : r.status === "queued" ? 0 : r.progress || 0;
    const tracks = TRACKS.filter((t) => t[3] !== "url" || r.kind === "url");
    return '<div class="rx-scan"><div class="rx-top"><span class="t-mono">' + (done ? "REFERENCE ANALYZED" : "ANALYSING REFERENCE") + '</span><b class="t-num" data-tween="' + Math.round(p * 100) + '">' + Math.round(p * 100) + '</b><small>%</small></div>' +
      '<div class="rx-total"><i style="width:' + Math.max(2, p * 100) + '%"></i></div>' +
      '<div class="rx-tracks">' + tracks.map(([l, a, b]) => { const k = A.clamp((p - a) / (b - a), 0, 1); return '<div class="rx-t' + (k >= 1 ? " done" : k > 0 ? " now" : "") + '"><span>' + l + '</span><i><b style="width:' + Math.round(k * 100) + '%"></b></i><em>' + (k >= 1 ? icon("check") : k > 0 ? Math.round(k * 100) + "%" : "") + "</em></div>"; }).join("") + "</div>" +
      (done ? "" : '<div class="rx-msg t-mono" aria-live="polite"><span data-key="m-' + esc(r.message) + '" data-type="' + esc(r.message || "Starting…") + '"></span></div>') + "</div>";
  }
  function readoutRows(rows) {
    const groups = [];
    rows.forEach((row) => { let g = groups.find((x) => x[0] === row.group); if (!g) groups.push(g = [row.group, []]); g[1].push(row); });
    return groups.map(([g, rs], gi) => '<div class="ra-g" style="--gi:' + gi + '"><span class="t-mono ra-gh">' + esc(g.toUpperCase()) + "</span>" + rs.map((row, i) => {
      if (row.font && row.font_url) A.ensureFont(row.font, [row.font_url]);
      const val = row.font ? '<span class="ra-font" style="font-family:\'aie-' + esc(row.font) + '\',var(--text)">' + esc(row.value) + "</span>" : esc(row.value);
      return '<div class="ra-row" style="--i:' + i + '"><span class="k">' + esc(row.label) + '</span><span class="v">' + val +
        (row.swatches ? '<span class="sw">' + row.swatches.map((c) => '<i style="background:' + esc(c) + '"></i>').join("") + "</span>" : "") + "</span>" +
        (row.bar != null ? '<i class="ra-bar"><b style="--w:' + Math.round(row.bar * 100) + '%"></b></i>' : "") + "</div>";
    }).join("") + "</div>").join("");
  }
  /* the measurements, folded away until asked for */
  function details(key, rows) {
    const open = !!(A.ui.openDetails || {})[key];
    return '<div class="ra-more"><button class="link t-small" data-act="toggleDetails" data-k="' + esc(key) + '" aria-expanded="' + open + '">' + (open ? "Hide details" : "Show details") + icon("arrow", 'style="transform:rotate(' + (open ? -90 : 90) + 'deg)"') + "</button>" +
      (open ? '<div class="ra-rows">' + readoutRows(rows) + "</div>" : "") + "</div>";
  }
  function presetNameFrom(r) {
    const t = (r.name || "").replace(/^Video by\s+/i, "").replace(/\.(mp4|mov|m4v|webm)$/i, "").trim();
    return t.slice(0, 32);
  }
  function refCard(r, p) {
    const busy = !["done", "error"].includes(r.status);
    const saved = r.used_by && styleById(r.used_by);
    const naming = A.ui.namingRef === r.id;
    const job = A.ui.savingRef && A.ui.savingRef.ref === r.id ? (S().jobs || []).find((j) => j.id === A.ui.savingRef.job) : null;
    const savingNow = job && ["queued", "running", "waiting"].includes(job.state);
    const head = '<div class="rx-head"><span class="rx-src">' + (r.kind === "url" ? icon("link") : icon("film")) + "<b>" + esc(r.name || r.host || "Reference") + "</b>" + (r.host ? '<span class="t-mono">' + esc(r.host.toUpperCase()) + "</span>" : "") + '</span><button class="icon-btn" data-act="' + (p ? "removeVideoRef" : "removeRef") + '" data-id="' + esc(r.id) + '" aria-label="Remove reference">' + icon("x") + "</button></div>";
    let side;
    if (r.status === "error") side = '<div class="rx-err"><b>Couldn’t analyse this reference.</b><span class="t-small">' + esc(r.message) + '</span><button class="btn btn-line btn-sm" data-act="retryRef" data-id="' + esc(r.id) + '">Try again</button></div>';
    else if (busy) side = refScan(r);
    else side = '<div class="ra done">' + refScan(r) +
      ((r.readout || []).length ? details("rd-" + r.id, r.readout) : '<p class="t-small">Only the cover could be read from this link, so there is nothing to measure. Add the video file instead.</p>') +
      '<div class="ra-save">' + (saved ? '<span class="chip on">' + icon("check") + "Saved as preset · " + esc(saved.name) + "</span>"
        : savingNow ? '<span class="chip"><span class="spinner"></span>Saving preset</span>'
        : naming ? '<div class="namebar"><input class="input" value="' + esc(A.ui.refName != null ? A.ui.refName : presetNameFrom(r)) + '" placeholder="Preset name" data-input="refName" data-enter="saveRefPreset" data-id="' + esc(r.id) + '" data-project="' + esc(p ? p.name : "") + '" data-free aria-label="Preset name"><button class="btn btn-ink btn-sm" data-act="saveRefPreset" data-id="' + esc(r.id) + '" data-project="' + esc(p ? p.name : "") + '">Save</button><button class="btn btn-text btn-sm" data-act="cancelRefName">Cancel</button></div>'
        : (r.readout || []).length ? '<button class="btn btn-line btn-sm" data-act="nameRefPreset" data-id="' + esc(r.id) + '">' + icon("plus") + "Save this style as a preset</button>" : "") + "</div></div>";
    return '<article class="rx" data-key="rx-' + esc(r.id) + '">' + head + '<div class="rx-body">' + refMedia(r, busy) + side + "</div></article>";
  }
  function refSection(p) {
    const refs = p.refs || [];
    const ups = Object.values(A.ui.uploads).filter((u) => u.project === p.name && u.kind === "reference");
    const ps = presets();
    const chosen = styleById(p.settings.style);
    return '<div class="sx-ref">' +
      '<div class="urlbar big">' + icon("link") + '<input type="url" inputmode="url" placeholder="Add reference link from TikTok, Instagram or YouTube" aria-label="Reference link" data-enter="addRefLink" data-free autocomplete="off" spellcheck="false"><button class="btn btn-ink btn-sm" data-act="addRefLinkBtn">Add</button></div>' +
      '<label class="sx-file" data-drop="vref" data-project="' + esc(p.name) + '">' + icon("upload") + "Add reference video file" + '<input type="file" accept="video/*,.mov,.mp4" data-change="refFile" data-project="' + esc(p.name) + '"></label>' +
      ups.map((u) => '<div class="rx up"><div class="rx-head"><span class="rx-src">' + icon("film") + "<b>" + esc(u.name || "Uploading") + '</b></span><span class="t-mono">' + (u.stalled ? "STUCK" : u.progress >= 1 ? "PROCESSING" : Math.round(u.progress * 100) + "%") + '</span><button class="icon-btn" data-act="cancelUpload" data-id="' + u.id + '" aria-label="Remove upload">' + icon("x") + '</button></div><div class="rx-total"><i style="width:' + Math.round(u.progress * 100) + '%"></i></div></div>').join("") +
      refs.map((r) => refCard(r, p)).join("") +
      (ps.length ? '<div class="sx-presets"><span class="t-label">Use saved preset</span><div class="plist sx-plist">' + ps.map((s) => presetTile(s, { act: "choosePreset", pressed: p.settings.style === s.id })).join("") + "</div></div>" : "") +
      (chosen && chosen.yours ? '<span class="t-tiny">Uses your saved preset “' + esc(chosen.name) + "”.</span>" : "") + "</div>";
  }
  const BRIEF_EXAMPLE = "STYLE: Use my reference for typography and layout. Aim for a clean product demo, with white UI panels and one accent colour.\nCUTS & PACING: Keep my strongest complete takes. Remove repeated starts and tighten gaps, while keeping natural word endings. Leave extra time for the steps viewers need to read.\nCOLOUR: Keep skin natural. Preserve the original colour unless I ask for a change. If I say \u201cmake it cinematic\u201d, change the look exactly on my finger snap.\nCAPTIONS: Two lines at most, clear of my face and the app controls. Emphasize the key term rather than every word.\nANIMATION & PLACEMENT: When I say \u201copen the app\u201d, show its real interface on the right. Pop it in, highlight the button I mention, and keep the complete prompt visible as it types.\nMOTION GRAPHICS: When I say \u201csave the skill\u201d, show three labelled cards moving into a folder over my lower body. Keep my face visible. Let the folder settle, then exit on the next sentence.\nB-ROLL: Show the matching clip on the words it explains. Use real playing video for the montage. Avoid repeating the same animation for different examples.\nMUSIC & SOUND: Energetic instrumental, low beneath my voice. Small clicks for button presses, a soft accent for the folder closing. Avoid loud repeated whooshes.\nENDING: Use my spoken CTA word, with a simple animated entrance and enough time to read.\nCHANGE THESE EXAMPLES to suit your footage and reference. Include timestamps or the exact spoken words where timing matters.";
  function studioDraft(p) {
    const hasFootage = (p.media || []).some((m) => m.kind === "raw");
    const refs = p.refs || [];
    const analysing = refs.some((r) => !["done", "error"].includes(r.status));
    const uploading = Object.values(A.ui.uploads).some((u) => u.project === p.name);
    const named = !!(p.title && p.title !== "Untitled video");
    const updating = ['downloading','installing'].includes((S().update || {}).status);
    const why = !hasFootage ? "Add your raw footage first." : uploading ? "Waiting for uploads." : updating ? "CreatorCut is updating. Your instructions are saved." : "";
    let start = (A.ui.editStarts || {})[p.name];
    if (start && start.state === 'sent' && Date.now()/1000 - start.delivered > 45) {
      start = { ...start, state:'uncertain', error:'The request was delivered, but editing has not started. I have not received a start confirmation. Do not resend until you check the conversation; it may already contain the request.' };
      A.ui.editStarts[p.name] = start; A.saveUI();
    }
    const note = !why ? (start && start.state === 'sent' ? "Request delivered. Waiting for the editor to start." : A.nativeChat && A.nativeChat.available ? "Starts your edit in this conversation." : "Automatic start is unavailable in this preview. Your files and instructions are saved.") : "";
    const step = (n, title, sub, body, on) => '<section class="sx-step' + (on ? " on" : "") + '"><div class="sx-n t-mono">' + n + '</div><div class="sx-c"><h2>' + title + "</h2>" + (sub ? '<p class="t-small">' + sub + "</p>" : "") + body + "</div></section>";
    return '<div class="sx page-in">' +
      '<header class="sx-head"><div class="studio-eyebrow"><span class="studio-signal"></span>CREATORCUT / STUDIO</div><a class="link t-small" href="#/videos">' + icon("back") + 'My videos</a><h1 class="t-1">Make a new video</h1></header>' +
      step("01", "Name your video", "So you can find it later in My videos and in your folder.",
        '<label class="sx-name' + (named ? " done" : "") + '"><span class="name-glyph" aria-hidden="true">' + icon('film') + '</span><input value="' + esc(named ? p.title : "") + '" placeholder="Give your next video a name…" maxlength="60" ' +
        'data-change="renameVideo" data-enter="renameVideo" data-free aria-label="Name your video"><span class="name-signal" aria-hidden="true"><i></i><i></i><i></i></span>' + (named ? '<span class="ok">' + icon("check") + "</span>" : "") + "</label>", true) +
      step("02", "Your footage", "Upload your raw footage. Add B-roll, photos and music if you have them.", mediaZones(p), true) +
      step("03", "Reference", "Optional. Your reference guides the look. Anything unclear uses CreatorCut Signature: bold white and yellow text with clean motion.", refSection(p), hasFootage || refs.length) +
      step("04", "Look", "The colour of your video.", '<div class="looks">' + LOOKS.map(([k, n, c]) => '<button class="look' + (((p.settings || {}).look || "natural") === k ? " on" : "") +
        '" data-act="setLook" data-k="' + k + '"><i style="background:' + c + '"></i>' + n + "</button>").join("") + '<span class="t-tiny">Or describe it in the chat: “warm and soft”.</span></div>', hasFootage) +
      step("05", "Tell me exactly what you want", "More detail helps shape a more tailored video. With less detail, I have to make more assumptions and the edit may feel more generic.",
        '<div class="brief-box"><label class="t-small" for="editing-brief">Your editing instructions <span class="t-tiny">(optional)</span></label>' +
        '<textarea id="editing-brief" rows="13" maxlength="20000" data-input="briefDraft" data-change="saveBrief" data-free aria-label="Detailed editing instructions" placeholder="' + esc(BRIEF_EXAMPLE) + '">' +
        esc(Object.prototype.hasOwnProperty.call(A.ui.briefDrafts || {}, p.name) ? A.ui.briefDrafts[p.name] : (p.brief || {}).prompt || '') + '</textarea>' +
        '<div class="brief-foot"><button class="link t-small" data-act="useBriefExample">Use and customize this example</button><span class="t-tiny" data-brief-status>' + esc((A.ui.briefStatus || {})[p.name] || 'Saved before the editor starts.') + '</span></div></div>', true) +
      savePresetCard(p, true) + '<div class="sx-go2">' + (why ? '<p class="t-small">' + why + "</p>" : "") +
        '<button class="make-btn' + (A.ui.launching === p.name ? " launch" : "") + '" data-act="makeNativeVideo" ' + (why || A.ui.savingMake || (start && ['sent','uncertain'].includes(start.state)) ? "disabled" : "") + '>' +
        '<span class="mb-glow"></span><span class="mb-ring"></span><span class="mb-label">' + 'Make my video' + '</span><span class="mb-go">' + icon("arrow") + "</span></button>" +
        (note ? '<span class="t-tiny">' + note + "</span>" : "") +
        (start && start.error ? '<div class="step-recovery" role="alert"><b>Editing has not been confirmed.</b><p>' + esc(start.error) + '</p><span class="t-tiny">Your footage and instructions are saved.</span></div>' : '') +
      '<p class="t-small">Want a change? Tell me in the chat.</p>' + "</div></div>";
  }

  /* ---- being made */
  function studioWorking(p) {
    const idx = stageIndex(p);
    const raw = (p.media || []).filter((m) => m.kind === "raw");
    const frames = rawFrames(p);
    const hero = p.poster || (raw[0] && (raw[0].hero || raw[0].thumb)) || frames[0] || "";
    const rawFrame = !hero && raw[0] && raw[0].url ? '<video class="ed-frame" muted playsinline preload="auto" src="' + esc(raw[0].url + '#t=0.001') + '" aria-label="Your footage"></video>' : '';
    const land = raw[0] && raw[0].w && raw[0].h && raw[0].w > raw[0].h;
    const act = S().activity || {};
    const mine = act.project === p.name;
    let pct = mine && act.running && act.percent != null ? Math.round(act.percent) : null;
    let total = Math.min(99, Math.round(((Math.min(idx, STAGES.length - 1) + (pct != null ? pct / 100 : 0.15)) / STAGES.length) * 100));
    // what's really happening right now: the reference studied first, the Studio's own edit job, or the engine
    const mk = (S().jobs || []).find((j) => j.kind === "make" && j.key === p.name && ["queued", "running", "waiting"].includes(j.state));
    const rj = (p.refs || []).find((r) => !["done", "error"].includes(r.status));
    let nowText = null;
    if (rj && !(mine && act.running)) { nowText = "Studying your reference first (" + Math.round((rj.progress || 0) * 100) + "%): fonts, colours, captions, cuts"; total = Math.max(total, Math.round((rj.progress || 0) * 12)); }
    else if (mk && mk.state !== "running" && !(mine && act.running)) nowText = "Getting your edit ready…";
    else if (mk && !(mine && act.running) && mk.message) { nowText = mk.message.replace(/…$/, "") + "…"; total = Math.max(total, Math.round((mk.progress || 0) * 100)); }
    const making = (S().jobs || []).some((j) => j.kind === "make" && j.key === p.name && ["queued", "running", "waiting"].includes(j.state));
    const lastEd = (p.chat || []).filter((m) => m.role === "editor").map((m) => m.time || 0).pop() || 0;
    let noEditor = !making && !(p.refs || []).some((r) => !["done", "error"].includes(r.status)) && !(mine && act.running) && Date.now() / 1000 - Math.max(act.updated || 0, lastEd) > 150;   // nothing running: say so, never a frozen number
    const wf = p.workflow || {};
    const nativeStage = !!wf.owner && ['analysing','planning','building','reviewing'].includes(wf.phase) && !(mine && act.running);
    const nativeLabel = {analysing:'Reading',planning:'Planning',building:'Editing',reviewing:'Reviewing'}[wf.phase] || 'Working';
    if (['analysing','planning','building','reviewing'].includes(wf.phase) && Date.now()/1000 - Number(wf.updated || 0) < 120) noEditor = false;
    if (wf.phase === "waiting_editor" || wf.phase === "blocked") { noEditor = true; }
    const health = p.progress_health || {};
    if (health.message) nowText = health.message;
    const awaitingChat = p.status === 'awaiting_editor' && (p.preparation || {}).state === 'ready' &&
      !['analysing','planning','building','reviewing','blocked'].includes(wf.phase) && !(mine && act.running) &&
      !['quiet','error'].includes(health.state);
    const attention = !awaitingChat && (health.state === 'quiet' || health.state === 'error' || noEditor);
    if (attention || awaitingChat) pct = null;
    if (awaitingChat) { nowText = 'Your footage is ready. In the chat, send “Make my video” to begin the creative edit.'; noEditor = false; }
    if (wf.message && !awaitingChat && !(attention && health.message)) nowText = wf.message;
    const log = mine ? (act.log || []).slice(-4) : [];
    const strip = frames.length ? frames : hero ? [hero] : [];
    const cutsOn = !nativeStage && idx >= 3, capsOn = !nativeStage && idx >= 4, gfxOn = !nativeStage && idx >= 5;
    const tlFrames = strip.map((f, i) => '<img alt="" class="' + (cutsOn && i % 4 === 2 ? "gone" : "") + '" src="' + esc(f) + '">').join("");
    const bars = (n, seed, on) => Array.from({ length: n }, (_, k) => { const l = (k * 97 + seed * 31) % 88, w = 5 + ((k * 53 + seed * 17) % 9); return '<i style="left:' + l + "%;width:" + w + "%;--d:" + (k * 0.09).toFixed(2) + 's"' + (on ? "" : ' class="off"') + "></i>"; }).join("");
    const wave = Array.from({ length: 64 }, (_, k) => '<i style="height:' + (18 + ((k * 37) % 70)) + "%;--d:" + ((k * 13) % 50) / 50 + 's"></i>').join("");
    const elapsedStart = Number(wf.started || (p.preparation || {}).started || p.generated_at || (p.created ? Date.parse(p.created)/1000 : 0));
    const elapsedNow = Number.isFinite(elapsedStart) && elapsedStart > 0 ? A.fmtTime(Math.max(0, Date.now()/1000 - elapsedStart)) : '—';
    const editor = '<div class="ed"><div class="ed-bar"><span class="dots"><b></b><b></b><b></b></span><span class="t-mono">' + esc((p.title || "untitled").toUpperCase()) + '</span><span class="spacer"></span><span class="t-mono rec"><i></i><span title="Elapsed task time"' + (Number.isFinite(elapsedStart) && elapsedStart > 0 ? ' data-elapsed="' + elapsedStart + '"' : '') + '>' + elapsedNow + '</span></span></div>' +
      '<div class="ed-main"><div class="ed-view' + (land ? " land" : "") + '">' + (hero ? '<img class="ed-blur" alt="" src="' + esc(hero) + '"><img class="ed-frame" alt="Your video" src="' + esc(hero) + '">' : rawFrame) +
        '<i class="ed-scan"></i><span class="ed-c tl"></span><span class="ed-c tr"></span><span class="ed-c bl"></span><span class="ed-c br"></span>' +
        (capsOn ? '<span class="ed-cap"><b></b><b></b></span>' : "") + (gfxOn ? '<span class="ed-card"></span>' : "") +
        '<span class="ed-pct t-mono">' + (awaitingChat ? "FOOTAGE READY" : health.state === "error" ? "STOPPED" : health.state === "quiet" ? "CHECK STEP" : noEditor ? "PAUSED" : pct != null ? pct + "%" : nativeStage ? nativeLabel.toUpperCase() : "WORKING") + "</span></div>" +
        '<div class="ed-insp"><span class="t-mono k">NOW</span><b data-key="st-' + (noEditor ? "wait" : idx) + '" data-type="' + esc(noEditor ? (nowText || "Your project is saved. Continue in the conversation beside Studio.") : nowText || STAGES[Math.min(idx, STAGES.length - 1)][1]) + '"></b>' +
        '<div class="ed-layers">' + [["Footage", true], ["Cuts", cutsOn], ["Captions", capsOn], ["Graphics", gfxOn], ["Colour + sound", !nativeStage && idx >= 6]].map(([n, on]) => '<span class="' + (on ? "on" : "") + '"><i></i>' + n + "</span>").join("") + "</div></div></div>" +
      '<div class="ed-tl"><div class="ed-ruler">' + Array.from({ length: 13 }, (_, k) => "<i></i>").join("") + "</div>" +
        '<div class="ed-row"><span class="t-mono">V1</span><div class="ed-clips">' + tlFrames + "</div></div>" +
        '<div class="ed-row"><span class="t-mono">TXT</span><div class="ed-bars cap">' + bars(9, 1, capsOn) + "</div></div>" +
        '<div class="ed-row"><span class="t-mono">GFX</span><div class="ed-bars gfx">' + bars(4, 3, gfxOn) + "</div></div>" +
        '<div class="ed-row"><span class="t-mono">A1</span><div class="ed-wave">' + wave + "</div></div><i class=\"ed-head\"></i></div></div>";
    return '<div class="gx page-in' + (awaitingChat ? ' awaiting-chat' : '') + '">' + editor +
      (awaitingChat ? '<div class="editor-handoff" role="status"><b>Your footage is ready to edit.</b><p>In the chat, type <strong>Make my video</strong> and press Send. I’ll use the files and instructions you saved here.</p><span>Your video edit has not started yet.</span></div>' : '') +
      '<div class="gx-info"><div class="gx-pct' + (nativeStage ? ' gx-phase' : '') + '"><b class="t-num">' + (awaitingChat ? "Ready" : attention ? "—" : pct != null ? pct : nativeStage ? nativeLabel : Math.min(idx + 1, STAGES.length)) + "</b><small>" + (awaitingChat ? "to edit" : attention ? "Needs attention" : pct != null ? "% of this step" : nativeStage ? 'In progress' : " / " + STAGES.length + " steps") + "</small></div>" +
      (awaitingChat ? '' : '<div class="gx-bar' + (nativeStage && !attention ? ' bar indet' : '') + '"><i style="width:' + Math.max(2, total) + '%"></i></div>') +
      '<ol class="gx-steps">' + (nativeStage ? '<li class="now"><span class="ic"><i class="pulse"></i></span><span>' + esc(wf.message || nativeLabel) + '</span></li>' : STAGES.map(([k, now, done], i) => '<li class="' + (i < idx ? "done" : i === idx ? "now" : "") + '" style="--i:' + i + '"><span class="ic">' + (i < idx ? icon("check") : i === idx ? '<i class="pulse"></i>' : "") + "</span><span>" + (i < idx ? done : now) + "</span>" +
        (i === idx && pct != null ? '<em class="t-mono">' + pct + "%</em>" : "") + "</li>").join("")) + "</ol>" +
      (log.length ? '<div class="worklog" aria-live="polite">' + log.map((l, i) => '<div style="opacity:' + (0.35 + (i / Math.max(1, log.length - 1)) * 0.65).toFixed(2) + '" data-key="lg-' + esc(l) + '"><i>›</i>' + esc(l) + "</div>").join("") + "</div>" : "") +
      (attention ? '<div class="step-recovery" role="status"><p class="t-small">' + esc(health.message || 'No editing worker is reporting activity. Your project is saved.') + '</p><button class="btn btn-line btn-sm" data-act="recoverStep">' + (A.nativeChat && A.nativeChat.available ? 'Check and resume this step' : 'Copy recovery request') + '</button></div>' : "") + "</div>" + revisionGuide(p) + "</div>";
  }
  /* under the video: the editor's notes, and what to say in the chat (the conversation itself is in Claude Code / Codex) */
  // "Save as preset": the look of this video, for every next video (only while it copies a reference, not a saved preset)
  function savePresetCard(p, beforeProduce) {
    const s = styleById(p.settings && p.settings.style);
    if (!beforeProduce && !(p.versions || []).length) return "";
    return '<div class="savepreset' + (beforeProduce ? ' savepreset-draft' : '') + '"><div class="sp-h"><span class="preset-mark" aria-hidden="true">' + icon('styles') + '</span><div><small>YOUR STYLE, READY TO REUSE</small><b>Save this as a preset</b><span>Name your instructions and references. Use them again on your next video.</span></div></div>' +
      '<div class="sp-row"><input placeholder="Name it, e.g. Calm & clean" maxlength="40" data-enter="' + (beforeProduce ? "saveBriefPreset" : "saveVideoPreset") + '" data-free aria-label="Preset name">' +
      '<button class="btn btn-ink btn-sm" data-act="' + (beforeProduce ? "saveBriefPreset" : "saveVideoPreset") + '">' + icon("plus") + "Save as preset</button>" + (!beforeProduce && s && s.yours ? '<button class="btn btn-line btn-sm" data-act="updateVideoPreset" data-id="' + esc(s.id) + '">Update “' + esc(s.name) + '”</button>' : "") + "</div></div>";
  }
  const LOOKS = [["reference", "Like the reference", "conic-gradient(#f0a4a4,#9cc4f5,#f6d38a,#f0a4a4)"], ["natural", "Original colour", "#d9c3b0"],
    ["bright", "Bright & airy", "#f4efe6"], ["warm", "Warm", "#e9a25d"], ["cinematic", "Cinematic", "#3f6f7a"], ["moody", "Moody", "#2b2a33"], ["bw", "Black & white", "linear-gradient(90deg,#111 50%,#eee 50%)"]];
  function sayChip(text, big) {
    return '<button class="say-chip' + (big ? " big" : "") + '" data-act="sayCopy" data-text="' + esc(text) + '" title="Copy, then paste it in the chat">' + icon("copy") + "<span>" + esc(text) + "</span></button>";
  }
  function revisionGuide(p) {
    const examples = ["Make the captions bigger and keep them away from my face.", "Tighten the pauses, but keep my words sounding natural.", "At 0:15, lower the music and hold the video on screen longer."];
    return '<section class="native-conversation-note" aria-label="How to request changes"><div class="revision-heading">' + icon("edit") + '<b>Want to change something?</b></div>' +
      '<p>Tell me what you want to change in the chat, then press Send. You can ask while I’m editing, too.</p>' +
      '<div class="revision-examples"><span class="t-small">Not sure what to say? Copy an example, paste it into the chat, and make it your own.</span>' +
      examples.map(text => '<button class="revision-example" data-act="sayCopy" data-text="' + esc(text) + '" aria-label="Copy example: ' + esc(text) + '"><span>“' + esc(text) + '”</span><small>' + icon("copy") + 'Copy example</small></button>').join("") + '</div></section>';
  }
  /* ---- ready: watch, ask for changes, save */
  function studioOutput(p) {
    const src = p.preview || p.latest;
    const busy = p.busy;
    const overlay = busy ? '<div class="busy"><b>' + esc(busy.label) + '</b><div class="bar' + (busy.progress != null ? "" : " indet") + '"><i style="width:' + Math.round((busy.progress || 0.1) * 100) + '%"></i></div></div>' : "";
    const vers = p.versions || [];
    const poster = (vers.length && vers[vers.length - 1].poster) || p.poster || "";
    const rendering = (S().jobs || []).find((j) => j.kind === "render" && j.key === p.name && ["queued", "running", "waiting"].includes(j.state));
    const ea = S().activity || {};
    const epct = rendering && ea.project === p.name && ea.cmd === "render" && ea.percent != null ? Math.round(ea.percent) : Math.round(((rendering || {}).progress || 0) * 100);
    const save = rendering ? '<span class="export-meter"><span class="t-mono">SAVING ' + epct + '%</span><span class="bar"><i style="width:' + Math.max(3, epct) + '%"></i></span></span>'
      : p.status === "finished" ? '<a class="btn btn-soft" href="#/videos">' + icon("check") + "Saved · open My videos</a>" : "";
    return '<div class="ox page-in"><div class="ox-player"><div class="iphone reveal-in"><div class="screen"><i class="island"></i><video id="mon" playsinline preload="metadata"' + (poster ? ' poster="' + esc(poster) + '"' : "") + ' src="' + esc(src) + '"></video>' +
      '<button class="bigplay" data-act="playpause" aria-label="Play">' + icon("play") + "</button>" + overlay + "</div></div>" +
      '<div class="player"><button class="play" data-act="playpause" aria-label="Play">' + icon("play") + '</button><input type="range" min="0" max="1000" value="0" aria-label="Seek" data-input="seek" data-free id="scrub"><span class="time" id="tc">0:00</span></div>' +
      (vers.length > 1 ? '<div class="vtabs">' + vers.map((v) => '<button aria-pressed="' + (v.n === vers.length) + '" title="' + esc(v.note || "") + '" data-act="restore" data-n="' + v.n + '">v' + v.n + "</button>").join("") + "</div>" : "") + "</div>" +
      '<div class="ox-side"><input class="sx-title" value="' + esc(p.title || "") + '" placeholder="Name this video" data-change="renameVideo" data-free aria-label="Video title">' + presetBadge(p) +
      savePresetCard(p) +
      '<div class="ox-save">' + save + "</div></div>" + revisionGuide(p) + "</div>";
  }
  function studio() {
    const id = A.route().arg;
    if (!id) {
      const draft = (S().projects || []).find((x) => x.status === "draft" && !(x.media || []).length && !(x.refs || []).length && !(x.brief && x.brief.prompt));
      if (draft) { setTimeout(() => A.go("studio/" + draft.name), 0); }
      else if (!A.ui.creating) { A.ui.creating = true; A.createVideoDraft().then((r) => { A.ui.creating = false; A.go("studio/" + r.project); }).catch(() => { A.ui.creating = false; }); }
      return '<div class="page"><div class="skel" style="height:60vh;border-radius:12px"></div></div>';
    }
    const p = projectById(id);
    if (A.ui.studioProject !== id) { A.ui.studioProject = id; A.ui.namingRef = null; A.ui.refName = null; A.api.focus && A.api.focus(id).catch(() => {}); }
    if (!p) return '<div class="page"><div class="skel" style="height:60vh;border-radius:12px"></div></div>';
    const activeEdit = ['analysing','planning','building','reviewing'].includes((p.workflow || {}).phase);
    const mode = p.status === 'draft' && !activeEdit ? 'draft' : !activeEdit && (p.preview || p.latest) ? 'out' : 'work';
    const body = mode === 'draft' ? studioDraft(p) : mode === 'out' ? studioOutput(p) : studioWorking(p);
    return '<div data-studio-project="' + esc(p.name) + '" data-studio-view="' + mode + '" data-key="st-' + mode + '">' + body + "</div>";
  }

  /* =========================================================== my videos == */
  function myVideos() {
    const vids = (S().projects || []).filter((p) => !p.parent && p.status !== "draft");
    const cards = vids.map((p, i) => {
      const vers = p.versions || [];
      const poster = (vers.length && vers[vers.length - 1].poster) || p.poster || ((p.media || []).find((m) => m.kind === "raw") || {}).thumb || "";
      const vid = p.latest || p.preview;
      const dl = p.download || p.preview;
      const status = p.status === "finished" ? "Saved" : p.preview ? "Ready" : "Creating";
      const confirm = A.ui.confirmDelete === p.name;
      return '<article class="vcard2 spot" style="animation-delay:' + Math.min(i, 12) * 0.035 + 's" data-key="v-' + esc(p.name) + '">' +
        '<a class="fold" href="#/studio/' + encodeURIComponent(p.name) + '" aria-label="Open ' + esc(p.title || p.name) + '">' + FOLDER_BACK + '<span class="frame">' + (poster ? '<img alt="" loading="lazy" src="' + esc(poster) + '">' : vid ? '<video class="still" muted playsinline preload="metadata" src="' + esc(vid) + '#t=0.5"></video>' : "") +
        (vid ? '<video muted loop playsinline preload="none" data-hover src="' + esc(vid) + '"></video>' : "") + '<span class="badge">' + status + (vers.length > 1 ? " · v" + vers.length : "") + "</span>" +
        (p.timeline && p.timeline.duration ? '<span class="dur t-mono">' + A.fmtTime(p.timeline.duration) + "</span>" : "") + "</span>" + FOLDER_FRONT + "</a>" +
        '<div class="meta"><b>' + esc(p.title || p.name) + "</b></div>" +
        (confirm ? '<div class="acts confirm"><span class="t-small">Delete this video?</span><span class="spacer"></span><button class="btn btn-text btn-sm" data-act="cancelDelete">Cancel</button><button class="btn btn-sm danger" data-act="deleteVideo" data-p="' + esc(p.name) + '">Delete</button></div>'
          : '<div class="acts"><a class="btn btn-ink btn-sm grow" href="#/studio/' + encodeURIComponent(p.name) + '">' + icon("edit") + "Keep editing</a>" +
            (vers.length ? '<button class="btn btn-line btn-sm" data-act="manageVideoPreset" data-project="' + esc(p.name) + '">Save / update preset</button>' : '') +
            (dl ? '<a class="icon-btn" href="' + esc(dl) + '" download="' + esc((p.title || p.name) + ".mp4") + '" title="Download" aria-label="Download">' + icon("dl") + "</a>" : "") +
            '<button class="icon-btn" data-act="askDelete" data-p="' + esc(p.name) + '" title="Delete" aria-label="Delete">' + icon("trash") + "</button></div>") + "</article>";
    });
    return '<div class="page page-in"><div class="head"><h1 class="t-1">My videos</h1><button class="btn btn-ink btn-sm" data-act="startVideo">' + icon("plus") + "New video</button></div>" +
      (cards.length ? '<div class="vgrid">' + cards.join("") + "</div>" : '<div class="empty"><b class="t-3">No videos yet</b><button class="btn btn-ink" data-act="startVideo">New video</button></div>') + "</div>";
  }

  /* ============================================================ presets == */
  function presetsPage() {
    const ps = presets();
    return '<div class="page page-in"><div class="head"><h1 class="t-1">Presets</h1><button class="btn btn-ink btn-sm" data-act="startVideo">' + icon("plus") + "New preset</button></div>" +
      '<div class="plist">' + ps.map((s) => presetTile(s)).join("") + newPresetTile() + "</div></div>";
  }
  function presetPage() {
    const s = styleById(A.route().arg);
    if (!s || !s.yours) return '<div class="page page-in"><div class="empty"><b class="t-3">This preset was deleted.</b><a class="btn btn-ink" href="#/presets">Presets</a></div></div>';
    const src = (s.sources || []).filter((x) => x.title || x.url);
    return '<div class="page page-in"><div class="head"><div class="col"><a class="link t-small" href="#/presets">' + icon("back") + 'Presets</a><input class="pname t-1" value="' + esc(s.name) + '" data-change="renamePreset" data-id="' + esc(s.id) + '" data-free aria-label="Preset name" title="Rename">' +
      (src.length ? '<span class="t-small">From ' + src.map((x) => x.url ? '<a class="link" href="' + esc(x.url) + '" target="_blank" rel="noopener">' + esc(x.title || x.url) + "</a>" : esc(x.title)).join(", ") + "</span>" : "") + "</div>" +
      '<div class="row"><button class="btn btn-text btn-sm" data-act="deletePreset" data-id="' + esc(s.id) + '">' + icon("trash") + 'Delete</button><button class="btn btn-ink btn-sm" data-act="startVideo" data-style="' + esc(s.id) + '">Use for a new video</button></div></div>' +
      '<div class="pp"><div class="rx-media">' + flip(s.frames) + '</div><div class="ra done">' + (s.recipe_kind === 'brief' ? '<p class="t-small">Your instructions, settings and references are saved. Update this preset after your first finished edit.</p>' : refScan({ status: "done", kind: "file" }) + details("ps-" + s.id, s.readout || [])) + "</div></div>" +
      "</div>";
  }
  function teachPage() { setTimeout(() => act.startVideo(null), 0); return '<div class="page"><div class="skel" style="height:60vh;border-radius:12px"></div></div>'; }

  /* =========================================================== settings == */
  /* ============================================================= sheets == */
  function sheet() {
    const sh = A.ui.sheet;
    if (!sh) return "";
    let body = "", wide = false;
    if (sh.type === "install") body = '<h2 class="t-2">Installing</h2>' + installListHtml() + '<button class="btn btn-soft" data-act="closeSheet">Close</button>';
    else if (sh.type === "adjust") body = A.adjustSheet ? A.adjustSheet() : "";
    else if (sh.type === "copyblock") body = '<div class="copybox">' + esc(sh.text) + '</div><button class="btn btn-ink" data-act="copy" data-text="' + esc(sh.text) + '">Copy</button>';
    if (sh.type === "adjust") wide = true;
    return '<div class="scrim" data-act="scrim"><div class="sheet' + (wide ? " wide" : "") + '" role="dialog" aria-modal="true">' + body + "</div></div>";
  }
  function installListHtml() {
    const iv = installInfo();
    return '<div class="install-list">' + iv.steps.map((s) => '<div class="install-row ' + s.state + '" data-key="' + s.key + '"><span class="ic">' + (s.state === "done" ? icon("check") : "") + "</span>" + esc(s.label) + "</div>").join("") + "</div>";
  }
  const COMMANDS = () => [
    ["New video", "plus", () => act.startVideo(null)], ["Home", "home", () => A.go("home")], ["Studio", "edit", () => A.go("studio")], ["My videos", "library", () => A.go("videos")],
    ["Presets", "styles", () => A.go("presets")], ["New preset", "spark", () => act.startVideo(null)],
    ["Switch light / dark", "eye", () => { const r = document.documentElement; const d = r.getAttribute("data-theme") === "dark" || (!r.getAttribute("data-theme") && matchMedia("(prefers-color-scheme: dark)").matches); r.setAttribute("data-theme", d ? "light" : "dark"); }],
  ].concat((S().projects || []).filter((p) => p.status !== "draft").slice(0, 8).map((p) => [p.title || p.name, "film", () => A.go("studio/" + p.name)]));
  function palette() {
    if (!A.ui.palette) return "";
    const q = (A.ui.paletteQ || "").toLowerCase();
    const items = COMMANDS().filter((c) => c[0].toLowerCase().includes(q)).slice(0, 10);
    const sel = Math.min(A.ui.paletteSel || 0, Math.max(0, items.length - 1));
    return '<div class="palette" data-act="closePalette"><div class="palette-box"><input placeholder="Search" data-input="paletteQ" data-free value="' + esc(A.ui.paletteQ || "") + '" aria-label="Search"><div class="palette-list">' +
      items.map((c, i) => '<button class="palette-item" aria-selected="' + (i === sel) + '" data-act="paletteRun" data-i="' + i + '">' + icon(c[1]) + esc(c[0]) + "</button>").join("") + "</div></div></div>";
  }

  /* ============================================================= render == */
  const root = document.getElementById("app");
  function view() {
    const s = A.state;
    if (!s && A.fatal) return '<div class="ob"><div></div><main class="ob-body"><div class="ob-step"><h1 class="t-1">Something went wrong.</h1><p class="t-body">' + esc(A.fatal) + "</p></div></main></div>";
    if (!s) return '<div class="ob"><div></div><main class="ob-body">' + mark("xl") + "</main></div>";
    const done = s.profile && s.profile.onboarding && s.profile.onboarding.done;
    if (!done || A.ui.forceOnboarding) return onboarding() + sheet() + palette();
    const r = A.route();
    const pages = { home, studio, videos: myVideos, library: myVideos, presets: presetsPage, styles: presetsPage, style: presetPage, preset: presetPage, teach: teachPage };
    const nav = { style: "", preset: "", teach: "", presets: "", styles: "", library: "videos" }[r.name];
    const issues = (s.data_issues || []).map(text => '<p class="metadata-issue" role="alert">' + esc(text) + '</p>').join('');
    return shell(updateBar() + issues + (pages[r.name] || home)(), nav != null ? nav : r.name) + sheet() + palette();
  }
  A.subscribe(() => { A.patch(root, view()); after(); });

  /* scroll-linked fade: sections ease in as they enter the viewport */
  const io = "IntersectionObserver" in window ? new IntersectionObserver((es) => es.forEach((e) => e.target.classList.toggle("seen", e.isIntersecting)), { threshold: 0.12 }) : null;
  setInterval(() => {
    document.querySelectorAll("[data-elapsed]").forEach((el) => {
      const s = Math.max(0, Math.floor(Date.now() / 1000 - Number(el.getAttribute("data-elapsed"))));
      el.textContent = String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0");
    });
  }, 1000);
  /* scroll-linked motion: each update line's opacity and offset follow its position in the viewport */
  let scrollRaf = 0;
  const scrollFx = () => {
    scrollRaf = 0;
    const vh = window.innerHeight;
    document.querySelectorAll(".upd").forEach((el) => {
      const r = el.getBoundingClientRect();
      const c = (r.top + r.height / 2) / vh;                    // 0 top … 1 bottom
      const d = Math.min(1, Math.abs(c - 0.55) / 0.55);
      el.style.opacity = (1 - d * d * 0.75).toFixed(3);
      el.style.transform = el.matches(":hover") ? "" : "translateX(" + (d * 14).toFixed(1) + "px)";
    });
  };
  window.addEventListener("scroll", () => { if (!scrollRaf) scrollRaf = requestAnimationFrame(scrollFx); }, { passive: true });
  /* rotating word in the welcome subtitle */
  setInterval(() => {
    document.querySelectorAll(".rot[data-words]").forEach((el) => {
      const words = el.getAttribute("data-words").split(",");
      el._i = ((el._i || 0) + 1) % words.length;
      const old = el.firstElementChild;
      if (old) { old.classList.add("out"); setTimeout(() => old.remove(), 450); }
      const n = document.createElement("span"); n.textContent = words[el._i]; n.className = "in"; el.appendChild(n);
    });
  }, 2400);
  /* numbers glide to their new value instead of jumping */
  function tweens() {
    document.querySelectorAll("[data-tween]").forEach((el) => {
      const to = Number(el.getAttribute("data-tween")) || 0;
      const from = el._v != null ? el._v : 0;
      if (from === to && el._done) return;
      el._done = true; const t0 = performance.now(), dur = 900;
      const step = (t) => { const k = Math.min(1, (t - t0) / dur), v = from + (to - from) * (1 - Math.pow(1 - k, 3)); el.textContent = Math.round(v); el._v = v; if (k < 1) requestAnimationFrame(step); else el._v = to; };
      requestAnimationFrame(step);
    });
  }
  let lastStudioView = '', editorScrollFrame = 0;
  function keepEditorVisible() {
    const stage = document.querySelector('[data-studio-view]');
    if (!stage) { lastStudioView = ''; if (editorScrollFrame) cancelAnimationFrame(editorScrollFrame); editorScrollFrame = 0; return; }
    const key = stage.dataset.studioProject + ':' + stage.dataset.studioView;
    if (key === lastStudioView) return;
    lastStudioView = key;
    if (editorScrollFrame) cancelAnimationFrame(editorScrollFrame);
    if (stage.dataset.studioView === 'draft') return;
    editorScrollFrame = requestAnimationFrame(() => {
      editorScrollFrame = 0;
      const current = document.querySelector('[data-studio-view]');
      if (!current || current.dataset.studioProject + ':' + current.dataset.studioView !== key) return;
      const target = current.querySelector('.ed, .ox-player');
      if (target) target.scrollIntoView({block:'start', behavior:'instant'});
    });
  }
  function after() {
    keepEditorVisible();
    tweens();
    scrollFx();
    document.querySelectorAll("[data-type]").forEach((el) => {
      if (el._typed === el.getAttribute("data-type")) return;
      const text = el._typed = el.getAttribute("data-type"); let i = 0;
      const step = () => { i += 1; el.textContent = text.slice(0, i); if (i < text.length && el._typed === text) setTimeout(step, 22); };
      if (A.reduced) el.textContent = text; else step();
    });
    if (!A.ui.introSeen && !A.ui.introTimer) { A.ui.introTimer = setTimeout(() => { A.ui.introSeen = true; try { localStorage.setItem("aie-intro", "1"); } catch (e) {} A.render(); }, 3000); }
    if (io) document.querySelectorAll(".feed-item, .folder, .section").forEach((el) => { if (!el._io) { el._io = 1; el.classList.add("fade-scroll"); io.observe(el); } });
    document.querySelectorAll("video[data-hover]").forEach((v) => {
      if (v._b) return; v._b = true;
      let tile = v.closest(".vtile, .vcard2");
      (tile = v.closest(".vtile, .vcard2")) && tile.addEventListener("mouseenter", () => { v.preload = "auto"; v.play().then(() => v.classList.add("ready")).catch(() => {}); });
      tile.addEventListener("mouseleave", () => { v.pause(); v.classList.remove("ready"); });
    });
    const m = document.getElementById("msgs");
    if (m && m._n !== m.children.length) { m._n = m.children.length; m.scrollTop = m.scrollHeight; }
    const v = document.getElementById("mon");
    if (v && !v._bound) {
      v._bound = true;
      const sync = () => {
        const d = v.duration || 0, t = v.currentTime || 0;
        const tc = document.getElementById("tc"); if (tc) tc.textContent = A.fmtTime(t) + " / " + A.fmtTime(d);
        const sc = document.getElementById("scrub"); if (sc && document.activeElement !== sc && d) { sc.value = String(Math.round((t / d) * 1000)); sc.style.setProperty("--p", (t / d) * 100 + "%"); }
        const p = projectById(A.ui.studioProject); const tl = p && p.timeline;
        if (tl && tl.duration) {
          ["h1", "h2"].forEach((id) => { const h = document.getElementById(id); if (h) h.style.left = (t / tl.duration) * 100 + "%"; });
          const seg = tl.segments.find((s) => t >= s.start && t <= s.end) || tl.segments[tl.segments.length - 1];
          const h0 = document.getElementById("h0"); if (h0 && seg) h0.style.left = ((seg.src_start + (t - seg.start)) / (tl.source_duration || tl.duration)) * 100 + "%";
        }
        const scr = v.closest(".screen"); if (scr) scr.classList.toggle("playing", !v.paused);
        const pb = document.querySelector(".play"); if (pb) { const want = v.paused ? "Play" : "Pause"; if (pb.getAttribute("aria-label") !== want) { pb.setAttribute("aria-label", want); pb.innerHTML = icon(v.paused ? "play" : "pause"); } }
      };
      ["timeupdate", "loadedmetadata", "play", "pause", "seeked"].forEach((e) => v.addEventListener(e, sync));
      v.addEventListener("click", () => (v.paused ? v.play() : v.pause()));
    }
    const pi = document.querySelector(".palette input"); if (pi && document.activeElement !== pi) pi.focus();
  }
  document.addEventListener("pointerdown", (e) => {
    const b = e.target.closest && e.target.closest("[data-hold=compare]"); if (!b) return;
    const cmp = document.getElementById("cmp"), mon = document.getElementById("mon"), cv = document.getElementById("cmpv"); if (!cmp || !mon || !cv) return;
    const p = projectById(A.ui.studioProject); const tl = p && p.timeline;
    const t = mon.currentTime; const seg = tl ? tl.segments.find((s) => t >= s.start && t <= s.end) : null;
    cv.currentTime = seg ? seg.src_start + (t - seg.start) : t;
    cmp.hidden = false; let k = 0;
    const open = () => { k = Math.min(100, k + 8); cmp.style.setProperty("--split", k + "%"); if (k < 100 && !cmp.hidden) requestAnimationFrame(open); };
    requestAnimationFrame(open);
    const up = () => { cmp.hidden = true; cmp.style.setProperty("--split", "0%"); window.removeEventListener("pointerup", up); };
    window.addEventListener("pointerup", up);
  });

  /* ============================================================ actions == */
  const act = A.actions;
  act.forgetRule = (el) => A.act(() => A.api.forgetRule(el.getAttribute("data-id"), +el.getAttribute("data-i")));
  act.go = (el) => A.go(el.getAttribute("data-to"));
  act.cancelUpload = (el) => A.cancelUpload(el.getAttribute("data-id"));
  act.chatDraft = el => { A.ui.chatDraft = el.value; el.style.height = "auto"; el.style.height = Math.min(160, el.scrollHeight) + "px"; };
  act.recoverStep = () => {
    const p = projectById(A.ui.studioProject); if (!p) return;
    const text = 'Check project ' + p.name + ': its last editing step needs attention. Inspect the actual process and logs, preserve my footage and approved output, fix the cause and resume only the interrupted step. Do not start a second model or duplicate an active render.';
    if (A.nativeChat && A.nativeChat.available) { A.ui.chatDraft = text; act.sendChat().catch(e => A.toast(e.message, 'check')); }
    else A.copy(text);
  };
  act.confirmNativeRetry = () => A.nativeChat && A.nativeChat.confirmRetry(A.ui.studioProject);
  act.sendChat = async () => {
    const p = projectById(A.ui.studioProject), text = (A.ui.chatDraft || "").trim();
    if (!p || !text || !A.nativeChat) return;
    try {
      const delivered = await A.nativeChat.send(p.name, text);
      if (!delivered || delivered.accepted !== true) throw new Error('The conversation did not confirm this request.');
      // Record only a host-acknowledged user message, never queue it for another editor.
      p.chat = (p.chat || []).concat([{ id: "native-" + Date.now(), role: "user", text, time: Date.now()/1000, native: true }]);
      if ((A.ui.chatDraft || "").trim() === text) A.ui.chatDraft = "";
      A.render();
      A.api.mirrorUser && A.api.mirrorUser(p.name, text).catch(() => A.toast("Sent to the conversation; the local mirror could not refresh.", "check"));
      return { accepted: true };
    } catch (e) { A.render(); throw e; }
  };
  act.sayThis = el => { A.ui.chatDraft = el.getAttribute("data-text"); act.sendChat().catch(e => A.toast(e.message, 'check')); };
  const briefSaves = {};
  async function persistBrief(p, text) {
    const prior = briefSaves[p.name] || Promise.resolve();
    const job = prior.catch(() => {}).then(async () => {
      await A.api.brief(p.name, { prompt: text });
      p.brief = Object.assign({}, p.brief, { prompt: text });
      A.ui.briefStatus = Object.assign({}, A.ui.briefStatus, { [p.name]: 'Instructions saved' });
    });
    briefSaves[p.name] = job;
    try { await job; }
    catch(e) { A.ui.briefStatus = Object.assign({}, A.ui.briefStatus, { [p.name]: 'Not saved yet. Your draft is kept.' }); throw e; }
  }
  act.briefDraft = el => {
    const p = projectById(A.ui.studioProject); if (!p) return;
    A.ui.briefDrafts = Object.assign({}, A.ui.briefDrafts, { [p.name]: el.value });
    A.ui.briefStatus = Object.assign({}, A.ui.briefStatus, { [p.name]: 'Draft kept here. Saved when you leave the box or start editing.' });
    A.saveUI();
    const status = document.querySelector('[data-brief-status]'); if (status) status.textContent = A.ui.briefStatus[p.name];
  };
  act.saveBrief = async () => {
    const p = projectById(A.ui.studioProject); if (!p) return;
    const text = Object.prototype.hasOwnProperty.call(A.ui.briefDrafts || {}, p.name) ? A.ui.briefDrafts[p.name] : (p.brief || {}).prompt || '';
    try { await persistBrief(p,text); A.render(); } catch(e) { A.render(); }
  };
  act.useBriefExample = () => {
    const p = projectById(A.ui.studioProject); if (!p) return;
    const el = document.getElementById('editing-brief'); if (!el) return;
    if (el.value.trim()) { A.toast('Your instructions are kept. The example stays available in the empty-box placeholder.', 'check'); return; }
    el.value = BRIEF_EXAMPLE; act.briefDraft(el); el.focus();
  };
  act.makeNativeVideo = async () => {
    const p = projectById(A.ui.studioProject); if (!p || A.ui.savingMake) return;
    const existing = (A.ui.editStarts || {})[p.name];
    if (existing && ['sent','uncertain'].includes(existing.state)) return;
    const text = Object.prototype.hasOwnProperty.call(A.ui.briefDrafts || {}, p.name) ? A.ui.briefDrafts[p.name] : (p.brief || {}).prompt || '';
    const started = Date.now()/1000;
    const startState = state => {
      A.ui.editStarts = Object.assign({}, A.ui.editStarts, { [p.name]: state });
      A.saveUI(); A.render();
    };
    A.ui.savingMake = true;
    startState({ state:'saving', at:started });
    try {
      await persistBrief(p,text);
      if (!(A.nativeChat && A.nativeChat.available)) {
        throw new Error('This preview has no connection for sending an editing request. I have not started an edit.');
      }
      A.ui.chatDraft = 'Edit my video “' + (p.title || p.name) + '” using its footage and reference. Reuse project ' + p.name + '; do not create another project. Read its FULL saved brief.prompt before planning; it has ' + text.length + ' characters. Claim the project immediately so Studio can confirm work started. Follow the saved instructions and settings. Start footage preparation and transcription while reference analysis continues. Use the completed reference analysis before styling and final review. Please start now.';
      const result = await act.sendChat();
      if (!result || result.accepted !== true) throw new Error('The editing request was not confirmed.');
      startState({ state:'sent', at:started, delivered:Date.now()/1000 });
      setTimeout(() => { const st = (A.ui.editStarts || {})[p.name]; if (st && st.at === started && st.state === 'sent') A.render(); }, 46000);
      A.toast('Request delivered. Studio will confirm when editing starts.', 'check');
    } catch(e) {
      startState({ state:e.uncertain ? 'uncertain' : 'error', at:started, error:e.message || 'The edit could not start.' });
    } finally { A.ui.savingMake = false; A.render(); }
  };
  act.copyEditBrief = async () => {
    const p = projectById(A.ui.studioProject); if (!p) return;
    A.copy('Edit my video “' + (p.title || p.name) + '” (project ' + p.name + '). Use the footage, reference and settings I added in Studio.');
    A.toast('Brief copied. Paste it into the conversation beside Studio.', 'check');
  };
  act.setLook = (el) => { const p = projectById(A.ui.studioProject); const k = el.getAttribute("data-k");
    if (p) { p.settings = Object.assign({}, p.settings, { look: k }); A.render(); A.act(() => A.api.brief(p.name, { look: k })); } };
  const presetSaves = new Set();
  act.updateVideoPreset = async (el) => {
    const p = projectById(A.ui.studioProject), id = el.getAttribute('data-id'), preset = styleById(id);
    if (!p || !preset || presetSaves.has(p.name)) return;
    presetSaves.add(p.name);
    try {
      const r = await A.act(() => A.api.presetFromVideo(p.name, preset.name, id));
      if (r) A.toast('Preset saved. Existing projects keep their selected recipe version.', 'check');
    } finally { presetSaves.delete(p.name); }
  };
  act.manageVideoPreset = (el) => {
    A.go('studio/'+el.getAttribute('data-project'));
    setTimeout(()=>{const card=document.querySelector('.savepreset');if(card)card.scrollIntoView({behavior:A.reduced?'auto':'smooth',block:'center'});},100);
  };
  act.saveBriefPreset = async () => {
    const p = projectById(A.ui.studioProject), input=document.querySelector('.savepreset input');
    const name=((input && input.value)||'').trim();
    if(!p || !name || presetSaves.has(p.name)) { if(input) input.focus(); return; }
    presetSaves.add(p.name);
    try {
      const text=Object.prototype.hasOwnProperty.call(A.ui.briefDrafts||{},p.name)?A.ui.briefDrafts[p.name]:(p.brief||{}).prompt||'';
      await persistBrief(p,text);
      const result=await A.api.presetFromBrief(p.name,name);
      if(result) { p.settings.style=result.id; A.toast('Preset saved. Find it on Home or choose it in Studio.','check'); }
    } catch(e) { A.toast(e.message,'alert','err'); }
    finally { presetSaves.delete(p.name); }
  };
  act.saveVideoPreset = async () => {
    const p = projectById(A.ui.studioProject); const i = document.querySelector(".savepreset input");
    const name = ((i && i.value) || "").trim();
    if (!name) { if (i) { i.classList.add("shake"); i.focus(); setTimeout(() => i.classList.remove("shake"), 400); } return; }
    if (!p || presetSaves.has(p.name)) return;
    presetSaves.add(p.name);
    try {
      const r = await A.act(() => A.api.presetFromVideo(p.name, name));
      if (r) A.toast("Saved preset “" + name + "”. It's on Home and in Studio.", "check");
    } finally { presetSaves.delete(p.name); }
  };
  act.sayCopy = async (el) => { if (await A.copy(el.getAttribute("data-text"))) A.toast("Example copied. Paste it in the chat beside Studio, then press Send.", "check"); };
  act.copy = (el) => A.copy(el.getAttribute("data-text"));
  act.sheet = (el) => { A.ui.sheet = { type: el.getAttribute("data-sheet") }; A.render(); };
  act.closeSheet = () => { A.ui.sheet = null; A.render(); };
  act.scrim = (el, e) => { if (e.target === el) act.closeSheet(); };
  act.obGo = (el) => goStep(el.getAttribute("data-to"));
  act.obName = (el) => { A.ui.obName = el.value; };
  act.obNameGo = () => { const n = (A.ui.obName != null ? A.ui.obName : P().name || "").trim(); if (n) A.setProfile({ name: n }); goStep("teach"); };
  act.urlDraft = (el) => { A.ui.urlDraft = el.value; };
  act.addUrl = async () => {
    const input = document.querySelector(".urlbar input[data-input=urlDraft]");
    const raw = ((input && input.value) || A.ui.urlDraft || "").trim();
    if (!raw) { const bar = input && input.closest(".urlbar"); if (bar) { bar.classList.add("shake"); setTimeout(() => bar.classList.remove("shake"), 400); } return; }
    A.ui.urlDraft = ""; if (input) input.value = "";
    for (const u of raw.split(/[\s,]+/).filter(Boolean)) await A.act(() => A.api.addUrl(u));
  };
  act.removeRef = (el) => A.act(() => A.api.removeRef(el.getAttribute("data-id")));
  act.retryRef = (el) => A.act(() => A.api.retryRef(el.getAttribute("data-id")));
  act.finishOb = async () => {
    if (S().offline) return;
    await A.act(() => A.api.event("onboarding.done", { platform: P().platform, style: P().style, name: P().name }));
    A.ui.forceOnboarding = false; A.ui.obStep = null; A.go("home");
  };
  act.restartOb = () => { A.ui.forceOnboarding = true; A.ui.obStep = "welcome"; A.render(); };
  act.startVideo = async (el) => {
    if (A.ui.startingVideo) return;
    A.ui.startingVideo = true;
    try {
      const st = el && el.getAttribute && el.getAttribute("data-style");
      const r = await A.act(() => A.createVideoDraft());
      if (!r) return;
      if (st) await A.act(() => A.api.brief(r.project, { style: st }));
      A.go("studio/" + r.project);
    } finally { A.ui.startingVideo = false; }
  };
  act.openStyle = (el) => A.go("preset/" + el.getAttribute("data-id"));
  act.choosePreset = async (el) => {
    const p = projectById(A.ui.studioProject); if (!p) return;
    const id = el.getAttribute("data-id");
    const next = p.settings.style === id ? "creatorcut-signature" : id;
    const ok = await A.act(() => A.api.brief(p.name, { style: next }));
    if (ok) {
      p.settings.style = next;
      const state = await A.api.state(), fresh = state.projects.find(x=>x.name===p.name);
      if(fresh && fresh.brief && !((A.ui.briefDrafts||{})[p.name]||'').trim()) {
        A.ui.briefDrafts=Object.assign({},A.ui.briefDrafts,{[p.name]:fresh.brief.prompt||''});
      }
      A.setState(state);
    }
  };
  act.refFile = (el) => { A.handleFiles(Array.from(el.files || []), "vref", el.getAttribute("data-project")); el.value = ""; };
  act.removeVideoRef = (el) => { const p = projectById(A.ui.studioProject); if (p) { p.refs = (p.refs || []).filter((r) => r.id !== el.getAttribute("data-id")); A.render(); A.act(() => A.api.removeVideoRef(p.name, el.getAttribute("data-id"))); } };
  act.nameRefPreset = (el) => { A.ui.namingRef = el.getAttribute("data-id"); A.ui.refName = null; A.render(); setTimeout(() => { const i = document.querySelector(".namebar input"); if (i) { i.focus(); i.select(); } }, 30); };
  act.cancelRefName = () => { A.ui.namingRef = null; A.render(); };
  act.refName = (el) => { A.ui.refName = el.value; };
  act.saveRefPreset = async (el) => {
    const pid = el.getAttribute("data-project") || "";
    const id = el.getAttribute("data-id"); const i = document.querySelector(".namebar input");
    const name = ((i && i.value) || "").trim();
    if (!name) { if (i) { i.classList.add("shake"); setTimeout(() => i.classList.remove("shake"), 400); } return; }
    const r = await A.act(() => A.api.teach(name, [id], pid));
    if (r) { A.ui.savingRef = { ref: id, job: r.job }; A.ui.namingRef = null; A.ui.refName = null; A.toast("Saving preset “" + name + "”", "check"); A.render(); }
  };
  act.binFiles = (el) => { A.handleFiles(Array.from(el.files || []), el.getAttribute("data-kind"), el.getAttribute("data-project")); el.value = ""; };
  act.files = (el) => { A.handleFiles(Array.from(el.files || []), el.getAttribute("data-kind")); el.value = ""; };
  act.removeMedia = (el) => A.act(() => A.api.removeMedia(A.ui.studioProject, el.getAttribute("data-id")));
  act.renameVideo = (el, e) => { const p = projectById(A.ui.studioProject); const v = el.value.trim();
    if (e && e.type === "keydown") { el.blur(); return; }       // Enter: leaving the field saves it (change event)
    if (p && v && v !== p.title) { p.title = v; A.act(() => A.api.brief(p.name, { title: v })).then(() => A.render()); } };
  act.restore = (el) => A.act(() => A.api.restore(A.ui.studioProject, Number(el.getAttribute("data-n"))));
  act.playpause = () => { const v = document.getElementById("mon"); if (v) v.paused ? v.play() : v.pause(); };
  act.seek = (el) => { const v = document.getElementById("mon"); if (v && v.duration) { v.currentTime = (el.value / 1000) * v.duration; el.style.setProperty("--p", el.value / 10 + "%"); } };
  act.profileField = (el) => { A.setProfile({ [el.getAttribute("data-k")]: el.value.trim() }); el.classList.add("saved"); setTimeout(() => el.classList.remove("saved"), 900); };
  act.rulebookDraft = (el) => { A.ui.rulebookDraft = el.value; A.ui.rulebookFor = A.route().arg; };
  act.saveRulebook = async (el) => { const t = document.querySelector("textarea.rulebook"); if (t && await A.act(() => A.api.saveRulebook(el.getAttribute("data-id"), t.value), "Saved")) A.ui.rulebookDraft = null; };
  act.saveWebsite = async () => {
    const i = document.querySelector(".page .urlbar input"); if (!i) return;
    if (await A.act(() => A.api.website(i.value.trim()))) A.render();
  };
  act.addRefLink = async (el) => { const p = projectById(A.ui.studioProject); const u = (el.value || "").trim(); if (!p || !u) return; el.value = ""; await A.act(() => A.api.videoRef(p.name, u)); };
  act.addRefLinkBtn = (el) => act.addRefLink(el.parentElement.querySelector("input"));
  act.askDelete = (el) => { A.ui.confirmDelete = el.getAttribute("data-p"); A.render(); };
  act.cancelDelete = () => { A.ui.confirmDelete = null; A.render(); };
  act.deleteVideo = async (el) => { const id = el.getAttribute("data-p"); A.ui.confirmDelete = null; if (await A.act(() => A.api.deleteVideo(id), "Deleted")) { if (A.state) A.state.projects = (A.state.projects || []).filter((p) => p.name !== id); A.render(); } };
  act.toggleDetails = (el) => { const k = el.getAttribute("data-k"); A.ui.openDetails = Object.assign({}, A.ui.openDetails, { [k]: !(A.ui.openDetails || {})[k] }); A.render(); };
  act.renamePreset = async (el) => {
    const id = el.getAttribute("data-id"), name = el.value.trim();
    const cur = styleById(id); if (!cur || !name || name === cur.name) { if (cur) el.value = cur.name; return; }
    const r = await A.act(() => A.api.renameStyle(id, name), "Renamed");
    if (!r) { el.value = cur.name; return; }
    if (r.id && r.id !== id) A.go("preset/" + r.id);
  };
  act.deletePreset = async (el) => { const id = el.getAttribute("data-id"); if (await A.act(() => A.api.deletePreset(id), "Preset deleted")) A.go("presets"); };
  act.forget = (el) => { const m = (P().memory || []).slice(); m.splice(Number(el.getAttribute("data-i")), 1); A.setProfile({ memory: m }); };
  act.cleanStorage = async () => { const r = await A.act(() => A.api.cleanStorage()); if (r) A.toast("Freed " + r.freed_mb + " MB", "check"); };
  act.checkUpdate = async () => { const r = await A.act(() => A.api.checkUpdate()); if (r) A.toast(!r.configured ? "Updates are not connected to a release feed yet." : r.error ? r.error : r.available ? "Version " + r.latest + " available" : "Up to date", "check"); };
  // one click: the Studio downloads and installs the update itself, restarts, and the page reloads on the new version
  act.installUpdate = async () => {
    const from = S().version;
    A.updating = true; A.render();
    const r = await A.act(() => A.api.applyUpdate());
    if (!r) { A.updating = false; A.render(); return; }
    const started = Date.now();
    const tick = async () => {
      try {
        const s = await A.api.state();
        if (s.version && s.version !== from && !["downloading","installing"].includes((s.update || {}).status)) { location.reload(); return; }
        if (s.update && s.update.status === "failed") { A.updating = false; A.setState(s); return; }
        A.setState(s);
      } catch (_) {}                                  // the Studio is restarting: keep waiting
      if (Date.now() - started < 30 * 60 * 1000) setTimeout(tick, 1000); else { A.updating = false; A.render(); }
    };
    setTimeout(tick, 800);
  };
  act.repair = () => { A.copy("repair my studio"); A.toast("Copied. Paste it in the chat and your editor repairs it.", "check"); };
  act.palette = () => { A.ui.palette = true; A.ui.paletteQ = ""; A.ui.paletteSel = 0; A.render(); };
  act.closePalette = (el, e) => { if (!e || e.target === el) { A.ui.palette = false; A.render(); } };
  act.paletteQ = (el) => { A.ui.paletteQ = el.value; A.ui.paletteSel = 0; A.render(); };
  act.paletteRun = (el) => { const q = (A.ui.paletteQ || "").toLowerCase(); const c = COMMANDS().filter((x) => x[0].toLowerCase().includes(q))[Number(el.getAttribute("data-i"))]; A.ui.palette = false; A.render(); if (c) c[2](); };

  /* settings changes from the Adjust sheet (shared with v2 helpers below) */
  function setProject(key, value) {
    const p = projectById(A.ui.studioProject); if (!p) return;
    p.settings[key] = value; A.render();
    A.act(() => A.api.event("edit.set", { project: p.name, key, value }), "Setting saved for the next edit");
  }
  act.setVal = (el) => setProject(el.getAttribute("data-key"), el.getAttribute("data-value"));
  act.setToggle = (el) => setProject(el.getAttribute("data-key"), el.getAttribute("aria-checked") !== "true");
  act.nudge = (el) => { const p = projectById(A.ui.studioProject); if (p) setProject("caption_size", A.clamp((p.settings.caption_size || 80) + Number(el.getAttribute("data-d")), 40, 180)); };
  act.captionY = (el) => setProject("caption_y", Math.round((0.8 - (el.value / 100) * 0.35) * 1000) / 1000);
  act.musicVol = (el) => setProject("music_volume", Math.round((el.value / 100) * 0.5 * 1000) / 1000);
  act.sfxVol = (el) => setProject("sfx_volume", Math.round((el.value / 100) * 0.6 * 1000) / 1000);
  act.rangeFill = (el) => el.style.setProperty("--p", el.value + "%");
  let audioEl = null;
  act.previewMusic = (el) => { const src = el.getAttribute("data-src"); if (audioEl && audioEl._src === src && !audioEl.paused) { audioEl.pause(); return; } if (audioEl) audioEl.pause(); audioEl = new Audio(src); audioEl._src = src; audioEl.volume = 0.6; audioEl.play().catch(() => {}); };
  A.adjustSheet = () => {
    const p = projectById(A.ui.studioProject); if (!p) return "";
    const st = p.settings;
    const tog = (key, on, label) => '<div class="row" style="justify-content:space-between"><span>' + label + '</span><button class="toggle" role="switch" aria-checked="' + !!on + '" data-act="setToggle" data-key="' + key + '" aria-label="' + label + '"></button></div>';
    const y = st.caption_y || 0.66, yp = Math.round(((0.8 - y) / 0.35) * 100);
    const grades = [["natural", "Natural"], ["clean", "Clean"], ["warm", "Warm"], ["punchy", "Punchy"], ["cinematic", "Cinematic"], ["moody", "Moody"], ["soft", "Soft"], ["luxe", "Luxe"], ["film", "Film"], ["mono", "B&W"]];
    if (st.custom_grade) grades.unshift(["custom", "From preset"]);
    const music = S().music_library || [];
    const mv = Math.round(((st.music_volume || 0.16) / 0.5) * 100), sv = Math.round(((st.sfx_volume || 0.32) / 0.6) * 100);
    return '<div class="row"><h2 class="t-2">Adjust</h2><span class="spacer"></span><button class="icon-btn" data-act="closeSheet" aria-label="Close">' + icon("x") + "</button></div>" +
      '<div class="form"><div class="col" style="gap:14px"><span class="t-3">Captions</span>' + tog("captions_on", st.captions_on !== false, "Captions") +
      '<div class="row" style="justify-content:space-between"><span>Size</span><div class="row"><button class="icon-btn" data-act="nudge" data-d="-6" aria-label="Smaller">' + icon("minus") + '</button><span class="t-num" style="min-width:34px;text-align:center">' + (st.caption_size || 80) + '</span><button class="icon-btn" data-act="nudge" data-d="6" aria-label="Bigger">' + icon("plus") + "</button></div></div>" +
      '<div class="col" style="gap:6px"><span>Position</span><input type="range" min="0" max="100" value="' + yp + '" style="--p:' + yp + '%" data-change="captionY" data-input="rangeFill" aria-label="Caption position"></div>' +
      '<div class="seg">' + [["highlight", "Highlight"], ["reveal", "Reveal"], ["pop", "Pop"], ["plain", "Plain"]].map(([k, n]) => '<button aria-pressed="' + (st.caption_mode === k) + '" data-act="setVal" data-key="caption_mode" data-value="' + k + '">' + n + "</button>").join("") + "</div>" + tog("uppercase", st.uppercase, "All caps") + "</div>" +
      '<div class="col" style="gap:14px"><span class="t-3">Look</span><div class="opt-row">' + grades.map(([k, n]) => '<button class="chip" aria-pressed="' + (st.grade === k) + '" data-act="setVal" data-key="grade" data-value="' + k + '">' + n + "</button>").join("") + "</div>" + tog("zoom_on", st.zoom_on, "Punch-in zooms") + tog("progress_bar", st.progress_bar, "Progress bar") + "</div>" +
      '<div class="col full" style="gap:12px"><span class="t-3">Music</span><div class="opt-row"><button class="chip" aria-pressed="' + (st.music === "none") + '" data-act="setVal" data-key="music" data-value="none">Off</button><button class="chip" aria-pressed="' + (st.music === "auto") + '" data-act="setVal" data-key="music" data-value="auto">Auto</button>' +
      music.map((m) => '<span class="row" style="gap:2px"><button class="chip" aria-pressed="' + (st.music === m.id) + '" data-act="setVal" data-key="music" data-value="' + esc(m.id) + '">' + esc(m.name) + '</button><button class="icon-btn" style="width:26px;height:26px" data-act="previewMusic" data-src="' + esc(m.url) + '" aria-label="Listen">' + icon("play") + "</button></span>").join("") + "</div>" +
      (st.music !== "none" ? '<div class="col" style="gap:6px"><span>Music volume</span><input type="range" min="0" max="100" value="' + mv + '" style="--p:' + mv + '%" data-change="musicVol" data-input="rangeFill" aria-label="Music volume"></div>' : "") + "</div>" +
      '<div class="col full" style="gap:14px"><span class="t-3">Sound</span>' + tog("voice_cleanup", st.voice_cleanup !== false, "Voice clean-up") + tog("sfx_on", st.sfx_on !== false, "Sound effects") +
      (st.sfx_on !== false ? '<div class="col" style="gap:6px"><span>Effects level</span><input type="range" min="0" max="100" value="' + sv + '" style="--p:' + sv + '%" data-change="sfxVol" data-input="rangeFill" aria-label="Effects level"></div>' : "") + "</div></div>";
  };

  document.addEventListener("keydown", (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); if (A.ui.palette) { A.ui.palette = false; A.render(); } else act.palette(); return; }
    if (A.ui.palette) {
      const q = (A.ui.paletteQ || "").toLowerCase(); const n = COMMANDS().filter((c) => c[0].toLowerCase().includes(q)).length;
      if (e.key === "ArrowDown") { A.ui.paletteSel = Math.min(n - 1, (A.ui.paletteSel || 0) + 1); A.render(); e.preventDefault(); }
      if (e.key === "ArrowUp") { A.ui.paletteSel = Math.max(0, (A.ui.paletteSel || 0) - 1); A.render(); e.preventDefault(); }
      if (e.key === "Enter") { const b = document.querySelector('.palette-item[aria-selected="true"]'); if (b) b.click(); }
      if (e.key === "Escape") { A.ui.palette = false; A.render(); }
      return;
    }
    const tag = (e.target.tagName || "").toLowerCase();
    if (tag === "input" || tag === "textarea") return;
    if (document.querySelector(".platforms") && /^[1-4]$/.test(e.key)) { const b = document.querySelectorAll(".ptile")[Number(e.key) - 1]; if (b) b.click(); return; }
    if (document.querySelector(".rail") && /^[1-3]$/.test(e.key)) A.go(NAV[Number(e.key) - 1][0]);
  });
  A.onEvent = (ev) => {
    const p = ev.payload || {};
    if (ev.type === "render.done") A.toast("Saved to My videos", "check");
    else if (ev.type === "version.ready") A.toast("Version " + p.n + " ready", "check");
    else if (ev.type === "job.error") A.toast(p.message || "Something didn’t work", "alert", "err");
  };
  A.onUploaded = () => {};
  try { A.ui.introSeen = !!localStorage.getItem("aie-intro"); } catch (e) { A.ui.introSeen = true; }
  if (A.reduced) A.ui.introSeen = true;
})();
