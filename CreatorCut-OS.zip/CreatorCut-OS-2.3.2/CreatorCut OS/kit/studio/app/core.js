/* CreatorCut OS · Studio — core: store, API, router, DOM morphing, uploads, icons.
   Plain scripts (no build step, no modules) so the very same files also run from file:// as the
   install-time / last-resort fallback (Studio.html opened directly). */
(function () {
  "use strict";
  const A = (window.AIE = window.AIE || {});
  const SERVER = window.AIE_SERVER || null;          // injected by the Studio server
  A.online = !!SERVER;
  const forced = (location.search.match(/[?&]theme=(light|dark)/) || [])[1];   // for screenshots / support
  if (forced) document.documentElement.setAttribute("data-theme", forced);

  /* ------------------------------------------------------------ helpers -- */
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  A.esc = esc;
  A.attr = esc;
  A.cls = (...xs) => xs.filter(Boolean).join(" ");
  A.fmtTime = (t) => { t = Math.max(0, t || 0); const m = Math.floor(t / 60), s = Math.floor(t % 60); return m + ":" + String(s).padStart(2, "0"); };
  A.fmtDur = (t) => { t = Math.round(t || 0); if (t < 60) return t + " seconds"; const m = Math.floor(t / 60), s = t % 60; return m + ":" + String(s).padStart(2, "0"); };
  A.clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  A.debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
  A.greeting = () => { const h = new Date().getHours(); return h < 5 ? "Good night" : h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening"; };
  A.copy = async (text) => {
    let copied = false;
    try { await navigator.clipboard.writeText(text); copied = true; }
    catch (e) {
      const prior = document.activeElement, t = document.createElement("textarea");
      t.value = text; t.setAttribute("aria-label", "Text to copy"); document.body.appendChild(t); t.select();
      try { copied = document.execCommand("copy"); } catch (_) {}
      t.remove(); if (prior && prior.focus) prior.focus();
    }
    A.toast(copied ? "Copied" : "Could not copy. Select the example text and paste it into the chat.", copied ? "check" : "copy");
    return copied;
  };
  A.reduced = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  A.agentName = () => ((A.state && A.state.profile && A.state.profile.agent) === "codex" ? "ChatGPT" : "Claude");

  /* -------------------------------------------------------------- icons -- */
  const P = {
    download: '<path d="M12 3v12M7 10l5 5 5-5M4 16v4a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-4"/>',
    home: '<path d="M3.5 10.5 12 4l8.5 6.5V20a1 1 0 0 1-1 1H15v-6h-6v6H4.5a1 1 0 0 1-1-1z"/>',
    edit: '<circle cx="6" cy="6" r="2.6"/><circle cx="6" cy="18" r="2.6"/><path d="M8.2 7.4 20 17M8.2 16.6 20 7"/>',
    styles: '<path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/><circle cx="12" cy="12" r="3"/>',
    library: '<rect x="3.5" y="3.5" width="7" height="9" rx="2"/><rect x="13.5" y="3.5" width="7" height="6" rx="2"/><rect x="13.5" y="12.5" width="7" height="8" rx="2"/><rect x="3.5" y="15.5" width="7" height="5" rx="2"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-2.7 1.1V21a2 2 0 1 1-4 0v-.1A1.6 1.6 0 0 0 9 19.4a1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0-1.1-2.7H3a2 2 0 1 1 0-4h.1A1.6 1.6 0 0 0 4.6 9a1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.8.3H9a1.6 1.6 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8V9a1.6 1.6 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z"/>',
    upload: '<path d="M12 16V4M7 9l5-5 5 5"/><path d="M4 15v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3"/>',
    link: '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>',
    check: '<path d="M5 12.5 10 17.5 19.5 7"/>',
    x: '<path d="M6 6l12 12M18 6 6 18"/>',
    play: '<path d="M7 4.5v15l12.5-7.5z" fill="currentColor" stroke="none"/>',
    pause: '<rect x="6" y="5" width="4" height="14" rx="1" fill="currentColor" stroke="none"/><rect x="14" y="5" width="4" height="14" rx="1" fill="currentColor" stroke="none"/>',
    copy: '<rect x="8.5" y="8.5" width="12" height="12" rx="2.5"/><path d="M15.5 8.5V6a2.5 2.5 0 0 0-2.5-2.5H6A2.5 2.5 0 0 0 3.5 6v7A2.5 2.5 0 0 0 6 15.5h2.5"/>',
    folder: '<path d="M3.5 7.5a2 2 0 0 1 2-2h4l2 2.5h7a2 2 0 0 1 2 2v8.5a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2z"/>',
    send: '<path d="M4.5 12 20 4.5 15 20l-3.2-6.8z"/><path d="M11.8 13.2 20 4.5"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    minus: '<path d="M5 12h14"/>',
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    back: '<path d="M19 12H5M11 6l-6 6 6 6"/>',
    spark: '<path d="M12 3.5 13.9 10l6.6 2-6.6 2L12 20.5 10.1 14l-6.6-2 6.6-2z"/>',
    film: '<rect x="3.5" y="4.5" width="17" height="15" rx="2.5"/><path d="M7.5 4.5v15M16.5 4.5v15M3.5 9h4M3.5 15h4M16.5 9h4M16.5 15h4"/>',
    music: '<path d="M9 18V6l11-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/>',
    info: '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5M12 8h.01"/>',
    alert: '<path d="M12 4 2.8 19.5h18.4z"/><path d="M12 10v4M12 17h.01"/>',
    shield: '<path d="M12 3.5 5 6.5v5c0 4.4 3 7.6 7 9 4-1.4 7-4.6 7-9v-5z"/>',
    image: '<rect x="3.5" y="4.5" width="17" height="15" rx="2.5"/><circle cx="9" cy="10" r="1.8"/><path d="m20.5 16-5-5-9 8.5"/>',
    wand: '<path d="m4 20 11-11M14 4v3M18.5 5.5l-2 2M20 10h-3M12.5 2.5"/><path d="m15 9 1-1"/>',
    redo: '<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/>',
    eye: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/>',
    safe: '<rect x="6" y="2.5" width="12" height="19" rx="3"/><path d="M6 7h12M6 16.5h12" stroke-dasharray="2 2"/>',
    phone: '<rect x="6.5" y="2.5" width="11" height="19" rx="2.5"/><path d="M10.5 18.5h3"/>',
    chat: '<path d="M4 5.5h16v10H9l-5 4z"/>',
    dl: '<path d="M12 4v12M7 11l5 5 5-5"/><path d="M4 20h16"/>',
    user: '<circle cx="12" cy="8.5" r="3.8"/><path d="M4.5 20c1.2-3.6 4-5.5 7.5-5.5s6.3 1.9 7.5 5.5"/>',
    globe: '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.4 2.5 3.6 5.3 3.6 8.5S14.4 18 12 20.5C9.6 18 8.4 15.2 8.4 12S9.6 6 12 3.5z"/>',
    cut: '<rect x="5" y="3.5" width="5" height="11" rx="1.6" fill="currentColor" stroke="none"/><rect x="14" y="9.5" width="5" height="11" rx="1.6" fill="currentColor" stroke="none"/>',
    trash: '<path d="M4.5 7h15M10 11v6M14 11v6M6.5 7l1 12.5a1.5 1.5 0 0 0 1.5 1.5h6a1.5 1.5 0 0 0 1.5-1.5l1-12.5M9.5 7V4.5h5V7"/>',
    chev: '<path d="m9 6 6 6-6 6"/>',
    down: '<path d="m6 9 6 6 6-6"/>',
    clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
    lock: '<rect x="5" y="10.5" width="14" height="10" rx="2.5"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/>',
    layers: '<path d="m12 4 8.5 4.5L12 13 3.5 8.5z"/><path d="m3.5 12.5 8.5 4.5 8.5-4.5"/><path d="m3.5 16.5 8.5 4.5 8.5-4.5"/>',
    search: '<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/>',
    bolt: '<path d="M13 3 5 13.5h6L10 21l8-10.5h-6z"/>',
    update: '<path d="M4 12a8 8 0 0 1 13.7-5.6L20 9"/><path d="M20 4v5h-5"/><path d="M20 12a8 8 0 0 1-13.7 5.6L4 15"/><path d="M4 20v-5h5"/>',
  };
  A.icon = (name, extra) => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"' + (extra ? " " + extra : "") + ">" + (P[name] || "") + "</svg>";

  /* Platform glyphs: device shapes, no platform logos. */
  A.glyph = (k) => {
    const phone = (inner) => '<svg class="glyph" viewBox="0 0 64 84" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="14" y="4" width="36" height="76" rx="9"/><path d="M28 9.5h8" opacity=".5"/>' + inner + "</svg>";
    if (k === "tiktok") return phone('<path d="M24 60h16M24 66h10" opacity=".55"/><circle cx="43" cy="36" r="2.6" fill="currentColor" stroke="none"/><circle cx="43" cy="45" r="2.6" fill="currentColor" stroke="none"/><circle cx="43" cy="54" r="2.6" fill="currentColor" stroke="none"/><path d="M22 22h12" opacity=".35"/>');
    if (k === "reels") return phone('<rect x="21" y="26" width="22" height="22" rx="7"/><path d="M29 32.5v9l7-4.5z" fill="currentColor" stroke="none"/><path d="M22 62h20" opacity=".5"/>');
    if (k === "shorts") return phone('<path d="M26 31.5v15l12-7.5z" fill="currentColor" stroke="none"/><path d="M21 60h22M21 66h14" opacity=".5"/><circle cx="42" cy="66" r="2.2" fill="currentColor" stroke="none" opacity=".5"/>');
    return '<svg class="glyph" viewBox="0 0 64 84" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="22" width="58" height="36" rx="7"/><path d="M28 33v14l11-7z" fill="currentColor" stroke="none"/><path d="M10 52h44" opacity=".45"/><path d="M10 52h18" stroke-width="3"/><path d="M24 66h16" opacity=".5"/></svg>';
  };

  /* --------------------------------------------------------------- morph --
     Minimal DOM diffing so live updates never reset a playing video, a focused field or a scroll position. */
  function sameNode(a, b) { return a.nodeType === b.nodeType && a.nodeName === b.nodeName && (a.nodeType !== 1 || (a.getAttribute("data-key") || "") === (b.getAttribute("data-key") || "")); }
  function morphAttrs(from, to) {
    const keep = from.hasAttribute("data-keep-attrs");
    for (const at of Array.from(to.attributes)) if (from.getAttribute(at.name) !== at.value) from.setAttribute(at.name, at.value);
    if (!keep) for (const at of Array.from(from.attributes)) if (!to.hasAttribute(at.name)) from.removeAttribute(at.name);
  }
  function morph(from, to) {
    if (from.nodeType === 3 || from.nodeType === 8) { if (from.nodeValue !== to.nodeValue) from.nodeValue = to.nodeValue; return; }
    if (from.hasAttribute && from.hasAttribute("data-static") && from.getAttribute("data-static") === to.getAttribute("data-static")) return;
    morphAttrs(from, to);
    const tag = from.nodeName;
    if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") {
      if (document.activeElement !== from) {
        if (tag === "INPUT" && (from.type === "checkbox" || from.type === "radio")) from.checked = to.checked;
        else if (to.hasAttribute("value") || tag === "TEXTAREA") { const v = tag === "TEXTAREA" ? to.value : to.getAttribute("value"); if (from.value !== v && !from.hasAttribute("data-free")) from.value = v; }
      }
      if (tag !== "SELECT") return;
    }
    if (tag === "VIDEO") return;                  // keep playback state; src changes are handled by attributes
    const a = Array.from(from.childNodes), b = Array.from(to.childNodes);
    let i = 0;
    for (; i < b.length; i++) {
      const tn = b[i], fn = a[i];
      if (!fn) { from.appendChild(tn); continue; }
      if (sameNode(fn, tn)) morph(fn, tn);
      else {
        const key = tn.nodeType === 1 && tn.getAttribute("data-key");
        const match = key && a.slice(i + 1).find((n) => n.nodeType === 1 && n.getAttribute("data-key") === key && n.nodeName === tn.nodeName);
        if (match) { from.insertBefore(match, fn); a.splice(a.indexOf(match), 1); a.splice(i, 0, match); morph(match, tn); }
        else { from.replaceChild(tn, fn); a[i] = tn; }
      }
    }
    for (let j = from.childNodes.length - 1; j >= b.length; j--) from.removeChild(from.childNodes[j]);
  }
  A.patch = (root, html) => {
    const tpl = document.createElement(root.nodeName === "BODY" ? "div" : root.nodeName);
    tpl.innerHTML = html;
    if (!root.firstChild) { root.innerHTML = html; return; }
    morph(root, tpl);
  };

  /* --------------------------------------------------------------- store -- */
  A.state = null;
  A.ui = {                           // view state that lives only in this tab
    obStep: null, obDir: 1, favs: null, selectedProject: null, tab: "style", safe: false, uploads: {},
    urlDraft: "", learnJob: null, pendingRefs: [], ask: "", sheet: null, lastClip: null, libFilter: "all",
  };
  try { const saved = JSON.parse(sessionStorage.getItem("aie-ui") || "{}"); Object.assign(A.ui, saved, { uploads: {}, sheet: null }); } catch (e) {}
  A.saveUI = A.debounce(() => { try { const { obStep, favs, selectedProject, tab, safe, libFilter, briefDrafts, chatDraft, editStarts } = A.ui; sessionStorage.setItem("aie-ui", JSON.stringify({ obStep, favs, selectedProject, tab, safe, libFilter, briefDrafts, chatDraft, editStarts })); } catch (e) {} }, 200);

  const subs = [];
  A.subscribe = (fn) => subs.push(fn);
  A.render = () => {
    try { A.saveUI(); } catch (e) {}
    subs.forEach((f) => {
      try { f(A.state); }
      catch (e) { console.error(e); A.pageError(e); }                 // never a blank page
    });
  };
  // a friendly note instead of a white screen; the details go to the console for repair
  A.pageError = (e) => {
    if (document.getElementById("pageerr")) return;
    const d = document.createElement("div");
    d.id = "pageerr"; d.className = "pageerr";
    d.innerHTML = "<b>Something on this screen didn’t load.</b><span>Your videos are safe. Reload, or tell your editor in the chat: “the Studio shows an error”.</span><button>Reload</button>";
    d.querySelector("button").onclick = () => location.reload();
    document.body.appendChild(d);
  };
  window.addEventListener("error", (ev) => { if (ev && ev.error) A.pageError(ev.error); });
  window.addEventListener("unhandledrejection", (ev) => { console.error(ev.reason); });
  A.setState = (s) => {
    if (SERVER && new URLSearchParams(location.search).has('cc_embed')) {
      const fix = v => {
        if (typeof v === 'string' && v.startsWith('/media/')) return v + (v.includes('?') ? '&' : '?') + 't=' + encodeURIComponent(SERVER.token);
        if (Array.isArray(v)) return v.map(fix);
        if (v && typeof v === 'object') return Object.fromEntries(Object.entries(v).map(([k,x]) => [k,fix(x)]));
        return v;
      };
      s = fix(s);
    }
    for (const p of s.projects || []) {
      const start = (A.ui.editStarts || {})[p.name];
      const wf = p.workflow || {};
      const claimed = wf.owner && ['analysing','planning','building','reviewing'].includes(wf.phase) && Number(wf.lease_until || 0) > Date.now()/1000;
      if (start && ['sent','uncertain'].includes(start.state) && Number(wf.updated || 0) >= start.at && (claimed || wf.phase === 'ready')) {
        A.ui.editStarts[p.name] = { ...start, state:'started', confirmed:Number(wf.updated) };
        if (A.nativeChat && A.nativeChat.confirmStarted) A.nativeChat.confirmStarted(p.name);
      }
    }
    A.state = s;
    if (A.nativeChat && A.nativeChat.syncReceiver) A.nativeChat.syncReceiver(s);
    A.render();
  };

  /* ----------------------------------------------------------------- api -- */
  async function call(method, path, body) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 30000);
    try {
      const r = await fetch(path, {
        method, headers: { "X-AIE-Token": SERVER.token, "Content-Type": "application/json" },
        body: body ? JSON.stringify(body) : undefined, credentials: "same-origin", signal: controller.signal,
      });
      let data;
      try { data = await r.json(); }
      catch(e) { if (e.name === 'AbortError') throw e; throw new Error('Studio returned an incomplete response. Your draft is kept; check its saved state before retrying.'); }
      if (r.status === 403 && path !== "/api/state") A.reloadOnce();
      if (!r.ok || data.ok === false) { const err = new Error(data.error || "Something went wrong."); err.fix = data.fix; err.status = r.status; throw err; }
      return data;
    } catch(e) {
      if(e.name === 'AbortError') throw new Error('Studio did not confirm this operation in time. Your draft is kept. Check its saved state before retrying.');
      throw e;
    } finally { clearTimeout(timer); }
  }
  A.api = {
    state: () => call("GET", "/api/state"),
    nativeAction: (project, text, request_id) => call('POST', '/api/native/dispatch', {project, text, request_id}),
    mirrorUser: (project, text) => call("POST", "/api/videos/mirror-user", {project, text}),
    profile: (patch) => call("POST", "/api/profile", patch),
    event: (type, payload) => call("POST", "/api/event", { type, payload: payload || {} }),
    addUrl: (url) => call("POST", "/api/references/url", { url }),
    removeRef: (id) => call("POST", "/api/references/remove", { id }),
    retryRef: (id) => call("POST", "/api/references/retry", { id }),
    saveRulebook: (id, text) => call("POST", "/api/styles/rulebook", { id, text }),
    website: (url) => call("POST", "/api/profile/website", { url }),
    cleanStorage: () => call("POST", "/api/storage/clean", {}),
    checkUpdate: () => call("POST", "/api/update/check", {}),
    applyUpdate: () => call("POST", "/api/update/apply", {}),
    focus: (project) => call("POST", "/api/focus", { project }),
    presetFromBrief: (project, name) => call("POST", "/api/styles/from-brief", { project, name }),
    presetFromVideo: (project, name, update) => call("POST", "/api/styles/from-video", { project, name, update: update || "" }),
    forgetRule: (preset, index) => call("POST", "/api/learned/forget", { preset, index }),
    renameStyle: (id, name) => call("POST", "/api/styles/rename", { id, name }),
    teach: (label, ids, project, note) => call("POST", "/api/teach", { label, ids: ids || null, project: project || "", note: note || "" }),
    open: (what) => call("POST", "/api/open", { what }),
    job: (id) => call("GET", "/api/jobs/" + id),
    newVideo: (title, request_id) => call("POST", "/api/videos/new", { title: title || "", request_id: request_id || "" }),
    startVideo: (project) => call("POST", "/api/videos/start", { project }),
    brief: (project, brief) => call("POST", "/api/videos/brief", { project, brief }),
    removeMedia: (project, id) => call("POST", "/api/videos/media/remove", { project, id }),
    restore: (project, n) => call("POST", "/api/videos/restore", { project, n }),
    videoRef: (project, url) => call("POST", "/api/videos/reference", { project, url }),
    removeVideoRef: (project, id) => call("POST", "/api/videos/reference/remove", { project, id }),
    deleteVideo: (project) => call("POST", "/api/videos/delete", { project }),
    deletePreset: (id) => call("POST", "/api/styles/delete", { id }),
  };
  A.act = async (fn, okMsg) => {
    try { const r = await fn(); if (okMsg) A.toast(okMsg, "check"); return r; }
    catch (e) { A.toast(e.message + (e.fix ? " " + e.fix : ""), "alert", "err"); return null; }
  };

  /* Optimistic profile change: update the local copy, render, then save. */
  A.setProfile = async (patch) => {
    if (A.state) { A.state.profile = Object.assign({}, A.state.profile, patch); A.render(); }
    if (!A.online) return A.offline.setProfile(patch);
    return A.act(() => A.api.profile(patch));
  };

  /* --------------------------------------------------------------- live --- */
  let es = null, pollT = null, lastEvent = 0, downSince = 0;
  A.connect = () => {
    const poll = async () => {
      try { A.setState(await A.api.state()); downSince = 0; } catch (e) { if (!downSince) downSince = Date.now(); }
      pollT = setTimeout(poll, 1500);
    };
    const open = () => {
      try {
        es = new EventSource("/api/events/stream" + (SERVER && new URLSearchParams(location.search).has("cc_embed") ? "?t=" + encodeURIComponent(SERVER.token) : ""), { withCredentials: true });
        es.addEventListener("open", () => { downSince = 0; A.connectionBack(); });
        es.addEventListener("state", (e) => { try { const s = JSON.parse(e.data); downSince = 0; A.connectionBack(); A.setState(s); } catch (_) {} });
        es.addEventListener("studio", (e) => { try { const ev = JSON.parse(e.data); if (ev.id > lastEvent) { lastEvent = ev.id; A.onEvent && A.onEvent(ev); } } catch (_) {} });
        es.onerror = () => { if (!downSince) downSince = Date.now(); if (es.readyState === 2) { es = null; if (!pollT) poll(); } };
      } catch (e) { poll(); }
    };
    open();
    // Watchdog: a restarted Studio has a new key (reload to pick it up); a real outage shows a quiet toast.
    setInterval(async () => {
      if (!downSince || Date.now() - downSince < 5000) return;
      try { await A.api.state(); downSince = 0; A.connectionBack(); if (!es && !pollT) open(); }
      catch (e) { if (e.status === 403) A.reloadOnce(); else A.connectionLost(); }
    }, 2500);
    A.api.state().then((s) => { lastEvent = s.last_event || 0; A.setState(s); }).catch((e) => {
      if (e.status === 403) return A.reloadOnce();
      A.fatal = e.message; A.render();
      setTimeout(() => location.reload(), 8000);
    });
  };
  A.reloadOnce = () => {
    try { const t = Number(sessionStorage.getItem("aie-reload") || 0); if (Date.now() - t < 10000) return A.connectionLost(); sessionStorage.setItem("aie-reload", String(Date.now())); } catch (e) {}
    location.reload();
  };
  let lostToast = null;
  A.connectionLost = () => { if (!lostToast) lostToast = A.toast("Reconnecting to your Studio…", "redo", "", 0); };
  A.connectionBack = () => { if (lostToast) { lostToast.close(); lostToast = null; } };

  /* --------------------------------------------------------------- toast -- */
  A.toast = (msg, icon, kind, ms) => {
    let host = document.querySelector(".toasts");
    if (!host) { host = document.createElement("div"); host.className = "toasts"; host.setAttribute("aria-live", "polite"); document.body.appendChild(host); }
    const el = document.createElement("div");
    el.className = "toast" + (kind ? " " + kind : "");
    el.innerHTML = (icon ? A.icon(icon) : "") + "<span>" + esc(msg) + '</span><button class="icon-btn x" aria-label="Dismiss">' + A.icon("x") + "</button>";
    const close = () => { el.classList.add("out"); setTimeout(() => el.remove(), 300); };
    el.querySelector(".x").onclick = close;
    host.appendChild(el);
    if (ms !== 0) setTimeout(close, ms || 4200);
    return { close };
  };

  /* -------------------------------------------------------------- upload -- */
  A.upload = (file, kind, onDone, project) => {
    if (!A.online) { A.toast("Your Studio is still starting. Try again in a few seconds.", "info"); return; }
    const id = Math.random().toString(36).slice(2, 9);
    const u = { id, name: file.name, size: file.size, kind, project: project || "", progress: 0, state: "uploading", thumb: "" };
    if (file.type.startsWith("image/")) u.thumb = URL.createObjectURL(file);
    A.ui.uploads[id] = u;
    A.render();
    const x = new XMLHttpRequest();
    u.xhr = x; u.last = Date.now();
    const fail = (msg) => { if (!A.ui.uploads[id]) return; u.state = "error"; u.error = msg; A.render(); A.toast(msg, "alert", "err");
      setTimeout(() => { delete A.ui.uploads[id]; A.render(); }, 4000); };
    x.open("POST", "/api/upload?kind=" + encodeURIComponent(kind) + (project ? "&project=" + encodeURIComponent(project) : ""));
    x.setRequestHeader("X-AIE-Token", SERVER.token);
    x.setRequestHeader("X-Filename", encodeURIComponent(file.name));
    x.timeout = 20 * 60 * 1000;
    x.upload.onprogress = (e) => { if (e.lengthComputable) { u.progress = e.loaded / e.total; u.last = Date.now(); A.render(); } };
    x.onload = () => {
      let data = {};
      try { data = JSON.parse(x.responseText); } catch (e) {}
      if (x.status >= 200 && x.status < 300 && data.ok !== false) { u.state = "done"; u.result = data; delete A.ui.uploads[id]; A.render(); onDone && onDone(data); }
      else { u.state = "error"; u.error = data.error || "The upload didn't work."; A.render(); A.toast(u.error + (data.fix ? " " + data.fix : ""), "alert", "err"); setTimeout(() => { delete A.ui.uploads[id]; A.render(); }, 5000); }
    };
    x.onerror = () => fail("The upload stopped. Drop the file again.");
    x.ontimeout = () => fail("The upload took too long. Drop the file again.");
    x.send(file);
    return id;
  };
  // the X on an upload: stop it and remove it (a half-sent file is deleted by the server)
  A.cancelUpload = (id) => { const u = A.ui.uploads[id]; if (!u) return; try { u.xhr && u.xhr.abort(); } catch (e) {} delete A.ui.uploads[id]; A.render(); };
  // an upload with no progress for 45 s is stuck: say so (the X removes it)
  setInterval(() => { let ch = false; Object.values(A.ui.uploads).forEach((u) => { const st = u.state === "uploading" && u.progress < 1 && Date.now() - (u.last || 0) > 45000;
    if (st !== !!u.stalled) { u.stalled = st; ch = true; } }); if (ch) A.render(); }, 5000);
  A.kindFor = (file, want) => {
    const nm = file.name.toLowerCase();
    if (want === "broll") return /\.(mp4|mov|m4v|webm|mkv|png|jpe?g|webp)$/.test(nm) ? "broll" : null;
    if (want === "music") return /\.(mp3|wav|m4a|aac|flac|ogg)$/.test(nm) ? "music" : null;
    if (want === "footage") return /\.(mp4|mov|m4v|webm|mkv)$/.test(nm) ? "raw" : null;
    const n = file.name.toLowerCase();
    const video = /\.(mp4|mov|m4v|webm|mkv)$/.test(n), image = /\.(png|jpe?g|webp)$/.test(n), audio = /\.(mp3|wav|m4a|aac|flac|ogg)$/.test(n);
    if (want === "reference") return video || image ? "reference" : null;
    if (want === "vref") return video ? "reference" : null;
    if (want === "raw") return video ? "raw" : image ? "proof" : audio ? "music" : null;
    return video ? "raw" : image ? "proof" : audio ? "music" : null;
  };

  /* ------------------------------------------------------- drag & drop --
     The whole window accepts drops; the active drop zone (data-drop="<kind>") is highlighted. */
  // a drop zone glows while a file is dragged over it
  document.addEventListener("dragover", (e) => { const z = e.target.closest && e.target.closest("[data-drop]");
    document.querySelectorAll("[data-drop].dropping").forEach((x) => { if (x !== z) x.classList.remove("dropping"); }); if (z) z.classList.add("dropping"); });
  ["dragleave", "drop", "dragend"].forEach((t) => document.addEventListener(t, (e) => { if (t !== "dragleave" || !e.relatedTarget) document.querySelectorAll("[data-drop].dropping").forEach((x) => x.classList.remove("dropping")); }));
  A.dropTarget = () => document.querySelector("[data-drop].primary") || document.querySelector("[data-drop]");
  let dragDepth = 0;
  window.addEventListener("dragenter", (e) => { if (!e.dataTransfer || !Array.from(e.dataTransfer.types || []).includes("Files")) return; e.preventDefault(); dragDepth++; document.body.classList.add("dragging"); const t = A.dropTarget(); t && t.classList.add("over"); });
  window.addEventListener("dragover", (e) => { if (e.dataTransfer && Array.from(e.dataTransfer.types || []).includes("Files")) { e.preventDefault(); e.dataTransfer.dropEffect = "copy"; } });
  window.addEventListener("dragleave", () => { dragDepth = Math.max(0, dragDepth - 1); if (!dragDepth) { document.body.classList.remove("dragging"); document.querySelectorAll(".drop.over").forEach((d) => d.classList.remove("over")); } });
  window.addEventListener("drop", (e) => {
    if (!e.dataTransfer || !e.dataTransfer.files.length) return;
    e.preventDefault(); dragDepth = 0; document.body.classList.remove("dragging");
    document.querySelectorAll(".drop.over").forEach((d) => d.classList.remove("over"));
    const zone = (e.target.closest && e.target.closest("[data-drop]")) || A.dropTarget();
    A.handleFiles(Array.from(e.dataTransfer.files), zone ? zone.getAttribute("data-drop") : "raw", zone ? zone.getAttribute("data-project") || "" : "");
  });
  A.handleFiles = (files, want, project) => {
    let skipped = 0;
    files.forEach((f) => {
      const kind = A.kindFor(f, want);
      if (!kind) { skipped++; return; }
      A.upload(f, kind, A.onUploaded, project || (want === "footage" || want === "broll" || want === "music" || want === "vref" ? A.ui.studioProject : ""));
    });
    if (skipped) A.toast(want === "vref" ? "Add a video file (MP4 or MOV)." : want === "reference" ? "Drop videos or screenshots here." : "That file type can't be used. Drop a video from your phone (MP4 or MOV).", "info");
  };

  A.createVideoDraft = () => {
    if (A._newVideoPromise) return A._newVideoPromise;
    let key = A._newVideoKey;
    if (!key) { try { key = sessionStorage.getItem('creatorcut-new-request'); } catch (_) {} }
    if (!key) key = (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : Date.now().toString(36) + '-' + Math.random().toString(36).slice(2);
    A._newVideoKey = key;
    try { sessionStorage.setItem('creatorcut-new-request', key); } catch (_) {}
    A._newVideoPromise = A.api.newVideo('', key).then(r => {
      A._newVideoKey = null;
      try { sessionStorage.removeItem('creatorcut-new-request'); } catch (_) {}
      return r;
    }).finally(() => { A._newVideoPromise = null; });
    return A._newVideoPromise;
  };

  /* -------------------------------------------------------------- router -- */
  A.route = () => { const h = (location.hash || "#/home").slice(2).split("/"); return { name: h[0] || "home", arg: decodeURIComponent(h[1] || "") }; };
  A.go = (path) => { if (location.hash !== "#/" + path) location.hash = "#/" + path; else A.render(); };
  window.addEventListener("hashchange", () => {
    const go = () => { A.render(); window.scrollTo({ top: 0 }); };
    if (document.startViewTransition && !A.reduced) { const t = document.startViewTransition(go); [t.ready, t.finished, t.updateCallbackDone].forEach((x) => x && x.catch(() => {})); } else go();
  });

  /* ------------------------------------------------ pointer-driven light --
     Cards with .spot get a soft light that follows the cursor; .tilt panels lean a little towards it. */
  document.addEventListener("pointermove", (e) => {
    const el = e.target.closest && e.target.closest(".spot, .tilt");
    if (!el) return;
    const r = el.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
    el.style.setProperty("--mx", (x * 100).toFixed(1) + "%");
    el.style.setProperty("--my", (y * 100).toFixed(1) + "%");
    if (el.classList.contains("tilt") && !A.reduced) el.style.transform = "perspective(900px) rotateX(" + ((0.5 - y) * 3).toFixed(2) + "deg) rotateY(" + ((x - 0.5) * 4).toFixed(2) + "deg)";
  }, { passive: true });
  document.addEventListener("pointerout", (e) => {
    const el = e.target.closest && e.target.closest(".tilt");
    if (el && !el.contains(e.relatedTarget)) el.style.transform = "";
  });

  /* ----------------------------------------------------- event delegation --
     Elements declare data-act="name" (+ data-* args); views register handlers in A.actions. */
  A.actions = {};
  document.addEventListener("click", (e) => {
    const el = e.target.closest("[data-act]");
    if (!el || el.disabled) return;
    const fn = A.actions[el.getAttribute("data-act")];
    if (fn) { e.preventDefault(); fn(el, e); }
  });
  document.addEventListener("input", (e) => { const el = e.target.closest("[data-input]"); if (el) { const fn = A.actions[el.getAttribute("data-input")]; fn && fn(el, e); } });
  document.addEventListener("change", (e) => { const el = e.target.closest("[data-change]"); if (el) { const fn = A.actions[el.getAttribute("data-change")]; fn && fn(el, e); } });
  document.addEventListener("keydown", (e) => {
    const el = e.target.closest && e.target.closest("[data-enter]");
    if (el && e.key === "Enter" && !e.shiftKey) { e.preventDefault(); const fn = A.actions[el.getAttribute("data-enter")]; fn && fn(el, e); }
    if (e.key === "Escape" && A.ui.sheet) { A.ui.sheet = null; A.render(); }
  });

  /* ---------------------------------------------------- install progress --
     Expected seconds per step: drives the ring's percentage and the time-left estimate. */
  const EXPECT = { python: 20, engine: 35, packages: 45, extras: 8, model: 75, studio: 20 };
  A.installView = (inst) => {
    const steps = (inst && inst.steps) || [];
    const now = Date.now() / 1000;
    let total = 0, done = 0, left = 0;
    steps.forEach((s) => {
      const e = EXPECT[s.key] || 20; total += e;
      if (s.state === "done" || s.state === "later") done += e;
      else if (s.state === "running") { const el = s.start ? Math.max(0, now - s.start) : 0; done += Math.min(e * 0.95, el); left += Math.max(e * 0.15, e - el); }
      else left += e;
    });
    let pct = total ? Math.round((done / total) * 100) : 0;
    const st = inst ? inst.state : "none";
    if (st === "done") pct = 100;
    const eta = st === "done" ? "Ready" : left > 90 ? "About " + Math.ceil(left / 60) + " min left" : left > 0 ? "Less than " + (left > 45 ? "2 min" : "a minute") + " left" : "Almost there";
    return { pct, eta, state: st, steps };
  };
  A.ring = (pct, size, label) => {
    const r = 70, c = 2 * Math.PI * r, off = c * (1 - A.clamp(pct, 0, 100) / 100);
    return '<div class="ring' + (size === "mini" ? " mini" : "") + '" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + pct + '" aria-label="Install progress">' +
      '<svg viewBox="0 0 160 160"><defs><linearGradient id="ringgrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#4F5BFF"/><stop offset="1" stop-color="#8B5CF6"/></linearGradient></defs>' +
      '<circle class="track" cx="80" cy="80" r="' + r + '" fill="none" stroke-width="' + (size === "mini" ? 22 : 10) + '"/>' +
      '<circle class="bar" cx="80" cy="80" r="' + r + '" fill="none" stroke-width="' + (size === "mini" ? 22 : 10) + '" stroke-linecap="round" stroke-dasharray="' + c.toFixed(1) + '" stroke-dashoffset="' + off.toFixed(1) + '"/></svg>' +
      '<div class="center"><div class="pct num">' + pct + '<small>%</small></div><div class="eta">' + esc(label || "") + "</div></div></div>";
  };

  /* ------------------------------------------------------------ offline --
     Studio.html opened as a file (no server yet, or no server at all): live install progress from
     kit/studio-out/progress.js, then hand over to the server as soon as it answers. */
  A.offline = {
    profile: {},
    setProfile(patch) { Object.assign(this.profile, patch); try { localStorage.setItem("aie-offline-profile", JSON.stringify(this.profile)); } catch (e) {} },
    load() { try { this.profile = JSON.parse(localStorage.getItem("aie-offline-profile") || "{}"); } catch (e) {} },
    reload(src) { const s = document.createElement("script"); s.src = src + "?t=" + Date.now(); s.onload = s.onerror = () => s.remove(); document.head.appendChild(s); },
    snapshot() {
      const data = window.STUDIO || {};
      const prog = window.AIE_PROGRESS || {};
      const order = prog.order || ["python", "engine", "packages", "motion", "vision", "extras", "model", "studio"];
      const labels = { python: "Private Python", engine: "Video engine", packages: "Editing tools", motion: "Motion graphics", vision: "Reference reading", extras: "Fonts & sound effects", model: "Speech recognition", studio: "Your Studio" };
      const beat = window.AIE_BEAT || 0;
      let st = prog.state || "none";
      if (st === "running" && beat && Date.now() / 1000 - beat > 20) st = "paused";
      return {
        offline: true, os: prog.os || "",
        install: { state: st, error: prog.error, steps: order.map((k) => Object.assign({ key: k, label: labels[k] }, (prog.steps || {})[k] || { state: "todo" })) },
        profile: Object.assign({}, data.profile || {}, this.profile),
        styles: [],                       // only presets the creator saved, and those come from the server
        references: { items: [], learned: null }, projects: [], library: (data.videos || []).map((v) => ({ file: v.file, name: v.name, poster: v.cover, post: v.post, date: v.date })),
        raw: (data.raw_waiting || []).map((n) => ({ name: n })), jobs: [], listening: { listening: false }, pending: 0, phrases: data.phrases || {},
        checks: data.checks || { ready: false, checks: [] },
      };
    },
    start() {
      this.load();
      A.setState(this.snapshot());
      // Only hand over to the server this folder started (it writes kit/studio-out/server.js), never another one.
      const info = () => (window.AIE_SERVER_INFO && window.AIE_SERVER_INFO.port) || 0;
      const probe = () => new Promise((res) => {
        const port = info();
        if (!port) return res(0);
        let done = false;
        const finish = (ok) => { if (!done) { done = true; res(ok ? port : 0); } };
        fetch("http://127.0.0.1:" + port + "/api/ping", { mode: "no-cors", cache: "no-store" }).then(() => finish(true)).catch(() => {
          const img = new Image(); img.onload = () => finish(true); img.onerror = () => finish(false);
          img.src = "http://127.0.0.1:" + port + "/kit/studio/app/icon.svg?t=" + Date.now();
        });
        setTimeout(() => finish(false), 1500);
      });
      const tick = async () => {
        this.reload("kit/studio-out/progress.js"); this.reload("kit/studio-out/beat.js"); this.reload("kit/studio-out/server.js");
        setTimeout(() => A.setState(this.snapshot()), 250);
        const port = await probe();
        if (port) { location.replace("http://localhost:" + port + "/" + location.hash); return; }
        setTimeout(tick, 1500);
      };
      tick();
    },
  };
})();
