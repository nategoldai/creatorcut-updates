/* Conversation transport only. No model, background editor, or local send queue. */
(function () {
  'use strict';
  const A = window.AIE;
  const nonce = new URLSearchParams(location.search).get('cc_embed');
  const pending = new Map();
  const uncertainProjects = new Map();
  let next = 0;
  let hostAvailable = false, receiverAvailable = false;
  const bridge = A.nativeChat = { available: false, pending: false, error: '', uncertain: false };
  function changed() { if (A.render) A.render(); }
  bridge.syncReceiver = state => {
    receiverAvailable = !!(state && state.native_receiver && state.native_receiver.available);
    bridge.available = hostAvailable || receiverAvailable;
  };
  function request(type, payload, timeout) {
    return new Promise((resolve, reject) => {
      if (!nonce || window.parent === window) return reject(new Error('This view has no native message connection. Your text is kept.'));
      const id = 'cc-' + (++next);
      const timer = setTimeout(() => {
        pending.delete(id);
        const e = new Error('Delivery was not confirmed. Check the conversation before sending again; your text is kept.');
        e.uncertain = type === 'creatorcut:send'; reject(e);
      }, timeout);
      pending.set(id, { resolve, reject, timer });
      window.parent.postMessage({ type, id, nonce, ...payload }, '*');
    });
  }
  window.addEventListener('message', e => {
    const m = e.data;
    if (e.source !== window.parent || !nonce || !m || m.nonce !== nonce) return;
    if (m.type === 'creatorcut:capability') {
      hostAvailable = m.available === true;
      bridge.available = hostAvailable || receiverAvailable;
      bridge.error = bridge.available ? '' : 'Message connection unavailable in this preview. Your text is kept.';
      changed(); return;
    }
    if (m.type !== 'creatorcut:result' || !pending.has(m.id)) return;
    const p = pending.get(m.id); clearTimeout(p.timer); pending.delete(m.id);
    if (m.error) { const err = new Error(m.error); err.uncertain = !!m.uncertain; p.reject(err); }
    else p.resolve(m.result || {});
  });
  bridge.send = async (project, text) => {
    if (!bridge.available) throw new Error(bridge.error || 'No native message connection in this preview. Your text is kept.');
    if (bridge.pending) throw new Error('A send is awaiting delivery confirmation.');
    if (uncertainProjects.has(project)) throw new Error('Check the conversation before retrying this unconfirmed request.');
    bridge.pending = true; bridge.error = ''; changed();
    try {
      const result = hostAvailable
        ? await request('creatorcut:send', { project, text }, 20000)
        : await A.api.nativeAction(project, text, 'native-' + crypto.randomUUID());
      if (!result || result.accepted !== true) {
        const e = new Error('The editing connection did not confirm receipt. Your instructions are saved.');
        e.uncertain = !!(result && result.state === 'unconfirmed'); throw e;
      }
      return result;
    } catch (e) {
      if (!hostAvailable && (!e.status || e.status >= 500)) e.uncertain = true;
      if (e.uncertain) uncertainProjects.set(project, true);
      bridge.error = e.message; bridge.uncertain = uncertainProjects.size > 0; throw e;
    } finally { bridge.pending = false; changed(); }
  };
  bridge.confirmStarted = project => {
    // A real, newer workflow claim resolves delivery uncertainty for this
    // project only. Another project's missing receipt must stay protected.
    uncertainProjects.delete(project);
    bridge.uncertain = uncertainProjects.size > 0;
    if (!bridge.uncertain) bridge.error = '';
  };
  bridge.confirmRetry = project => {
    if (project) uncertainProjects.delete(project); else uncertainProjects.clear();
    bridge.uncertain = uncertainProjects.size > 0; bridge.error = ''; changed();
  };
  if (nonce && window.parent !== window) {
    window.parent.postMessage({ type: 'creatorcut:hello', nonce }, '*');
    // Retry only capability discovery, never a user's message.
    let tries = 0;
    const t = setInterval(() => { if (bridge.available || ++tries > 10) return clearInterval(t); window.parent.postMessage({ type: 'creatorcut:hello', nonce }, '*'); }, 500);
  }
})();
