/* MCP Apps wrapper. Host owns all inference and conversation history. */
(function () {
  'use strict';
  const cfg = window.CREATORCUT_EMBED;
  const frame = document.getElementById('studio');
  const localOrigin = new URL(cfg.url).origin;
  const requests = new Map();
  let serial = 0, available = false, hostOrigin = null;
  function notifyChild() {
    frame.contentWindow.postMessage({ type: 'creatorcut:capability', nonce: cfg.nonce, available }, localOrigin);
  }
  function rpc(method, params, timeout = 15000) {
    return new Promise((resolve, reject) => {
      const id = 'native-' + (++serial);
      const timer = setTimeout(() => { requests.delete(id); const e = new Error('The host did not confirm this request.'); e.uncertain = method === 'ui/message'; reject(e); }, timeout);
      requests.set(id, { resolve, reject, timer });
      window.parent.postMessage({ jsonrpc: '2.0', id, method, params }, (hostOrigin && hostOrigin !== 'null' ? hostOrigin : '*'));
    });
  }
  window.addEventListener('message', async e => {
    const m = e.data;
    if (!m || typeof m !== 'object') return;
    if (e.source === window.parent && e.source !== frame.contentWindow) {
      if (hostOrigin !== null && e.origin !== hostOrigin) return;
      if (m.jsonrpc !== '2.0' || !requests.has(m.id)) return;
      const r = requests.get(m.id); requests.delete(m.id); clearTimeout(r.timer);
      if (m.error) r.reject(new Error(m.error.message || 'The host rejected the request.'));
      else { if (hostOrigin === null) hostOrigin = e.origin; r.resolve(m.result || {}); }
      return;
    }
    if (e.source !== frame.contentWindow || e.origin !== localOrigin || m.nonce !== cfg.nonce) return;
    if (m.type === 'creatorcut:hello') return notifyChild();
    if (m.type !== 'creatorcut:send' || typeof m.id !== 'string') return;
    const reply = (result, error, uncertain = false) => frame.contentWindow.postMessage({ type: 'creatorcut:result', nonce: cfg.nonce, id: m.id, result, error, uncertain }, localOrigin);
    if (!available) return reply(null, 'Message connection is unavailable in this view. Your text is kept.');
    if (typeof m.project !== 'string' || !/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,80}$/.test(m.project) || typeof m.text !== 'string' || !m.text.trim() || m.text.length > 6000) return reply(null, 'Invalid message.');
    try {
      const text = '[CreatorCut Studio, project ' + m.project + ']\n' + m.text + '\nReply in this same conversation in the first person. Keep the existing editing task active.';
      const result = await rpc('ui/message', { role: 'user', content: [{ type: 'text', text }] });
      if (result.isError) return reply(null, 'The host rejected this message. Your text is kept.');
      reply({ accepted: true });
    } catch (e) { reply(null, e.message, !!e.uncertain); }
  });
  frame.addEventListener('load', notifyChild);
  if (window.parent === window) return;
  rpc('ui/initialize', { appInfo: { name: 'CREATORCUT', version: '2.3.1' }, appCapabilities: {}, protocolVersion: '2026-01-26' }, 5000)
    .then(result => {
      available = !!(result.hostCapabilities && result.hostCapabilities.message && result.hostCapabilities.message.text !== false);
      window.parent.postMessage({ jsonrpc: '2.0', method: 'ui/notifications/initialized', params: {} }, (hostOrigin && hostOrigin !== 'null' ? hostOrigin : '*'));
      notifyChild();
    }).catch(() => { available = false; notifyChild(); });
})();
