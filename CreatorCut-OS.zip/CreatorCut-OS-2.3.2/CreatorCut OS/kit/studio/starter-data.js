window.STUDIO = {
 "generated": "",
 "starter": true,
 "profile": {
  "name": "",
  "handle": "",
  "platform": "",
  "platform_label": "",
  "style": "",
  "accent": "",
  "agent": "claude",
  "cta": ""
 },
 "styles": [
  {
   "id": "bold",
   "name": "Bold Captions",
   "tagline": "Huge punchy words, fast punch-ins, high energy. The classic viral look.",
   "best_for": [
    "tips",
    "opinions",
    "motivation",
    "hot takes"
   ],
   "energy": 5,
   "origin": "toolkit",
   "accent": "#FFE500",
   "preview": {
    "fonts": [
     "kit/fonts/Anton-Regular.ttf",
     "kit/fonts/InterDisplay-Black.otf"
    ],
    "heading_fonts": [
     "kit/fonts/Anton-Regular.ttf",
     "kit/fonts/InterDisplay-Black.otf"
    ],
    "font": "anton",
    "heading": "anton",
    "upper": true,
    "size": 108,
    "mode": "highlight",
    "max_words": 2,
    "outline_w": 7,
    "text": "#FFFFFF",
    "accent": "#FFE500",
    "outline": "#000000",
    "box": false,
    "box_color": "#000000",
    "card": "#111111",
    "card_text": "#FFFFFF",
    "y": 0.64,
    "title_style": "block",
    "title_case": "upper",
    "grade": "punchy",
    "tilt": 0
   },
   "thumb": ""
  },
  {
   "id": "clean",
   "name": "Clean",
   "tagline": "Calm, readable captions and simple cards. Lets you do the talking.",
   "best_for": [
    "education",
    "business",
    "explainers"
   ],
   "energy": 2,
   "origin": "toolkit",
   "accent": "#8AB4FF",
   "preview": {
    "fonts": [
     "kit/fonts/Inter-ExtraBold.otf"
    ],
    "heading_fonts": [
     "kit/fonts/InterDisplay-Bold.otf"
    ],
    "font": "inter-extrabold",
    "heading": "inter-display-bold",
    "upper": false,
    "size": 78,
    "mode": "highlight",
    "max_words": 3,
    "outline_w": 4,
    "text": "#FFFFFF",
    "accent": "#8AB4FF",
    "outline": "#000000",
    "box": false,
    "box_color": "#000000",
    "card": "#111113",
    "card_text": "#FFFFFF",
    "y": 0.68,
    "title_style": "card",
    "title_case": "none",
    "grade": "clean",
    "tilt": 0
   },
   "thumb": ""
  },
  {
   "id": "day-in-life",
   "name": "Day in the Life",
   "tagline": "Soft, warm and personal. Feels like a vlog with a friend.",
   "best_for": [
    "vlogs",
    "routines",
    "lifestyle"
   ],
   "energy": 2,
   "origin": "toolkit",
   "accent": "#FDBA74",
   "preview": {
    "fonts": [
     "kit/fonts/Poppins-Medium.ttf"
    ],
    "heading_fonts": [
     "kit/fonts/Poppins-Bold.ttf"
    ],
    "font": "poppins-medium",
    "heading": "poppins-bold",
    "upper": false,
    "size": 70,
    "mode": "pop",
    "max_words": 3,
    "outline_w": 4,
    "text": "#FFFFFF",
    "accent": "#FDBA74",
    "outline": "#000000",
    "box": false,
    "box_color": "#000000",
    "card": "#111113",
    "card_text": "#FFFFFF",
    "y": 0.72,
    "title_style": "text",
    "title_case": "none",
    "grade": "film",
    "tilt": 0
   },
   "thumb": ""
  },
  {
   "id": "explainer",
   "name": "Explainer",
   "tagline": "Clear and confident. Lists, numbers and diagrams that make ideas click.",
   "best_for": [
    "how-to",
    "explainers",
    "education"
   ],
   "energy": 3,
   "origin": "toolkit",
   "accent": "#22D3EE",
   "preview": {
    "fonts": [
     "kit/fonts/Inter-Black.otf"
    ],
    "heading_fonts": [
     "kit/fonts/InterDisplay-Black.otf"
    ],
    "font": "inter-black",
    "heading": "inter-display-black",
    "upper": false,
    "size": 80,
    "mode": "highlight",
    "max_words": 3,
    "outline_w": 4,
    "text": "#FFFFFF",
    "accent": "#22D3EE",
    "outline": "#000000",
    "box": false,
    "box_color": "#000000",
    "card": "#111113",
    "card_text": "#FFFFFF",
    "y": 0.67,
    "title_style": "card",
    "title_case": "none",
    "grade": "natural",
    "tilt": 0
   },
   "thumb": ""
  },
  {
   "id": "finance",
   "name": "Finance",
   "tagline": "Trustworthy and sharp. Numbers that count up, charts that grow.",
   "best_for": [
    "money",
    "investing",
    "business"
   ],
   "energy": 3,
   "origin": "toolkit",
   "accent": "#22C55E",
   "preview": {
    "fonts": [
     "kit/fonts/Inter-Black.otf"
    ],
    "heading_fonts": [
     "kit/fonts/InterDisplay-Black.otf"
    ],
    "font": "inter-black",
    "heading": "inter-display-black",
    "upper": false,
    "size": 78,
    "mode": "highlight",
    "max_words": 3,
    "outline_w": 4,
    "text": "#FFFFFF",
    "accent": "#22C55E",
    "outline": "#000000",
    "box": false,
    "box_color": "#000000",
    "card": "#111113",
    "card_text": "#FFFFFF",
    "y": 0.67,
    "title_style": "card",
    "title_case": "none",
    "grade": "natural",
    "tilt": 0
   },
   "thumb": ""
  },
  {
   "id": "hot-take",
   "name": "Hot Take",
   "tagline": "Loud, fast and opinionated. Red accents and hard stamps.",
   "best_for": [
    "opinions",
    "debates",
    "reactions"
   ],
   "energy": 5,
   "origin": "toolkit",
   "accent": "#FF3B30",
   "preview": {
    "fonts": [
     "kit/fonts/ArchivoBlack-Regular.ttf",
     "kit/fonts/Inter-Black.otf"
    ],
    "heading_fonts": [
     "kit/fonts/ArchivoBlack-Regular.ttf",
     "kit/fonts/Inter-Black.otf"
    ],
    "font": "archivo-black",
    "heading": "archivo-black",
    "upper": true,
    "size": 96,
    "mode": "highlight",
    "max_words": 2,
    "outline_w": 6,
    "text": "#FFFFFF",
    "accent": "#FF3B30",
    "outline": "#000000",
    "box": false,
    "box_color": "#000000",
    "card": "#111113",
    "card_text": "#FFFFFF",
    "y": 0.64,
    "title_style": "block",
    "title_case": "upper",
    "grade": "punchy",
    "tilt": 0
   },
   "thumb": ""
  },
  {
   "id": "luxury",
   "name": "Luxury",
   "tagline": "Slow, elegant serif type and gold accents. Premium without trying.",
   "best_for": [
    "fashion",
    "beauty",
    "real estate"
   ],
   "energy": 1,
   "origin": "toolkit",
   "accent": "#D4AF37",
   "preview": {
    "fonts": [
     "kit/fonts/InstrumentSerif-Regular.ttf",
     "kit/fonts/Lora-Variable.ttf"
    ],
    "heading_fonts": [
     "kit/fonts/InstrumentSerif-Italic.ttf",
     "kit/fonts/Lora-Italic-Variable.ttf"
    ],
    "font": "instrument-serif",
    "heading": "instrument-serif-italic",
    "upper": false,
    "size": 78,
    "mode": "reveal",
    "max_words": 3,
    "outline_w": 4,
    "text": "#FFFFFF",
    "accent": "#D4AF37",
    "outline": "#000000",
    "box": false,
    "box_color": "#000000",
    "card": "#111113",
    "card_text": "#FFFFFF",
    "y": 0.72,
    "title_style": "text",
    "title_case": "none",
    "grade": "luxe",
    "tilt": 0
   },
   "thumb": ""
  },
  {
   "id": "paper",
   "name": "Paper",
   "tagline": "Playful collage: tilted cards, stickers and pops of pink.",
   "best_for": [
    "creators",
    "lifestyle",
    "fun"
   ],
   "energy": 4,
   "origin": "toolkit",
   "accent": "#FF6B9A",
   "preview": {
    "fonts": [
     "kit/fonts/Poppins-Bold.ttf"
    ],
    "heading_fonts": [
     "kit/fonts/Poppins-Bold.ttf"
    ],
    "font": "poppins-bold",
    "heading": "poppins-bold",
    "upper": false,
    "size": 68,
    "mode": "pop",
    "max_words": 3,
    "outline_w": 0,
    "text": "#FFFFFF",
    "accent": "#FF6B9A",
    "outline": "#000000",
    "box": true,
    "box_color": "#000000",
    "card": "#111113",
    "card_text": "#FFFFFF",
    "y": 0.67,
    "title_style": "card",
    "title_case": "none",
    "grade": "warm",
    "tilt": -3
   },
   "thumb": ""
  },
  {
   "id": "podcast",
   "name": "Podcast",
   "tagline": "Big readable captions for talking heads and interviews.",
   "best_for": [
    "podcasts",
    "interviews",
    "clips"
   ],
   "energy": 3,
   "origin": "toolkit",
   "accent": "#A3E635",
   "preview": {
    "fonts": [
     "kit/fonts/Inter-ExtraBold.otf"
    ],
    "heading_fonts": [
     "kit/fonts/InterDisplay-Black.otf"
    ],
    "font": "inter-extrabold",
    "heading": "inter-display-black",
    "upper": false,
    "size": 80,
    "mode": "highlight",
    "max_words": 3,
    "outline_w": 4,
    "text": "#FFFFFF",
    "accent": "#A3E635",
    "outline": "#000000",
    "box": false,
    "box_color": "#000000",
    "card": "#111113",
    "card_text": "#FFFFFF",
    "y": 0.68,
    "title_style": "text",
    "title_case": "none",
    "grade": "natural",
    "tilt": 0
   },
   "thumb": ""
  },
  {
   "id": "story-time",
   "name": "Story Time",
   "tagline": "Cinematic and intimate. Words appear as you say them.",
   "best_for": [
    "stories",
    "personal",
    "drama"
   ],
   "energy": 2,
   "origin": "toolkit",
   "accent": "#F5C99B",
   "preview": {
    "fonts": [
     "kit/fonts/Inter-SemiBold.otf"
    ],
    "heading_fonts": [
     "kit/fonts/DMSerifDisplay-Regular.ttf",
     "kit/fonts/Lora-Variable.ttf"
    ],
    "font": "inter-semibold",
    "heading": "dm-serif",
    "upper": false,
    "size": 68,
    "mode": "reveal",
    "max_words": 4,
    "outline_w": 4,
    "text": "#FFFFFF",
    "accent": "#F5C99B",
    "outline": "#000000",
    "box": false,
    "box_color": "#000000",
    "card": "#111113",
    "card_text": "#FFFFFF",
    "y": 0.73,
    "title_style": "text",
    "title_case": "none",
    "grade": "cinematic",
    "tilt": 0
   },
   "thumb": ""
  },
  {
   "id": "tech-review",
   "name": "Tech Review",
   "tagline": "Crisp and modern. Clean cards, product names in blue.",
   "best_for": [
    "tech",
    "reviews",
    "AI tools"
   ],
   "energy": 3,
   "origin": "toolkit",
   "accent": "#0A84FF",
   "preview": {
    "fonts": [
     "kit/fonts/Inter-ExtraBold.otf"
    ],
    "heading_fonts": [
     "kit/fonts/InterDisplay-Bold.otf"
    ],
    "font": "inter-extrabold",
    "heading": "inter-display-bold",
    "upper": false,
    "size": 76,
    "mode": "highlight",
    "max_words": 3,
    "outline_w": 4,
    "text": "#FFFFFF",
    "accent": "#0A84FF",
    "outline": "#000000",
    "box": false,
    "box_color": "#000000",
    "card": "#111113",
    "card_text": "#FFFFFF",
    "y": 0.68,
    "title_style": "card",
    "title_case": "none",
    "grade": "clean",
    "tilt": 0
   },
   "thumb": ""
  },
  {
   "id": "tutorial",
   "name": "Tutorial",
   "tagline": "Step by step on boxed subtitles, easy to follow with the sound off.",
   "best_for": [
    "tutorials",
    "how-to",
    "software"
   ],
   "energy": 3,
   "origin": "toolkit",
   "accent": "#FACC15",
   "preview": {
    "fonts": [
     "kit/fonts/Inter-Bold.otf"
    ],
    "heading_fonts": [
     "kit/fonts/InterDisplay-Bold.otf"
    ],
    "font": "inter-bold",
    "heading": "inter-display-bold",
    "upper": false,
    "size": 66,
    "mode": "highlight",
    "max_words": 4,
    "outline_w": 0,
    "text": "#FFFFFF",
    "accent": "#FACC15",
    "outline": "#000000",
    "box": true,
    "box_color": "#000000",
    "card": "#111113",
    "card_text": "#FFFFFF",
    "y": 0.74,
    "title_style": "card",
    "title_case": "none",
    "grade": "clean",
    "tilt": 0
   },
   "thumb": ""
  }
 ],
 "videos": [],
 "projects": [],
 "raw_waiting": [],
 "commands": [
  {
   "id": "setup",
   "title": "Set up or repair",
   "desc": "Installs everything automatically and builds this Studio. Run it again any time something is missing."
  },
  {
   "id": "edit",
   "title": "Edit a video",
   "desc": "Raw clip in, finished video out: cuts, captions, graphics, colour, sound. Shows you a preview first."
  },
  {
   "id": "hook",
   "title": "Fix my hook",
   "desc": "Rates your first 3 seconds and writes stronger opening lines and on-screen hook text."
  },
  {
   "id": "style",
   "title": "Change the look",
   "desc": "Switch to any style, or see your clip in all of them side by side."
  },
  {
   "id": "teach",
   "title": "Teach a new style",
   "desc": "Learns the look of creators you love from screenshots or clips and saves it as your own style."
  },
  {
   "id": "captions",
   "title": "Captions",
   "desc": "Change caption size, colour, position, words per line, or fix a misheard word."
  },
  {
   "id": "graphics",
   "title": "Graphics",
   "desc": "Add or change lists, counters, charts, screenshots, quotes, stickers and call-to-actions."
  },
  {
   "id": "look",
   "title": "Colour & music",
   "desc": "Colour grade, music under your voice, sound effects, zoom energy."
  },
  {
   "id": "cut",
   "title": "Tighten the cut",
   "desc": "Remove a sentence, keep a take, make it shorter or faster."
  },
  {
   "id": "retention",
   "title": "Retention check",
   "desc": "Finds moments where viewers might scroll away and fixes them."
  },
  {
   "id": "fix",
   "title": "Fix something",
   "desc": "Describe what looks wrong in plain words; it finds the cause and fixes only that."
  },
  {
   "id": "post",
   "title": "Post kit",
   "desc": "Caption, hashtags, title ideas and a cover image, ready to copy."
  },
  {
   "id": "versions",
   "title": "Every platform",
   "desc": "Make TikTok, Reels, Shorts and YouTube versions in one go."
  },
  {
   "id": "shorts",
   "title": "Long video to Shorts",
   "desc": "Finds the best 3-5 moments in a long video and edits each one."
  },
  {
   "id": "compare",
   "title": "Before & after",
   "desc": "A side-by-side video of your raw clip and the edit, ready to post."
  },
  {
   "id": "batch",
   "title": "Edit everything",
   "desc": "Edits every new clip in my-videos/raw while you do something else."
  },
  {
   "id": "studio",
   "title": "Refresh Studio",
   "desc": "Rebuilds this page with your latest videos."
  },
  {
   "id": "stuck",
   "title": "I am stuck",
   "desc": "Answers questions and solves install problems step by step."
  }
 ],
 "phrases": {
  "Cuts & pacing": [
   "Make it faster, cut every pause",
   "Keep my second take of the intro instead",
   "Cut the sentence about pricing",
   "Get it under 45 seconds",
   "Start straight on my first word",
   "Leave a beat before the big reveal"
  ],
  "Captions": [
   "Make the captions bigger",
   "Move captions higher, they cover my chin",
   "One word at a time",
   "Captions in my brand yellow",
   "Fix the spelling of my name in the captions",
   "Turn captions off for the first second",
   "Use boxed captions like a tutorial",
   "Highlight every number"
  ],
  "Graphics": [
   "Add a counter when I say 10 hours",
   "Show my 3 tips as a list that builds",
   "Put my analytics screenshot on screen when I mention views",
   "Add a big hook title for the first 2 seconds",
   "Fewer graphics, keep it clean",
   "Add a comment-for-the-guide button at the end",
   "Make a before/after comparison card",
   "Show a quote card with what my client said"
  ],
  "Look & sound": [
   "Warmer, more cinematic colours",
   "More energy, punch in on every cut",
   "No zooms",
   "Add music, quiet under my voice",
   "Turn the sound effects down",
   "Black and white for the story part",
   "Make it feel more premium"
  ],
  "Finish & post": [
   "Render the final version",
   "Make a TikTok and a YouTube Shorts version",
   "Write my caption and hashtags",
   "Make a cover with the text 'AI edits my videos'",
   "Make a before/after video",
   "Edit everything in my raw folder"
  ]
 },
 "checks": {
  "ready": false,
  "checks": []
 }
};
