# CreatorCut OS

Open the extracted inner **CreatorCut OS** folder as your project in Codex or Claude Code. Its project instructions guide setup and open Studio beside your conversation. Use the included START HERE.pdf for the introduction and kit/docs/setup-notes.txt for current setup details.

## Make your first video
1. Name your video and add raw footage and optional B-roll.
2. Add a reference or choose a saved preset if you have one. Otherwise CreatorCut Signature supplies bold white/yellow Inter Tight type, clean motion and selective behind-person emphasis. Clear instructions/reference choices override the default; unclear details fall back individually.
3. Choose your colour treatment. In Step 5, explain cuts, pacing, captions, animations, music and anything else you want.
4. Click Make my video. I’ll use the saved brief, footage and references in this same conversation. Keep the editing conversation open and ask for changes here.
5. Review the video, request changes, export, and optionally save/update a named preset for next time.

## Presets and editing memory
Home and Studio show named saved presets. A preset captures the entered brief and references, and can be updated from a reviewed final video. Existing projects keep their pinned recipe. Lasting feedback is saved locally in background preference files; one-off scene corrections stay with that project. Defaults do not become personal preferences just because they were used.

## Local tools
Setup downloads editing tools that can use several GB. Internet is required for installation. Your host AI provides the conversation and its usage limits. Studio has no separate chat. Host permissions and embedded-preview capabilities still apply. The ZIP excludes your personal projects, footage and preference files. The included worked-example reel is intentional.

For editing craft, see kit/docs/craft-guide.md and signature-style.md. Setup details: kit/docs/setup-notes.txt. Technical validation scope: kit/docs/verification-notes.md. Original recordings and reviewed outputs are preserved.
