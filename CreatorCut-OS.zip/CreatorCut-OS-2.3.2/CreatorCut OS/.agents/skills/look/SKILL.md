---
name: look
description: "Change the colour grade, music, sound effects and zoom energy of a video. Use when the creator says colour, warmer, cinematic, brighter, black and white, add music, change the music, quieter music, sound effects, zooms, more energy, or calmer."
---

Production integration: this is an auxiliary operation within the workflow in `kit/docs/production-workflow.md`. Root AGENTS.md / CLAUDE.md and the customer's current brief take precedence. Any edit/export change must update the scene contract and pass candidate review before publication. Recommendations below are conditional examples, not house-style defaults. Never infer permanent preferences from an ordinary project correction.


# Look and sound

## Colour

`edit.py grade <p>` builds a per-video colour grade (a .cube LUT made on this computer): exposure set for the face, white balance, highlight recovery, a gentle S-curve, skin-protected saturation, split tone and vignette, then **safety checks** (no clipped highlights, no crushed blacks, natural skin). It copies the reference's look only when the reference has a distinct grade. Warmer / cooler / brighter / moodier: say what you'll change, adjust, re-grade, and check the before/after numbers it prints stay inside the checks. Never blow out a face.

## Music

- Their own music: files in `my-brand/music/` or the video's media. Only music they own or licensed.
- Otherwise an original track from the built-in library (`kit/music`, made on this computer, royalty-free) matched to the preset's tempo and mood.
- Quieter / louder: the music volume (it's always ducked under the voice). No music: say so and remove it.

## Sound effects

Built-in, original: whoosh, swoosh, pop, click, tick, ding, thud, riser, camera (`kit/sfx`). Place them on graphic entrances and cuts the way the reference does, never under every word.

## Zooms / energy

Punch-ins per shot and pushes on key words. More energy: more and stronger zooms, tighter cut (`cut` skill). Calmer: fewer, smaller.

Apply, `compose` (or `preview` for classic videos), look, and say exactly what changed.
