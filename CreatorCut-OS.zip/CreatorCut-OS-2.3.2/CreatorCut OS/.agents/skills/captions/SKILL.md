---
name: captions
description: "Change the captions on a video: size, position, colour, words per line, uppercase, animation (highlight, reveal, pop), boxed subtitles, highlighted keywords, or fix a misspelled or misheard word. Use when the creator mentions captions, subtitles, text on screen size or spelling."
---

Production integration: this is an auxiliary operation within the workflow in `kit/docs/production-workflow.md`. Root AGENTS.md / CLAUDE.md and the customer's current brief take precedence. Any edit/export change must update the scene contract and pass candidate review before publication. Recommendations below are conditional examples, not house-style defaults. Never infer permanent preferences from an ordinary project correction.


# Captions

Engine below = `.venv/bin/python edit.py` (Mac/Linux) or `.venv\Scripts\python.exe edit.py` (Windows). Change one thing at a time and say exactly what changed.

## Which video, which engine

- A Studio video has `edit-plan.json` in `kit/projects/<p>/`: captions are items of `"type": "caption"` and their look lives in `styles` (format: `kit/docs/edit-plan.md`). Change the plan, then `edit.py compose <p> --note "<what changed>"` and reply in the app with `edit.py studio say --project <p> --text "…"`.
- An older chat video (no `edit-plan.json`) uses the classic captions: `edit.py set <p> captions.size=96 captions.y=0.62 …`, then `edit.py preview <p>`.

## Common requests

| They say | Studio video (`edit-plan.json`) | Classic (`edit.py set`) |
|---|---|---|
| bigger / smaller | `styles.<name>.size` (fraction of frame height; 10-15 % steps) | `captions.size=<px>` |
| higher / lower | each caption item's `y` (0 top … 1 bottom), never on the face (`_facts.face`) | `captions.y=0.6` |
| one word at a time / more words | split or merge caption items (keep sentence ends and cuts as breaks) | `captions.max_words=1` |
| all caps | `styles.<name>.case = "upper"` | `captions.uppercase=true` |
| colour | `styles.<name>.colour` (hex) | `overrides.colors.text="#FFFFFF"` |
| highlight the key word | put that word in the `accent` style | `captions.highlight=color` |
| animation | `anim` on the item (`ease` pop/cut/slide, `scale_from`, `dy_from`, `ms`) | `captions.mode=highlight|reveal|pop|plain` |
| boxed subtitles | a style with `"box": "#000000"` | `captions.box=true` |
| captions off | remove the caption items | `captions.enabled=false` |

## Spelling and misheard words

Fix the word in `kit/projects/<p>/transcript.json` (only `w`, never the times) and in `words.json` if the video is already cut, then re-run `design --force` only if they want a fresh draft; otherwise change the text directly in the caption items. Add recurring fixes to the profile so it never happens again: `edit.py profile corrections='{"cloud":"Claude"}'` and names to `vocabulary`.

## Rules

- Captions follow the preset's measured style: if a preset is used, only change what they asked, keep the rest exactly like the reference.
- Never cover the face, never go under the app buttons (bottom ~20 %, right edge).
- Look at the new contact sheet before you say it's done.

## Default visual direction
Use `kit/docs/signature-style.md` whenever a visual choice is unspecified. CreatorCut Signature is the default: Inter Tight white/yellow type, speech-timed in-place pops, selective readable words behind the speaker, purposeful animated media and gentle subject-safe finishing. Explicit instructions, clear reference observations, selected preset and relevant user memory override only the features they specify; unknown features fall back individually. Observed absence is an explicit choice (e.g. no captions or no motion), not a reason to add effects. Read style-direction.json and translate actual brief/reference/recipe/memory evidence to style-inputs.json before final planning. Defaults are not user preferences and must not be learned as feedback. Never silently restyle existing approved projects.
