---
name: batch
description: "Edit several clips in one go, in the creator's style, without stopping for approval on each one. Use when the creator drops several clips, says edit all of these, batch, or do them all."
---

Production integration: this is an auxiliary operation within the workflow in `kit/docs/production-workflow.md`. Root AGENTS.md / CLAUDE.md and the customer's current brief take precedence. Any edit/export change must update the scene contract and pass candidate review before publication. Recommendations below are conditional examples, not house-style defaults. Never infer permanent preferences from an ordinary project correction.


# Batch

1. List the new clips (in the app's media or `my-videos/raw`) and confirm the preset and platform once.
2. For each clip, run the **edit** skill in "just do it" mode: full quality bar, contact-sheet check, no approval stops.
3. Post a one-line progress note after each one ("2 of 5 done: *morning routine*, 0:42").
4. Finish with the list of finished videos and anything you weren't sure about, so they can review those first.
