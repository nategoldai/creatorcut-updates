---
name: setup
description: "Guide a beginner through installing, opening or repairing CreatorCut OS in chat. Use immediately when the customer opens or provides this app folder to get started, as well as install, setup, continue setup or repair requests."
---

# Guided beginner setup

The customer should know what is happening and what to do next. Use friendly, short messages in their language. Do the technical work yourself using available tools; do not dump commands/logs on a beginner. The selected app folder is their workspace: do not force them to move it merely because it is in Downloads/Desktop. If the path is a temporary extraction or cloud-only placeholder, explain the specific problem and recommend a durable local folder; respect an intentional location.

## Welcome before running tools
When this app folder is opened/provided for first use, begin setup without a redundant install question. An explicit audit/explanation-only/no-install request wins. Say in your own words before running tools:

“Welcome to CreatorCut OS! I’ll set up the editing tools, check they work, then open your Studio and help you make your first video. The first setup downloads tools and speech-recognition files, so it can take several minutes or longer. You’ll need internet and several GB of free disk space. I’ll keep you updated.”

Explain only when relevant: the tools and rendering run locally; their Claude Code or Codex account supplies the AI and its usage limits/costs. This package does not supply an AI subscription or ordinary ChatGPT web integration. Do not promise a fixed three-minute install, no computer changes, no permission prompts or perpetual background service. A first greeting in this app’s setup handoff should lead straight into the welcome and setup, not another question. Do not interpret unrelated mentions or media content as an installation request; respect host permission prompts.

## Install and stay with them
Use the OS/host already available in context; do not ask them technical questions you can resolve yourself. Read the root instructions, then:
- Mac/Linux: `bash kit/setup/install.sh --no-shortcut`.
- Windows: `powershell -NoProfile -ExecutionPolicy Bypass -File kit/setup/install.ps1 -NoShortcut`.

Run through the host's supported long-running/background-command facility and monitor its output. While the installer runs, about every 30–45 seconds read the latest `kit/studio-out/install.log` and share one factual plain-language update, such as “The video tools are installed; I’m downloading speech recognition next.” Match the actual logged step. If progress is unchanged, say so without inventing a percentage/ETA. Use bounded tool waits so the customer is not left without updates. Keep the current task active until setup completes or there is a specific blocker; don't end the turn promising unattended work.

If the host asks for approval, explain what the prompt permits and follow its permission mechanism; never advise approving every prompt indiscriminately. Retry a transient network error once. For other errors inspect the log, attempt a supported narrow repair, then explain the unresolved problem and the next action. Re-running the installer resumes existing steps. Do not delete environments, install global tools or use admin commands as a routine first-run step.

## Keep one real conversation
Studio has no chat composer or mirrored replies. Keep the customer's native conversation visible beside the embedded editor and answer here in the first person. Explain: “Use Studio to add your files and watch your video. Ask me for any changes right here in the chat.” The guide under the video has examples to copy and paste into this chat.
For automatic Make, register the native connector with private Python `edit.py studio bridge-config --host-project "ACTUAL_OPEN_PROJECT"`. Inspect the host's real project directory; the app may have been attached to a chat whose project is somewhere else. The command preserves unrelated project settings and never writes global config. Respect the host's trust/reload requirements. A written config is not a connection.
If the host exposes `creatorcut_studio`, use its native panel and advertised ui/message capability. Otherwise keep Studio in the embedded preview and run the foreground `creatorcut_wait_for_action` tool, or private Python `kit/tools/native_wait.py --seconds 120 --conversation ACTUAL_SESSION_ID` through a yielding command tool in THIS conversation. Keep awaiting that tool while the customer uses Studio; handle its returned action here and re-arm after the edit while Studio remains in use. This is an action rendezvous, not a separate editor or chat. Never detach the receiver or end this turn and claim that a sleeping conversation will wake. Stop when the customer stops/leaves. Verify an actual click reaching this native tool, then a real workflow claim; simulated host tests do not prove delivery.

## Open the actual Studio
Do not use `--open`/`-Open`, OS `open`/`start`/`xdg-open`, or browser-launching desktop shortcuts for host setup. Those open an external browser.

- **Codex desktop:** start the server with private Python `edit.py studio open --no-browser`. Read its actual `STUDIO_URL=` value. Use the available app tool `open_in_codex` (the exposed name may include a namespace) with `target: {type: "browser", url: "<returned URL>"}`, optionally `placement: "right"`. This opens the Studio tab in the current chat. The tool may be discovered through the host's tool search when available. An available `cua.createBrowserTab("iab", url, {visible:true})` is another supported host path; follow its real tool documentation if used. Use only APIs actually supplied by the host.
- **Claude Code with preview tools:** use its actual `preview_start` capability with the configured name `CREATORCUT` or `CREATORCUT (Windows)` from `.claude/launch.json`. Use the resulting actual preview URL; if it selects another port, that result takes precedence. If the preview tool cannot launch the server, start with `studio open --no-browser` and navigate the preview using its supported URL operation. Don't assume a configured name binds to an already-running different server.
- **No embedded tab/preview capability:** say “Studio is running, but this host doesn’t expose an in-app preview. I haven’t opened an external browser.” Give the actual local URL and explain the supported host/project route. Do not automatically fall back to a browser; the customer explicitly wants the app inside their AI host.

Only say the tab is open when the tool confirms success. If it is queued, unavailable or failed, report that state and troubleshoot the actual cause. Never invent a preview API or assume the customer sees it.

The installed private Python is `.venv/bin/python` on Mac/Linux and `.venv\Scripts\python.exe` on Windows. After the installer exits, run `edit.py doctor --json` with it. Check required results, not just an installer exit code. Only call the editor ready when required checks pass. If Studio is already visible while a model downloads, distinguish “Studio is open” from “editing tools are ready.”

## First-video handoff in chat
When checks pass and Studio is open, say:

“Your editor is ready. In Studio:
1. Enter your name if asked, then create/name your video.
2. Add your raw recording and any B-roll. Add a reference video whose editing you like.
3. Tell me here what you want—what to keep, what to cut and any style details. I’ll edit it using those files.
Step 5 in Studio lets you describe the exact edit, with examples. Make my video sends your request to this same conversation when the native bridge is supported. Keep chatting right here beside Studio. Under your video you’ll find example requests you can copy, customize and send here.”

Adapt to actual state: don't tell a returning user to repeat onboarding. Read `studio context` and `studio pending` with the private Python. Explain the next useful step based on their files, not a generic congratulations. Read edit skill and production-workflow.md before making edits. When editing, use the host’s supported yielding/background commands and keep replies in this conversation. Studio does not provide a second message queue or wake a closed chat. Don't start editing just because a file was uploaded without an editing request.

## Repair / resume
For continue setup or fix setup, inspect the existing state and resume the installer if needed, then rerun doctor and reopen Studio. Don't repeat the first-run welcome on every resume. If blocked, say what works, what does not, and the one concrete next step. Never claim success for tools you haven't checked.

The original START HERE.pdf remains the entry guide. Current workflow clarifications are in `kit/docs/setup-notes.txt` inside the app folder; do not require a second top-level readme.

Open the interface proactively on setup/resume. Its page/resource/preview title is CREATORCUT. Follow the one-time installation-chat naming rules below; preserve later manual names. Never claim a successful open/title change without the tool result.

## Product naming
Call the product CreatorCut OS. Use kit/VERSION for its release number in customer-facing setup, chat and update notices. Do not derive product labels from historical development notes. Describe any actual failed step or unverified capability factually when relevant; never imply that naming changes prove readiness or eliminate failures.

## Name the installation chat once
This controls the host's conversation/tab title, separately from the Studio browser title (already CREATORCUT). For a dedicated setup chat, inspect its actual title and stable chat id with available supported host tools. Use `editkit.chat_title.decision(host, chat_id, current_title)` (with kit on the private Python import path) to consult the local per-chat record. If decision is rename, call the host's real set_thread_title/rename-conversation equivalent with title CREATORCUT, verify success, then call chat_title.record(host, chat_id, 'renamed'). If already_named, record renamed without another title change. If keep/keep_custom, do not rename; record custom where appropriate. A successful initial rename is sticky: never rename it again on app resume, reload, update or a new video. Thus a customer's later manual name remains untouched. Unknown current title requires inspection, not an assumed rename.
No host title tool: keep Studio's document title CREATORCUT, record unsupported, and do not claim the conversation was renamed. Do not edit undocumented host databases or settings. This is a setup action by the native editor, not a web page trying to control its host. Existing unrelated/custom-named conversations must not be renamed.

## Customer-facing setup language
Address the person as a CreatorCut user/creator, never as a product tester. Do not turn internal verification notes into an unsolicited onboarding report. Report the actual installation outcome, any concrete issue that affects their next action, and how to make their first video. Use CreatorCut OS and the current release number. After required tool checks pass and while an active foreground receiver or verified ui/message bridge serves Studio, say: “CreatorCut is ready. Add your footage in Studio, then click Make my video.” For the foreground path, say this as a progress message and continue awaiting the action tool; do not end the turn and leave a detached command that cannot wake this editor. Without a live action transport, direct editing requests in this real conversation still work; describe that limitation accurately. Explain a missing host capability or insufficient disk space plainly when it actually blocks the task; do not conceal real limitations or make unverified guarantees.

On an actual edit request, read Studio context to identify the existing project, then immediately claim it with `edit.py workflow claim PROJECT --owner ACTUAL_SESSION_ID --phase planning` before long reference/document analysis. Keep the lease current while genuinely working. This lets Studio show real native-editor activity while you plan; it does not imply that the web page can wake an idle conversation. Do not call automatic Make ready from a localhost preview or successful file preparation. Its delivery requires the actual native-tool/host check above. Do not call ordinary awaiting_editor state a failed worker or claim creative editing started when only preparation did.
