---
name: teach
description: "Turn a reference video into a preset that copies its editing exactly (fonts, sizes, colours, motion, graphic language, pacing, colour grade). The Studio studies every reference automatically; you check the result and write the edit spec. Use when the Studio sends teach.ready, or the creator says copy this look, make it look like this creator, save this style."
---

Production integration: this is an auxiliary operation within the workflow in `kit/docs/production-workflow.md`. Root AGENTS.md / CLAUDE.md and the customer's current brief take precedence. Any edit/export change must update the scene contract and pass candidate review before publication. Recommendations below are conditional examples, not house-style defaults. Never infer permanent preferences from an ordinary project correction.


# Teach a style (check the study, write the spec)

Engine below = `.venv/bin/python edit.py` (Mac/Linux) or `.venv\Scripts\python.exe edit.py` (Windows).

Every reference added in the Studio is studied automatically (`edit.py study-ref`): every on-screen word with its box,
colour and size, text styles, entry motion, cuts, the person's outline, the exact fonts (matched letter by letter on the
whole Google Fonts catalogue), and the colour grade. Result: `kit/projects/_teach/_refs/<id>/kit.json`, annotated sheets
`map/annotated/page-NN.jpg` and font sheets `fonts/style-N.png`. When a preset is saved from it, the kit is in
`my-brand/styles/<style>.json` (`kit`). Never copy the reference creator's logos, name, face or footage.

## After `teach.ready` (not `hidden`)

1. **Fonts**: open each font sheet. Top row = the reference's words, below = the same words in the candidates. If the
   chosen font (row 2) isn't the closest, set the better one in `kit.styles.<N>.font` of the style JSON
   (`edit.py font "<Family>" <weight>` downloads any Google font).
2. **Read every annotated page.** Words are boxed and labelled by style (S0, S1 …), cuts are marked. Write down the
   **system**: when each style is used (per shot? one word or phrases? which word gets the accent?), the hook, and every
   graphic type with where/when/how it enters (cards, notes with arrows, bursts, icons, screenshots, stickers, text behind
   the person, cut-out person over a new background, moving backgrounds).
3. **Make the blueprint exact** (`kit/docs/blueprint.md`): open every dense sheet (`kit/projects/_teach/_refs/<id>/dense/`,
   10 frames a second at each moment a graphic appears) and `track.json`. Set in the style JSON's `blueprint`: the opening,
   the text block, the B-roll cards (size, place, tilt, behind the head or not, how many at once, how long, how they enter and
   drift), bursts, cutaways, pieces, notes, pacing. Remove what the reference never does. Set `"auto": false`.
4. **Write the edit spec** `my-brand/styles/<style>.md`: the rules above, concrete ("one big word per close shot; the last
   strong word of a sentence in yellow italic serif; white rounded cards of the thing she names, top corners, 6° tilt, 340 ms
   slide in"). Add a short **creative brief**: which kinds of new pieces fit this look (e.g. "handwritten asides about
   herself with a drawn arrow"), so every video gets fresh ideas in the same language.
5. `edit.py preset-skill <style>`, then one line to the creator: "Your preset **<name>** is saved."

If the study failed (`ref.json` has `study_error`), say so in one line and offer to add the reference as a file instead.
