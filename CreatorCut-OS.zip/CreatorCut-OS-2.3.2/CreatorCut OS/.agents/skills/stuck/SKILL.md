---
name: stuck
description: "Help when anything goes wrong or the creator has a question about CreatorCut OS: install problems, error messages, how to do something, where files are, what a command does, usage limits. Use when the creator says help, stuck, how do I, what is, doesn't work, or seems confused."
---

Production integration: this is an auxiliary operation within the workflow in `kit/docs/production-workflow.md`. Root AGENTS.md / CLAUDE.md and the customer's current brief take precedence. Any edit/export change must update the scene contract and pass candidate review before publication. Recommendations below are conditional examples, not house-style defaults. Never infer permanent preferences from an ordinary project correction.


# Help

Answer in plain words, short, then offer to do it for them.

- **Something doesn't work:** run `edit.py doctor` and read `kit/studio-out/server.log` (last 30 lines) and `kit/studio-out/install.log`. Fix it yourself if you can (re-running the installer is always safe: it skips what's done). Then say what was wrong in one sentence.
- **The app (Studio) is blank or stuck:** the **studio** skill (restart it).
- **Where are my files?** Every video has its own folder: `my-videos/<video name>/` (every version and the final), also **My videos** in the app. Presets: `my-brand/styles/`. Everything stays on their computer, inside the CreatorCut OS folder (keep it in Documents, never delete it).
- **How do I…?** Explain the 1-2 steps in the app (Studio → name your video → footage and a reference → **Make my video**; chat under the video, or here, for any change; "save my video" for the final).
- **Where's the Studio?** Type **/studio** (Codex: **$studio**), click **🎬 Open CreatorCut Studio** under the chat box, or open the **CreatorCut Studio** app.
- **Usage limits / slow:** editing uses their Claude (or ChatGPT) plan; long videos use more. If they hit a limit, the work so far is saved; continue later.
- **Updates:** the app shows "Update available" by itself; one click installs it and keeps everything.

Never ask them to type commands. Do it for them.
