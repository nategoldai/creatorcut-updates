---
name: graphics
description: "Add, remove or change motion graphics on a video: hook titles, lists that build, counters, charts, screenshots and proof images, before/after comparisons, quotes, stickers, name tags and call-to-action buttons. Use when the creator mentions graphics, animations, text on screen, show my screenshot, add a list/number/chart, or wants more or fewer graphics."
---

Production integration: this is an auxiliary operation within the workflow in `kit/docs/production-workflow.md`. Root AGENTS.md / CLAUDE.md and the customer's current brief take precedence. Any edit/export change must update the scene contract and pass candidate review before publication. Recommendations below are conditional examples, not house-style defaults. Never infer permanent preferences from an ordinary project correction.


# Graphics

**Studio videos** (`edit-plan.json`): graphics are `items` (format and every type in `kit/docs/edit-plan.md`): `caption`, `card` (a B-roll clip or screenshot on a card), `note` (handwritten aside with an arrow), `burst`, `html` (any custom piece, HTML + GSAP), with `t0`/`t1` or a `say` anchor. **Classic videos** use `beats.json` (`kit/docs/graphics-reference.md`).

## How to add one

1. Find the moment in the words (`edit.py words <p>`): the graphic appears **on the word it illustrates**.
2. Match the video's preset: use only graphic types the reference uses, in its fonts, colours and motion (read its annotated sheets and edit spec `my-brand/styles/<preset>.md`). No stock looks.
3. Proof / screenshots: the file must be in the video's media (Studio) or `my-brand/proof/`. If a claim begs for proof and there's none, ask once: "Do you have a screenshot of that? Drop it in and I'll put it on screen."
4. Never cover the face, at most one graphic at a time unless the preset stacks them, keep it inside the safe area.
5. `edit.py compose <p> --note "<what changed>"` (classic: `edit.py check <p>` then `edit.py preview <p>`). Fix every warning, look at the contact sheet, then tell them what you added and when it appears.

More or fewer graphics: density follows the preset (and its energy); say what you removed or added.

## Default visual direction
Use `kit/docs/signature-style.md` whenever a visual choice is unspecified. CreatorCut Signature is the default: Inter Tight white/yellow type, speech-timed in-place pops, selective readable words behind the speaker, purposeful animated media and gentle subject-safe finishing. Explicit instructions, clear reference observations, selected preset and relevant user memory override only the features they specify; unknown features fall back individually. Observed absence is an explicit choice (e.g. no captions or no motion), not a reason to add effects. Read style-direction.json and translate actual brief/reference/recipe/memory evidence to style-inputs.json before final planning. Defaults are not user preferences and must not be learned as feedback. Never silently restyle existing approved projects.
