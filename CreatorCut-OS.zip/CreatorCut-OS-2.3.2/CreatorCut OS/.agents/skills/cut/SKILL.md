---
name: cut
description: "Change what's kept in a video: remove a sentence, keep a different take, make it shorter, faster or slower, keep or remove pauses, restore something that was cut. Use when the creator says cut, remove, shorter, tighter, faster, slower, keep that part, or it's too long."
---

Production integration: this is an auxiliary operation within the workflow in `kit/docs/production-workflow.md`. Root AGENTS.md / CLAUDE.md and the customer's current brief take precedence. Any edit/export change must update the scene contract and pass candidate review before publication. Recommendations below are conditional examples, not house-style defaults. Never infer permanent preferences from an ordinary project correction.


# Change the cut

Engine = `.venv/bin/python edit.py` (Windows `.venv\Scripts\python.exe edit.py`).

1. Read `kit/projects/<p>/plan.md`: every phrase with ✓ kept / ✗ removed and why, plus "Inside sentences" (restarts, stretched words, mumbled fragments, lead-ins).
2. Make the change in `plan.json`:
   - remove or restore a sentence: set `keep` on that phrase;
   - a different take: swap `keep` between the two takes;
   - a word inside a sentence: add its index to `drop` (or remove it from `drop` to bring it back);
   - faster / tighter: lower `settings.max_pause` (0.12 is very tight, 0.35 relaxed); slower: raise it;
   - shorter: drop tangents, repeated points and weak examples, never the sentence that carries the main point.
3. `edit.py cut <p>` (it rewrites `words.json` and `segments.json` on the new timeline).
4. Captions and graphics follow the words. For a Studio video run `edit.py design <p> --force` only if timings moved a lot (it redrafts captions; keep the creative items you added: copy them back from the old plan), otherwise just `edit.py compose <p> --note "<what changed>"`. Classic videos: `edit.py preview <p>`.
5. Say the new length and exactly what changed ("Removed the sentence about pricing: 0:48 → 0:41").

Never cut mid-word. Leave a natural tail after a sentence's last word.
