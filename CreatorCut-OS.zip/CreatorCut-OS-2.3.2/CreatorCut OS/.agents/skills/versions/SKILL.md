---
name: versions
description: "Make versions of a finished video for other platforms (TikTok, Instagram Reels, YouTube Shorts, landscape YouTube, square or 4:5 feed posts), each with the right size, safe zones and length. Use when the creator says other platforms, Instagram version, YouTube version, export, resize, or post everywhere."
---

Production integration: this is an auxiliary operation within the workflow in `kit/docs/production-workflow.md`. Root AGENTS.md / CLAUDE.md and the customer's current brief take precedence. Any edit/export change must update the scene contract and pass candidate review before publication. Recommendations below are conditional examples, not house-style defaults. Never infer permanent preferences from an ordinary project correction.


# Versions for other platforms

1. Which platforms? TikTok, Reels and Shorts share 9:16 (one file usually works for all three; only safe zones differ slightly). Landscape YouTube (16:9), square (1:1) and feed (4:5) need their own versions.
2. `edit.py export <p> --to youtube,square` (keys: tiktok, reels, shorts, youtube, square, portrait). Each version is re-framed around the face, captions and graphics re-placed in that platform's safe area, and rendered to `my-videos/finished/`.
3. Check each contact sheet: nothing cut off, nothing under the app buttons.
4. Lengths: if a version is over the platform's sweet spot, say so and offer a shorter cut.
