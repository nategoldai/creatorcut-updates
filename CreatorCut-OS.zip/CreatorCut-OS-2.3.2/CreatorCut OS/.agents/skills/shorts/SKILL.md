---
name: shorts
description: "Turn a long video (podcast, YouTube video, livestream, talk) into several short vertical clips: finds the 3-5 strongest standalone moments with a hook and payoff, then edits each one fully. Use when the creator says shorts, clips, repurpose, cut this into TikToks, or drops a long video."
---

Production integration: this is an auxiliary operation within the workflow in `kit/docs/production-workflow.md`. Root AGENTS.md / CLAUDE.md and the customer's current brief take precedence. Any edit/export change must update the scene contract and pass candidate review before publication. Recommendations below are conditional examples, not house-style defaults. Never infer permanent preferences from an ordinary project correction.


# Shorts from a long video

1. `edit.py new <file>` then `edit.py transcribe <p>`.
2. Read the whole transcript. Pick **3-5 moments** (20-60 s each) that stand alone: a hook in the first sentence, one clear point, a payoff. Avoid moments that need earlier context.
3. Show the list (start-end, one-line hook each) and ask which ones to make, unless they said "just do it".
4. For each: `edit.py short <p> --range <start>-<end> --name <slug>`, then edit it fully with the **edit** skill (plan, cut, graphics, preview), in their preset.
5. Finish with the list of finished files and one line each on why it should perform.
