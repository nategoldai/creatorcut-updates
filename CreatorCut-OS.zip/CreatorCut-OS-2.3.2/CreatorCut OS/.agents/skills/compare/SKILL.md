---
name: compare
description: "Make a before/after video showing the raw footage next to the AI-edited version, side by side, ready to post as content about the edit itself. Use when the creator says before and after, comparison, side by side, show the difference, or wants content showing how CreatorCut OS works."
---

Production integration: this is an auxiliary operation within the workflow in `kit/docs/production-workflow.md`. Root AGENTS.md / CLAUDE.md and the customer's current brief take precedence. Any edit/export change must update the scene contract and pass candidate review before publication. Recommendations below are conditional examples, not house-style defaults. Never infer permanent preferences from an ordinary project correction.


# Before / after

1. Pick the video: the one they name, or the latest finished one (`edit.py status`). It must have a final render; if not, offer to make it first (`edit.py render <p>`).
2. `edit.py compare <p>` writes `my-videos/finished/<p>-before-after.mp4`: the raw clip on the left ("BEFORE"), the edit on the right ("AFTER"), up to 30 seconds, vertical.
3. Watch the first and last seconds (`edit.py stills <p> --video my-videos/finished/<p>-before-after.mp4`) and check both sides play and the labels are readable.
4. Tell them where it is and offer one idea for the post ("Hook: *I let AI edit my video. Here's the difference.*").
