---
name: style
description: "Switch a video to one of the creator's saved presets, or set their default preset. Presets are made only from their own reference videos (Preset Lab); there are no built-in templates to offer. Use when the creator says style, look, preset, make it look like, or wants a video to match another one."
---

Production integration: this is an auxiliary operation within the workflow in `kit/docs/production-workflow.md`. Root AGENTS.md / CLAUDE.md and the customer's current brief take precedence. Any edit/export change must update the scene contract and pass candidate review before publication. Recommendations below are conditional examples, not house-style defaults. Never infer permanent preferences from an ordinary project correction.

# Presets on a video

Engine = `.venv/bin/python edit.py` (Mac/Linux) or `.venv\Scripts\python.exe edit.py` (Windows).

- **Only the creator's presets exist for them.** Their presets are the files in `my-brand/styles/*.json` (each also a skill, `preset-<id>`). Never suggest, list or describe the engine's internal base looks in `kit/styles`; they're only a neutral starting point the engine uses when no preset is chosen.
- **Switch a video to a preset:** `engine style <project> <preset-id>`, then read that preset's skill and apply its edit spec (captions, pacing, graphics, B-roll, look). Preview with `engine preview <project> --note "Preset: <name>"` and say what changed in the app chat.
- **Default preset for new videos:** `engine profile style=<preset-id>`.
- **They want a look they don't have yet:** send them to the Preset Lab in the app (Presets → New preset) with 2–5 reference videos, or run the **teach** skill. Don't approximate it from a generic template.
- **One-off reference for one video:** `engine reference <link> --project <project>` studies it and applies it to that video only.

## Default visual direction
Use `kit/docs/signature-style.md` whenever a visual choice is unspecified. CreatorCut Signature is the default: Inter Tight white/yellow type, speech-timed in-place pops, selective readable words behind the speaker, purposeful animated media and gentle subject-safe finishing. Explicit instructions, clear reference observations, selected preset and relevant user memory override only the features they specify; unknown features fall back individually. Observed absence is an explicit choice (e.g. no captions or no motion), not a reason to add effects. Read style-direction.json and translate actual brief/reference/recipe/memory evidence to style-inputs.json before final planning. Defaults are not user preferences and must not be learned as feedback. Never silently restyle existing approved projects.
