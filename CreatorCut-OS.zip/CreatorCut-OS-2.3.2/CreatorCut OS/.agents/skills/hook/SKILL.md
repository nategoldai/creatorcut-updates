---
name: hook
description: "Rate and improve the first 3 seconds of a video: scores the hook, writes stronger spoken openings to re-film and punchy on-screen hook text, then applies the best one. Use when the creator says hook, intro, opening, first seconds, or people scroll away early."
---

Production integration: this is an auxiliary operation within the workflow in `kit/docs/production-workflow.md`. Root AGENTS.md / CLAUDE.md and the customer's current brief take precedence. Any edit/export change must update the scene contract and pass candidate review before publication. Recommendations below are conditional examples, not house-style defaults. Never infer permanent preferences from an ordinary project correction.


# The hook

1. Read the first ~10 seconds of the transcript (`edit.py words <p>`) and look at the first frames.
2. **Score it out of 10** on: starts on the payoff (no "hey guys"), a clear promise or tension in under 2 s, something moving on screen in the first second, readable hook text. Say the score and the one main reason in one line.
3. Write **3 spoken openings** they could re-film (different angles: result, mistake, curiosity) and **3 on-screen hook texts** (3-7 words, sharper than the spoken line).
4. Apply the best one now: if a stronger line exists later in the footage, offer to move it to the start (`cut` skill); set the hook text (Studio: the `role: hook` caption item in `edit-plan.json`, styled like the reference's hook; classic: the `title` beat at 0.0). Compose / preview and show them.
