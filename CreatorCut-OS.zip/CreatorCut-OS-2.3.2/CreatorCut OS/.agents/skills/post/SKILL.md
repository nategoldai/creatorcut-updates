---
name: post
description: "Create a ready-to-post kit for a finished video: platform-specific caption, hashtags, title options, a pinned comment, the best cover frame with hook text as an image, and posting tips. Use when the creator says post, caption, hashtags, description, title, thumbnail, cover, or what should I write."
---

Production integration: this is an auxiliary operation within the workflow in `kit/docs/production-workflow.md`. Root AGENTS.md / CLAUDE.md and the customer's current brief take precedence. Any edit/export change must update the scene contract and pass candidate review before publication. Recommendations below are conditional examples, not house-style defaults. Never infer permanent preferences from an ordinary project correction.

# Post kit

1. Pick the video: the latest finished one (`edit.py status`, `latest=`) unless they say otherwise. Read its `words.json` (what's said), `beats.json` (hook title) and the profile (`cta`, platform, handle).
2. Write the kit in their voice (plain, energetic, no corporate words):
   - **Caption** for their main platform:
     - TikTok/Reels: first line = the hook (it shows before "more"), 1–3 short lines of value, the CTA. Under ~300 characters.
     - Shorts: a short title-like line plus CTA.
     - YouTube: a 2–3 sentence description.
   - **Hashtags**: 3–6 relevant ones (1–2 broad, the rest niche). No banned-sounding or misleading tags.
   - **3 title / on-screen hook options** in different angles (result, number, curiosity).
   - **Pinned comment**: one line that sparks replies or repeats the CTA ("Comment VIDEO and I'll send it 👇").
   - **Posting tips**: 2 short, specific tips (e.g. "reply to the first 10 comments within an hour", "post the before/after as a follow-up").
3. Save `my-videos/finished/<project>-post.json`:
   ```json
   {"caption": "...", "hashtags": ["#..."], "titles": ["...", "...", "..."], "pinned_comment": "...", "tips": ["...", "..."], "cover_text": "..."}
   ```
   and a readable `my-videos/finished/<project>-post.md` with the same content.
4. **Cover image**: pick the strongest hook (3–6 words), then `edit.py cover <project> --text "<hook>"` (optionally `--at <seconds>` for a frame where their expression is strong; check `edit.py stills <project>` to choose). It writes `my-videos/finished/<project>-cover.jpg` with the text inside Instagram's grid-safe area. Look at it before showing.
5. `edit.py studio`: the Studio shows "Copy caption" on that video now.
6. Show the caption and hashtags in the chat, ready to copy, and give the cover path.
