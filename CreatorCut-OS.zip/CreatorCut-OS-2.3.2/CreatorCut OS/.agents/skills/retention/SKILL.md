---
name: retention
description: "Find and fix the moments where viewers might scroll away: slow starts, dead spots where nothing changes on screen, long pauses, low pace and length problems. Use when the creator says retention, boring, slow, people drop off, more engaging, or before posting an important video."
---

Production integration: this is an auxiliary operation within the workflow in `kit/docs/production-workflow.md`. Root AGENTS.md / CLAUDE.md and the customer's current brief take precedence. Any edit/export change must update the scene contract and pass candidate review before publication. Recommendations below are conditional examples, not house-style defaults. Never infer permanent preferences from an ordinary project correction.


# Retention

1. `edit.py check <p>` writes `retention.json`: a score, dead spots (nothing changes on screen for too long for the preset's energy), slow start, length vs the platform's sweet spot.
2. Look at the contact sheet around each dead spot.
3. Fix each one with the lightest touch that works: a punch-in zoom, a caption accent, a graphic that explains what's said, B-roll from their media, or a tighter cut (`cut` skill). Start on the first word; cut warm-ups.
4. Re-check and tell them the before/after score and what you changed, in 2-3 bullets.
