---
name: fix
description: "Fix anything that looks or sounds wrong in a video or in the setup, described in plain words: text cut off, captions covering the face, wrong colours, bad crop, out of sync, a graphic at the wrong time, an error message, something not working. Use when the creator says fix, it's broken, looks wrong, doesn't work, error, or describes a problem."
---

Production integration: this is an auxiliary operation within the workflow in `kit/docs/production-workflow.md`. Root AGENTS.md / CLAUDE.md and the customer's current brief take precedence. Any edit/export change must update the scene contract and pass candidate review before publication. Recommendations below are conditional examples, not house-style defaults. Never infer permanent preferences from an ordinary project correction.


# Fix it

1. **See it yourself first.** Open the latest contact sheet (`kit/projects/<p>/render/snapshots/contact-sheet.jpg` for Studio videos, `render/contact-sheet.jpg` otherwise) or make one at the exact moment: `edit.py stills <p> --at 3.2,3.6`. Read error messages fully (`kit/studio-out/server.log` has details).
2. **Find the cause, then fix the cause:**

| Problem | Where to fix |
|---|---|
| text cut off / off screen | caption or item `x`/`y`/size in `edit-plan.json`; compose fits text to the safe area, check its warnings |
| captions on the face | move them below the chin (`_facts.face` in the plan) |
| wrong colours / too bright / washed out | `edit.py grade <p>` again (safe grade); HDR clips: the cut tone-maps them |
| bad crop | `framing` in `project.json` (`{"x":0.5,"y":0.4}` focus point), then `edit.py cut <p>` |
| out of sync | a word time in `transcript.json` is wrong: fix it, `cut` again |
| graphic at the wrong moment | its `t0` or `say` anchor in the plan |
| text behind the person looks wrong | `edit.py cutout <p>` again, or remove `"behind": true` |
| error from a command | read the plain-language line and the fix it prints; `edit.py doctor` for setup problems |
| the Studio doesn't load | the **studio** skill |
| something not installed | run the installer again: `bash kit/setup/install.sh` (Windows: `install.ps1`); it skips what's done |

3. Re-render (`compose` / `preview`) and look again. Only then tell the creator, in one line, what was wrong and what you changed.
