// Readiness is tied to the shipped lock, not just executable filenames.
const fs = require('node:fs');
const path = require('node:path');
try {
  const root = path.resolve(process.argv[2]);
  const modules = fs.realpathSync(path.join(root, 'node_modules'));
  const declared = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8')).dependencies;
  for (const name of ['hyperframes', 'hyperframes-library', 'remotion', '@remotion/renderer']) {
    const directory = fs.realpathSync(path.join(root, 'node_modules', name));
    const relative = path.relative(modules, directory);
    if (relative.startsWith('..' + path.sep) || path.isAbsolute(relative)) throw Error('Renderer points outside app dependencies');
    const actual = JSON.parse(fs.readFileSync(path.join(directory, 'package.json'), 'utf8')).version;
    const expected = declared[name].split('@').pop();
    if (actual !== expected) throw Error('Installed renderer does not match the shipped version');
  }
} catch {
  process.exitCode = 1;
}
