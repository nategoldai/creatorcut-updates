# Craft example: build from the current brief

No personal reel or preset is distributed as a worked example. Use these general craft checks with the current customer's own footage and reference.

1. Choose the cleanest complete spoken take before placing graphics.
2. Match each visual response to the meaning and timing of the speech.
3. Read the reference's actual caption design, motion, pacing and observed absences; do not force an example style.
4. Use real supplied media for B-roll and readable graphics. Inspect cutouts, text edges and safe zones at full resolution.
5. Review the full movie and sound, then save the exact reviewed version.

This is optional craft advice, not a saved user preference or executable preset. Each customer starts with their own empty personal memory and preset library. The effect-library previews are demonstrations of the selected implementations, not footage to place in customer videos.
