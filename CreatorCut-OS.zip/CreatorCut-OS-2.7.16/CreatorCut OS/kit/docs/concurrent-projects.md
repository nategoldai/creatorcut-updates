# Multiple videos, one installation

Each engine command owns a unique activity record with its project and process ID. Studio selects that video's live worker, never the last unrelated command. Finishing one command cannot mark another video's command complete. Dead worker records are reported as interrupted, not successful. Updates check every live worker.

The shared heavy-operation lock covers built-in CLI processing, graphics rendering/checking, FFmpeg helpers, delivery encoding, speech transcription, reference study and masking. One heavy operation runs at a time; another waits visibly and continues automatically. This conservative default protects small laptops; it does not measure or guarantee available RAM for unrelated apps. Planning, native chat and file browsing do not need this lock. Resource waits have a six-hour deadline and are cancellable. Nested built-in calls reuse their context's lock. Never hold the gate while launching another independently gated edit.py child.

A graphics invocation uses its own TMPDIR/TMP/TEMP and cleans that directory after its subprocess group exits. There is no age-based deletion of system-wide extracted frames. Browser render workers are fixed at one. Build/render/check protect the project's assets with a writer lock.

Two simultaneous renders were checked with separate processes; resource serialization, distinct progress records, owner-process termination and foreign-cache preservation have automated regression coverage. These checks are not a guarantee against operating-system, host or hardware failures. Arbitrary terminal commands outside these helpers do not inherit their safeguards.

## Crash and connection recovery
On POSIX systems, spawned heavy workers inherit the resource-lock descriptor. If their Python parent is killed, capacity stays reserved until the owned child exits. Normal timeout cleanup stops the owned process group before releasing capacity. Windows uses its existing process/lock facilities; the POSIX inheritance test does not establish Windows process-tree crash equivalence.

Studio checks for a silent event stream, fetches real state and reconnects. Only one recovery request runs at a time. Background jobs retain every active record plus recent history; a repeat click with the same kind/project reuses the active job. A worker that cannot start becomes an error with its project preserved. On server restart, interrupted job records stay identifiable; a surviving child's later confirmed completion supersedes that old restart marker. A notification failure cannot undo a successful render. No interrupted creative job is blindly replayed or auto-approved.
