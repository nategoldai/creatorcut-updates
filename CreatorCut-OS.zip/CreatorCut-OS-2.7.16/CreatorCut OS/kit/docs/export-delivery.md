# Final export encoding

Default final delivery is CapCut-style: H.264 High, constant 30 fps, 8-bit yuv420p, approximately 12 Mbps, one-second closed GOP, one B-frame, AAC stereo at 44.1 kHz / 160 kbps and SDR Rec.709. Preserve the planned dimensions and aspect ratio; do not force landscape videos into a vertical crop. Larger canvases use an appropriate H.264 level. HDR is properly tone-mapped, never simply relabelled SDR.

The normalization runs before candidate registration and review. Evidence, audio checks, review hashes, published previews and new version files therefore refer to the normalized candidate. Final export also handles historical reviewed content through the same encoding gate and records both reviewed-source and delivery hashes in render/final-export.json. This legacy technical transcode is not a new creative edit or a claim that identical encoded bytes were reviewed.

Encoding preserves duration, speech, music, composition and playback speed. It does not add slow motion, optical flow, music or a new colour look. It preserves ordinary metadata instead of spoofing CapCut attribution or stripping AI provenance. This is a compatibility profile, not evidence of an AI block or a guarantee about Instagram reach.

Exports are atomic, locked per project and cached against source/output SHA-256 and profile version. Full decoding, duration, audio presence, dimensions and frame-rate checks run before a new delivery is accepted. Failed attempts keep the previous good output. Cached, byte-identical reviewed files are not repeatedly re-encoded.
