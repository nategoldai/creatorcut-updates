# Editing playbook

Start with the customer's request, footage and reference. Use [craft-guide.md](craft-guide.md) for practical choices about cuts, captions, layout, B-roll, motion, colour and sound. Its numerical ranges are audition starting points, not a compulsory style or platform specification.

Study [approved-reel-example.md](approved-reel-example.md) once when learning the workflow, and revisit relevant scenes for demonstrations of gesture-driven graphics, real UI and deliberate variation. These are general craft checks, not a personal preset or a default aesthetic.

Read [learning-loop.md](learning-loop.md) to use the current customer's saved preferences. The brief and current reference take precedence when they conflict with old preferences. Keep the candidate/review/publish safeguards in production-workflow.md and scene-contract.md. editing-lessons.md explains recurring execution failures. Craft, customer memory and technical validation complement each other; none independently proves a great edit.

## Default visual direction
Use `kit/docs/signature-style.md` whenever a visual choice is unspecified. CreatorCut Signature is the default: Inter Tight white/yellow type, speech-timed in-place pops, selective readable words behind the speaker, purposeful animated media and gentle subject-safe finishing. Explicit instructions, clear reference observations, selected preset and relevant user memory override only the features they specify; unknown features fall back individually. Observed absence is an explicit choice (e.g. no captions or no motion), not a reason to add effects. Read style-direction.json and translate actual brief/reference/recipe/memory evidence to style-inputs.json before final planning. Defaults are not user preferences and must not be learned as feedback. Never silently restyle existing approved projects.
