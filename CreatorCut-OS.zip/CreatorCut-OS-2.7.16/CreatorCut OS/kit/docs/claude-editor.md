# Native Claude editing contract

This installation runs the official Claude Agent SDK in a private runtime. It must never start or authenticate another provider. The selected provider is saved in installation-local editor config and captured in every durable job. Each video has one writer and a separate resumable Claude session; revisions reuse only that video’s verified session. A missing session is rebuilt from saved creative artifacts, never another video’s history.

Read persistent-editor.md for the complete creative, reference, preset, memory, revision, review and publication requirements. All those gates apply unchanged. Read the immutable request snapshot and project memory before making decisions. Match the actual selected effect implementation, captions and reference evidence. Do not substitute a generic template or change settings for convenience.

Use the provided private Python and absolute edit.py paths. Read files with Claude’s native tools and execute local editing commands through its normal tool interface. Run renderer_probe.py for this exact project before heavy work. A successful probe is not a full render. User/project/managed security rules remain in effect. Real tool confirmations are relayed to Studio; do not bypass, pre-accept or hide required consent. A denial stops that operation safely. Never edit global host settings or credentials.

Publish only the exact registered, visually reviewed and verified candidate hash for this immutable request. A text answer, saved composition or decorative animation is not a completed movie. Preserve originals, published versions, scene-bound feedback, selected presets and scoped learning. Reuse verified caches without reducing quality. One heavy render runs at a time across projects.

Saved jobs survive a browser close. Real SDK events keep liveness current; animation and elapsed time do not imply progress. Repeated clicks must not duplicate a writer or render. Recovery is bounded and preserves the immutable request. Authentication, capacity, missing input and declined access require honest supported next steps; never report a finished video without verified publication. Keep customer messages short and plain.

## Installed instruction access
The SDK receives only the existing installed documentation, skill, style, font, sound and helper-code folders as additional readable resource directories. File-edit deny rules and sandbox write fences protect these static resources. The app root, other video projects and home directory are not added. Root app instructions are supplied in session context, so do not re-read the root AGENTS.md. Normal user/managed restrictions and command confirmations remain in effect.

Use literal absolute executable paths, quote paths safely, and run one editing command per tool call. Avoid dynamic executable variables and unnecessary shell chains; never retry a declined operation through another route.
