# Exact Studio request

Make and Update save a content-addressed edit-requests/<id>.json under the existing project. Read it in full, not only its short delivery summary. It contains the complete saved brief/settings/media manifest; Update also contains every exact version-bound note. Never treat transport receipt as editing.

Claim the correct project immediately when the assigned persistent editing session receives the request. Preparation/transcription can proceed while reference analysis runs. Do not style a reference-led edit until its evidence is available; failed analysis needs recovery or an explicit user decision, never silent generic substitution.

Bind scene-plan.json `request_id` to its snapshot id. Add `request_application` rows with `key`, `status`, `reason`, and `scenes` (existing scene ids). Use editkit.requests.required(snapshot) to list exact required keys. For the full brief, break every distinct instruction into the existing requirements scene map; do not summarise away individual instructions. Each selected effect still needs its real pinned implementation and library_application proof. Explain any lower-priority setting overridden by current explicit instructions. Feedback note keys must be applied; conflicts or missing assets stay unresolved rather than marked done.

After inspecting the actual rendered candidate, release review JSON must include `request_checks`: one object per required key, each with `pass: true` and specific `observations` (at least 20 characters). Verify exact timestamps/scene mapping for every note, reference similarity in motion, captions, effects, pacing, audio and colour. These are honest editor attestations, not automatic aesthetic verification. The normal evidence/technical/hash gates still apply.

A changed Studio configuration requires a new request; status/lease changes do not. Do not overwrite a request snapshot or remove its pointer to bypass validation. A revision should preserve versions and originals, then mark included notes ready only after publishing its reviewed new version.

The snapshots preserve intent across disconnect/restart. Studio persists the job before acknowledging it; its managed supervisor uses the assigned project session independently of the host chat. Inspect existing publications before retrying. Do not fork another writer or fabricate progress.
