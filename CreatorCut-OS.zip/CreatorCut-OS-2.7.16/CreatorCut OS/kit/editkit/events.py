"""Project activity/audit events. Native conversation messages use MCP Apps ui/message.

The Studio (and the engine) append events to kit/studio-out/events.jsonl. The agent can't be pushed by a
web page, so it *waits* on the Studio: `edit.py studio wait --for clip.added,edit.request` blocks until a
matching event that hasn't been handled yet appears, prints it as JSON and exits 0 (exit 3 on timeout).

While it waits it writes a heartbeat (listening.json), so the Studio can show "Your editor is listening"."""
from __future__ import annotations

import json
import os
import re
import threading
import time
from pathlib import Path

from . import util

EVENTS = util.STUDIO_OUT / "events.jsonl"
HANDLED = util.STUDIO_OUT / "events.handled"      # ids of events the agent has already picked up
LISTENING = util.STUDIO_OUT / "listening.json"    # heartbeat while `studio wait` runs
_lock = threading.Lock()

# Events the agent acts on. Everything else (install.step, job.done, …) is informational.
# 2.2: the creator talks to the agent in its own chat, so no app event waits on the agent any more (kept for older tools).
AGENT_TYPES = {"video.ready", "teach.ready", "media.added"}     # what the editor picks up


def _read_all() -> list[dict]:
    if not EVENTS.exists():
        return []
    out = []
    for line in EVENTS.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if line:
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return out


def last_id() -> int:
    ev = _read_all()
    return ev[-1]["id"] if ev else 0


def emit(type_: str, payload: dict | None = None, source: str = "studio") -> dict:
    """Append one event. Safe to call from several threads of the server."""
    with _lock:
        EVENTS.parent.mkdir(parents=True, exist_ok=True)
        ev = {"id": last_id() + 1, "type": str(type_)[:64], "payload": payload or {}, "source": source,
              "time": round(time.time(), 3)}
        with EVENTS.open("a", encoding="utf-8") as f:
            f.write(json.dumps(ev, ensure_ascii=False) + "\n")
    return ev


def since(event_id: int, types: set[str] | None = None) -> list[dict]:
    return [e for e in _read_all() if e["id"] > event_id and (not types or e["type"] in types)]


def handled() -> set[int]:
    try:
        return {int(x) for x in HANDLED.read_text().split() if x.strip()}
    except (OSError, ValueError):
        return set()


def mark_handled(ids) -> None:
    HANDLED.parent.mkdir(parents=True, exist_ok=True)
    with HANDLED.open("a") as f:
        for i in ids:
            f.write(f"{int(i)}\n")


def pending(types: set[str] | None = None) -> list[dict]:
    """Agent events that haven't been picked up yet ("check my studio"), oldest first."""
    done = handled()
    want = types or AGENT_TYPES
    out=[]
    for e in _read_all():
        if e['type'] not in want or e['id'] in done: continue
        pid=e.get('payload',{}).get('project')
        if pid and (not isinstance(pid,str) or not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_-]{0,80}',pid) or not (util.PROJECTS/pid/'project.json').exists()):
            continue
        out.append(e)
    return out


def listening() -> dict:
    """{"listening": bool, "for": [...]}: true while a `studio wait` heartbeat is fresh."""
    try:
        d = json.loads(LISTENING.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"listening": False, "for": []}
    alive = time.time() - float(d.get("beat", 0)) < 8
    if alive and d.get("pid"):
        try:
            alive = util.process_alive(int(d["pid"]))
        except (OSError, ValueError):
            alive = False
        except Exception:
            pass
    return {"listening": alive, "for": d.get("for", []) if alive else []}


def wait(types: set[str], timeout: float) -> dict | None:
    """Block until an unhandled event of one of `types` exists. Returns the oldest one and marks it handled.
    Events of other types stay pending, so nothing the creator did in the Studio is ever lost."""
    deadline = time.time() + timeout
    try:
        while True:
            LISTENING.parent.mkdir(parents=True, exist_ok=True)
            LISTENING.write_text(json.dumps({"beat": time.time(), "pid": os.getpid(), "for": sorted(types)}))
            hits = pending(types)
            if hits:
                mark_handled([hits[0]["id"]])
                return hits[0]
            if time.time() >= deadline:
                return None
            time.sleep(0.5)
    finally:
        try:
            LISTENING.unlink()
        except OSError:
            pass


def watch_file_mtime(path: Path) -> float:
    try:
        return path.stat().st_mtime
    except OSError:
        return 0.0
