"""Consistent CapCut-style delivery encoding, before review and for legacy exports.

Encoding compatibility only; no claim about Instagram reach or AI detection.
Preserve footage, timing, aspect ratio and normal provenance metadata.
"""
from __future__ import annotations
import hashlib
import math
import os
import uuid
from pathlib import Path
from .resources import serialized
from . import util

PROFILE = 'capcut-style-30fps-v1'
FPS = 30


def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()


@serialized
def prepare(project: Path, source: Path) -> Path:
    """Atomic, cached final encode. A failed encode never replaces a good file."""
    source=Path(source);project=Path(project)
    folder=project/'render';folder.mkdir(parents=True,exist_ok=True)
    record=folder/'delivery-profile.json'
    with util.file_guard(project/'.delivery.guard','This video is already preparing its export.'):
        source_hash=digest(source)
        prior=util.read_json(record,default={})
        if prior.get('profile')==PROFILE:
            if prior.get('output_sha256')==source_hash:
                return source  # An archived copy of the reviewed delivery is byte-identical.
            cached=folder/str(prior.get('output',''))
            if cached.parent==folder and prior.get('source_sha256')==source_hash and cached.is_file() and digest(cached)==prior.get('output_sha256'):
                return cached
        info=util.probe(source)
        duration=float(info.get('duration',0))
        if not math.isfinite(duration) or duration<=0:
            raise util.Fail('The export has no valid duration.')
        width,height=info['width'],info['height']
        if width%2 or height%2:
            raise util.Fail('The planned export dimensions must be even for H.264 delivery.')
        from .cut import tonemap_filter
        vf=tonemap_filter(info)+'fps=30,setsar=1'
        level='4.1' if width*height<=1920*1080 else '5.1' if width*height<=4096*2304 else '6.0'
        out=folder/('delivery-'+source_hash[:16]+'.mp4')
        temporary=folder/('.delivery-'+uuid.uuid4().hex+'.partial.mp4')
        cmd=[util.ffmpeg_bin(),'-nostdin','-y','-v','error','-i',str(source),'-map','0:v:0','-map','0:a:0?',
             '-map_metadata','0','-vf',vf,'-c:v','libx264','-preset','fast','-b:v','12M','-maxrate','12M','-bufsize','24M',
             '-profile:v','high','-level:v',level,'-tag:v','avc1','-pix_fmt','yuv420p','-fps_mode','cfr',
             '-g','30','-keyint_min','30','-sc_threshold','0','-bf','1',
             '-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709',
             '-c:a','aac','-b:a','160k','-ar','44100','-ac','2','-movflags','+faststart',str(temporary)]
        try:
            timeout=max(120,min(14400,duration*20))
            util.run_progress(cmd,duration,label='Export encoding ready',detail='Preparing CapCut-style export',timeout=timeout)
            result=util.probe(temporary)
            if (result['width'],result['height'])!=(width,height) or abs(result['fps']-FPS)>.001:
                raise util.Fail('The export encoding did not preserve the planned picture.')
            if abs(result['duration']-duration)>max(.1,2/FPS) or result.get('has_audio')!=info.get('has_audio'):
                raise util.Fail('The export encoding changed the duration or audio track.')
            util.run([util.ffmpeg_bin(),'-nostdin','-v','error','-xerror','-i',str(temporary),'-f','null','-'],timeout=timeout)
            output_hash=digest(temporary)
            os.replace(temporary,out)
            util.write_json(record,{'profile':PROFILE,'source_sha256':source_hash,'output_sha256':output_hash,
                'output':out.name,'probe':result,'settings':{'fps':30,'keyframe_seconds':1,'video_bitrate':12000000,
                'audio_rate':44100,'audio_bitrate':160000,'audio_channels':2,'colour':'SDR Rec.709'},
                'full_decode_passed':True,'scope':'Encoding compatibility; no distribution or reach guarantee.'})
            return out
        finally:
            temporary.unlink(missing_ok=True)
