"""Put it all together: zooms, colour, images, graphics, captions, voice clean-up, music, sound effects."""
from __future__ import annotations

import datetime as dt
import os
from pathlib import Path

from . import ass, captions, graphics, look, platforms, styles as st, util


def _relpath(p: Path, base: Path) -> str:
    return os.path.relpath(Path(p).resolve(), base.resolve()).replace("\\", "/")


def build_overlay_ass(project: Path, cfg: dict, style: dict, plat: dict) -> tuple[graphics.Ctx | None, dict]:
    wj = util.read_json(project / "words.json")
    words, duration = wj["words"], wj["duration"]
    doc = ass.Doc(plat["width"], plat["height"])
    beats_file = project / "beats.json"
    beats = util.read_json(beats_file).get("beats", []) if beats_file.exists() else []
    ctx = graphics.build(doc, beats, words, duration, style, plat, project)
    n_cap = captions.build(doc, words, style, plat, duration, keywords=cfg.get("keywords", []), hide=ctx.hide,
                           overrides=cfg.get("captions"))
    if cfg.get("progress_bar", style.get("progress_bar")):
        graphics.progress_bar(doc, style, plat, duration)
    out = project / "render" / "overlay.ass"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(doc.render(), encoding="utf-8")
    return ctx, {"captions": n_cap, "graphics": len(beats), "duration": duration}


def render(project: Path, preview: bool = False, out_path: Path | None = None, limit: float | None = None) -> Path:
    if (project / "edit-plan.json").exists():          # the motion-graphics engine (HyperFrames) edit
        return render_plan(project, preview, out_path)
    if preview and out_path is not None:  # explicit legacy style-tour experiment, not a completed edit
        return _render_classic(project, preview, out_path, limit)
    raise util.Fail('Build a scene contract and edit plan before rendering this video.', 'Use the edit skill; legacy auto graphics are only a scaffold.')


def render_plan(project: Path, preview: bool = False, out_path: Path | None = None) -> Path:
    """Build the HyperFrames composition from edit-plan.json, refuse to render if its checks fail, render, then
    normalise loudness. Previews render fast (draft); the final in full quality."""
    import json as _json
    from . import compose
    cfg = util.read_json(project / "project.json")
    plan = util.read_json(project / "edit-plan.json")
    if not plan.get('items') and not plan.get('person_cutout') and not plan.get('background',{}).get('zooms'):
        # An explicitly planned cut-only video needs no browser composition.
        from . import soundtrack, workflow
        target = out_path or project/'render'/'candidate.mp4'
        util.write_json(project/'render'/'check.json', {'ok':True,'errors':[],'warnings':[],
                        'review_findings':[],'backend':'explicit cut-only scene contract'})
        soundtrack.mix(project,workflow.local(project,plan['background']['src']),target,plan)
        return target
    util.step("Building the motion graphics…")
    compose.build(project, plan)
    chk = compose.check(project)
    if not chk["ok"]:
        util.write_json(project / "render" / "check.json", chk)
        raise util.Fail("The edit plan has problems the render would show.", "; ".join(chk["errors"])[:600])
    util.write_json(project / "render" / "check.json", chk)

    def prog(line: str):
        if line.startswith("@hf-progress"):
            try:
                d = _json.loads(line.split(" ", 1)[1])
                util.activity({"capture": "Drawing every frame", "encode": "Encoding", "assemble": "Adding the sound"}.get(d.get("code"), "Rendering"),
                              d.get("pct"))
            except Exception:
                pass
    from . import artifact_cache as cache, cut as cutmod
    visual_plan={k:v for k,v in plan.items() if k!='audio'}
    def visual_key():
        runtime=[f for f in (compose.motion.RENDER/'package-lock.json',compose.motion.RENDER/'node_modules/gsap/dist/gsap.min.js',compose.motion.RENDER/'node_modules/hyperframes/package.json') if f.is_file()]
        runtime += sorted((compose.motion.RENDER/'node_modules/hyperframes/dist').glob('*.js'))
        return cache.key('full-visual-render-v1',compose.visual_inputs(project,plan)+runtime+([project/'words.json'] if (project/'words.json').is_file() else []),{'plan':visual_plan,'quality':'draft' if preview else 'looks'},[Path(__file__),Path(compose.__file__),Path(compose.motion.__file__),Path(cutmod.__file__)])
    expected=visual_key()
    cache_dir=project/'render'/'.visual-cache';cache_dir.mkdir(parents=True,exist_ok=True)
    raw=cache_dir/'frames.mp4';manifest=cache_dir/'manifest.json'
    if cache.hit(manifest,expected):
        util.step('Reusing the exact unchanged visual render; updating your sound')
    else:
        util.step("Rendering the preview…" if preview else "Rendering the final video in full quality…")
        compose.render(project, raw, quality="draft" if preview else "looks", progress=prog)
        if visual_key()!=expected:raise util.Fail('Visual inputs changed while rendering. Retry the updated plan.')
        cache.commit(manifest,expected,[raw])
    if out_path is None:
        out_path = project / 'render' / 'candidate.mp4'
    from . import soundtrack
    soundtrack.mix(project, raw, out_path, plan)
    return out_path


def _render_classic(project: Path, preview: bool = False, out_path: Path | None = None, limit: float | None = None) -> Path:
    cfg = util.read_json(project / "project.json")
    style = st.for_project(cfg)
    plat = platforms.get(cfg.get("platform", "tiktok"))
    W, H, fps = plat["width"], plat["height"], float(plat["fps"])
    cut = project / "cut.mp4"
    if not cut.exists():
        raise util.Fail("This project hasn't been cut yet.", f"Run: edit.py cut {project.name}")

    util.step("Building captions and graphics…")
    ctx, stats = build_overlay_ass(project, cfg, style, plat)
    for w in ctx.warnings:
        util.warn(w)
    duration = stats["duration"]

    segs = util.read_json(project / "segments.json", default={"segments": []})["segments"]
    inputs: list[list[str]] = [["-i", "cut.mp4"]]
    fparts: list[str] = []

    # ---- video
    zoom = look.zoom_filter(segs, ctx.zooms, style, W, H, fps) if cfg.get("zoom", True) else ""
    gname = cfg.get("grade") or style.get("grade", "natural")
    grade = style["grade_filter"] if gname == "custom" and style.get("grade_filter") else look.grade_filter(gname)
    chain = ",".join(x for x in [zoom, grade] if x) or "null"
    fparts.append(f"[0:v]{chain},setsar=1[vb]")
    last = "vb"
    # B-roll clips and moving photos (under the graphics and captions)
    for j, br in enumerate(ctx.brolls):
        idx = len(inputs)
        a, z = br["start"], br["end"]
        dur = max(0.3, z - a)
        if br["image"]:
            inputs.append(["-loop", "1", "-framerate", f"{fps:g}", "-t", f"{dur:.3f}", "-i", _relpath(Path(br["file"]), project)])
        else:
            inputs.append(["-ss", f"{br['offset']:.3f}", "-t", f"{dur:.3f}", "-i", _relpath(Path(br["file"]), project)])
        full = br["mode"] != "pip"
        bw, bh = (W, H) if full else (int(W * 0.44) // 2 * 2, int(H * 0.27) // 2 * 2)
        mask_idx = None
        if not full:
            # picture-in-picture as a card: rounded corners, then a slight alternating tilt (like hand-placed screenshots)
            mask = project / "render" / f"pipmask-{bw}x{bh}.png"
            if not mask.exists():
                from PIL import Image, ImageDraw
                mask.parent.mkdir(parents=True, exist_ok=True)
                m = Image.new("L", (bw, bh), 0)
                ImageDraw.Draw(m).rounded_rectangle((0, 0, bw - 1, bh - 1), radius=int(bw * 0.06), fill=255)
                m.save(mask)
            inputs.append(["-loop", "1", "-framerate", f"{fps:g}", "-t", f"{dur:.3f}", "-i", _relpath(mask, project)])
            mask_idx = len(inputs) - 1
        if br["image"] and br["motion"] != "none":
            # slow push-in (or pan) rendered by scaling a little each frame, then cropping to the frame
            zoom = f"(1.04+0.10*t/{dur:.3f})"
            pre = (f"[{idx}:v]scale={bw}:{bh}:force_original_aspect_ratio=increase,crop={bw}:{bh},"
                   f"scale=w='iw*{zoom}':h='ih*{zoom}':eval=frame,"
                   + (f"crop={bw}:{bh}:x='(iw-{bw})*t/{dur:.3f}':y='(ih-{bh})/2'" if br["motion"] == "pan"
                      else f"crop={bw}:{bh}:x='(iw-{bw})/2':y='(ih-{bh})/2'"))
        else:
            pre = f"[{idx}:v]fps={fps:g},scale={bw}:{bh}:force_original_aspect_ratio=increase,crop={bw}:{bh}"
        if mask_idx is not None:
            tilt = 0.045 if j % 2 == 0 else -0.04
            pre += (f",setsar=1,format=yuva420p[bx{j}];[{mask_idx}:v]format=gray,scale={bw}:{bh}[bm{j}];"
                    f"[bx{j}][bm{j}]alphamerge,rotate=a={tilt}:c=none:ow=rotw({tilt}):oh=roth({tilt})")
        pre += (f",setsar=1,format=yuva420p,fade=t=in:st=0:d=0.12:alpha=1,fade=t=out:st={max(0, dur - 0.12):.3f}:d=0.12:alpha=1,"
                f"setpts=PTS-STARTPTS+{a:.3f}/TB[br{j}]")
        fparts.append(pre)
        # cards sit in the top corners, beside the face (alternating sides), never over it
        x, y = (0, 0) if full else ((int(W * 0.03) if j % 2 == 0 else W - bw - int(W * 0.03)), int(H * 0.07))
        fparts.append(f"[{last}][br{j}]overlay=x={x}:y={y}:enable='between(t,{a:.3f},{z:.3f})':eof_action=pass[vbr{j}]")
        last = f"vbr{j}"
    overlays = list(ctx.overlays)
    prof = util.load_profile()
    logo = prof.get("brand", {}).get("logo")
    if prof.get("brand", {}).get("watermark") and logo and (util.ROOT / logo).exists():
        overlays.append({"png": str(util.ROOT / logo), "x": W * plat["safe"]["left"] + 10, "y": H * plat["safe"]["top"],
                         "start": 0, "end": duration, "anim": "none", "w": 0, "h": 0, "logo": True})
    for i, o in enumerate(overlays):
        idx = len(inputs)
        inputs.append(["-loop", "1", "-framerate", f"{fps:g}", "-t", f"{duration:.3f}", "-i", _relpath(Path(o["png"]), project)])
        a, b = o["start"], o["end"]
        pre = f"[{idx}:v]format=rgba"
        if o.get("logo"):
            pre += f",scale={int(W * 0.12)}:-1,colorchannelmixer=aa=0.85"
        else:
            pre += f",fade=t=in:st={a:.3f}:d=0.22:alpha=1,fade=t=out:st={max(a, b - 0.22):.3f}:d=0.22:alpha=1"
        fparts.append(f"{pre}[o{i}]")
        p = f"min(1,max(0,(t-{a:.3f})/0.32))"
        x, y = f"{o['x']:.1f}", f"{o['y']:.1f}"
        if o["anim"] == "slide":
            x = f"{o['x']:.1f}-90*pow(1-{p},3)"
        elif o["anim"] == "rise":
            y = f"{o['y']:.1f}+80*pow(1-{p},3)"
        fparts.append(f"[{last}][o{i}]overlay=x='{x}':y='{y}':enable='between(t,{a:.3f},{b:.3f})':eval=frame[v{i}]")
        last = f"v{i}"
    fonts_rel = _relpath(util.FONTS_DIR, project)
    final_scale = ",scale=iw/2:ih/2" if preview else ""
    fparts.append(f"[{last}]ass=render/overlay.ass:fontsdir={fonts_rel}{final_scale},format=yuv420p[vout]")

    # ---- audio
    voice = look.VOICE if cfg.get("voice_cleanup", True) else "anull"
    fparts.append(f"[0:a]{voice}[voice]")
    mix = ["voice"]
    music = look.pick_music(cfg, style)
    if music:
        idx = len(inputs)
        inputs.append(["-stream_loop", "-1", "-i", _relpath(music, project)])
        vol = float(cfg.get("music_volume", style.get("music", {}).get("volume", 0.16)))
        fparts.append(f"[voice]asplit=2[voicemix][voicekey]")
        mix = ["voicemix"]
        fparts.append(f"[{idx}:a]aresample=48000,aformat=channel_layouts=stereo,atrim=0:{duration:.3f},volume={vol:.3f},"
                      f"afade=t=in:d=0.6,afade=t=out:st={max(0, duration - 1.8):.3f}:d=1.8[mus]")
        fparts.append("[mus][voicekey]sidechaincompress=threshold=0.025:ratio=9:attack=12:release=380:makeup=1[ducked]")
        mix.append("ducked")
    for j, s in enumerate(ctx.sfx if cfg.get("sfx", True) else []):
        path = look.sfx_path(s["name"])
        if not path:
            continue
        idx = len(inputs)
        inputs.append(["-i", _relpath(path, project)])
        ms = int(s["t"] * 1000)
        fparts.append(f"[{idx}:a]aresample=48000,aformat=channel_layouts=stereo,volume={s['volume']:.2f},adelay={ms}|{ms}[sx{j}]")
        mix.append(f"sx{j}")
    mix_in = "".join(f"[{m}]" for m in mix)
    fparts.append(f"{mix_in}amix=inputs={len(mix)}:duration=first:normalize=0:dropout_transition=0,"
                  f"loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000[aout]")

    script = project / "render" / "render.filter"
    script.write_text(";\n".join(fparts), encoding="utf-8")

    if out_path is None:
        if preview:
            out_path = project / "preview.mp4"
        else:
            version = int(cfg.get("version", 0)) + 1
            util.FINISHED.mkdir(parents=True, exist_ok=True)
            out_path = util.FINISHED / f"{project.name}-{style['id']}-{plat['key']}-v{version}.mp4"
            cfg["version"] = version
    enc = (["-c:v", "libx264", "-preset", "ultrafast", "-crf", "30"] if preview else
           ["-c:v", "libx264", "-preset", "medium", "-crf", "18", "-profile:v", "high", "-tag:v", "avc1"])
    cmd = [util.ffmpeg_bin(), "-y", "-hide_banner"]
    for i in inputs:
        cmd += i
    cmd += [*util.filter_script_args(Path("render/render.filter")), "-map", "[vout]", "-map", "[aout]",
            *enc, "-r", f"{fps:g}", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
            "-movflags", "+faststart", "-t", f"{min(duration, limit or duration):.3f}", _relpath(out_path, project)]
    util.step("Rendering the preview (fast, lower quality)…" if preview else "Rendering the final video in full quality…")
    util.activity(f"Rendering {len(overlays)} overlays, {len(ctx.brolls)} B-roll, {stats['captions']} captions", 0)
    util.run_progress(cmd, min(duration, limit or duration), label="Preview ready" if preview else "Final video rendered",
                      cwd=project, detail="Rendering" if preview else "Exporting in full quality")
    if not preview:
        from . import delivery
        ready = delivery.prepare(project, out_path)
        if ready.resolve() != out_path.resolve():
            import shutil
            temporary = out_path.with_suffix('.delivery.partial.mp4')
            try:
                shutil.copy2(ready, temporary)
                os.replace(temporary, out_path)
            finally:
                temporary.unlink(missing_ok=True)
        with util.file_guard(project / '.metadata.guard', 'This video is saving another change.', timeout=5):
            current = util.read_json(project / 'project.json')
            current.update(latest=util.rel(out_path),rendered_at=dt.datetime.now().isoformat(timespec='seconds'),status='finished')
            util.write_json(project / 'project.json', current)
    return out_path


def done(project: Path, out: Path) -> None:
    """After a final render: tidy the big working files the creator never needs again."""
    for name in ("audio16k.wav",):
        f = project / name
        if f.exists():
            f.unlink()
    for f in (project / "render").glob("*.png") if (project / "render").exists() else []:
        if f.name.startswith(("pipmask-",)):
            continue
        f.unlink()


def stills(project: Path, video: Path | None = None, times: list[float] | None = None) -> Path:
    """A contact sheet: 12 frames of the video in a grid, so the editor (and the agent) can check it at a glance."""
    from PIL import Image
    video = Path(video or project / "preview.mp4")
    info = util.probe(video)
    dur = info["duration"]
    if not times:
        n = 12
        times = [dur * (k + 0.5) / n for k in range(n)]
    out_dir = project / "render" / "stills"
    out_dir.mkdir(parents=True, exist_ok=True)
    for f in out_dir.glob("*.jpg"):
        f.unlink()
    frames = []
    for k, t in enumerate(times):
        f = out_dir / f"{k:02d}.jpg"
        util.run([util.ffmpeg_bin(), "-y", "-hide_banner", "-ss", f"{t:.2f}", "-i", str(video), "-frames:v", "1",
                  "-vf", "scale=360:-2", "-q:v", "3", str(f)], check=False)
        if f.exists():
            frames.append((t, f))
    if not frames:
        raise util.Fail("Couldn't read frames from the video.")
    w, h = Image.open(frames[0][1]).size
    cols = 6 if len(frames) > 8 else 4
    rows = (len(frames) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * w + (cols + 1) * 8, rows * (h + 26) + 8), (18, 18, 20))
    from PIL import ImageDraw
    d = ImageDraw.Draw(sheet)
    for k, (t, f) in enumerate(frames):
        x, y = 8 + (k % cols) * (w + 8), 8 + (k // cols) * (h + 26)
        sheet.paste(Image.open(f), (x, y))
        d.text((x + 4, y + h + 6), util.fmt_time(t), fill=(200, 200, 205))
    out = project / "render" / "contact-sheet.jpg"
    sheet.save(out, quality=88)
    return out
