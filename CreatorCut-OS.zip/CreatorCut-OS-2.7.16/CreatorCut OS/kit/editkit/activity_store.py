"""Worker-owned activity. One process can never finish another project's step."""
import contextvars, os, time, uuid, math, functools
from . import util
_current = contextvars.ContextVar('creatorcut_activity', default=None)
_read_snapshot = contextvars.ContextVar('creatorcut_activity_read_snapshot',default=None)

def begin(project, **fields):
    path = util.STUDIO_OUT / 'activities' / (str(os.getpid()) + '-' + uuid.uuid4().hex + '.json')
    _current.set(path)
    util.write_json(path, dict(fields, project=project, pid=os.getpid(), birth=util.process_identity(os.getpid()), running=True, started=time.time(), updated=time.time()))
    return path

def update(**fields):
    path = _current.get()
    if path is None:
        # An unbound helper may run in a server thread: never borrow another worker.
        return
    record = util.read_json(path, default={})
    record.update(fields, updated=time.time())
    util.write_json(path, record)

def detail(text='', percent=None):
    path = _current.get()
    if path is None: return
    record = util.read_json(path, default={})
    if text:
        if percent is None and text[:120] != record.get('detail'):
            record['percent'] = None  # A new unmeasured stage must not inherit a stale 100%.
        record['detail'] = text[:120]
        log = record.get('log', [])
        if not log or log[-1] != record['detail']: log.append(record['detail'])
        record['log'] = log[-12:]
    if percent is not None: record['percent'] = round(max(0., min(100.,percent)),1)
    update(**record)

def records():
    cached=_read_snapshot.get()
    if cached is not None:return [dict(row) for row in cached]
    result = []
    identities={}
    for path in (util.STUDIO_OUT / 'activities').glob('*.json'):
        try: a = util.read_json(path, default={})
        except (OSError, util.Fail): continue
        if not isinstance(a, dict): continue
        try:
            a['updated'] = float(a.get('updated') or 0)
            if not math.isfinite(a['updated']): continue
        except (ValueError, TypeError): continue
        if a.get('running'):
            try:
                pid = int(a.get('pid') or 0)
                if pid <= 0: raise ValueError()
                if not util.process_alive(pid):raise ProcessLookupError()
                if a.get('birth'):
                    if pid not in identities:identities[pid]=util.process_identity(pid)
                    if identities[pid] and identities[pid]!=a['birth']:
                        a.update(running=False,interrupted=True,pid_reused=True)
            except (ProcessLookupError, ValueError, TypeError):
                a.update(running=False, interrupted=True)
            except PermissionError: pass
        result.append(a)
    return result

def latest(project=None):
    rows = [a for a in records() if project is None or a.get('project') == project]
    return max(rows, key=lambda a:(bool(a.get('running')), a.get('updated',0)), default={})


def consistent_snapshot(fn):
    """Read worker files once per HTTP snapshot, not once per displayed project."""
    @functools.wraps(fn)
    def wrapped(*args,**kwargs):
        if _read_snapshot.get() is not None:return fn(*args,**kwargs)
        token=_read_snapshot.set(records())
        try:return fn(*args,**kwargs)
        finally:_read_snapshot.reset(token)
    return wrapped
