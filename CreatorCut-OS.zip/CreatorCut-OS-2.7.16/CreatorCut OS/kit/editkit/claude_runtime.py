"""Claude-native runtime. No other provider, credential copying or global configuration writes."""
from pathlib import Path
import json,os,subprocess,sys,threading,time
from . import util
VERSION='0.2.174'
def directory():return util.KIT/'claude-runtime'
def binary():
    bundled=directory()/'claude_agent_sdk/_bundled'/('claude.exe' if os.name=='nt' else 'claude')
    return str(bundled.resolve()) if bundled.is_file() and os.access(bundled,os.X_OK) else None
def ready():return bool(binary() and (directory()/'claude_agent_sdk/__init__.py').is_file() and (directory()/('claude_agent_sdk-'+VERSION+'.dist-info/METADATA')).is_file())
def account():
    cli=binary()
    if not cli:raise util.Fail('Finish installing the Claude editing engine, then continue setup.')
    proc=util.spawn([cli,'auth','status'],cwd=util.ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    try:
        out,_=proc.communicate(timeout=20)
        try:data=json.loads(out)
        except (ValueError,TypeError):data={}
        connected=proc.returncode==0 and data.get('loggedIn') is True
        # No emails, tokens, raw auth output or credential files in app metadata.
        return {'state':'connected' if connected else 'disconnected','provider':'claude','updated':time.time()}
    except subprocess.TimeoutExpired:raise util.Fail('Claude did not finish its connection check. Try connecting again.')
    finally:util.stop_process(proc)
def verify():
    from . import editor
    result=account();util.write_json(editor.root()/'account.json',result)
    if result['state']!='connected':raise util.Fail('Sign in to Claude to finish setup. Your files are saved.')
    return result

def connect():
    """An explicit Sign in button uses Claude's ordinary, user-completed login."""
    from . import editor
    if not ready():raise util.Fail('Finish installing the Claude editing engine first.')
    with editor.CONNECT_LOCK:
        state=editor.safe_json(editor.root()/'account.json')
        if state.get('state')=='connecting' and time.time()-state.get('updated',0)<600:return state
        status=account()
        if status['state']=='connected':
            util.write_json(editor.root()/'account.json',status);return status
        state={'state':'connecting','provider':'claude','updated':time.time()}
        util.write_json(editor.root()/'account.json',state)
    def login():
        proc=None
        try:
            # Official CLI owns browser-based sign-in and normal credential storage.
            proc=util.spawn([binary(),'auth','login','--claudeai'],cwd=util.ROOT,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            proc.wait(timeout=600);verify()
            for pid in editor.all_projects():
                try:
                    job=editor.read(pid)
                    if job.get('provider')=='claude' and job.get('state')=='needs_setup':editor.retry(pid)
                except (util.Fail,OSError):continue
            editor.wake_worker()
        except Exception:
            util.write_json(editor.root()/'account.json',{'state':'disconnected','provider':'claude','updated':time.time(),'message':'Sign-in did not finish. Choose Sign in to Claude to continue.'})
        finally:
            if proc:util.stop_process(proc)
    try:threading.Thread(target=login,daemon=True,name='claude-sign-in').start()
    except Exception:
        util.write_json(editor.root()/'account.json',{'state':'disconnected','provider':'claude','updated':time.time()})
        raise util.Fail('Sign-in could not start. Choose Sign in to Claude to try again.')
    return state
