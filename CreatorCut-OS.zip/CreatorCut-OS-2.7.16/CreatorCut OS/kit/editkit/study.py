"""Study a reference completely: map -> fonts -> style kit. Runs after the quick measurements in teach.py.

Writes into the reference's folder:
  map/refmap.json      every on-screen word, style, cut, motion; map/annotated/page-NN.jpg (for Claude to read)
  fonts.json           the identified font per text style; fonts/style-N.png comparison sheets (eye check)
  kit.json             the style kit the planner and composer use"""
from __future__ import annotations

from pathlib import Path

from . import fontmatch, refmap, stylekit, util


from .resources import serialized

@serialized
def run(src: Path, ref_dir: Path, words: list[dict] | None, progress=None) -> dict:
    say = progress or (lambda *_: None)
    from . import artifact_cache as cache
    import platform,importlib.metadata
    versions={}
    for package in ('Pillow','numpy','opencv-python','ocrmac','rapidocr-onnxruntime'):
        try:versions[package]=importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:pass
    implementations=sorted(Path(__file__).parent.glob('*.py'))
    font_files=sorted(p for p in util.FONTS_DIR.rglob('*') if p.is_file()) if hasattr(util,'FONTS_DIR') else []
    def study_key():return cache.key('full-reference-study-v1',[src,*font_files],{'words':words or [],'platform':platform.platform(),'packages':versions},implementations)
    expected=study_key();manifest=ref_dir/'study-cache.json'
    if cache.hit(manifest,expected):
        say('Reusing the exact unchanged reference style study',1)
        return util.read_json(ref_dir/'kit.json')
    out = ref_dir / "map"
    rm = refmap.build(src, out, words or [], lambda m, p: say(m, 0.75 * p))
    fonts, sheets = {}, {}
    wanted = [s for s in rm["styles"] if s["count"] >= 3 and s["role"] == "caption"][:4]
    notes = [s for s in rm["styles"] if s["role"] == "static" and s["count"] >= 3][:1]
    for k, st in enumerate(wanted + notes):
        say(f"Finding the exact font ({k + 1} of {len(wanted) + len(notes)})…", 0.75 + 0.2 * k / max(1, len(wanted) + len(notes)))
        sm = fontmatch.samples_for(rm, out / "f10", st["id"])
        if len(sm) < 2:
            continue
        top = fontmatch.match(sm)
        try:                                    # the most-used caption fonts too, on a second sheet for the eye check
            more = fontmatch.lookalikes(sm)
            fontmatch.compare_sheet(sm, more, ref_dir / "fonts" / f"style-{st['id']}-lookalikes.png")
            if more and (not top or more[0]["score"] > top[0]["score"]):
                top = [more[0]] + (top or [])
        except Exception:
            util.log_exception("font look-alikes")
        if top:
            fonts[st["id"]] = top[0]
            sheets[st["id"]] = fontmatch.compare_sheet(sm, top, ref_dir / "fonts" / f"style-{st['id']}.png")
            util.write_json(ref_dir / "fonts" / f"style-{st['id']}.json", top)
    util.write_json(ref_dir / "fonts.json", {str(k): v for k, v in fonts.items()})
    say("Writing the style kit…", 0.97)
    kit = stylekit.build(rm, fonts)
    from . import grade
    kit["colour"] = grade.stats(src)
    kit["font_sheets"] = {str(k): v for k, v in sheets.items()}
    kit["annotated"] = rm.get("sheets", [])
    cache_complete=True
    # the editing beyond text: cards, bursts, cutaways (tracked), then a first blueprint and dense frames of each moment
    try:
        from . import blueprint, reftrack
        say("Following the cards and images…", 0.975)
        ocr = util.read_json(out / "ocr.json", default=[])
        tr = reftrack.track(sorted((out / "f10").glob("*.jpg")), rm.get("cuts", []), ocr, refmap.FPS, refmap.person_mask)
        try:
            from . import cardfind
            say("Measuring where every image sits…", 0.98)
            tr["placed"] = cardfind.find(sorted((out / "f10").glob("*.jpg")), rm.get("cuts", []), refmap.FPS, ocr, src)
        except Exception:
            cache_complete=False
            util.log_exception("card positions")
        util.write_json(ref_dir / "track.json", tr)
        kit["track"] = tr.get("stats", {})
        # cuts: a graphic popping in changes the frame too; only the cuts no graphic explains are cuts
        try:
            from . import planner
            face = planner.face_box(src)
        except Exception:
            face = None
        real = blueprint.real_cuts(rm.get("cuts", []), tr, sorted((out / "f10").glob("*.jpg")), face, refmap.FPS)
        kit["cuts_detected_per_minute"] = kit.get("cuts_per_minute")
        kit["cuts_per_minute"] = round(len(real) / max(float(rm.get("duration") or 1), 1) * 60, 1)
        try:
            kit["zoom_measured"] = blueprint.measure_zoom(sorted((out / "f10").glob("*.jpg")), real, refmap.FPS)
        except Exception:
            kit["zoom_measured"] = {}
        kit.setdefault("captions", {}).update(blueprint.caption_screens(rm))
        kit["blueprint"] = blueprint.auto(kit, tr, rm, words or [])
        warn = []
        fw, fh = (rm.get("frame") or [9, 16])[:2]
        if fw > fh:
            warn.append("the reference is landscape (wide); a vertical reference copies better")
        if float(rm.get("duration") or 0) < 6:
            warn.append("the reference is very short, so there's little editing to copy")
        try:
            from . import planner
            kit["face"] = planner.face_box(src)
            if kit["face"] is None:
                warn.append("no one is talking to camera in the reference; a talking-head reference copies best")
        except Exception:
            pass
        if not [s for s in kit.get("styles", {}).values() if s.get("role") == "caption"]:
            warn.append("the reference has no captions to copy")
        kit["reference_warnings"] = warn
        kit["moments"] = [0.0] + tr.get("moments", [])
        for t in kit["moments"][:10]:
            reftrack.dense_sheet(src, t, ref_dir / "dense" / f"at-{t:05.1f}.jpg")
        kit["dense"] = sorted(util.rel(x) for x in (ref_dir / "dense").glob("*.jpg"))
    except Exception as e:
        cache_complete=False
        util.log_exception("graphics tracking")
        kit.setdefault("blueprint", {})
    util.write_json(ref_dir / "kit.json", kit)
    # the frames are only needed while studying; keep the folder light
    import shutil
    shutil.rmtree(out / "f10", ignore_errors=True)
    shutil.rmtree(out / "motion", ignore_errors=True)
    if study_key()!=expected:raise util.Fail('The reference or font library changed during its study. Retry the scan.')
    outputs=[ref_dir/'kit.json',ref_dir/'fonts.json']
    outputs += [ref_dir/name for name in ('track.json','words.json') if (ref_dir/name).is_file()]
    outputs += [p for folder in ('map','fonts','dense') for p in (ref_dir/folder).rglob('*') if p.is_file() and p.suffix in ('.json','.jpg','.png')]
    if cache_complete:cache.commit(manifest,expected,outputs)
    return kit
