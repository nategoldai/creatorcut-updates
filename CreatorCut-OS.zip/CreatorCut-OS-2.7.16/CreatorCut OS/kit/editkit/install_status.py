"""Read-only installation progress. Runs before third-party tools are installed."""
from __future__ import annotations
import json,re,time,math
from pathlib import Path
ORDER=('python','engine','packages','motion','vision','extras','model','studio')
LABELS={'python':'Preparing your workspace','engine':'Installing video tools','packages':'Building your editing engine','motion':'Adding motion graphics','vision':'Setting up reference scanning','extras':'Adding fonts & sounds','model':'Downloading speech recognition','studio':'Checking your editing tools','connect':'Connecting your editor'}
def assignment(path:Path,name:str):
 try:
  s=path.read_text().strip();prefix='window.'+name+' = '
  if not s.startswith(prefix):return None
  return json.loads(s[len(prefix):].rstrip(';\n'))
 except (OSError,ValueError):return None

def timestamp(value):
 try:
  n=float(value)
  return n if math.isfinite(n) and n>=0 else 0
 except (TypeError,ValueError,OverflowError):return 0

def snapshot(root:Path,now=None):
 now=time.time() if now is None else now;out=root/'kit/studio-out'
 progress=assignment(out/'progress.js','AIE_PROGRESS')
 if not isinstance(progress,dict):progress={}
 state=progress.get('state','none');steps=progress.get('steps') or {}
 if not isinstance(steps,dict):steps={}
 complete=[k for k in ORDER if isinstance(steps.get(k),dict) and steps[k].get('state')=='done']
 count=len(complete);percent=int(count*90/len(ORDER));started=timestamp(progress.get('started',0))
 try:ready=json.loads((out/'setup-ready.json').read_text())
 except (OSError,ValueError):ready={}
 if not isinstance(ready,dict):ready={}
 try:version=(root/'kit/VERSION').read_text().strip()
 except OSError:version=''
 valid=started>0 and timestamp(ready.get('updated',0))>0 and ready.get('state')=='ready' and ready.get('version')==version and timestamp(ready.get('updated',0))>=started and count==len(ORDER) and state=='done'
 if valid:return {'state':'ready','percent':100,'label':'Ready to create','detail':'CreatorCut is installed. Your Studio opens next.','completed':9,'total':9}
 if state=='error' or any(isinstance(s,dict) and s.get('state')=='error' for s in steps.values()):
  return {'state':'paused','percent':percent,'label':'Your progress is saved','detail':'Your setup can continue in the chat.','completed':count,'total':9}
 beat=assignment(out/'beat.js','AIE_BEAT') or progress.get('updated',0)
 if state=='running' and now-timestamp(beat)>45:
  return {'state':'paused','percent':percent,'label':'Your progress is saved','detail':'Setup isn’t reporting activity. Continue in the chat.','completed':count,'total':9}
 if state not in ('running','done'):
  return {'state':'waiting','percent':0,'label':'Getting ready','detail':'Installation begins in the chat.','completed':0,'total':9}
 return {'state':'running','percent':percent,'label':LABELS.get(progress.get('current'),'Connecting your editor' if count==8 else 'Preparing your editor'),'detail':'Everything is being set up for you.','completed':count,'total':9}
