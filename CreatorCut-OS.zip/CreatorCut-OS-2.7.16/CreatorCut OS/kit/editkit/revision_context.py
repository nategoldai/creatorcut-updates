"""Exact saved-version edit scope for planning; never applies feedback automatically."""
from . import util

def write(p):
    request=util.read_json(p/'active-edit-request.json',default={});batch=request.get('batch') or {}
    result={'schema':1,'request_id':request.get('id'),'notes':[],'preserve_unmentioned_work':bool(batch),'automatic_patch':False,'new_review_required':True}
    if batch:
        version=batch.get('version')
        if type(version) is not int or version<1:raise util.Fail('Select an available saved video version for these edits.')
        scenes=util.read_json(p/'versions'/f'v{version}.scenes.json',default={})
        plan=p/'versions'/f'v{version}.plan.json'
        from .artifact_cache import digest
        result.update(version=version,approved_plan_sha256=digest(plan) if plan.is_file() else None)
        for note in batch.get('notes',[]):
            scene=next((s for s in scenes.get('scenes',[]) if s.get('id')==note.get('scene')),None)
            result['notes'].append({k:note.get(k) for k in ('id','text','version','start','end','frame','scene','source_start') }|{'affected_items':scene.get('items',[]) if scene else [],'inspect_broader_context':scene is None})
    util.write_json(p/'revision-context.json',result)
    return result
