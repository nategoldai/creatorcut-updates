"""Conservative project-local artifact reuse. Content hashes, no quality shortcuts."""
import hashlib,json,time
from pathlib import Path
from . import util

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def key(stage,files,settings=None,code=()):
    payload={'stage':stage,'settings':settings or {},'inputs':[(str(Path(f).resolve()),digest(f)) for f in files],
             'implementation':[(str(Path(f).resolve()),digest(f)) for f in code]}
    return hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def hit(manifest,expected):
    try:
        doc=util.read_json(manifest,default={});base=Path(manifest).parent.resolve()
        if doc.get('schema')!=1 or doc.get('key')!=expected or not doc.get('outputs'):return False
        for rel,sha in doc['outputs'].items():
            f=(base/rel).resolve()
            if not f.is_relative_to(base) or not f.is_file() or not f.stat().st_size or digest(f)!=sha:return False
        return True
    except (OSError,ValueError,TypeError,AttributeError,util.Fail):return False

def commit(manifest,expected,outputs):
    manifest=Path(manifest);base=manifest.parent.resolve();rows={}
    for output in outputs:
        f=Path(output).resolve()
        if not f.is_relative_to(base) or not f.is_file() or not f.stat().st_size:raise util.Fail('Cannot cache an incomplete artifact.')
        rows[f.relative_to(base).as_posix()]=digest(f)
    if not rows:raise util.Fail('Cannot cache empty output.')
    try:util.write_json(manifest,{'schema':1,'key':expected,'outputs':rows,'saved':time.time()})
    except OSError:
        util.log_exception('Optional cache record could not be saved')
        return False
    return True

def model_files(model):
    import os
    custom=Path(model).expanduser()
    roots=[custom] if custom.is_dir() else []
    hub=Path(os.environ.get('HF_HUB_CACHE') or Path(os.environ.get('HF_HOME',Path.home()/'.cache/huggingface'))/'hub')
    for repo in hub.glob('models--*faster-whisper-'+str(model).replace('/','--')+'*'):
        ref=repo/'refs/main'
        if ref.is_file():
            revision=ref.read_text().strip()
            if revision and '/' not in revision and '\\' not in revision:roots.append(repo/'snapshots'/revision)
    return sorted({p for root in roots for p in root.rglob('*') if p.is_file() and p.suffix in ('.bin','.json','.txt','.model')})
