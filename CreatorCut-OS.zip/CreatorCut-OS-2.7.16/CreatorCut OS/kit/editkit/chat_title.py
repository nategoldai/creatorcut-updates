"""Record one-time host chat naming; never an unsupported host API substitute."""
import re
from . import util

def decision(host: str, chat_id: str, current_title: str | None, *, dedicated_install: bool = False) -> str:
    data = util.read_json(util.BRAND / 'chat-titles.json', default={})
    if data.get(host + ':' + chat_id, {}).get('status') in {'renamed','custom'}:
        return 'keep'
    if current_title is None: return 'inspect_host_title'
    normalized = re.sub(r'[^a-z0-9]+', ' ', current_title.lower()).strip()
    if normalized == 'creatorcut': return 'already_named'
    # Only a dedicated first installation may override arbitrary initial wording.
    if dedicated_install: return 'rename'
    generic = {'install','setup','set up','install creatorcut','install creatorcut os','setup creatorcut','setup creatorcut os','set up creatorcut','set up creatorcut os','install creatorcut updates','creatorcut installation','install creatorcut from github'}
    return 'rename' if normalized in generic else 'keep_custom'

def record(host: str, chat_id: str, status: str) -> None:
    if not host or not chat_id or status not in {'renamed','custom','unsupported'}:
        raise util.Fail('Use the actual host/chat id and a valid naming result.')
    f = util.BRAND / 'chat-titles.json'
    data = util.read_json(f, default={})
    data[host + ':' + chat_id] = {'status':status}
    util.write_json(f,data)
