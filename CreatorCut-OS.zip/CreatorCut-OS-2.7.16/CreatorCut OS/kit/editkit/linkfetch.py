"""Turn a pasted TikTok / Instagram / YouTube link into a local video for style analysis, with no login.

A chain of free methods; each one runs only if the previous one failed:

  1. yt-dlp, locally (works for all three most of the time)
  2. the platform's public pages:
       Instagram: the page Instagram serves to search-engine crawlers (it embeds the video URLs), then the
                  public embed page
       TikTok:    the free tikwm.com API (no key)
  3. public Cobalt instances (open-source downloader API; self-host one via AIE_COBALT=https://…)
  4. cover image only: the post's public thumbnail (oEmbed / og:image). Enough to learn colours and caption
     style, so the creator still doesn't have to download anything
  5. give up with a friendly message: drop the file instead

Only the public link is ever sent to the services in steps 2–4. Downloads are deleted after analysis."""
from __future__ import annotations

import json
import math
import os
import re
import shutil
import ssl
import urllib.parse
import urllib.request
from pathlib import Path

from . import util

BROWSER_UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) "
              "Chrome/129.0.0.0 Safari/537.36")
CRAWLER_UA = "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)"
PREVIEW_UA = "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)"
COBALT = ["https://co.otomir23.me/", "https://cobaltapi.cjs.nz/"]
MAX_BYTES = 150 * 1024 * 1024


class Fetched:
    def __init__(self, path: Path, method: str, partial: bool = False, title: str = ""):
        self.path, self.method, self.partial, self.title = path, method, partial, title


def platform_of(url: str) -> str:
    host = (urllib.parse.urlparse(url).hostname or "").lower()
    if "instagram" in host:
        return "instagram"
    if "tiktok" in host:
        return "tiktok"
    return "youtube"


# ----------------------------------------------------------------- http ----
def _ctx():
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def _get(url: str, ua: str = BROWSER_UA, referer: str = "", timeout: int = 20, data: bytes | None = None,
         headers: dict | None = None) -> bytes:
    h = {"User-Agent": ua, "Accept-Language": "en-US,en;q=0.9"}
    if referer:
        h["Referer"] = referer
    h.update(headers or {})
    req = urllib.request.Request(url, data=data, headers=h)
    with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
        return r.read(MAX_BYTES + 1)


def _download(url: str, dest: Path, referer: str = "", progress=None) -> Path:
    req = urllib.request.Request(url, headers={"User-Agent": BROWSER_UA, "Referer": referer or url})
    with urllib.request.urlopen(req, timeout=30, context=_ctx()) as r, dest.open("wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        got = 0
        while True:
            chunk = r.read(256 * 1024)
            if not chunk:
                break
            got += len(chunk)
            if got > MAX_BYTES:
                raise util.Fail("That video is too big to analyse.")
            f.write(chunk)
            if progress and total:
                progress(got / total)
    if dest.stat().st_size < (2_000 if dest.suffix == ".jpg" else 20_000):
        raise util.Fail("The download was empty.")
    return dest


def _resolve_short(url: str) -> str:
    """vm.tiktok.com / vt.tiktok.com / youtu.be → the full URL."""
    try:
        req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": BROWSER_UA})
        with urllib.request.urlopen(req, timeout=15, context=_ctx()) as r:
            return r.geturl()
    except Exception:
        return url


# ------------------------------------------------------------- methods ----
def via_ytdlp(url: str, out: Path, progress=None) -> Fetched:
    import yt_dlp  # type: ignore

    class Quiet:
        def debug(self, m): pass
        def info(self, m): pass
        def warning(self, m): pass
        def error(self, m): util.log(f"yt-dlp: {m[:400]}")

    def hook(d):
        if progress and d.get("status") == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            if total:
                progress(d.get("downloaded_bytes", 0) / total)

    ff = util.BIN / ("ffmpeg.exe" if util.os_name() == "windows" else "ffmpeg")
    opts = {"format": "bv*[height>=720][height<=1080]+ba/b[height>=720][height<=1080]/bv*+ba/b",
            "format_sort": ["+res:720", "ext:mp4:m4a"], "outtmpl": str(out / "ref.%(ext)s"),
            "merge_output_format": "mp4", "noplaylist": True, "quiet": True, "no_warnings": True,
            "noprogress": True, "progress_hooks": [hook], "socket_timeout": 20, "retries": 2, "logger": Quiet(), "max_filesize": MAX_BYTES,
            "match_filter": lambda info, *, incomplete=False: "too long" if (info.get("duration") or 0) > 185 else None}
    if ff.exists():
        opts["ffmpeg_location"] = str(ff.parent)
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=True) or {}
    files = [p for p in out.iterdir() if p.suffix.lower() in util.VIDEO_EXT]
    if not files:
        raise util.Fail("yt-dlp found no video")
    return Fetched(files[0], "yt-dlp", title=info.get("title") or "")


def _ig_shortcode(url: str) -> str:
    m = re.search(r"instagram\.com/(?:[^/]+/)?(?:p|reel|reels|tv)/([A-Za-z0-9_-]+)", url)
    if not m:
        raise util.Fail("That isn't a single Instagram post.")
    return m.group(1)


def _first_video_url(html: str) -> str:
    """The first progressive MP4 in "video_versions" (or a video_url field), unescaped."""
    i = html.find('"video_versions"')
    if i >= 0:
        m = re.search(r'"url"\s*:\s*"(https:[^"]+)"', html[i:i + 4000])
        if m:
            return json.loads(f'"{m.group(1)}"')
    m = re.search(r'"video_url"\s*:\s*"(https:[^"]+)"', html) or re.search(r'property="og:video(?::secure_url)?" content="([^"]+)"', html)
    if m:
        v = m.group(1)
        return json.loads(f'"{v}"') if "\\" in v else v.replace("&amp;", "&")
    return ""


def via_instagram_pages(url: str, out: Path, progress=None) -> Fetched:
    code = _ig_shortcode(url)
    attempts = [(f"https://www.instagram.com/reel/{code}/", CRAWLER_UA),
                (f"https://www.instagram.com/p/{code}/embed/captioned/", BROWSER_UA),
                (f"https://www.instagram.com/p/{code}/", PREVIEW_UA)]
    for page, ua in attempts:
        try:
            html = _get(page, ua=ua).decode("utf-8", "replace")
        except Exception as e:
            util.log(f"instagram page {page}: {e}")
            continue
        v = _first_video_url(html)
        if v:
            try:
                return Fetched(_download(v, out / "ref.mp4", "https://www.instagram.com/", progress), "instagram page")
            except Exception as e:
                util.log(f"Instagram media link failed; trying the next public page: {e}")
    raise util.Fail("no video in Instagram's public pages")


def via_tikwm(url: str, out: Path, progress=None) -> Fetched:
    api = "https://www.tikwm.com/api/?" + urllib.parse.urlencode({"url": url, "hd": 1})
    d = json.loads(_get(api, timeout=25).decode("utf-8"))
    if d.get("code") != 0 or not d.get("data"):
        raise util.Fail(f"tikwm: {d.get('msg')}")
    data = d["data"]
    if (data.get("duration") or 0) > 185:
        raise util.Fail("too long")
    v = data.get("play") or data.get("hdplay") or data.get("wmplay")
    if not v:
        raise util.Fail("tikwm: no video (maybe a photo post)")
    if v.startswith("/"):
        v = "https://www.tikwm.com" + v
    return Fetched(_download(v, out / "ref.mp4", "https://www.tikwm.com/", progress), "tikwm",
                   title=data.get("title") or "")


def via_cobalt(url: str, out: Path, progress=None) -> Fetched:
    instances = [x for x in re.split(r"[\s,]+", os.environ.get("AIE_COBALT", "")) if x] + COBALT
    last = ""
    for inst in instances:
        try:
            body = json.dumps({"url": url, "videoQuality": "720", "downloadMode": "auto"}).encode()
            d = json.loads(_get(inst, data=body, timeout=25, headers={"Accept": "application/json",
                                                                       "Content-Type": "application/json"}).decode())
        except Exception as e:
            last = str(e)
            continue
        link = d.get("url")
        if d.get("status") == "picker":
            link = next((p.get("url") for p in d.get("picker", []) if p.get("type") in (None, "video")), None)
        if d.get("status") in ("redirect", "tunnel", "stream", "picker") and link:
            try:
                return Fetched(_download(link, out / "ref.mp4", url, progress), "cobalt")
            except Exception as e:
                last = str(e)
                continue
        last = json.dumps(d.get("error") or d)[:200]
    raise util.Fail(f"cobalt: {last}")


def via_cover(url: str, out: Path, progress=None) -> Fetched:
    """Last resort before asking for the file: the public cover image (colours, caption style, framing)."""
    plat = platform_of(url)
    img, title = "", ""
    if plat == "tiktok":
        d = json.loads(_get("https://www.tiktok.com/oembed?" + urllib.parse.urlencode({"url": url})).decode())
        img, title = d.get("thumbnail_url", ""), d.get("title", "")
    elif plat == "youtube":
        m = re.search(r"(?:v=|shorts/|youtu\.be/|embed/)([A-Za-z0-9_-]{11})", url)
        if m:
            for q in ("maxresdefault", "hqdefault"):
                try:
                    p = _download(f"https://i.ytimg.com/vi/{m.group(1)}/{q}.jpg", out / "cover.jpg")
                    return Fetched(p, "cover", partial=True)
                except Exception:
                    continue
    else:
        html = _get(f"https://www.instagram.com/p/{_ig_shortcode(url)}/", ua=PREVIEW_UA).decode("utf-8", "replace")
        m = re.search(r'property="og:image" content="([^"]+)"', html)
        img = m.group(1).replace("&amp;", "&") if m else ""
    if not img:
        raise util.Fail("no cover image")
    return Fetched(_download(img, out / "cover.jpg", url), "cover", partial=True, title=title)


CHAINS = {
    "instagram": [via_ytdlp, via_instagram_pages, via_cobalt, via_cover],
    "tiktok": [via_ytdlp, via_tikwm, via_cobalt, via_cover],
    "youtube": [via_ytdlp, via_cobalt, via_cover],
}


def fetch(url: str, out: Path, say=None) -> Fetched:
    """Try every method in order. `say(message, fraction)` reports progress."""
    say = say or (lambda *_: None)
    if re.search(r"//(vm|vt)\.tiktok\.com/|//youtu\.be/", url):
        try:url = _resolve_short(url)
        except Exception as e:
            # Downloaders can resolve these themselves. A failed preflight must
            # not prevent the actual fallback chain from running.
            util.log(f"Short-link preflight failed; trying the original link: {e}")
    plat = platform_of(url)
    errors = []
    steps = CHAINS[plat]
    for n, method in enumerate(steps):
        shutil.rmtree(out, ignore_errors=True)
        out.mkdir(parents=True)
        label = "Fetching the video…" if n == 0 else ("Trying another way…" if method is not via_cover else
                                                       "Reading the cover image…")
        say(label, 0.02 + 0.05 * n)
        try:
            res = method(url, out, lambda f, n=n: say(label, 0.05 + 0.25 * f))
            if not res.partial:
                # A service can return HTML or a broken file labelled .mp4.
                # Reject it here so the next download method still gets tried.
                info=util.probe(res.path)
                duration=float(info.get('duration',0))
                if not math.isfinite(duration) or duration<=0 or not info.get('width') or not info.get('height'):
                    raise util.Fail('The downloaded file is not a playable video.')
                if duration>185:raise util.Fail('too long')
            util.log(f"link fetched via {res.method}: {url}")
            return res
        except Exception as e:
            msg = getattr(e, "message", None) or str(e)
            errors.append(f"{method.__name__}: {msg[:300]}")
            if "too long" in msg.lower():
                break
    util.log("link fetch failed: " + url + "\n  " + "\n  ".join(errors))
    shutil.rmtree(out, ignore_errors=True)
    raise util.Fail(friendly(" ".join(errors), plat))


def friendly(err: str, plat: str) -> str:
    low = err.lower()
    if "too long" in low:
        return "That video is longer than 3 minutes. Pick a short one, or drop a clip of it instead."
    if "private" in low:
        return "This video is private. Drop the video file here instead."
    if "not available in your country" in low or "geo" in low:
        return "This video isn't available in your country. Drop the file instead."
    if "photo post" in low or "picker" in low:
        return "That post is photos, not a video. Drop a screenshot of it instead."
    if plat == "instagram":
        return "Instagram blocked this one. Save it on your phone and drop the file here instead."
    return "Couldn't scan this reference video. Please download it and upload it as a video file."
