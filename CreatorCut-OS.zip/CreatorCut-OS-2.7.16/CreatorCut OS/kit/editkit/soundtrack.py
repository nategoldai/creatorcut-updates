"""Explicit, timed soundtrack for the main motion renderer. Voice is unchanged by default."""
from __future__ import annotations
import math
import os
from pathlib import Path
from . import util


def resolve(p: Path, src: str) -> Path:
    from .workflow import local
    return local(p,src)


def validate(p: Path, plan: dict):
    audio=plan.get('audio',{})
    if not isinstance(audio,dict): raise util.Fail('audio must be an object.')
    if audio.get('music') and not isinstance(audio['music'],dict): raise util.Fail('Music must be an object with src, volume and rights.')
    dur=plan.get('duration',0)
    events=audio.get('events',[])
    if not isinstance(events,list) or len(events)>200:
        raise util.Fail('Use a list of at most 200 intentional sound events.')
    scenes={s['id'] for s in util.read_json(p/'scene-plan.json',default={}).get('scenes',[])}
    for e in events:
        if not isinstance(e,dict) or not e.get('reason') or e.get('scene') not in scenes:
            raise util.Fail('Every sound event needs a valid scene and a visible/spoken reason.')
        t=e.get('t')
        if not isinstance(t,(float,int)) or not math.isfinite(t) or not 0<=t<dur:
            raise util.Fail('A sound event falls outside the video.')
    for e in events+([audio['music']] if audio.get('music') else []):
        resolve(p,e.get('src',''))
        v=e.get('volume',.15)
        if not isinstance(v,(float,int)) or not math.isfinite(v) or not 0<=v<=1:
            raise util.Fail('Sound volumes must be finite values between 0 and 1.')
    if audio.get('music') and not audio['music'].get('rights'):
        raise util.Fail('Record the music licence or customer ownership in audio.music.rights.')
    if audio.get('voice_processing'):
        raise util.Fail('Arbitrary voice filter strings are not supported. Preserve voice or prepare an explicitly requested processed source.')


def mix(p: Path, raw: Path, dest: Path, plan: dict):
    validate(p,plan)
    a=plan.get('audio',{})
    dur=float(plan['duration'])
    # Narration comes from the cut, not incidental audio inside B-roll HTML.
    voice=p/'cut.mp4'
    if not voice.exists(): voice=resolve(p,plan['background']['src'])
    info=util.probe(voice)
    cmd=[util.ffmpeg_bin(),'-nostdin','-y','-v','error','-filter_complex_threads','1','-i',str(voice)]
    parts=[]
    if info['has_audio']:
        parts.append('[0:a]aresample=48000,aformat=channel_layouts=stereo,apad,atrim=0:'+str(dur)+'[voice]')
    else:
        parts.append(f'anullsrc=r=48000:cl=stereo,atrim=0:{dur}[voice]')
    mixes=['voice']; idx=1
    bounded_music=p/'render'/'music-bounded.wav'
    if a.get('music'):
        m=a['music']
        bounded_music.parent.mkdir(parents=True,exist_ok=True)
        util.run([util.ffmpeg_bin(),'-nostdin','-y','-v','error','-stream_loop','-1','-i',str(resolve(p,m['src'])),
                  '-vn','-t',str(dur),'-ar','48000','-ac','2','-c:a','pcm_s16le',str(bounded_music)], timeout=max(60,dur*4))
        cmd+=['-i',str(bounded_music)]
        fade=min(.6,dur/4)
        # Duck from the actual cut's word intervals. A bounded time envelope
        # avoids FFmpeg split/sidechain EOF deadlocks on some portable builds.
        words=util.read_json(p/'words.json',default={'words':[]}).get('words',[])
        spans=[]
        for w in words:
            lo,hi=max(0,float(w['start'])-.08),min(dur,float(w['end'])+.18)
            if spans and lo<=spans[-1][1]: spans[-1][1]=max(spans[-1][1],hi)
            else: spans.append([lo,hi])
        active='+'.join(f'min(1,min(max(0,(t-{lo:.3f})/0.08),max(0,({hi:.3f}-t)/0.16)))' for lo,hi in spans) or '0'
        volume=f"if(isnan(t),{m.get('volume',.1)},{m.get('volume',.1)}*(1-0.65*min(1,{active})))"
        parts.append(f"[{idx}:a]aresample=48000,aformat=channel_layouts=stereo,atrim=0:{dur},asetpts=PTS-STARTPTS,volume='{volume}':eval=frame,afade=t=in:d={fade},afade=t=out:st={max(0,dur-fade)}:d={fade}[music]")
        mixes=['voice','music'];idx+=1
    for n,e in enumerate(a.get('events',[])):
        cmd+=['-i',str(resolve(p,e['src']))]
        ms=round(e['t']*1000)
        start=float(e.get('media_start',0));length=e.get('duration')
        if not math.isfinite(start) or start<0 or (length is not None and (not isinstance(length,(int,float)) or not math.isfinite(length) or length<=0)):
            raise util.Fail('Invalid sound cue trim.')
        trim=f'atrim=start={start}'+(f':duration={length}' if length is not None else '')+','
        parts.append(f"[{idx}:a]aresample=48000,aformat=channel_layouts=stereo,{trim}asetpts=PTS-STARTPTS,volume={e.get('volume',.15)},adelay={ms}|{ms}[event{n}]")
        mixes.append(f'event{n}');idx+=1
    if len(mixes)>1:
        parts.append(''.join(f'[{x}]' for x in mixes)+f'amix=inputs={len(mixes)}:duration=first:normalize=0:dropout_transition=0,alimiter=limit=0.95:level=false:latency=true[out]')
    else:
        parts.append('[voice]anull[out]')
    dest.parent.mkdir(parents=True,exist_ok=True)
    tmp=dest.with_name(dest.stem+'.partial.mp4')
    script=p/'render'/'soundtrack.filter';script.parent.mkdir(parents=True,exist_ok=True)
    script.write_text(';\n'.join(parts))
    # Mix finite audio separately before remuxing video.
    mixed=p/'render'/'mixed.wav'
    cmd += [*util.filter_script_args(script),'-map','[out]','-vn','-c:a','pcm_s16le','-t',str(dur),str(mixed)]
    try:
        util.run(cmd,timeout=max(60, min(1800, dur*8)))
        util.run([util.ffmpeg_bin(),'-nostdin','-y','-v','error','-i',str(raw),'-i',str(mixed),
                  '-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k',
                  '-t',str(dur),'-movflags','+faststart',str(tmp)], timeout=max(60,min(1800,dur*8)))
        os.replace(tmp,dest)
    finally:
        tmp.unlink(missing_ok=True)
        mixed.unlink(missing_ok=True)
        bounded_music.unlink(missing_ok=True)
