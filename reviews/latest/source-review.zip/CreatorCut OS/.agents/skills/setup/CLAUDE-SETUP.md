# Claude Code setup

Follow the adjacent setup skill using CREATORCUT_HOST=claude. Keep messages beginner-friendly and do not mention another host in normal setup messages. The visible Claude Code conversation edits; no SDK editor session or extra API key is required for chat mode.

Open the actual installation as the project, verify its private tools, show Studio in the supported preview, and arm studio wait --timeout 100 with this session's actual identity. The project Bash allow rule includes .venv/bin/python edit.py studio wait; use that relative command from the app root. Normal first-use trust and real command/security decisions remain the user's.

The project-only Stop hook can return a queued Studio request through the documented Stop feedback. It never grants permissions and does not modify global settings. If the hook or listener is not available, use the saved paste backup. After a reply or completed edit, listen again while Studio remains open.
