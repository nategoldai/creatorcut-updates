---
name: setup
description: "Install, open or repair CreatorCut for a beginner in their current native AI project."
---
# Install CreatorCut

Work only in this installation. Detect the actual host from its tools; do not ask a beginner to choose or require another host's account. Chat is the default editing mode. This visible conversation is the AI editor; do not start a managed editor or another model.

1. Say: I’ll set up CreatorCut and open it when it’s ready. This may take a few minutes. Keep updates short, factual and about 45–60 seconds apart. No technical inventories unless asked.
2. Name a dedicated installation chat CREATORCUT with a supported native title control, preserving any later manual rename. Never edit private host databases or claim a rename without verification.
3. Read the supplied installer before running it. Mac/Linux: set CREATORCUT_HOST to the actual host and run `bash kit/setup/install.sh --no-shortcut`. Windows: use the supplied PowerShell installer with -NoShortcut. Python 3.9 is sufficient for the download/extraction bootstrap; the installer owns its private Python 3.12. Do not change the user's system Python or global host settings.
4. Show the installation progress card from kit/tools/install_status.py in the supported embedded preview. It reports actual setup milestones. Continue the installer and health checks rather than ending the turn. Preserve an existing installation and its customer files during repairs.
5. Use the installed private interpreter to run `edit.py doctor --json`. Required engine tools must be installed before Make. Studio can show installation/progress while optional assets download; missing tools must have a clear repair action. A failed browser probe is not a permission grant or completed render.
6. Open `edit.py studio open --no-browser` in the supported host preview and verify the actual Studio screen. Register only this project's CreatorCut MCP integration when supported; respect its ordinary first-use trust and permission prompts. Do not change global settings or silently approve access.
7. Before announcing that automatic starts are connected, run a short `edit.py studio wait --timeout 2 --conversation ACTUAL_CONVERSATION_ID` round, or the registered creatorcut_wait_for_action tool. A connection_unavailable result is not a successful connection. The host may require its ordinary first-use approval for a local Studio connection; explain that one decision briefly and respect the answer. Do not change global security settings or promise that approval persists. If access is declined or unavailable, keep Studio usable with its paste backup and say so plainly. If the short round receives a real action, handle that exact action instead of discarding it.
8. Say at most two short ready sentences. Then arm `edit.py studio wait --timeout 100 --conversation ACTUAL_CONVERSATION_ID`, or creatorcut_wait_for_action if registered. Re-arm after empty rounds and after every reply/completed edit while Studio stays open. When the listener returns Make/Update, claim that exact request/delivery and follow the edit skill in THIS conversation.

If the host cannot keep listening, the user can use the Editor's Start in your chat paste card. It contains the same saved request. Never pretend a localhost preview is a message-capable MCP App or that an idle/closed chat has begun editing.

Use only supported embedding: this host's in-app browser/preview tools or a mounted CreatorCut MCP App. Do not automatically open an external browser. If embedding is unavailable, state that limitation and the actual local URL. Claude Code project configuration must point at this installation; never reuse another host's folder, credentials or runtime.

For setup/resume, inspect and repair what is actually missing, preserve videos/presets/memory/settings, and reopen Studio. Do not repeat a full installation unnecessarily. Keep required security decisions explicit. Once ready, listen again rather than launching a hidden AI. See kit/docs/chat-editing.md, kit/docs/setup-notes.txt and the edit skill for exact contracts.
