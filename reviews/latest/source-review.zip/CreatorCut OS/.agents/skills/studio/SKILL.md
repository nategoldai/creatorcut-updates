---
name: studio
description: Open CreatorCut Studio and listen for Make or Update in this conversation.
---
Open the actual supported embedded Studio using the private interpreter and edit.py studio open --no-browser. Chat mode is the default. Do not launch a managed editor or another AI. Arm studio wait --timeout 100 with the actual conversation identity, or creatorcut_wait_for_action when registered. Re-arm after each empty round, reply and completed edit while Studio is open. Native permissions remain visible and explicit. If no listener is available, Studio supplies the same saved request in a paste card. Read kit/docs/chat-editing.md and the edit skill before claiming the exact project/request/delivery. Preserve originals, presets, memory and saved versions.
