/* Conversation transport only. No model, background editor, or local send queue. */
(function () {
  'use strict';
  const A = window.AIE;
  const nonce = new URLSearchParams(location.search).get('cc_embed');
  const pending = new Map();
  const uncertainProjects = new Map(Object.entries(A.ui?.nativeUncertain||{}));
  function persistUncertainty(){if(A.ui){A.ui.nativeUncertain=Object.fromEntries(uncertainProjects);try{if(typeof sessionStorage!=='undefined'){const saved=JSON.parse(sessionStorage.getItem('aie-ui')||'{}');saved.nativeUncertain=A.ui.nativeUncertain;sessionStorage.setItem('aie-ui',JSON.stringify(saved));}}catch(e){}A.saveUI?.();}}
  let next = 0;
  const view='view-'+Math.random().toString(36).slice(2);
  const presence=()=>{if(A.state?.editor?.mode==='chat')A.api?.nativePresence?.(view)?.catch(()=>{});};
  let presenceTimer=null;
  function armPresence(){if(presenceTimer==null){presenceTimer=setInterval(presence,20000);presenceTimer?.unref?.();}presence();}
  armPresence();
  window.addEventListener('pageshow',armPresence);
  if(typeof document!=='undefined'&&typeof document.addEventListener==='function')document.addEventListener('visibilitychange',()=>{if(!document.hidden)armPresence();});
  window.addEventListener('pagehide',()=>{if(presenceTimer!=null)clearInterval(presenceTimer);presenceTimer=null;A.api?.nativePresence?.(view,false)?.catch(()=>{});});


  let hostAvailable = false, receiverAvailable = false;
  const directAvailable=()=>typeof window.openai?.sendFollowUpMessage==='function';
  function directSend(text){return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{const e=new Error('The conversation has not confirmed delivery. Check before retrying.');e.uncertain=true;reject(e);},20000);Promise.resolve().then(()=>window.openai.sendFollowUpMessage({prompt:text})).then(()=>{clearTimeout(timer);resolve({accepted:true});},e=>{clearTimeout(timer);e.uncertain=true;reject(e);});});}
  const bridge = A.nativeChat = { available: directAvailable(), pending: false, error: '', uncertain: uncertainProjects.size>0 };
  function changed() { if (A.render) A.render(); }
  bridge.syncReceiver = state => {
    if(state?.editor?.mode==='chat'&&!bridge.presenceStarted){bridge.presenceStarted=true;A.api?.nativePresence?.(view)?.catch(()=>{});}
    bridge.transport=hostAvailable||directAvailable()?'mcp':'foreground';
    receiverAvailable = !!(state && state.native_receiver && state.native_receiver.available);
    bridge.available = hostAvailable || directAvailable() || receiverAvailable;
    if(typeof document!=='undefined')document.documentElement.dataset.creatorcutTransport=hostAvailable?'mcp-app':directAvailable()?'host-message':receiverAvailable?'foreground':'disconnected';
  };
  function request(type, payload, timeout) {
    return new Promise((resolve, reject) => {
      if (!nonce || window.parent === window) return reject(new Error('This view has no native message connection. Your text is kept.'));
      const id = 'cc-' + (++next);
      const timer = setTimeout(() => {
        pending.delete(id);
        const e = new Error('Delivery was not confirmed. Check the conversation before sending again; your text is kept.');
        e.uncertain = type === 'creatorcut:send'; reject(e);
      }, timeout);
      pending.set(id, { resolve, reject, timer });
      window.parent.postMessage({ type, id, nonce, ...payload }, '*');
    });
  }
  window.addEventListener('message', e => {
    const m = e.data;
    if (e.source !== window.parent || !nonce || !m || m.nonce !== nonce) return;
    if (m.type === 'creatorcut:capability') {
      hostAvailable = m.available === true;
      bridge.available = hostAvailable || directAvailable() || receiverAvailable;
      bridge.error = bridge.available ? '' : 'Message connection unavailable in this preview. Your text is kept.';
      changed(); return;
    }
    if (m.type !== 'creatorcut:result' || !pending.has(m.id)) return;
    const p = pending.get(m.id); clearTimeout(p.timer); pending.delete(m.id);
    if (m.error) { const err = new Error(m.error); err.uncertain = !!m.uncertain; p.reject(err); }
    else p.resolve(m.result || {});
  });
  window.addEventListener('openai:set_globals', () => { bridge.syncReceiver({native_receiver:{available:receiverAvailable}}); changed(); });
  bridge.send = async (project, text, requestId) => {
    if (!bridge.available) throw new Error(bridge.error || 'No native message connection in this preview. Your text is kept.');
    if (bridge.pending) throw new Error('A send is awaiting delivery confirmation.');
    if (uncertainProjects.has(project)) throw new Error('Check the conversation before retrying this unconfirmed request.');
    bridge.pending = true; bridge.error = ''; changed();
    try {
      const result = hostAvailable
        ? await request('creatorcut:send', { project, text, request_id:requestId }, 20000)
        : directAvailable() ? await directSend('[CreatorCut Studio, project '+project+']\n'+text)
        : await A.api.nativeAction(project, text, requestId || 'native-' + crypto.randomUUID());
      if (!result || result.accepted !== true) {
        const e = new Error('The editing connection did not confirm receipt. Your instructions are saved.');
        e.uncertain = !!(result && result.state === 'unconfirmed'); throw e;
      }
      return result;
    } catch (e) {
      if (!hostAvailable && (!e.status || e.status >= 500)) e.uncertain = true;
      if (e.uncertain){uncertainProjects.set(project,true);persistUncertainty();}
      bridge.error = e.message; bridge.uncertain = uncertainProjects.size > 0; throw e;
    } finally { bridge.pending = false; changed(); }
  };
  bridge.confirmStarted = project => {
    // A real, newer workflow claim resolves delivery uncertainty for this
    // project only. Another project's missing receipt must stay protected.
    uncertainProjects.delete(project);persistUncertainty();
    bridge.uncertain = uncertainProjects.size > 0;
    if (!bridge.uncertain) bridge.error = '';
  };
  bridge.confirmRetry = project => {
    if (project) uncertainProjects.delete(project); else uncertainProjects.clear();persistUncertainty();
    bridge.uncertain = uncertainProjects.size > 0; bridge.error = ''; changed();
  };
  if (nonce && window.parent !== window) {
    window.parent.postMessage({ type: 'creatorcut:hello', nonce }, '*');
    // Retry only capability discovery, never a user's message.
    let tries = 0;
    const t = setInterval(() => { if (bridge.available || ++tries > 10) return clearInterval(t); window.parent.postMessage({ type: 'creatorcut:hello', nonce }, '*'); }, 500);
  }
})();
