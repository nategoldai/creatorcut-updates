# CreatorCut: visible-chat editing

Chat is the customer default. Studio saves all choices, references and notes; THIS Claude Code or Codex conversation edits. Managed mode is retained only for explicit development/recovery use, never an automatic fallback.

Open Studio with the normal supported host preview. While Studio is open and no edit is running, arm `edit.py studio wait --timeout 100 --conversation CONVERSATION_ID` or the registered creatorcut_wait_for_action tool. Claude shell rounds are at most 100 seconds; MCP rounds are at most 25 seconds. Re-arm immediately after an empty round, an unrelated reply, a completed edit or a safely failed edit. Keep idle messages to one short Listening for Studio line. A new typed message may wait up to one round. Exit listening when Studio closes or the host/user stops the turn. Account limits still apply; do not promise free or perpetual listening.

The listener returns the immutable request and its delivery token to this conversation. Read the exact request, then `workflow claim PROJECT --request REQUEST --delivery TOKEN --owner CONVERSATION_ID`. Include `CREATORCUT_NATIVE_DELIVERY=TOKEN` on editing commands. A request is Saved before delivery; only a valid claim makes it Editing. One request owns the project; the current delivery generation rejects an old message after a safe resend. An uncertain send is never permission to start another writer.

If no chat is listening, use the Editor's Start in your chat paste card. It copies the SAME saved message and never makes a new request. If clipboard access is blocked, Copy again is the explicit fallback. After 90 seconds without a claim the card appears again. A successful later claim hides it. User-requested resends fence the older delivery token; an already claimed request cannot be replaced blindly.

Run the normal engine, exact choices, reference, memory, review and publication checks. Frame/signal-only review must disclose its limits. Existing files or a textual answer cannot finish a request. Reviewed publication for this exact request updates Studio and matching feedback. Failed or cancelled revisions return unapplied notes to the saved list. Preserve previous versions and originals.

One visible chat normally works on one video at a time. Extra requests remain saved in order and are received on the next listening round. Another conversation cannot become a second listener while the installation is leased. If the user deliberately uses the paste card in a second chat for a separate video, normal per-project ownership and serialized heavy work still apply.

Claude's project-only Stop hook may return documented Stop feedback containing a genuinely pending action; it must not invent actions, approve permissions or keep a closed Studio alive. Its wait is bounded and loop protection remains in force. Codex uses the supported foreground listener or a genuinely advertised native message connection. No global host settings are changed.
