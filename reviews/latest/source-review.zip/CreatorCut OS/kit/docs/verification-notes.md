# CreatorCut 2.7.19 candidate verification — 2026-10-31

The customer path is the current visible native chat, not a hidden provider session. The latest backend run exercised 879 checks: 877 passed in that run and two process-visibility checks passed separately with normal local process access. All 25 interface suites pass, including completed feedback on historical versions.

Actual isolated Claude Code and Codex installations completed setup and produced full-quality talking-head videos with supplied B-roll. Both hosts completed two-note timeline revisions, retained the previous version and returned byte-matching saved-video downloads over HTTP. Both also completed reference-file analysis and a new video using a reviewed saved preset with captions Off and Original colour. Inspection used candidate-bound frame sequences and complete audio-decode signal measurements; it does not claim continuous perceptual video/audio review.

Codex also received Make automatically after six uninterrupted 100-second listening rounds and again after a normal unrelated chat question. The connection-only fixtures were deliberately stopped after successful native claim and workflow initialization. The queue test finished two real videos in order. A real ten-minute no-work interval showed the saved-edit message; the same request and native owner subsequently completed the video. Codex's copied backup message reached the same conversation through its supported chat-message tool, and its successful claim removed the paste card. This does not certify literal keyboard paste or closing/reopening the native chat on both hosts.

One measured idle Claude hour used 36 listening rounds and reported 5,894 output tokens, 11,924 cache-creation input tokens and 9,515,082 cached input tokens. These are observed token counts, not a cash charge or a guarantee about account limits. Close Studio when finished to pause listening. First-use host permissions remain explicit and are never answered automatically.

This is still a candidate. The final native Claude paste/closed-chat interaction and native file-save confirmation remain pending, followed by normal release admission. The Mac was locked during the remaining native controls. No customer release or owner-app upgrade is implied by the automated tests; publication needs the owner's explicit approval.

## Historical verification (older build; not the current execution architecture)

# CreatorCut 2.7.17 verification — 2026-10-27

The last clean 657-test backend regression passes (one platform-specific skip); the subsequent startup migration has six targeted passing checks, and 19 JavaScript/interface suites pass. Tests exercise installation checks, route/draft loading, exact request bindings, concurrent projects, resource serialization, stale/failed connections, cancellation, permission interruption, saved presets and memory, downloads and update preservation. These are automated checks, not a claim that every customer environment has been exercised.

An authenticated official Claude SDK session rendered a synthetic 1.2-second animated composition with audio in its normal sandbox. The same saved session resumed and rendered the requested 0.8-second green revision with changed caption. Both runs completed with zero tool permission prompts after the human explicitly authorized CreatorCut-only local connections. Independent decoding verified duration, 360×640 resolution, 30 fps, H.264/AAC, moving requested colour blocks and audio signal. The first movie's hash remained unchanged. This tests the renderer and saved-session revision, not a full customer Studio creative/publication run.

The setup check now also protects jobs queued before an update. Browser transport heartbeats do not fabricate editing progress. A disconnected permission exchange does not replay an approval or restart a denied operation. Normal host security policies remain in force; arbitrary tools or customer-specific resources can still require genuine consent.

Fresh independent onboarding, Windows, mobile host execution and a new full Studio-to-publication customer edit on both providers have not been certified by this run. Earlier Codex publication evidence is retained below. No universal reliability percentage is claimed. Mac account access is required: launching the entire app inside another host's restrictive command sandbox may prevent credential access; a detached process does not escape that sandbox.

## Earlier release evidence

# CreatorCut 2.7.16 verification

631 backend tests (one platform-specific skip), 15 UI suites and eight publisher/bootstrap tests pass. Nineteen provider tests cover native selection, installation-local configuration, exact permission responses, single-writer turn ownership, normal sandbox settings and SDK cleanup.

A real authenticated official Claude Agent SDK session created a synthetic 1.2-second H.264/AAC edit with the requested yellow overlay, disconnected, resumed its saved session, and created the requested 0.8-second green revision. Both actual movies were independently checked for duration, resolution, pixel colors, video/audio codecs and hashes. The source and first edit remained present. Both render commands used explicit human approval; all other security confirmations remained enabled. This verifies the native SDK editing path, not a full customer Studio creative/publication run.

Fresh independent Claude desktop onboarding, Windows execution, complex reference-led customer edits and a complete Studio-to-publication run on Claude were not exercised in this check. Normal host security confirmations, authentication, storage, network and account limits remain real prerequisites. Commercial account-policy review remains required before claiming broad paid-product readiness. No universal reliability percentage is claimed.

## Earlier release evidence (historical)


# CreatorCut OS 2.5.0 verification

Make and timeline Update were exercised through actual in-app Studio controls using an isolated four-second clip of the creator's own footage. Make published a reviewed yellow LIVE composition; a note at frame 61 of version 1 requested white DONE with unchanged placement, timing and source voice. Update reused the same persistent Codex project session and published version 2. The note became ready only after that publication. Candidate and saved-version hashes matched.

Studio was restarted during the revision. Its persisted request, job identity, start time, provider session and version-bound note survived. The archived-session failure found during this test was fixed using the documented thread/unarchive operation before resume. No native foreground action receiver was used. Real renderer permission requests were shown and answered in Studio; no sandbox or approval policy was disabled.

The regression suite passes 376 tests, covering exact request/reference preservation, pinned effects, preset/memory scopes, publication gates, provider pipe EOF/timeouts, bounded connection recovery, duplicate dispatch, cancelled jobs, corrupt records, PID reuse, session restoration, resource gates and update preservation. Numerical and structural checks are not a visual quality guarantee. Real render review used full-resolution frame sequences and audio signals, without a perceptual listening claim.

The managed engine uses each creator's signed-in Codex account and its limits. It can display in a supported embedded Codex or Claude preview, but it is not a mirror of the host conversation and does not use Claude subscription credentials. The Claude host lifecycle and Windows installation were not independently exercised in this run. No claim is made that hardware, disk, provider, permission or network failures are impossible; concrete failures preserve work, show their actual state and use bounded safe recovery.

The distributable excludes customer videos, account state, jobs, presets, learned memory and installed runtimes. The update destination remains the configured public repository; this ZIP has not been published there automatically.


## 2.5.1 public-use failure audit — 2026-10-21
397 Python regression cases passed in the bundled Python runtime. Scenarios include repeated clicks, independent jobs, queued cancellation, malformed project isolation, protected active requests/media/references, missing/torn job records, concurrent preference writes and backup recovery. Existing process tests exercise heavy-resource waiting and owner death. These tests are scoped evidence, not a guarantee against every hardware, account, network or renderer failure.

A real four-second managed Make used an attached measured yellow-title reference, a previously reviewed white-title preset and explicit creator voice/no-music memory. It rendered and published yellow CHECK at the requested placement and window, overriding the preset. Full-resolution sampled frames and exact title boundary frames were inspected. Source/candidate audio correlation was 0.999694; no perceptual listening was performed. The reference fixture was hand-measured from an existing real render; this does not benchmark automatic Instagram extraction. Earlier actual Make and frame-feedback Update tests remain recorded above. Independent Claude lifecycle and Windows installation remain unverified.


## 2.5.2 measured render progress and library actions
402 Python checks passed with the bundled runtime. Added regressions for unsuppressed renderer telemetry, stale percentage reset, supported explicit session permission and saving presets without mutating active settings. The actual 33-second customer composition reported measured capture progress after removing --quiet and produced a new normalized candidate, then passed the review gate and published v1 (33.233 seconds, 1080×1920, 30 fps). Existing baked-in captions and graphics were retained; reference fonts are a visual approximation. Review used full-resolution frames and signal analysis, without perceptual playback/listening. Timeline animation is an illustrative editing visualization, not an exact live edit decision list; it adds no completion credit. Its five stage variants, waiting state, many-small-frame fallback and preserved measured percentages were checked with a JavaScript rendering harness. My videos' four controls and draft-preset naming dialog were verified in the embedded browser. Download waits for an available video; deletion waits until active editing stops.

Permission prompts are not silently approved or hidden. Session-scoped approval is an explicit customer action and appears only when supported by that request. No universal zero-failure or automatic artistic-quality guarantee is made.


## 2.5.3 feedback and responsive checks
The executable feedback_ui.cjs regression exercises exact note version/time, input clearing, newest-first order, pause-before-send, per-project sending state and single dispatch under repeated clicks. timeline_ui.cjs verifies the five editing visualizations, measured progress, waiting state, many-small-thumbnail fallback and absence of the old movie player while editing. Both pass. The unchanged Python engine retains its 402 passing checks from 2.5.2.

Embedded-browser viewport tests found no horizontal page overflow: feedback at 320px and 375px; library and active Studio at 375px; Home at 375px and 430px; Studio at 768px; library at 1024px. Feedback was tested as an isolated, clearly labelled rendered UI fixture to avoid changing the customer's notes; other screens used the actual local Studio in same-origin test iframes. Native phone-app embedding, remote connections and mobile-host permissions have not been independently tested. A localhost installation is not automatically available on another device.


## 2.5.4 startup and frame badge
405 Python checks passed. The response schema for installed App Server supports acceptForSession without an availableDecisions field; the old feature detector incorrectly required that nonexistent field. Explicit session responses are tested in the actual RPC shape, and missing consent still declines rather than auto-grants. Standard command approvals are eligible; stdin and broader permission requests are not given that session shortcut. The currently running provider is not interrupted to reload source.
The feedback UI regression now calls its binding with null initial state, which previously produced a startup error. Frame label is a dedicated purple span directly after the blue time. Security approvals are not removed or hidden.


## 2.5.5 reliability sweep
408 Python checks passed. New regressions reproduce the old loaded-version and long-render-output gaps before their fixes. The worker-version case uses a real child supervisor and modifies VERSION while it runs; its next heartbeat keeps the originally loaded version. A stale owned supervisor is terminated for recovery even with an update plus queued job. A 300-event tool-output burst counts as real liveness while persisting once, without reporting a numeric percent.
The real four-note revision of video-1020-2215 completed and published version 2. Live UI verified the 33.233-second movie playing, pausing, seeking, matching frame 362 at 12.067 seconds, and all 12 actual timeline thumbnails loaded. Its release review explicitly used frame inspection and audio signal analysis; it did not claim perceptual listening. These checks are not a guarantee against all host, network, account, permission, disk or renderer failures.

Startup UI also renders immediately before the first network response. A delayed-state regression checks that this remains visible and repeated connect does not create duplicate listeners.


## 2.5.6 reference recovery
415 Python checks passed. Controlled downloader tests cover short-link preflight failure, unusable MP4 responses, an expired Instagram CDN URL followed by another public page, all methods failing, and a cover-only result. UI checks verify that errors, cover-only results even with readout rows, and study errors display the upload instruction with the exact project id. These tests do not claim that external Instagram/TikTok services accept every URL. The chain uses the existing free providers; no paid service or new external destination was added.

Partial reference retry clears stale cover/study failure flags and runs once; an already-complete full scan is left intact.


## 2.5.7 navigation and download
417 Python checks passed. The actual Studio/Editor routing functions were exercised for draft reuse, active and finished output, old deep links, empty/missing projects and accepted Make switching routes without duplicate dispatch. Attachment serving preserves bytes and range requests and sanitizes Unicode/header-control filenames. Percentages refer only to the measured current tool step; planning has no invented completion percentage. The API, persistent project id, request integrity, feedback, preset and memory endpoints are unchanged.


## 2.5.8 comprehensive audit
418 Python tests pass. Seven Node UI suites verify action/API wiring, separate Studio/Editor routes and draft reuse, exact-version feedback, download URLs, timeline state, initial loading and reference recovery. The action suite checks 57 declared bindings and 42 API methods; wiring coverage is not manual end-to-end coverage of every button. Additional races replace project state during an accepted request and fail the next refresh; queued state and one dispatch survive. Draft-creation failure stops automatic repeat submissions and offers an explicit retry. Permission expiry remains a real pause and is no longer described as a user decline.

A real click on My videos Download in the Codex embedded browser saved Feedback preview.mp4 (2,190,034 bytes). Its SHA-256 equals the source saved version: 0f94e5fa2bab524fdd0b738f5d817e6a28a0b87d685710a2da0d4f16ab372d50. Header tests verify attachment names, unchanged bytes and normal seek/range playback. The latest saved version is preferred to a stale preview URL.

An isolated three-second synthetic render passed contract validation, graphics checks, full capture/decode, changing visible frames, timed audio event and bounded mixed-audio checks. It was not a customer edit or artistic-quality evaluation. The guide was rendered and all six pages inspected. Account, security approval, disk, hardware and network requirements remain real. The current customer test 5 stopped after an unanswered renderer-permission request expired; it was not claimed as a completed render. Independent Claude/mobile-host/Windows lifecycle and all-user launch readiness remain unverified. No release-feed publication was performed by this audit.


## 2.6.1 renderer permission correction
432 tests pass, including explicit permission scope=session, scope=turn, decline, timeout, renderer cache ownership and a sandbox-preserving preflight command. A real command/exec probe ran under workspaceWrite with networkAccess=false: cache write passed, loopback bind was blocked. The probe intentionally does not grant access or certify a full render. Required customer consent is retained, and session-scoped authorization is not promised across different project sessions or host restrictions. The current customer edit has not been marked complete by this change.


## 2.7.0 quality-preserving reuse
464 Python tests and eight UI suites passed. New regressions cover same-size/same-timestamp source replacement, changed settings/model weights, corrupt/empty outputs, malformed manifests, path traversal, unavailable cache storage, interrupted capture, source/font/runtime changes, separate draft/final renders, exact note/version context and the single percentage display. A sound-only revision calls capture once across two passes while remix and technical check run twice. Changes to caption text trigger a new capture. Publication/review gates were not weakened.

A real isolated 1.2-second synthetic test joined two clips, reused the prepared movie and rebuilt composition assets twice. Prepared/movie assets remained byte-identical and originals unchanged. Observed microtest timings were about 0.204s versus 0.0007s for preparation and 0.066s versus 0.0022s for composition asset setup. These tiny-fixture timings are not a claimed speedup for customer edits.

An isolated three-second H.264/AAC graphics/audio render passed normal contract/check/capture/decode, moving-video, timed-sound, mix-level and review-evidence checks. A subsequent actual audio-only revision retained the exact raw visual SHA and modification time, changed the candidate audio/output hash, reran technical checks and registered a new candidate with new review evidence. Neither synthetic result was published or evaluated for artistic quality. Required host permissions remain real; this optimization does not remove them. Per-scene rendered-video stitching is intentionally deferred because transition and audio boundaries need separate validation.


## 2.7.5 release audit
504 Python tests and 12 interface suites pass. Lost-start regression cases cover two lost dispatch replies, a late confirmed matching job, mismatched request and terminal failure. Four page layouts were checked at 320/390/430px with no horizontal overflow. Reduced-motion users receive a static update highlight. This is responsive browser validation, not an iPhone host lifecycle test. Actual public 2.7.4 download, installation and preservation were verified before this release; 2.7.5 publication verification is recorded outside the customer package. Real permissions, disk space, account/network availability and per-host support remain requirements. No guaranteed zero-failure claim.


## 2.7.6 GitHub publication race
Live post-publication verification reproduced a changing-branch raw download serving 2.7.4 bytes while metadata identified 2.7.5. Integrity checks rejected the mismatch. Both bootstrap and updater now fetch GitHubs immutable blob API with the raw media type; exact size, Git blob identity and every SHA-256 file check remain mandatory. Regression coverage verifies the pinned object URL. 505 Python tests, 12 UI suites and 8 bootstrap checks form this release verification; independent fresh-machine/Claude/iPhone host lifecycles remain unverified.


## 2.7.7 active-editor screen freeze
A real active customer edit exposed synchronous readiness checks acquiring the heavy-render lock inside /api/state. The screen remained at Starting and hid an actual permission request. Readiness refresh now runs in a single background task, serving cached checks immediately. Exact FFmpeg version/filter metadata commands use a bounded lightweight path; encoding still requires the heavy lock. Four regressions cover blocked diagnostics, duplicate refresh suppression, thread-start failure, metadata and encoding separation. 509 Python tests pass. A live active-edit state request improved from a 20-second timeout to 0.022 seconds; its worker/provider processes were preserved, and the actual footage timeline animation and editing activity were observed after recovery. This does not establish universal failure immunity or remove legitimate security permissions.

2.7.8: isolated start/status and immediate preparation UI verified by fault-injection tests. This does not establish universal immunity to operating-system, storage, provider, account or permission failures. No new customer video was needed or rendered for these start-path tests.

2.7.9: 526 backend tests passed, including 10 setup/host-isolation fault-injection checks. macOS live setup gate checked separately. A complete fresh Windows installation and independent Claude installation have not been executed in this release audit. Host chat naming depends on a real supported title tool.

## Startup ownership audit — 26 October 2026

Startup now uses separate kernel guards for launch and server lifetime. Healthy reopens reuse the server without repeating the installation doctor/account checks; a new server still completes those checks before binding. A monotonic 90-second launch budget replaces count-based polling, and every unconfirmed owned child is cleaned up with its process group. Log handles close after spawn. Nine new tests cover eight concurrent open calls, direct server collisions, real timeout cleanup, launcher crashes, failures and successful ownership. The installed copy now carries the same maintained test suite as source.

Verification: 588 backend tests and 15 interface suites passed. Live cold start: 2.297 seconds; eight healthy simultaneous reopens: 0.007 seconds, same server. Prior exact-request V2 render/review/publication still passes, and player/timeline/frame feedback were checked after reconnect. This is local evidence, not a statistical 99% reliability estimate. An independent fresh Claude installation and all future host/security conditions are not verified. No permission bypass or automatic acceptance was introduced. This build remains local and has not been published.

## Deeper recovery audit — 26 October 2026

Reproduced a real shutdown hang: a detached helper retaining stdout/stderr trapped the transport close call. Connections now create owned process groups; close stops only that owned group and leaves reader threads responsible for their own pipes. It does not synchronously close a stream held by another reader. Pending requests fail promptly on close, repeated cleanup cannot signal a recycled process ID, EOF marks the transport closed, and partial thread startup failure reaps its child. Detached helpers outside the owned group are not targeted. No approval policy was changed.

Supervisor records now carry monotonic heartbeat and scheduling-loop progress. A live heartbeat thread cannot mask a frozen scheduler, malformed timestamps cannot crash supervision, and system clock changes cannot invalidate fresh monotonic health. Setup and public status use the same health check. Worker updates consult both durable job copies before replacing an active worker.

Validation: 600 backend tests and 15 interface suites passed, including real inherited pipes, subprocess-group cleanup, constructor failure, EOF, supervisor kill/restart and exact same-request resumption without a duplicate job. Crash/restart fixture tests scheduling only, not rendered video quality. The prior full render/review/publication remains independently checked. Fresh Claude installation and universal zero-failure reliability remain unverified; no statistical 99% or 100% claim is established. Changes remain local.

## 2.7.13 progress interface
One status card replaces duplicate headings, work logs and the sweeping shimmer line. Current tool telemetry takes precedence over weighted milestones; the label distinguishes the measurement basis. Permission pauses show no percentage or active timeline motion. Security confirmation controls remain visible and actionable, with technical details collapsed. No approval policy was weakened. Desktop and phone card layouts checked in a labelled sample preview; source and installed interface regression suites passed.

## Unpublished Python/bootstrap audit — 26 October 2026
The publisher extractor and installation-status tool ran under real system Python 3.9.6. A full published package was verified and extracted with it. Eight publisher tests passed under 3.9.6. The engine uses private managed Python 3.12; both installers now reject an incompatible existing private runtime, including readiness-wait and post-create checks. Runtime doctor checks the supported private version. Bash fixtures exercised no environment, an existing system-3.9-linked environment, and a failed runtime replacement without Homebrew or downloads. Native Windows execution was not repeated.

GUI editor discovery now checks executable private and desktop-app locations when PATH is minimal. A ~/.codex directory is not installation or authentication evidence; actual account/read remains required. 610 backend tests passed. These changes remain local and unpublished.

Backend/product prerequisite: the current engine requires Codex even in Claude; no Claude-native managed editor is implemented. Do not remove prerequisite text or claim Claude-only operation. Official authentication guidance checked at https://learn.chatgpt.com/docs/app-server#auth-endpoints allows local/open-source applications and excludes commercial/hosted services from that authentication route. Commercial distribution/category and the supported authentication route require review before claiming paid-customer readiness. Do not describe this as a validated commercial integration.

A real Claude SDK Read-tool test accessed installed persistent-editor.md and the edit skill from a video subfolder with permissions.blockReadsOutsideWorkingDirectories enabled: two requested file reads, zero permission prompts, 13.37 seconds. The app root was not added. Static directories have file-edit deny rules and sandbox write fences. This test verifies instruction access, not unrestricted command approval or complete customer publication.


### 2.7.18 scoped verification (2026-10-27)
Actual FFmpeg renders cover 10 static colour choices plus a measured reference match, and two caption On/Off outputs with decoded frame differences and real bundled fonts. Original is byte-preserving at colour preparation; technical encoding/HDR conversion remains separate. 75 library entries have integrity and syntax checks, not 75 independently visually approved edits. Tests cover current-reference failure, immutable settings, saved colour recipes/font choices, caption-off stale composite rejection, concurrent folder creation, exact effect slot requirements and update data preservation. No additional account permission was granted. Earlier real Claude sandboxed graphics render/revision verification remains scoped to 2.7.17 runtime, unchanged in this release. Full fresh customer onboarding on every operating system remains unverified.
