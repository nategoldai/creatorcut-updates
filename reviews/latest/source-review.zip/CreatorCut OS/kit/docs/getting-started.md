# Your first CreatorCut video

Open the CreatorCut folder as your AI project. In Claude, click **Trust** once. Ask it to install CreatorCut and wait until the setup checks finish.

Open Studio. Give your video a name, then add raw footage and B-roll. Add a reference if you have an edit you love. Choose a style, captions, effects, colour and music. Add any instructions.

Press **Make my video** and keep your chat open. Claude starts by itself. In Codex, type **go** and press Enter. Studio shows progress only after the chat starts the work.

If your chat asks a question or requests permission, answer it there. If it closes, open the same folder and type **continue**. **Stop edit** stops the work safely; you can press **Make my video** again afterwards.

When the video is ready, play it or choose **Download**. Pause on its timeline to add feedback, then press **Update video**. Your earlier version is kept.

Choose **Save as preset** to keep that style. Tell your chat when a preference should carry into future videos.

Keep your Mac awake and leave several GB free for video files. If something goes wrong, send a screenshot of the chat. This app currently runs on a Mac.
