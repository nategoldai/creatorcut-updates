For chat mode, follow chat-editing.md for listening, delivery, exact claims and the paste backup. Managed-only execution details are in persistent-editor.md.

# Production workflow

In customer chat mode, THIS visible Claude Code or Codex conversation runs CreatorCut's local editing tools. Studio saves the immutable request, references, choices and feedback, then delivers Make/Update through the bounded native listener. No extra AI session, API key or managed supervisor is started. Normal host permissions and account limits remain in force. Dependencies, models and rendering use local disk/CPU.

## Start / resume

Read the exact saved project and request, then claim `workflow claim PROJECT --request REQUEST --delivery TOKEN --owner CONVERSATION_ID`. Carry `CREATORCUT_NATIVE_DELIVERY=TOKEN` on editing commands. Refresh the lease while actually working; keep project-specific files and output paths. One visible chat edits one video at a time; more requests wait in order. Re-arm the bounded listener after an edit or reply while Studio stays open. If the chat is stopped or closed, its saved request remains and the paste backup provides an explicit restart; an animation alone is never evidence of editing. Never start a second writer.

Only an installation deliberately configured with editor_mode=managed uses an app-owned persistent project session and supervisor. Those legacy/development rules are confined to persistent-editor.md and do not override the customer chat path.

## Required artifacts
1. Best-take plan + cut transcript (`plan.json`, `words.json`, `segments.json`). Agent reviews actual cuts.
2. Reference evidence and scene contract (`scene-plan.json`). Brief wins; reference adaptations explained.
3. Exact composition (`edit-plan.json`) with stable item ids and explicit audio events.
4. Candidate (`render/candidate.mp4`), technical decode check, review frames and manifest.
5. Agent-authored review tied to candidate SHA256 and input hashes.
6. Published numbered version; final export copies the same approved candidate.

`workflow init` only creates a scaffold; it does not invent scenes. `design` remains a legacy heuristic helper. A host agent must perform the creative work. The gate validates coverage/bindings/assets but cannot independently prove design fidelity or truthful human/agent observation.

## Commands
Use private Python, then `edit.py workflow {init,status,claim,block,validate,evidence,review,publish} PROJECT`.
Claim: `--owner SESSION --phase planning` (analysing/planning/building/reviewing supported).
Review: `--report PATH`. Publish: `--note TEXT`.
`compose PROJECT --final` makes an internal full-quality candidate. `compose` uses draft quality for experiments. Both require the scene contract. `workflow evidence` regenerates inspection frames. `render PROJECT` copies the reviewed output to finished; it doesn't render an unchecked alternate.

If a requirement is impossible or assets are missing: explain it, record unresolved entries, and block. An unknown logo or web UI is not a reason to make up a fake approximation without disclosure. Budget-limited failures remain candidates, not finished versions.

## Release support
Automated regression and local render tests are shipped in kit/tests. Independent first-run installations on Windows/Linux and creative evaluations across customer footage must be completed before advertising broad production readiness. See kit/docs/verification-notes.md at package root for measured status.

## Default visual direction
Use `kit/docs/signature-style.md` whenever a visual choice is unspecified. CreatorCut Signature is the default: Inter Tight white/yellow type, speech-timed in-place pops, selective readable words behind the speaker, purposeful animated media and gentle subject-safe finishing. Explicit instructions, clear reference observations, selected preset and relevant user memory override only the features they specify; unknown features fall back individually. Observed absence is an explicit choice (e.g. no captions or no motion), not a reason to add effects. Read style-direction.json and translate actual brief/reference/recipe/memory evidence to style-inputs.json before final planning. Defaults are not user preferences and must not be learned as feedback. Never silently restyle existing approved projects.
