"""File-only Studio/chat handoff and recipe commands. No model client or permission relay."""
import contextlib,hashlib,json,os,re,secrets,shutil,signal,subprocess,sys,threading,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];KIT=ROOT/'kit';PROJECTS=KIT/'projects';OUT=KIT/'studio-out';LIB=KIT/'style-library';SCRIPTS=LIB/'scripts'
LABELS={'ingest':'Reading your footage','assemble':'Picking your best takes','words':'Listening to your cut','layout':'Finding your best framing','init':'Preparing your style','build':'Building your video','lint':'Checking your graphics','snapshot':'Checking the look','base':'Saving your first cut','fx-check':'Choosing your effects','fx-new':'Preparing your effect','fx-run':'Adding your effect','fx-add':'Adding your effect','render':'Rendering your video','check':'Checking the result','music':'Adding your music','publish':'Saving your video','frames':'Checking the result','probe':'Checking your video','silence':'Checking your sound','look':'Checking the look'}
WEIGHTS={'ingest':(0,10),'assemble':(10,20),'words':(20,26),'layout':(26,30),'init':(30,35),'build':(35,40),'lint':(40,42),'snapshot':(42,44),'base':(44,55),'fx-check':(55,55),'fx-new':(55,58),'fx-run':(58,74),'fx-add':(74,76),'render':(76,91),'check':(91,94),'music':(94,98),'publish':(98,100)}
PLAIN={'waiting':'Open your CreatorCut chat. In Claude it starts by itself. In Codex, type go and press Enter.','queue':'Next in line','paused':'Paused: open your CreatorCut chat and type continue. Nothing is lost.','needs':'Your chat needs you →','stopped':'Stopped. Your footage and versions are safe.','failed':'This step could not finish. Open your chat and ask it to continue.','space':'Please free some space, then type continue in your CreatorCut chat.','missing':'Please add your footage again, then type continue in your CreatorCut chat.'}
TECH=re.compile(r'\.(?:py|json|mp4)\b|kit/|Traceback|Error:|mean difference|frame f|stderr|ffmpeg|\b(?:slot|token|delivery|workflow|listener|waiter)\b',re.I)
class Needed(Exception):pass
class SpanNeeded(Needed):pass
class Busy(Needed):pass
class EffectSkip(Needed):pass
def read(p,default=None):
 try:return json.loads(Path(p).read_text())
 except (OSError,ValueError):return {} if default is None else default
def write(p,value):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.'+secrets.token_hex(6)+'.partial')
 with tmp.open('w') as f:json.dump(value,f,indent=2);f.flush();os.fsync(f.fileno())
 os.replace(tmp,p)
@contextlib.contextmanager
def lock(p,wait=False):
 import fcntl
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('a+') as f:
  try:fcntl.flock(f,fcntl.LOCK_EX|(0 if wait else fcntl.LOCK_NB))
  except BlockingIOError:raise Busy('This video is being edited in your other chat.')
  try:yield
  finally:fcntl.flock(f,fcntl.LOCK_UN)
def alive(pid):
 from editkit import util
 return util.process_alive(pid)
def project(name):
 if not isinstance(name,str) or not re.fullmatch('[a-zA-Z0-9_-]+',name) or not (PROJECTS/name/'project.json').is_file():raise Needed(PLAIN['missing'])
 p=PROJECTS/name
 if not p.resolve().is_relative_to(PROJECTS.resolve()):raise Needed(PLAIN['missing'])
 return p
def current():
 data=read(OUT/'current-edit.json');return project(data['video']) if data.get('video') else None
def status(p):
 row=read(Path(p)/'status.json')
 if not isinstance(row,dict) or row.get('schema')!=2:return {}
 return row
def put(p,state=None,**changes):
 with lock(Path(p)/'.status-28.guard',True):
  old=status(p);now=time.time();elapsed=float(old.get('elapsed',0))
  if old.get('state')=='working':elapsed+=max(0,min(600,now-float(old.get('elapsed_at',old.get('updated',now)))))
  row=dict(old,schema=2,updated=now,elapsed=elapsed,elapsed_at=now,**changes)
  if state:
   row['state']=state
   if state!='needs_you':row.pop('question',None)
  row['overall_percent']=max(float(old.get('overall_percent',0)),float(changes.get('overall_percent',old.get('overall_percent',0))))
  if row.get('state')!='done':row['overall_percent']=min(99,row['overall_percent'])
  if row.get('state')=='working':row['timer_started']=now-row['elapsed']
  else:row.pop('timer_started',None)
  row['seq']=old.get('seq',0)+1;write(Path(p)/'status.json',row)
 return row
def public(name):
 try:return status(project(name))
 except Needed:return {}
def refresh_clock():
 """Engine-only clock; no chat client, edit scheduling, takeover or rendering."""
 p=current()
 if not p:return False
 s=status(p)
 if s.get('state') in ('done','stopped'):return False
 if s.get('state')=='working' and time.time()-s.get('heartbeat',0)>600 and not alive(s.get('command_pid')):
  put(p,'paused',step_label=PLAIN['paused'],command_pid=None)
 return True
def status_clock():
 from editkit import util
 deadline=time.monotonic()+3
 while True:
  try:
   with lock(OUT/'.status-clock.guard'):
    write(OUT/'status-clock.json',{'pid':os.getpid(),'birth':util.process_identity(os.getpid())})
    try:
     while refresh_clock():time.sleep(2)
    finally:
     file=OUT/'status-clock.json'
     if read(file).get('pid')==os.getpid():write(file,{'pid':None})
    return
  except Busy:
   if time.monotonic()>=deadline:return
   time.sleep(.05)
def start_clock():
 # A bounded engine observer only marks a genuinely abandoned edit paused.
 # Studio stays read-only; the observer cannot start or recover an edit.
 subprocess.Popen([sys.executable,str(ROOT/'edit.py'),'_status-clock'],cwd=ROOT,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
def requests():return sorted((read(f) for f in (OUT/'requests').glob('*.json')),key=lambda r:r.get('created',0))
def waiter_alive():
 r=read(OUT/'waiter.json');return alive(r.get('pid')) and time.time()-r.get('heartbeat',0)<12
def digest_file(file):
 h=hashlib.sha256()
 with Path(file).open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def atomic_copy(source,target):
 target=Path(target);target.parent.mkdir(parents=True,exist_ok=True);temporary=target.with_name(target.name+'.'+secrets.token_hex(5)+'.partial')
 try:
  cloned=False
  if sys.platform=='darwin':
   import ctypes
   fn=ctypes.CDLL('/usr/lib/libSystem.B.dylib',use_errno=True).clonefile
   fn.argtypes=[ctypes.c_char_p,ctypes.c_char_p,ctypes.c_int];fn.restype=ctypes.c_int
   cloned=fn(os.fsencode(source),os.fsencode(temporary),0)==0
  if not cloned:shutil.copyfile(source,temporary)
  with temporary.open('rb') as stream:os.fsync(stream.fileno())
  os.replace(temporary,target)
 finally:temporary.unlink(missing_ok=True)
def source_identity(files):
 result={}
 for value in files.get('raw',[]):
  path=Path(value).resolve()
  if not path.is_relative_to(ROOT.resolve()) or not path.is_file():raise Needed(PLAIN['missing'])
  result[str(path)]=digest_file(path)
 return result
def save_request(name,notes=None,key=None):
 from editkit import videos,editor,util
 editor.retire_managed_workers()
 p=project(name);cfg=videos.load(name)
 from editkit import library
 cfg=dict(cfg,library_choices=library.choices(p,include_disabled=True,current=True))
 for kind in ('look','caption'):
  if isinstance(cfg['library_choices'].get(kind),dict):
   row=library.entry(cfg['library_choices'][kind]['id']);cfg['library_choices'][kind]={'id':row['id'],'version':row['version']}
 cfg['library_choices']['effects']=[{'id':row['id'],'version':row['version']} for row in (library.entry(item['id']) for item in cfg['library_choices'].get('effects',[]))]
 with lock(OUT/'.queue.guard',True):
  if key:
   found=next((r for r in requests() if r.get('key')==key and r.get('video')==name),None)
   if found:return found
  active=status(p)
  if alive(active.get('command_pid')):raise Needed('Your previous edit is stopping. Press Make my video again in a moment.')
  if active.get('state')=='waiting_chat' and active.get('request_id') and not read(OUT/'request-state'/f"{active['request_id']}.json").get('cancelled'):raise Needed(PLAIN['waiting'])
  if active.get('state') in ('working','needs_you') and active.get('request_id'):raise Needed('Finish or stop this edit before starting it again.')
  refs=[]
  from editkit import refs as reference
  for r in reference.for_project(name):
   local=ROOT/r['file'] if r.get('file') else next(iter(reference._ref_dir(r['id']).glob('video.*')),None)
   refs.append({'id':r['id'],'file':str(local) if local and local.is_file() else None,'status':r['status'],'analysis':str(reference._ref_dir(r['id'])/'kit.json'),'frames':str(reference._ref_dir(r['id'])/'map/annotated')})
  media=cfg.get('media',[]);files={kind:[str((ROOT/m['file']).resolve()) for m in media if m.get('kind')==kind and m.get('file')] for kind in ('raw','broll','image','music')}
  files['references']=refs
  selection=cfg.get('music_selection') or {}
  files['auto_music']=[dict(t,file=str((p/t['project_file']).resolve())) for t in selection.get('tracks',[]) if t.get('project_file')]
  files['effect_material']=cfg.get('effect_material',{})
  (p/'cancel.json').unlink(missing_ok=True)
  identity=source_identity(files);previous=read(p/'creator-request.json');reused=[]
  if identity and previous.get('source_identity')==identity:
   required={'ingest':['sources.json','transcript.txt'],'assemble':['assets/aroll.mp4','segments.json'],'words':['words.json'],'layout':['layout.json']}
   for step,paths in required.items():
    if all((p/name).is_file() for name in paths):reused.append(step)
   if bool(previous.get('choices',{}).get('voice_cleanup'))!=bool(cfg.get('voice_cleanup')):reused=[step for step in reused if step=='ingest']
  feedback_context={}
  if notes:
   layers=[];plan=read(p/'plan.json');slots=plan.get('slots',[]) if isinstance(plan,dict) else []
   for slot in slots or []:
    if not isinstance(slot,dict):continue
    effect=str(slot.get('key') or slot.get('slot') or 'effect')
    try:effect_name=library.entry('effect:'+effect)['name']
    except (util.Fail,KeyError,ValueError):effect_name=effect.replace('-',' ').title()
    start=slot.get('from',float(slot.get('frame',0))/30)
    end=slot.get('to',float(start)+float(slot.get('frames',0))/30)
    slot_name=str(slot.get('slot') or slot.get('key') or '');folder=p/'fx'/slot_name if re.fullmatch('[a-zA-Z0-9_-]+',slot_name) else p/'fx'
    layers.append({'effect':effect_name,'from':start,'to':end,'normal_captions_hidden':slot.get('captions')=='hide','effect_folder':str(folder.relative_to(ROOT))})
   feedback_context={'published_version':active.get('version'),'creative_html':str((p/'index.html').relative_to(ROOT)),'visible_effects':layers,'instruction':'Inspect the visible text at each feedback moment. An effect may replace the normal captions. Enlarge or restyle that effect text when it is what the customer sees; do not only change a hidden caption layer. Compare actual before/after frames.'}
  rid=secrets.token_hex(16);row={'id':rid,'key':key,'type':'notes' if notes else 'make','video':name,'title':cfg.get('title') or 'Your video','created':time.time(),'feedback_context':feedback_context,'choices':cfg,'notes':notes or [],'files':files,'source_identity':identity,'reused_steps':reused}
  write(OUT/'requests'/f'{rid}.json',row)
  # Delivery state is separate; the request is immutable.
  write(OUT/'request-state'/f'{rid}.json',{'delivered':False})
  write(p/'status.json',{'schema':2,'state':'waiting_chat','step_label':PLAIN['queue'] if any(status(project(r['video'])).get('state')=='working' for r in requests() if r.get('video')!=name) else PLAIN['waiting'],'overall_percent':0,'started':None,'updated':time.time(),'heartbeat':0,'request_id':rid,'queue_position':sum(not read(OUT/'request-state'/f"{r['id']}.json").get('delivered') for r in requests()),'notices':[],'seq':active.get('seq',0)+1})
  return row

def chat_owner():
 if os.environ.get('CLAUDE_CODE_SESSION_ID'):return os.environ['CLAUDE_CODE_SESSION_ID']
 if os.environ.get('CLAUDECODE') or os.environ.get('CLAUDE_PROJECT_DIR') or os.environ.get('CLAUDE_SESSION_ID'):
  return os.environ.get('CLAUDE_SESSION_ID') or read(OUT/'chat-session.json').get('id','')
 return os.environ.get('CODEX_THREAD_ID') or read(OUT/'chat-session.json').get('id','')
def next_request():
 from editkit import editor
 if os.environ.get('CLAUDE_CODE_SESSION_ID') or os.environ.get('CLAUDECODE'):editor.configure_provider('claude')
 elif os.environ.get('CODEX_THREAD_ID'):editor.configure_provider('codex')
 with lock(OUT/'.queue.guard',True):
  p=current()
  if p:
   s=public(p.name)
   if s.get('state') not in ('done','stopped') and read(OUT/'request-state'/f"{s.get('request_id')}.json").get('delivered'):
    owner=chat_owner()
    if s.get('command_pid') and alive(s['command_pid']):raise Busy('This video is being edited in your other chat.')
    if s.get('owner')!=owner and time.time()-s.get('heartbeat',0)<600:raise Busy('This video is being edited in your other chat.')
    row=read(OUT/'requests'/f"{s['request_id']}.json");put(p,owner=owner,heartbeat=time.time());return describe(row,p,resume=True)
  for row in requests():
   delivered=OUT/'request-state'/f"{row['id']}.json"
   if read(delivered).get('delivered') or read(delivered).get('cancelled'):continue
   p=project(row['video']);write(delivered,{'delivered':True,'at':time.time()});write(OUT/'current-edit.json',{'video':p.name,'request_id':row['id']})
   put(p,'working',step_label='Reading your choices',started=time.time(),heartbeat=time.time(),owner=chat_owner(),queue_position=0,completed=row.get('reused_steps',[]))
   if row.get('notes'):
    with lock(p/'.annotations.guard',True):
     notes=read(p/'annotations.json',{'notes':[]});ids={n['id'] for n in row['notes']}
     for note in notes.get('notes',[]):
      if note.get('id') in ids and note.get('status')=='saved':note.update(status='received',received_at=time.time())
     write(p/'annotations.json',notes)
   return describe(row,p)
 return {'message':'Nothing is waiting.'}
def describe(row,p,resume=False):
 if ROOT.joinpath('edit.py').is_file():start_clock()
 write(p/'creator-request.json',row)
 return {'message':('Continue the saved edit' if resume else 'A new, separate request')+' '+row['id']+' for '+row['title'],'request':row,'recipe':'Follow kit/editor/RECIPE.md from step 1. Use the saved completed steps when continuing.','project':str(p),'completed':status(p).get('completed',[]),'memory':str(ROOT/'my-brand/editing-memory.md')}
def wait():
 with lock(OUT/'.waiter.guard'):
  while True:
   write(OUT/'waiter.json',{'pid':os.getpid(),'heartbeat':time.time(),'birth':__import__('editkit.util',fromlist=['process_identity']).process_identity(os.getpid())})
   with lock(OUT/'.queue.guard',True):
    for row in requests():
     f=OUT/'request-state'/f"{row['id']}.json";s=read(f)
     if s.get('delivered') or s.get('announced') or s.get('cancelled'):continue
     write(f,dict(s,announced=True))
     print('CREATORCUT: the customer pressed Make for '+json.dumps(row['title'])+' (a new request '+row['id']+'). Run now: .venv/bin/python edit.py next',flush=True);return
   time.sleep(2)
def cancel(name):
 p=project(name)
 with lock(OUT/'.queue.guard',True):
  write(p/'cancel.json',{'cancel':True,'at':time.time()})
  rid=status(p).get('request_id')
  if rid:
   f=OUT/'request-state'/f'{rid}.json';write(f,dict(read(f),cancelled=True))
  return put(p,'stopped',step_label=PLAIN['stopped'])
def ensure(p,starting=False):
 if read(p/'cancel.json').get('cancel'):raise Needed(PLAIN['stopped'])
 threshold=int(os.environ.get('CREATORCUT_TEST_MIN_FREE_BYTES','2000000000')) if starting else 2_000_000_000
 if shutil.disk_usage(p).free<threshold:raise Needed(PLAIN['space'])
def environment(p):
 env=dict(os.environ);env['PYTHONUNBUFFERED']='1';env['CREATORCUT_KIT']=str(KIT);env['CREATORCUT_LIBRARY_STATE']=str(KIT/'library-state');env['CREATORCUT_LIBRARY_RENDER']=str(KIT/'render/node_modules/hyperframes-library');env['PATH']=str(KIT/'bin')+os.pathsep+str(KIT/'bin/node/bin')+os.pathsep+env.get('PATH','');env['TMPDIR']=str(p/'work/tmp');Path(env['TMPDIR']).mkdir(parents=True,exist_ok=True);env['CREATORCUT_SPEECH_MODEL']=str(KIT/'models/small');env['HF_HUB_OFFLINE']='1';env['SFX']='1' if read(p/'creator-request.json').get('choices',{}).get('sfx',True) else '0';env['HF_HOME']=str(KIT/'cache/huggingface');env['HYPERFRAMES_FONT_CACHE_DIR']=str(KIT/'cache/render-fonts');env['HYPERFRAMES_EXTRACT_CACHE_DIR']=str(p/'work/tmp/extract')
 for pattern in ('render/node_modules/.remotion/chrome-headless-shell/*/chrome-headless-shell-*/*','bin/chrome-headless-shell/*/chrome-headless-shell-*/*','bin/chrome-headless-shell-*/*','render/node_modules/.cache/puppeteer/chrome-headless-shell/*/chrome-headless-shell-*/*'):
  browser=next((f for f in KIT.glob(pattern) if f.name in ('chrome-headless-shell','chrome-headless-shell.exe') and f.is_file()),None)
  if browser:env['HYPERFRAMES_BROWSER_PATH']=str(browser);break
 return env
def apply_colour_choice(html,grade):
 """An explicit Studio grade wins over stock photographic treatments.

 Grade actual footage/cut-outs once, not ancestor wrappers or creative layers.
 Stock tint overlays are separately marked so Original really removes them.
 """
 html=re.sub(r'<style\b[^>]*\bid=[\"\']creatorcut-colour[\"\'][^>]*>.*?</style>','',html,flags=re.I|re.S)
 grade=grade or 'none'
 css=('#plate,#cutw{filter:none!important}'
      '#footage video:not(#back *),#slots video.gr,.creatorcut-colour-fill{filter:'+grade+'!important}'
      '[data-creatorcut-look-grade]{display:none!important}')
 return html.replace('</head>','<style id="creatorcut-colour">'+css+'</style></head>')
def inline_local_fonts(index,project):
 """Expose installed font declarations to the renderer's static compiler.

 Browsers read linked CSS, but the pinned compiler otherwise mistakes its fonts
 for missing and tries an online font download. Keep the same local font files.
 """
 if not index.is_file():return
 from urllib.parse import urlsplit,unquote
 html=index.read_text()
 def replace_link(match):
  tag=match.group(0)
  rel=re.search(r"\brel=[\"']([^\"']+)[\"']",tag,re.I);href=re.search(r"\bhref=[\"']([^\"']+)[\"']",tag,re.I)
  if not rel or 'stylesheet' not in rel.group(1).lower().split() or not href:return tag
  url=urlsplit(href.group(1))
  if url.scheme or url.netloc or url.query:return tag
  sheet=(index.parent/unquote(url.path)).resolve()
  if not sheet.is_relative_to(project.resolve()) or not sheet.is_file() or sheet.stat().st_size>500000:return tag
  css=sheet.read_text()
  if '@font-face' not in css:return tag
  def address(m):
   value=m.group(2);parsed=urlsplit(value)
   if parsed.scheme or parsed.netloc or value.startswith('#'):return m.group(0)
   file=(sheet.parent/unquote(parsed.path)).resolve()
   if not file.is_relative_to(project.resolve()) or not file.is_file():return m.group(0)
   return 'url("'+os.path.relpath(file,index.parent.resolve()).replace(os.sep,'/')+'")'
  css=re.sub(r"url\(\s*([\"']?)([^\"')]+)\1\s*\)",address,css)
  return '<style data-creatorcut-local-fonts="true">'+css+'</style>'
 changed=re.sub(r'<link\b[^>]*>',replace_link,html,flags=re.I)
 if changed!=html:index.write_text(changed)

def script(p,name,args):return [sys.executable,str(SCRIPTS/name),str(p),*map(str,args)]
def command_limit(step,p):
 duration=float(read(p/'plan.json').get('duration',0) or 0)
 if step in ('base','render','fx-run','fx-new','layout','init'):return max(1200,min(21600,900+duration*90))
 return max(300,min(3600,180+duration*8))
def stop_child(proc):
 """Only the unreaped direct child/session created by this command."""
 if proc.poll() is not None:return
 if getattr(proc,'_creatorcut_guardian',False):
  try:proc.stdin.write('stop\n');proc.stdin.flush()
  except (OSError,ValueError):pass
  try:proc.wait(timeout=6);return
  except subprocess.TimeoutExpired:pass
 from editkit import stepguard
 stepguard._stop_child(proc,grace=.5)
 try:proc.wait(timeout=5)
 except subprocess.TimeoutExpired:raise Needed(PLAIN['failed'])
def measured_progress(line,argv,p):
 m=re.search(r'(?:"pct"\s*:\s*|"percent"\s*:\s*)([\d.]+)',line)
 if m:return float(m[1])
 m=re.search(r'(?:Streaming|Rendering|Rendered|Capturing|Captured) (?:frame )?(\d+)/(\d+)',line,re.I)
 if m and int(m[2]):return float(m[1])*100/int(m[2])
 m=re.search(r'(\d+) frames done,',line)
 if m:
  total=0;args=list(map(str,argv))
  try:
   if '--from' in args and '--to' in args:total=round((float(args[args.index('--to')+1])-float(args[args.index('--from')+1]))*30)
   elif len(args)>2 and Path(args[1]).name=='fx_run.py':total=int(read(Path(args[2])/'clip.json').get('frames',0))
   else:total=round(float(read(p/'plan.json').get('duration',0))*30)
  except (ValueError,IndexError,TypeError):total=0
  if total:return min(100,int(m[1])*100/total)
 return None
def step_display(p,cmd,step):
 lo,hi=WEIGHTS.get(step,(status(p).get('overall_percent',0),status(p).get('overall_percent',0)));label=LABELS.get(step,'Editing your video')
 if step not in ('fx-new','fx-run','fx-add'):return lo,hi,label
 args=list(map(str,cmd));key=Path(args[3] if step=='fx-add' and len(args)>3 else args[2] if len(args)>2 else '').name
 entries=read(LIB/'catalogue.json',{}).get('entries',[]);entry=next((e for e in entries if e.get('key')==key and e.get('kind')=='effect'),None)
 if not entry:return lo,hi,label
 selected=read(p/'creator-request.json').get('choices',{}).get('library_choices',{}).get('effects',[]);keys=[(v.get('id','') if isinstance(v,dict) else str(v)).split(':')[-1] for v in selected]
 n=max(1,len(keys));i=keys.index(key) if key in keys else 0;base=55+21*i/n
 a,b=(0,3) if step=='fx-new' else (20,21) if step=='fx-add' else (3,20)
 if step=='fx-run':
  op=args[3:] if len(args)>3 else []
  if op[:1]==['onsets.py']:a,b=3,4
  elif op[:1]==['prep.py']:a,b=4,9
  elif op[:1]==['build.py']:a,b=9,11
  elif op[:2]==['hf','lint']:a,b=11,12
  elif op[:2]==['hf','snapshot']:a,b=12,13
  elif op[:2]==['hf','render']:a,b=13,19
  elif op[:1] in (['post.py'],['check.py']):a,b=19,20
 return base+a/n,base+b/n,('Preparing ' if step=='fx-new' else 'Adding ')+entry['name']
def capture_retry_command(cmd,text,attempt):
 """One same-quality retry for a capture failure after rendering really began.
 Host denials, startup crashes and invalid content are never bypassed/retried.
 """
 words=list(map(str,cmd))
 if attempt or 'render' not in words or not any(Path(w).name in ('hf.py','fx_run.py') for w in words):return None
 if 'Unable to capture screenshot' not in text or '[Parallel]' not in text:return None
 if not re.search(r'"framesCompleted"\s*:\s*[1-9]\d*',text):return None
 if re.search(r'operation not permitted|permission denied|thermal_state_observer_mac|requires approval|sandbox access denied',text,re.I):return None
 if '--workers' in words:
  i=words.index('--workers')
  if i+1>=len(words) or words[i+1]=='1':return None
  del words[i:i+2]
 if '--workers=1' in words:return None
 words=[w for w in words if not w.startswith('--workers=')]
 return [*words,'--workers','1']

def run_process(p,cmd,step,_capture_attempt=0):
 ensure(p,starting=True);log=p/'work'/('last-'+step+'.log');log.parent.mkdir(parents=True,exist_ok=True);lo,hi,label=step_display(p,cmd,step)
 read_fd,write_fd=os.pipe();guardian=Path(__file__).resolve().parents[1]/'editkit/stepguard.py'
 try:
  proc=subprocess.Popen([sys.executable,'-S',str(guardian),'--supervise',str(write_fd),str(p/'work/child-cpu.json'),'--exec',*map(str,cmd)],cwd=p,env=environment(p),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True,pass_fds=(write_fd,))
  proc._creatorcut_guardian=True;proc._creatorcut_status_fd=read_fd
 except BaseException:
  os.close(read_fd);raise
 finally:os.close(write_fd)
 started=time.time();last_output=[time.monotonic()];limit=command_limit(step,p);stalled=[False];put(p,'working',step_label=label,overall_percent=lo,heartbeat=time.time(),command_pid=proc.pid,command_started=started,eta=None)
 stop=threading.Event()
 def watch():
  while not stop.wait(2):
   if read(p/'cancel.json').get('cancel'):
    stop_child(proc);return
   if time.time()-started>limit or time.monotonic()-last_output[0]>max(300,min(limit,900)):
    stalled[0]=True;stop_child(proc);return
   put(p,heartbeat=time.time(),command_pid=proc.pid)
 thread=threading.Thread(target=watch,daemon=True);thread.start()
 try:
  with log.open('w') as f:
   for line in proc.stdout:
    last_output[0]=time.monotonic();f.write(line);f.flush()
    percent=measured_progress(line,cmd,p)
    if percent is not None:
     elapsed=time.time()-started;eta=elapsed*(100-percent)/percent if 0<percent<100 else None
     put(p,overall_percent=lo+(hi-lo)*min(100,percent)/100,heartbeat=time.time(),eta=eta)
  code=proc.wait()
 finally:
  stop.set();thread.join(timeout=4)
  stop_child(proc)
  if proc.stdout:proc.stdout.close()
  if proc.stdin:proc.stdin.close()
  os.close(proc._creatorcut_status_fd)
 put(p,command_pid=None)
 ensure(p)
 retry=capture_retry_command(cmd,log.read_text(errors='replace'),_capture_attempt) if code and not stalled[0] else None
 if retry:
  atomic_copy(log,log.with_name(log.stem+'.parallel-attempt.log'))
  write(p/'work/capture-retry.json',{'attempts':2,'workers':1,'same_quality':True,'reason':'Parallel frame capture failed after rendering began.'})
  return run_process(p,retry,step,_capture_attempt=1)
 if code or stalled[0]:raise Needed(PLAIN['failed'])
 done=status(p).get('completed',[])
 put(p,overall_percent=hi,heartbeat=time.time(),command_pid=None,eta=None,completed=list(dict.fromkeys(done+[step])))
 return log

def init(p):
 req=read(p/'creator-request.json');cfg=req['choices'];choices=cfg.get('library_choices',{});caption=choices.get('caption',{})
 from editkit import styles
 saved=styles.style_path(cfg.get('style',''))
 preset=read(saved) if saved else {}
 if saved:
  from editkit import presets
  preset=dict(preset,design=presets.recipe_context(cfg.get('style',''),cfg.get('preset_version')))
 write(p/'preset-inputs.json',preset)
 available=[]
 for ref in req.get('files',{}).get('references',[]):
  measured=read(ref.get('analysis',''))
  if measured:available.append(dict(ref,measurements=measured))
 write(p/'reference-inputs.json',available)
 reference_notice='Your reference was not ready, so I used your selected style.'
 notices=[n for n in status(p).get('notices',[]) if n!=reference_notice]
 if req.get('files',{}).get('references') and not available:
  notices.append(reference_notice);print(reference_notice)
 if notices!=status(p).get('notices',[]):put(p,notices=notices)
 from editkit import library
 default_caption=library.entry(choices['look']['id']).get('captionStyle','signature') if choices.get('look') else 'signature'
 picks={'mode':'preset' if choices.get('look') else 'custom','style':(choices.get('look') or {}).get('id','').split(':')[-1] or None,'captionStyle':caption.get('id','caption:'+default_caption).split(':')[-1] if isinstance(caption,dict) else 'none' if caption=='none' else 'signature','effects':[r['id'].split(':')[-1] if isinstance(r,dict) else r.split(':')[-1] for r in choices.get('effects',[])]}
 if cfg.get('captions_on') is False or cfg.get('captions',{}).get('enabled') is False:picks['captionStyle']='none'
 write(p/'studio-picks.json',picks)
 if picks.get('style') in ('chalk-talk','show-and-tell') and not (p/'assets/subject.webm').is_file():run_process(p,script(p,'rvm_cut.py',[]),'layout')
 run_process(p,script(p,'init_project.py',[]),'init');plan=read(p/'plan.json');plan['picks']=picks
 from editkit import colour_choice
 grade=colour_choice.choice(cfg);plan['grade']={'natural':None,'bw':'grayscale(1)','warm':'sepia(.12) saturate(1.08) brightness(1.02)','cinematic':'contrast(1.08) saturate(.86)','moody':'brightness(.90) contrast(1.08) saturate(.88)','bright':'brightness(1.06) contrast(.96) saturate(1.06)','punchy':'contrast(1.12) saturate(1.12)','soft':'contrast(.92) brightness(1.04)','luxe':'contrast(1.04) saturate(.92)','film':'sepia(.08) contrast(.96) saturate(.94)'}.get(grade,plan.get('grade'))
 if grade=='reference':
  target=next((r['measurements'].get('colour') for r in reversed(available) if r['measurements'].get('colour')),None)
  if target:
   from editkit import grade as measured_grade
   ours=measured_grade.stats(p/'assets/aroll.mp4',n=6)
   if ours:
    clamp=lambda v,a,b:max(a,min(b,v))
    brightness=clamp(target['lum']/max(.02,ours['lum']),.85,1.15)
    contrast=clamp(target['contrast']/max(.02,ours['contrast']),.88,1.22)
    saturation=clamp(target['sat']/max(.02,ours['sat']),.75,1.3)
    warmth=clamp((target['warm']-ours['warm'])*.8,0,.18)
    plan['grade']=f'brightness({brightness:.4f}) contrast({contrast:.4f}) saturate({saturation:.4f}) sepia({warmth:.4f})'
    write(p/'reference-colour.json',{'reference':target,'source':ours,'css':plan['grade']})
  else:
   notes=status(p).get('notices',[]);put(p,notices=list(dict.fromkeys(notes+['Your reference was not ready, so I used your selected style.'])))
 write(p/'plan.json',plan)
def fx_new(p,args):
 if len(args)<3:raise Needed('Choose the effect and a moment for it in your chat.')
 key=args[0].split(':')[-1];a,b=float(args[1]),float(args[2]);n=round((b-a)*30);segments=read(p/'segments.json',[]);segments=segments.get('segments',[]) if isinstance(segments,dict) else segments
 cuts=[int(r.get('frame',round(r.get('start',0)*30))) for r in segments];total=round(float(read(p/'plan.json').get('duration',0))*30)
 keyfile=LIB/'effects'/key/'build.py';code=keyfile.read_text() if keyfile.exists() else ''
 minimum=109 if key=='spotlight' else 72 if key=='frame-break' else 30
 for m in re.finditer(r'assert\s+(?:N|n|FRAMES|frames)\s*>\s*(\d+)',code):minimum=max(minimum,int(m[1])+1)
 overlap=any(float(s.get('from',s.get('t0',s.get('start',0))))<b and a<float(s.get('to',s.get('t1',s.get('end',0)))) for s in read(p/'plan.json').get('slots',[]))
 if n<minimum or any(round(a*30)<c<round(b*30) for c in cuts) or overlap:
  boundaries=sorted(set([0,*cuts,*[int(r.get('frame',0))+int(r.get('frames',0)) for r in segments]]))
  options=[(x/30,(x+minimum)/30) for x,y in zip(boundaries,boundaries[1:]) if y-x>=minimum]
  reason='That moment is too short.' if n<minimum else 'That moment overlaps another effect.' if overlap else 'That moment crosses a cut.'
  suggestion=min(options,key=lambda pair:abs(pair[0]-a)) if options else None
  raise SpanNeeded(reason+(' Try %.2f to %.2f seconds within one shot.'%suggestion if suggestion else ' This cut has no continuous shot long enough; leave this effect out and keep finishing.'))
 args2=[key,'--project',str(p),'--from',str(a),'--to',str(b),'--picks',str(p/'studio-picks.json')]
 material=read(p/'creator-request.json').get('files',{}).get('effect_material',{}).get(key)
 needs={'orbit':'your reel covers','couch-wall':'your reel covers','ui-world':'a screen picture or recording','phone-mockup':'a screen picture or recording','green-screen':'your background video or picture','inside-out':'your B-roll clip'}
 if key in needs and not material:raise EffectSkip('it needs '+needs[key]+' from Studio')
 if material:
  material=Path(material).resolve()
  if not material.is_relative_to(p.resolve()) or not material.is_dir():raise EffectSkip('its extra files need adding again in Studio')
  args2+=['--buyer-files',str(material)]
 slot=p/'fx'/key;fingerprint={'source':digest_file(p/'assets/aroll.mp4'),'from':a,'to':b,'key':key}
 if slot.exists() and read(slot/'creatorcut-source.json')!=fingerprint:
  archive=p/'fx/_retired';archive.mkdir(parents=True,exist_ok=True);slot.rename(archive/(key+'-'+secrets.token_hex(5)))
 result=run_process(p,[sys.executable,str(SCRIPTS/'fx_new.py'),*args2],'fx-new')
 if slot.is_dir():write(slot/'creatorcut-source.json',fingerprint)
 return result
def mix_music(p):
 req=read(p/'creator-request.json');cfg=req['choices'];selection=cfg.get('music_selection') or {};mode=selection.get('mode') or cfg.get('music','none');plan=read(p/'plan.json')
 source=p/'renders/final.mp4';mixed=read(p/'music-mix.json')
 current=digest_file(source) if source.is_file() else None
 if mode=='none':
  if current and current==mixed.get('mixed_sha256'):raise Needed('Rebuild the video in your chat to remove its added music.')
  (p/'music-credit.json').unlink(missing_ok=True);return
 track=p/selection.get('project_file','')
 if mode=='auto':
  music=plan.get('music',{});track=p/music.get('src','');selection=music
  allowed={str((p/t['project_file']).resolve()):t for t in (cfg.get('music_selection') or {}).get('tracks',[])}
  if str(track.resolve()) not in allowed:raise Needed('Please choose one of the prepared music tracks in your chat.')
  selection=dict(allowed[str(track.resolve())],reason=music.get('reason',''),mode='auto')
 if not track.is_file():raise Needed('Please choose a music track in Studio, then continue in your chat.')
 out=p/'renders/music.pending.mp4'
 graph='[1:a]volume=0.14,asplit[music][m];[0:a]asplit[voice][key];[music][key]sidechaincompress=threshold=0.025:ratio=9:attack=12:release=380[duck];[voice][duck]amix=inputs=2:duration=first:normalize=0[a]'
 # One ducked track, no unused graph outputs.
 volume=max(0,min(1,float(cfg.get('music_volume',.16))))
 signature=hashlib.sha256(json.dumps({'track':digest_file(track),'volume':volume},sort_keys=True).encode()).hexdigest()
 if current and current==mixed.get('mixed_sha256'):
  if signature==mixed.get('signature'):return
  raise Needed('Rebuild the video in your chat before changing its music.')
 graph=f'[1:a]volume={volume}[music];[0:a]asplit[voice][key];[music][key]sidechaincompress=threshold=0.025:ratio=9:attack=12:release=380[duck];[voice][duck]amix=inputs=2:duration=first:normalize=0[a]'
 run_process(p,[str(KIT/'bin/ffmpeg'),'-v','error','-y','-i',str(source),'-stream_loop','-1','-i',str(track),'-filter_complex',graph,'-map','0:v:0','-map','[a]','-c:v','copy','-c:a','aac','-shortest',str(out)],'music');out.replace(source);write(p/'music-credit.json',selection);write(p/'music-mix.json',{'signature':signature,'mixed_sha256':digest_file(source)})
 records=status(p).get('rendered_artifacts',{});saved=records.get('renders/final.mp4',{})
 if saved.get('request_id')==status(p).get('request_id'):
  saved['sha256']=digest_file(source);records['renders/final.mp4']=saved;put(p,rendered_artifacts=records)

def saved_versions(p):
 index=p/'versions/versions.json'
 try:
  doc=json.loads(index.read_text())
  if isinstance(doc.get('versions'),list) and all(isinstance(v,dict) and isinstance(v.get('n'),int) for v in doc['versions']):return doc['versions']
 except (OSError,ValueError,AttributeError):pass
 rows=[]
 for file in sorted((p/'versions').glob('v*.mp4')):
  m=re.fullmatch(r'v(\d+)\.mp4',file.name)
  if not m:continue
  n=int(m[1]);entry=read(p/'versions'/f'v{n}.entry.json');digest=digest_file(file)
  if entry.get('n')==n and entry.get('candidate_sha256')==digest and entry.get('file')==str(file.relative_to(ROOT)):
   rows.append(entry);continue
  try:
   info=json.loads(subprocess.check_output([str(KIT/'bin/ffprobe'),'-v','error','-show_format','-of','json',str(file)],timeout=15))
   duration=float(info['format']['duration'])
   if duration>0:rows.append({'n':n,'file':str(file.relative_to(ROOT)),'duration':duration,'candidate_sha256':digest,'created':file.stat().st_mtime,'note':'Saved video'})
  except (OSError,ValueError,KeyError,subprocess.SubprocessError):continue
 if index.exists() and not rows:raise Needed('Your saved video list needs repair. Open your CreatorCut chat and ask it to restore your saved versions.')
 return sorted(rows,key=lambda row:row['n'])
def clear_render_temporary(p):
 """Finished decoder frames only; retain sources, mattes, plans and every saved version."""
 temporary=p/'work/tmp'
 if temporary.is_symlink() or not temporary.resolve().is_relative_to(p.resolve()):return
 try:
  if temporary.is_dir():shutil.rmtree(temporary)
 except OSError:pass # Cleanup never turns a published movie into a failed edit.
def snapshot_design(p,folder):
 """Keep the actual editable design with a version; never copy example media.

 Creative HTML can differ from plan.json. Retaining only the plan loses those
 changes when the creator saves that version as a preset after another edit.
 """
 folder=Path(folder);files={};allowed={'.html','.css','.js','.py','.json','.svg'}
 candidates=[p/'index.html',*p.glob('*.css'),*p.glob('*.js')]
 for slot in read(p/'plan.json').get('slots',[]):
  key=str(slot.get('slot') or slot.get('key') or '')
  if not re.fullmatch(r'[a-zA-Z0-9_-]+',key):continue
  effect=p/'fx'/key
  if effect.is_dir():candidates.extend(f for f in effect.iterdir() if f.is_file())
 for source in candidates:
  if source.suffix.lower() not in allowed or source.is_symlink() or not source.resolve().is_relative_to(p.resolve()) or not source.is_file():continue
  if source.stat().st_size>2_000_000:continue
  relative=source.relative_to(p);target=folder/relative
  if not target.exists():atomic_copy(source,target)
  files[str(relative)]=digest_file(target)
 write(folder/'design.json',{'schema':1,'files':files,'adaptation':'Read this actual design as evidence. Adapt typography, layout and animation to new speech; never reuse example footage, words or absolute times.'})
 return files

def final_effect_notices(p):
 """A retry is not an omission. Report only unresolved work at publication."""
 st=status(p);notices=list(st.get('notices',[]));slots=read(p/'plan.json').get('slots',[])
 for key,notice in st.get('pending_effect_notices',{}).items():
  if not st.get('failed_effects',{}).get(key):continue
  retained=any(str(slot.get('slot') or slot.get('key') or '').split(':')[-1]==key or Path(str(slot.get('src',''))).stem in (key,'fx-'+key) for slot in slots)
  if retained:notice='I kept the last good '+key.replace('-',' ').title()+': that change could not finish.'
  if notice not in notices:notices.append(notice)
 return notices
def publish(p,args):
 ensure(p);src=p/(args[0] if args else 'renders/final.mp4')
 if not src.resolve().is_relative_to(p.resolve()) or not src.is_file():raise Needed('Finish rendering your video, then save it again.')
 record=status(p).get('rendered_artifacts',{}).get(str(src.relative_to(p)),{})
 if record.get('request_id')!=status(p).get('request_id') or record.get('sha256')!=digest_file(src) or record.get('html_sha256')!=digest_file(p/'index.html'):
  raise Needed('The latest changes still need rendering. Continue in your chat to finish them.')
 probe=json.loads(subprocess.check_output([str(KIT/'bin/ffprobe'),'-v','error','-show_streams','-show_format','-of','json',str(src)]));streams=probe.get('streams',[]);duration=float(probe.get('format',{}).get('duration',0));base=json.loads(subprocess.check_output([str(KIT/'bin/ffprobe'),'-v','error','-show_format','-of','json',str(p/'assets/aroll.mp4')]))
 if duration<=0 or duration+.1<float(base['format']['duration']) or not any(s.get('codec_type')=='audio' for s in streams):raise Needed('The video has not finished rendering yet. Please continue in your chat.')
 subprocess.run([str(KIT/'bin/ffmpeg'),'-nostdin','-v','error','-xerror','-i',str(src),'-map','0:v:0','-map','0:a:0','-f','null','-'],check=True,capture_output=True,timeout=max(60,duration*5))
 with lock(p/'.publish.guard'):
  cfg=read(p/'project.json');index=p/'versions/versions.json';versions=saved_versions(p);digest=digest_file(src);existing=next((v for v in versions if v.get('candidate_sha256')==digest and v.get('request_id')==status(p).get('request_id')),None)
  if not existing:
   n=max([v.get('n',0) for v in versions]+[0])+1;dst=p/'versions'/f'v{n}.mp4';dst.parent.mkdir(exist_ok=True)
   while dst.exists():n+=1;dst=p/'versions'/f'v{n}.mp4'
   existing={'n':n,'file':str(dst.relative_to(ROOT)),'duration':duration,'created':time.time(),'time':time.time(),'note':'Edited in your chat','candidate_sha256':digest,'request_id':status(p).get('request_id')}
   write(p/'versions'/f'v{n}.entry.json',existing)
   atomic_copy(src,dst);finished=ROOT/'my-videos/finished'/f'{p.name}-v{n}.mp4';finished.parent.mkdir(parents=True,exist_ok=True);atomic_copy(src,finished)
   versions.append(existing)
  write(index,{'versions':versions})
  cfg.update(latest=existing['file'],status='finished',version=existing['n']);write(p/'project.json',cfg);atomic_copy(src,p/'preview.mp4')
  for name,suffix in [('words.json','words.json'),('segments.json','segments.json'),('plan.json','plan.json'),('work/build.json','build.json')]:
   if (p/name).exists():shutil.copy2(p/name,p/'versions'/f"v{existing['n']}.{suffix}")
  write(p/'versions'/f"v{existing['n']}.settings.json",read(p/'creator-request.json').get('choices',{}))
  design=p/'versions'/f"v{existing['n']}.design"
  if not (design/'design.json').is_file():snapshot_design(p,design)
  if (p/'music-credit.json').is_file():shutil.copy2(p/'music-credit.json',p/'versions'/f"v{existing['n']}.music-credit.json")
  notes=read(p/'annotations.json',{'notes':[]});ids={n['id'] for n in read(p/'creator-request.json').get('notes',[])}
  for n in notes.get('notes',[]):
   if n.get('id') in ids:n.update(status='ready',applied_version=existing['n'])
  if ids:write(p/'annotations.json',notes)
  counter=read(ROOT/'my-brand/learning-progress.json',{'completed':{}});counter.setdefault('completed',{})[p.name]={'sha256':digest,'time':time.time(),'published':True};write(ROOT/'my-brand/learning-progress.json',counter)
  put(p,'done',overall_percent=100,step_label='Your video is ready',version=existing['n'],command_pid=None,heartbeat=time.time(),notices=final_effect_notices(p))
  clear_render_temporary(p)
 return {'message':'Your video is ready.','version':existing['n']}
def main(argv):
 cmd=argv[0] if argv else 'status';args=argv[1:]
 try:
  if cmd=='_status-clock':status_clock();return 0
  if cmd=='wait':wait();return 0
  if cmd=='next':print(json.dumps(next_request(),indent=2));return 0
  p=current()
  if cmd=='status':print(json.dumps(public(args[0]) if args else status(p) if p else {},indent=2));return 0
  if not p:raise Needed('Choose your video in Studio and press Make my video.')
  st=status(p);owner=chat_owner()
  if st.get('owner') and st['owner']!=owner:raise Busy('This video is being edited in your other chat.')
  if st.get('command_pid') and alive(st['command_pid']):raise Busy('This video is being edited in your other chat.')
  if cmd=='ask':put(p,'needs_you',step_label=PLAIN['needs'],question=' '.join(args) if args and not TECH.search(' '.join(args)) else PLAIN['needs']);print('Please answer the question in your chat.');return 0
  if cmd=='progress':put(p,'working',step_label='Designing your graphics',heartbeat=time.time());print('Designing your graphics.');return 0
  ensure(p)
  with lock(p/'.recipe-command.guard'):
   if cmd=='ingest':run_process(p,script(p,'ingest.py',read(p/'creator-request.json')['files']['raw']),'ingest')
   elif cmd=='assemble':run_process(p,script(p,'assemble.py',[]),'assemble')
   elif cmd=='words':run_process(p,script(p,'transcribe_cut.py',args),'words')
   elif cmd=='layout':run_process(p,script(p,'layout.py',args),'layout')
   elif cmd=='init':init(p)
   elif cmd=='build':
    cfg=read(p/'creator-request.json').get('choices',{});choices=cfg.get('library_choices',{});flags=[]
    if choices.get('look'):flags+=['--style',choices['look']['id'].split(':')[-1]]
    if cfg.get('captions',{}).get('enabled') is False or cfg.get('captions_on') is False or choices.get('caption')=='none':flags+=['--caption','none']
    elif isinstance(choices.get('caption'),dict):flags+=['--caption',choices['caption']['id'].split(':')[-1]]
    if cfg.get('sfx') is False:
     plan=read(p/'plan.json');plan['sounds']=[];write(p/'plan.json',plan)
    run_process(p,script(p,'build_reel.py',['--picks',str(p/'studio-picks.json'),*args,*flags]),'build')
    page=p/'index.html';page.write_text(apply_colour_choice(page.read_text(),read(p/'plan.json').get('grade')))
   elif cmd in ('lint','snapshot','render','base'):
    inline_local_fonts(p/'index.html',p)
    op='render' if cmd in ('base','render') else cmd
    target='renders/base.mp4' if cmd=='base' else 'renders/final.mp4';pending=p/('renders/base.pending.mp4' if cmd=='base' else 'renders/final.pending.mp4')
    if op=='render':pending.unlink(missing_ok=True)
    flags=['-o',str(pending.relative_to(p)),'--quality','high','--sdr',*args] if op=='render' else args
    recovered=False
    try:run_process(p,script(p,'hf.py',[op,*flags]),cmd)
    except Needed:
     trial=status(p).get('effect_trial')
     if cmd!='render' or not trial or read(p/'cancel.json').get('cancel'):raise
     folder=p/'work/effect-trial';good=p/trial['previous_good'];record=status(p).get('rendered_artifacts',{}).get(trial['previous_good'],{})
     if not good.is_file() or record.get('request_id')!=status(p).get('request_id') or record.get('sha256')!=digest_file(good):raise
     atomic_copy(folder/'plan.json',p/'plan.json');atomic_copy(folder/'index.html',p/'index.html');atomic_copy(good,p/'renders/final.mp4')
     notices=status(p).get('notices',[]);notice='I left '+trial['key'].replace('-',' ').title()+' out: its finished effect could not be added cleanly.'
     put(p,'working',step_label='Finishing your video',notices=list(dict.fromkeys(notices+[notice])),effect_trial=None)
     print('SKIP: '+notice);recovered=True
    if op=='render':
     file=p/target
     if not recovered:
      if not pending.is_file():raise Needed('The video has not finished rendering yet. Please continue in your chat.')
      pending.replace(file)
     else:pending.unlink(missing_ok=True)
     if not file.is_file():raise Needed('The video has not finished rendering yet. Please continue in your chat.')
     records=status(p).get('rendered_artifacts',{});records[str(file.relative_to(p))]={'request_id':status(p).get('request_id'),'sha256':digest_file(file),'html_sha256':digest_file(p/'index.html')}
     put(p,rendered_artifacts=records,effect_trial=None)
     clear_render_temporary(p)
   elif cmd=='fx-new':fx_new(p,args)
   elif cmd=='fx-run':
    extra=args[1:]
    if extra[:1]==['hf']:inline_local_fonts(p/'fx'/args[0]/'index.html',p)
    if extra[:2]==['hf','render'] and '--sdr' not in extra:extra=[*extra,'--sdr']
    run_process(p,[sys.executable,str(SCRIPTS/'fx_run.py'),str(p/'fx'/args[0]),*extra],cmd)
    if extra[:2]==['hf','render']:clear_render_temporary(p)
    if extra[:1]==['check.py'] or extra[:2]==['hf','render'] and not (p/'fx'/args[0]/'check.py').is_file():
     failed=status(p).get('failed_effects',{});failed.pop(args[0],None)
     pending=status(p).get('pending_effect_notices',{});pending.pop(args[0],None)
     prefix='I left '+args[0].replace('-',' ').title()+' out:'
     put(p,failed_effects=failed,pending_effect_notices=pending,notices=[n for n in status(p).get('notices',[]) if not n.startswith(prefix)])
   elif cmd=='fx-add':
    if status(p).get('failed_effects',{}).get(args[0]):raise EffectSkip('its finished effect has not passed its check yet')
    folder=p/'work/effect-trial';folder.mkdir(parents=True,exist_ok=True)
    atomic_copy(p/'plan.json',folder/'plan.json');atomic_copy(p/'index.html',folder/'index.html')
    artifacts=status(p).get('rendered_artifacts',{});good='renders/final.mp4' if artifacts.get('renders/final.mp4',{}).get('request_id')==status(p).get('request_id') else 'renders/base.mp4'
    put(p,effect_trial={'key':args[0],'previous_good':good})
    run_process(p,script(p,'fx_add.py',[str(p/'fx'/args[0]),'--picks',str(p/'studio-picks.json'),*args[1:]]),cmd)
    prefix='I left '+args[0].replace('-',' ').title()+' out:';put(p,notices=[n for n in status(p).get('notices',[]) if not n.startswith(prefix)])
   elif cmd=='fx-check':run_process(p,script(p,'footage_check.py',[*args,'--picks',str(p/'studio-picks.json')]),cmd)
   elif cmd=='check':run_process(p,script(p,'frames_check.py',args or ['renders/final.mp4']),cmd)
   elif cmd in ('frames','look'):
    run_process(p,script(p,'frames_check.py',args or ['renders/final.mp4']),cmd)
   elif cmd=='probe':
    file=p/(args[0] if args else 'assets/aroll.mp4');data=json.loads(subprocess.check_output([str(KIT/'bin/ffprobe'),'-v','error','-show_streams','-show_format','-of','json',str(file)]));print(json.dumps(data,indent=2));return 0
   elif cmd=='silence':run_process(p,[str(KIT/'bin/ffmpeg'),'-hide_banner','-i',str(p/'assets/aroll.mp4'),'-af','silencedetect=n=-38dB:d=0.35','-f','null','-'],cmd)
   elif cmd=='music':mix_music(p)
   elif cmd=='publish':print(json.dumps(publish(p,args)));return 0
   else:raise Needed('Open your chat to continue this step.')
  print(LABELS.get(cmd,'Editing your video')+' — done.')
  artifacts={'ingest':['sources.json','transcript.txt','words_c1.json','work/sheets.jpg'],'assemble':['assets/aroll.mp4','segments.json'],'words':['words.json'],'layout':['layout.json','work/layout/check.jpg'],'init':['plan.json','studio-picks.json'],'build':['index.html'],'snapshot':['snapshots/contact-sheet.jpg'],'base':['renders/base.mp4'],'render':['renders/final.mp4'],'check':['work/check/final.jpg']}
  print(json.dumps({'project':str(p),'artifacts':[str(p/f) for f in artifacts.get(cmd,[]) if (p/f).exists()],'details':str(p/'work'/('last-'+cmd+'.log'))}))
  return 0
 except Busy as error:
  print(str(error));return 1
 except SpanNeeded as error:
  print(str(error));return 2
 except (Needed,OSError,ValueError,KeyError,subprocess.SubprocessError) as error:
  try:
   p=current()
   if p and cmd in ('fx-new','fx-run','fx-add','fx-check') and not read(p/'cancel.json').get('cancel') and not (isinstance(error,Needed) and str(error) in (PLAIN['space'],PLAIN['missing'])):
    if cmd=='fx-run' and args:
     failed=status(p).get('failed_effects',{});failed[args[0]]=True;put(p,failed_effects=failed)
    key=args[0] if args else 'effect';title=key.replace('-',' ').title();reason=str(error) if isinstance(error,EffectSkip) else 'this moment could not use that effect'
    notice='I left '+title+' out: '+reason.rstrip('.')+'.'
    if cmd=='fx-run' and not isinstance(error,EffectSkip):
     pending=status(p).get('pending_effect_notices',{});pending[key]=notice
     put(p,'working',step_label='Adjusting '+title,pending_effect_notices=pending,heartbeat=time.time(),command_pid=None)
    else:
     notes=status(p).get('notices',[]);put(p,'working',step_label='Finishing your video',notices=list(dict.fromkeys(notes+[notice])),heartbeat=time.time(),command_pid=None)
    print('SKIP: '+notice);return 0
   if p:
    import errno
    message=str(error) if isinstance(error,Needed) and str(error) in PLAIN.values() else PLAIN['space'] if isinstance(error,OSError) and error.errno==errno.ENOSPC else PLAIN['failed']
    put(p,'needs_you' if not read(p/'cancel.json').get('cancel') else 'stopped',step_label=PLAIN['needs'] if not read(p/'cancel.json').get('cancel') else PLAIN['stopped'],question=message,heartbeat=time.time(),command_pid=None)
  except (OSError,Needed):pass
  import errno
  print(str(error) if isinstance(error,Needed) else PLAIN['space'] if isinstance(error,OSError) and error.errno==errno.ENOSPC else PLAIN['failed']);return 1
