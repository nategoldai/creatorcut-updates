"""Project hooks only. No global settings and no permission answers."""
import hashlib,json,sys,time
from . import director as d

def run(kind,data):
 session=str(data.get('session_id','unknown'));name=hashlib.sha256(session.encode()).hexdigest()[:20]
 if kind=='start':
  from editkit import editor
  editor.configure_provider('claude')
  d.write(d.OUT/'chat-session.json',{'id':session,'at':time.time()})
  return {'hookSpecificOutput':{'hookEventName':'SessionStart','additionalContext':'This is CreatorCut. Read CLAUDE.md. Run .venv/bin/python edit.py next for pending or unfinished work. Start .venv/bin/python edit.py wait using the background Bash option so Make wakes this chat. If setup is unfinished, finish setup first. Do background housekeeping silently. If nothing is waiting, the only customer reply is: Choose your footage in Studio, then press Make my video. Never narrate housekeeping.'}}
 p=d.current()
 if kind=='notification':
  if p and d.status(p).get('owner') in (None,'',session) and d.status(p).get('state') not in ('done','stopped'):d.put(p,'needs_you',step_label=d.PLAIN['needs'])
  return None
 if kind!='stop' or data.get('stop_hook_active'):return None
 file=d.OUT/'hook-stops'/f'{name}.json';previous=d.read(file)
 if previous.get('blocked'):
  d.write(file,{'blocked':False});return None
 reason=None
 if p and d.status(p).get('owner') in (None,'',session) and d.status(p).get('state')=='working':reason='Continue the saved CreatorCut edit from its next unfinished recipe step; publish it or record ask if the customer must answer.'
 elif not d.waiter_alive():reason='Start .venv/bin/python edit.py wait with the Bash background option, then stop. Do this silently; do not narrate housekeeping.'
 if reason:
  d.write(file,{'blocked':True});return {'decision':'block','reason':reason}
 return None
if __name__=='__main__':
 try:data=json.loads(sys.stdin.read(65536) or '{}');result=run(sys.argv[1],data)
 except (ValueError,OSError,d.Needed):result=None
 if result:print(json.dumps(result))
