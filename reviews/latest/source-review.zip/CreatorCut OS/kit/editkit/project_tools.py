"""Project-bound typed metadata tools. No shell, network, security settings or arbitrary paths."""
import json,os,re,hashlib
from pathlib import Path
from . import util

def bound_project():
 if os.environ.get('CREATORCUT_MANAGED_EDITOR')!='1':return None
 expected=os.environ.get('CREATORCUT_INSTALLATION_ROOT')
 if expected and util.ROOT.resolve()!=Path(expected).resolve():
  raise util.Fail('This project tool belongs to a different CreatorCut installation. Reconnect this editor.')
 return os.environ.get('CREATORCUT_PROJECT')

def codex_inherited_servers(command):
 """Read server names only through the CLI; never edit or copy host config/auth."""
 import subprocess
 proc=util.spawn([command,'mcp','list','--json'],cwd=util.ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 try:
  output,_=proc.communicate(timeout=15)
  if proc.returncode or len(output)>4*1024*1024:raise ValueError('Server configuration unavailable')
  rows=json.loads(output)
  if not isinstance(rows,list) or len(rows)>256 or any(not isinstance(row,dict) or not isinstance(row.get('name'),str) or len(row['name'])>200 for row in rows):raise ValueError('Invalid server list')
  result=[]
  for row in rows:
   kind=(row.get('transport') or {}).get('type')
   if kind not in ('stdio','streamable_http'):raise ValueError('Unsupported server transport')
   result.append({'name':row['name'],'transport':kind})
  return result
 except (ValueError,subprocess.TimeoutExpired) as error:
  raise util.Fail('The editor could not verify its own tool connection. Your request is saved; reconnect the editor before starting.') from error
 finally:
  util.stop_process(proc)
  for stream in (proc.stdout,proc.stderr):
   if stream is not None:stream.close()

def codex_server_name():return 'creatorcut_project_'+hashlib.sha256(str(util.ROOT.resolve()).encode()).hexdigest()[:12]

def codex_config(project,inherited=()):
 """One process owns one installation's MCP, without writing user configuration.

 Normal tool/security policies remain in force; no approval settings are added.
 Replacing the process MCP table avoids inheriting an older installation's
 same-named native bridge or unrelated external tool connections.
 """
 import sys
 _project(project)
 quote=lambda value:json.dumps(str(value),ensure_ascii=False)
 env={'CREATORCUT_MANAGED_EDITOR':'1','CREATORCUT_PROJECT':project,'CREATORCUT_INSTALLATION_ROOT':str(util.ROOT.resolve())}
 settings='command='+quote(sys.executable)+',args=['+quote(util.KIT/'tools/native_mcp.py')+'],cwd='+quote(util.ROOT)+',env={'+','.join(key+'='+quote(value) for key,value in env.items())+'}'
 name=codex_server_name()
 disabled=[]
 for row in inherited:
  other=row if isinstance(row,str) else row['name']
  if other==name:continue
  # Overrides replace individual server entries. A disabled entry still needs
  # a valid transport. Use inert local values, never copy credential-bearing
  # URLs, environment variables, headers or launch commands into CLI arguments.
  transport='url="http://127.0.0.1:1/disabled"' if isinstance(row,dict) and row.get('transport')=='streamable_http' else 'command='+quote(sys.executable)+',args=[]'
  disabled.append(quote(other)+'={enabled=false,'+transport+'}')
 disabled=','.join(disabled)
 return 'mcp_servers={'+name+'={'+settings+'}'+(','+disabled if disabled else '')+'}'

def _project(project):
 if not isinstance(project,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,80}',project):raise util.Fail('This editing tool needs its assigned project.')
 path=util.PROJECTS/project
 if path.is_symlink() or path.resolve().parent!=util.PROJECTS.resolve() or not (path/'project.json').is_file():raise util.Fail('The assigned editing project is unavailable.')
 return path

def tools():
 return [
 {'name':'creatorcut_review_check','description':'Return all current review problems for this assigned video. This never approves or publishes a video. Resolve issues, then use the normal full review/publication gates.','inputSchema':{'type':'object','properties':{'report':{'type':'object'}},'required':['report'],'additionalProperties':False}},
 {'name':'creatorcut_project_context','description':'Read the full immutable request, saved plans, creator/preset memory, style direction and revision context for this assigned video only. Use this instead of shell loops to read context. No project or path parameter is accepted.','inputSchema':{'type':'object','properties':{},'additionalProperties':False}},
 {'name':'creatorcut_plan_save','description':'Validate and save both plans for this assigned video as a recoverable transaction. Supply complete JSON objects; no shell commands or file paths. Correct all returned validation issues before rendering.','inputSchema':{'type':'object','properties':{'scene':{'type':'object'},'plan':{'type':'object'}},'required':['scene','plan'],'additionalProperties':False}}
 ]

def call(project,name,args):
 p=_project(project)
 if not isinstance(args,dict):raise util.Fail('Tool arguments must be an object.')
 if name=='creatorcut_project_context':
  if args:raise util.Fail('This tool accepts no extra project or path arguments.')
  from . import requests
  context={name:util.read_json(p/name,default={}) for name in (
   'customer-memory.json','style-direction.json','style-inputs.json',
   'revision-context.json','selected-library.json','request-context.json')}
  request=requests.active(p)
  return {'project':project,'request':request,'required_request_keys':requests.required(request) if request else [],'scene':util.read_json(p/'scene-plan.json',default={}), 'plan':util.read_json(p/'edit-plan.json',default={}), 'context':context}
 if name=='creatorcut_review_check':
  if set(args)!={'report'}:raise util.Fail('Supply only the review report object.')
  from . import workflow
  return workflow.review_dry_run(p,args['report'])
 if name=='creatorcut_plan_save':
  if set(args)!={'scene','plan'} or len(json.dumps(args,allow_nan=False).encode())>8*1024*1024:raise util.Fail('Supply complete scene and plan objects smaller than 8 MB.')
  from . import plan_io
  return plan_io.save(p,args['scene'],args['plan'])
 raise util.Fail('This project tool is not available.')

def sdk_server(project):
 """Official in-process SDK MCP adapter; normal provider tool permissions stay unchanged."""
 import asyncio
 from claude_agent_sdk import tool,create_sdk_mcp_server
 registered=[]
 for descriptor in tools():
  async def handler(args,_name=descriptor['name']):
   try:result=await asyncio.to_thread(call,project,_name,args);return {'content':[{'type':'text','text':json.dumps(result,ensure_ascii=False)}]}
   except (util.Fail,ValueError) as error:return {'is_error':True,'content':[{'type':'text','text':str(error)}]}
  registered.append(tool(descriptor['name'],descriptor['description'],descriptor['inputSchema'])(handler))
 return create_sdk_mcp_server('creatorcut_project',version='1.0.0',tools=registered)
