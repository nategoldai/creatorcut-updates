"""The motion graphics engine: HyperFrames (HTML + GSAP) and Remotion (React), installed privately by the installer
into kit/bin/node and kit/render. Every call goes through the wrappers in kit/bin, which point at the private Node,
FFmpeg and headless browser, so nothing depends on what's installed on the computer."""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from . import util
from .resources import serialized
import tempfile
import shutil

RENDER = util.KIT / "render"
NODE_DIR = util.BIN / "node"
WIN = sys.platform.startswith("win")


def _tool(name: str) -> Path:
    return util.BIN / (f"{name}.cmd" if WIN else name)


def chrome() -> Path | None:
    hits = sorted(RENDER.glob("node_modules/.remotion/chrome-headless-shell/*/chrome-headless-shell-*/chrome-headless-shell*"))
    return next((h for h in hits if h.is_file()), None)


def status() -> dict:
    node = NODE_DIR / ("node.exe" if WIN else "bin/node")
    parts = {"node": node.exists(), "hyperframes": (RENDER / "node_modules" / "hyperframes").exists(),
             "remotion": (RENDER / "node_modules" / "remotion").exists(), "browser": chrome() is not None,
             "skills": (util.KIT / "skills-src/edit/SKILL.md").exists() and (util.DOCS_DIR / "motion.md").exists()}
    missing = [k for k, v in parts.items() if not v]
    return {"ready": not missing, "detail": "ready" if not missing else "missing: " + ", ".join(missing), "parts": parts}


def vision_ready() -> bool:
    try:
        if sys.platform == "darwin":
            import ocrmac  # noqa: F401
            import Vision  # noqa: F401
        else:
            import rapidocr_onnxruntime  # noqa: F401
        import scipy.ndimage, onnxruntime, cv2  # noqa: F401
        return True
    except Exception:
        return False


def render_budget(duration,fps=30):
    """Allow long full-quality compositions; the independent no-output deadline remains enforced."""
    import math
    if type(duration) not in (int,float) or not math.isfinite(duration) or duration<0:raise util.Fail('The render needs a valid video duration.')
    if type(fps) not in (int,float) or not math.isfinite(fps) or not 1<=fps<=120:raise util.Fail('The render needs a supported frame rate.')
    return max(3600,int(duration*fps*3+600))


@serialized
def run(tool: str, args: list[str], cwd: Path, timeout: int = 3600, progress=None) -> subprocess.CompletedProcess:
    """Run hyperframes / remotion through the private wrapper. Fails in plain words if it isn't installed."""
    exe = _tool(tool)
    if not exe.exists():
        raise util.Fail("The motion graphics engine isn't installed yet.", "Run setup again (it only adds what's missing).")
    # An imported renderer is installed under an npm alias. Its executable name
    # must never displace the main composition engine through npm's .bin links.
    argv = [str(exe), *args]
    main = RENDER / "node_modules/hyperframes/bin/hyperframes.mjs"
    node = NODE_DIR / ("node.exe" if WIN else "bin/node")
    if tool == "hyperframes" and main.is_file() and node.is_file():
        argv = [str(node), str(main), *args]
    # A cache directory belongs to exactly one invocation, not the whole machine.
    with tempfile.TemporaryDirectory(prefix='creatorcut-render-') as owned:
        env = dict(os.environ, HYPERFRAMES_SKIP_SKILLS="1", DO_NOT_TRACK="1", TMPDIR=owned, TMP=owned, TEMP=owned)
        # Use the renderer's documented cache settings inside locations this
        # project already owns. Do not write into the customer's global cache,
        # change HOME, or alter the host's network/permission policy.
        font_cache = (cwd.resolve().parent if cwd.name=='hf' else cwd.resolve()) / '.creatorcut-render-cache' / 'fonts'
        font_cache.mkdir(parents=True, exist_ok=True)
        env['HYPERFRAMES_FONT_CACHE_DIR'] = str(font_cache)
        env['HYPERFRAMES_HISTORY_ROOT'] = str(font_cache.parent / 'history')
        env['HYPERFRAMES_EXTRACT_CACHE_DIR'] = str(Path(owned) / 'extract')
        env["PATH"] = str(node.parent) + os.pathsep + str(util.BIN) + os.pathsep + env.get("PATH", "")
        from . import browser_runtime
        project=cwd.resolve().parent if cwd.name=='hf' else cwd.resolve()
        needs_browser = tool == 'hyperframes' and bool(args) and args[0] in ('render', 'check')
        layout=browser_runtime.ensure(project) if needs_browser else browser_runtime.current(project)
        compatible=env.get('CREATORCUT_EDITOR_PROVIDER')=='claude' or layout=='compatibility'
        if sys.platform == 'darwin' and compatible:
            env['CREATORCUT_BROWSER_MODE']='compatibility'
            # Only this owned render's Node processes use the compatibility
            # adapter. It never disables the enclosing host sandbox.
            preload=(util.KIT/'tools/browser_compat.mjs').as_uri()
            env['NODE_OPTIONS']=(env.get('NODE_OPTIONS','')+' --import='+preload).strip()
            import uuid
            env['CREATORCUT_RENDER_SCOPE_ID']=uuid.uuid4().hex
        browser = chrome()
        if browser: env["HYPERFRAMES_BROWSER_PATH"] = str(browser)
        proc = util.spawn(argv, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                          text=True, encoding="utf-8", errors="replace", env=env)
        out = []
        from .render_watchdog import FrameWatchdog
        watchdog=FrameWatchdog() if 'render' in args else None
        try:
            for line in util.progress_lines(proc, timeout=timeout, idle_timeout=min(timeout,120) if watchdog else timeout,on_tick=watchdog.check if watchdog else None):
                if watchdog:watchdog.observe(line)
                out.append(line)
                if progress is not None: progress(line.rstrip())
            return subprocess.CompletedProcess(proc.args, proc.returncode, "".join(out), "")
        finally:
            util.stop_process(proc)
