"""Listen to every word: speech to text with a time for each word (faster-whisper, runs on this computer)."""
from __future__ import annotations

import re
import os
import time
from pathlib import Path

from . import util
from .resources import serialized

DEFAULT_VOCAB = ["Claude", "ChatGPT", "TikTok", "Instagram", "YouTube", "CapCut", "AI"]


def extract_audio(video: Path, out_wav: Path) -> None:
    if util.probe(video).get("has_audio") is False:raise util.Fail("This clip has no sound. Add a spoken clip for speech-based captions and cuts, or choose a music-only edit.")
    util.run([util.ffmpeg_bin(), "-y", "-hide_banner", "-i", str(video), "-vn", "-ac", "1", "-ar", "16000",
              "-c:a", "pcm_s16le", str(out_wav)], label="Pulled the audio out")


def load_wav(wav: Path):
    """16 kHz mono PCM WAV → float32 samples. Whisper gets samples directly, so it never depends on PyAV's
    file decoding (whose API changes between releases)."""
    import wave
    import numpy as np
    with wave.open(str(wav), "rb") as w:
        data = w.readframes(w.getnframes())
    return np.frombuffer(data, dtype=np.int16).astype(np.float32) / 32768.0


def _apply_corrections(word: str, corrections: dict) -> str:
    core = re.sub(r"^\W+|\W+$", "", word)
    for wrong, right in corrections.items():
        if core.lower() == wrong.lower():
            return word.replace(core, right)
    return word


@serialized
def transcribe(project: Path, model_name: str | None = None, language: str | None = None) -> dict:
    src = util.read_json(project / "source.json")
    # A real video without an audio stream is a valid visual edit. Record the
    # measured absence, rather than failing audio extraction or inventing words.
    source = Path(src['path'])
    actual = util.probe(source) if src.get('has_audio') is False else {}
    if actual.get('has_audio') is False:
        from .artifact_cache import digest
        duration = actual.get('duration')
        import math
        if type(duration) not in (int, float) or not math.isfinite(duration) or duration <= 0:
            raise util.Fail('The silent video needs a valid measured duration before editing.')
        out = {'language':None,'duration':float(duration),'model':None,'words':[],
               'segments':[],'speech_status':'not_applicable_no_audio','source_sha256':digest(source)}
        util.write_json(project/'transcript.json',out)
        (project/'transcript.txt').write_text('',encoding='utf-8')
        util.activity('Audio checked: this video has no audio track',100)
        return out
    prof = util.load_profile()
    from . import speech_models
    model_name = speech_models.name(model_name or prof.get("whisper_model", "small"))
    language = language or prof.get("language") or None
    if language in ("auto", ""):
        language = None
    vocab = DEFAULT_VOCAB + list(prof.get("vocabulary", []))
    corrections = {"cloud": "Claude"} if "Claude" in vocab else {}
    corrections.update(prof.get("corrections", {}))

    from . import artifact_cache as cache
    import importlib.metadata
    def cache_key():
        try:version=importlib.metadata.version('faster-whisper')
        except importlib.metadata.PackageNotFoundError:version='unavailable'
        return cache.key('transcript-v1',[Path(src['path']),*cache.model_files(model_name)],
            {'model':model_name,'language':language,'vocabulary':vocab,'corrections':corrections,'engine':version},[Path(__file__)])
    manifest=project/'transcript-cache.json'
    expected=cache_key()
    if cache.hit(manifest,expected):
        util.step('Reusing the unchanged, verified transcript')
        return util.read_json(project/'transcript.json')

    wav = project / "audio16k.wav"
    extract_audio(Path(src["path"]), wav)

    try:
        from faster_whisper import WhisperModel  # type: ignore
    except ImportError:
        raise util.Fail("The transcription engine (faster-whisper) isn't installed.",
                        "Run the setup skill and try again.")

    util.step(f"Listening to every word (model: {model_name}; the first run downloads it once)…")
    t0 = time.time()
    import onnxruntime
    onnxruntime.disable_telemetry_events()
    util.activity("Loading private speech recognition",None)
    model = WhisperModel(str(speech_models.require(model_name)), device="auto", compute_type="int8", cpu_threads=max(1,min(4,(os.cpu_count() or 2)-2)), local_files_only=True)
    segments, info = model.transcribe(
        load_wav(wav), language=language, word_timestamps=True, vad_filter=True, vad_parameters={"min_silence_duration_ms":2000}, beam_size=5,
        # a verbatim-style prompt makes Whisper write down "um", "uh" and restarts instead of tidying them away,
        # so the bad-take logic can see (and cut) them
        condition_on_previous_text=False, initial_prompt="Umm, so, uh, I- I mean, like, hmm. " + ", ".join(vocab) + ".",
    )
    words, segs = [], []
    total = max(0.1, float(getattr(info, "duration", 0) or src.get("duration") or 1))
    util.activity("Listening to every word", 0)
    for seg in segments:
        util.activity(f"Heard: “{seg.text.strip()[:60]}”", seg.end / total * 100)
        segs.append({"start": round(seg.start, 3), "end": round(seg.end, 3), "text": seg.text.strip()})
        for w in seg.words or []:
            text = w.word.strip()
            if not text:
                continue
            text = _apply_corrections(text, corrections)
            words.append({"w": text, "start": round(w.start, 3), "end": round(w.end, 3),
                          "p": round(getattr(w, "probability", 1.0), 3)})
    out = {"language": info.language, "duration": round(float(info.duration), 3), "model": model_name,
           "words": words, "segments": segs}
    if cache_key()!=expected:raise util.Fail('Source footage or speech assets changed during transcription. Retry with the saved footage.')
    util.write_json(project / "transcript.json", out)
    (project / "transcript.txt").write_text("\n".join(s["text"] for s in segs) + "\n", encoding="utf-8")
    wav.unlink(missing_ok=True)
    cache.commit(manifest,expected,[project/'transcript.json',project/'transcript.txt'])
    util.ok(f"Heard {len(words)} words in {time.time() - t0:.0f}s ({info.language})")
    return out


def import_words(project: Path, words_file: Path) -> dict:
    """Use a transcript made elsewhere (JSON list of {w, start, end}) instead of listening."""
    data = util.read_json(words_file)
    words = data.get("words", data) if isinstance(data, dict) else data
    if not isinstance(words, list) or not words:
        raise util.Fail("That file has no words in it.", "It needs a list of {\"w\", \"start\", \"end\"}.")
    src = util.read_json(project / "source.json")
    clean = [{"w": str(w["w"]).strip(), "start": float(w["start"]), "end": float(w["end"]), "p": float(w.get("p", 1.0))}
             for w in words if str(w.get("w", "")).strip()]
    out = {"language": "", "duration": src.get("duration", 0), "model": "imported", "words": clean,
           "segments": [{"start": clean[0]["start"], "end": clean[-1]["end"], "text": " ".join(w["w"] for w in clean)}]}
    util.write_json(project / "transcript.json", out)
    (project / "transcript.txt").write_text(out["segments"][0]["text"] + "\n", encoding="utf-8")
    util.ok(f"Imported {len(clean)} words")
    return out
