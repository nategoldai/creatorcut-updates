"""Immutable Studio instructions and explicit, candidate-bound coverage checks.
These checks enforce traceability, not automatic aesthetic judgement or AI wakeup.
"""
from __future__ import annotations
import hashlib,json
from . import util,videos

FIELDS=('brief','style','preset_version','preset_library_choices','platform','look','library_choices','media','music','music_selection','music_volume','progress_bar','voice_cleanup','keywords','cta','captions','framing','grade','colour_recipe','overrides','sfx','zoom')

def settings(cfg):
    result={k:cfg[k] for k in FIELDS if k in cfg}
    if isinstance(result.get('framing'),dict):result['framing']={k:v for k,v in result['framing'].items() if k!='auto_face'}
    if 'media' in result:
        result['media']=[{k:m[k] for k in ('id','kind','file','name','size_mb','duration') if k in m} for m in result['media']]
    return result

def attached(pid):
    from . import refs
    return [{k:r[k] for k in ('id','kind','url','file','name') if k in r}
            for r in refs.for_project(pid)]

def create(pid, *, batch=None):
    p=videos._dir(pid)
    with util.file_guard(p/'.request.guard',timeout=5),util.file_guard(p/'.editor-job.guard',timeout=5):
        from . import editor
        if editor.read(pid).get('state') not in editor.ACTIVE and (p/'next-settings.json').exists():
            from .server import apply_pending_settings
            apply_pending_settings(pid)
        cfg=videos.load(pid)
        data={'schema':3,'project':pid,'settings':settings(cfg),'references':attached(pid),'batch':batch}
        rid=hashlib.sha256(json.dumps(data,sort_keys=True).encode()).hexdigest()[:32]
        from . import editor
        job=editor.read(pid)
        if job.get('state') in editor.ACTIVE and job.get('request_id')!=rid:
            raise util.Fail('Your current edit is still running. Your new notes stay saved; apply them after it finishes.')
        data['id']=rid
        dst=p/'edit-requests'/f'{rid}.json'
        if not dst.exists():util.write_durable_json(dst,data)
        util.write_durable_json(p/'active-edit-request.json',data)
    return {'ok':True,'id':rid,'prompt':f'Edit existing project {pid}. Read the COMPLETE immutable request kit/projects/{pid}/edit-requests/{rid}.json, including every setting, full brief, reference and feedback batch. Claim this exact request in the current native conversation when editor_mode is chat; in managed mode use only the assigned session. Prepare footage while reference analysis runs; use completed reference evidence before styling. Do not substitute a generic look for a failed reference. Read kit/docs/request-contract.md. Bind scene-plan.request_id to {rid} and account for every requested setting and note in request_application. Render, inspect and publish only after candidate-bound request_checks pass. Preserve originals and older versions. Current instructions override reference, then preset, then creator memory. Keep the current execution owner; never fork a competing editor.'}

def active(p):
    d=util.read_json(p/'active-edit-request.json',default={})
    if not d:return {}
    if not isinstance(d,dict) or d.get('schema') not in (1,2,3) or d.get('project')!=p.name:
        raise util.Fail('The saved editing request is invalid. Resend the saved Studio instructions.')
    expected=dict(d);rid=expected.pop('id',None)
    if hashlib.sha256(json.dumps(expected,sort_keys=True).encode()).hexdigest()[:32]!=rid:
        raise util.Fail('The saved editing request changed. Resend the saved Studio instructions.')
    file=p/'edit-requests'/f'{rid}.json'
    if util.read_json(file,default={})!=d:raise util.Fail('The exact editing request snapshot is missing or changed.')
    return d

def required(d):
    s=d.get('settings',{});out=['brief']
    for k in ('style','preset_version','look','platform','library_choices','preset_library_choices'):
        if s.get(k):out.append(k)
    if d.get('schema',1)>=3:
        for k in ('media','music','music_selection','music_volume','voice_cleanup','captions','framing','grade','colour_recipe','overrides','sfx','zoom','progress_bar','keywords','cta'):
            if k in s and s[k] is not None:out.append(k)
    for i,_ in enumerate(s.get('brief',{}).get('references',[])):out.append(f'reference:{i}')
    for r in d.get('references',[]):out.append('studio-reference:'+r['id'])
    if s.get('brief',{}).get('length'):out.append('length')
    for n in (d.get('batch') or {}).get('notes',[]):out.append('note:'+n['id'])
    return out

def errors(p,doc,*,report=None):
    try:d=active(p)
    except util.Fail as e:return [str(e)]
    if not d:return [] # Existing projects remain compatible until their next Studio request.
    out=[]
    if settings(videos.load(p.name))!=d['settings']:
        out.append('Studio settings changed after this request. Save and send a fresh request before rendering.')
    if d.get('schema',1)>=2 and attached(p.name)!=d.get('references',[]):
        out.append('Studio reference choices changed after this request. Start with the current saved choices.')
    if doc.get('request_id')!=d['id']:out.append('Bind scene-plan.request_id to the exact active editing request.')
    rows=doc.get('request_application',[])
    if not isinstance(rows,list) or any(not isinstance(x,dict) for x in rows):return out+['request_application must contain objects.']
    ids={s.get('id') for s in doc.get('scenes',[]) if isinstance(s,dict)}
    need=required(d)
    for key in need:
        matches=[x for x in rows if x.get('key')==key]
        if len(matches)!=1:out.append('Account for requested input exactly once: '+key);continue
        row=matches[0]
        if row.get('status') not in ('applied','overridden') or len(str(row.get('reason','')).strip())<20:
            out.append('Record a concrete application or explicit higher-priority override: '+key)
        if row.get('status')=='applied' and (not isinstance(row.get('scenes'),list) or not row['scenes'] or any(x not in ids for x in row['scenes'])):
            out.append('Bind requested input to existing scene ids: '+key)
        # Revision notes cannot be silently dismissed as a lower-priority style default.
        if key.startswith('note:') and row.get('status')!='applied':out.append('Resolve the requested revision before release: '+key)
    if report is not None:
        checks=report.get('request_checks',{})
        if not isinstance(checks,dict):return out+['request_checks must be an object.']
        for key in need:
            row=checks.get(key,{})
            if not isinstance(row,dict) or row.get('pass') is not True or len(str(row.get('observations','')).strip())<20:
                out.append('Inspect this requested input in the actual candidate: '+key)
    return out
