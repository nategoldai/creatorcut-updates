"""Bounded editing steps with ownership-scoped cleanup.

A small guardian owns the real step until cleanup and wait finish. It can stop
that unreaped child without process-table access, and watches for parent EOF.
CPU counters and real progress distinguish work from a stall; host permissions
and genuine rendering failures remain explicit.
"""
import json,os,re,signal,subprocess,sys,time,threading,queue,tempfile,ctypes,errno
from pathlib import Path

CHILD='CREATORCUT_STEP_CHILD'
RETRY='CREATORCUT_STEP_RETRY'
STEPS={'measure-ref','design','compose','grade','new','prepare','transcribe','plan','cut','beats','check','preview','render','auto','export','compare','cover','study-ref','cutout','teach','tour','short'}
WORKFLOW={'init','validate','evidence','review-dry-run','review','publish'}
RETRYABLE=(STEPS-{'auto','teach','study-ref','new'})|{'library-prepare','library-run','library-render-look'}
STALL_SECONDS=float(os.environ.get('CREATORCUT_STEP_STALL_SECONDS') or 180)
POLL=float(os.environ.get('CREATORCUT_STEP_POLL_SECONDS') or 2)
STOPPED=130

def _table():
 if os.name=='nt':return []
 try:out=subprocess.run(['ps','-Ao','pid=,ppid=,time='],capture_output=True,text=True,timeout=20).stdout
 except (OSError,subprocess.SubprocessError):return []
 rows=[]
 for line in out.splitlines():
  part=line.split()
  if len(part)==3 and part[0].isdigit() and part[1].isdigit():rows.append((int(part[0]),int(part[1]),_seconds(part[2])))
 return rows

def _seconds(text):
 days,_,rest=text.rpartition('-')
 total=0.
 for piece in rest.split(':'):
  try:total=total*60+float(piece)
  except ValueError:return 0.
 return total+(int(days)*86400 if days.isdigit() else 0)

def tree(root):
 rows=_table()
 if not rows:return {root},None
 found={root};grew=True
 while grew:
  grew=False
  for pid,parent,_ in rows:
   if parent in found and pid not in found:found.add(pid);grew=True
 return found,sum(cpu for pid,_,cpu in rows if pid in found)

def _identity(pid):
 try:return subprocess.run(['ps','-o','lstart=','-p',str(pid)],capture_output=True,text=True,timeout=10).stdout.strip()
 except (OSError,subprocess.SubprocessError):return ''

def _parent(pid):
 try:
  value=subprocess.run(['ps','-o','ppid=','-p',str(pid)],capture_output=True,text=True,timeout=10).stdout.strip()
  return int(value) if value.isdigit() else None
 except (OSError,subprocess.SubprocessError):return None


def end_tree(root,birth,grace=3):
 """Stop the step's own tree only. A reused process id is never signalled."""
 if os.name=='nt':
  subprocess.run(['taskkill','/PID',str(root),'/T','/F'],capture_output=True,check=False);return
 if not birth or _identity(root)!=birth:return
 pids,_=tree(root);parents={pid:_parent(pid) for pid in pids if pid!=root};owned={root}
 while True:
  added={pid for pid,parent in parents.items() if parent in owned}-owned
  if not added:break
  owned.update(added)
 pids=owned;identities={pid:_identity(pid) for pid in pids};deadline=time.monotonic()+grace
 for sig,wait in ((signal.SIGTERM,True),(signal.SIGKILL,False)):
  for pid in pids:
   if not identities.get(pid) or _identity(pid)!=identities[pid]:continue
   try:os.kill(pid,sig)
   except (ProcessLookupError,PermissionError):pass
  while wait and time.monotonic()<deadline:
   pids={pid for pid in pids if _alive(pid)}
   if not pids:return
   time.sleep(.1)

def _alive(pid):
 try:os.kill(pid,0)
 except ProcessLookupError:return False
 except PermissionError:pass
 try:
  # An exited child stays visible until its parent collects it.
  state=subprocess.run(['ps','-o','stat=','-p',str(pid)],capture_output=True,text=True,timeout=10).stdout.strip()
  return bool(state) and not state.startswith('Z')
 except (OSError,subprocess.SubprocessError):return True

def reap(root,birth):
 """Runs outside the chat's process group; a closed pipe without 'done' means the chat died."""
 signal.signal(signal.SIGINT,signal.SIG_IGN);signal.signal(signal.SIGTERM,signal.SIG_IGN)
 if sys.stdin.read(4)!='done':end_tree(root,birth)

def _project_file(root,project):
 return Path(root)/'kit/projects'/str(project)/'editor-job.json'

def _cancelled(root,project):
 try:return json.loads(_project_file(root,project).read_text()).get('cancel') is True
 except (OSError,ValueError,AttributeError):return False

def _record(root,child):
 """Progress and exact project from this step's own activity record."""
 progress=0.;project=None
 try:
  for row in (Path(root)/'kit/studio-out/activities').glob(str(child)+'-*.json'):
   data=json.loads(row.read_text());progress=max(progress,float(data.get('progress_at') or 0));project=data.get('project') or project
 except (OSError,ValueError,TypeError,AttributeError):pass
 return progress,project

def _waiting_for_resources(root,child):
 try:
  for file in (Path(root)/'kit/studio-out/activities').glob(str(child)+'-*.json'):
   row=json.loads(file.read_text())
   if row.get('pid')==child and row.get('running') and row.get('waiting_resources') and 0<=time.time()-float(row.get('queue_checked_at',0))<5:return True
 except (OSError,ValueError,TypeError):pass
 return False


def hard_limit(root,cmd,project):
 if os.environ.get('CREATORCUT_TEST_ONLY')=='1' and os.environ.get('CREATORCUT_STEP_LIMIT_SECONDS'):return float(os.environ['CREATORCUT_STEP_LIMIT_SECONDS'])
 duration=0.
 try:duration=float(json.loads((Path(root)/'kit/projects'/str(project)/'source.json').read_text()).get('duration') or 0)
 except (OSError,ValueError,TypeError):pass
 if cmd in ('transcribe','plan','cut','check','design','beats','cover'):return max(1200.,min(7200.,duration*40))
 effects=0
 try:effects=len(json.loads((Path(root)/'kit/projects'/str(project)/'project.json').read_text()).get('library_choices',{}).get('effects',[]))
 except (OSError,ValueError,TypeError):pass
 return max(3600.,min(43200.,max(duration*120,effects*4200.)))

def select(argv):
 """Return (step, project) for a command that must be watched, else None."""
 if not argv or os.environ.get(CHILD)=='1':return None
 cmd=argv[0]
 if cmd=='matrix-item':return 'matrix-item',argv[1] if len(argv)>1 else None
 rest=[item for item in argv[1:] if not item.startswith('-')]
 if cmd=='workflow':
  if not rest or rest[0] not in WORKFLOW:return None
  return 'workflow-'+rest[0],(rest[1] if len(rest)>1 else None)
 if cmd not in STEPS:return None
 return cmd,(rest[0] if rest else None)

def _child_exited(child):
 """Observe our child without reaping it, keeping its PID reserved by the kernel."""
 if child.returncode is not None:return True
 if os.name=='nt':return child.poll() is not None
 info=ctypes.create_string_buffer(256)
 libc=ctypes.CDLL(None,use_errno=True)
 result=libc.waitid(int(os.P_PID),child.pid,ctypes.byref(info),int(os.WEXITED|os.WNOHANG|os.WNOWAIT))
 if result:
  error=ctypes.get_errno()
  if error==errno.EINTR:return False
  raise OSError(error,os.strerror(error))
 return ctypes.c_int.from_buffer(info).value!=0

def _signal_child(child,grace=2,isolated=True):
 """Only the child we started: waitid proves ownership and does not release its PID."""
 if child.returncode is not None:return
 if os.name=='nt':
  if child.poll() is None:child.terminate()
  return
 try:_child_exited(child)
 except OSError:return # Not our unreaped child: never signal a remembered PID.
 # start_new_session=True makes this PID the session/group leader. Even an
 # exited leader remains unreaped here, so its ID cannot belong to a stranger.
 for sig in (signal.SIGTERM,signal.SIGKILL):
  try:
   if isolated:
    try:os.killpg(child.pid,sig)
    except PermissionError:os.kill(child.pid,sig) # Narrower: only our unreaped direct child.
   else:os.kill(child.pid,sig)
  except ProcessLookupError:pass
  if sig==signal.SIGTERM:
   until=time.monotonic()+grace
   while time.monotonic()<until:
    if _child_exited(child):break
    time.sleep(.05)
 # The caller, and only the caller, now collects the child.

def _stop_child(child,grace=2,isolated=True):
 """Never signal a reaped handle or race another thread collecting its PID."""
 lock=child._waitpid_lock if os.name!='nt' else None
 if lock is not None and not lock.acquire(blocking=False):return
 try:_signal_child(child,grace,isolated)
 finally:
  if lock is not None:lock.release()


def _own_child_cpu(pid):
 """Read only CPU counters, for a child handle held by this step; ps is optional."""
 if sys.platform=='darwin':
  try:
   usage=ctypes.create_string_buffer(1024);lib=ctypes.CDLL('/usr/lib/libproc.dylib',use_errno=True)
   if lib.proc_pid_rusage(int(pid),2,ctypes.byref(usage))==0:
    return (ctypes.c_uint64.from_buffer(usage,16).value+ctypes.c_uint64.from_buffer(usage,24).value)/1e9
  except (OSError,AttributeError):pass
 elif sys.platform.startswith('linux'):
  try:
   fields=Path('/proc/'+str(pid)+'/stat').read_text().rsplit(')',1)[1].split()
   return (int(fields[11])+int(fields[12]))/os.sysconf('SC_CLK_TCK')
  except (OSError,ValueError,IndexError):pass
 return None

def _cpu_reporter():
 file=os.environ.get('CREATORCUT_STEP_CPU_FILE')
 if not file or os.environ.get(CHILD)!='1':return
 import resource,weakref
 children=weakref.WeakSet();original=subprocess.Popen.__init__
 def started(handle,*args,**kwargs):
  original(handle,*args,**kwargs);children.add(handle)
 subprocess.Popen.__init__=started
 def handles():return [ref() for ref in children.data.copy() if ref() is not None]
 def report():
  while True:
   try:
    usage=resource.getrusage(resource.RUSAGE_CHILDREN);live=0.;complete=True
    for handle in handles():
     if handle.returncode is None:
      try:
       if not _child_exited(handle):
        cpu=_own_child_cpu(handle.pid)
        if cpu is None:complete=False
        else:live+=cpu
      except OSError:pass
    data={'pid':os.getpid(),'complete':complete,'cpu':max(0.,time.process_time()-time.thread_time())+usage.ru_utime+usage.ru_stime+live}
    temp=Path(file+'.'+str(os.getpid())+'.tmp');temp.write_text(json.dumps(data));os.replace(temp,file)
   except OSError:return
   time.sleep(.5)
 threading.Thread(target=report,daemon=True).start()
 # Clean only this step's Popen handles, including helpers that detached into
 # another session. waitid confirms they remain this process's unreaped children.
 def stopped(signum,frame):
  signal.signal(signum,signal.SIG_DFL)
  for handle in handles():
   if handle.returncode is None:
    try:
     _stop_child(handle,grace=.2,isolated=False);handle.wait(timeout=.5)
    except (OSError,subprocess.SubprocessError):pass
  raise SystemExit(130)
 signal.signal(signal.SIGTERM,stopped)

def _fallback_cpu(file,pid):
 try:
  value=json.loads(Path(file).read_text())
  return float(value['cpu']) if value.get('pid')==pid and value.get('complete',True) else None
 except (OSError,ValueError,TypeError,KeyError):return None

def supervise(entry,argv,status_fd,cpu_file):
 """Own the real child even if the chat/watcher dies. No process-query permission."""
 messages=queue.Queue()
 def commands():
  for line in sys.stdin:messages.put(line.strip())
  messages.put('stop') # The watcher died or closed its end of the pipe.
 threading.Thread(target=commands,daemon=True).start()
 env=dict(os.environ,**{CHILD:'1','CREATORCUT_STEP_CPU_FILE':cpu_file})
 command=argv if entry=='--exec' else [sys.executable,entry,*argv]
 child=subprocess.Popen(command,stdin=subprocess.DEVNULL,env=env,start_new_session=True)
 with os.fdopen(status_fd,'w',buffering=1) as status:
  try:status.write(json.dumps({'pid':child.pid})+'\n')
  except BrokenPipeError:
   _stop_child(child);child.wait(timeout=5);return STOPPED
  awake=None
  if sys.platform=='darwin':
   try:awake=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(child.pid)],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
   except OSError:pass
  try:
   while not _child_exited(child):
    try:message=messages.get(timeout=.1)
    except queue.Empty:continue
    if message=='stop':break
   # Keep the child unreaped until all signals are sent. The optional identity
   # path also cleans detached descendants when the OS exposes them.
   birth=_identity(child.pid)
   if birth:end_tree(child.pid,birth,grace=0)
   _stop_child(child)
   code=child.wait(timeout=5)
   try:status.write(json.dumps({'exit':code})+'\n')
   except BrokenPipeError:pass
   return code
  finally:
   if awake:
    try:awake.wait(timeout=1)
    except subprocess.TimeoutExpired:
     awake.terminate()
     try:awake.wait(timeout=2)
     except subprocess.TimeoutExpired:pass

def _attempt(entry,argv,root,step,project,retry):
 if os.name=='nt':
  # This installation is Mac-only; Windows remains unverified.
  raise RuntimeError('This installation watcher requires macOS or POSIX child sessions.')
 out=Path(root)/'kit/studio-out';out.mkdir(parents=True,exist_ok=True)
 with tempfile.TemporaryDirectory(prefix='.stepguard-',dir=out) as temp:
  cpu_file=str(Path(temp)/'cpu.json');read_fd,write_fd=os.pipe()
  env=dict(os.environ)
  if retry:env[RETRY]='1'
  guardian=subprocess.Popen([sys.executable,'-S',str(Path(__file__).resolve()),'--supervise',str(write_fd),cpu_file,str(entry),*argv],stdin=subprocess.PIPE,env=env,pass_fds=(write_fd,),start_new_session=True,text=True)
  os.close(write_fd);events=queue.Queue()
  def receive():
   with os.fdopen(read_fd) as stream:
    for line in stream:
     try:events.put(json.loads(line))
     except ValueError:pass
  threading.Thread(target=receive,daemon=True).start()
  try:first=events.get(timeout=90)
  except queue.Empty:
   guardian.stdin.close()
   try:guardian.wait(timeout=8)
   except subprocess.TimeoutExpired:return 1,'cleanup'
   return 1,'startup'
  child_pid=first['pid'];started=time.monotonic();limit=hard_limit(root,step,project)
  last_cpu=-1.;last_change=started;last_progress=0.;outcome=None;queue_time=0.;last_tick=started;was_waiting=False
  def stop():
   try:guardian.stdin.write('stop\n');guardian.stdin.flush()
   except (OSError,ValueError):pass
   try:return guardian.wait(timeout=8)
   except subprocess.TimeoutExpired:return None
  try:
   while True:
    try:event=events.get_nowait()
    except queue.Empty:event={}
    if 'exit' in event:
     guardian.wait(timeout=5);return event['exit'],None
    if guardian.poll() is not None:return guardian.returncode,None
    now=time.monotonic()
    # This is liveness checked by the owner of the guardian handle, not invented
    # render progress. The temporary directory is removed when this attempt ends.
    health=Path(temp)/'watcher.json';pending=health.with_suffix('.partial')
    pending.write_text(json.dumps({'project':project,'guardian_pid':guardian.pid,'child_pid':child_pid,'watcher_pid':os.getpid(),'checked_at':time.time(),'state':'running','step':step,'hard_limit_seconds':limit}))
    os.replace(pending,health)
    waiting=_waiting_for_resources(root,child_pid)
    if waiting:queue_time+=max(0,now-last_tick);last_change=now
    elif was_waiting:last_change=now
    was_waiting=waiting;last_tick=now
    if project and _cancelled(root,project):outcome='stopped'
    elif queue_time>21600:outcome='queue_limit'
    elif now-started-queue_time>limit:outcome='limit'
    elif not waiting:
     progress,owner=_record(root,child_pid)
     if owner:project=owner
     _,cpu=tree(child_pid)
     if cpu is None:cpu=_fallback_cpu(cpu_file,child_pid)
     if cpu is not None and abs(cpu-last_cpu)>.005 or progress>last_progress:
      if cpu is not None:last_cpu=cpu
      last_progress=max(progress,last_progress);last_change=now
     elif cpu is not None and now-last_change>STALL_SECONDS:outcome='stalled'
    if outcome:
     if stop() is None:return 1,'cleanup'
     return (STOPPED if outcome=='stopped' else 1),outcome
    time.sleep(POLL)
  except (KeyboardInterrupt,SystemExit):stop();raise
  finally:
   try:guardian.stdin.close()
   except (OSError,ValueError):pass

def _terminate(signum,frame):
 raise KeyboardInterrupt

def run(entry,argv,root):
 """Watch one step through exit, Stop, stall or its hard deadline."""
 selected=select(argv)
 if Path(entry).name=='style-library.py' and argv and argv[0] in ('prepare','run','render-look','slot','attach','recipe') and os.environ.get(CHILD)!='1':selected=('library-'+argv[0],argv[1] if len(argv)>1 else None)
 if not selected:return None
 step,project=selected
 signal.signal(signal.SIGTERM,_terminate)
 try:
  code,outcome=_attempt(entry,argv,root,step,project,False)
  if outcome=='startup' or outcome=='stalled' and step in RETRYABLE:
   print('\n• The step did not get ready in time, so CreatorCut is retrying once. Your work is saved.' if outcome=='startup' else '\n• This step stopped moving, so CreatorCut restarted it once. Your work is saved.',flush=True)
   code,outcome=_attempt(entry,argv,root,step,project,True)
 except KeyboardInterrupt:
  print('\n✗ This editing step was stopped. Your footage and saved versions are safe.',flush=True)
  return STOPPED
 if outcome=='stopped':print('\n✗ Edit stopped. Your footage and saved versions are safe.',flush=True)
 elif outcome:
  messages={
   'startup':'The step could not start after one retry. Close other heavy apps, then run this saved step again.',
   'cleanup':'The previous step is still finishing its safe shutdown. Do not start a second editor. Press Stop edit, wait for it to stop, then choose Continue in a new chat.',
   'limit':'This step reached its time limit and stopped. Close heavy apps or use a shorter clip, then retry the saved step.',
   'queue_limit':'Your other video is still using the editor. This saved step has waited six hours. Finish that video, then retry this step.',
   'stalled':'This step stopped responding and was stopped safely. Close other heavy apps, then retry this saved step.'}
  print('\n✗ '+messages.get(outcome,'This step paused. Open your chat, check the last message, then retry the saved step.')+' Your footage and saved versions are safe.',flush=True)
 if outcome and project:
  try:
   sys.path.insert(0,str(Path(root)/'kit'))
   from editkit import editor
   if outcome=='stopped':editor.cancel(project)
  except Exception:pass
 return code

if __name__=='__main__':
 if sys.argv[1:2]==['--reap']:reap(int(sys.argv[2]),sys.argv[3])
 elif sys.argv[1:2]==['--supervise']:
  try:sys.exit(supervise(sys.argv[4],sys.argv[5:],int(sys.argv[2]),sys.argv[3]))
  except BrokenPipeError:sys.exit(STOPPED)
else:_cpu_reporter()

