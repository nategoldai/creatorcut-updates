"""Opening Studio is independent of readiness to edit. Checks are single-flight and observable."""
import threading,time
from . import util
_lock=threading.Lock();_memory={};_memory_root=None
def _save(value):
 global _memory,_memory_root
 _memory=value;_memory_root=util.ROOT
 try:util.write_json(util.STUDIO_OUT/'readiness.json',value)
 except OSError:util.log('Readiness status kept in memory; storage is not writable.')
def status():
 try:
  value=util.read_json(util.STUDIO_OUT/'readiness.json',default=_memory if _memory_root==util.ROOT else {})
  if not isinstance(value,dict) or (value and value.get('state') not in ('ready','checking','repair')):raise util.Fail('Invalid readiness record.')
  proof=util.read_json(util.STUDIO_OUT/'setup-ready.json',default={})
  if proof.get('state')=='ready' and proof.get('version')==(util.KIT/'VERSION').read_text().strip() and float(proof.get('updated',0))>=float(value.get('updated',0)):
   return {'state':'ready','updated':proof['updated'],'message':''}
  return value
 except (util.Fail,OSError,ValueError,TypeError):return {'state':'repair','message':'The saved setup status could not be read. Run the setup check again.'}
def start():
 if not _lock.acquire(blocking=False):return status()
 _save({'state':'checking','updated':time.time(),'message':'Checking your editing tools'})
 def check():
  try:
   from . import setup
   setup.require_open_ready();_save({'state':'ready','updated':time.time(),'message':''})
  except Exception as e:
   util.log_exception('Editing readiness')
   _save({'state':'repair','updated':time.time(),'message':str(e)[:400] if isinstance(e,util.Fail) else 'The editing tools need a setup check. Your videos are saved.'})
  finally:_lock.release()
 try:threading.Thread(target=check,name='creatorcut-readiness',daemon=True).start()
 except RuntimeError:
  _save({'state':'repair','updated':time.time(),'message':'The setup check could not start. Close unused apps and check again.'});_lock.release()
 return status()
