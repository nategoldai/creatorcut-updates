"""Cut the video: keep the good takes, drop pauses and fillers, reframe to the platform, tone-map HDR."""
from __future__ import annotations

from pathlib import Path

from . import plan as planmod
from . import platforms, util


def _snap(t: float, fps: float) -> float:
    return round(round(t * fps) / fps, 4)


def reframe_filter(src: dict, out_w: int, out_h: int, framing: dict) -> tuple[str, bool]:
    """Return (filter, uses_split). Cover-crop around a focus point, or blur-fill when shapes differ a lot."""
    sw, sh = src["width"], src["height"]
    framing=dict(framing)
    auto=framing.get('auto_face') or {}
    if not any(k in framing for k in ('face_x','face_y')) and framing.get('x',.5)==.5 and framing.get('y',.5)==.5:
        framing.update({k:auto[v] for k,v in [('face_x','x'),('face_y','y')] if v in auto})
    fit = framing.get("fit", "auto")
    src_ar, out_ar = sw / sh, out_w / out_h
    if fit == "auto":
        fit = "blur" if (src_ar > 1.2 and out_ar < 0.8) and framing.get("prefer_blur", False) else "cover"
    if fit == "blur":
        return (f"split=2[bgsrc][fgsrc];"
                f"[bgsrc]scale={out_w}:{out_h}:force_original_aspect_ratio=increase,crop={out_w}:{out_h},"
                f"boxblur=luma_radius=40:luma_power=2,eq=brightness=-0.08[bg];"
                f"[fgsrc]scale={out_w}:{out_h}:force_original_aspect_ratio=decrease[fg];"
                f"[bg][fg]overlay=(W-w)/2:(H-h)/2"), True
    fx = float(framing.get("x", 0.5))
    fy = float(framing.get("y", 0.5))
    if framing.get("face_x") is not None:
        # keep the detected face centred: convert its position in the source into a pan position for the crop
        s_ = max(out_w / sw, out_h / sh)
        iw, ih = sw * s_, sh * s_
        if iw - out_w > 1:
            fx = min(1.0, max(0.0, (float(framing["face_x"]) * iw - out_w / 2) / (iw - out_w)))
        if ih - out_h > 1 and framing.get("face_y") is not None:
            fy = min(1.0, max(0.0, (float(framing["face_y"]) * ih - out_h * 0.38) / (ih - out_h)))
    return (f"scale={out_w}:{out_h}:force_original_aspect_ratio=increase:flags=lanczos,"
            f"crop={out_w}:{out_h}:'(iw-ow)*{fx:.3f}':'(ih-oh)*{fy:.3f}'"), False


def tonemap_filter(src: dict) -> str:
    """iPhone HDR (HLG / PQ) looks washed out or neon in normal players: map it to standard colour."""
    if not src.get("hdr"):
        return ""
    if util.ffmpeg_has_filter("zscale") and util.ffmpeg_has_filter("tonemap"):
        return ("zscale=t=linear:npl=100,format=gbrpf32le,zscale=p=bt709,tonemap=tonemap=hable:desat=0,"
                "zscale=t=bt709:m=bt709:r=tv,format=yuv420p,")
    raise util.Fail("This HDR source needs colour conversion support before SDR export.",
                    "Run setup with an FFmpeg build that includes zscale and tonemap, or provide a correctly converted SDR source.")


def cut(project: Path) -> dict:
    cfg = util.read_json(project / "project.json")
    src = util.read_json(project / "source.json")
    tr = util.read_json(project / "transcript.json")
    pl = util.read_json(project / "plan.json")
    if pl.get('mode')=='visual':
        from .artifact_cache import digest
        actual=util.probe(Path(src['path']))
        if actual.get('has_audio') is not False or tr.get('speech_status')!='not_applicable_no_audio' or pl.get('source_sha256')!=tr.get('source_sha256') or digest(Path(src['path']))!=pl.get('source_sha256'):
            raise util.Fail('The visual edit no longer matches the verified silent footage. Run transcribe and plan again.')
    plat = platforms.get(cfg.get("platform", "tiktok"))
    fps = float(plat["fps"])
    W, H = plat["width"], plat["height"]

    segs = planmod.segments_from_plan(pl, tr["words"], src["duration"])
    for s in segs:
        s["start"] = _snap(s["start"], fps)
        s["end"] = max(_snap(s["end"], fps), s["start"] + 1 / fps)

    sel = util.balanced_sum(f"between(t,{s['start']:.4f},{s['end'] - 0.0005:.4f})" for s in segs)
    ramp = 0.014                                   # a short fade at every join: no clicks
    gain = util.balanced_sum(f"between(t,{s['start']:.4f},{s['end']:.4f})*min(1,min((t-{s['start']:.4f})/{ramp},({s['end']:.4f}-t)/{ramp}))"
                    for s in segs)
    reframe, _ = reframe_filter(src, W, H, cfg.get("framing", {}))
    tm = tonemap_filter(src)

    vchain = (f"[0:v]{tm}fps={fps:g},select='{sel}',setpts=N/FRAME_RATE/TB,{reframe},setsar=1,format=yuv420p[v]")
    if src["has_audio"]:
        achain = (f"[0:a]aresample=48000,aformat=channel_layouts=stereo,asetnsamples=n={int(48000 / fps)}:p=1,"
                  f"aeval='val(ch)*({gain})':c=same,"
                  f"aselect='{sel}',asetpts=N/SR/TB[a]")
    else:
        total = sum(s["end"] - s["start"] for s in segs)
        achain = f"anullsrc=r=48000:cl=stereo,atrim=duration={total:.3f}[a]"
    script = project / "work" / "cut.filter"
    script.parent.mkdir(exist_ok=True)
    script.write_text(vchain + ";\n" + achain, encoding="utf-8")

    out = project / "cut.mp4"
    util.step(f"Cutting {len(segs)} clean sections out of your video…")
    util.activity(f"Cutting {len(segs)} clean sections, removing {max(0, len(segs) - 1)} gaps", 0)
    util.run_progress([util.ffmpeg_bin(), "-y", "-hide_banner", "-i", src["path"], *util.filter_script_args(script),
              "-map", "[v]", "-map", "[a]", "-c:v", "libx264", "-preset", "veryfast", "-crf", "16",
              "-c:a", "aac", "-b:a", "256k", "-movflags", "+faststart", str(out)],
                      sum(s["end"] - s["start"] for s in segs), label="Cut done", detail="Cutting")

    # remap words to the new timeline
    words = tr["words"]
    phrase_of = {}
    for ph in pl["phrases"]:
        for i in range(ph["first"], ph["last"] + 1):
            phrase_of[i] = ph["id"]
    new_words, offset, seg_map = [], 0.0, []
    for s in segs:
        seg_map.append({"src_start": s["start"], "src_end": s["end"], "start": round(offset, 3),
                        "end": round(offset + s["end"] - s["start"], 3)})
        for i in s["words"]:
            w = words[i]
            ns = max(0.0, w["start"] - s["start"]) + offset
            ne = min(w["end"], s["end"]) - s["start"] + offset
            new_words.append({"w": w["w"], "start": round(ns, 3), "end": round(max(ne, ns + 0.04), 3),
                              "i": i, "phrase": phrase_of.get(i)})
        offset += s["end"] - s["start"]
    info = util.probe(out)
    util.write_json(project / "words.json", {"duration": info["duration"], "words": new_words})
    util.write_json(project / "segments.json", {"segments": seg_map})
    util.ok(f"New length {util.fmt_time(info['duration'])} (was {util.fmt_time(src['duration'])})")
    return {"duration": info["duration"], "segments": len(segs)}
