"""Release admission uses evidence bound to this source, never historical green flags."""
import json,hashlib,re
from pathlib import Path
HOST_REQUIRED={host:tuple(key+'_'+host for key in ('clean_install','make_publish','revision')) for host in ('codex','claude')}
COMMON_REQUIRED=('reference_and_choices','download_saved_video','update_and_rollback','backend_and_ui','release_e2e','customer_journey')

REQUIRED=HOST_REQUIRED['claude']+COMMON_REQUIRED

def errors(source,evidence):
 source=Path(source);evidence=Path(evidence);issues=[]
 def read(file):
  try:
   value=json.loads(file.read_text())
   return value if isinstance(value,dict) else {}
  except (OSError,ValueError):return {}
 build=read(source/'BUILD.json');receipt=read(evidence)
 policy=read(source/'kit/execution-policy.json')
 if policy.get('default_editor_mode')!='chat':issues.append('The customer execution policy must default to visible-chat editing.')
 version=(source/'kit/VERSION').read_text().strip()
 if build.get('version')!=version:issues.append('Build metadata and the app version differ.')
 if build.get('status')!='release':issues.append('This app is a candidate, not an approved customer release.')
 if receipt.get('version')!=version:issues.append('Acceptance evidence is missing for this exact version.')
 manifest=receipt.get('source_manifest',{})
 if not isinstance(manifest,dict) or not manifest:issues.append('A source-bound verification manifest is required.')
 else:
  for name,want in manifest.items():
   rel=Path(name) if isinstance(name,str) else Path('..')
   if rel.is_absolute() or '..' in rel.parts or not isinstance(want,str) or not re.fullmatch('[0-9a-f]{64}',want):issues.append('The acceptance manifest contains an invalid file.');break
   file=source/rel
   if file.is_symlink() or not file.is_file() or not file.resolve().is_relative_to(source.resolve()):issues.append('A verified source file is missing: '+name);continue
   if hashlib.sha256(file.read_bytes()).hexdigest()!=want:issues.append('Source changed after verification: '+name)
  for name in ('edit.py','AGENTS.md','CLAUDE.md','Studio.html','BUILD.json','kit/VERSION','kit/execution-policy.json','README.md','.claude/settings.json','.claude/launch.json'):
   if name not in manifest:issues.append('Acceptance manifest omits required source: '+name)
  # A manifest cannot approve only a convenient subset of the implementation.
  required=set()
  for root in ('kit/editkit','kit/tools','kit/setup','kit/studio/app','kit/style-library','kit/styles','kit/fonts','kit/sfx','kit/skills-src','kit/docs','kit/render/package.json','kit/render/package-lock.json'):
   location=source/root
   for file in location.rglob('*') if location.is_dir() else [location]:
    if file.is_file() and file.suffix!='.pyc' and file.name!='.DS_Store' and '__pycache__' not in file.parts:required.add(file.relative_to(source).as_posix())
  for skill in (source/'kit/skills-src').rglob('*'):
   if not skill.is_file() or '__pycache__' in skill.parts or skill.suffix=='.pyc':continue
   for host in ('.agents/skills','.claude/skills'):
    clone=source/host/skill.relative_to(source/'kit/skills-src')
    required.add(clone.relative_to(source).as_posix())
    if not clone.is_file() or clone.read_bytes()!=skill.read_bytes():issues.append('Host skill differs from its verified instructions: '+clone.relative_to(source).as_posix())
  for name in sorted(required-set(manifest)):issues.append('Acceptance manifest omits implementation: '+name)
 checks=receipt.get('checks',{})
 hosts=build.get('release_hosts',['claude'])
 if not isinstance(hosts,list) or not hosts or any(h not in HOST_REQUIRED for h in hosts):issues.append('Declare the actual accepted release hosts.');hosts=['claude']
 required=tuple(dict.fromkeys((*COMMON_REQUIRED,*(key for host in hosts for key in HOST_REQUIRED[host]))))
 for name in required:
  row=checks.get(name,{}) if isinstance(checks,dict) else {}
  if not isinstance(row,dict) or row.get('passed') is not True or row.get('mode')!='actual':issues.append('Actual acceptance has not passed: '+name);continue
  proof=row.get('evidence')
  rel=Path(proof) if isinstance(proof,str) and proof else Path('..')
  file=evidence.parent/rel
  want=row.get('sha256')
  if rel.is_absolute() or '..' in rel.parts or file.is_symlink() or not file.is_file() or not file.resolve().is_relative_to(evidence.parent.resolve()) or not isinstance(want,str) or hashlib.sha256(file.read_bytes()).hexdigest()!=want:
   issues.append('Acceptance evidence is unavailable or changed: '+name)
 return issues
