"""Revision-pinned private speech models. Setup verifies bytes; editing stays offline."""
from pathlib import Path
import os,shutil,hashlib,json,time
from . import util
NAMES={'tiny','tiny.en','base','base.en','small','small.en','medium','medium.en','large-v1','large-v2','large-v3','large-v3-turbo','turbo','distil-small.en','distil-medium.en','distil-large-v2','distil-large-v3'}
REQUIRED=('model.bin','config.json','tokenizer.json')
def name(value):
 if not isinstance(value,str) or value not in NAMES:raise util.Fail('Choose a supported speech model before downloading it.')
 return value
def folder(value):return util.KIT/'models'/name(value)
def complete(path):return not path.is_symlink() and all((path/n).is_file() and not (path/n).is_symlink() and (path/n).stat().st_size>0 for n in REQUIRED)
def _pin(value):
 pins=util.read_json(util.KIT/'editkit/speech-model-pins.json',default={});pin=pins.get(name(value))
 if not isinstance(pin,dict) or not pin.get('revision') or not all(k in pin.get('files',{}) for k in REQUIRED):raise util.Fail('The verified speech model list is missing. Repair the app tools.')
 return pin

def _stats(path,pin):
 out={}
 for key in pin['files']:
  file=path/key
  if Path(key).name!=key or not file.is_file() or file.is_symlink():return None
  st=file.stat();out[key]={'size':st.st_size,'mtime_ns':st.st_mtime_ns,'inode':st.st_ino}
 return out

def _pin_sha(pin):return hashlib.sha256(json.dumps(pin,sort_keys=True).encode()).hexdigest()
def cached(value):
 try:
  p=folder(value);pin=_pin(value)
  if not complete(p):return False
  receipt=util.read_json(p/'model-receipt.json',default={});stats=_stats(p,pin)
  return stats is not None and receipt.get('pin_sha256')==_pin_sha(pin) and receipt.get('files')==stats
 except (util.Fail,OSError,ValueError,TypeError):return False

def require(value):
 p=folder(value)
 if not cached(value):raise util.Fail('Speech recognition needs its verified private model. Repair the video tools before editing; your footage is saved.')
 return p

def verify(path,pin):
 if not complete(path):return False
 for key,item in pin['files'].items():
  file=path/key
  if Path(key).name!=key or not file.is_file() or file.is_symlink() or file.stat().st_size!=item['size']:return False
  sha=hashlib.sha256() if item.get('sha256') else hashlib.sha1(b'blob '+str(item['size']).encode()+b'\0')
  with file.open('rb') as stream:
   for chunk in iter(lambda:stream.read(1024*1024),b''):sha.update(chunk)
  if sha.hexdigest()!=(item.get('sha256') or item.get('blob_id')):return False
 util.write_durable_json(path/'model-receipt.json',{'pin_sha256':_pin_sha(pin),'revision':pin['revision'],'files':_stats(path,pin),'verified_at':time.time()})
 return True

def _commit(temp,dest):
 recovery=dest.with_name(dest.name+'.recovery.'+str(time.time_ns())) if dest.exists() else None
 if recovery:dest.replace(recovery)
 try:temp.replace(dest)
 except OSError:
  if recovery and not dest.exists():recovery.replace(dest)
  raise

def install(value):
 value=name(value);dest=folder(value);pin=_pin(value)
 if dest.parent.is_symlink() or dest.is_symlink() or dest.with_name(dest.name+'.partial').is_symlink():raise util.Fail('The private speech model folder points elsewhere. Repair it before downloading.')
 with util.file_guard(dest.parent/'.download.guard',timeout=120):
  if cached(value):return dest
  if verify(dest,pin):return dest
  temp=dest.with_name(dest.name+'.partial');temp.mkdir(parents=True,exist_ok=True)
  # Import an old private/global cache during setup only, then verify it against the pinned publisher bytes.
  hub=Path(os.environ.get('HF_HOME',Path.home()/'.cache/huggingface'))/'hub'
  for repo in hub.glob('models--*faster-whisper-'+value):
   for old in (repo/'snapshots').glob('*'):
    if all((old/n).is_file() and (old/n).stat().st_size==pin['files'][n]['size'] for n in REQUIRED):
     for key in pin['files']:
      if (old/key).is_file():shutil.copy2(old/key,temp/key)
     if verify(temp,pin):_commit(temp,dest);return dest
  from faster_whisper.utils import download_model
  download_model(pin['repo'],revision=pin['revision'],output_dir=str(temp),cache_dir=str(util.KIT/'models/hub'),use_auth_token=False)
  if not verify(temp,pin):raise util.Fail('The speech model download did not verify. Run setup again; no unverified model will be used.')
  _commit(temp,dest);return dest
