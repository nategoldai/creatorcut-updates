"""Everything the Studio shows, as one JSON snapshot (GET /api/state)."""
from __future__ import annotations

import datetime as dt
import json
import time
import threading
from pathlib import Path

from . import events, util, activity_store

PROGRESS_JS = util.STUDIO_OUT / "progress.js"
BEAT_JS = util.STUDIO_OUT / "beat.js"
ACTIVITY = util.STUDIO_OUT / "activity.json"
BUNDLED_THUMBS = util.KIT / "studio" / "thumbs"

STEP_LABELS = {"python": "Private Python", "engine": "Video engine", "packages": "Editing tools",
               "motion": "Motion graphics", "vision": "Reference reading", "extras": "Fonts & sound effects", "model": "Speech recognition", "studio": "Your Studio"}

PIPELINE = [  # project status → (label, progress through the first edit)
    ("new", "Getting your clip ready", 0.05), ("transcribed", "Listening to every word", 0.25),
    ("planned", "Finding the best takes", 0.4), ("cut", "Designing captions and graphics", 0.6),
    ("previewed", "Preview ready", 1.0), ("finished", "Finished", 1.0),
]


def _js_payload(path: Path, prefix: str):
    try:
        txt = path.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    i = txt.find("=")
    if i < 0:
        return None
    body = txt[i + 1:].strip().rstrip(";")
    try:
        return json.loads(body)
    except ValueError:
        return None


def update_status() -> dict:
    from . import updater
    return updater.public_state(util.STUDIO_OUT/'update.json')


def install_status() -> dict:
    p = _js_payload(PROGRESS_JS, "window.AIE_PROGRESS") or {}
    beat = _js_payload(BEAT_JS, "window.AIE_BEAT")
    st = p.get("state") or ("done" if (util.ROOT / ".venv").exists() and util.BIN.exists() else "none")
    paused = st == "running" and (not beat or time.time() - float(beat) > 20)
    steps = []
    order = p.get("order") or ["python", "engine", "packages", "motion", "vision", "extras", "model", "studio"]
    for k in order:
        s = (p.get("steps") or {}).get(k, {})
        steps.append({"key": k, "label": STEP_LABELS.get(k, k), "state": s.get("state", "todo"),
                      "start": s.get("start", 0), "end": s.get("end", 0)})
    return {"state": "paused" if paused else st, "current": p.get("current", ""), "error": p.get("error"),
            "started": p.get("started"), "updated": p.get("updated"), "steps": steps,
            "percent": p.get("percent"), "eta": p.get("eta")}


_doctor_cache = {"t": 0.0, "v": None}
_doctor_lock = threading.Lock()
_doctor_running = False


def checks() -> dict:
    """Serve cached readiness immediately; diagnostics never block Studio state."""
    global _doctor_running
    now = time.time()
    if _doctor_cache['v'] is None:
        try:saved=util.read_json(util.STUDIO_OUT/'checks.json',default={})
        except (OSError,ValueError,util.Fail):saved={}
        if isinstance(saved,dict) and saved.get('checks'):
            _doctor_cache['v']=saved
    with _doctor_lock:
        start=not _doctor_running and now-_doctor_cache['t']>60
        if start:_doctor_running=True
    def refresh():
        global _doctor_running
        try:
            from . import setup
            value=setup.doctor()
            with _doctor_lock:_doctor_cache.update(t=time.time(),v=value)
        except Exception:
            util.log_exception('background readiness check')
            with _doctor_lock:_doctor_cache['t']=time.time()
        finally:
            with _doctor_lock:_doctor_running=False
    if start:
        try:threading.Thread(target=refresh,daemon=True,name='studio-readiness').start()
        except Exception:
            with _doctor_lock:
                _doctor_running=False
                _doctor_cache['t']=now
            util.log_exception('readiness thread start')
    return _doctor_cache['v'] or {'ready':False,'checks':[],'checking':True}


def media(path) -> str:
    """URL for a file inside the folder (the server's /media/ route)."""
    if not path:
        return ""
    p = Path(path)
    if not p.is_absolute():
        p = util.ROOT / p
    try:
        rel = p.resolve().relative_to(util.ROOT.resolve()).as_posix()
    except ValueError:
        return ""
    try:
        v = int(p.stat().st_mtime)
    except OSError:
        return ""
    from urllib.parse import quote
    return f"/media/{quote(rel)}?v={v}"


# ----------------------------------------------------------------- styles ----
def styles_list(prof: dict) -> list[dict]:
    from . import studio, styles as st
    rows = []
    learned = set(prof.get("learned_styles", []))
    for s in st.list_styles():
        if s.get("hidden") or s["origin"] != "yours":      # only presets the creator saved, never stock styles
            continue
        try:
            row = studio.style_row(s)
        except util.Fail:
            continue
        thumb = util.STUDIO_OUT / "assets" / "styles" / f"{s['id']}.jpg"
        if not thumb.exists():
            thumb = BUNDLED_THUMBS / f"{s['id']}.jpg"
        row["thumb"] = media(thumb) if thumb.exists() else ""
        row["preview"]["fonts"] = [media(util.ROOT / f) for f in row["preview"]["fonts"]]
        row["preview"]["heading_fonts"] = [media(util.ROOT / f) for f in row["preview"]["heading_fonts"]]
        row["yours"] = s["origin"] == "yours"
        saved = util.read_json(util.USER_STYLES_DIR/f"{s['id']}.json", default={})
        row["recipe_kind"] = (saved.get('recipe') or {}).get('kind', '')
        row["recipe_version"] = (saved.get('recipe') or {}).get('version')
        rb = util.USER_STYLES_DIR / f"{s['id']}.md"
        row["rulebook"] = rb.read_text(encoding="utf-8")[:6000] if rb.exists() else ""
        rv = util.PROJECTS / "_teach" / s["id"] / "reveal.json"
        if rv.exists():
            row["reveal"] = util.read_json(rv)
        ms = util.read_json(util.PROJECTS / "_teach" / s["id"] / "measurements.json", default={})
        first = next((t for t in ms.get("first_3s", []) if t), "")
        row["preview"]["sample"] = " ".join(first.replace(",", "").replace(".", "").split()[:8])
        row["learned"] = s["id"] in learned
        if row["yours"]:
            row.update(_preset_media(s["id"]))
        rows.append(row)
    rows.sort(key=lambda r: (not r["yours"], 0))
    return rows


def _kit_fonts(rows: list[dict], kit: dict) -> list[dict]:
    """The readout shows the fonts the style kit identified (letter by letter), not the older estimate."""
    sts = sorted((kit or {}).get("styles", {}).values(), key=lambda s: -s.get("count", 0))
    if not sts:
        return rows
    body = next((s for s in sts if s.get("colour_family") in ("white", "grey", "black")), sts[0])
    acc = next((s for s in sts if s.get("colour_family") not in ("white", "grey", "black")), None)
    def label(st):
        f = st["font"]
        return f"{f['family']} {f['weight']}{' italic' if f['italic'] else ''}"
    def row(lbl, st):
        f = st["font"]
        return {"group": "Captions", "label": lbl, "value": label(st), "bar": None, "font": util.slugify(f["family"] + "-" + str(f["weight"])),
                "font_file": f["file"], "font_url": media(util.ROOT / f["file"])}
    out = [r for r in rows if r["label"] not in ("Font", "Accent words")]
    extra = [row("Font", body)] + ([row("Accent words", acc)] if acc and acc["font"]["family"] != body["font"]["family"] else [])
    return extra + out


def _preset_media(sid: str) -> dict:
    """A preset's own pictures and measurements: the frames of the references it was saved from."""
    from . import teach
    used = []
    if teach.REFS.exists():
        for f in teach.REFS.glob("*/ref.json"):
            r = util.read_json(f, default={})
            if r.get("used_by") == sid:
                used.append(r)
    fdir = util.USER_STYLES_DIR / f"{sid}.frames"
    frames = sorted(fdir.glob("*.jpg")) if fdir.exists() else []
    if not frames:
        frames = [f for r in used for f in sorted((teach.REFS / r["id"] / "frames").glob("[0-9][0-9].jpg"))][:12]
    data = util.read_json(util.USER_STYLES_DIR / f"{sid}.json", default={})
    ids = [x.get("id") for x in data.get("references", [])] or [r["id"] for r in used]
    rows = _readout_for("p-" + sid, [teach.REFS / i / "measurements.json" for i in ids if i])
    for row in rows:
        if row.get("font_file") and not row.get("font_url"):
            row["font_url"] = media(util.FONTS_DIR / row["font_file"])
    rows = _kit_fonts(rows, data.get("kit"))
    sources = [{"title": x.get("title") or "", "url": x.get("url", "")} for x in data.get("references", [])] or \
              [{"title": r.get("title") or r.get("name", ""), "url": r.get("url", "")} for r in used]
    return {"frames": [media(f) for f in frames], "readout": rows, "sources": sources}


_readout_cache: dict = {}


def _readout_for(key: str, files: list[Path]) -> list[dict]:
    """The measured readout, recomputed only when a measurements file changes."""
    from . import refs
    stamp = tuple(f.stat().st_mtime if f.exists() else 0 for f in files)
    hit = _readout_cache.get(key)
    if hit and hit[0] == stamp:
        return hit[1]
    rows = refs.readout([util.read_json(f, default={}) for f in files if f.exists()])
    _readout_cache[key] = (stamp, rows)
    return rows


def _scan_video(r: dict) -> str:
    """A linked reference plays while it's being studied (the download is deleted once the analysis is done)."""
    from . import refs
    d = refs.DOWNLOADS / r["id"]
    f = next((x for x in sorted(d.glob("*.mp4")) if x.stat().st_size > 50_000), None) if d.exists() else None
    return media(f) if f else ""


def ref_row(r: dict) -> dict:
    """One reference as the Studio shows it: real frames, live analysis progress, then what was measured."""
    from . import jobs as jobsmod, teach
    if r.get("status") in ("queued", "fetching", "analysing"):          # the server owns the jobs: is it still working?
        live = r.get("job") and (jobsmod.get(r["job"]) or {}).get("state") in ("queued", "waiting", "running")
        quiet = time.time() - float(r.get("updated") or r.get("created") or 0)
        if not live and quiet > 240:
            from . import refs as _refs
            r = dict(r, status="error", message="The study stopped before it finished (the computer may have slept). Tap Try again.")
            try:
                _refs.save(r)
            except Exception:
                pass
    d = teach.REFS / r["id"]
    done = r["status"] == "done"
    j = jobsmod.get(r.get("job", "")) if r.get("job") and not done else None
    rows = _readout_for(r["id"], [d / "measurements.json"]) if done else []
    for row in rows:
        if row.get("font_file"):
            row["font_url"] = media(util.FONTS_DIR / row["font_file"])
    if done and (d / "kit.json").exists():
        rows = _kit_fonts(rows, util.read_json(d / "kit.json", default={}))
    return {"id": r["id"], "kind": r["kind"], "name": r.get("title") or r.get("name", ""), "url": r.get("url", ""),
            "host": (r.get("host") or "").replace("www.", ""), "status": r["status"], "message": r.get("message", ""),
            "progress": 1.0 if done else round(float((j or {}).get("progress") or 0), 3), "study_error": r.get('study_error',''),
            "thumb": media(r.get("thumb")) if r.get("thumb") else "",
            "frames": [media(f) for f in sorted((d / "frames").glob("[0-9][0-9].jpg"))[:14]] if (d / "frames").exists() else [],
            "video": media(util.ROOT / r["file"]) if r.get("kind") == "file" and r.get("file") and (util.ROOT / r["file"]).exists()
                     else _scan_video(r),
            "used_by": r.get("used_by", ""), "readout": rows, "cover_only": bool(r.get("cover_only"))}


def references() -> dict:
    """References added outside a video (onboarding), studied the same way."""
    from . import refs
    return {"items": [ref_row(r) for r in refs.all_refs()]}


# --------------------------------------------------------------- projects ----
def _find_say(say: str, words: list[dict], after: float = -1.0) -> float | None:
    target = [w.lower().strip(".,!?;:\"'") for w in say.split()]
    toks = [w["w"].lower().strip(".,!?;:\"' ") for w in words]
    for i in range(len(toks) - len(target) + 1):
        if words[i]["start"] > after and toks[i:i + len(target)] == target:
            return words[i]["start"]
    for i, t in enumerate(toks):
        if target and t == target[0] and words[i]["start"] > after:
            return words[i]["start"]
    return None


def _anchor(at, words: list[dict], after: float = -1.0) -> float | None:
    if isinstance(at, (int, float)):
        return float(at)
    if isinstance(at, dict) and isinstance(at.get("say"), str) and words:
        t = _find_say(at["say"], words, -1.0 if at.get("anywhere") else after)
        return None if t is None else t + float(at.get("offset", 0))
    return None


def _beat_span(b: dict, words: list[dict], duration: float, after: float) -> tuple[float, float] | None:
    """Approximate when a beat is on screen (the engine resolves it exactly at render time)."""
    start = _anchor(b.get("at"), words, after)
    if start is None and isinstance(b.get("items"), list) and b["items"]:
        first = b["items"][0]
        start = _anchor(first.get("at") if isinstance(first, dict) else None, words, after)
    if start is None and b.get("type") == "cta":
        start = max(0.0, duration - float(b.get("duration") or 3))
    if start is None:
        return None
    end = _anchor(b.get("until"), words, start) if b.get("until") else None
    if end is None:
        end = start + float(b.get("duration") or (4.0 if b.get("type") == "list" else 2.5))
    return start, min(max(end, start + 0.3), duration or end)


def timeline(p: Path, cfg: dict) -> dict | None:
    """Kept/cut segments on the source timeline, caption chunks and graphic beats on the edited timeline."""
    src = util.read_json(p / "source.json", default={})
    segs = util.read_json(p / "segments.json", default={"segments": []})["segments"]
    wj = util.read_json(p / "words.json", default={})
    if not segs and not wj:
        return None
    words = wj.get("words", [])
    out = {"source_duration": round(src.get("duration", 0), 3), "duration": round(wj.get("duration", 0), 3),
           "segments": [{"src_start": round(s["src_start"], 3), "src_end": round(s["src_end"], 3),
                         "start": s["start"], "end": s["end"]} for s in segs],
           "captions": [], "beats": []}
    try:
        from . import captions, styles as st
        style = st.for_project(cfg)
        cap = dict(style["captions"])
        cap.update(cfg.get("captions") or {})
        for ch in captions.chunk_words(words, int(cap["max_words"]), int(cap["max_chars"])):
            out["captions"].append({"start": ch[0]["start"], "end": ch[-1]["end"],
                                    "text": " ".join(w["w"].strip() for w in ch), "first": words.index(ch[0])})
    except Exception:
        pass
    beats = util.read_json(p / "beats.json", default={"beats": []}).get("beats", [])
    after = -1.0
    for b in beats:
        span = _beat_span(b, words, out["duration"], after)
        if span is None:
            continue
        after = span[0]
        items = b.get("items")
        label = b.get("text") or b.get("title") or b.get("label") or (items[0] if isinstance(items, list) and items else "")
        if isinstance(label, dict):
            label = label.get("text", "")
        if b.get("type") == "counter" and b.get("value") is not None:
            label = f"{b.get('prefix', '')}{b['value']}{b.get('suffix', '')}"
        out["beats"].append({"type": b.get("type", ""), "start": round(span[0], 3), "end": round(span[1], 3),
                             "label": str(label or b.get("type", ""))[:40]})
    return out


def _poster(p: Path, cfg: dict) -> str:
    from . import thumbnails
    candidates = []
    from . import videos
    vs=videos.versions(p.name)
    if vs:
        latest=vs[-1]
        if latest.get('poster'):
            poster=media(util.ROOT/latest['poster'])
            if poster:return poster
        if latest.get('file'):candidates.append(util.ROOT/latest['file'])
    if cfg.get('latest'):candidates.append(util.ROOT/cfg['latest'])
    candidates.append(p/'preview.mp4')
    saved=any(f.is_file() for f in candidates)
    if not saved:candidates.extend(util.ROOT/m['file'] for m in cfg.get('media',[]) if m.get('kind')=='raw' and m.get('file'))
    for candidate in candidates:
        frame = thumbnails.cached(candidate)
        if frame:
            return media(frame)
    if cfg.get("latest"):
        f = util.STUDIO_OUT / "assets" / "posters" / (Path(cfg["latest"]).stem + ".jpg")
        if f.exists():
            return media(f)
    for f in (p / "render" / "poster.jpg",):
        if f.exists():
            return media(f)
    if saved:return '' # A raw source frame must not impersonate the saved edit.
    for item in cfg.get('media', []):
        if item.get('kind') == 'raw':
            for key in ('hero', 'thumb'):
                frame = util.ROOT / item[key] if item.get(key) else None
                if frame and frame.exists():
                    return media(frame)
    return ""


def _media_thumb(item: dict) -> str:
    from . import thumbnails
    frame=util.ROOT/item['thumb'] if item.get('thumb') else None
    if frame and frame.is_file():return media(frame)
    source=util.ROOT/item['file'] if item.get('file') else None
    if source and source.suffix.lower() in util.VIDEO_EXT:
        frame=thumbnails.cached(source)
        if frame:return media(frame)
    return ''


def _chat(pid: str) -> list[dict]:
    from . import videos
    try:
        return videos.chat(pid)[-80:]
    except util.Fail:
        return []


def _versions(pid: str) -> list[dict]:
    from . import videos
    try:
        from . import annotations,thumbnails
        result=[]
        for v in videos.versions(pid):
            p=util.PROJECTS/pid;cache=annotations.strip_cache(p,v) or {}
            poster=media(util.ROOT/v['poster']) if v.get('poster') else ''
            if not poster:
                frame=thumbnails.cached(util.ROOT/v['file'])
                poster=media(frame) if frame else ''
            result.append(dict(v,strip=[media(p/'versions'/f"v{v['n']}.frames"/f) for f in cache.get('frames',[])],url=media(util.ROOT/v['file']),poster=poster))
        return result
    except util.Fail:
        return []


def _activity(project=None) -> dict:
    from . import activity_store
    a = activity_store.latest(project)
    if not a:
        a = util.read_json(ACTIVITY, default={})
        if project is not None and a.get('project') != project: a = {}
    if a and a.get('running'):
        try:
            import os
            pid = int(a.get('pid') or 0)
            if pid <= 0:
                raise ValueError('No individual worker PID was recorded')
            if not util.process_alive(pid):raise ProcessLookupError()
        except (OSError, ValueError):
            a['running'] = False
            a['interrupted'] = True
        if time.time() - a.get('updated', 0) > 900:
            a['quiet'] = True  # an alive process is not proof of advancing work
    return a



def progress_health(pid: str, activity: dict, jobs_list: list[dict], now=None, workflow=None) -> dict:
    now = time.time() if now is None else now
    wf = workflow or {}
    resumed = float(wf.get('updated') or 0) if wf.get('owner') and wf.get('phase') in {'analysing','planning','building','reviewing'} and wf.get('lease_until', 0) > now else 0
    if resumed and activity.get('project') == pid and not activity.get('running') and float(activity.get('updated') or 0) < resumed:
        activity = {}  # A previous failed command is not the newly claimed step.
    if activity.get('project') == pid and (activity.get('error') or activity.get('interrupted')):
        return {'state':'error','message':activity.get('error') or 'This worker stopped before reporting completion. Your files are kept; ask the editor to check and resume this step.'}
    relevant = [j for j in jobs_list if j.get('key') == pid and j.get('state') in {'queued','waiting','running','error'}
                and not (resumed and j.get('state') == 'error' and float(j.get('updated') or 0) < resumed)]
    if activity.get('project') == pid and activity.get('running') and activity.get('waiting_resources'):
        return {'state':'waiting_resources', 'message':'Waiting for video resources. Another heavy step is running; this video will continue automatically.'}
    if activity.get('project') == pid and activity.get('running'):
        age = max(0, now-float(activity.get('last_output') or activity.get('updated') or now))
        if age>120 and now-float(activity.get('heartbeat') or 0)<25:
            return {'state':'waiting_progress','seconds_since_progress':round(age),'message':'The rendering process is still running. No new frame count has been reported yet.'}
        return {'state':'quiet' if age > 120 else 'working', 'seconds_since_progress':round(age),
                'message':f'No new progress reported for {round(age)} seconds. The step needs checking; its last percentage is not a live measurement.' if age > 120 else ''}
    # A child may outlive a Studio-server crash. Its later confirmed completion
    # supersedes only the restart marker, never a genuine newer job failure.
    if activity.get('project') == pid and not activity.get('running') and not activity.get('error') and not activity.get('interrupted'):
        relevant = [j for j in relevant if not (j.get('state') == 'error' and j.get('interrupted') and float(j.get('updated') or 0) < float(activity.get('updated') or 0))]
    if relevant:
        j=max(relevant,key=lambda j:j.get('updated',0))
        if j.get('state') == 'error':
            return {'state':'error','message':j.get('message') or 'This step failed. Your source files are kept.'}
        age=max(0,now-float(j.get('progress_at') or j.get('updated') or now))
        return {'state':'quiet' if age > 120 else j['state'], 'seconds_since_progress':round(age),
                'message':f'No new progress reported for {round(age)} seconds. The step needs checking.' if age > 120 else ''}
    if resumed:
        age = max(0, now - resumed)
        return {'state':'quiet' if age > 120 else 'working', 'seconds_since_progress':round(age),
                'message':'No new editing activity has been reported. This step needs checking.' if age > 120 else ''}
    return {'state':'idle','message':''}

def projects() -> list[dict]:
    from . import jobs as jobsmod, refs as refs_mod
    out = []
    running_jobs = {(j.get("key"), j["kind"]): j for j in jobsmod.all_jobs() if j["state"] in ("queued", "running", "waiting")}
    for f in sorted(util.PROJECTS.glob("*/project.json"), key=lambda x: x.stat().st_mtime, reverse=True):
        p = f.parent
        cfg = {}
        try:
            act = _activity(p.name)
            if p.name.startswith("_"):
                continue
            try:
                cfg = util.read_json(f)
            except util.Fail:
                continue
            from . import workflow
            wf = workflow.state(p)
            from . import editor, edit_progress
            editor_job = editor.public(p.name)
            measured_edit = edit_progress.measure(p, editor_job, act)
            status = cfg.get("status", "new")
            stage = next(((lbl, pr) for k, lbl, pr in PIPELINE if k == status), ("Working", 0.1))
            busy = None
            if act.get("running") and act.get("project") == p.name:
                busy = {"label": act.get("label", "Working…"), "progress": act.get("progress")}
            for kind in ("preview", "render", "versions", "compare", "cover"):
                j = running_jobs.get((p.name, kind))
                if j:
                    busy = {"label": j["message"], "progress": j["progress"], "job": j["id"], "kind": kind}
            preview = p / "preview.mp4"
            src = util.read_json(p / "source.json", default={})
            caps = dict(cfg.get("captions") or {})
            try:
                from . import styles as st
                style = st.for_project(cfg)
                caps_full = dict(style["captions"], **caps)
            except Exception:
                style, caps_full = {"grade": "natural", "sfx": {}}, caps
            out.append({
                "name": p.name, "editor_job": editor_job, "edit_progress": measured_edit, "status": status, "activity": act, "workflow": wf, "progress_health": progress_health(p.name, act, jobsmod.all_jobs(), workflow=wf), "stage": stage[0], "stage_progress": stage[1], "busy": busy,
                "source": cfg.get("source", ""), "source_duration": round(src.get("duration", 0), 1),
                "created": cfg.get("created", ""), "parent": cfg.get("parent"),
                "preview": media(preview) if preview.exists() else "",
                "poster": _poster(p, cfg),
                "contact_sheet": media(p / "render" / "contact-sheet.jpg") if (p / "render" / "contact-sheet.jpg").exists() else "",
                "latest": media(util.ROOT / cfg["latest"]) if cfg.get("latest") and (util.ROOT / cfg["latest"]).exists() else "",
                "settings": {
                    "library_choices": cfg.get("library_choices", {}),
                    "preset_library_choices": cfg.get("preset_library_choices", {}),
                    "style": cfg.get("style"), "platform": cfg.get("platform"), "look": cfg.get("look") or "natural",
                    "grade": cfg.get("grade") or style.get("grade", "natural"),
                    "caption_size": caps_full.get("size"), "caption_y": caps_full.get("y"),
                    "caption_mode": caps_full.get("mode"), "captions_on": caps_full.get("enabled", True),
                    "uppercase": caps_full.get("uppercase", False),
                    "music_selection": cfg.get("music_selection"), "music": cfg.get("music", "auto"), "music_volume": cfg.get("music_volume", style.get("music", {}).get("volume", 0.16)),
                    "sfx_on": cfg.get("sfx", True),
                    "sfx_volume": (cfg.get("overrides") or {}).get("sfx", {}).get("volume", style.get("sfx", {}).get("volume", 0.32)),
                    "zoom_on": cfg.get("zoom", True), "progress_bar": cfg.get("progress_bar", style.get("progress_bar", False)),
                    "voice_cleanup": cfg.get("voice_cleanup", False), "custom_grade": bool(style.get("grade_filter")),
                },
                "timeline": timeline(p, cfg),
                "updated": f.stat().st_mtime,
                "title": cfg.get("title") or p.name.replace("-", " ").capitalize(),
                "studio": bool(cfg.get("studio")),
                "brief": dict(cfg.get("brief", {}), reference_meta=[dict(m, thumb_url=media(util.ROOT / m["thumb"]) if m.get("thumb") else "")
                                                                   for m in cfg.get("brief", {}).get("reference_meta", [])]),
                "media": [dict(m, url=media(util.ROOT / m["file"]), thumb=_media_thumb(m),
                               hero=media(util.ROOT / m["hero"]) if m.get("hero") else "",
                               strip=[media(util.ROOT / f) for f in m.get("strip", [])])
                          for m in cfg.get("media", [])],
                "studio_step": cfg.get("studio_step", ""),
                "preparation": cfg.get("preparation", {}),
                "refs": [ref_row(r) for r in refs_mod.for_project(p.name)],
                "generated_at": cfg.get("generated_at"),
                "download": media(util.ROOT / cfg["latest"]) if cfg.get("latest") and (util.ROOT / cfg["latest"]).exists() else "",
                "chat": _chat(p.name),
                "versions": _versions(p.name),
                "annotations": __import__("editkit.annotations",fromlist=["read"]).read(p.name)["notes"],
                "source_url": media(Path(src["path"])) if src.get("path") and Path(src["path"]).exists() else "",
            })
        except (util.Fail, OSError, ValueError, TypeError, KeyError, AttributeError):
            util.log_exception('Studio project metadata: '+p.name)
            title=cfg.get('title') if isinstance(cfg,dict) else None
            out.append({'name':p.name,'title':title or p.name,'status':'metadata_error','metadata_issue':'This project has unreadable editing metadata. Your files are kept; other projects are still available.',
                        'progress_health':{'state':'error','message':'This project needs a metadata check. Your original files are saved.'},'settings':{},'brief':{},'media':[],'refs':[],'versions':[],'annotations':[],'workflow':{},'activity':{},'stage':'Needs attention','busy':None,'preview':'','latest':'','parent':cfg.get('parent') if isinstance(cfg,dict) else None})

    return out


# ---------------------------------------------------------------- library ----
def library() -> list[dict]:
    from . import studio
    vids = []
    finished = sorted(util.FINISHED.glob("*.mp4"), key=lambda x: x.stat().st_mtime, reverse=True) if util.FINISHED.exists() else []
    for f in finished:
        stem = f.stem
        post = next((x for x in util.FINISHED.glob("*-post.json") if stem.startswith(x.stem[:-5])), None)
        cover = next((x for x in util.FINISHED.glob("*-cover.jpg") if stem.startswith(x.stem[:-6])), None)
        from . import thumbnails
        poster = thumbnails.cached(f)
        project = next((p.parent.name for p in util.PROJECTS.glob("*/project.json")
                        if not p.parent.name.startswith("_") and stem.startswith(p.parent.name + "-")), None)
        kind = "tour" if "style-tour" in stem else "compare" if "before-after" in stem else "edit"
        vids.append({"file": media(f), "name": stem, "kind": kind, "project": project,
                     "date": dt.datetime.fromtimestamp(f.stat().st_mtime).strftime("%-d %b, %H:%M")
                     if util.os_name() != "windows" else dt.datetime.fromtimestamp(f.stat().st_mtime).strftime("%d %b, %H:%M"),
                     "size_mb": round(f.stat().st_size / 1e6, 1),
                     "post": util.read_json(post) if post else None,
                     "cover": media(cover) if cover else "", "poster": media(poster) if poster else "",
                     "path": util.rel(f)})
    return vids


def raw_waiting() -> list[dict]:
    if not util.RAW.exists():
        return []
    used = set()
    for f in util.PROJECTS.glob("*/project.json"):
        try:
            used.add(util.read_json(f).get("source"))
        except util.Fail:
            pass
    return [{"name": p.name, "size_mb": round(p.stat().st_size / 1e6, 1), "url": media(p)}
            for p in sorted(util.RAW.iterdir(), key=lambda x: x.stat().st_mtime, reverse=True)
            if p.suffix.lower() in util.VIDEO_EXT and p.name not in used]


def stats() -> dict:
    """Time saved and work done, for the Home dashboard."""
    cuts = words = videos_n = 0
    saved = 0.0
    for f in util.PROJECTS.glob("*/segments.json"):
        p = f.parent
        if p.name.startswith("_"):
            continue
        segs = util.read_json(f, default={"segments": []})["segments"]
        cuts += max(0, len(segs) - 1)
        wj = util.read_json(p / "words.json", default={"words": []})
        words += len(wj.get("words", []))
        if (util.read_json(p / "project.json", default={}).get("latest")):
            videos_n += 1
        dur = wj.get("duration", 0)
        saved += 45 * 60 * max(0.5, dur / 60)      # a pro edit of a short takes ~45 min per minute of output
    return {"cuts": cuts, "words": words, "videos": videos_n, "minutes_saved": round(saved / 60)}


def music_library() -> list[dict]:
    out = []
    lib = util.KIT / "music"
    for f in sorted(lib.glob("*.m4a")) if lib.exists() else []:
        out.append({"id": "library:" + f.stem, "name": f.stem.replace("-", " ").capitalize(), "url": media(f), "kind": "library"})
    for f in sorted(util.MUSIC.glob("*")) if util.MUSIC.exists() else []:
        if f.suffix.lower() in util.AUDIO_EXT:
            out.append({"id": f.name, "name": f.stem, "url": media(f), "kind": "yours"})
    return out


_storage_cache = {"t": 0.0, "v": {}, "root":None}
_storage_lock=__import__('threading').Lock()

def storage() -> dict:
    """Disk free is cheap/live. Folder sizes never block the first app snapshot."""
    import shutil,threading
    root,projects_dir,finished_dir=util.ROOT,util.PROJECTS,util.FINISHED
    same=_storage_cache['root']==root
    value=dict(_storage_cache['v']) if same else {'projects_mb':None,'finished_mb':None}
    try:
        free=shutil.disk_usage(root).free;value.update(free_gb=round(free/1e9,1),free_bytes=free)
    except OSError:value['free_gb']=None
    if same and time.monotonic()-_storage_cache['t']<60:return dict(value,checking=False)
    if _storage_lock.acquire(blocking=False):
        def scan():
            try:
                def size(folder):
                    total=0
                    for file in folder.rglob('*'):
                        try:
                            if file.is_file():total+=file.stat().st_size
                        except OSError:continue
                    return total
                measured={'projects_mb':round(size(projects_dir)/1e6),'finished_mb':round(size(finished_dir)/1e6)}
                _storage_cache.update(t=time.monotonic(),v=measured,root=root)
            except OSError:pass
            finally:_storage_lock.release()
        try:threading.Thread(target=scan,name='creatorcut-storage-measurement',daemon=True).start()
        except RuntimeError:_storage_lock.release()
    return dict(value,checking=True)


def profile_public(prof: dict) -> dict:
    keys = ("website", "about", "audience", "memory", "name", "handle", "platform", "style", "favourites", "cta", "language", "vocabulary", "onboarding",
            "agent", "music", "learned_styles")
    out = {k: prof.get(k) for k in keys if k in prof}
    out["accent"] = prof.get("brand", {}).get("accent", "")
    if isinstance(out.get("website"), dict) and out["website"].get("thumb"):
        out["website"] = dict(out["website"], thumb_url=media(util.ROOT / out["website"]["thumb"]))
    return out


@activity_store.consistent_snapshot
def snapshot() -> dict:
    from . import videos as videos_mod
    from . import jobs, studio
    issues = []
    def safe(label, fn, fallback):
        try: return fn()
        except (util.Fail, OSError, ValueError, TypeError, KeyError):
            util.log_exception('Studio metadata: '+label)
            issues.append(label+' could not be read. Your files were kept. Ask your editor to check it before editing.')
            return fallback
    prof = safe('Settings', util.load_profile, {'onboarding': {'done': True}})
    inst = install_status()
    return {
        "readiness": __import__("editkit.readiness",fromlist=["status"]).status(),
        "data_issues": issues,
        "time": time.time(),
        "conversation_mode": "persistent_editor",
        "editor": __import__("editkit.editor",fromlist=["status"]).status(),
        "native_receiver": __import__('editkit.native_actions', fromlist=['BROKER']).BROKER.status(),
        "learning_progress": safe("Learning progress", lambda: __import__("editkit.learn", fromlist=["progress"]).progress(), {"unavailable": True}),
        "version": (util.KIT / "VERSION").read_text().strip() if (util.KIT / "VERSION").exists() else "",
        "os": util.os_name(),
        "install": inst,
        "checks": checks() if inst["state"] in ("done", "none") else {"ready": False, "checks": []},
        "profile": profile_public(prof),
        "styles": safe("Presets", lambda: styles_list(prof), []),
        "references": safe('References', references, []),
        "projects": safe("Projects", projects, []),
        "library": safe('Video library', library, []),
        "raw": safe('Raw footage', raw_waiting, []),
        "jobs": jobs.all_jobs(),
        "listening": events.listening(),
        "pending": len(events.pending()),
        "activity": _activity(),
        "phrases": studio.PHRASES,
        "your_frame": media(util.STUDIO_OUT / "assets" / "your-frame.jpg") if (util.STUDIO_OUT / "assets" / "your-frame.jpg").exists() else "",
        "last_event": events.last_id(),
        "updates": videos_mod.updates(),
        "stats": safe('Activity counts', stats, {}),
        "music_library": safe('Music', music_library, []),
        "storage": storage(),
        "update": safe('Updates', update_status, {}),
        "learned": safe("Editing memory", lambda: __import__("editkit.learn", fromlist=["public"]).public(), {"creator": [], "presets": {}}),
    }
