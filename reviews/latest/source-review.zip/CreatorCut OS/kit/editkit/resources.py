"""One memory-heavy operation at a time per installation, across native sessions.
Kernel locks release on process death; waiting is visible and never fake rendering.
"""
import contextvars, functools, os, time
from contextlib import contextmanager
from . import util, activity_store
_depth = contextvars.ContextVar('creatorcut_resource_depth', default=0)
_fd = contextvars.ContextVar('creatorcut_resource_fd', default=None)

def inherited_fds():
    fd = _fd.get()
    return () if fd is None else (fd,)

@contextmanager
def heavy(label='Processing video', timeout=21600):
    if _depth.get():
        yield
        return
    deadline = time.monotonic() + timeout
    announced = False
    last_notice = 0.0
    while True:
        guard = util.file_guard(util.STUDIO_OUT / '.heavy.guard', 'Another video is using the render resources.')
        try: stream = guard.__enter__()
        except util.LockBusy:
            if time.monotonic() >= deadline:
                activity_store.update(waiting_resources=False)
                raise util.Fail('Another video is using the editor. This step has paused safely.', 'Wait for the current step, then retry this saved step; do not create another editor.')
            holder=util.read_json(util.STUDIO_OUT/'heavy-holder.json',default={})
            blocker=holder.get('label') or 'the current video step'
            if not announced:
                util.step('Waiting for '+blocker+'. Your project is safely in line.')
                announced = True
            if time.monotonic() - last_notice >= 10:
                util.say('Waiting for '+blocker+'.')
                last_notice = time.monotonic()
            activity_store.update(waiting_resources=True, queue_checked_at=time.time(), percent=None, blocker=blocker, detail='Waiting for '+blocker)
            time.sleep(.25)
            continue
        break
    record=util.read_json(activity_store._current.get(),default={}) if activity_store._current.get() else {}
    util.write_json(util.STUDIO_OUT/'heavy-holder.json',{'pid':os.getpid(),'project':record.get('project'),'label':label+(' for '+str(record['project']) if record.get('project') else ''),'started':time.time()})
    token = _depth.set(1)
    fd_token = _fd.set(stream.fileno())
    try:
        activity_store.update(waiting_resources=False, detail=label, percent=None, started=time.time())
        yield
    finally:
        _fd.reset(fd_token)
        _depth.reset(token)
        guard.__exit__(None,None,None)

def serialized(fn):
    @functools.wraps(fn)
    def wrapped(*args, **kwargs):
        with heavy(): return fn(*args, **kwargs)
    return wrapped


def reference_work(fn):
    """Serialize scans separately; foreground speech/cut work has its own slot."""
    @functools.wraps(fn)
    def wrapped(*args, **kwargs):
        try: os.nice(8)
        except (OSError,AttributeError): pass
        with util.file_guard(util.STUDIO_OUT/'.reference-heavy.guard', timeout=21600):
            return fn(*args, **kwargs)
    return wrapped
