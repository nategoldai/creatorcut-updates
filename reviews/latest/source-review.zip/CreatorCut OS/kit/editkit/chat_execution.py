"""Visible-conversation execution. Durable requests; no model, provider or daemon launch."""
import os,secrets,time
from . import util

def mode():
 from . import editor
 policy=util.read_json(util.ROOT/'kit/execution-policy.json',default={})
 value=editor.config().get('editor_mode',policy.get('default_editor_mode','managed'))
 if value not in ('chat','managed'):raise util.Fail('The saved editor mode is invalid. Choose chat or managed.')
 return value

def configure(value):
 from . import editor,activity_store
 if value not in ('chat','managed'):raise util.Fail('Choose chat or managed editing.')
 with util.file_guard(editor.control()/'configuration.guard',timeout=5):
  if any(editor.read(pid).get('state') in editor.ACTIVE for pid in editor.all_projects()) or any(row.get('running') for row in activity_store.records()):
   raise util.Fail('Finish or stop your current edit before changing its editing connection.')
  worker=editor.safe_json(editor.control()/'worker.json')
  if value=='chat' and editor.same_process(worker.get('pid'),worker.get('birth')):
   raise util.Fail('Close the managed editor service before switching this installation to chat mode.')
  cfg=editor.config();cfg['editor_mode']=value;util.write_durable_json(editor.root()/'config.json',cfg)
 return {'mode':value,'changed':True,'starts_editor':False}

def message(pid,rid,update=False,token=None):
 from . import videos
 title=str(videos.load(pid).get('title') or pid).replace('\n',' ')[:70]
 text=('CreatorCut: '+('update' if update else 'make')+' my video "'+title+'"\n'
         '(project '+pid+', request '+rid+', delivery '+str(token or '')+') — read it with edit.py studio context '+pid+
         ', claim it with edit.py workflow claim '+pid+' --request '+rid+(' --delivery '+token if token else '')+
         ' --owner YOUR_CONVERSATION_ID, then edit it in this chat with the CreatorCut edit skill.')
 if len(text)>499:
  text=('CreatorCut: '+('update' if update else 'make')+' my video "'+title[:30]+'"\n'
        'project='+pid+' request='+rid+' delivery='+str(token or '')+'; read edit.py studio context "$project"; claim edit.py workflow claim "$project" --request "$request" --delivery "$delivery" --owner YOUR_CONVERSATION_ID; then edit here with the CreatorCut edit skill.')
 return text

def response(job,deliver=False):
 return {'accepted':True,'project':job['project'],'request_id':job['request_id'],'job':job['id'],'state':job['state'],'state_seq':job.get('state_seq',0),'updated':job['updated'],'message':job['message'],'transport':'native_chat','deliver':deliver,'native_message':job['native_message'],'delivery_state':job.get('delivery_state','unknown'),'delivery_id':job.get('delivery_id',job['request_id']),'delivery_token':job.get('delivery_token'),'delivery_generation':job.get('delivery_generation',0),'foreground_queued':job.get('native_transport')=='foreground'}

def reserve(pid,rid,transport="foreground"):
 from . import editor,videos,requests
 p=videos._dir(pid)
 from . import readiness
 if readiness.status().get('state') in ('checking','repair'):raise util.Fail('Your editing tools are still being prepared. Your footage and choices are saved.','Finish setup or check the tools again, then make this video.')
 if transport not in ('foreground','mcp'):raise util.Fail('Unsupported native editing connection.')
 import shutil
 if shutil.disk_usage(p).free<2_500_000_000:raise util.Fail('Free at least 2.5 GB before editing. Your footage and settings are saved.')
 with util.file_guard(p/'.request.guard',timeout=5),util.file_guard(p/'.editor-job.guard',timeout=5):
  request=requests.active(p)
  if not request or request['id']!=rid:raise util.Fail('Save the current video settings before starting this edit.')
  old=editor.read(pid)
  if old.get('request_id')==rid:
   if old.get('execution_mode')!='chat':raise util.Fail('This request already belongs to another editing connection.')
   return response(old)
  if old.get('state') in editor.ACTIVE:raise util.Fail('This video already has an editor. Your new settings are saved.')
  now=time.time();job={'schema':1,'id':secrets.token_hex(16),'project':pid,'request_id':rid,'execution_mode':'chat','state':'queued','message':'Waiting for your chat to receive this edit','created':now,'updated':now,'activity_at':now,'attempts':0,'provider':'native','previous_version':max((v['n'] for v in videos.versions(pid)),default=0),'delivery_state':'reserved','native_message':message(pid,rid,bool(request.get('batch')))}
  _new_delivery(job,transport)
  if transport=='foreground':
   from .native_actions import BROKER
   if not BROKER.status().get('connected'):job['delivery_state']='unavailable'
  editor.store_job(pid,job)
  # Only the first reservation authorizes a send. Lost replies never authorize another.
  return response(job,deliver=transport=="mcp")

def delivery(pid,rid,outcome,token=None):
 from . import editor,videos
 if outcome not in ('delivered','unconfirmed','unavailable'):raise util.Fail('Invalid conversation delivery result.')
 p=videos._dir(pid)
 with util.file_guard(p/'.editor-job.guard',timeout=5):
  job=editor.read(pid)
  if job.get('execution_mode')!='chat' or job.get('request_id')!=rid:raise util.Fail('This delivery belongs to a different edit.')
  if token is not None and token!=job.get('delivery_token'):return response(job)
  if job.get('state')!='queued':return response(job)
  if job.get('delivery_state')=='delivered':return response(job)
  job.update(delivery_state=outcome,message='Waiting for your chat to start the saved edit' if outcome=='delivered' else 'Open your connected editing chat to start this saved edit' if outcome=='unavailable' else 'Delivery is unconfirmed. Check your chat before resending.',updated=time.time());editor.store_job(pid,job)
  return response(job)

def claim(p,request_id,owner,delivery_token=None):
 from . import editor,requests
 with util.file_guard(p/'.request.guard',timeout=5),util.file_guard(p/'.editor-job.guard',timeout=5):
  job=editor.read(p.name);request=requests.active(p)
  if job.get('execution_mode')!='chat':raise util.Fail('This request is not assigned to visible-chat editing.')
  if not request_id or request.get('id')!=request_id or job.get('request_id')!=request_id:raise util.Fail('Claim the exact saved video request; a different request cannot start.')
  if job.get('delivery_token') and delivery_token!=job['delivery_token']:raise util.Fail('This delivery was replaced. Read the newest saved request; this older message cannot start editing.')
  if job.get('cancel') or job.get('state') in editor.TERMINAL:raise util.Fail('This saved edit has stopped or finished. Do not start another writer.')
  conversation=os.environ.get('CODEX_THREAD_ID') or os.environ.get('CLAUDE_SESSION_ID') or owner
  if job.get('delivered_to') and conversation!=job['delivered_to']:raise util.Fail('This request was delivered to another conversation.')
  if job.get('claimed_owner') and job['claimed_owner']!=conversation:raise util.Fail('Another conversation already claimed this edit.')
  job.update(state='editing',claimed_delivery=job.get('delivery_token'),claimed_owner=conversation,activity_at=time.time(),updated=time.time(),message='Editing in your conversation');editor.store_job(p.name,job)
  return job

def reconcile(pid):
 from . import editor
 job=editor.read(pid)
 if job.get('execution_mode')!='chat':return
 if job.get('state')=='succeeded':return
 version=editor.published(job)
 if version:editor.finish_success(job,version)

def status(pid):
 from . import editor
 job=editor.read(pid)
 if job.get('execution_mode')!='chat':return None
 if job.get('cancel') and job.get('state') not in editor.TERMINAL:
  # Cancellation can arrive during a render. Finish stopping once that owned
  # command exits; a dead chat must not leave this video marked editing forever.
  editor.cancel(pid);job=editor.read(pid)
 result={k:job[k] for k in ('id','state_seq','state','message','created','updated','activity_at','request_id','version','delivery_state','execution_mode','native_message','delivery_token','delivery_id','delivery_expires_at') if k in job}
 if job.get('state')=='queued' and job.get('delivery_expires_at',float('inf'))<time.time():
  result.update(native_saved=True,message='Waiting for your chat to start…')
 if job.get('state')=='editing':
  from . import activity_store
  work=activity_store.latest(pid);last=max(float(job.get('activity_at',0)),float(work.get('progress_at',0)))
  result['last_update_seconds']=max(0,int(time.time()-last))
  if time.time()-last>600:result.update(stalled=True,message="Your chat hasn't reported work for 10 minutes. Open it to continue. Your edit is saved.")
 if job.get('state')=='queued':
  queue=sorted((editor.read(pid) for pid in editor.all_projects()),key=lambda row:row.get('created',0))
  ahead=sum(1 for row in queue if row.get('execution_mode')=='chat' and row.get('id')!=job.get('id') and not row.get('cancel') and (row.get('state')=='editing' or row.get('state')=='queued' and row.get('created',0)<job.get('created',0)))
  result['queue_position']=ahead+1
 return result


def _new_delivery(job,transport):
 token=secrets.token_hex(16);now=time.time()
 job.update(delivery_token=token,delivery_id=job['request_id']+':'+token,
            delivery_generation=job.get('delivery_generation',0)+1,native_transport=transport,
            delivery_state='reserved',delivery_started_at=now,delivery_expires_at=now+90)
 job['native_message']=message(job['project'],job['request_id'],job.get('previous_version',0)>0,token)
 job.pop('delivered_to',None)

def resend(pid,transport='foreground'):
 from . import editor,videos
 p=videos._dir(pid)
 with util.file_guard(p/'.request.guard',timeout=5),util.file_guard(p/'.editor-job.guard',timeout=5):
  job=editor.read(pid)
  if job.get('execution_mode')!='chat' or job.get('state')!='queued' or job.get('claimed_owner') or job.get('cancel'):
   raise util.Fail('This edit has already started or stopped. Continue it in the owning conversation.')
  if transport not in ('foreground','mcp'):raise util.Fail('Unsupported native editing connection.')
  if job.get('delivery_state')!='unavailable' and time.time()<job.get('delivery_expires_at',float('inf')):
   return response(job)
  _new_delivery(job,transport);job.update(message='Saved. Open your CreatorCut chat to start.',updated=time.time())
  editor.store_job(pid,job);return response(job,deliver=transport=='mcp')

def validate_receiver(receiver):
 from . import editor
 for pid in editor.all_projects():
  job=editor.read(pid)
  if job.get('execution_mode')=='chat' and job.get('state')=='editing' and job.get('delivered_to') and job.get('delivered_to')!=receiver:
   raise util.Fail('Another CreatorCut chat is editing for this installation. Use the paste card in a second chat for a separate video.')

def take_pending(receiver):
 from . import editor
 if mode()!='chat':return None
 validate_receiver(receiver)
 # A receiver handles one project at a time, including the delivery-to-claim gap.
 for pid in editor.all_projects():
  active=editor.read(pid)
  if active.get('execution_mode')=='chat' and not active.get('cancel') and ((active.get('state')=='editing' and active.get('claimed_owner')==receiver) or (active.get('state')=='queued' and active.get('delivered_to')==receiver and active.get('delivery_state') in ('sent','delivered'))):return None
 rows=[]
 for pid in editor.all_projects():
  try:
   row=editor.read(pid)
   if (row.get('execution_mode')=='chat' and row.get('state')=='queued' and not row.get('cancel')
       and row.get('native_transport')=='foreground' and row.get('delivery_state') in ('reserved','unavailable')):rows.append(row)
  except (OSError,util.Fail):continue
 for row in sorted(rows,key=lambda x:x.get('created',0)):
  p=util.PROJECTS/row['project']
  with util.file_guard(p/'.editor-job.guard',timeout=1):
   job=editor.read(row['project'])
   if job.get('state')!='queued' or job.get('delivery_token')!=row.get('delivery_token') or job.get('delivery_state') not in ('reserved','unavailable'):continue
   job.update(delivery_state='sent',delivered_to=receiver,delivery_expires_at=time.time()+90,updated=time.time(),message='Delivered. Waiting for your chat to claim the edit.')
   editor.store_job(job['project'],job)
   return {'request_id':job['delivery_id'],'immutable_request_id':job['request_id'],'delivery_token':job['delivery_token'],'project':job['project'],'text':job['native_message'],'state':'delivering','time':time.time()}
 return None

def acknowledge(action):
 from . import editor
 if not action or not action.get('immutable_request_id'):return
 job=editor.read(action['project'])
 if job.get('delivery_id')==action['request_id']:
  delivery(action['project'],job['request_id'],'delivered',action.get('delivery_token'))

def require_owner(p):
 from . import editor
 job=editor.read(p.name)
 if job.get('execution_mode')!='chat' or not job.get('delivery_token'):return
 if job.get('state')!='editing' or job.get('cancel') or job.get('claimed_delivery')!=job['delivery_token']:
  raise util.Fail('Claim the newest saved native request before editing this project.')
 if os.environ.get('CREATORCUT_NATIVE_DELIVERY')!=job['delivery_token']:
  raise util.Fail('Use the current native delivery token with this command. An older delivery cannot edit this video.')

def retry(pid):
 from . import editor,videos,activity_store
 p=videos._dir(pid)
 with util.file_guard(p/'.request.guard',timeout=5),util.file_guard(p/'.editor-job.guard',timeout=5):
  job=editor.read(pid)
  import shutil
  if shutil.disk_usage(p).free<2_500_000_000:raise util.Fail('Free at least 2.5 GB before editing. Your footage and settings are saved.')
  if job.get('execution_mode')!='chat':raise util.Fail('This saved request uses another editing connection.')
  if job.get('state') not in ('failed','cancelled'):return response(job)
  if any(row.get('running') and row.get('project')==pid for row in activity_store.records()):raise util.Fail('Your current editing step is still closing. Your request is saved; try again shortly.')
  from . import requests
  if requests.active(p).get('id')!=job['request_id']:raise util.Fail('Your choices changed. Make the video with your current settings.')
  job.update(state='queued',cancel=False,updated=time.time(),message='Waiting for your chat to start…')
  _new_delivery(job,'foreground');job['delivery_state']='unavailable'
  editor.store_job(pid,job);return response(job)

def fail(p,note):
 from . import editor,annotations
 require_owner(p)
 with util.file_guard(p/'.editor-job.guard',timeout=5):
  job=editor.read(p.name)
  if any(row.get('running') and row.get('project')==p.name for row in __import__('editkit.activity_store',fromlist=['records']).records()):raise util.Fail('Finish or stop the current command before closing this edit.')
  job.update(state='failed',message='This edit could not finish. Your footage and saved versions are safe.',failure_note=str(note)[:1000],updated=time.time())
  editor.store_job(p.name,job)
 annotations.recover_unpublished_batch(p.name,job.get('request_id'),job.get('previous_version',0))
 return response(job)
