"""Colour grade that matches the reference's look, with guards so the result is never blown out or muddy.

1. Measure both videos on sampled frames: brightness, contrast, saturation, warmth, and how much is clipped.
2. Build one FFmpeg filter: exposure/contrast/saturation (eq), warmth (colortemperature), and a gentle
   highlight roll-off so whites never clip.
3. Check the graded frames: clipped highlights < 0.5 %, crushed blacks < 2 %, brightness within a safe range.
   If a check fails, the grade is softened and checked again (never shipped unchecked)."""
from __future__ import annotations

from pathlib import Path

from . import util


def stats(video: Path, n: int = 16, vf: str | None = None) -> dict:
    import cv2
    import numpy as np
    import subprocess
    import tempfile
    tmp = Path(tempfile.mkdtemp(prefix="cc-grade-"))
    dur = util.probe(video)["duration"]
    vals = []
    for k in range(n):
        t = min(dur * (k + 0.5) / n,max(0,dur-.05))
        f = tmp / f"{k}.png"
        args = [util.ffmpeg_bin(), "-v", "error", "-ss", f"{t:.2f}", "-i", str(video), "-frames:v", "1"]
        if vf:
            args += ["-vf", vf]
        subprocess.run(args + ["-y", str(f)], capture_output=True, timeout=60)
        if not f.is_file():continue
        im = cv2.imread(str(f))
        if im is None:
            continue
        im = cv2.resize(im, (270, int(270 * im.shape[0] / im.shape[1])))
        hsv = cv2.cvtColor(im, cv2.COLOR_BGR2HSV).astype(np.float32)
        lum = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY).astype(np.float32)
        b, g, r = [im[..., i].astype(np.float32) for i in range(3)]
        vals.append({"lum": lum.mean() / 255, "contrast": lum.std() / 255, "sat": hsv[..., 1].mean() / 255,
                     "warm": (r.mean() - b.mean()) / 255, "clip": float((im.max(axis=2) >= 250).mean()),
                     "crush": float((lum <= 6).mean())})
    for f in tmp.glob("*"):
        f.unlink()
    tmp.rmdir()
    return {k: round(float(np.median([v[k] for v in vals])), 4) for k in vals[0]} if vals else {}


def build_filter(ref: dict, ours: dict, strength: float = 1.0) -> str:
    """Move ours towards the reference, capped so a big difference never produces an extreme grade."""
    clamp = lambda v, a, b: max(a, min(b, v))
    d_lum = clamp((ref["lum"] - ours["lum"]) * strength, -0.12, 0.10)
    contrast = clamp(1 + (ref["contrast"] / max(ours["contrast"], 0.02) - 1) * 0.7 * strength, 0.88, 1.22)
    sat = clamp(1 + (ref["sat"] / max(ours["sat"], 0.02) - 1) * 0.8 * strength, 0.75, 1.3)
    temp = int(clamp(6500 - (ref["warm"] - ours["warm"]) * 9000 * strength, 5200, 7600))
    gamma = clamp(1 + d_lum * 1.6, 0.85, 1.15)
    # soft shoulder: compress the top 12 % instead of letting whites clip
    return (f"eq=contrast={contrast:.3f}:saturation={sat:.3f}:gamma={gamma:.3f},"
            f"colortemperature=temperature={temp},curves=all='0/0.012 0.5/0.5 0.88/0.86 1/0.955'")


def match(ref: dict, our_video: Path, out: Path, progress=None) -> dict:
    """Grade our footage towards the reference's measured colour (grade.stats of the reference, kept in its style
    kit) with safety checks. Returns {filter, before, after, ref, ok}."""
    say = progress or (lambda *_: None)
    ours = stats(our_video)
    if not ours:raise util.Fail('The source video colour could not be measured. Check the source video before grading.')
    strength, last = 1.0, None
    for attempt in range(4):
        vf = build_filter(ref, ours, strength)
        after = stats(our_video, n=10, vf=vf)
        if not after:raise util.Fail('The reference colour test did not produce readable frames. No replacement look was applied.')
        ok = after["clip"] < 0.005 and after["crush"] < 0.02 and 0.22 <= after["lum"] <= 0.68
        last = {"filter": vf, "before": ours, "after": after, "ref": ref, "ok": ok, "strength": strength}
        if ok:
            break
        strength *= 0.6                      # soften and check again
    if not last["ok"]:
        last["filter"] = "curves=all='0/0.012 0.5/0.5 0.88/0.86 1/0.955'"   # only protect highlights
        last['after']=stats(our_video,n=10,vf=last['filter'])
        last['matched_reference']=False
        last['fallback_reason']='Reference match exceeded clipping limits; only highlight protection was applied.'
    else:last['matched_reference']=True
    say("Applying the colour grade…", 0.6)
    util.run([util.ffmpeg_bin(), "-v", "error", "-y", "-i", str(our_video), "-vf", last["filter"], "-c:v", "libx264", "-preset", "veryfast",
              "-crf", "16", "-pix_fmt", "yuv420p", "-g", "30", "-c:a", "copy", str(out)])
    return last


# ======================================================== automatic grade ====
# The colourist's order: exposure (for the face) -> white balance -> contrast -> saturation (skin protected) ->
# creative look last, with a soft highlight roll-off so whites never clip. The look is a LUT this app generates
# itself (no third-party LUT licences): a clean, cinematic Rec.709 look that suits talking heads.

def write_lut(path: Path, strength: float = 0.75, contrast: float = 0.32, sat: float = 1.08, split: float = 1.0, n: int = 33,
              gains: tuple = (1.0, 1.0, 1.0), gamma: float = 1.0, recover: float = 0.0) -> Path:
    """One LUT for the whole correction: white-balance gains and exposure (gamma) first, then the look, then the
    highlight shoulder, so nothing a correction brightens can ever clip."""
    import colorsys
    import numpy as np
    lines = ["TITLE \"CreatorCut clean cinematic\"", f"LUT_3D_SIZE {n}"]
    g = np.linspace(0, 1, n)
    for b in g:                              # .cube order: red changes fastest
        for gg in g:
            for r in g:
                R0, G0, B0 = r, gg, b
                R, G, B = (min(1.2, c * gn) ** (1 / gamma) for c, gn in ((r, gains[0]), (gg, gains[1]), (b, gains[2])))
                Y = 0.2126 * R + 0.7152 * G + 0.0722 * B
                if recover and Y > 0.62:                                    # highlight recovery: bright walls and windows
                    Yr = 0.62 + (Y - 0.62) * (1 - recover)                  # come down, faces (mid-tones) stay put
                    R, G, B = (c * Yr / Y for c in (R, G, B))
                    Y = Yr
                if Y > 0.8:                                                 # corrections never clip: shoulder first
                    Y_s = 0.8 + 0.18 * np.tanh((Y - 0.8) / 0.18)
                    R, G, B = (c * Y_s / Y for c in (R, G, B))
                    Y = Y_s
                s = 1 / (1 + np.exp(-6 * (Y - 0.5)))
                s = (s - 1 / (1 + np.exp(3))) / (1 / (1 + np.exp(-3)) - 1 / (1 + np.exp(3)))
                Y2 = Y + (s - Y) * contrast
                Y2 = 0.012 + Y2 * (1 - 0.012)                               # a touch of lift: no crushed blacks
                if Y2 > 0.8:                                                # soft shoulder: highlights roll off
                    Y2 = 0.8 + 0.16 * np.tanh((Y2 - 0.8) / 0.16)
                k = Y2 / Y if Y > 1e-4 else 1.0
                R2, G2, B2 = (min(1.0, max(0.0, c * k)) for c in (R, G, B))
                h, l, sa = colorsys.rgb_to_hls(R2, G2, B2)
                skin = 0.0 <= h <= 0.14 or h >= 0.97
                sa = min(1.0, sa * (1.0 if skin else sat))
                R2, G2, B2 = colorsys.hls_to_rgb(h, l, sa)
                sh = max(0.0, 1 - Y2 / 0.4) * 0.012 * split                  # shadows a hair cooler
                hi = max(0.0, (Y2 - 0.6) / 0.4) * 0.010 * split              # highlights a hair warmer
                R2, B2 = R2 - sh + hi, B2 + sh - hi * 0.8
                out = [min(1.0, max(0.0, x)) for x in (R2, G2, B2)]
                corr = [min(1.0, c) for c in (R, G, B)]                    # the correction is always applied in full,
                fin = [c + (o - c) * strength for c, o in zip(corr, out)]   # the creative look at `strength`
                lines.append(" ".join(f"{v:.6f}" for v in fin))
    path.write_text("\n".join(lines) + "\n")
    return path


def measure(video: Path, face=None, n: int = 12, vf: str | None = None) -> dict:
    """Face brightness and hue, neutral-surface colour cast, and the global stats."""
    import cv2
    import numpy as np
    import subprocess
    import tempfile
    tmp = Path(tempfile.mkdtemp(prefix="cc-measure-"))
    dur = util.probe(video)["duration"]
    face_l, face_h, neutral, glob = [], [], [], []
    for k in range(n):
        f = tmp / f"{k}.png"
        args = [util.ffmpeg_bin(), "-v", "error", "-ss", f"{dur * (k + 0.5) / n:.2f}", "-i", str(video), "-frames:v", "1"]
        subprocess.run(args + (["-vf", vf] if vf else []) + ["-y", str(f)], capture_output=True, timeout=60)
        im = cv2.imread(str(f))
        if im is None:
            continue
        im = cv2.resize(im, (360, int(360 * im.shape[0] / im.shape[1])))
        H, W = im.shape[:2]
        rgb = im[..., ::-1].astype(np.float32) / 255
        lum = rgb @ np.array([0.2126, 0.7152, 0.0722], np.float32)
        hsv = cv2.cvtColor(im, cv2.COLOR_BGR2HSV).astype(np.float32)
        if face:
            x, y, w, h = face
            fx0, fx1, fy0, fy1 = int((x + w * 0.25) * W), int((x + w * 0.75) * W), int((y + h * 0.3) * H), int((y + h * 0.75) * H)
            face_l.append(float(lum[fy0:fy1, fx0:fx1].mean()))
            lab = cv2.cvtColor(im[fy0:fy1, fx0:fx1], cv2.COLOR_BGR2LAB).astype(np.float32)
            face_h.append((float(lab[..., 1].mean() - 128), float(lab[..., 2].mean() - 128)))   # skin: a > 0 (red), b > 0 (yellow)
        sat = hsv[..., 1] / 255
        m = (sat < 0.18) & (lum > 0.3) & (lum < 0.92)
        if m.mean() > 0.03:
            neutral.append(rgb[m].mean(axis=0))
        glob.append({"lum": float(lum.mean()), "contrast": float(lum.std()), "sat": float(sat.mean()),
                     "clip": float((rgb.max(axis=2) >= 0.985).mean()), "crush": float((lum <= 0.025).mean()),
                     "warm": float(rgb[..., 0].mean() - rgb[..., 2].mean())})
    for f in tmp.glob("*"):
        f.unlink()
    tmp.rmdir()
    out = {k: round(float(np.median([g[k] for g in glob])), 4) for k in glob[0]} if glob else {}
    out["face_lum"] = round(float(np.median(face_l)), 4) if face_l else None
    out["face_ab"] = [round(float(np.median([v[0] for v in face_h])), 1), round(float(np.median([v[1] for v in face_h])), 1)] if face_h else None
    out["neutral"] = [round(float(v), 4) for v in np.median(neutral, axis=0)] if neutral else None
    return out


# looks the creator can pick instead of the reference's (targets, applied gently and safety-checked like any grade)
LOOKS = {
    "natural": {"lum": 0.5, "contrast": 0.22, "sat": 0.24, "warm": 0.03, "force": True},
    "bright": {"lum": 0.6, "contrast": 0.2, "sat": 0.25, "warm": 0.04, "force": True},
    "warm": {"lum": 0.5, "contrast": 0.24, "sat": 0.3, "warm": 0.14, "force": True},
    "cinematic": {"lum": 0.42, "contrast": 0.3, "sat": 0.22, "warm": 0.06, "force": True},
    "moody": {"lum": 0.33, "contrast": 0.32, "sat": 0.18, "warm": 0.02, "force": True},
    "bw": {"lum": 0.48, "contrast": 0.3, "sat": 0.2, "warm": 0.0, "force": True, "bw": True},
}


def distinct_look(ref: dict) -> bool:
    """Does the reference have a deliberate look (moody, very warm/cool, punchy/washed) worth copying, rather than
    plain footage? Then we match it; otherwise our clean cinematic grade is used."""
    return ref.get("lum", 0.45) < 0.33 or abs(ref.get("warm", 0.05)) > 0.12 or ref.get("sat", 0.3) > 0.45 or ref.get("sat", 0.3) < 0.12 \
        or ref.get("contrast", 0.22) > 0.3


def auto(video: Path, out: Path, face=None, ref: dict | None = None, progress=None) -> dict:
    """Grade a talking-head video automatically (see the order above). Every result is checked; a failing check
    softens the grade and checks again."""
    import math
    say = progress or (lambda *_: None)
    say("Reading the colour of your footage…", 0.05)
    m0 = measure(video, face)
    lut = out.parent / "look.cube"
    target_face, target_lum = 0.56, 0.46
    if ref and ref.get("lum") is not None:              # aim for the reference's own brightness (bright and airy stays bright)
        target_lum = max(0.34, min(0.64, float(ref["lum"])))
        target_face = max(0.5, min(0.66, 0.56 + (target_lum - 0.46) * 0.6))
    moody = not ref or float(ref.get("lum", 0.45)) < 0.45     # the vignette only where the reference is moody
    strength, report = 1.0, {}
    for attempt in range(4):
        gains = (1.0, 1.0, 1.0)
        if m0.get("neutral"):                                   # white balance: partly neutralise the cast
            r, g, b = m0["neutral"]
            gains = (max(0.88, min(1.12, 1 + (g / max(r, 1e-3) - 1) * 0.7 * strength)), 1.0,
                     max(0.88, min(1.12, 1 + (g / max(b, 1e-3) - 1) * 0.7 * strength)))
        cur = m0.get("face_lum") or m0["lum"]
        tgt = target_face if m0.get("face_lum") else target_lum
        gamma = max(0.8, min(1.3, 1 + (math.log(max(cur, 0.02)) / math.log(tgt) - 1) * strength))
        bright_bg = m0["lum"] > (m0.get("face_lum") or m0["lum"]) + 0.06      # background brighter than the face (white walls, windows)
        write_lut(lut, strength=strength, contrast=0.45, sat=1.12, gains=gains, gamma=gamma, recover=(0.45 if bright_bg else 0.2) * strength)
        steps = [f"lut3d=file='{lut}'"] + ([f"vignette=angle={0.2 + 0.43 * strength:.3f}:mode=forward"] if moody else [])   # draws the eye to the face
        vf = ",".join(steps)
        if ref and (distinct_look(ref) or ref.get("force")):   # the reference's (or the chosen) look on top
            m1 = measure(video, face, n=8, vf=vf)
            vf += "," + build_filter(ref, m1, strength * 0.8).split(",curves")[0]
        if ref and ref.get("bw"):
            vf += ",hue=s=0"
        after = measure(video, face, n=8, vf=vf)
        ok = after["clip"] < 0.006 and after["crush"] < 0.02 and 0.2 <= after["lum"] <= 0.7 and \
            (after.get("face_lum") is None or 0.42 <= after["face_lum"] <= 0.7) and \
            (after.get("face_ab") is None or (after["face_ab"][0] > 2 and after["face_ab"][1] > 2))
        report = {"filter": vf, "before": m0, "after": after, "ref": ref, "ok": ok, "strength": round(strength, 2), "gains": gains, "gamma": round(gamma, 3),
                  "matched_reference": bool(ref and distinct_look(ref))}
        if ok:
            break
        strength *= 0.65
    if not report["ok"]:
        report["filter"] = "lut3d=file='" + str(write_lut(lut, strength=0.35, recover=0.2)) + "'"
    say("Grading…", 0.5)
    util.run([util.ffmpeg_bin(), "-v", "error", "-y", "-i", str(video), "-vf", report["filter"], "-c:v", "libx264", "-preset", "veryfast",
              "-crf", "16", "-pix_fmt", "yuv420p", "-g", "30", "-c:a", "copy", str(out)])
    return report
