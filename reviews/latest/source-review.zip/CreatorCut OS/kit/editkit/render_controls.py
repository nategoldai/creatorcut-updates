"""Mechanical Studio controls for the main renderer, separate from creative inference.
Only a verbatim current brief override may waive a selected scalar control.
"""
import copy,math
from . import util

def _settings(p):
 from . import requests
 request=requests.active(p)
 return request.get('settings',{}) if request else {}  # Existing reviewed projects remain valid until their next explicit Studio request.

def normalized(p,plan,scene=None):
 cfg=_settings(p);out=copy.deepcopy(plan);scene=scene or {};overrides=scene.get('studio_control_overrides',{})
 prompt=str(cfg.get('brief',{}).get('prompt',''))
 def enabled(key):
  row=overrides.get(key) if isinstance(overrides,dict) else None
  if row is None:return True
  quote=row.get('quote','') if isinstance(row,dict) else ''
  if not isinstance(quote,str) or len(quote.strip())<12 or quote not in prompt or len(str(row.get('reason','')).strip())<20:
   raise util.Fail('A Studio control override needs the exact current brief sentence and a concrete reason: '+key)
  return False
 if cfg.get('sfx') is False and enabled('sfx'):
  out.setdefault('audio',{})['events']=[]
 if cfg.get('zoom') is False and enabled('zoom'):
  out.setdefault('background',{})['zooms']=[]
 if cfg.get('music')=='none' and enabled('music'):
  out.setdefault('audio',{}).pop('music',None)
 if cfg.get('music_selection') and enabled('music'):
  from . import music_library
  out=music_library.apply_plan(p,cfg,out)
 if 'music_volume' in cfg and enabled('music_volume') and out.get('audio',{}).get('music'):
  value=cfg['music_volume']
  if type(value) not in (int,float) or not math.isfinite(value) or not 0<=value<=.5:raise util.Fail('The saved music volume needs a value between 0 and 0.5.')
  out['audio']['music']['volume']=value
 if type(cfg.get('progress_bar')) is bool and enabled('progress_bar'):
  out['studio_progress_bar']=cfg['progress_bar']
 return out

def prepare(p):
 plan=util.read_json(p/'edit-plan.json',default={});scene=util.read_json(p/'scene-plan.json',default={})
 actual=normalized(p,plan,scene)
 if actual!=plan:
  # This is called under the per-project lock before render fingerprints are taken.
  util.write_durable_json(p/'edit-plan.json',actual)
 return actual

def errors(p,scene,plan):
 try:
  actual=normalized(p,plan,scene)
 except util.Fail as error:return [error.message]
 issues=[]
 if actual.get('audio',{})!=plan.get('audio',{}):issues.append('Apply the saved Studio sound/music controls before rendering.')
 if actual.get('background',{}).get('zooms')!=plan.get('background',{}).get('zooms'):issues.append('Zoom is off in Studio: remove background punch-ins.')
 if actual.get('studio_progress_bar')!=plan.get('studio_progress_bar'):issues.append('Apply the saved Studio progress-bar switch before rendering.')
 return issues
