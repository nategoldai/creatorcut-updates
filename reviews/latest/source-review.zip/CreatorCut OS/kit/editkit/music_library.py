"""Explicit music choices, audio validation and immutable editor handoff."""
import hashlib,json,os,tempfile,urllib.request,time,shutil,secrets,re,copy
from pathlib import Path
from contextlib import nullcontext
from . import util
MODES={'none','auto','library','upload'}

def catalogue():return util.read_json(util.KIT/'studio/app/music-catalogue.json')['tracks']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def validate(file):
 data=json.loads(util.run([util.ffprobe_bin(),'-v','error','-show_format','-show_streams','-of','json',str(file)],timeout=15).stdout)
 if not any(s.get('codec_type')=='audio' for s in data.get('streams',[])) or any(s.get('codec_type')=='video' for s in data.get('streams',[])):
  raise util.Fail('Choose an audio track such as MP3, M4A or WAV.')
 duration=float(data.get('format',{}).get('duration',0))
 if not 0<duration<10800:raise util.Fail('Choose a playable audio track under three hours.')
 return duration

def intent(pid,client,sequence):
 from . import videos
 p=videos._dir(pid)
 if not re.fullmatch(r'[a-zA-Z0-9_-]{8,80}',client or '') or type(sequence) is not int or not 0<sequence<2**53:raise util.Fail('Refresh the music panel and try again.')
 with util.file_guard(p/'.music-intent.guard',timeout=5):
  record=util.read_json(p/'music-intent.json',default={});clients=record.get('clients',{})
  if sequence<=clients.get(client,0):raise util.Fail('A newer music choice replaced this one.')
  clients.pop(client,None);clients[client]=sequence;clients=dict(list(clients.items())[-16:]);token=secrets.token_hex(16)
  util.write_durable_json(p/'music-intent.json',dict(token=token,clients=clients))
 return {'ok':True,'token':token}

@__import__('contextlib').contextmanager
def intent_guard(pid,token):
 from . import videos
 p=videos._dir(pid)
 with util.file_guard(p/'.music-intent.guard',timeout=5):
  if not token or util.read_json(p/'music-intent.json',default={}).get('token')!=token:raise util.Fail('A newer music choice replaced this one.')
  yield

def state(pid):
 from . import videos
 p=videos._dir(pid);cfg=videos.load(pid);pending=util.read_json(p/'next-settings.json',default={})
 if 'music' in pending:
  cfg.update({k:pending[k] for k in ('music','music_selection') if k in pending})
  if 'music_selection' not in pending:cfg.pop('music_selection',None)
 receipt=cfg.get('music_selection') or {};mode=receipt.get('mode') if receipt else ('none' if cfg.get('music') in (None,'none','') else 'auto')
 return dict(ok=True,project=pid,mode=mode,music=cfg.get('music','none'),selection=receipt or None,queued='music' in pending)

def clear_pending_music(p):
 """Under the request/job guards, a later immediate choice supersedes only queued music."""
 file=p/'next-settings.json';pending=util.read_json(file,default={})
 if not any(key in pending for key in ('music','music_selection')):return
 for key in ('music','music_selection'):pending.pop(key,None)
 if pending:util.write_durable_json(file,pending)
 else:file.unlink(missing_ok=True)

def _save(pid,value,receipt,guard=None):
 from . import videos,editor
 p=videos._dir(pid)
 with util.file_guard(p/'.request.guard',timeout=5),util.file_guard(p/'.editor-job.guard',timeout=5),(guard() if guard else nullcontext()):
  if editor.read(pid).get('state') in editor.ACTIVE:
   pending=util.read_json(p/'next-settings.json',default={});pending.update(music=value,music_selection=receipt);util.write_durable_json(p/'next-settings.json',pending)
  else:
   clear_pending_music(p)
   def update(cfg):
    cfg['music']=value;cfg['music_selection']=receipt;cfg.setdefault('choice_origins',{})['music']='studio'
   videos.update(pid,update)
 return state(pid)

def selected_file(pid):
 from . import videos
 cfg=state(pid);return verified_file(videos._dir(pid),cfg.get('selection') or {})

def verified_file(p,receipt):
 relative=receipt.get('project_file','');file=(p/relative).resolve()
 if not relative or not file.is_relative_to(p.resolve()) or not file.is_file() or sha(file)!=receipt.get('sha256'):
  raise util.Fail('Choose your track again to finish preparing it. Your previous video is safe.')
 return file

def save_mode(pid,mode,guard=None):
 if mode not in MODES:raise util.Fail('Choose a music option from the menu.')
 # Browsing/upload mode is not a committed track until the file has been verified.
 if mode in ('library','upload'):return {'ok':True,'pending':True,'mode':mode}
 return _save(pid,'none' if mode=='none' else 'auto',dict(mode=mode,instruction='Do not add background music.' if mode=='none' else 'AI: choose suitable background music for this exact video, preserve the voice, and record the selected track in the scene plan.'),guard=guard)

def _attach(pid,file,receipt,guard=None):
 from . import videos
 p=videos._dir(pid);duration=validate(file);digest=sha(file)
 folder=p/'work/music';folder.mkdir(parents=True,exist_ok=True)
 if not folder.resolve().is_relative_to(p.resolve()):raise util.Fail('The music folder needs checking.')
 suffix=Path(file).suffix.lower();target=folder/(digest+suffix)
 if target.exists() and (target.is_symlink() or sha(target)!=digest):raise util.Fail('The saved track changed. Choose it again.')
 if not target.exists():
  fd,name=tempfile.mkstemp(prefix=digest+'-',suffix='.pending',dir=folder);os.close(fd);pending=Path(name)
  try:shutil.copyfile(file,pending);pending.replace(target)
  finally:pending.unlink(missing_ok=True)
 receipt=dict(receipt,sha256=digest,duration=duration,project_file=target.relative_to(p).as_posix())
 return _save(pid,target.relative_to(util.ROOT).as_posix(),receipt,guard=guard)

def upload(pid,file,name,guard=None):
 if file.stat().st_size>100*1024*1024:raise util.Fail('Choose a track smaller than 100 MB.')
 return _attach(pid,file,dict(mode='upload',id='upload-'+sha(file)[:20],title=Path(name).stem[:120],artist='Your uploaded music',rights='Music file supplied by the user.'),guard=guard)

def select(pid,track_id,row=None,guard=None):
 if track_id in ('none','auto'):return save_mode(pid,track_id,guard=guard)
 from . import music_provider
 rows={str(r['id']).removeprefix('ccmixter-'):r for r in catalogue()};row=row or rows.get(track_id) or music_provider.lookup(track_id)
 if not row or str(row.get('id'))!=track_id:raise util.Fail('Choose a track from the music library.')
 url=row['url'];source=row['source']
 if not music_provider.safe_url(url,'/content/') or not music_provider.safe_url(source,'/files/'):
  raise util.Fail('Choose a track from the music library.')
 key=hashlib.sha256(url.encode()).hexdigest();folder=util.STUDIO_OUT/'assets/music';folder.mkdir(parents=True,exist_ok=True)
 target=folder/(key+'.mp3');record=folder/(key+'.json')
 with util.file_guard(folder/(key+'.guard'),timeout=5):
  saved=util.read_json(record,default={})
  valid=target.is_file() and not target.is_symlink() and saved.get('source')==url and saved.get('sha256')==sha(target)
  if not valid:
   fd,name=tempfile.mkstemp(prefix=key+'-',suffix='.mp3',dir=folder);os.close(fd);temp=Path(name)
   try:
    request=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (compatible; CreatorCutMusic/1.0)','Referer':source})
    started=time.monotonic()
    with (guard() if guard else nullcontext()):pass
    with urllib.request.urlopen(request,timeout=15) as response,temp.open('wb') as out:
     if not music_provider.safe_url(response.geturl(),'/content/'):raise util.Fail('This music download changed location. Choose another track.')
     expected=int(response.headers.get('Content-Length',0));count=0
     while True:
      with (guard() if guard else nullcontext()):pass
      data=response.read(65536)
      if not data:break
      count+=len(data)
      if count>25_000_000 or time.monotonic()-started>60:raise util.Fail('The music download is taking too long. Your previous choice is safe.')
      out.write(data)
    if not count or (expected and count!=expected):raise util.Fail('The track download was interrupted. Please try again.')
    validate(temp);saved=dict(source=url,sha256=sha(temp));temp.replace(target);util.write_durable_json(record,saved)
   except util.Fail:raise
   except Exception as e:raise util.Fail('Music could not download. Your previous choice is saved; try again.') from e
   finally:temp.unlink(missing_ok=True)
  result=_attach(pid,target,dict(mode='library',id=track_id,title=row['title'],artist=row['artist'],source=source,credit=row.get('credit',''),rights=row.get('credit') or source),guard=guard)
  prune_cache(folder)
  return result

def prune_cache(folder):
 files=sorted((f for f in folder.glob('*.mp3') if re.fullmatch(r'[a-f0-9]{64}\.mp3',f.name)),key=lambda f:f.stat().st_mtime,reverse=True);total=0
 for file in files:
  total+=file.stat().st_size
  if total>96*1024*1024:
   try:
    with util.file_guard(file.with_suffix('.guard'),timeout=0):
     file.unlink(missing_ok=True);file.with_suffix('.json').unlink(missing_ok=True)
   except util.LockBusy:pass

def apply_plan(p,settings,plan):
 """Keep exact project-local audio, voice and independent sound events."""
 out=copy.deepcopy(plan);receipt=settings.get('music_selection') or {};mode=receipt.get('mode')
 if settings.get('music')=='none':out.setdefault('audio',{}).pop('music',None);return out
 if mode=='auto':
  music=out.get('audio',{}).get('music') or {}
  if not music.get('src') or not music.get('rights') or len(str(music.get('reason','')).strip())<12:
   raise util.Fail('Auto music: choose the actual track and record audio.music.src, rights and reason before rendering.')
  from . import soundtrack
  file=soundtrack.resolve(p,music['src']);validate(file)
  music['selection']={'mode':'auto','sha256':sha(file),'reason':music['reason']}
  return out
 if mode not in ('library','upload'):return out
 file=verified_file(p,receipt);music=out.setdefault('audio',{}).setdefault('music',{})
 music.update(src=receipt['project_file'],rights=receipt.get('rights') or receipt.get('credit'),volume=settings.get('music_volume',.12),selection={'mode':mode,'id':receipt['id'],'sha256':receipt['sha256']})
 # Explicit selection always uses the whole chosen file, never a stale plan's offset/trim.
 for key in ('media_start','duration'):music.pop(key,None)
 return out
