#!/usr/bin/env python3
"""CreatorCut OS: engine entry point.

You never need to run this yourself: Claude (or ChatGPT Codex) runs it for you.
Usage:  python3 edit.py <command>      (Windows: python edit.py <command>)
"""
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.environ["HF_HUB_DISABLE_TELEMETRY"]="1"
os.environ["DO_NOT_TRACK"]="1"
os.environ["HF_HOME"] = str(ROOT / "kit/cache/huggingface")
os.environ["HF_HUB_CACHE"] = str(ROOT / "kit/cache/huggingface/hub")
os.environ["XDG_CACHE_HOME"] = str(ROOT / "kit/cache")

VENV_PY = ROOT / ".venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")

# Use the toolkit's private Python environment when it exists (created by `install`).
IN_VENV = Path(sys.prefix).resolve() == (ROOT / ".venv").resolve()
if VENV_PY.exists() and not IN_VENV and sys.argv[1:2] != ["install"]:
    args = [str(VENV_PY), str(Path(__file__).resolve())] + sys.argv[1:]
    if os.name == "nt":
        import subprocess
        sys.exit(subprocess.call(args))
    os.execv(str(VENV_PY), args)

if sys.version_info < (3, 9):
    sys.exit("CreatorCut OS needs its private Python. Ask your AI assistant to install CreatorCut OS (type: install).")

try:  # nicer output on Windows terminals
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

sys.path.insert(0, str(ROOT / "kit"))
from editkit.cli import main  # noqa: E402

if __name__ == "__main__":
    main()
