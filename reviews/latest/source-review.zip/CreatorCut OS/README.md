# CreatorCut

Your AI chat edits. Studio holds your footage, references and style choices.

1. Install CreatorCut, then open its folder as your AI project. In Claude, click **Trust** once.
2. Add your raw footage and B-roll in Studio. Choose a reference, style, captions, effects, colour and music.
3. Press **Make my video**. Keep your CreatorCut chat open: Claude starts by itself; in Codex, type **go**.
4. Watch the real progress in Editor. When it is ready, play or download your video. Add timeline feedback and press **Update video** for a new version.

If your chat needs an answer or permission, answer it there. If the chat closes, reopen the same CreatorCut folder and type **continue**. Your footage and saved versions stay safe.

Save a style as a preset to use it again. Tell your chat when a preference should apply to future videos; it keeps that preference in this installation.

CreatorCut keeps its tools and your videos together in the installation folder. Updates preserve your projects, presets, references and memory. A running edit must finish or stop before an update installs.
